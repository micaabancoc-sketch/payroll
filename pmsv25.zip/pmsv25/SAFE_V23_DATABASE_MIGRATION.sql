-- PMS V23 SAFE MIGRATION (MariaDB 10.4 / XAMPP)
-- Apply only to a BACKED-UP, CLONED V22 database that has the V22 eligibility migration.
-- This migration is repeatable, preserves historical attendance/payroll rows,
-- and does NOT claim to recompute old approved salary payments.

-- Snapshot original employee schedules, available for forensic/audit review.
CREATE TABLE IF NOT EXISTS pms_v23_previous_schedules (
    employee_id BIGINT UNSIGNED NOT NULL PRIMARY KEY,
    work_schedule_id BIGINT UNSIGNED NULL,
    saved_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT IGNORE INTO pms_v23_previous_schedules (employee_id,work_schedule_id)
SELECT id, work_schedule_id FROM employees WHERE deleted_at IS NULL;

-- The original schema contains STD-MFS: Mon-Sat 08:00-17:00 and Sunday rest.
-- Update the employee SCHEDULE reference only; historical attendance rows are NOT rewritten.
UPDATE employees e
JOIN work_schedules ws ON ws.code = 'STD-MFS' AND ws.is_active = 1 AND ws.deleted_at IS NULL
SET e.work_schedule_id = ws.id
WHERE e.deleted_at IS NULL AND (e.work_schedule_id IS NULL OR e.work_schedule_id <> ws.id);

-- Only the standard schedule should be the default for new employees.
UPDATE work_schedules SET is_default = CASE WHEN code = 'STD-MFS' THEN 1 ELSE 0 END
WHERE deleted_at IS NULL;

-- Existing FOR_REVIEW payroll totals were computed under earlier attendance logic.
-- Reopen them as DRAFT to prevent approval until Calculate All is run again.
-- DO NOT touch APPROVED/FINALIZED/PAID payroll records here.
UPDATE payroll_periods SET status = 'DRAFT'
WHERE status = 'FOR_REVIEW' AND deleted_at IS NULL;

SELECT 'V23 migration completed. Recalculate each affected DRAFT period; do not use old calculated rows as final pay.' AS next_step;
