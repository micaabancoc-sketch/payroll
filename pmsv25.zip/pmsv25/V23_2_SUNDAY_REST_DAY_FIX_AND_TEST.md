# PMS V23.2 — Sunday REST DAY Time Log Hotfix

## Purpose
Allow manual Time In/Out on Sunday without converting the record into a regular workday, automatic overtime, late/undertime deduction, or extra payroll earnings. Historical Sunday source data is preserved.

## Scope and policy
- Standard employee schedule: Monday–Saturday, 8:00 AM–5:00 PM, 12:00–1:00 PM unpaid lunch; Sunday is REST DAY.
- A Sunday **manual attendance time log** is accepted with original Time In/Out preserved and is automatically classified REST_DAY. It records **zero ordinary worked hours**, late, undertime and inferred overtime. It does **not** create a second regular paid day or an absence deduction. This classification does not certify that an employee performed no work.
- HR/Manager-approved, verified overtime remains independently payable through `overtime_requests`, including applicable rest-day premiums under a verified, authorized workflow. **Real work must not go unpaid simply because it happened on Sunday.**
- Sunday QR scans are recorded with REST_DAY status too, but an unverified complete QR Sunday attendance remains an exception requiring review before payroll approval.
- Existing Sunday MANUAL attendance is shown as REST_DAY in the Attendance table, with old inferred 9-hour overtime masked in the display. The source database rows are NOT silently rewritten by a page load. Payroll calculation defensively ignores stale ordinary PRESENT/OT classifications on Sundays.
- Historic payroll already FINALIZED/PAID is not recalculated or edited. Do not use a draft preview as an official payslip.

## Installation — CLONED TEST DATABASE only
1. Export/backup your current V23.1 XAMPP folder and `attendance_payroll_v23_test` database.
2. Extract `PMS_V23_2_SUNDAY_REST_DAY_FIX_FULL_PROJECT.zip` to `C:\xampp\htdocs\`; the folder inside is `pmsv23_2`.
3. V23.2 defaults to existing `attendance_payroll_v23_test`. Verify `api/config/config.php` DB settings before testing; do not point to production.
4. No new table/column is required; **no SQL migration needs to be imported**. Optional `PMS_V23_2_READ_ONLY_SUNDAY_CHECK.sql` contains a read-only query for checking old records.
5. Open `http://localhost/pmsv23_2/` and hard-refresh (Ctrl+Shift+R). Log in as HR.

## Demonstration cases
1. HR > Attendance > Manual entry > Maria Santos > `2026-10-18` (Sunday), 08:00–17:00, status Automatic. A Sunday hint appears. Save. Expected: REST DAY, raw time in/out visible, 0.00 ordinary worked hours and 0.00 unverified OT, zero late/undertime. (If this record already exists, use authorized correction, not new entry.)
2. HR > Attendance > Manual entry > Maria Santos > `2026-10-19` (Monday), 08:00–17:00. Expected: PRESENT, 8.00 worked hours, 0.00 OT.
3. HR > Payroll Processing > existing Oct 16–31 DRAFT > Calculate All. Sunday MANUAL time logs are no longer unexplained "rest-day work" batch exceptions. The work schedule's unscanned Sundays are not absences. Other attendance exceptions must still be resolved and finalization remains blocked if needed.
4. Any genuine Sunday work or QR scans without documented authorization need separate verification and applicable rest-day compensation. This hotfix does not automatically pay rest-day premiums from raw scan timestamps.

## Offline tests completed
- `php tests/v23_2_sunday_rest_day_test.php` (11 cases) PASSED.
- PHP syntax, frontend JavaScript syntax and inline-script syntax checked.
- XAMPP/MariaDB transactions **not** exercised in this environment. Use the cloned database and demo data first, review payroll deductions and verified Sunday work before approval.
