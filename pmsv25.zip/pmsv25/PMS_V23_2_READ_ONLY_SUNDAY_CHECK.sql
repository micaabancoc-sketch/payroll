-- PMS V23.2: READ-ONLY Sunday record diagnostic (MariaDB/XAMPP).
-- NO SCHEMA MIGRATION is required. Does NOT change tables or attendance rows.
-- Run only against your CLONED V23 test database if you want to inspect old Sunday records.
SELECT a.id, a.employee_id, a.attendance_date, a.source,
       a.time_in, a.time_out, a.status AS stored_status,
       a.worked_hours AS stored_worked_hours,
       a.overtime_hours AS stored_overtime_hours,
       a.late_minutes, a.undertime_minutes
FROM attendance a
WHERE a.deleted_at IS NULL
  AND DAYOFWEEK(a.attendance_date) = 1
ORDER BY a.attendance_date DESC, a.employee_id;
