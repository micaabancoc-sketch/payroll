-- PMS V22 — PAYROLL ELIGIBILITY / APPROVAL FIX (MariaDB 10.4, MySQL-compatible)
-- IMPORTANT: BACK UP THE DATABASE AND TEST ON A CLONE FIRST.
-- Run against attendance_payroll_v19_test or your dedicated cloned database,
-- NOT an original/production database. Does not delete accounts, payroll, attendance or history.
-- This migration is re-runnable: its targeted username backfill runs only on FIRST addition of the column.

SET @v22_column_already_exists := (
  SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS
  WHERE TABLE_SCHEMA = DATABASE()
    AND TABLE_NAME = 'employees'
    AND COLUMN_NAME = 'payroll_eligible'
);
SET @v22_ddl := IF(
  @v22_column_already_exists = 0,
  'ALTER TABLE employees ADD COLUMN payroll_eligible TINYINT(1) NOT NULL DEFAULT 1 AFTER status',
  'SELECT ''payroll_eligible already exists — no ALTER necessary'' AS migration_note'
);
PREPARE v22_migrate FROM @v22_ddl;
EXECUTE v22_migrate;
DEALLOCATE PREPARE v22_migrate;

-- FIRST RUN ONLY: classify exact extra test usernames as excluded from payroll.
-- Existing normal STAFF, HR and MANAGER employees remain eligible (= 1).
-- Does NOT deactivate, delete or archive test accounts or their history.
UPDATE employees e
JOIN users u ON u.employee_id = e.id AND u.deleted_at IS NULL
SET e.payroll_eligible = 0
WHERE @v22_column_already_exists = 0
  AND LOWER(u.username) IN ('test','demo2')
  AND e.deleted_at IS NULL;

SELECT e.employee_number, CONCAT_WS(' ',e.first_name,e.last_name) AS employee_name,
       e.status, e.payroll_eligible, u.username
FROM employees e LEFT JOIN users u ON u.employee_id=e.id AND u.deleted_at IS NULL
WHERE e.deleted_at IS NULL
ORDER BY e.id;
