@echo off
REM ---------------------------------------------------------------------------
REM Automatic absence reconciler for the 30-minute late cut-off rule.
REM
REM Marks scheduled employees ABSENT shortly after their own cut-off passes,
REM even if they never open the scanner. Idempotent; safe to run repeatedly.
REM
REM Register with Windows Task Scheduler (run once, as Administrator):
REM
REM   schtasks /Create /TN "PMS Attendance Absence Reconciler" /SC MINUTE /MO 1 ^
REM     /TR "C:\xampp\htdocs\pms\tools\attendance_absence_reconciler.bat" /RU SYSTEM /F
REM
REM Verify:
REM   schtasks /Run    /TN "PMS Attendance Absence Reconciler"
REM   schtasks /Query  /TN "PMS Attendance Absence Reconciler" /V /FO LIST
REM   schtasks /Delete /TN "PMS Attendance Absence Reconciler" /F
REM ---------------------------------------------------------------------------
setlocal

set "ROOT=%~dp0.."

if defined PHP_BIN (
  set "PHP=%PHP_BIN%"
) else (
  set "PHP=C:\xampp\php\php.exe"
)

"%PHP%" "%ROOT%\api\cli\attendance_absence_reconciler.php"
exit /b %ERRORLEVEL%