# PMS V18 — Individual Draft Payroll + Navigation/UI Fix (TEST BUILD)

**Test build only. Not certified for real wages, loan deductions, taxes, or government remittances.**

## Exactly what changed compared with the PMS V17 consolidated test build

1. **Calculate Employee (Save Draft):** HR selects a finished DRAFT cutoff and an active employee, runs `Check Employee`, and then chooses `Calculate Employee`. On the server this validates all scheduled attendance dates, computes that employee, and saves the payroll row, itemized earnings/deductions, statutory rows, and calculation snapshot in a single database transaction. A repeat calculation safely replaces that **one unlocked, not-yet-disbursed** employee row; it does **not** erase other employees' DRAFT payroll.
2. **Never finalize a partial batch:** Individual calculation leaves the payroll period in `DRAFT`. The only way to reach `FOR_REVIEW` is the existing full-batch `Calculate All` operation, which validates the attendance for every active eligible employee; a failure rolls its payroll inserts/deletes back. `APPROVED`, `FINALIZED`, and payment actions cannot be reached from the partial DRAFT state.
3. **Attendance exception details:** `Check Employee` lists exact dates and verification reasons. `View Batch Exceptions` lists affected employees/dates for the selected period, without generating payroll or marking any missing scan ABSENT. Read-only diagnostics are separate from payroll saving.
4. **Payroll UI:** Clearly labeled `Check Employee`, `Calculate Employee (Save Draft)`, `Calculate All`, and `View Batch Exceptions` controls. The screen shows a basic/gross/deductions/net summary and line-by-line earnings/deductions. Employee and cutoff selection automatically reset stale preview authorization. Individual drafts are labeled DRAFT, not issued payslips.
5. **Staff navigation:** Simple V16-style Staff sidebar with single Attendance, Leave, Overtime, My QR, My Payslips, and My Loans links—no second 'My Personal' group and no duplicate routes.
6. **HR/Manager navigation:** Management-only sidebar. Their personal Profile, My Attendance, My Leave, My Overtime, My QR, My Payslips, and My Loans links are in the **upper-right profile dropdown**. Desktop hamburger collapses/expands the common sidebar. Manager HR Personal Reviewer item is visible only for the designated Manager (not Admin).
7. **HR/Manager My Loans:** `?mine=1` filters the loan list **and summary on the PHP backend** by the signed-in employee ID. The HR personal-loans screen hides company-management actions; the management page remains available via HR's sidebar. This is a self-service VIEW, not a replacement for independent approvals of HR's own loans, which still need work.

## Important outstanding limitations

- No live MariaDB/XAMPP end-to-end test has been performed. PHP and JS syntax checks only demonstrate syntactic validity. Verify all calculations with independent HR validation before release.
- All earlier V17 known limitations remain, including independent HR personal leave/OT/loan reviews, 13th-month independent approval, validation of statutory schedules/tax rules, old archive flows, and policy review of payroll deductions.
- Individual DRAFT amounts are not paid, approved, nor official payslips; they are only draft records for testing and review. Complete the entire employee batch (including verified exceptions) before attempting finalization.
- Existing manual attendance with suspicious OT hours must be audited; this build does not retroactively rewrite historical records or auto-approve OT.
- Company-loan release / agency remittance require actual supporting evidence; no money is transferred by PMS.

## Safe installation

1. Back up the existing `pmsv17` source and **full database** in phpMyAdmin. Keep `pmsv15` and `pmsv17` intact.
2. Extract `PMS_V18_PAYROLL_UI_TEST_BUILD.zip` under `C:\xampp\htdocs\` to create `C:\xampp\htdocs\pmsv18`.
3. **Use a cloned database** (example `attendance_payroll_v18_test`) containing your existing demo rows. Never run payroll tests against production.
4. If the clone already has all V17 migration fields (`assigned_supervisor_id`, `employee_deduction_payments`, and `loans.agency_evidence_reference`), **do not re-run migrations**. If the cloned schema is from V16, first apply `SAFE_V17_DATABASE_MIGRATION.sql` from the ZIP. V18 itself requires **no schema changes** (see `SAFE_V18_DATABASE_MIGRATION.sql`).
5. Set `DB_NAME`/database config for the V18 copy to the **cloned** database. Open `http://localhost/pmsv18/` and sign in as HR. Hard refresh with Ctrl+F5 on the first visit.
6. Payroll Processing → choose `October 16–31, 2026` and `Demo Staff Member` → `Check Employee` → if clear, `Calculate Employee (Save Draft)`. The period should show one employee, still DRAFT; the other employees should remain untouched. Do not click `Calculate All` just to force a test.
7. Choose Employee #8 in `Check Employee` to confirm missing-scan dates and block. Click `View Batch Exceptions` on the selected cutoff to see everybody's issues without inserting absences.
8. Verify Staff sidebar has no duplication. Sign in HR and Manager and verify management sidebar + personal profile dropdown; test their My Loans page and check it lists only their own loans.
9. **Do not finalize or disburse** any payroll until attendance, adjustments, loans, taxes, and statutory rules have been independently verified.

## Rollback

Stop using `pmsv18` and switch back to unchanged `pmsv17`. Restore the cloned test database from your backup if any saved demo DRAFT calculations must be undone. **Never** delete or alter actual paid payroll history.
