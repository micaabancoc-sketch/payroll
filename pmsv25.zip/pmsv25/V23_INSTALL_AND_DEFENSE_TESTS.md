# PMS V23 — consolidated test build; NOT production certified

**Source:** Full V22 ZIP + focused fixes. Keep the original project and DB backup unchanged.

## Install (test database only)
1. In phpMyAdmin, export your working **V22 test database** using Quick > SQL, including structure and records.
2. Create `attendance_payroll_v23_test` and import that SQL dump. Make sure it doesn't contain `USE attendance_payroll_v22_test` (which would redirect import).
3. Import `SAFE_V23_DATABASE_MIGRATION.sql` **into the V23 test database**. All V22 columns (including `payroll_eligible`) must already exist.
4. Extract the full ZIP into `C:\xampp\htdocs\pmsv23` and verify `api/config/config.php` DB_NAME matches `attendance_payroll_v23_test`.
5. Open `http://localhost/pmsv23/` and login as HR. Refresh browser cache (Ctrl+Shift+R).
6. Recalculate October 16–31 DRAFT payroll after reviewing the attendance exceptions. Do not use the old V22 payroll figures.

## Changes implemented in source
- Standard Mon–Sat schedule (08:00–17:00, noon–1PM unpaid break); Sunday rest. Existing employee schedule references migrated with original mapping preserved. The attendance engine uses STD-MFS for newly evaluated dates.
- Manual 08:00–17:00 attendance is **8 hours**, not 9; no automatic manual/rest-day OT; payable overtime reads only verified overtime_requests.applied_hours.
- Sunday attendance with work punches triggers **REST_DAY_WORK_REQUIRES_VERIFIED_PREMIUM_REVIEW** during payroll checking. It is not silently counted as regular work or made payable without appropriate verification.
- A new manual entry for Sunday work is refused; no forged rest-day wages.
- Correction (manual records only) uses the original attendance ID; prevents date duplicates, requires reason, retains audit history, resets FOR_REVIEW to DRAFT after an editable correction. QR raw punches cannot be silently edited.
- Attendance *View* is read-only. Attendance date filter uses only saved payroll periods; shows `Oct 16–31, 2026`, sorted latest first. Date options available to Staff without revealing payroll money.
- Staff, HR and Manager keep role-specific navigation from V22. HR/Manager personal links remain in profile dropdown.
- Account actions use one three-dot menu. Inactive staff omitted from manual-entry options.
- Leave Archived tab, unwanted checkbox/bulk options, and Archive actions hidden from UI; historical records remain intact.
- HR Salary Payments is displayed from the Payroll Processing page **after FINALIZED**, using the existing secure payment ledger embedded without another sidebar. Agency Loan Remittance and Disbursements are removed from the main sidebar, but underlying data and payment audit trails are **preserved**. Agency payment recording is outside the simplified PMS workflow; no automatic agency payment is claimed.
- Payslip detail is labeled `DRAFT PREVIEW — NOT FOR PAYMENT` before finalization; print disabled. Employee final payslip API policy is unchanged, including the finalized-only access control.
- Employee check/recalculate is an optional advanced area inside a selected payroll period rather than a large standalone card.

## Optional historical test-data correction
`OPTIONAL_V23_TEST_DATA_REPAIR.sql` is **not** run automatically. Only after checking that the affected 08:00–17:00 9-hour rows were invented test entries, import it on your *cloned test DB*. It snapshots originals, writes audit entries, and resets invalid manual hours to 8 worked, 0 OT; on Sunday marks REST_DAY. It does **not** authorize Sunday work or pay a rest-day premium.

## Defense validation plan (do not skip)
1. Employee directory: Staff, HR, and Manager accounts exist; default eligible/active filtering; schedule shows fixed Standard Mon–Sat.
2. Attendance: Sunday with no scan is REST_DAY; Mon–Sat 08:00–17:00 => 8h, OT=0. Test manual correction Oct 11 -> Oct 12: same record ID, no duplicate, audit with reason. `View` read-only; QR correction blocked.
3. OT: Oct 28 verified QR request has 60 payable minutes; Oct 17/18/24/25 must not show or pay 9h OT. Any Sunday work still requires a separate documented premium decision.
4. Attendance Payroll Period dropdown must exactly match the periods saved in Payroll Processing, label `Oct 16–31, 2026`.
5. Recalculate DRAFT payroll; check exact monthly salary, basic half, late, verified OT, statutory deductions. Resolve all missing scans/rest-day activity; do not approve with exceptions. Check test employee records and payroll eligibility.
6. Payroll approval and finalize transitions; confirm Staff has **no payslip** during DRAFT/FOR_REVIEW; HR sees clearly labeled draft breakdown. On FINALIZED, Staff may see official payslip.
7. Salary Payment Records button appears for finalized periods, and `PAID` must reflect recorded actual payment with reference, not just a button click.
8. Verify Admin account actions (three-dot), Leave requests/calendar no Archived tab, and no unusable checkboxes.

## Important financial/legal limitations
- The project **cannot be certified fully DOLE/SSS/PhilHealth/Pag-IBIG/BIR compliant** from syntax checks or screenshots. Current statutory rates must be validated against the employer's actual pay setup and effective-dated agency tables.
- The V22 data sets `payroll.rest_days_paid=0`, selecting a 313-day 6-day factor. Whether the fixed monthly wage legally includes paid Sunday/rest days (often the 365 factor for monthly-paid workers) must be confirmed by the employer before any salary is approved. **Do not blindly use the screenshot's ₱119.81 OT as a legal rate.**
- **Sunday/rest-day hours:** This focused build deliberately blocks unverified rest-day work rather than inventing premium pay. It does not implement a full compensable rest-day/holiday matrix. Resolve actual Sunday work separately.
- Existing APPROVED/FINALIZED/PAID period records remain untouched by the migration. Do not pay or deploy until verified by a qualified local payroll practitioner.
- Other previously tracked items (complete independent reviewer workflows, 13th-month approval, old Archive endpoints, and all government remittance reconciliation) still need full XAMPP functional testing.

## Source references for rate review
- DOLE Labor Code Book III https://dole.gov.ph/book-3-conditions-of-employment/
- DOLE NWPC salary factor FAQ https://nwpc.dole.gov.ph/faqs/
- SSS contributions https://www.sss.gov.ph/pay-contribution
- PhilHealth contribution announcement https://pia.gov.ph/news/philhealth-sets-5-premium-contribution-rate-for-2026/
- Pag-IBIG contribution changes https://pco.gov.ph/other_releases/pag-ibig-members-to-gain-more-benefits-under-new-rates-starting-february-2024/
