# PMS V24 — Defense Test Build (Automatic Absence + Simplified OT)

## What changed (only two functional changes)

### 1. Payroll — reversible AUTO ABSENT after a closed cutoff
- If a **completed payroll cutoff** has a scheduled Monday–Saturday workday with no attendance and no approved leave, that day becomes a **payroll-only presumed absence**. It appears in the payroll row's absent days, itemized unpaid absence deduction, and calculation snapshot (`auto_absent_dates`).
- Sundays/rest days, configured holidays, dates before the employee's hire date and approved paid/unpaid leaves **are not auto-absent**.
- An approved leave without an attendance row is still classified as leave when calculating payroll, so paid leave is not deducted.
- Incomplete QR/time records and conflicting evidence STILL require investigation; the app doesn't equate partial evidence with a full-day absence.
- A period whose end date has not fully passed cannot be calculated, approved or finalized. This avoids applying future absences.
- The system **does not insert false QR scans or overwrite raw attendance evidence**: these are payroll-only presumed absences. HR may correct source attendance with a reason and recalculate an unlocked period.
- **Existing FINALIZED and PAID records are NOT recalculated or modified.** If auto deductions exceed pay, the financial exception remains blocked for review.

### 2. Overtime — no employee Accept/Decline gate
- **Manager assigns → HR authorizes before scheduled OT → regular Time Out → authorized QR OT Time In/Out → Manager confirms actual work → HR verifies payable minutes → Payroll**.
- Employees can **view the OT assignment**; they no longer click Accept/Decline. The old endpoints return HTTP 410 and old response history is preserved, not deleted.
- HR can authorize newly assigned `PENDING` OT without a recorded employee response. Existing legacy `ACCEPTED` OT is still supported.
- HR authorization alone is **never payable**. The original QR scans, Manager confirmation, and HR payroll verification are required.
- **LEGAL NOTE:** Removing an acceptance UI is NOT a blanket right to compel ordinary overtime. Mandatory overtime is restricted by Philippine Labor Code Article 89 to qualifying documented emergency/urgent cases. If employee cannot report for non-emergency OT, escalate to HR/Manager; do not fake scans or auto-deduct for unworked OT.

## Install safely
1. **Backup both** the old project directory and MariaDB database (Export SQL through phpMyAdmin).
2. Prefer a dedicated testing database cloned from your working V23.3/V23.2 database, especially if any periods are already FINALIZED/PAID.
3. Extract the updated folder `pmsv24` into `C:\xampp\htdocs\` and inspect `pmsv24/api/config/config.php`: `database.name` defaults to `attendance_payroll_v23_test`. Change `DB_NAME` to your actual test-clone database name if necessary. **Never point this test build to a real payroll database.**
4. **No SQL migration is required** when using a database already migrated for V23.3. Do not import a full older SQL dump or rerun historical migrations over existing data.
5. Visit `http://localhost/pmsv24/` and force refresh `Ctrl+Shift+R`; re-login if needed.

## 2-minute pre-recording smoke tests (clone only)
1. HR > Attendance: select an **already elapsed** cutoff with test staff; note a missing Mon–Sat scheduled date and a Sunday date. DO NOT manually create absence scans.
2. HR > Payroll Processing > select that **unlocked DRAFT cutoff** > Calculate All. On that staff's row: `Absent (incl. auto)` should count missing weekdays, not Sunday/approved leave. Hover the `auto-absent date(s) — correctable` text to see dates. Check payslip draft: `Unpaid Absence` is a separate line.
3. If incomplete Time In/Out or financial calculation exceptions remain, stop; resolve with authorized correction and recalculate. Do not skip safeguards.
4. Manager > Overtime > Assign future OT to supervised staff. **No Accept/Decline button** in employee My Overtime. HR > Overtime should show `Authorize OT assignment` while assignment is `PENDING`.
5. HR authorize BEFORE scheduled OT start; Staff view assignment; QR OT scan only during valid time window; Manager confirms actual OT; HR verifies; payroll includes only verified actual minutes. For screen-recording, show previously verified historical OT if the future test window cannot be scanned today.

## Suggested defense screen-recording order (about 5–8 scenes)
1. Login/role-based dashboards (Admin, Manager, HR, Staff) and no salary visibility for Manager.
2. HR employee list: show 3 Cashiers, assigned supervisor, Mon–Sat schedule.
3. Attendance cutoff: Present, Late, Undertime, approved Leave, Sunday REST DAY, missing-day AUTO ABSENT **in payroll**.
4. Manager OT assignment > HR authorization > Staff reads notification (no response click) > previous QR history, Manager confirmation, HR verification.
5. Payroll DRAFT: absence, late, undertime, OT, uniform, loan and statutory deductions; show formula/breakdown. **Use a clone with valid sample records**.
6. Payroll Approve > Finalize only on a **separate valid test period** with no unresolved exceptions and reviewed rates. Staff final payslip appears; FINALIZED != PAID.
7. HR payment records / Staff payslip PAID vs UNPAID; do not record a real payment unless genuinely disbursed, mark any simulation as DEMO.
8. 13th month: salary-earned/12 and no duplicate routine contributions; BIR taxable-excess handling still needs independent verification.

## Validation performed here
- PHP syntax lint across 119 PHP files: passed.
- Inline scripts in 22 frontend HTML files: 18 compiled successfully.
- Offline behavior tests: closed-cutoff missing weekday auto-absent; Sunday, holiday and approved leave excluded; future cutoff not auto-absent; HR can authorize PENDING OT; COMPLETED OT cannot be authorized retroactively.
- **NOT validated**: real MariaDB/XAMPP transaction behavior, payroll statutory rate compliance, company policy classification, all role permission routes, or money transfers. Do not claim production certification in your defense.

DOLE basis for emergency compulsory overtime: https://dole.gov.ph/book-3-conditions-of-employment/ (Article 89).
