﻿# Attendance & Payroll Management System

A complete, end-to-end attendance and payroll system for a small to medium
business. Employees check in and out by scanning a QR code; the system applies
work schedules, shift rules and company policy to produce finalised payslips.

- **Backend:** PHP 8.1+ REST API, PDO/MySQL (MariaDB 10.4+), no Composer
  dependencies â€” plain PHP with a PSR-4 style autoloader.
- **Frontend:** static HTML, vanilla JavaScript (ES5-safe), hand-written CSS
  and inline SVG charts. No build step, no npm.
- **QR codes:** a pure-PHP ISO/IEC 18004 encoder, so the system works on hosting
  without the GD extension. Codes are emitted as SVG.

---

## 1. Requirements

| Requirement | Notes |
|---|---|
| PHP 8.1 or newer | `pdo_mysql`, `mbstring`, `json` and `openssl` extensions |
| MySQL 5.7+ / MariaDB 10.2+ | InnoDB, `utf8mb4` |
| Any web server | Apache (XAMPP), Nginx, or the PHP built-in server |

The GD extension is **not** required.

---

## 2. Installation

### 2.1 Create the database

```bash
mysql -u root -p -e "CREATE DATABASE attendance_payroll CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;"
```

### 2.2 Configure the connection

Edit `api/config/config.php` and set your credentials:

```php
'database' => [
    'host'     => '127.0.0.1',
    'port'     => 3306,
    'name'     => 'attendance_payroll',
    'user'     => 'root',
    'password' => '',
    'charset'  => 'utf8mb4',
],
```

### 2.3 Import the database

```bash
mysql -u root -p < database/main.sql
```

This creates all 31 tables, loads the reference data (roles, departments,
positions, shifts, schedules, leave types, allowances, deductions, holidays)
and creates the three demo accounts with working password hashes.

The single `main.sql` file contains the complete schema, reference data, and
ready-to-use demo accounts.

### 2.4 Make the storage folder writable

The API writes QR images and logs to `storage/`:

```bash
chmod -R 775 storage
```

### 2.5 Serve the application

The project root holds `index.html`, which **is** the sign-in page. Point your
web server's document root at the project folder (or a subfolder of it) and open
it:

```
http://localhost/pms/          <- opens the sign-in page
http://localhost/pms/index     <- same thing, no extension needed
```

**XAMPP/Apache** â€” copy the project into `htdocs/pms` and browse to the URL
above. The bundled `.htaccess` sets `DirectoryIndex index.html`, so nothing else
is required.

**PHP built-in server** â€” the API can be served on its own for development:

```bash
php -S 127.0.0.1:8099 api/index.php
```

That serves `http://127.0.0.1:8099/api/...` only. The frontend is static, so
either use Apache, or serve the whole project and set `SITE_ROOT` when testing:

```bash
php -S 127.0.0.1:8099 index.php     # serves the pages; see tests/routing_test.sh
```

> The frontend and the API are independent: the pages are static files and PHP is
> only ever used by the API. You can host them on different machines and point
> the frontend at the API with `window.PMS_API_BASE` (set in `frontend/js/api.js`
> or in a small inline `<script>` before it loads).

---

## 3. Demo accounts

Every seeded account uses the password **`Password123@`**.

| Username | Role | Access |
|---|---|---|
| `admin` | Administrator | Everything, including user management and settings |
| `manager` | Manager | Employees, attendance, leave, overtime, payroll and reports |
| `staff` | Staff | Linked self-service attendance, requests and payslips |

The schema, roles, reference data, and demo users are consolidated in
`database/main.sql`.

> **Change these passwords before going live.** The API enforces a lockout after
> repeated failed logins and records every sensitive action in the audit trail.


---

## 4. Project layout

```
pms/
â”œâ”€â”€ index.html                 Sign-in page â€” the entry point at the project root
â”œâ”€â”€ .htaccess                  DirectoryIndex, friendly URLs, blocks source/config
â”œâ”€â”€ api/
â”‚   â”œâ”€â”€ index.php              Front controller (bootstrap -> middleware -> router)
â”‚   â”œâ”€â”€ bootstrap.php          Autoloader, error handling, CORS, global limiter
â”‚   â”œâ”€â”€ routes.php             The whole route table with per-route permissions
â”‚   â”œâ”€â”€ config/config.php      Database, app, security and path settings
â”‚   â”œâ”€â”€ core/                  Database, Auth, Router, Request, Response, Validator,
â”‚   â”‚                          Settings, Logger, AuditLogger, ValidationException
â”‚   â”œâ”€â”€ middleware/            Cors, SecurityHeaders, RateLimiter
â”‚   â”œâ”€â”€ services/              All business logic + the pure-PHP QR encoder
â”‚   â”‚                          (QrCodeGenerator.php); no HTTP in here
â”‚   â”œâ”€â”€ controllers/           Thin HTTP adapters over the services
â”‚   â””â”€â”€ cli/                   Command-line entry points (absence reconciler)
â”€â”€ 
â”œâ”€â”€ frontend/
â”‚   â”œâ”€â”€ dashboard.html         KPIs, charts, activity feed
â”‚   â”œâ”€â”€ attendance/            Register view + camera QR scanner
â”‚   â”œâ”€â”€ employees/             Directory, profiles, QR badges
â”‚   â”œâ”€â”€ leave/ overtime/       Leave requests; admin OT assignments (accept/decline)
â”‚   â”œâ”€â”€ payroll/               Periods, processing, payslips
â”‚   â”œâ”€â”€ reports/               Report builder with CSV export
â”‚   â”œâ”€â”€ settings/              Settings, holidays, schedules, users, audit
â”‚   â”œâ”€â”€ css/app.css            Entire stylesheet
â”‚   â””â”€â”€ js/                    api.js, app.js, charts.js, dashboard.js
â”œâ”€â”€ database/
â”‚   â””â”€â”€ main.sql               Schema, reference data and demo accounts
â”œâ”€â”€ storage/                   QR images and logs (writable)
â”œâ”€â”€ tools/                     attendance_absence_reconciler.bat (Task Scheduler)
â””â”€â”€ tests/
    â”œâ”€â”€ run_all.sh             Runs every check in one pass
    â”œâ”€â”€ api_test.sh            End-to-end API suite
    â”œâ”€â”€ frontend_smoke.sh      Endpoint contract used by the UI
    â”œâ”€â”€ routing_test.sh        Entry point + every relative link resolves
    â”œâ”€â”€ js_syntax_check.js     Frontend syntax + DOM id check
    â”œâ”€â”€ placeholder_check.php  PDO placeholder reuse check
    â”œâ”€â”€ reset_test_data.php    Makes the API suite re-runnable
    â”œâ”€â”€ late_cutoff_absence_test.php  30-min cut-off + automatic absence
    â”œâ”€â”€ qr_matrix.php          QR function-module verification
    â”œâ”€â”€ verify_qr.py           Cross-check against segno
    â”œâ”€â”€ verify_codewords.py    Reed-Solomon codeword verification
    â””â”€â”€ debug_payslip.php      Renders a payslip through the services
```

---

## 5. How the calculation engine works

### Attendance (`AttendanceEngine`)

Every scan resolves the employee's schedule for that weekday, then classifies
the day:

| Status | Meaning |
|---|---|
| `PRESENT` | Within the grace period of the shift start |
| `LATE` | Arrived after the grace period; minutes are recorded |
| `UNDERTIME` | Left before the shift end |
| `HALF_DAY` | Worked less than half the scheduled hours |
| `ABSENT` | No scan and no approved leave |
| `ON_LEAVE` | Covered by an approved leave request |
| `HOLIDAY` | Falls on a configured holiday; premiums applied |

The engine also derives **late minutes**, **undertime minutes**, **regular
hours**, **overtime hours** and **night-differential hours** (22:00â€“06:00 by
default) for each day.

### The 30-minute late cutoff and automatic absence

**Time-in scanning (always allowed):**

A time-in is **never** rejected on the basis of a lateness threshold. Regardless
of how late the arrival is, the scan is always recorded and the day is classified
as `LATE` with the actual late minutes stored. The configurable
`attendance.late_cutoff_minutes` (default `30`) is **no longer used to reject
entries**.

Examples (shift start 08:00, grace period 5 minutes):

| Time-in | Late minutes | Status | Notes |
|---|---|---|---|
| 07:55 | 0 | PRESENT | Within the 5-minute grace period |
| 08:05 | 0 | PRESENT | Exactly one grace period elapsed |
| 08:06 | 1 | LATE | 1 minute late after grace period |
| 08:30 | 25 | LATE | 30 minutes late, minus 5-grace |
| 08:31 | 26 | LATE | 31 minutes late, minus 5-grace |

The late minutes are calculated as **raw minutes late âˆ’ grace period (5)**.
Overtime is derived from the scheduled shift end and actual Time Out, NOT from a corrected Time In. The actual Time In timestamp is always preserved exactly as scanned. The grace period affects only the late-minute calculation, while overtime is measured as minutes worked beyond the scheduled shift end.

**Late-shift scans are recorded, not denied.** The QR camera, an uploaded QR
image, a manual QR token, an operator override, and all API endpoints pass
through `AttendanceService::recordScan()`, which accepts every time-in and
records it as `LATE` with the correct late minutes.

#### Automatic absence without a scan (`AttendanceReconciler`)

Absence must not depend on somebody scanning. `AttendanceReconciler` walks every
active, scheduled employee and marks `ABSENT` once *that employee's* cut-off has
passed with no valid time-in. It is idempotent (one row per employee/day), never
overwrites an existing record, and is serialised by a MySQL advisory lock
(`GET_LOCK`) so overlapping runs cannot process the same employee twice.
`attendance.auto_absence` (default on) can disable it.

Run it from the command line:

```bash
php api/cli/attendance_absence_reconciler.php
```

**It only marks absence when the scheduler actually runs it.** Configure Windows
Task Scheduler once (as Administrator) to run it at least once a minute:

```bat
schtasks /Create /TN "PMS Attendance Absence Reconciler" /SC MINUTE /MO 1 ^
```

1. **Period** â€” an admin opens a payroll period (date ranges may not overlap).
2. **Calculate** â€” for every active employee the engine pulls basic pay,
   attendance-derived amounts, approved overtime, leave with pay, allowances and
   deductions; applies statutory contributions, withholding tax and night
   differential; and writes a `payroll` row.
3. **Review** â€” `DRAFT` â†’ `FOR_REVIEW` â†’ `APPROVED` â†’ `FINALIZED`.
4. **Lock** â€” once finalized the rows are locked; recalculation is refused and
   payslips become readable.

Every rate, multiplier, grace period and statutory bracket is a **setting** in
`system_settings`, editable from the Settings page â€” no code changes needed.

### Rate formulas

```
hourly_rate      = basic_salary / (work_days_per_month x hours_per_day)
daily_rate       = hourly_rate x hours_per_day
basic_pay        = daily_rate for every day actually worked or covered by paid leave
overtime_amount  = overtime_hours x hourly_rate x payroll.overtime_multiplier
night_diff       = night_hours x hourly_rate x (night_differential_multiplier - 1)
holiday_pay      = daily_rate x holiday_rate_multiplier, once per paid holiday
late_deduction   = late_minutes / 60 x hourly_rate
gross_pay        = basic_pay + overtime + night_diff + allowances + holiday_pay
net_pay          = gross_pay - (deductions + contributions + withholding_tax)
```

An **absent day and an unpaid-leave day are unpaid by the `basic_pay` accrual
itself**: no pay is earned for that day, so it is never deducted a second time
(`absence_deduction` and `leave_deduction` stay `0.00`; `absent_days`,
`leave_days` and the working-day counts still report the time). A **paid holiday
is calendar-driven**: it is paid exactly once whether or not an attendance row
exists for the day - a `HOLIDAY` row, or the payroll calendar sweep when nobody
recorded it - so a configured paid holiday can neither be paid twice nor skipped.

---

## 6. Deployment

### The entry point

`index.html` at the project root **is** the sign-in page, so the application is
reachable at the top of the site rather than buried in a subfolder:

```
http://localhost/pms/        ->  index.html  (sign-in)
http://localhost/pms/index   ->  index.html  (same, no extension)
```

The other pages stay under `frontend/`, and all of them are linked relative to
that folder:

```
frontend/dashboard.html        <base href="./">
frontend/employees/index.html  <base href="../">
```

That one line per page is what makes the links work. A browser resolves relative
URLs against the *current directory* unless a `<base>` element overrides it, so
without it `dashboard.html` on `/pms/frontend/employees/index.html` would point
at `/pms/frontend/employees/dashboard.html` â€” which does not exist. Because the
bases are relative and not `"/pms/frontend/"`, the whole project can be dropped
at a domain root or in any subfolder without edits.

`tests/routing_test.sh` checks exactly this: it takes every relative link and
every sidebar entry, applies each page's `<base>`, and confirms the result is a
real page.

### Putting it at a domain root

Nothing is hard-coded to `/pms`, so pointing a virtual host at the project
folder is enough:

```apache
<VirtualHost *:80>
    ServerName attendance.local
    DocumentRoot "C:/xampp/htdocs/pms"

    <Directory "C:/xampp/htdocs/pms">
        AllowOverride All
        Require all granted
    </Directory>
</VirtualHost>
```

Then `http://attendance.local/` opens the sign-in page and the API answers at
`http://attendance.local/api/...`.

### Tightening it further

All of this works with the folder layout as-is, but if your host allows it, the
strongest arrangement is to keep the application code outside the web root and
publish only what the browser needs:

```
/var/www/pms/            <- outside the web root: api/, database/, tests/, storage/
public_html/             <- DocumentRoot
â”œâ”€â”€ index.html
â”œâ”€â”€ frontend/
â””â”€â”€ api/  (a small file that requires ../pms/api/index.php)
```

`api/config`, `api/core`, `api/services`, `api/controllers`, `api/middleware`,
`database`, `tests` and `storage/logs` each ship with their own `.htaccess`
denying all access, so even in the simple layout they are not reachable:

```
/pms/api/core/Auth.php        ->  403
/pms/database/main.sql        ->  403
/pms/tests/api_test.sh        ->  403
/pms/README.md                ->  403
```

---

## 7. Testing

Start the API, then run everything with one command:

```bash
# One-time: create an isolated test database (tests/db_guard.php refuses to run
# the destructive phases against the genuine 'attendance_payroll' database).
mysql -u root -e "CREATE DATABASE attendance_payroll_test CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci"
mysqldump -u root attendance_payroll | mysql -u root attendance_payroll_test

DB_NAME=attendance_payroll_test php -S 127.0.0.1:8099 api/index.php   # terminal 1
DB_NAME=attendance_payroll_test bash tests/run_all.sh                 # terminal 2
```

`run_all.sh` runs every phase in order:

| Check | What it proves |
|---|---|
| Database preflight | The database is seeded before anything else runs; otherwise you get one clear message instead of a puzzling login failure |
| PHP syntax | Every `.php` file parses |
| JavaScript syntax | Every inline and `.js` script parses; every `getElementById` target exists |
| JavaScript behaviour | The real frontend modules run: each one publishes its global, `escapeHtml` actually escapes, the password toggle works, and the API base resolves for every page location |
| PDO placeholders | No named parameter is reused (a `HY093` waiting to happen) |
| QR encoder | The generated matrices still match the reference encoder |
| API end-to-end | 72 assertions across auth, employees, QR, attendance, leave, overtime, payroll, dashboard, reports, audit, settings, security and rate limiting |
| Frontend contract | 43 GET endpoints the UI depends on, each called with a real token |
| Entry point | `/pms/` and `/pms/index` open the sign-in page; every relative link and sidebar entry on every page resolves to a real file; source and config return 403 |
| Late cut-off & automatic absence | 30-minute rule end to end (29/30/31, STAFF/MANAGER), all entry points, preview non-writing, exceptions, overnight boundaries, reconciler idempotency + lock, existing flows and HTTP wiring |
| 13th-month pay | The 13th-month ledger, accumulation and payment rule, over a real period inside a transaction that is rolled back |
| Forced password change | A reset issues the shared temporary password, chains the account to the change-password screen, and only a real password releases it |
| Government contribution tables | `database/migrate_statutory_deductions.php` runs idempotently (CREATE TABLE IF NOT EXISTS / INSERT IGNORE, plus one tolerated ALTER) and reports the payroll columns, statutory tables, contribution schedules and BIR bracket rows it found. No table is ever dropped, truncated or reset |
| Government contributions & withholding tax | 199 checks: the seeded SSS / PhilHealth / Pag-IBIG / BIR schedules are the published ones; every rate, floor, ceiling, MSC step, Pag-IBIG Fund Salary tier and BIR bracket (daily, weekly, semi-monthly and monthly) is applied correctly; a monthly contribution splits across a twice-monthly payroll; the schedule in force for the period is the one used; a recalculation does not duplicate statutory rows; and a finalized period is locked |
| Payroll calculation | 123 checks: basic pay is present days x the daily rate; a paid holiday reaches gross pay exactly once - with or without an attendance row, and never inside `basic_pay`; overtime (1.25 / 2.00 per request type), night differential (22:00-06:00) and allowances keep their own classification; an absent or unpaid-leave day is charged once; a draft recalculation duplicates no payroll rows or items; finalized/paid payroll cannot be recalculated; and a year of 360,000.00 of basic salary produces 30,000.00 of 13th-month pay (part-year, salary change, draft exclusion and the 31 Dec / 1 Jan boundary included) |

### The test database

The database-backed phases write to the database they are pointed at, so
`tests/db_guard.php` runs first and **refuses** production-looking names *and*
the shipped default `attendance_payroll` (the genuine working database). Point
`DB_NAME` at a scratch database instead - `attendance_payroll_test` above, or
any other name that is neither `attendance_payroll` nor a `prod`/`live` name.

To run against a production-looking or genuine database anyway, set
`PMS_ALLOW_PRODUCTION_DB=1` or `PMS_ALLOW_GENUINE_DB=1`; the guard then prints a
loud warning and continues.

Individual suites:

```bash
bash tests/api_test.sh                            # full end-to-end flow
bash tests/api_test.sh http://localhost/pms/api   # same, against Apache
bash tests/frontend_smoke.sh                      # endpoint contract used by the UI
bash tests/routing_test.sh                        # entry point + link resolution
node tests/js_syntax_check.js                     # frontend syntax
node tests/frontend_js_test.js                    # frontend behaviour (runs the JS)
php  tests/placeholder_check.php                  # PDO placeholder reuse
php  tests/late_cutoff_absence_test.php             # 30-min cut-off + auto-absence
php  tests/statutory_deductions_test.php            # SSS / PhilHealth / Pag-IBIG / BIR (199 checks)
php  tests/thirteenth_pay_test.php                  # 13th-month ledger + payment rule (55 checks)
php  tests/payroll_calculation_test.php             # engine arithmetic + 13th-month integration (123 checks)
```

The database-backed suites honour `DB_NAME` and enforce `tests/db_guard.php`
themselves, so a standalone run is guarded exactly like `run_all.sh`.

`frontend_js_test.js` runs the actual modules against a small DOM stub, so it
needs no jsdom or npm install. It exists because parsing is not enough: an
unexported global or a helper that quietly returns its input both pass a syntax
check while leaving every page broken.

The end-to-end suite is **re-runnable**: it creates a fresh employee on every
pass and `tests/reset_test_data.php` clears the payroll period and rate-limit
buckets it left behind.

`tests/debug_payslip.php` renders a payslip directly through the services
(bypassing HTTP), which is useful for inspecting the payroll engine's numbers.

### Known constraints

- The QR encoder emits **SVG only** â€” there is no raster output, because the
  system must run on hosts without the GD extension.
- A QR token is stored as a hash, so the plaintext is shown once at issue time.
  The SVG file written alongside it is the canonical image and is what the UI
  displays.
- The scanner page uses `getUserMedia`, so it requires a secure context
  (`https://` or `localhost`). On a plain HTTP LAN address the camera is blocked
  by the browser; use the manual-entry form there instead.

---

## 8. Security notes

- **Passwords** are stored with `password_hash()` (bcrypt). Sign-in is rate
  limited and the account locks after repeated failures.
- **Tokens** are random 32-byte values; only a SHA-256 hash with a server-side
  pepper is stored, so a database leak does not yield usable tokens.
- **RBAC** is enforced per route. Every route in `api/routes.php` declares the
  permission it needs, and permission checks are centralised in `Auth`.
- **SQL** is always parameterised. Nothing is interpolated into a statement
  except identifiers drawn from a fixed allow-list.
- **Output** is JSON-encoded, and the frontend escapes every interpolated value
  through `App.escapeHtml`.
- **Errors** never leak file paths, SQL or stack traces unless `app.debug` is
  enabled. Debug mode is driven by the `APP_DEBUG` environment variable and
  **defaults to on**, which is convenient during development but must be turned
  off in production:

  ```bash
  APP_DEBUG=false
  ```

- **Audit trail** records who did what, from which IP, for every sensitive
  action.

Change the demo passwords, set `APP_DEBUG=false` and move `storage/` outside
the web root before deploying.

