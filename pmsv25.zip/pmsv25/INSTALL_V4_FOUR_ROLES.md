# V4 — Install and test the four roles

This update changes role separation only; it does **not** certify the remaining payroll/loan/holiday formulas as legally verified. Original CSS and layout templates are retained.

## Install on an EXISTING XAMPP project

1. Back up **both** the project folder and MySQL database using phpMyAdmin export.
2. Extract this ZIP to a **new** project folder (for example `C:\xampp\htdocs\pms-v4`) for testing. Do not overwrite the old project until verification passes.
3. Point the new project at a **copy of your test database** through your existing `api/config` connection settings. Confirm it is not the live payroll database.
4. In phpMyAdmin, select that copied database and run **only** `database/migrations/20261022_four_role_access.sql`.
5. **DO NOT re-import `database/main.sql` into an existing DB**: it contains DROP/TRUNCATE statements. `main.sql` is for fresh test installs only.
6. Log out and sign back in to refresh browser-cached permissions.
7. Sign in as Admin, go to **Employees → Add Employee**. Choose Account Role `HR / Payroll Staff` to create a dedicated test HR account. Choose a real department, then its position. Admin-only `Settings → Role access` now lists four roles.
8. Test each user with the access checklist below, plus an unauthorized **API** request (a hidden link alone does not prove backend security).

## Access expectations

- **Admin:** Settings, user/role/organization management; finalizes payroll, records payments, approves company loans.
- **HR / Payroll Staff:** Manages employee records, prepares payroll and statutory reports, records authorized loan transactions; does NOT approve payroll or release money.
- **Manager:** Reviews attendance/leave, assigns OT, approves payroll and 13th-month runs; does NOT access the unrestricted loan ledger or generate payroll.
- **Employee / Staff:** Own attendance, QR scan, leave and loan requests, own payslips only; no company-wide payroll or loans.

`STAFF` is still the database code for Employee / Staff so previous accounts remain usable; HR uses `HR_PAYROLL`.

## Important behaviors / caveats

- **Job Position ≠ Account Role.** Manager job titles never automatically grant Manager access. Existing employee role assignments are preserved when HR edits a job position. Only Admin can change Account Role in the employee form.
- The new employee form shows Department → Position and separately Account Role for Admin. HR can onboard Employee / Staff accounts without assigning privileges.
- `Payroll Runs` status approval is Manager-only; finalization and release are Admin-only. 13th-month approval/release follow the same separation.
- These changes have static and isolated tests, but **no full running MySQL/XAMPP integration test** was possible in this environment. Do not use this build for live disbursements before local validation.
- Previous policies that were still partially implemented before V4 remain partial; this is an access-control upgrade, not completion of all payroll policies.

## Tests already run

- `php -l` on 74 API and database PHP files: passed
- `node tests/frontend_js_test.js`: 77 passed
- `node tests/dashboard_role_access_test.js`: 3 passed
- `node tests/four_role_access_test.js`: passed
- `node tests/js_syntax_check.js`: passed
- `php tests/payroll_calendar_policy_test.php`: passed
- `php tests/dashboard_loan_route_policy_test.php`: passed

**Extra check:** Verify the Manager sees **Approve** for a 13th-month run submitted by HR, while only Admin sees **Release Approved**. For ordinary payroll, HR sees **Calculate**, Manager **Approve**, and Admin **Finalize/Mark Paid**.
