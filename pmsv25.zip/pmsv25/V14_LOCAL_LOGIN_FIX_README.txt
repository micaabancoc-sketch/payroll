PMS V14 — Local Login Rate-Limit Fix (Full V13 Package + Small Backend Change)
========================================================================

WHAT CHANGED
------------
Only the API rate limiter behavior was updated:
- On XAMPP localhost, with APP_ENV=development (the existing default),
  requests coming from the same computer to localhost / 127.0.0.1
  bypass the 'Too many requests' IP rate limit.
- This bypass applies to the global and login limiter (and kiosk scan limiter)
  on localhost, so existing old rate-limit database records cannot block it.
- Requests from other machines / on the LAN remain limited.
- APP_ENV=production remains rate limited, even on localhost.
- Incorrect-password checks, password hashing, RBAC authorization,
  account activation, and the separate 5-failed-attempt lockout remain enabled.
- Payroll and QR / OT workflows are otherwise unchanged from V13.

IMPORTANT: This is for local development/testing, not for a deployed system.
Before deploying or allowing remote use, set APP_ENV=production and
configure production credentials / TLS correctly.

INSTALLATION (WINDOWS + XAMPP)
--------------------------------
1. Back up C:\xampp\htdocs\pmsv3 and export the current MySQL database.
2. Extract the ZIP (it contains a pmsv3 folder).
3. Copy that pmsv3 folder into C:\xampp\htdocs\ and replace code files.
   Do not delete the old project folder first: existing QR images/uploads
   may be stored locally and must be kept.
4. No SQL import or migration is needed for this V14 login fix.
   DO NOT re-import database/main.sql.
5. Start XAMPP Apache and MySQL. In the same computer, open
   http://localhost/pmsv3/ and refresh (Ctrl+F5).
6. Sign in with the correct existing credentials.

IF LOGIN STILL FAILS
--------------------
- 'Account temporarily locked' means the separate failed-password account
  lockout has been triggered. This fix intentionally does not remove it.
- 'Invalid username or password' means the credentials should be checked.
- If you still see 'Too many requests', confirm that the updated file
  api/middleware/RateLimiter.php is in the folder PHP is serving, and that
  you are using localhost on the computer itself (not an IP from another device).

TESTING
-------
The updated PHP file passed php -l. The bypass was tested for local/remote
and development/production combinations. The actual MySQL/XAMPP installation
was not accessible for live end-to-end testing.
