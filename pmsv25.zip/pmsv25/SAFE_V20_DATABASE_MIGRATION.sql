-- PMS V20 Staff-only Test Mode
-- From existing V19 schema: NO SCHEMA CHANGES REQUIRED.
-- HR/Manager exclusions use the linked account roles in application code.
-- This file intentionally contains NO INSERT, UPDATE, DELETE, ALTER, DROP or CREATE.
-- DO NOT import the old full database dump over your test records.
SELECT 'PMS V20: no SQL migration required; existing employee and user data preserved.' AS migration_status;
