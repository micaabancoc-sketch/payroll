# Payroll System — Final Defense: One Employee / One Cutoff

**Training-only synthetic records. Source: PMS September 2026 demo fixture.**

## Required demonstration

- Employee: **Max Test**, `TEST-SEP26-08`, username `max_sep26`
- Department/Position: Cashier / Cashier
- Employment: Regular Full-Time, monthly basic salary **PHP 20,000**
- Shift: Monday–Saturday, 08:00–17:00 with unpaid 12:00–13:00 lunch (8 paid hours)
- Normal weekly rest day: Sunday
- Cutoff: **1–15 September 2026**, 13 scheduled working days
- Sundays: **6 and 13 September 2026** (no scan, no ordinary absence deduction)
- Scheduled payday: **18 September 2026**, advanced from Sunday Sept 20 under the project payday policy (verify applicable banking holidays).
- Starting fixed monthly basic per complete cutoff: **PHP 10,000** before unpaid time adjustments and other earnings/deductions.

### Attendance / OT / paid leave — every scheduled day

| Date (2026) | Day | Status | Regular In | Regular Out | Payroll impact |
|---|---|---|---|---|---|
| Sep 1 | Tue | Present | 08:00 | 17:00 | Normal |
| Sep 2 | Wed | Present | 08:00 | 17:00 | Normal |
| Sep 3 | Thu | Present | 08:00 | 17:00 | Normal |
| Sep 4 | Fri | Present | 08:00 | 17:00 | Normal |
| Sep 5 | Sat | **Absent** | — | — | One verified unpaid day |
| Sep 6 | Sun | Rest Day | — | — | No ordinary scan or deduction |
| Sep 7 | Mon | Present | 08:00 | 17:00 | Normal |
| Sep 8 | Tue | **Late** | 08:20 | 17:00 | 20 unpaid late minutes |
| Sep 9 | Wed | Present | 08:00 | 17:00 | Normal |
| Sep 10 | Thu | **Undertime** | 08:00 | 16:30 | 30 unpaid undertime minutes |
| Sep 11 | Fri | Present | 08:00 | 17:00 | Normal |
| Sep 12 | Sat | **Approved OT** | 08:00 | 17:00 | Separate OT 17:30–19:30 (2 hours) |
| Sep 13 | Sun | Rest Day | — | — | No ordinary scan or deduction |
| Sep 14 | Mon | **Approved paid SL** | — | — | 1 day paid sick leave; no leave deduction |
| Sep 15 | Tue | Present | 08:00 | 17:00 | Normal |

**Expected evidence:** 13 workday attendance rows, 1 absence, 1 approved paid leave, 20 late minutes, 30 undertime minutes, 2 approved/recorded overtime hours, zero Sunday attendance rows. Original demo attendance source is `IMPORT`, not actual QR scanner transactions. Manager approval flags for the pre-seeded leave and OT are synthetic records, not proof of having clicked the live approval UI.

## Example payroll calculation for the defense

*This is a reference calculation, NOT a certified final net pay. Confirm the actual employee salary basis, workweek, holiday-entitlement pattern, statutory rates, and rounding before grading the software's output.*

To illustrate the **313 annual paid-day factor** for a six-day workweek where unworked Sundays are not separately paid but certain holidays are covered, per NWPC examples:

- Basic cutoff = 20,000 / 2 = **PHP 10,000.00**
- Daily rate = 20,000 × 12 / 313 = **PHP 766.77316...**
- Hourly rate = Daily rate / 8 = **PHP 95.84665...**
- Unpaid absence (1 day) = **PHP 766.77**
- Late (20 minutes) = Hourly rate × 20 / 60 = **PHP 31.95**
- Undertime (30 minutes) = Hourly rate × 30 / 60 = **PHP 47.92**
- Regular weekday OT (2 hours, 125%) = Hourly rate × 2 × 1.25 = **PHP 239.62**
- Approved paid sick leave = **PHP 0 deduction**
- Gross before attendance deductions = **PHP 10,239.62**
- After verified unpaid time, *before government/loan deductions* = **PHP 9,392.98**

This separates payroll calculation from statutory contributions. *Do not claim an exact final net pay without verifying the SSS monthly salary credit for the actual applicable full-month remuneration, PhilHealth basis, Pag-IBIG and BIR period withholding, and that the system uses the same salary factors.* An approved but not released loan must have zero payroll deduction. A separate 13th-month record is **not required for the one-cutoff instructor request**; a final annual 13th month needs full eligible yearly basic earnings, not just this cutoff.

## Presentation walkthrough

1. Run `database/MAX_DEFENSE_VERIFY_READ_ONLY.sql` **after selecting the V9-configured test database** in phpMyAdmin. It only SELECTs; it cannot clear data.
2. Show Max's Employee profile, fixed monthly salary, Monday–Saturday schedule, Sunday rest day.
3. Show the Attendance page filtered to Sep 1–15 and point to Sep 5, Sep 8, and Sep 10.
4. Show the approved paid Sick Leave for Sep 14 under Leave Requests.
5. Show Manager-approved OT Sep 12, along with separate OT scan timestamps (17:30–19:30).
6. HR → Payroll Runs → Sep 1–15 → Generate/Recalculate while the period is DRAFT, on a disposable demo database. Run the query again and compare payroll-item lines to the reference math. **If the output differs, do not silently alter it for the demo; investigate and fix the cause.**
7. Manager reviews/approves; Admin finalizes and records a **fictional test payment** only if computations validate. Employee then checks the payslip. No role should bypass approvals.
8. Explain that QR/time validation for current-day scans must be tested separately; these are **historical imported attendance** records. Avoid portraying imported rows as actual scans.

## Database safety

- `database/SEED_EXISTING_TEST_DB_MAX_DEFENSE.sql` adds a fictional Max record to the **selected test database**, without dropping or deleting existing rows. It does not rewrite conflicting historical entries; use a clean copied TEST database if conflicts exist.
- If you already imported the demo and have the 8 cashier records, **do not re-import**; use the read-only verifier.
- Ensure the **PMS application config** points to the same test database you selected for SQL import; otherwise records may exist in phpMyAdmin but not appear in the app.
- The user cannot receive live MySQL changes from ChatGPT; import and live testing happen on their XAMPP installation.
