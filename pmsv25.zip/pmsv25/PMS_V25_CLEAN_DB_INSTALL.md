# PMS V25 — Clean DB / Operators Only Demo

Use `PMS_V25_NEW_CLEAN_DEMO_READY.sql` as ONE phpMyAdmin import on a brand-new database named `attendance_payroll_v25_clean`.
This imports 45 tables + reference settings + Admin/Manager/HR/Staff login + 3 profiles.
No attendance logs, loans, payroll, payslips, leave requests, overtime, payroll periods or financial transactions are prefilled.
HR and Manager are system operators only, with `payroll_eligible=0` and no personal QR/loans/attendance.
Only Demo Staff Member (employee id 1; EMP-000001) can participate.

Local testing accounts (change password immediately after setup):
  admin / PMSdemo#2027!
  hr / PMSdemo#2027!
  manager / PMSdemo#2027!
  staff / PMSdemo#2027!

The project config defaults to database `attendance_payroll_v25_clean`.
If you set the environment variable `DB_NAME`, that value overrides config.php.
Never import the clean SQL into the old database; never run the destructive database/main.sql.
To show payroll, record staff attendance, create a DRAFT payroll period, then calculate only after cutoff.
Demo mode intentionally prevents finalizing and releasing real payroll.
SQL schema recreated from your uploaded dump; local XAMPP integration is not verified.
