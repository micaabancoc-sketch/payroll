# V8 UI and QR Navigation Fixes — Oct 23, 2026

This V8 release builds directly on V7. **No new database migration is required for these UI fixes.** It does not reset, delete, or silently edit existing records, periods, contributions, or payroll amounts.

## Fixes

1. **`undefined` in sidebar** — V7 added navigation pages (`adjustments`, `deductions`, and `my-qr`) without entries in `NAV_ICONS`. Added all three SVG mappings plus a safe icon fallback for any future page. Links retain the existing sidebar styling.
2. **Employee "My QR Code"** — now opens `frontend/profile/my-qr.html`, a dedicated self-service page that displays the employee's own QR **at the top of the page**, with Download and Print. The secure PHP `/api/qr/svg/{employeeId}` endpoint still verifies ownership. Admin still issues/regenerates QR codes. The regular Profile page is preserved.
3. **Manager Payroll Adjustments** — clarified the empty state. A zero-row list is expected until HR submits a documented adjustment. Manager can approve/reject only Pending records; the role rules are unchanged.
4. **HR Deduction Management** — clear read-only text for HR, explicit no-assignments message, and outdated inactive SSS/PhilHealth/Pag-IBIG/tax deduction masters are marked **System-managed (reference only)** with **Auto-calculated** instead of exposing misleading old demo fixed prices. Actual official statutory rates are handled by the payroll calculation service. Admin-only company-deduction actions remain unchanged. The PHP backend blocks assignment/toggling of reserved deduction codes.
5. **Attendance chart provenance** — charts clarified as DB records that may include historic/imported/test data. **No records are deleted or reclassified.** Use `database/diagnostics/v8_attendance_readonly.sql` to trace the screenshot's 92 ABSENT records in a test database.
6. **Cache busting** — HTML pages now load `app.js?v=20261023-ui8` to prevent the old sidebar code from being served by the browser cache.

## How to install

1. Back up current `/htdocs/pms/` and your test MySQL database.
2. Replace the **code** in `/htdocs/pms/` with this V8 project (or copy only changed frontend files). Preserve your local environment configuration and any user-generated uploads; compare custom settings before overwriting.
3. **Do not re-import `database/main.sql`.** Existing V7 DB and its migrations should remain as installed; this V8 UI patch needs **no new SQL import**.
4. Open PMS in Chrome/Edge, sign out and back in, and press Ctrl+Shift+R once.
5. Test as Admin / HR / Manager / Employee:
   - Admin/Manager/HR nav: no `undefined`; all links have an icon.
   - Employee: **My QR Code** opens a QR card immediately, not the Profile form. SVG appears only if Admin issued a valid QR code.
   - Manager: Payroll Adjustments shows clear guidance when empty; it lists HR requests after submission.
   - HR: Deduction Types shows legacy statutory types as reference-only, and no company deduction actions. Admin may create/assign authorized company deductions.
   - Admin dashboard: ABSENT counts still reflect DB records; use read-only diagnostics before removing any known demo data.

## QA and remaining limits

- V8 UI role/navigation regression: checks every rendered sidebar link for four roles, no `undefined` icon, expected role visibility, real target file, dedicated QR content and backend ownership guard.
- Existing frontend syntax and regression suites run offline; the actual XAMPP/MySQL site still needs live testing.
- V8 **does not certify payroll calculation accuracy or modify statutory tables**, and it does not erase the historical attendance records displayed in the screenshot. Previous V7 legal-rate and end-to-end tests still remain necessary.
