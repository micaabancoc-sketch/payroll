<?php
declare(strict_types=1);

/**
 * Migration: statutory reports & remittance tracking.
 *
 * Run once on an existing database:
 *   php database/migrate_statutory_remittances.php
 *
 * Same shape as the other runners: it opens its own PDO connection
 * (api/bootstrap.php would dispatch an HTTP request and exit before the
 * migration ran), splits the SQL file on statement terminators and treats
 * "already exists"/duplicate-key errors as an already-applied skip.
 *
 * It never drops, truncates or rewrites a remittance, and the three MANAGER
 * permission grants are guarded with JSON_CONTAINS, so a rerun leaves an
 * existing register and role definitions exactly as they were.
 */

$config = require __DIR__ . '/../api/config/config.php';
$db     = $config['database'];

$path = __DIR__ . '/migrations/20261015_statutory_remittances.sql';

if (!is_file($path)) {
    echo "MIGRATION NOT FOUND: {$path}\n";
    exit(1);
}

$ddl = file_get_contents($path);
if ($ddl === false) {
    echo "MIGRATION READ FAILED: {$path}\n";
    exit(1);
}

// Strip standalone comment lines, then split on the statement terminator. The
// migration contains no semicolons inside string literals, so a plain split is
// safe (same approach as database/migrate_employee_loans.php).
$sql        = preg_replace('/^\s*--.*$/m', '', $ddl) ?? '';
$statements = array_values(array_filter(
    array_map('trim', explode(';', $sql)),
    static fn (string $statement): bool => $statement !== ''
));

/** Errors that simply mean the statement was already applied. */
const ALREADY_APPLIED = [
    'Duplicate column name',
    'Duplicate key name',
    'Duplicate foreign key constraint name',
    'already exists',
    'check that column/key exists',
    'duplicate key on write or update',
    'errno: 121',
];

try {
    $pdo = new PDO(
        sprintf('mysql:host=%s;port=%d;dbname=%s;charset=%s', $db['host'], (int) $db['port'], $db['name'], $db['charset']),
        $db['user'],
        $db['password'],
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
    );

    // Prove the target before a single statement runs. DB_NAME can be set by a
    // wrapper (run_all.sh does), so the resolved database is read back from the
    // server instead of being trusted from configuration alone.
    printf(
        "REMITTANCES: target %s on %s:%d (DATABASE() = %s, server %s)\n",
        $db['name'],
        $db['host'],
        (int) $db['port'],
        $pdo->query('SELECT DATABASE()')->fetchColumn(),
        $pdo->query('SELECT VERSION()')->fetchColumn()
    );

    $applied = 0;
    $skipped = 0;

    foreach ($statements as $statement) {
        try {
            $pdo->exec($statement);
            $applied++;
        } catch (\PDOException $e) {
            $message = $e->getMessage();
            $benign  = false;
            foreach (ALREADY_APPLIED as $needle) {
                if (stripos($message, $needle) !== false) {
                    $benign = true;
                    break;
                }
            }

            if (!$benign) {
                throw $e;
            }

            $skipped++;
        }
    }

    $tables = (int) $pdo->query(
        "SELECT COUNT(*) FROM information_schema.tables
          WHERE table_schema = DATABASE() AND table_name IN ('statutory_remittances','statutory_remittance_items')"
    )->fetchColumn();

    $remittanceColumns = (int) $pdo->query(
        "SELECT COUNT(*) FROM information_schema.columns
          WHERE table_schema = DATABASE() AND table_name = 'statutory_remittances'
            AND column_name IN ('reference_no','status','total_employee','filing_reference','paid_reference','paid_date')"
    )->fetchColumn();

    $itemColumns = (int) $pdo->query(
        "SELECT COUNT(*) FROM information_schema.columns
          WHERE table_schema = DATABASE() AND table_name = 'statutory_remittance_items'
            AND column_name IN ('employee_amount','employer_amount','extra_amount','schedule_source','payroll_statutory_id')"
    )->fetchColumn();

    $windowUnique = (int) $pdo->query(
        "SELECT COUNT(DISTINCT index_name) FROM information_schema.statistics
          WHERE table_schema = DATABASE() AND table_name = 'statutory_remittances'
            AND index_name = 'uq_remittance_window'"
    )->fetchColumn();

    // Counted per permission (0-3) so the report reads like the other x/y
    // lines — one COUNT(*) over ANDed JSON_CONTAINS could only answer 0/1.
    $permissions = (int) $pdo->query(
        "SELECT COALESCE(SUM(
                    JSON_CONTAINS(`permissions`, '\"report.statutory\"')
                  + JSON_CONTAINS(`permissions`, '\"remittance.view\"')
                  + JSON_CONTAINS(`permissions`, '\"remittance.manage\"')
                ), 0)
           FROM `roles`
          WHERE `code` = 'MANAGER' AND JSON_VALID(`permissions`)"
    )->fetchColumn();

    $remittances = (int) $pdo->query('SELECT COUNT(*) FROM `statutory_remittances`')->fetchColumn();
    $items       = (int) $pdo->query('SELECT COUNT(*) FROM `statutory_remittance_items`')->fetchColumn();

    printf(
        "REMITTANCES: migrated OK (statements %d applied, %d already in place)\n" .
        "  tables:                    %d/2\n" .
        "  remittance header columns: %d/6\n" .
        "  remittance item columns:   %d/5\n" .
        "  window uniqueness:         %d/1\n" .
        "  MANAGER remittance perms:  %d/3\n" .
        "  remittances / items kept:  %d / %d\n",
        $applied,
        $skipped,
        $tables,
        $remittanceColumns,
        $itemColumns,
        $windowUnique,
        $permissions,
        $remittances,
        $items
    );
} catch (\Throwable $e) {
    echo 'REMITTANCES: MIGRATION FAILED: ' . $e->getMessage() . "\n";
    exit(1);
}