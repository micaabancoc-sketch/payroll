-- V8 READ-ONLY attendance audit. Run under phpMyAdmin in a TEST database.
-- Does not update, delete or modify payroll/attendance records.
-- Dashboard charts include manually entered, imported and seeded attendance records.

SELECT status, COUNT(*) AS records_last_30_days
FROM attendance
WHERE attendance_date >= DATE_SUB(CURDATE(), INTERVAL 30 DAY)
  AND attendance_date <= CURDATE()
  AND deleted_at IS NULL
GROUP BY status
ORDER BY records_last_30_days DESC;

SELECT attendance_date, status, COUNT(*) AS record_count,
       GROUP_CONCAT(DISTINCT LEFT(COALESCE(remarks, ''), 80) SEPARATOR ' | ') AS notes_examples
FROM attendance
WHERE attendance_date >= DATE_SUB(CURDATE(), INTERVAL 30 DAY)
  AND attendance_date <= CURDATE()
  AND deleted_at IS NULL
GROUP BY attendance_date, status
ORDER BY attendance_date DESC, status;
