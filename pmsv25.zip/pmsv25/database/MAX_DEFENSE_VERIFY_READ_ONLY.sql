-- PMS V9 SEPTEMBER 2026: ONE-EMPLOYEE DEFENSE VALIDATION
-- READ-ONLY: no inserts, deletes, updates, drops, transactions or database changes.
-- Select the same TEST database configured in the V9 application in phpMyAdmin before running.
-- This checks EXISTING data; it does not seed or reset records.

-- 1) Employee profile / fixed salary / schedule
SELECT e.id AS employee_id, e.employee_number,
       CONCAT(e.first_name, ' ', e.last_name) AS employee_name,
       d.name AS department, p.name AS position,
       e.basic_salary AS monthly_salary, e.salary_type,
       ws.name AS work_schedule, e.status
FROM employees e
LEFT JOIN departments d ON d.id=e.department_id
LEFT JOIN positions p ON p.id=e.position_id
LEFT JOIN work_schedules ws ON ws.id=e.work_schedule_id
WHERE e.employee_number='TEST-SEP26-08';

-- 2) Date-by-date attendance. Sep 6 and Sep 13 are normal Sunday rest days
-- and do NOT require an attendance row.
SELECT a.attendance_date, DAYNAME(a.attendance_date) AS day_name,
       a.status, TIME(a.time_in) AS time_in, TIME(a.time_out) AS time_out,
       a.late_minutes, a.undertime_minutes, a.overtime_hours, a.source, a.remarks
FROM attendance a
JOIN employees e ON e.id=a.employee_id
WHERE e.employee_number='TEST-SEP26-08'
  AND a.attendance_date BETWEEN '2026-09-01' AND '2026-09-15'
  AND a.deleted_at IS NULL
ORDER BY a.attendance_date;

-- 3) Expected counts: 13 workday rows; 1 absence; 1 leave; 20 min late;
-- 30 min undertime; 2 OT hours; 0 attendance rows on Sundays.
SELECT COUNT(*) AS workday_attendance_rows,
       SUM(a.status='ABSENT') AS absent_days,
       SUM(a.status='LEAVE') AS leave_days,
       SUM(a.status='LATE') AS late_days,
       SUM(a.status='UNDERTIME') AS undertime_days,
       SUM(a.late_minutes) AS late_minutes,
       SUM(a.undertime_minutes) AS undertime_minutes,
       SUM(a.overtime_hours) AS overtime_hours,
       SUM(DAYOFWEEK(a.attendance_date)=1) AS sunday_attendance_rows
FROM attendance a JOIN employees e ON e.id=a.employee_id
WHERE e.employee_number='TEST-SEP26-08'
  AND a.attendance_date BETWEEN '2026-09-01' AND '2026-09-15'
  AND a.deleted_at IS NULL;

-- 4) Approved paid sick leave, Sep 14, one scheduled day.
SELECT lr.start_date, lr.end_date, lr.days, lr.status,
       lt.code AS leave_code, lt.name AS leave_type, lt.is_paid,
       approver.username AS approver, lr.approved_at
FROM leave_requests lr
JOIN employees e ON e.id=lr.employee_id
JOIN leave_types lt ON lt.id=lr.leave_type_id
LEFT JOIN users approver ON approver.id=lr.approver_id
WHERE e.employee_number='TEST-SEP26-08'
  AND lr.start_date <= '2026-09-15'
  AND lr.end_date >= '2026-09-01';

-- 5) Approved OT plus actual scanned OT timestamps.
SELECT ot.overtime_date, ot.status, ot.start_time AS assigned_start,
       ot.end_time AS assigned_end, ot.hours AS assigned_hours,
       ot.applied_hours AS eligible_hours,
       TIME(os.ot_time_in) AS actual_ot_in,
       TIME(os.ot_time_out) AS actual_ot_out,
       os.payable_minutes, u.username AS approver
FROM overtime_requests ot
JOIN employees e ON e.id=ot.employee_id
LEFT JOIN overtime_scans os ON os.overtime_request_id=ot.id
LEFT JOIN users u ON u.id=ot.approver_id
WHERE e.employee_number='TEST-SEP26-08'
  AND ot.overtime_date BETWEEN '2026-09-01' AND '2026-09-15';

-- 6) Payroll cutoff must exist exactly once (Sep 1-15; Sep 18 sample pay date).
SELECT code, start_date, end_date, pay_date, status
FROM payroll_periods
WHERE start_date='2026-09-01' AND end_date='2026-09-15' AND deleted_at IS NULL;

-- 7) AFTER HR generates the draft payroll, this returns the computed amounts.
-- Empty result => payroll has not been generated yet, not proof of correct salary.
SELECT pp.code, pp.status AS period_status,
       pr.basic_pay, pr.gross_pay, pr.absent_days, pr.late_minutes,
       pr.undertime_minutes, pr.overtime_hours, pr.overtime_pay,
       pr.absence_deduction, pr.late_deduction, pr.undertime_deduction,
       pr.leave_deduction,
       pr.statutory_sss, pr.statutory_philhealth, pr.statutory_pagibig,
       pr.withholding_tax, pr.total_deductions, pr.net_pay, pr.payment_status
FROM payroll pr
JOIN employees e ON e.id=pr.employee_id
JOIN payroll_periods pp ON pp.id=pr.payroll_period_id
WHERE e.employee_number='TEST-SEP26-08'
  AND pp.start_date='2026-09-01' AND pp.end_date='2026-09-15';

-- 8) AFTER HR generates payroll, show the exact payslip earning/deduction lines.
SELECT pi.item_type, pi.code, pi.name, pi.amount, pi.remarks
FROM payroll_items pi
JOIN payroll pr ON pr.id=pi.payroll_id
JOIN employees e ON e.id=pr.employee_id
JOIN payroll_periods pp ON pp.id=pr.payroll_period_id
WHERE e.employee_number='TEST-SEP26-08'
  AND pp.start_date='2026-09-01' AND pp.end_date='2026-09-15'
ORDER BY pi.item_type, pi.code;
