<?php
/** @no-transition */
declare(strict_types=1);

/**
 * Audit-log sample-data cleanup + fresh development activity seed.
 *
 * What it does, in order:
 *
 *   1. BACK UP every audit_logs row that is about to be removed, written as a
 *      re-importable INSERT script under database/backup/.
 *   2. PURGE the rows written by a previous run of this script (they carry
 *      SEED_MARKER). Rows that merely *look* local -- a loopback or blank
 *      address -- are preserved unless --purge-demo is given, because the
 *      development server, curl, the API test suite and a local browser all
 *      record themselves from 127.0.0.1/::1 as well.
 *   3. SEED fresh, role-appropriate activity for every ACTIVE user, using the
 *      real action names from App\Core\AuditLogger and the real description
 *      wording produced by the controllers and services.
 *
 * Seeded rows are tagged in the existing `user_agent` column with SEED_MARKER
 * (the same value the application reads through
 * App\Core\AuditLogger::SAMPLE_USER_AGENT) so they stay distinguishable from
 * genuine audit history:
 *
 *     SELECT * FROM audit_logs WHERE user_agent = 'PMS-SEED/1.0';
 *
 * Usage:
 *   php database/seed_audit_logs.php                 # backup + replace own seed rows
 *   php database/seed_audit_logs.php --purge-demo    # ... and drop loopback/blank-IP rows
 *   php database/seed_audit_logs.php --dry-run       # report only, no writes
 *   php database/seed_audit_logs.php --backup-only   # write the backup only
 *   php database/seed_audit_logs.php --restore=<file.sql>
 *
 * Nothing outside `audit_logs` is written: users, employees, attendance,
 * leave, overtime and payroll rows are never modified.
 */

// The marker belongs to the application, not to this script: it is the same
// constant the audit endpoints evaluate is_sample from, so the seeder and the
// API can never drift apart.
require_once __DIR__ . '/../api/core/AuditLogger.php';

const SEED_MARKER = \App\Core\AuditLogger::SAMPLE_USER_AGENT;

/**
 * Addresses that can only ever be produced by traffic generated on this
 * machine. They are a hint, not proof: real activity from the dev server, curl,
 * the test suite or a local browser shares them, so these rows are only removed
 * when --purge-demo is passed explicitly. Rows with any other address (remote
 * traffic) are never deleted automatically.
 *
 * @var list<string>
 */
const DEMO_ADDRESSES = ['127.0.0.1', '::1', '0.0.0.0'];

// ---------------------------------------------------------------------------
// 0. Arguments
// ---------------------------------------------------------------------------
$dryRun      = in_array('--dry-run', $argv, true) || in_array('-n', $argv, true);
$backupOnly  = in_array('--backup-only', $argv, true);
$purgeDemo   = in_array('--purge-demo', $argv, true);
$restoreFile = null;

foreach ($argv as $argument) {
    if (str_starts_with($argument, '--restore=')) {
        $restoreFile = substr($argument, strlen('--restore='));
    }
}

// ---------------------------------------------------------------------------
// 1. Configuration + connection (same pattern as tests/reset_test_data.php)
// ---------------------------------------------------------------------------
/** @var array<string, mixed> $config */
$config = require __DIR__ . '/../api/config/config.php';
$db     = $config['database'];

// The application runs in Asia/Manila; every seeded timestamp uses it.
date_default_timezone_set((string) ($config['app']['timezone'] ?? 'Asia/Manila'));

try {
    $pdo = new PDO(
        sprintf('mysql:host=%s;port=%d;dbname=%s;charset=utf8mb4', $db['host'], $db['port'], $db['name']),
        $db['user'],
        $db['password'],
        [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        ]
    );
} catch (PDOException $exception) {
    fwrite(STDERR, 'Cannot reach the database: ' . $exception->getMessage() . "\n");
    fwrite(STDERR, "Start MySQL, then import: mysql -u root -p < database/main.sql\n");
    exit(2);
}

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

/** Quote a PHP value as a MySQL literal (used only while writing the backup). */
function sql_literal(PDO $pdo, mixed $value): string
{
    if ($value === null) {
        return 'NULL';
    }
    if (is_int($value) || is_float($value)) {
        return (string) $value;
    }
    return $pdo->quote((string) $value);
}

/** Scalar preview matching App\Core\AuditLogger::summarise(). */
function summarise(mixed $value): string
{
    if ($value === null) {
        return 'null';
    }
    if (is_array($value)) {
        $encoded = json_encode($value, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PARTIAL_OUTPUT_ON_ERROR);
        return $encoded === false ? '[array]' : (string) $encoded;
    }
    if (is_bool($value)) {
        return $value ? '1' : '0';
    }
    return (string) $value;
}

/** "field: old -> new, ..." summary produced by AuditLogger::recordChanges(). */
function change_summary(array $old, array $new): string
{
    $parts = [];
    foreach ($new as $field => $value) {
        $before = $old[$field] ?? null;
        if (summarise($before) !== summarise($value)) {
            $parts[] = sprintf('%s: %s -> %s', $field, summarise($before), summarise($value));
        }
    }
    return implode(', ', $parts);
}

/**
 * Build one audit row. $when = [daysAgo, hour, minute], resolved later so the
 * whole set can be sorted chronologically before it is inserted.
 *
 * @return array<string, mixed>
 */
function entry(
    array $when,
    ?int $userId,
    ?string $username,
    string $action,
    ?string $entityType,
    int|string|null $entityId,
    string $description,
    ?array $oldValue = null,
    ?array $newValue = null
): array {
    return [
        'when'        => $when,
        'user_id'     => $userId,
        'username'    => $username,
        'action'      => $action,
        'entity_type' => $entityType,
        'entity_id'   => $entityId === null ? null : (string) $entityId,
        'description' => mb_substr($description, 0, 500),
        'old_value'   => $oldValue,
        'new_value'   => $newValue,
    ];
}

/**
 * Resolve [daysAgo, hour, minute] to a DATETIME that is never in the future.
 * The requested wall-clock time is kept for realism; if it would land after
 * "now - 5 minutes" the slot moves back a day until it is valid.
 */
function resolve_slot(array $when, DateTimeImmutable $now): DateTimeImmutable
{
    [$daysAgo, $hour, $minute] = $when;
    $limit  = $now->modify('-5 minutes');
    $result = $now->modify(sprintf('-%d days', max(0, $daysAgo)))->setTime($hour, $minute, 0);

    $guard = 0;
    while ($result > $limit && $guard < 60) {
        $result = $result->modify('-1 day');
        $guard++;
    }

    return $result;
}

// ---------------------------------------------------------------------------
// 1b. --restore: put a previous backup back and stop
// ---------------------------------------------------------------------------
if ($restoreFile !== null) {
    $sql = @file_get_contents($restoreFile);

    if ($sql === false) {
        fwrite(STDERR, "Backup file not readable: {$restoreFile}\n");
        exit(1);
    }

    $statements = [];
    foreach (explode(";\n", (string) $sql) as $chunk) {
        // Drop leading SQL comments but keep the statement that follows them.
        $lines = [];
        foreach (preg_split('/\r?\n/', $chunk) ?: [] as $line) {
            if (str_starts_with(ltrim($line), '--')) {
                continue;
            }
            $lines[] = $line;
        }
        $statement = trim(implode("\n", $lines));
        if ($statement !== '') {
            $statements[] = $statement;
        }
    }
    $written    = 0;

    $pdo->beginTransaction();
    foreach ($statements as $statement) {
        if ($statement === '' || str_starts_with($statement, '--')) {
            continue;
        }
        $pdo->exec($statement);
        $written++;
    }
    $pdo->commit();

    echo "Restored {$written} statement(s) from {$restoreFile}\n";
    exit(0);
}

// ---------------------------------------------------------------------------
// 2. Classify the rows currently in audit_logs
// ---------------------------------------------------------------------------
$buckets = [
    'previous seed' => ['reason' => 'previous seed', 'rows' => []],
    'no ip'         => ['reason' => 'no ip',         'rows' => []],
    'loopback ip'   => ['reason' => 'loopback ip',   'rows' => []],
    'genuine'       => ['reason' => null,            'rows' => []],
];

$existing = $pdo->query(
    'SELECT id, user_id, username, action, entity_type, entity_id, description,
            old_value, new_value, ip_address, user_agent, created_at
       FROM audit_logs
      ORDER BY id'
)->fetchAll();

foreach ($existing as $row) {
    $userAgent = (string) ($row['user_agent'] ?? '');
    $ip        = $row['ip_address'];

    if ($userAgent === SEED_MARKER) {
        $buckets['previous seed']['rows'][] = $row;
    } elseif ($ip === null || $ip === '') {
        $buckets['no ip']['rows'][] = $row;
    } elseif (in_array((string) $ip, DEMO_ADDRESSES, true)) {
        $buckets['loopback ip']['rows'][] = $row;
    } else {
        // Remote/unknown origin: cannot be identified as sample data, so it is
        // never deleted automatically.
        $buckets['genuine']['rows'][] = $row;
    }
}

// A previous run of this script is always safe to replace: its rows are tagged
// with SEED_MARKER, so they are sample data by construction.
$toDelete = $buckets['previous seed']['rows'];

// Loopback and blank addresses are only a hint of local sample traffic. Removing
// them by default would throw away genuine history recorded by the development
// server, curl, the test suite or a local browser, so it takes --purge-demo.
$demoCandidates = array_merge($buckets['no ip']['rows'], $buckets['loopback ip']['rows']);

if ($purgeDemo) {
    $toDelete = array_merge($toDelete, $demoCandidates);
}

$toKeep = array_merge($buckets['genuine']['rows'], $purgeDemo ? [] : $demoCandidates);

echo "=== audit_logs before ===\n";
echo sprintf("total rows .............. %d\n", count($existing));
foreach ($buckets as $name => $bucket) {
    $retained = !$purgeDemo && ($name === 'no ip' || $name === 'loopback ip');
    echo sprintf("  %-21s %d%s\n", $name . ':', count($bucket['rows']), $retained ? '  [kept]' : '');
}
echo sprintf("will remove ............. %d row(s)\n", count($toDelete));
echo sprintf("will keep ............... %d row(s)\n", count($toKeep));

if (!$purgeDemo && $demoCandidates !== []) {
    echo "\n" . sprintf(
        "Note: %d row(s) have a loopback or blank address but were not written by\n",
        count($demoCandidates)
    );
    echo "this script, so they may be genuine activity (dev server, curl, browser).\n";
    echo "They are kept. Add --purge-demo to remove them as well.\n";
}

if ($dryRun) {
    echo "\nDRY RUN - no rows written, no rows deleted.\n";
    echo sprintf("Would delete %d row(s), keep %d row(s).\n", count($toDelete), count($toKeep));
    exit(0);
}

// ---------------------------------------------------------------------------
// 3. Back up the rows that are about to be removed
// ---------------------------------------------------------------------------
$backupDirectory = __DIR__ . '/backup';
if (!is_dir($backupDirectory) && !mkdir($backupDirectory, 0775, true) && !is_dir($backupDirectory)) {
    fwrite(STDERR, "Cannot create backup directory: {$backupDirectory}\n");
    exit(1);
}

$backupFile = $backupDirectory . '/audit_logs_' . date('Ymd_His') . '.sql';
$handle     = fopen($backupFile, 'wb');

if ($handle === false) {
    fwrite(STDERR, "Cannot write backup file: {$backupFile}\n");
    exit(1);
}

fwrite($handle, sprintf(
    "-- Backup of `audit_logs`\n-- Taken: %s %s (%s)\n-- Rows: %d\n-- Restore: mysql -u root %s < %s\n\n",
    date('Y-m-d'),
    date('H:i:s'),
    (string) ($config['app']['timezone'] ?? 'Asia/Manila'),
    count($toDelete),
    (string) $db['name'],
    str_replace('\\', '/', $backupFile)
));
fwrite($handle, "SET FOREIGN_KEY_CHECKS=0;\n");

$columns = ['id', 'user_id', 'username', 'action', 'entity_type', 'entity_id',
            'description', 'old_value', 'new_value', 'ip_address', 'user_agent', 'created_at'];

foreach ($toDelete as $row) {
    $values = [];
    foreach ($columns as $column) {
        $values[] = sql_literal($pdo, $row[$column] ?? null);
    }
    fwrite(
        $handle,
        sprintf("INSERT INTO `audit_logs` (`%s`) VALUES (%s);\n", implode('`, `', $columns), implode(', ', $values))
    );
}

fwrite($handle, "SET FOREIGN_KEY_CHECKS=1;\n");
fclose($handle);

echo sprintf("\nBackup written: %s (%d row(s))\n", $backupFile, count($toDelete));

if ($backupOnly) {
    echo "--backup-only requested: purge and seed skipped.\n";
    exit(0);
}

// ---------------------------------------------------------------------------
// 4. Reference data the seeded entries point at
// ---------------------------------------------------------------------------
/** @var array<int, array<string, mixed>> $activeUsers */
$activeUsers = $pdo->query(
    "SELECT u.id, u.username, u.email, u.full_name, u.employee_id, u.role_id, r.code AS role_code
       FROM users u
       JOIN roles r ON r.id = u.role_id
      WHERE u.status = 'ACTIVE' AND u.deleted_at IS NULL
      ORDER BY u.id"
)->fetchAll();

/** @var array<int, array<string, mixed>> $employees */
$employees = $pdo->query('SELECT id, employee_number, first_name, last_name FROM employees ORDER BY id')->fetchAll();
$employeeById = [];
foreach ($employees as $employee) {
    $employeeById[(int) $employee['id']] = $employee;
}

$employeeName = static function (int $id) use ($employeeById): string {
    $row = $employeeById[$id] ?? null;
    return $row === null ? sprintf('employee %d', $id) : trim($row['first_name'] . ' ' . $row['last_name']);
};

$employeeNumber = static function (int $id) use ($employeeById): string {
    return (string) ($employeeById[$id]['employee_number'] ?? sprintf('EMP-%06d', $id));
};

/** @var array<int, array<int, array<string, mixed>>> $overtimeByEmployee */
$overtimeByEmployee = [];
foreach ($pdo->query('SELECT id, employee_id, overtime_date, hours, status FROM overtime_requests ORDER BY id')->fetchAll() as $ot) {
    $overtimeByEmployee[(int) $ot['employee_id']][] = $ot;
}

$overtimeFor = static function (?int $employeeId) use ($overtimeByEmployee): ?array {
    if ($employeeId === null || empty($overtimeByEmployee[$employeeId])) {
        return null;
    }
    foreach ($overtimeByEmployee[$employeeId] as $row) {
        if ($row['status'] === 'PENDING') {
            return $row;
        }
    }
    return $overtimeByEmployee[$employeeId][0];
};

$leaveTypeNames = [];
foreach ($pdo->query('SELECT id, name FROM leave_types ORDER BY id')->fetchAll() as $leaveType) {
    $leaveTypeNames[(int) $leaveType['id']] = (string) $leaveType['name'];
}
$firstLeaveType  = $leaveTypeNames[1] ?? 'Vacation Leave';
$secondLeaveType = $leaveTypeNames[2] ?? ($leaveTypeNames[1] ?? 'Sick Leave');

/** @var array<int, array<string, mixed>> $leaveRequests */
$leaveRequests = $pdo->query(
    'SELECT id, employee_id, leave_type_id, start_date, end_date, days FROM leave_requests ORDER BY id'
)->fetchAll();

/** @var array<int, array<int, array<string, mixed>>> $attendanceByEmployee */
$attendanceByEmployee = [];
foreach ($pdo->query('SELECT id, employee_id, attendance_date FROM attendance WHERE deleted_at IS NULL ORDER BY id')->fetchAll() as $attendance) {
    $attendanceByEmployee[(int) $attendance['employee_id']][] = $attendance;
}

/** @var array<int, array<int, array<string, mixed>>> $qrByEmployee */
$qrByEmployee = [];
foreach ($pdo->query('SELECT id, employee_id FROM employee_qr_codes ORDER BY id')->fetchAll() as $qr) {
    $qrByEmployee[(int) $qr['employee_id']][] = $qr;
}

$scheduleRows = $pdo->query('SELECT id, name FROM work_schedules WHERE deleted_at IS NULL ORDER BY id')->fetchAll();
$shiftRows    = $pdo->query('SELECT id, name FROM shifts WHERE deleted_at IS NULL ORDER BY id')->fetchAll();
$holidayRows  = $pdo->query('SELECT id, name FROM holidays WHERE deleted_at IS NULL ORDER BY id')->fetchAll();

$settingRows = $pdo->query('SELECT id, setting_key FROM system_settings ORDER BY id')->fetchAll();
$settingLast = min(3, max(0, count($settingRows) - 1));
$settingKeyA = (string) ($settingRows[0]['setting_key'] ?? 'company.name');
$settingKeyB = (string) ($settingRows[$settingLast]['setting_key'] ?? $settingKeyA);
$settingIdA  = isset($settingRows[0]) ? (int) $settingRows[0]['id'] : null;
$settingIdB  = isset($settingRows[$settingLast]) ? (int) $settingRows[$settingLast]['id'] : null;

$period      = $pdo->query('SELECT id, code FROM payroll_periods ORDER BY id')->fetch();
$periodId    = $period === false ? null : (int) $period['id'];
$periodCode  = $period === false ? sprintf('PP-%s-01', date('Ym')) : (string) $period['code'];
$employeeCount = count($employees);

// The archive/restore pair below targets an employee that is INACTIVE today,
// so the seeded history ends in the same state the table is in now.
$archivedEmployeeId = null;
foreach ($employees as $employee) {
    $status = $pdo->query('SELECT status FROM employees WHERE id = ' . (int) $employee['id'])->fetchColumn();
    if ($status === 'INACTIVE') {
        $archivedEmployeeId = (int) $employee['id'];
        break;
    }
}

// ---------------------------------------------------------------------------
// 5. Build the activity set
// ---------------------------------------------------------------------------
$entries = [];
$admin   = null;
foreach ($activeUsers as $user) {
    if ($user['role_code'] === 'ADMIN') {
        $admin = $user;
        break;
    }
}

// --- Administrator --------------------------------------------------------
if ($admin !== null) {
    $adminId   = (int) $admin['id'];
    $adminName = (string) $admin['username'];

    $firstEmp = $employees[0] ?? null;
    $firstId  = $firstEmp === null ? 1 : (int) $firstEmp['id'];

    $entries[] = entry([12, 8, 2], $adminId, $adminName, 'LOGIN', 'user', $adminId,
        sprintf('User "%s" signed in', $adminName));
    $entries[] = entry([12, 7, 57], $adminId, $adminName, 'LOGIN_FAILED', 'user', $adminId,
        sprintf('Failed login for "%s"', $adminName));

    if ($firstEmp !== null) {
        $entries[] = entry([12, 9, 20], $adminId, $adminName, 'EMPLOYEE_CREATED', 'employee', $firstId,
            sprintf('Created employee %s %s', $firstEmp['first_name'], $firstEmp['last_name']),
            null,
            ['employee_number' => $firstEmp['employee_number'], 'status' => 'ACTIVE']);
    }

    if (!empty($qrByEmployee[$firstId])) {
        $entries[] = entry([12, 9, 22], $adminId, $adminName, 'QR_REGENERATED', 'employee_qr_code',
            (int) $qrByEmployee[$firstId][0]['id'],
            sprintf('Regenerated QR code for employee %d', $firstId));
    }

    if (!empty($attendanceByEmployee[$firstId])) {
        $entries[] = entry([12, 10, 5], $adminId, $adminName, 'ATTENDANCE_OVERRIDE', 'attendance',
            (int) $attendanceByEmployee[$firstId][0]['id'],
            sprintf('Manual override by %s: TIME_IN for %s (PRESENT)', $adminName, $employeeNumber($firstId)));
    }

    $entries[] = entry([11, 8, 40], $adminId, $adminName, 'LOGIN', 'user', $adminId,
        sprintf('User "%s" signed in', $adminName));

    $entries[] = entry([11, 9, 30], $adminId, $adminName, 'EMPLOYEE_UPDATED', 'employee', $firstId,
        change_summary(
            ['contact_number' => null, 'department_name' => null],
            ['contact_number' => '09171234567', 'department_name' => 'Operations']
        ),
        ['contact_number' => null, 'department_name' => null],
        ['contact_number' => '09171234567', 'department_name' => 'Operations']);

    if ($leaveRequests !== []) {
        $approved  = $leaveRequests[0];
        $leaveName = $leaveTypeNames[(int) $approved['leave_type_id']] ?? $firstLeaveType;
        $entries[] = entry([11, 14, 15], $adminId, $adminName, 'LEAVE_APPROVED', 'leave_request',
            (int) $approved['id'],
            sprintf('Leave approved for employee %s: %s (%.2f days)',
                (string) $approved['employee_id'], $leaveName, (float) $approved['days']),
            ['status' => 'PENDING'],
            ['status' => 'APPROVED']);

        if (isset($leaveRequests[1])) {
            $rejected  = $leaveRequests[1];
            $entries[] = entry([10, 9, 10], $adminId, $adminName, 'LEAVE_REJECTED', 'leave_request',
                (int) $rejected['id'],
                sprintf('Leave rejected for employee %s: %s (%.2f days)',
                    (string) $rejected['employee_id'], $secondLeaveType, 1.00),
                ['status' => 'PENDING'],
                ['status' => 'REJECTED']);
        }
    }

    $assignedEmployeeId = $firstId;
    foreach ($activeUsers as $user) {
        if ($user['employee_id'] !== null && $overtimeFor((int) $user['employee_id']) !== null) {
            $assignedEmployeeId = (int) $user['employee_id'];
            break;
        }
    }
    $otTarget = $overtimeFor($assignedEmployeeId);
    if ($otTarget !== null) {
        $entries[] = entry([10, 10, 45], $adminId, $adminName, 'OVERTIME_ASSIGNED', 'overtime_request',
            (int) $otTarget['id'],
            sprintf('Overtime assigned: %.2f hours on %s', (float) $otTarget['hours'], (string) $otTarget['overtime_date']),
            null,
            ['employee_id' => $assignedEmployeeId, 'overtime_date' => $otTarget['overtime_date'], 'status' => 'PENDING']);
        $entries[] = entry([9, 11, 5], $adminId, $adminName, 'OVERTIME_APPROVED', 'overtime_request',
            (int) $otTarget['id'],
            sprintf('Overtime approved: %.2f hours on %s', (float) $otTarget['hours'], (string) $otTarget['overtime_date']),
            ['status' => 'PENDING'],
            ['status' => 'APPROVED']);
    }

    $completedOt = null;
    foreach ($overtimeByEmployee as $rows) {
        foreach ($rows as $row) {
            if ($row['status'] === 'COMPLETED') {
                $completedOt = $row;
                break 2;
            }
        }
    }
    if ($completedOt !== null) {
        $entries[] = entry([3, 9, 5], $adminId, $adminName, 'OVERTIME_COMPLETED', 'overtime_request',
            (int) $completedOt['id'],
            sprintf('Overtime completed: %.2f hours total (%.2f requested) on %s',
                (float) $completedOt['hours'], (float) $completedOt['hours'], (string) $completedOt['overtime_date']),
            ['status' => 'PENDING'],
            ['status' => 'COMPLETED']);
    }

    foreach ($overtimeByEmployee as $rows) {
        foreach ($rows as $row) {
            if ($row['status'] === 'DECLINED') {
                $entries[] = entry([8, 9, 25], $adminId, $adminName, 'OVERTIME_REJECTED', 'overtime_request',
                    (int) $row['id'],
                    sprintf('Overtime rejected: %.2f hours on %s', (float) $row['hours'], (string) $row['overtime_date']),
                    ['status' => 'ACCEPTED'],
                    ['status' => 'REJECTED']);
                break 2;
            }
        }
    }

    $entries[] = entry([10, 16, 20], $adminId, $adminName, 'LOGOUT', 'user', $adminId,
        sprintf('User "%s" signed out', $adminName));
    $entries[] = entry([9, 8, 35], $adminId, $adminName, 'LOGIN', 'user', $adminId,
        sprintf('User "%s" signed in', $adminName));

    if ($periodId !== null) {
        $entries[] = entry([9, 10, 15], $adminId, $adminName, 'PAYROLL_CALCULATED', 'payroll_period', $periodId,
            sprintf('Payroll period created: %s', $periodCode));
        $entries[] = entry([6, 9, 45], $adminId, $adminName, 'PAYROLL_CALCULATED', 'payroll_period', $periodId,
            sprintf('Payroll calculated for %d employee(s)', $employeeCount));
    }

    $entries[] = entry([8, 15, 40], $adminId, $adminName, 'SETTINGS_CHANGED', 'system_settings', $settingIdA,
        sprintf('Settings changed: %s', $settingKeyA),
        [$settingKeyA => '7.5'],
        [$settingKeyA => '8.0']);

    $entries[] = entry([6, 14, 5], $adminId, $adminName, 'USER_CHANGED', 'user', 3,
        change_summary(
            ['email' => 'staff@company.com'],
            ['email' => 'staff.member@company.com']
        ),
        ['email' => 'staff@company.com'],
        ['email' => 'staff.member@company.com']);

    if ($archivedEmployeeId !== null) {
        $entries[] = entry([5, 9, 15], $adminId, $adminName, 'EMPLOYEE_RESTORED', 'employee', $archivedEmployeeId,
            sprintf('Restored employee %s', $employeeName($archivedEmployeeId)));
        $entries[] = entry([4, 10, 35], $adminId, $adminName, 'EMPLOYEE_ARCHIVED', 'employee', $archivedEmployeeId,
            sprintf('Archived employee %s', $employeeName($archivedEmployeeId)));
    }

    if ($scheduleRows !== []) {
        $entries[] = entry([5, 13, 50], $adminId, $adminName, 'SCHEDULE_CHANGED', 'work_schedule',
            (int) $scheduleRows[0]['id'],
            sprintf('Updated work schedule "%s"', $scheduleRows[0]['name']));
    }

    $entries[] = entry([4, 16, 10], $adminId, $adminName, 'HOLIDAY_CHANGED', 'holiday',
        $holidayRows === [] ? null : (int) $holidayRows[count($holidayRows) - 1]['id'],
        change_summary(['remarks' => null], ['remarks' => 'Office closed at noon']),
        ['remarks' => null],
        ['remarks' => 'Office closed at noon']);

    $entries[] = entry([4, 8, 25], $adminId, $adminName, 'LOGIN', 'user', $adminId,
        sprintf('User "%s" signed in', $adminName));
    $entries[] = entry([3, 11, 25], $adminId, $adminName, 'PASSWORD_CHANGED', 'user', $adminId,
        sprintf('Password changed for "%s"', $adminName));
    $entries[] = entry([2, 8, 45], $adminId, $adminName, 'LOGIN', 'user', $adminId,
        sprintf('User "%s" signed in', $adminName));
    $entries[] = entry([2, 15, 15], $adminId, $adminName, 'SETTINGS_CHANGED', 'system_settings', $settingIdB,
        sprintf('Settings changed: %s', $settingKeyB));
    $entries[] = entry([1, 9, 20], $adminId, $adminName, 'SCHEDULE_CHANGED', 'shift',
        $shiftRows === [] ? null : (int) $shiftRows[0]['id'],
        sprintf('Created shift "%s"', $shiftRows === [] ? 'Regular Shift' : $shiftRows[0]['name']));
    $entries[] = entry([1, 17, 40], $adminId, $adminName, 'LOGOUT', 'user', $adminId,
        sprintf('User "%s" signed out', $adminName));
    $entries[] = entry([0, 8, 10], $adminId, $adminName, 'LOGIN', 'user', $adminId,
        sprintf('User "%s" signed in', $adminName));
}

// --- Manager + Staff ------------------------------------------------------
$position = 0;

foreach ($activeUsers as $user) {
    if ($user['role_code'] === 'ADMIN') {
        continue;
    }

    $userId     = (int) $user['id'];
    $username   = (string) $user['username'];
    $role       = (string) $user['role_code'];
    $employeeId = $user['employee_id'] === null ? null : (int) $user['employee_id'];
    $index      = $position++;

    $dayOne   = 12 - ($index % 11);            // 12 .. 2 days ago
    $dayTwo   = max(0, $dayOne - 2);
    $dayThree = max(0, $dayTwo - 3);
    $hourOne  = 7 + ($index % 3);
    $hourTwo  = 9 + ($index % 5);
    $minute   = (7 + 11 * $index) % 60;

    // Every active account gets at least one sign-in.
    $entries[] = entry([$dayOne, $hourOne, $minute], $userId, $username, 'LOGIN', 'user', $userId,
        sprintf('User "%s" signed in', $username));

    if ($role === 'MANAGER') {
        // MANAGER holds employees.*, attendance.*, leave.approve, payroll.*,
        // schedule.manage and holiday.manage — but never overtime.create.
        $managerPicks = [
            static function () use ($userId, $username, $employeeId, $employeeNumber, $attendanceByEmployee, $dayTwo, $hourTwo, $minute): array {
                if ($employeeId !== null && !empty($attendanceByEmployee[$employeeId])) {
                    $att = $attendanceByEmployee[$employeeId][0];
                    return entry([$dayTwo, $hourTwo, $minute], $userId, $username, 'ATTENDANCE_CREATED', 'attendance',
                        (int) $att['id'],
                        sprintf('Created manual attendance for %s', (string) $att['attendance_date']));
                }
                return entry([$dayTwo, $hourTwo, $minute], $userId, $username, 'ATTENDANCE_OVERRIDE', 'attendance',
                    null,
                    sprintf('Manual override by %s: TIME_OUT for %s (LATE)', $username,
                        $employeeId === null ? 'EMP-000001' : $employeeNumber($employeeId)));
            },
            static function () use ($userId, $username, $employeeId, $dayTwo, $hourTwo, $minute): array {
                return entry([$dayTwo, $hourTwo, $minute], $userId, $username, 'EMPLOYEE_UPDATED', 'employee', $employeeId,
                    change_summary(
                        ['work_schedule_name' => null],
                        ['work_schedule_name' => 'Standard Mon-Fri']
                    ),
                    ['work_schedule_name' => null],
                    ['work_schedule_name' => 'Standard Mon-Fri']);
            },
            static function () use ($userId, $username, $employeeId, $employeeName, $dayTwo, $hourTwo, $minute): array {
                $name = $employeeId === null ? 'Operations Manager' : $employeeName($employeeId);
                return entry([$dayTwo, $hourTwo, $minute], $userId, $username, 'EMPLOYEE_CREATED', 'employee', $employeeId,
                    sprintf('Created employee %s', $name),
                    null,
                    ['status' => 'ACTIVE']);
            },
            static function () use ($userId, $username, $leaveRequests, $firstLeaveType, $dayTwo, $hourTwo, $minute): array {
                $target = $leaveRequests[0] ?? null;
                return entry([$dayTwo, $hourTwo, $minute], $userId, $username, 'LEAVE_APPROVED', 'leave_request',
                    $target === null ? null : (int) $target['id'],
                    sprintf('Leave approved for employee %s: %s (%.2f days)',
                        $target === null ? '1' : (string) $target['employee_id'],
                        $firstLeaveType,
                        $target === null ? 1.00 : (float) $target['days']),
                    ['status' => 'PENDING'],
                    ['status' => 'APPROVED']);
            },
            static function () use ($userId, $username, $periodId, $employeeCount, $dayTwo, $hourTwo, $minute): array {
                return entry([$dayTwo, $hourTwo, $minute], $userId, $username, 'PAYROLL_CALCULATED', 'payroll_period',
                    $periodId,
                    sprintf('Payroll calculated for %d employee(s)', $employeeCount));
            },
            static function () use ($userId, $username, $shiftRows, $dayTwo, $hourTwo, $minute): array {
                return entry([$dayTwo, $hourTwo, $minute], $userId, $username, 'SCHEDULE_CHANGED', 'shift',
                    $shiftRows === [] ? null : (int) $shiftRows[0]['id'],
                    sprintf('Updated shift "%s"', $shiftRows === [] ? 'Regular Shift' : $shiftRows[0]['name']));
            },
            static function () use ($userId, $username, $holidayRows, $dayTwo, $hourTwo, $minute): array {
                return entry([$dayTwo, $hourTwo, $minute], $userId, $username, 'HOLIDAY_CHANGED', 'holiday',
                    $holidayRows === [] ? null : (int) $holidayRows[0]['id'],
                    change_summary(['is_paid' => 0], ['is_paid' => 1]),
                    ['is_paid' => 0],
                    ['is_paid' => 1]);
            },
        ];

        // Two role-appropriate actions per manager so the pool is fully
        // exercised (create/update/approve/schedule/holiday/attendance/payroll).
        $slotShifts = [[0, 0, 0], [1, 2, 27]];
        foreach ([0, 3] as $n => $offset) {
            $pick = $managerPicks[($index + $offset) % count($managerPicks)];
            $made = $pick();
            $made['when'] = [
                $dayTwo + $slotShifts[$n][0],
                ($hourTwo + $slotShifts[$n][1]) % 24,
                ($minute + $slotShifts[$n][2]) % 60,
            ];
            $entries[] = $made;
        }

        $ot = $overtimeFor($employeeId);
        if ($ot !== null) {
            $assignee  = $employeeId === null ? 'Operations Manager' : $employeeName($employeeId);
            $accepting = ($index % 2) === 0;
            $entries[] = entry([$dayThree, 12 + ($index % 5), ($minute + 9) % 60], $userId, $username,
                $accepting ? 'OVERTIME_ACCEPTED' : 'OVERTIME_DECLINED', 'overtime_request', (int) $ot['id'],
                $accepting
                    ? sprintf('Overtime accepted by %s for %s', $assignee, (string) $ot['overtime_date'])
                    : sprintf('Overtime declined by %s for %s: Schedule conflict', $assignee, (string) $ot['overtime_date']),
                ['status' => $ot['status']],
                $accepting ? ['status' => 'ACCEPTED'] : ['status' => 'DECLINED', 'decline_reason' => 'Schedule conflict']);
        } else {
            $entries[] = entry([$dayThree, 12 + ($index % 5), ($minute + 9) % 60], $userId, $username,
                'LEAVE_REJECTED', 'leave_request',
                count($leaveRequests) > 1 ? (int) $leaveRequests[1]['id'] : null,
                sprintf('Leave rejected for employee %s: %s (%.2f days)',
                    $employeeId === null ? '2' : (string) $employeeId, $firstLeaveType, 1.00),
                ['status' => 'PENDING'],
                ['status' => 'REJECTED']);
        }
    } else {
        // STAFF: attendance.view_own/scan, leave.create/cancel_own,
        // overtime.view_own and self-service profile/password only. STAFF has
        // no overtime.create, no leave.approve and no payroll/employee rights.
        if ($employeeId !== null) {
            $statuses = ['PRESENT', 'LATE', 'INCOMPLETE', 'UNDERTIME'];
            $entries[] = entry([$dayTwo, $hourTwo, $minute], $userId, $username, 'ATTENDANCE_SCAN', 'attendance',
                !empty($attendanceByEmployee[$employeeId]) ? (int) $attendanceByEmployee[$employeeId][0]['id'] : null,
                sprintf('QR scan: %s for %s (%s)',
                    ($index % 2) === 0 ? 'TIME_IN' : 'TIME_OUT',
                    $employeeNumber($employeeId),
                    $statuses[$index % count($statuses)]));
        }

        $entries[] = entry([$dayTwo, 8 + ($index % 4), ($minute + 23) % 60], $userId, $username,
            'LEAVE_CREATED', 'leave_request', null,
            sprintf('Leave request submitted: %s from %s to %s (%.2f days)',
                ($index % 2) === 0 ? $firstLeaveType : $secondLeaveType,
                date('Y-m-d', strtotime(sprintf('+%d days', 7 + $index))),
                date('Y-m-d', strtotime(sprintf('+%d days', 8 + $index))),
                1.00),
            null,
            ['status' => 'PENDING']);

        $ot = $overtimeFor($employeeId);
        if ($ot !== null) {
            $assignee  = $employeeName($employeeId);
            $accepting = ($index % 3) !== 0;
            $entries[] = entry([$dayThree, 13 + ($index % 4), ($minute + 41) % 60], $userId, $username,
                $accepting ? 'OVERTIME_ACCEPTED' : 'OVERTIME_DECLINED', 'overtime_request', (int) $ot['id'],
                $accepting
                    ? sprintf('Overtime accepted by %s for %s', $assignee, (string) $ot['overtime_date'])
                    : sprintf('Overtime declined by %s for %s: Family matter', $assignee, (string) $ot['overtime_date']),
                ['status' => $ot['status']],
                $accepting ? ['status' => 'ACCEPTED'] : ['status' => 'DECLINED', 'decline_reason' => 'Family matter']);
        } elseif (($index % 3) === 0) {
            $entries[] = entry([$dayThree, 15, ($minute + 17) % 60], $userId, $username,
                'LEAVE_CANCELLED', 'leave_request', null,
                sprintf('Leave request cancelled (%.2f days)', 1.00),
                ['status' => 'PENDING'],
                ['status' => 'CANCELLED']);
        }
    }
}

// A few sign-outs, a password change and failed sign-in attempts so the feed
// is not uniformly "everything succeeded".
$extra = 0;
foreach ($activeUsers as $user) {
    if ($user['role_code'] === 'ADMIN') {
        continue;
    }
    $userId   = (int) $user['id'];
    $username = (string) $user['username'];
    $offset   = $extra++;

    if (($offset % 2) === 0) {
        $entries[] = entry([max(0, 10 - ($offset % 9)), 17, (12 + 5 * $offset) % 60], $userId, $username,
            'LOGOUT', 'user', $userId, sprintf('User "%s" signed out', $username));
    }
    if (($offset % 5) === 2) {
        $entries[] = entry([max(0, 9 - ($offset % 8)), 7, (33 + 3 * $offset) % 60], $userId, $username,
            'LOGIN_FAILED', 'user', $userId, sprintf('Failed login for "%s"', $username));
    }
    if (($offset % 5) === 4) {
        $entries[] = entry([max(0, 8 - ($offset % 7)), 19, (6 + 4 * $offset) % 60], $userId, $username,
            'PASSWORD_CHANGED', 'user', $userId, sprintf('Password changed for "%s"', $username));
    }
}

// ---------------------------------------------------------------------------
// 6. Resolve timestamps, sort chronologically, insert
// ---------------------------------------------------------------------------
$now = new DateTimeImmutable('now');

foreach ($entries as &$item) {
    $item['created_at'] = resolve_slot($item['when'], $now)->format('Y-m-d H:i:s');
}
unset($item);

// Oldest first, so `ORDER BY id DESC` (what the Audit Logs page issues) still
// reads as newest-first and id order matches created_at order.
usort($entries, static fn (array $a, array $b): int => strcmp($a['created_at'], $b['created_at']));

// Nudge exact collisions forward a minute so no two rows share a timestamp.
$seen = [];
foreach ($entries as &$item) {
    $stamp = $item['created_at'];
    while (isset($seen[$stamp])) {
        $stamp = (new DateTimeImmutable($stamp))->modify('+1 minute')->format('Y-m-d H:i:s');
    }
    $seen[$stamp] = true;
    $item['created_at'] = $stamp;
}
unset($item);

// Re-sort once more: nudging a collision can move a row past its neighbour.
usort($entries, static fn (array $a, array $b): int => strcmp($a['created_at'], $b['created_at']));

$deleteStatement = $pdo->prepare('DELETE FROM audit_logs WHERE id = :id');
$insert = $pdo->prepare(
    'INSERT INTO audit_logs
        (user_id, username, action, entity_type, entity_id, description,
         old_value, new_value, ip_address, user_agent, created_at)
     VALUES
        (:user_id, :username, :action, :entity_type, :entity_id, :description,
         :old_value, :new_value, :ip_address, :user_agent, :created_at)'
);

$pdo->beginTransaction();

foreach ($toDelete as $row) {
    $deleteStatement->execute(['id' => (int) $row['id']]);
}

$inserted = 0;
foreach ($entries as $item) {
    $insert->execute([
        'user_id'     => $item['user_id'],
        'username'    => $item['username'],
        'action'      => $item['action'],
        'entity_type' => $item['entity_type'],
        'entity_id'   => $item['entity_id'],
        'description' => $item['description'],
        'old_value'   => $item['old_value'] === null
            ? null
            : json_encode($item['old_value'], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
        'new_value'   => $item['new_value'] === null
            ? null
            : json_encode($item['new_value'], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
        'ip_address'  => '127.0.0.1',
        'user_agent'  => SEED_MARKER,
        'created_at'  => $item['created_at'],
    ]);
    $inserted++;
}

$pdo->commit();

// ---------------------------------------------------------------------------
// 7. Report
// ---------------------------------------------------------------------------
echo "\n=== purge ===\n";
echo sprintf("deleted .................. %d row(s)\n", count($toDelete));
echo sprintf("preserved ................ %d row(s)\n", count($toKeep));

echo "\n=== seed ===\n";
echo sprintf("inserted ................. %d row(s)\n", $inserted);
echo sprintf("marker ................... user_agent = '%s'\n", SEED_MARKER);

$rangeStatement = $pdo->prepare(
    'SELECT MIN(created_at) AS oldest, MAX(created_at) AS newest, COUNT(*) AS total
       FROM audit_logs WHERE user_agent = :marker'
);
$rangeStatement->execute(['marker' => SEED_MARKER]);
$range = $rangeStatement->fetch();
echo sprintf("range .................... %s -> %s\n", $range['oldest'], $range['newest']);

$future = (int) $pdo->query('SELECT COUNT(*) FROM audit_logs WHERE created_at > NOW()')->fetchColumn();
echo sprintf("future-dated rows ........ %d\n", $future);

echo "\n=== per-active-user coverage ===\n";
$coverageStatement = $pdo->prepare(
    'SELECT u.id, u.username, r.code AS role_code,
            COUNT(al.id) AS seeded,
            GROUP_CONCAT(DISTINCT al.action ORDER BY al.action SEPARATOR ", ") AS actions
       FROM users u
       JOIN roles r ON r.id = u.role_id
       LEFT JOIN audit_logs al ON al.user_id = u.id AND al.user_agent = :marker
      WHERE u.status = "ACTIVE" AND u.deleted_at IS NULL
      GROUP BY u.id, u.username, r.code
      ORDER BY u.id'
);
$coverageStatement->execute(['marker' => SEED_MARKER]);
$coverage = $coverageStatement->fetchAll();

$gaps = 0;
foreach ($coverage as $line) {
    $count = (int) $line['seeded'];
    if ($count === 0) {
        $gaps++;
    }
    echo sprintf(
        "  user %-3d %-18s %-8s %2d  %s\n",
        (int) $line['id'],
        $line['username'] === '' ? '(blank username)' : $line['username'],
        $line['role_code'],
        $count,
        (string) ($line['actions'] ?? '')
    );
}

echo "\n=== seeded actions ===\n";
$actionStatement = $pdo->prepare(
    'SELECT action, COUNT(*) AS c FROM audit_logs WHERE user_agent = :marker GROUP BY action ORDER BY action'
);
$actionStatement->execute(['marker' => SEED_MARKER]);
$actionRows = $actionStatement->fetchAll();
foreach ($actionRows as $line) {
    echo sprintf("  %-22s %d\n", $line['action'], $line['c']);
}

echo sprintf("\nActive users with no seeded activity: %d\n", $gaps);
echo "Verify in the UI: Settings -> Audit log.\n";
echo sprintf("Restore this run's backup with:\n  php database/seed_audit_logs.php --restore=%s\n", $backupFile);