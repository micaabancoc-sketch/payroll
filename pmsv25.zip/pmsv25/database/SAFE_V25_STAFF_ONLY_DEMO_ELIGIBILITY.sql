-- PMS V25 SAFE STAFF-ONLY DEFENSE DEMO (NON-DESTRUCTIVE)
-- Use AFTER importing the ORIGINAL / user's EXISTING database.
-- Verified dataset: EMP-000001 = Demo Staff Member (id=1),
-- manager (id=2), Demo HR Payroll (id=8), other sample employees.
-- NEVER run this on production/payable payroll without a full backup.
-- Does NOT DELETE/UPDATE attendance, payroll, payroll_items, payslips,
-- loan records, user logins, employee salaries, or employee profiles.
-- In the PHP demo code, only EMP-000001 can attend or enter new DRAFT payroll.
START TRANSACTION;
-- Check identity BEFORE writing. No employee rows are removed.
UPDATE employees
   SET payroll_eligible = CASE WHEN id = 1 AND employee_number = 'EMP-000001' THEN 1 ELSE 0 END
 WHERE id IN (1,2,3,4,5,6,7,8,9) AND deleted_at IS NULL;
COMMIT;

-- Verification: returns exactly one ACTIVE eligible employee in supplied dataset.
SELECT id, employee_number, CONCAT_WS(' ',first_name,last_name) AS full_name,
       status, payroll_eligible
  FROM employees WHERE id IN (1,2,3,4,5,6,7,8,9) ORDER BY id;
-- Historical records stay untouched; use these read-only checks.
SELECT employee_id, COUNT(*) AS old_attendance_rows FROM attendance
 WHERE employee_id IN (1,2,8) GROUP BY employee_id;
SELECT p.employee_id, pp.code AS payroll_period, pp.status, COUNT(*) AS old_payroll_rows
  FROM payroll p JOIN payroll_periods pp ON pp.id=p.payroll_period_id
 WHERE p.employee_id IN (1,2,8) GROUP BY p.employee_id,pp.code,pp.status ORDER BY pp.start_date;
