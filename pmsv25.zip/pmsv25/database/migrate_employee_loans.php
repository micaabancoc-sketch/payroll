<?php
declare(strict_types=1);

/**
 * Migration: employee loans & repayment ledger (Phase 3 / Phase 3B).
 *
 * Run once on an existing database:
 *   php database/migrate_employee_loans.php
 *
 * Like the other runners this opens its own PDO connection (api/bootstrap.php
 * would dispatch an HTTP request and exit before the migration ran). The SQL
 * itself only adds columns, keys, constraints and permissions, so the whole
 * file is repeatable: a repeated column/key/constraint is reported as
 * "already in place" instead of failing the run.
 *
 * It never drops, truncates or resets a table and it never rewrites a loan
 * balance, so the existing loans and their repayments are preserved exactly
 * as they were. The Phase 3B step only widens the status ENUM (every value the
 * old ENUM allowed stays valid, so no existing loan changes status) and adds
 * the rejection_reason column, which starts empty.
 */

$config = require __DIR__ . '/../api/config/config.php';
$db     = $config['database'];

$path = __DIR__ . '/migrations/20261012_employee_loans.sql';

if (!is_file($path)) {
    echo "MIGRATION NOT FOUND: {$path}\n";
    exit(1);
}

$ddl = file_get_contents($path);
if ($ddl === false) {
    echo "MIGRATION READ FAILED: {$path}\n";
    exit(1);
}

// Strip standalone comment lines, then split on the statement terminator. The
// migration contains no semicolons inside string literals, so a plain split is
// safe (same approach as database/migrate_statutory_deductions.php).
$sql        = preg_replace('/^\s*--.*$/m', '', $ddl) ?? '';
$statements = array_values(array_filter(
    array_map('trim', explode(';', $sql)),
    static fn (string $statement): bool => $statement !== ''
));

/** Errors that simply mean the statement was already applied. */
const ALREADY_APPLIED = [
    'Duplicate column name',
    'Duplicate key name',
    'Duplicate foreign key constraint name',
    'already exists',
    'check that column/key exists',
    // Re-adding a FOREIGN KEY whose backing index was auto-created by the
    // first run raises errno 121 "Duplicate key on write or update" rather
    // than "Duplicate ... constraint name". Same situation, same skip.
    'duplicate key on write or update',
    'errno: 121',
];

try {
    $pdo = new PDO(
        sprintf('mysql:host=%s;port=%d;dbname=%s;charset=%s', $db['host'], (int) $db['port'], $db['name'], $db['charset']),
        $db['user'],
        $db['password'],
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
    );

    // Prove the target before a single statement runs. DB_NAME can be set by a
    // wrapper (run_all.sh does), so the resolved database is read back from the
    // server instead of being trusted from configuration alone: a misdirected
    // run is visible on the first line of the output.
    printf(
        "LOANS: target %s on %s:%d (DATABASE() = %s, server %s)\n",
        $db['name'],
        $db['host'],
        (int) $db['port'],
        $pdo->query('SELECT DATABASE()')->fetchColumn(),
        $pdo->query('SELECT VERSION()')->fetchColumn()
    );

    $applied = 0;
    $skipped = 0;

    foreach ($statements as $statement) {
        try {
            $pdo->exec($statement);
            $applied++;
        } catch (\PDOException $e) {
            $message = $e->getMessage();
            $benign  = false;
            foreach (ALREADY_APPLIED as $needle) {
                if (stripos($message, $needle) !== false) {
                    $benign = true;
                    break;
                }
            }

            if (!$benign) {
                throw $e;
            }

            $skipped++;
        }
    }

    $loanColumns = (int) $pdo->query(
        "SELECT COUNT(*) FROM information_schema.columns
          WHERE table_schema = DATABASE() AND table_name = 'loans'
            AND column_name IN ('reference_no','notes','approved_by','approved_at','rejection_reason')"
    )->fetchColumn();

    // Phase 3B: the status ENUM has to carry the two approval states, otherwise
    // a filing or a rejection would be truncated by MySQL.
    $approvalStates = (int) $pdo->query(
        "SELECT COUNT(*) FROM information_schema.columns
          WHERE table_schema = DATABASE() AND table_name = 'loans' AND column_name = 'status'
            AND COLUMN_TYPE LIKE '%PENDING%' AND COLUMN_TYPE LIKE '%REJECTED%'"
    )->fetchColumn();

    $paymentColumns = (int) $pdo->query(
        "SELECT COUNT(*) FROM information_schema.columns
          WHERE table_schema = DATABASE() AND table_name = 'loan_payments'
            AND column_name IN ('period_id','payment_type','remarks','created_by')"
    )->fetchColumn();

    $paymentIndex = (int) $pdo->query(
        "SELECT COUNT(*) FROM information_schema.statistics
          WHERE table_schema = DATABASE() AND table_name = 'loan_payments'
            AND index_name = 'idx_loanpay_period'"
    )->fetchColumn();

    $paymentUnique = (int) $pdo->query(
        "SELECT COUNT(DISTINCT index_name) FROM information_schema.statistics
          WHERE table_schema = DATABASE() AND table_name = 'loan_payments'
            AND index_name = 'uq_loanpay_period_loan'"
    )->fetchColumn();

    // Counted per permission (0-5) so the report below reads like the other
    // x/y lines. A single COUNT(*) over five ANDed JSON_CONTAINS conditions
    // could only ever answer 0 or 1, which printed as a misleading "1/5".
    $permissions = (int) $pdo->query(
        "SELECT COALESCE(SUM(
                    JSON_CONTAINS(`permissions`, '\"loans.view\"')
                  + JSON_CONTAINS(`permissions`, '\"loans.create\"')
                  + JSON_CONTAINS(`permissions`, '\"loans.update\"')
                  + JSON_CONTAINS(`permissions`, '\"loans.payment\"')
                  + JSON_CONTAINS(`permissions`, '\"loans.approve\"')
                ), 0)
           FROM `roles`
          WHERE `code` = 'MANAGER' AND JSON_VALID(`permissions`)"
    )->fetchColumn();

    $loans     = (int) $pdo->query('SELECT COUNT(*) FROM `loans`')->fetchColumn();
    $repayments = (int) $pdo->query('SELECT COUNT(*) FROM `loan_payments`')->fetchColumn();

    $approvalCounts = $pdo->query(
        "SELECT SUM(status = 'PENDING') AS pending, SUM(status = 'REJECTED') AS rejected FROM `loans`"
    )->fetch(PDO::FETCH_ASSOC) ?: [];

    printf(
        "LOANS: migrated OK (statements %d applied, %d already in place)\n" .
        "  loans columns:           %d/5\n" .
        "  approval states (ENUM):  %d/1\n" .
        "  loan_payments columns:   %d/4\n" .
        "  ledger index:            %d/1\n" .
        "  repayment idempotency:   %d/1\n" .
        "  MANAGER loan permissions:%d/5\n" .
        "  loans / repayments kept: %d / %d\n" .
        "  awaiting / rejected:     %d / %d\n",
        $applied,
        $skipped,
        $loanColumns,
        $approvalStates,
        $paymentColumns,
        $paymentIndex,
        $paymentUnique,
        $permissions,
        $loans,
        $repayments,
        (int) ($approvalCounts['pending'] ?? 0),
        (int) ($approvalCounts['rejected'] ?? 0)
    );
} catch (\Throwable $e) {
    echo 'LOANS: MIGRATION FAILED: ' . $e->getMessage() . "\n";
    exit(1);
}