<?php
/**
 * Migration: add departments.base_salary (DEMO Department -> Basic Salary).
 *
 * Run once on an existing database:
 *   php database/migrate_department_base_salary.php
 *
 * - Adds `departments.base_salary DECIMAL(12,2) NULL` if missing (idempotent).
 * - Seeds the exact DEMO mapping (by department code, NOT by id order):
 *     HR=30000.00, IT=35000.00, FIN=32000.00, OPS=28000.00, SALES=30000.00
 * - Only fills NULL rows so an Admin-edited salary is never overwritten.
 */

declare(strict_types=1);

$config = require __DIR__ . '/../api/config/config.php';
$db = $config['database'];

$dsn = sprintf(
    'mysql:host=%s;port=%d;charset=%s',
    $db['host'],
    (int) $db['port'],
    $db['charset']
);

$pdo = new PDO($dsn, $db['user'], $db['password'], [
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
]);
$pdo->exec(sprintf('USE `%s`', str_replace('`', '', (string) $db['name'])));

$col = $pdo->query("SHOW COLUMNS FROM `departments` LIKE 'base_salary'")->fetch(PDO::FETCH_ASSOC);
if ($col === false) {
    $pdo->exec(
        "ALTER TABLE `departments` ADD COLUMN `base_salary` DECIMAL(12,2) NULL DEFAULT NULL " .
        "COMMENT 'DEMO department base salary auto-filled into employee basic_salary' AFTER `description`"
    );
    echo "Added departments.base_salary column.\n";
} else {
    echo "departments.base_salary column already exists — skipping ALTER.\n";
}

$demo = [
    'HR'    => 30000.00,
    'IT'    => 35000.00,
    'FIN'   => 32000.00,
    'OPS'   => 28000.00,
    'SALES' => 30000.00,
];

$stmt = $pdo->prepare('UPDATE `departments` SET `base_salary` = :salary WHERE `code` = :code AND `base_salary` IS NULL');
foreach ($demo as $code => $salary) {
    $stmt->execute(['salary' => $salary, 'code' => $code]);
    printf("DEMO seed: %s -> %.2f (%d row(s) filled, existing values kept).\n", $code, $salary, $stmt->rowCount());
}

echo "Done.\n";
