<?php
declare(strict_types=1);

/**
 * Migration: create 13th-Month Pay tables (idempotent).
 *
 * Run once on an existing database:
 *   php database/migrate_13th_month.php
 *
 * Uses its own PDO connection (like database/migrate_department_base_salary.php)
 * instead of api/bootstrap.php: the bootstrap dispatches an HTTP request and
 * exits, which would stop this script before any migration ran.
 *
 * Idempotent and non-destructive: CREATE TABLE IF NOT EXISTS creates the two
 * 13th-month tables when they are missing and leaves an existing ledger intact;
 * the only statement that runs against an existing table is an idempotent
 * MODIFY COLUMN widening payment_status to include 'PARTIAL'. It never touches
 * payroll, payroll_periods, payroll_items or any employee data, and it can
 * never discard recorded 13th-month payments (the suite runs it every pass).
 */

$config = require __DIR__ . '/../api/config/config.php';
$db     = $config['database'];

$path = __DIR__ . '/migrations/20261009_fifteenth_13th_month.sql';

if (!is_file($path)) {
    echo "MIGRATION NOT FOUND: {$path}\n";
    exit(1);
}

$ddl = file_get_contents($path);
if ($ddl === false) {
    echo "MIGRATION READ FAILED: {$path}\n";
    exit(1);
}

// Strip standalone comment lines, then split on the statement terminator. The
// migration contains no semicolons inside string literals, so a plain split is
// safe. DDL auto-commits in MySQL, so a wrapping transaction is not possible.
$sql        = preg_replace('/^\s*--.*$/m', '', $ddl) ?? '';
$statements = array_values(array_filter(
    array_map('trim', explode(';', $sql)),
    static fn (string $statement): bool => $statement !== ''
));

try {
    $pdo = new PDO(
        sprintf('mysql:host=%s;port=%d;charset=%s', $db['host'], (int) $db['port'], $db['charset']),
        $db['user'],
        $db['password'],
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
    );
    $pdo->exec(sprintf('USE `%s`', str_replace('`', '', (string) $db['name'])));

    foreach ($statements as $statement) {
        $pdo->exec($statement);
    }

    echo "THIRTEENTH_MONTH: migrated OK (created thirteenth_pays + thirteenth_payments)\n";
} catch (\Throwable $e) {
    echo 'THIRTEENTH_MONTH: MIGRATION FAILED: ' . $e->getMessage() . "\n";
    exit(1);
}
