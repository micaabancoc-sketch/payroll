#!/usr/bin/env php
<?php
/**
 * Seed payroll history for 3 sample employees into the TEST database only.
 *
 * Creates two completed historical payroll periods (August 2026 and September
 * 2026), runs each through the real payroll engine and the real payment
 * service, and records disbursements so the data persists and is readable
 * through the API (and therefore the frontend payroll / payments pages).
 *
 * Sample employees (existing test employees - no new employee records created):
 *   - Employee A: id 1, EMP-000001 "Demo Staff Member"     - basic ₱25,000  -> fully paid
 *   - Employee B: id 2, EMP-000002 "Operations Manager"    - basic ₱45,000  -> fully paid
 *                                                   with Transport + Meal allowances
 *                                                   and a Uniform deduction
 *   - Employee C: id 9, EMP-000009 "shaine debs"           - basic ₱30,000  -> finalised,
 *                                                   awaiting payment (UNPAID)
 *
 * Safe to rerun: the sample periods (which cascade to payroll rows, payroll items,
 * payroll statutory rows and the payroll_payments ledger via ON DELETE CASCADE)
 * plus the attendance rows this script manages are deleted before being recreated,
 * so nothing is duplicated.
 *
 * Usage:
 *   DB_NAME=attendance_payroll_test php database/seed_payroll_history.php
 *
 * The script refuses to run against a production-looking database
 * (attendance_payroll, ...prod..., ...live...) unless
 * PMS_ALLOW_GENUINE_DB=1 or PMS_ALLOW_PRODUCTION_DB=1 is set.
 */

declare(strict_types=1);

require __DIR__ . '/../api/autoload.php';

use App\Core\Database;
use App\Services\PayrollService;
use App\Services\PayrollPaymentService;

// ---------------------------------------------------------------------------
// Configuration
// ---------------------------------------------------------------------------

const ADMIN_USER_ID = 1; // The CLI has no HTTP session; attribute actions to admin.

const SAMPLE_PERIODS = [
    [
        'name'     => 'Payroll History Sample - August 2026',
        'code'     => 'PP-SAMPLE-20260801-20260831',
        'start'    => '2026-08-01',
        'end'      => '2026-08-31',
        'pay_date' => '2026-08-31',
    ],
    [
        'name'     => 'Payroll History Sample - September 2026',
        'code'     => 'PP-SAMPLE-20260901-20260930',
        'start'    => '2026-09-01',
        'end'      => '2026-09-30',
        'pay_date' => '2026-09-30',
    ],
];

// Existing test employees used as the three samples.
const SAMPLE_EMPLOYEE_IDS = [1, 2, 9]; // A, B, C
const EMPLOYEE_B_ID = 2;

// Allowance / deduction master ids (verified against the seeded allowances /
// deductions tables): TRANSPORT=1, MEAL=2, UNIFORM=5.
const B_ALLOWANCES = [1 => 1500.00, 2 => 800.00];
const B_DEDUCTIONS = [5 => 250.00];

const REMARK = 'PAYROLL HISTORY SAMPLE'; // marks attendance rows this script manages.
// ---------------------------------------------------------------------------
// Safety: test database only
// ---------------------------------------------------------------------------

$config = require __DIR__ . '/../api/config/config.php';
$dbName = (string) ($config['database']['name'] ?? '');
$lower  = strtolower($dbName);

$productionLike = $dbName === ''
    || $lower === 'attendance_payroll'
    || preg_match('/(^|[_\\-.])prod(uction)?([_\\-.]|$)/', $lower) === 1
    || preg_match('/(^|[_\\-.])live([_\\-.]|$)/', $lower) === 1;

if ($productionLike
    && getenv('PMS_ALLOW_GENUINE_DB') !== '1'
    && getenv('PMS_ALLOW_PRODUCTION_DB') !== '1') {
    fwrite(STDERR, "Refusing to seed payroll history into a production-looking database: {$dbName}\n");
    fwrite(STDERR, "Run against the test database instead, for example:\n");
    fwrite(STDERR, "  DB_NAME=attendance_payroll_test php {$_SERVER['SCRIPT_FILENAME']}\n");
    exit(1);
}

echo "Seeding payroll history into database: {$dbName}\n";

// ---------------------------------------------------------------------------
// Ensure the payments ledger migration is applied (idempotent, safe to rerun).
// ---------------------------------------------------------------------------

$phpBin   = getenv('PMS_PHP_BIN') ?: 'C:/xampp/php/php.exe';
$migrate  = __DIR__ . '/migrate_payroll_payments.php';
$migrateOutput = [];
$migrateCode = 0;
exec("\"{$phpBin}\" {$migrate}", $migrateOutput, $migrateCode);
foreach ($migrateOutput as $line) {
    if ($line !== '') {
        echo "  {$line}\n";
    }
}
if ($migrateCode !== 0) {
    fwrite(STDERR, "Payroll payments migration failed.\n");
    exit(1);
}

// ---------------------------------------------------------------------------
// Idempotency: remove anything a previous run of this script created.
// ---------------------------------------------------------------------------

Database::transaction(function () {
    $names = array_map(static fn (array $p): string => $p['name'], SAMPLE_PERIODS);
    // Deleting a period cascades to payroll rows, payroll_items,
    // payroll_statutory and payroll_payments (all ON DELETE CASCADE).
    foreach ($names as $name) {
        Database::delete('payroll_periods', ['name' => $name]);
    }
    // Attendance is not tied to payroll_periods, so remove the sample-managed
    // attendance rows we are about to recreate.
    $from = min(array_column(SAMPLE_PERIODS, 'start'));
    $to   = max(array_column(SAMPLE_PERIODS, 'end'));
    Database::execute(
        'DELETE FROM attendance WHERE remarks = :remark AND attendance_date >= :from AND attendance_date <= :to',
        ['remark' => REMARK, 'from' => $from, 'to' => $to]
    );
});

// Idempotent component assignments for sample B (delete then re-insert).
Database::delete('employee_allowances', ['employee_id' => EMPLOYEE_B_ID]);
Database::delete('employee_deductions', ['employee_id' => EMPLOYEE_B_ID]);
foreach (B_ALLOWANCES as $allowanceId => $amount) {
    Database::insert('employee_allowances', [
        'employee_id' => EMPLOYEE_B_ID,
        'allowance_id' => $allowanceId,
        'amount' => $amount,
        'is_active' => 1,
    ]);
}
foreach (B_DEDUCTIONS as $deductionId => $amount) {
    Database::insert('employee_deductions', [
        'employee_id' => EMPLOYEE_B_ID,
        'deduction_id' => $deductionId,
        'amount' => $amount,
        'is_active' => 1,
    ]);
}

echo "Component assignments for employee B (id " . EMPLOYEE_B_ID . ") refreshed.\n";

// ---------------------------------------------------------------------------
// Reference data: holidays and working-day schedule (schedule 1 = Mon-Fri).
// ---------------------------------------------------------------------------

$holidays = [];
foreach (Database::select("SELECT holiday_date FROM holidays WHERE status = 'ACTIVE' AND deleted_at IS NULL") as $row) {
    $holidays[$row['holiday_date']] = true;
}

$scheduleDays = []; // (schedule_id, day_of_week) => ['shift_id'=>.., 'is_rest_day'=>..]
foreach (Database::select("SELECT work_schedule_id, day_of_week, shift_id, is_rest_day FROM work_schedule_days") as $row) {
    $scheduleDays[(int) $row['work_schedule_id']][(int) $row['day_of_week']] = [
        'shift_id'    => $row['shift_id'] ?? null,
        'is_rest_day' => (int) ($row['is_rest_day'] ?? 0) === 1,
    ];
}

$shifts = [];
foreach (Database::select("SELECT id, start_time, end_time FROM shifts WHERE is_active = 1 AND deleted_at IS NULL") as $row) {
    $shifts[(int) $row['id']] = ['start' => (string) $row['start_time'], 'end' => (string) $row['end_time']];
}

function isWorkingDay(string $date): bool
{
    global $scheduleDays, $holidays;
    $dow = (int) date('w', strtotime($date)); // 0 = Sunday
    foreach ($scheduleDays as $days) {
        $day = $days[$dow] ?? null;
        if ($day !== null && !$day['is_rest_day'] && $day['shift_id'] !== null && !isset($holidays[$date])) {
            return true;
        }
    }
    return false;
}

function shiftForDay(string $date, int $scheduleId): ?array
{
    global $scheduleDays, $shifts;
    $dow = (int) date('w', strtotime($date));
    $day = $scheduleDays[$scheduleId][$dow] ?? null;
    if ($day === null || $day['shift_id'] === null) {
        return null;
    }
    return $shifts[$day['shift_id']] ?? null;
}

// ---------------------------------------------------------------------------
// Create periods, attendance, calculate, approve, finalise.
// ---------------------------------------------------------------------------

$createdPeriodIds = [];
$globalFrom = min(array_column(SAMPLE_PERIODS, 'start'));
$globalTo   = max(array_column(SAMPLE_PERIODS, 'end'));

// Pre-fetch existing attendance in the managed date range so we never insert a
// duplicate row for an employee/date that already has one.
$existingAttendance = [];
foreach (Database::select(
    'SELECT employee_id, attendance_date FROM attendance
      WHERE attendance_date >= :from AND attendance_date <= :to AND deleted_at IS NULL',
    ['from' => $globalFrom, 'to' => $globalTo]
) as $row) {
    $existingAttendance[(int) $row['employee_id'] . '|' . $row['attendance_date']] = true;
}

$payrollService = new PayrollService();

foreach (SAMPLE_PERIODS as $periodData) {
    // 1. Create the period (DRAFT).
    $period = $payrollService->createPeriod([
        'code'       => $periodData['code'],
        'name'       => $periodData['name'],
        'start_date' => $periodData['start'],
        'end_date'   => $periodData['end'],
        'pay_date'   => $periodData['pay_date'],
    ], ADMIN_USER_ID);
    $periodId = (int) $period['id'];
    $createdPeriodIds[] = $periodId;
    echo "Created period: {$periodData['name']} (id {$periodId})\n";

    // 2. Create PRESENT attendance for every active employee on working days.
    $employees = Database::select(
        "SELECT id, work_schedule_id FROM employees
          WHERE status = 'ACTIVE' AND archived_at IS NULL AND deleted_at IS NULL
          ORDER BY id"
    );
    $attendanceCount = 0;
    $start = new DateTimeImmutable($periodData['start']);
    $end   = new DateTimeImmutable($periodData['end']);
    for ($date = $start; $date <= $end; $date = $date->modify('+1 day')) {
        $dateString = $date->format('Y-m-d');
        if (!isWorkingDay($dateString)) {
            continue;
        }
        $shift = shiftForDay($dateString, 1); // all active employees use schedule 1
        if ($shift === null) {
            continue;
        }
        foreach ($employees as $employee) {
            $empId = (int) $employee['id'];
            $key   = $empId . '|' . $dateString;
            if (isset($existingAttendance[$key])) {
                continue;
            }
            Database::insert('attendance', [
                'employee_id'      => $empId,
                'attendance_date'  => $dateString,
                'shift_id'         => $shift['shift_id'] ?? null,
                'work_schedule_id' => (int) ($employee['work_schedule_id'] ?? 0),
                'scheduled_start'  => $shift['start'],
                'scheduled_end'    => $shift['end'],
                'worked_hours'     => 8.00,
                'late_minutes'     => 0,
                'undertime_minutes'=> 0,
                'overtime_hours'   => 0.00,
                'status'           => 'PRESENT',
                'is_rest_day'      => 0,
                'is_holiday'       => 0,
                'leave_request_id' => null,
                'source'           => 'MANUAL',
                'remarks'          => REMARK,
            ]);
            $existingAttendance[$key] = true;
            $attendanceCount++;
        }
    }
    echo "  Created {$attendanceCount} attendance record(s)\n";

    // 3. Calculate payroll via the real engine (DRAFT -> CALCULATING -> FOR_REVIEW).
    $calc = $payrollService->calculate($periodId, ADMIN_USER_ID);
    echo "  Calculated payroll for {$calc['employees_processed']} employee(s): "
        . "gross " . number_format($calc['total_gross'], 2)
        . ", deductions " . number_format($calc['total_deductions'], 2)
        . ", net " . number_format($calc['total_net'], 2) . "\n";

    // 4. Approve then finalise (finalised payroll is locked).
    $payrollService->transition($periodId, 'APPROVED', ADMIN_USER_ID);
    $payrollService->transition($periodId, 'FINALIZED', ADMIN_USER_ID);
    echo "  Period moved to FINALIZED\n";
}

// ---------------------------------------------------------------------------
// Record payments: sample A and B fully paid in the August period;
// sample C left UNPAID (finalised payroll awaiting payment).
// ---------------------------------------------------------------------------

$payrollPeriodId = (int) $createdPeriodIds[0]; // August 2026
$paymentService  = new PayrollPaymentService();
$payDate         = SAMPLE_PERIODS[0]['pay_date'];

$rows = Database::select(
    "SELECT p.id AS payroll_id, p.employee_id, p.net_pay, p.payment_status
       FROM payroll p
      WHERE p.payroll_period_id = :pid
        AND p.employee_id IN (:e1, :e2, :e3)",
    ['pid' => $payrollPeriodId, 'e1' => SAMPLE_EMPLOYEE_IDS[0], 'e2' => SAMPLE_EMPLOYEE_IDS[1], 'e3' => SAMPLE_EMPLOYEE_IDS[2]]
);

$sampleById = [
    SAMPLE_EMPLOYEE_IDS[0] => 'A',
    SAMPLE_EMPLOYEE_IDS[1] => 'B',
    SAMPLE_EMPLOYEE_IDS[2] => 'C',
];

$paidEmployeeIds = [SAMPLE_EMPLOYEE_IDS[0], SAMPLE_EMPLOYEE_IDS[1]]; // A and B are fully paid

foreach ($rows as $row) {
    $empId    = (int) $row['employee_id'];
    $netPay   = round((float) $row['net_pay'], 2);
    $label    = $sampleById[$empId] ?? '?';
    $already  = (string) $row['payment_status'];

    if ($netPay <= 0) {
        echo "  Sample {$label} (emp {$empId}): net_pay is zero/negative, no payment recorded\n";
        continue;
    }

    if (!in_array($empId, $paidEmployeeIds, true)) {
        echo "  Sample {$label} (emp {$empId}): left UNPAID (finalised, awaiting payment)\n";
        continue;
    }

    if ($already === 'PAID') {
        echo "  Sample {$label} (emp {$empId}): already PAID, skipping\n";
        continue;
    }

    $paymentService->record(
        (int) $row['payroll_id'],
        [
            'amount'             => $netPay,
            'payment_method'     => 'BANK_TRANSFER',
            'payment_status'     => 'COMPLETED',
            'confirmed'          => true,
            'payment_date'       => $payDate,
            'idempotency_key'    => 'SAMPLE-' . $empId . '-' . $payrollPeriodId,
            'method_reference'   => 'SAMPLE-PAY-' . $empId,
            'notes'              => 'Sample payroll history - full net pay disbursed.',
        ],
        ADMIN_USER_ID
    );
    echo "  Sample {$label} (emp {$empId}): fully paid (net ₱" . number_format($netPay, 2) . ")\n";
}

// ---------------------------------------------------------------------------
// Summary
// ---------------------------------------------------------------------------

echo "\nPayroll history seeding complete.\n";
echo "  Periods created : " . count($createdPeriodIds) . " (" . implode(', ', array_column(SAMPLE_PERIODS, 'name')) . ")\n";
echo "  Sample employees: " . implode(', ', SAMPLE_EMPLOYEE_IDS) . "\n";
echo "  Scenarios:\n";
echo "    A (emp " . SAMPLE_EMPLOYEE_IDS[0] . ") - fully paid\n";
echo "    B (emp " . SAMPLE_EMPLOYEE_IDS[1] . ") - fully paid with allowances/deductions\n";
echo "    C (emp " . SAMPLE_EMPLOYEE_IDS[2] . ") - finalised, awaiting payment\n";

