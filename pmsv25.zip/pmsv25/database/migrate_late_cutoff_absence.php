<?php
declare(strict_types=1);

/**
 * Migration: add the 30-minute late cut-off settings (idempotent).
 *
 * Run once on an existing database:
 *   php database/migrate_late_cutoff_absence.php
 *
 * Uses its own PDO connection (like database/migrate_13th_month.php) instead
 * of api/bootstrap.php, which would dispatch an HTTP request and exit before
 * the migration ran. INSERT IGNORE means re-running never overwrites a value
 * an administrator has already set.
 */

$config = require __DIR__ . '/../api/config/config.php';
$db     = $config['database'];

$path = __DIR__ . '/migrations/20261010_late_cutoff_absence.sql';

if (!is_file($path)) {
    echo "MIGRATION NOT FOUND: {$path}\n";
    exit(1);
}

$ddl = file_get_contents($path);
if ($ddl === false) {
    echo "MIGRATION READ FAILED: {$path}\n";
    exit(1);
}

// Strip standalone comment lines, then split on the statement terminator. The
// migration contains no semicolons inside string literals, so a plain split is
// safe.
$sql        = preg_replace('/^\s*--.*$/m', '', $ddl) ?? '';
$statements = array_values(array_filter(
    array_map('trim', explode(';', $sql)),
    static fn (string $statement): bool => $statement !== ''
));

try {
    $pdo = new PDO(
        sprintf('mysql:host=%s;port=%d;dbname=%s;charset=%s', $db['host'], (int) $db['port'], $db['name'], $db['charset']),
        $db['user'],
        $db['password'],
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
    );

    foreach ($statements as $statement) {
        $pdo->exec($statement);
    }

    echo "LATE_CUTOFF: migrated OK (attendance.late_cutoff_minutes + attendance.auto_absence)\n";
} catch (\Throwable $e) {
    echo 'LATE_CUTOFF: MIGRATION FAILED: ' . $e->getMessage() . "\n";
    exit(1);
}