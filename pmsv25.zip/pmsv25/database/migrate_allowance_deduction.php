<?php
declare(strict_types=1);

/**
 * Migration: allowance & deduction management (Phase 4).
 *
 * Run once on an existing database:
 *   php database/migrate_allowance_deduction.php
 *
 * Like the other runners this opens its own PDO connection (api/bootstrap.php
 * would dispatch an HTTP request and exit before the migration ran). The SQL
 * itself only adds columns, keys, constraints and permissions, so the whole
 * file is repeatable: a repeated column/key/constraint is reported as
 * "already in place" instead of failing the run.
 *
 * It never drops, truncates or resets a table, and every column it adds
 * defaults to the behaviour that was already in force (fixed peso amount,
 * recurring, charged in full every pay period, no date bound), so no existing
 * allowance, deduction or payroll figure changes.
 */

$config = require __DIR__ . '/../api/config/config.php';
$db     = $config['database'];

$path = __DIR__ . '/migrations/20261013_allowance_deduction_management.sql';

if (!is_file($path)) {
    echo "MIGRATION NOT FOUND: {$path}\n";
    exit(1);
}

$ddl = file_get_contents($path);
if ($ddl === false) {
    echo "MIGRATION READ FAILED: {$path}\n";
    exit(1);
}

// Strip standalone comment lines, then split on the statement terminator. The
// migration contains no semicolons inside string literals, so a plain split is
// safe (same approach as database/migrate_employee_loans.php).
$sql        = preg_replace('/^\s*--.*$/m', '', $ddl) ?? '';
$statements = array_values(array_filter(
    array_map('trim', explode(';', $sql)),
    static fn (string $statement): bool => $statement !== ''
));

/** Errors that simply mean the statement was already applied. */
const ALREADY_APPLIED = [
    'Duplicate column name',
    'Duplicate key name',
    'Duplicate foreign key constraint name',
    'already exists',
    'check that column/key exists',
    // Re-adding a FOREIGN KEY whose backing index was auto-created by the
    // first run raises errno 121 "Duplicate key on write or update" rather
    // than "Duplicate ... constraint name". Same situation, same skip.
    'duplicate key on write or update',
    'errno: 121',
];

try {
    $pdo = new PDO(
        sprintf('mysql:host=%s;port=%d;dbname=%s;charset=%s', $db['host'], (int) $db['port'], $db['name'], $db['charset']),
        $db['user'],
        $db['password'],
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
    );

    // Prove the target before a single statement runs. DB_NAME can be set by a
    // wrapper (run_all.sh does), so the resolved database is read back from the
    // server instead of being trusted from configuration alone: a misdirected
    // run is visible on the first line of the output.
    printf(
        "ALLOWANCE-DEDUCTION: target %s on %s:%d (DATABASE() = %s, server %s)\n",
        $db['name'],
        $db['host'],
        (int) $db['port'],
        $pdo->query('SELECT DATABASE()')->fetchColumn(),
        $pdo->query('SELECT VERSION()')->fetchColumn()
    );

    $applied = 0;
    $skipped = 0;

    foreach ($statements as $statement) {
        try {
            $pdo->exec($statement);
            $applied++;
        } catch (\PDOException $e) {
            $message = $e->getMessage();
            $benign  = false;
            foreach (ALREADY_APPLIED as $needle) {
                if (stripos($message, $needle) !== false) {
                    $benign = true;
                    break;
                }
            }

            if ($benign) {
                $skipped++;
                continue;
            }

            throw $e;
        }
    }

    // Report the shape of the result so a half-applied run is obvious.
    $allowanceColumns = (int) $pdo->query(
        "SELECT COUNT(*) FROM information_schema.columns
          WHERE table_schema = DATABASE() AND table_name = 'allowances'
            AND column_name IN ('is_percentage','is_recurring','frequency','effective_from','effective_to','category','created_by','updated_by')"
    )->fetchColumn();

    $deductionColumns = (int) $pdo->query(
        "SELECT COUNT(*) FROM information_schema.columns
          WHERE table_schema = DATABASE() AND table_name = 'deductions'
            AND column_name IN ('is_recurring','frequency','effective_from','effective_to','category','created_by','updated_by')"
    )->fetchColumn();

    $assignmentColumns = (int) $pdo->query(
        "SELECT COUNT(*) FROM information_schema.columns
          WHERE table_schema = DATABASE() AND table_name = 'employee_allowances'
            AND column_name IN ('effective_from','effective_to','reason','notes','created_by','updated_by','updated_at','deleted_at')"
    )->fetchColumn();

    $deductionAssignmentColumns = (int) $pdo->query(
        "SELECT COUNT(*) FROM information_schema.columns
          WHERE table_schema = DATABASE() AND table_name = 'employee_deductions'
            AND column_name IN ('effective_from','effective_to','reason','notes','created_by','updated_by','updated_at','deleted_at')"
    )->fetchColumn();

    $assignmentIndex = (int) $pdo->query(
        "SELECT COUNT(DISTINCT index_name) FROM information_schema.statistics
          WHERE table_schema = DATABASE()
            AND index_name IN ('idx_empallow_active','idx_empded_active')"
    )->fetchColumn();

    // Counted per permission (0-6) so the report below reads like the other
    // x/y lines. A single COUNT(*) over six ANDed JSON_CONTAINS conditions
    // could only ever answer 0 or 1, which printed as a misleading "1/6".
    $permissions = (int) $pdo->query(
        "SELECT COALESCE(SUM(
                    JSON_CONTAINS(`permissions`, '\"allowances.view\"')
                  + JSON_CONTAINS(`permissions`, '\"allowances.manage\"')
                  + JSON_CONTAINS(`permissions`, '\"allowances.assign\"')
                  + JSON_CONTAINS(`permissions`, '\"deductions.view\"')
                  + JSON_CONTAINS(`permissions`, '\"deductions.manage\"')
                  + JSON_CONTAINS(`permissions`, '\"deductions.assign\"')
                ), 0)
           FROM `roles`
          WHERE `code` = 'MANAGER' AND JSON_VALID(`permissions`)"
    )->fetchColumn();

    $allowances = (int) $pdo->query('SELECT COUNT(*) FROM `allowances`')->fetchColumn();
    $deductions = (int) $pdo->query('SELECT COUNT(*) FROM `deductions`')->fetchColumn();
    $assignments = (int) $pdo->query(
        'SELECT (SELECT COUNT(*) FROM `employee_allowances`) + (SELECT COUNT(*) FROM `employee_deductions`)'
    )->fetchColumn();

    printf(
        "ALLOWANCE-DEDUCTION: migrated OK (statements %d applied, %d already in place)\n" .
        "  allowances columns:      %d/8\n" .
        "  deductions columns:      %d/7\n" .
        "  allowance assignments:   %d/8\n" .
        "  deduction assignments:   %d/8\n" .
        "  assignment indexes:      %d/2\n" .
        "  MANAGER permissions:     %d/6\n" .
        "  allowances / deductions: %d / %d\n" .
        "  assignments kept:        %d\n",
        $applied,
        $skipped,
        $allowanceColumns,
        $deductionColumns,
        $assignmentColumns,
        $deductionAssignmentColumns,
        $assignmentIndex,
        $permissions,
        $allowances,
        $deductions,
        $assignments
    );
} catch (\Throwable $e) {
    echo 'ALLOWANCE-DEDUCTION: MIGRATION FAILED: ' . $e->getMessage() . "\n";
    exit(1);
}