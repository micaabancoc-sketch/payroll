<?php
declare(strict_types=1);

/**
 * Migration: individual payroll payments & disbursement ledger (Phase 5).
 *
 * Run once on an existing database:
 *   php database/migrate_payroll_payments.php
 *
 * Like the other runners this opens its own PDO connection (api/bootstrap.php
 * would dispatch an HTTP request and exit before the migration ran). The SQL
 * itself only adds a table, columns, keys, constraints and permissions, so the
 * whole file is repeatable: a repeated column/key/constraint is reported as
 * "already in place" instead of failing the run.
 *
 * It never drops, truncates or resets a table and it never rewrites a net-pay
 * figure, so existing payroll rows, loan repayments and 13th-month records
 * are preserved exactly as they were. The backfill only marks rows that were
 * already considered disbursed (period PAID) or need no disbursement
 * (net_pay <= 0) as PAID; every other row stays UNPAID until disbursed
 * through the new ledger.
 */

$config = require __DIR__ . '/../api/config/config.php';
$db     = $config['database'];

$path = __DIR__ . '/migrations/20261014_payroll_payments.sql';

if (!is_file($path)) {
    echo "MIGRATION NOT FOUND: {$path}\n";
    exit(1);
}

$ddl = file_get_contents($path);
if ($ddl === false) {
    echo "MIGRATION READ FAILED: {$path}\n";
    exit(1);
}

// Strip standalone comment lines, then split on the statement terminator. The
// migration contains no semicolons inside string literals, so a plain split is
// safe (same approach as database/migrate_employee_loans.php).
$sql        = preg_replace('/^\s*--.*$/m', '', $ddl) ?? '';
$statements = array_values(array_filter(
    array_map('trim', explode(';', $sql)),
    static fn (string $statement): bool => $statement !== ''
));

/** Errors that simply mean the statement was already applied. */
const ALREADY_APPLIED = [
    'Duplicate column name',
    'Duplicate key name',
    'Duplicate foreign key constraint name',
    'already exists',
    'check that column/key exists',
    'duplicate key on write or update',
    'errno: 121',
];

try {
    $pdo = new PDO(
        sprintf('mysql:host=%s;port=%d;dbname=%s;charset=%s', $db['host'], (int) $db['port'], $db['name'], $db['charset']),
        $db['user'],
        $db['password'],
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
    );

    printf(
        "PAYROLL_PAYMENTS: target %s on %s:%d (DATABASE() = %s, server %s)\n",
        $db['name'],
        $db['host'],
        (int) $db['port'],
        $pdo->query('SELECT DATABASE()')->fetchColumn(),
        $pdo->query('SELECT VERSION()')->fetchColumn()
    );

    $applied = 0;
    $skipped = 0;

    foreach ($statements as $statement) {
        try {
            $pdo->exec($statement);
            $applied++;
        } catch (\PDOException $e) {
            $message = $e->getMessage();
            $benign  = false;
            foreach (ALREADY_APPLIED as $needle) {
                if (stripos($message, $needle) !== false) {
                    $benign = true;
                    break;
                }
            }
            if ($benign) {
                $skipped++;
                continue;
            }
            throw $e;
        }
    }

    $ledgerTable = (int) $pdo->query(
        "SELECT COUNT(*) FROM information_schema.tables
          WHERE table_schema = DATABASE() AND table_name = 'payroll_payments'"
    )->fetchColumn();

    $payrollCols = (int) $pdo->query(
        "SELECT COUNT(*) FROM information_schema.columns
          WHERE table_schema = DATABASE() AND table_name = 'payroll'
            AND column_name IN ('amount_paid','payment_status')"
    )->fetchColumn();

    $payrollKey = (int) $pdo->query(
        "SELECT COUNT(*) FROM information_schema.statistics
          WHERE table_schema = DATABASE() AND table_name = 'payroll'
            AND index_name = 'idx_payroll_paystatus'"
    )->fetchColumn();

    $ledgerUnique = (int) $pdo->query(
        "SELECT COUNT(DISTINCT index_name) FROM information_schema.statistics
          WHERE table_schema = DATABASE() AND table_name = 'payroll_payments'
            AND index_name IN ('uq_payrollpay_ref','uq_payrollpay_idem')"
    )->fetchColumn();

    $permissions = (int) $pdo->query(
        "SELECT COALESCE(SUM(
                    JSON_CONTAINS(`permissions`, '\"payroll.payments.view\"')
                  + JSON_CONTAINS(`permissions`, '\"payroll.payments.record\"')
                  + JSON_CONTAINS(`permissions`, '\"payroll.payments.cancel\"')
                ), 0)
           FROM `roles`
          WHERE `code` = 'MANAGER' AND JSON_VALID(`permissions`)"
    )->fetchColumn();

    $payments = $ledgerTable > 0 ? (int) $pdo->query('SELECT COUNT(*) FROM `payroll_payments`')->fetchColumn() : 0;

    printf(
        "PAYROLL_PAYMENTS: migrated OK (statements %d applied, %d already in place)\n" .
        "  ledger table:              %d/1\n" .
        "  payroll columns:           %d/2\n" .
        "  payroll status key:        %d/1\n" .
        "  ledger unique keys:        %d/2\n" .
        "  MANAGER payment perms:     %d/3\n" .
        "  disbursement rows kept:    %d\n",
        $applied,
        $skipped,
        $ledgerTable,
        $payrollCols,
        $payrollKey,
        $ledgerUnique,
        $permissions,
        $payments
    );
} catch (\Throwable $e) {
    echo 'PAYROLL_PAYMENTS: MIGRATION FAILED: ' . $e->getMessage() . "\n";
    exit(1);
}
