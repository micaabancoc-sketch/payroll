<?php
declare(strict_types=1);

/**
 * Migration: government contributions (SSS, PhilHealth, Pag-IBIG) and BIR
 * withholding tax schedules + the payroll columns that hold them.
 *
 * Run once on an existing database:
 *   php database/migrate_statutory_deductions.php
 *
 * Like the other runners this opens its own PDO connection (api/bootstrap.php
 * would dispatch an HTTP request and exit before the migration ran). The SQL
 * itself is idempotent (CREATE TABLE IF NOT EXISTS / INSERT IGNORE); the only
 * non-repeatable statement is the ALTER TABLE on `payroll`, so duplicate
 * column errors are reported as "already applied" instead of failing the run.
 */

$config = require __DIR__ . '/../api/config/config.php';
$db     = $config['database'];

$path = __DIR__ . '/migrations/20261011_statutory_deductions.sql';

if (!is_file($path)) {
    echo "MIGRATION NOT FOUND: {$path}\n";
    exit(1);
}

$ddl = file_get_contents($path);
if ($ddl === false) {
    echo "MIGRATION READ FAILED: {$path}\n";
    exit(1);
}

// Strip standalone comment lines, then split on the statement terminator. The
// migration contains no semicolons inside string literals, so a plain split is
// safe (same approach as database/migrate_late_cutoff_absence.php).
$sql        = preg_replace('/^\s*--.*$/m', '', $ddl) ?? '';
$statements = array_values(array_filter(
    array_map('trim', explode(';', $sql)),
    static fn (string $statement): bool => $statement !== ''
));

/** Errors that simply mean the statement was already applied. */
const ALREADY_APPLIED = ['Duplicate column name', 'already exists', 'Duplicate key name', 'check that column/key exists'];

try {
    $pdo = new PDO(
        sprintf('mysql:host=%s;port=%d;dbname=%s;charset=%s', $db['host'], (int) $db['port'], $db['name'], $db['charset']),
        $db['user'],
        $db['password'],
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
    );

    $applied = 0;
    $skipped = 0;

    foreach ($statements as $statement) {
        try {
            $pdo->exec($statement);
            $applied++;
        } catch (\PDOException $e) {
            $message = $e->getMessage();
            $benign  = false;
            foreach (ALREADY_APPLIED as $needle) {
                if (stripos($message, $needle) !== false) {
                    $benign = true;
                    break;
                }
            }

            if (!$benign) {
                throw $e;
            }

            $skipped++;
        }
    }

    $tables = (int) $pdo->query(
        "SELECT COUNT(*) FROM information_schema.tables
          WHERE table_schema = DATABASE()
            AND table_name IN ('statutory_schedules','bir_withholding_schedules','bir_withholding_brackets','payroll_statutory')"
    )->fetchColumn();

    $brackets = (int) $pdo->query('SELECT COUNT(*) FROM `bir_withholding_brackets`')->fetchColumn();
    $schedules = (int) $pdo->query('SELECT COUNT(*) FROM `statutory_schedules`')->fetchColumn();
    $columns  = (int) $pdo->query(
        "SELECT COUNT(*) FROM information_schema.columns
          WHERE table_schema = DATABASE() AND table_name = 'payroll'
            AND column_name IN ('statutory_sss','statutory_philhealth','statutory_pagibig','withholding_tax','statutory_total','employer_contributions')"
    )->fetchColumn();

    printf(
        "STATUTORY: migrated OK (statements %d applied, %d already in place)\n" .
        "  payroll columns:        %d/6\n" .
        "  statutory tables:       %d/4\n" .
        "  contribution schedules: %d\n" .
        "  BIR bracket rows:       %d\n",
        $applied,
        $skipped,
        $columns,
        $tables,
        $schedules,
        $brackets
    );
} catch (\Throwable $e) {
    echo 'STATUTORY: MIGRATION FAILED: ' . $e->getMessage() . "\n";
    exit(1);
}