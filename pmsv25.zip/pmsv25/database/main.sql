-- ============================================================================
-- ATTENDANCE & PAYROLL MANAGEMENT SYSTEM
-- Database Schema (MySQL 8+ / MariaDB 10.4+)
-- ============================================================================
--
-- WARNING - THIS FILE ALWAYS TARGETS THE `attendance_payroll` DATABASE.
--
-- The CREATE DATABASE / USE statements below are hard-coded, so the import
-- always lands in `attendance_payroll` no matter which database the client was
-- pointed at (`mysql attendance_payroll_test < database/main.sql` still loads
-- into `attendance_payroll`). Importing it DROPs every table (37) and TRUNCATEs
-- the seeded ones (16) before recreating them, so anything already stored in
-- `attendance_payroll` - real employees, attendance and payroll - is destroyed.
--
-- It is therefore SAFE ONLY on an empty or throwaway database. To load the
-- schema into another database (for example a disposable test clone), create it
-- first and strip the two hard-coded lines:
--
--   mysql -u root -e "CREATE DATABASE IF NOT EXISTS attendance_payroll_test \
--     CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci"
--   sed -e '/^CREATE DATABASE/d' -e '/^USE /d' database/main.sql \
--     | mysql -u root attendance_payroll_test
--
-- Never re-import this file over an existing installation. Apply the migrations
-- in database/migrations/ through their runners instead (for example
-- `php database/migrate_statutory_deductions.php`): they are idempotent and
-- never drop, truncate or reset a table.
-- ============================================================================

CREATE DATABASE IF NOT EXISTS `attendance_payroll`
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `attendance_payroll`;

SET FOREIGN_KEY_CHECKS = 0;

-- ============================================================================
-- SECTION 1: ACCESS CONTROL
-- ============================================================================

DROP TABLE IF EXISTS `api_tokens`;
CREATE TABLE `api_tokens` (
  `id`            BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id`       BIGINT UNSIGNED NOT NULL,
  `token_hash`    CHAR(64)     NOT NULL,
  `expires_at`    DATETIME     NOT NULL,
  `last_used_at`  DATETIME     NULL,
  `ip_address`    VARCHAR(45)  NULL,
  `user_agent`    VARCHAR(255) NULL,
  `is_revoked`    TINYINT(1)   NOT NULL DEFAULT 0,
  `created_at`    DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_api_tokens_hash` (`token_hash`),
  KEY `idx_api_tokens_user` (`user_id`, `is_revoked`),
  KEY `idx_api_tokens_exp` (`expires_at`),
  CONSTRAINT `fk_api_tokens_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `roles`;
CREATE TABLE `roles` (
  `id`          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `code`        VARCHAR(50)  NOT NULL,
  `name`        VARCHAR(100) NOT NULL,
  `description` VARCHAR(255) NULL,
  `permissions` LONGTEXT     NULL, -- JSON array of permission codes
  `is_system`   TINYINT(1)   NOT NULL DEFAULT 0,
  `created_at`  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_roles_code` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id`             BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `username`       VARCHAR(100) NOT NULL,
  `email`          VARCHAR(150) NULL,
  `password_hash`  VARCHAR(255) NOT NULL,
  `full_name`      VARCHAR(150) NOT NULL,
  `role_id`        BIGINT UNSIGNED NOT NULL,
  `employee_id`    BIGINT UNSIGNED NULL,
  `status`         ENUM('ACTIVE','INACTIVE','LOCKED') NOT NULL DEFAULT 'ACTIVE',
  `must_change_password` TINYINT(1) NOT NULL DEFAULT 0,
  `failed_attempts` TINYINT UNSIGNED NOT NULL DEFAULT 0,
  `locked_until`   DATETIME     NULL,
  `last_login_at`  DATETIME     NULL,
  `last_login_ip`  VARCHAR(45)  NULL,
  `created_at`     DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`     DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted_at`     DATETIME     NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_users_username` (`username`),
  UNIQUE KEY `uq_users_email` (`email`),
  KEY `idx_users_role` (`role_id`),
  KEY `idx_users_employee` (`employee_id`),
  KEY `idx_users_status` (`status`),
  CONSTRAINT `fk_users_role` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`),
  CONSTRAINT `fk_users_employee` FOREIGN KEY (`employee_id`) REFERENCES `employees` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `login_attempts`;
CREATE TABLE `login_attempts` (
  `id`           BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `identifier`   VARCHAR(150) NOT NULL,
  `ip_address`   VARCHAR(45)  NOT NULL,
  `success`      TINYINT(1)   NOT NULL DEFAULT 0,
  `user_agent`   VARCHAR(255) NULL,
  `attempted_at` DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_login_attempts_ident` (`identifier`, `attempted_at`),
  KEY `idx_login_attempts_ip` (`ip_address`, `attempted_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Rate limiting buckets (Phase 20)
DROP TABLE IF EXISTS `rate_limits`;
CREATE TABLE `rate_limits` (
  `id`            BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `bucket_key`    VARCHAR(190) NOT NULL,
  `hits`          INT UNSIGNED NOT NULL DEFAULT 0,
  `window_start`  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `blocked_until` DATETIME     NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_rate_limits_key` (`bucket_key`),
  KEY `idx_rate_limits_blocked` (`blocked_until`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
-- ============================================================================
-- SECTION 2: ORGANISATION (Departments, Positions, Employees)
-- ============================================================================

DROP TABLE IF EXISTS `departments`;
CREATE TABLE `departments` (
  `id`          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `code`        VARCHAR(50)  NOT NULL,
  `name`        VARCHAR(150) NOT NULL,
  `description` VARCHAR(255) NULL,
  `base_salary` DECIMAL(12,2) NULL DEFAULT NULL COMMENT 'DEMO department base salary auto-filled into employee basic_salary',
  `is_active`   TINYINT(1)   NOT NULL DEFAULT 1,
  `created_at`  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted_at`  DATETIME     NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_departments_code` (`code`),
  KEY `idx_departments_active` (`is_active`, `deleted_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `positions`;
CREATE TABLE `positions` (
  `id`            BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `code`          VARCHAR(50)  NOT NULL,
  `name`          VARCHAR(150) NOT NULL,
  `department_id` BIGINT UNSIGNED NULL,
  `job_level`     VARCHAR(50)  NULL,
  `description`   VARCHAR(255) NULL,
  `is_active`     TINYINT(1)   NOT NULL DEFAULT 1,
  `created_at`    DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`    DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted_at`    DATETIME     NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_positions_code` (`code`),
  KEY `idx_positions_dept` (`department_id`),
  CONSTRAINT `fk_positions_dept` FOREIGN KEY (`department_id`) REFERENCES `departments` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `work_schedules`;
CREATE TABLE `work_schedules` (
  `id`            BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `code`          VARCHAR(50)  NOT NULL,
  `name`          VARCHAR(150) NOT NULL,
  `schedule_type` ENUM('REGULAR','FLEXIBLE','NIGHT_SHIFT','ROTATING','CUSTOM') NOT NULL DEFAULT 'REGULAR',
  `description`   VARCHAR(255) NULL,
  `is_default`    TINYINT(1)   NOT NULL DEFAULT 0,
  `is_active`     TINYINT(1)   NOT NULL DEFAULT 1,
  `created_at`    DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`    DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted_at`    DATETIME     NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_work_schedules_code` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `shifts`;
CREATE TABLE `shifts` (
  `id`            BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `code`          VARCHAR(50)  NOT NULL,
  `name`          VARCHAR(150) NOT NULL,
  `start_time`    TIME         NOT NULL,
  `end_time`      TIME         NOT NULL,
  `break_start`   TIME         NULL,
  `break_end`     TIME         NULL,
  `is_overnight`  TINYINT(1)   NOT NULL DEFAULT 0,
  `grace_period_minutes` INT UNSIGNED NOT NULL DEFAULT 5,
  `required_hours` DECIMAL(5,2) NOT NULL DEFAULT 8.00,
  `description`   VARCHAR(255) NULL,
  `is_active`     TINYINT(1)   NOT NULL DEFAULT 1,
  `created_at`    DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`    DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted_at`    DATETIME     NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_shifts_code` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Per-weekday mapping of shifts inside a schedule (supports multiple shifts/day)
DROP TABLE IF EXISTS `work_schedule_days`;
CREATE TABLE `work_schedule_days` (
  `id`               BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `work_schedule_id` BIGINT UNSIGNED NOT NULL,
  `day_of_week`      TINYINT UNSIGNED NOT NULL, -- 0=Sunday .. 6=Saturday
  `shift_id`         BIGINT UNSIGNED NULL,     -- NULL => rest day
  `is_rest_day`      TINYINT(1)   NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_wsd` (`work_schedule_id`, `day_of_week`, `shift_id`),
  KEY `idx_wsd_schedule` (`work_schedule_id`),
CONSTRAINT `fk_wsd_schedule` FOREIGN KEY (`work_schedule_id`) REFERENCES `work_schedules` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_wsd_shift` FOREIGN KEY (`shift_id`) REFERENCES `shifts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
-- ============================================================================
-- SECTION 3: EMPLOYEES, QR CODES, SALARY HISTORY
-- ============================================================================

DROP TABLE IF EXISTS `employees`;
CREATE TABLE `employees` (
  `id`               BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `employee_number`  VARCHAR(50)  NOT NULL,
  `first_name`       VARCHAR(100) NOT NULL,
  `middle_name`      VARCHAR(100) NULL,
  `last_name`        VARCHAR(100) NULL,
  `suffix`           VARCHAR(20)  NULL,
  `gender`           ENUM('MALE','FEMALE','OTHER') NOT NULL DEFAULT 'OTHER',
  `birth_date`       DATE         NULL,
  `address`          VARCHAR(255) NULL,
  `contact_number`   VARCHAR(30)  NULL,
  `email`            VARCHAR(150) NULL,
  `department_id`    BIGINT UNSIGNED NULL,
  `position_id`      BIGINT UNSIGNED NULL,
  `employment_type`  ENUM('FULL_TIME','PART_TIME','CONTRACT','PROBATIONARY','INTERN') NOT NULL DEFAULT 'FULL_TIME',
  `date_hired`       DATE         NOT NULL,
  `salary_type`      ENUM('MONTHLY','SEMI_MONTHLY','DAILY','HOURLY') NOT NULL DEFAULT 'MONTHLY',
  `basic_salary`     DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  `work_schedule_id` BIGINT UNSIGNED NULL,
  `status`           ENUM('ACTIVE','INACTIVE','SUSPENDED','RESIGNED','TERMINATED') NOT NULL DEFAULT 'ACTIVE',
  `archived_at`      DATETIME     NULL,
  `archived_by`      BIGINT UNSIGNED NULL,
  `notes`            TEXT         NULL,
  `created_by`       BIGINT UNSIGNED NULL,
  `created_at`       DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`       DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted_at`       DATETIME     NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_employees_number` (`employee_number`),
  UNIQUE KEY `uq_employees_email` (`email`),
  KEY `idx_employees_dept` (`department_id`),
  KEY `idx_employees_position` (`position_id`),
  KEY `idx_employees_schedule` (`work_schedule_id`),
  KEY `idx_employees_status` (`status`, `deleted_at`),
  KEY `idx_employees_name` (`last_name`, `first_name`),
  CONSTRAINT `fk_employees_dept` FOREIGN KEY (`department_id`) REFERENCES `departments` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_employees_position` FOREIGN KEY (`position_id`) REFERENCES `positions` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_employees_schedule` FOREIGN KEY (`work_schedule_id`) REFERENCES `work_schedules` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_employees_created_by` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_employees_archived_by` FOREIGN KEY (`archived_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `employee_qr_codes`;
CREATE TABLE `employee_qr_codes` (
  `id`              BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `employee_id`     BIGINT UNSIGNED NOT NULL,
  `token_hash`      CHAR(64)     NOT NULL,  -- SHA-256 of the QR token (never stored plaintext)
  `token_hint`      VARCHAR(16)  NOT NULL,  -- last 8 chars, for support lookup only
  `qr_image_path`   VARCHAR(255) NULL,      -- relative path in storage/qrcodes
  `serial_no`       INT UNSIGNED NOT NULL DEFAULT 1,
  `status`          ENUM('ACTIVE','DISABLED','EXPIRED','REPLACED') NOT NULL DEFAULT 'ACTIVE',
  `issued_at`       DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `expires_at`      DATETIME     NULL,
  `disabled_at`     DATETIME     NULL,
  `disabled_reason` VARCHAR(255) NULL,
  `issued_by`       BIGINT UNSIGNED NULL,
  `last_scanned_at` DATETIME     NULL,
  `scan_count`      INT UNSIGNED NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_qr_token_hash` (`token_hash`),
  KEY `idx_qr_employee_status` (`employee_id`, `status`),
  KEY `idx_qr_hint` (`token_hint`),
  CONSTRAINT `fk_qr_employee` FOREIGN KEY (`employee_id`) REFERENCES `employees` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_qr_issued_by` FOREIGN KEY (`issued_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `salary_history`;
CREATE TABLE `salary_history` (
  `id`             BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `employee_id`    BIGINT UNSIGNED NOT NULL,
  `salary_type`    ENUM('MONTHLY','SEMI_MONTHLY','DAILY','HOURLY') NOT NULL DEFAULT 'MONTHLY',
  `basic_salary`   DECIMAL(12,2) NOT NULL,
  `effective_from` DATE         NOT NULL,
  `effective_to`   DATE         NULL,
  `reason`         VARCHAR(255) NULL,
  `changed_by`     BIGINT UNSIGNED NULL,
  `created_at`     DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_salhist_emp` (`employee_id`, `effective_from`),
  CONSTRAINT `fk_salhist_emp` FOREIGN KEY (`employee_id`) REFERENCES `employees` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_salhist_user` FOREIGN KEY (`changed_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================================
-- SECTION 4: HOLIDAYS, ATTENDANCE
-- ============================================================================

DROP TABLE IF EXISTS `holidays`;
CREATE TABLE `holidays` (
  `id`            BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `name`          VARCHAR(150) NOT NULL,
  `holiday_date`  DATE         NOT NULL,
  `holiday_type`  ENUM('REGULAR','SPECIAL','OPTIONAL','REST') NOT NULL DEFAULT 'REGULAR',
  `is_paid`       TINYINT(1)   NOT NULL DEFAULT 1,
  `is_recurring`  TINYINT(1)   NOT NULL DEFAULT 0, -- repeats yearly (month/day kept)
  `status`        ENUM('ACTIVE','INACTIVE') NOT NULL DEFAULT 'ACTIVE',
  `remarks`       VARCHAR(255) NULL,
  `created_at`    DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`    DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted_at`    DATETIME     NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_holidays_date` (`holiday_date`, `name`),
  KEY `idx_holidays_status` (`status`, `deleted_at`),
  KEY `idx_holidays_monthday` (`holiday_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `attendance`;
CREATE TABLE `attendance` (
  `id`                BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `employee_id`       BIGINT UNSIGNED NOT NULL,
  `attendance_date`   DATE         NOT NULL,
  `shift_id`          BIGINT UNSIGNED NULL,
  `work_schedule_id`  BIGINT UNSIGNED NULL,
  `time_in`           DATETIME     NULL,
  `time_out`          DATETIME     NULL,
  `scheduled_start`   TIME         NULL,
  `scheduled_end`     TIME         NULL,
  `worked_hours`      DECIMAL(6,2) NOT NULL DEFAULT 0.00,
  `late_minutes`      INT UNSIGNED NOT NULL DEFAULT 0,
  `undertime_minutes` INT UNSIGNED NOT NULL DEFAULT 0,
  `overtime_hours`    DECIMAL(6,2) NOT NULL DEFAULT 0.00,
  `status`            ENUM('PRESENT','LATE','ABSENT','UNDERTIME','REST_DAY','HOLIDAY','LEAVE','INCOMPLETE','DAY_OFF')
                     NOT NULL DEFAULT 'PRESENT',
  `is_rest_day`       TINYINT(1)   NOT NULL DEFAULT 0,
  `is_holiday`        TINYINT(1)   NOT NULL DEFAULT 0,
  `leave_request_id`  BIGINT UNSIGNED NULL,
  `source`            ENUM('QR','MANUAL','AUTO','IMPORT') NOT NULL DEFAULT 'QR',
  `remarks`           VARCHAR(255) NULL,
  `adjusted_by`       BIGINT UNSIGNED NULL,
  `created_at`        DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`        DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted_at`        DATETIME     NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_attendance_emp_date` (`employee_id`, `attendance_date`),
  KEY `idx_attendance_date_status` (`attendance_date`, `status`),
  KEY `idx_attendance_shift` (`shift_id`),
  CONSTRAINT `fk_attendance_emp` FOREIGN KEY (`employee_id`) REFERENCES `employees` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_attendance_shift` FOREIGN KEY (`shift_id`) REFERENCES `shifts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_attendance_schedule` FOREIGN KEY (`work_schedule_id`) REFERENCES `work_schedules` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_attendance_adjuster` FOREIGN KEY (`adjusted_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Raw, immutable log of every scan/event (Phase 6/18 evidence trail)
DROP TABLE IF EXISTS `attendance_logs`;
CREATE TABLE `attendance_logs` (
  `id`              BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `attendance_id`   BIGINT UNSIGNED NULL,
  `employee_id`     BIGINT UNSIGNED NULL,
  `event_type`      ENUM('TIME_IN','TIME_OUT','OT_TIME_IN','OT_TIME_OUT','REJECTED','MANUAL','QR_REGENERATED','QR_DISABLED','ADJUSTED') NOT NULL,
  `scanned_at`      DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `qr_code_id`      BIGINT UNSIGNED NULL,
  `result`          ENUM('SUCCESS','FAILED') NOT NULL DEFAULT 'SUCCESS',
  `message`         VARCHAR(255) NULL,
  `ip_address`      VARCHAR(45)  NULL,
  `user_agent`      VARCHAR(255) NULL,
  `recorded_by`     BIGINT UNSIGNED NULL,
  PRIMARY KEY (`id`),
  KEY `idx_attlogs_date` (`scanned_at`),
  KEY `idx_attlogs_emp` (`employee_id`),
  KEY `idx_attlogs_result` (`result`),
  CONSTRAINT `fk_attlogs_attendance` FOREIGN KEY (`attendance_id`) REFERENCES `attendance` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_attlogs_emp` FOREIGN KEY (`employee_id`) REFERENCES `employees` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_attlogs_qr` FOREIGN KEY (`qr_code_id`) REFERENCES `employee_qr_codes` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_attlogs_user` FOREIGN KEY (`recorded_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
-- ============================================================================
-- SECTION 5: LEAVE MANAGEMENT
-- ============================================================================

DROP TABLE IF EXISTS `leave_types`;
CREATE TABLE `leave_types` (
  `id`              BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `code`            VARCHAR(50)  NOT NULL,
  `name`            VARCHAR(150) NOT NULL,
  `is_paid`         TINYINT(1)   NOT NULL DEFAULT 1,
  `default_days`    DECIMAL(5,2) NOT NULL DEFAULT 0.00, -- credits per year (0 = unlimited/untracked)
  `requires_attachment` TINYINT(1) NOT NULL DEFAULT 0,
  `allow_negative_balance` TINYINT(1) NOT NULL DEFAULT 0,
  `max_consecutive_days` INT UNSIGNED NULL,
  `description`     VARCHAR(255) NULL,
  `is_active`       TINYINT(1)   NOT NULL DEFAULT 1,
  `created_at`      DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`      DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted_at`      DATETIME     NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_leave_types_code` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `leave_balances`;
CREATE TABLE `leave_balances` (
  `id`            BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `employee_id`   BIGINT UNSIGNED NOT NULL,
  `leave_type_id` BIGINT UNSIGNED NOT NULL,
  `year`          SMALLINT UNSIGNED NOT NULL,
  `entitled_days` DECIMAL(6,2) NOT NULL DEFAULT 0.00,
  `used_days`     DECIMAL(6,2) NOT NULL DEFAULT 0.00,
  `pending_days`  DECIMAL(6,2) NOT NULL DEFAULT 0.00,
  `created_at`    DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`    DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_lb` (`employee_id`, `leave_type_id`, `year`),
  CONSTRAINT `fk_lb_emp` FOREIGN KEY (`employee_id`) REFERENCES `employees` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_lb_type` FOREIGN KEY (`leave_type_id`) REFERENCES `leave_types` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `leave_requests`;
CREATE TABLE `leave_requests` (
  `id`             BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `employee_id`    BIGINT UNSIGNED NOT NULL,
  `leave_type_id`  BIGINT UNSIGNED NOT NULL,
  `start_date`     DATE         NOT NULL,
  `end_date`       DATE         NOT NULL,
  `days`           DECIMAL(5,2) NOT NULL DEFAULT 0.00,
  `start_half`     ENUM('FULL','FIRST_HALF','SECOND_HALF') NOT NULL DEFAULT 'FULL',
  `end_half`       ENUM('FULL','FIRST_HALF','SECOND_HALF') NOT NULL DEFAULT 'FULL',
  `reason`         VARCHAR(500) NOT NULL,
  `attachment_path` VARCHAR(255) NULL,
  `status`         ENUM('PENDING','APPROVED','REJECTED','CANCELLED') NOT NULL DEFAULT 'PENDING',
  `approver_id`    BIGINT UNSIGNED NULL,
  `approved_at`    DATETIME     NULL,
  `approver_remarks` VARCHAR(500) NULL,
  `created_at`     DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`     DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `cancelled_at`   DATETIME     NULL,
  `deleted_at`     DATETIME     NULL,
  PRIMARY KEY (`id`),
  KEY `idx_leave_emp` (`employee_id`, `status`),
  KEY `idx_leave_status` (`status`),
  KEY `idx_leave_dates` (`start_date`, `end_date`),
  KEY `idx_leave_type` (`leave_type_id`),
  CONSTRAINT `fk_leave_emp` FOREIGN KEY (`employee_id`) REFERENCES `employees` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_leave_type` FOREIGN KEY (`leave_type_id`) REFERENCES `leave_types` (`id`),
  CONSTRAINT `fk_leave_approver` FOREIGN KEY (`approver_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================================
-- SECTION 6: OVERTIME
-- ============================================================================

DROP TABLE IF EXISTS `overtime_requests`;
CREATE TABLE `overtime_requests` (
  `id`            BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `employee_id`   BIGINT UNSIGNED NOT NULL,
  `overtime_date` DATE         NOT NULL,
  `start_time`    TIME         NOT NULL,
  `end_time`      TIME         NOT NULL,
  `hours`         DECIMAL(5,2) NOT NULL DEFAULT 0.00,
  `ot_type`       ENUM('REGULAR','REST_DAY','HOLIDAY','NIGHT') NOT NULL DEFAULT 'REGULAR',
  `reason`        VARCHAR(500) NOT NULL,
  `status`        ENUM('PENDING','ACCEPTED','DECLINED','COMPLETED','APPROVED','REJECTED','CANCELLED') NOT NULL DEFAULT 'PENDING',
  `approver_id`   BIGINT UNSIGNED NULL,
  `created_by`    BIGINT UNSIGNED NULL,             -- admin who announced the assignment
  `approved_at`   DATETIME     NULL,
  `approver_remarks` VARCHAR(500) NULL,
  `decline_reason` VARCHAR(500) NULL,               -- why the assignee declined (required at decline time)
  `responded_at`  DATETIME     NULL,                -- when the assignee accepted or declined
  `responded_by`  BIGINT UNSIGNED NULL,             -- user who accepted or declined
  `applied_hours` DECIMAL(5,2) NOT NULL DEFAULT 0.00, -- hours actually paid after payroll
  `total_hours`   DECIMAL(5,2) NULL,                   -- actual total once the OT window has ended
  `created_at`    DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`    DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted_at`    DATETIME     NULL,
  PRIMARY KEY (`id`),
  KEY `idx_ot_emp` (`employee_id`, `status`),
  KEY `idx_ot_date` (`overtime_date`),
  KEY `idx_ot_status` (`status`),
  KEY `idx_ot_date_status` (`overtime_date`, `status`),
  CONSTRAINT `fk_ot_emp` FOREIGN KEY (`employee_id`) REFERENCES `employees` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_ot_approver` FOREIGN KEY (`approver_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_ot_creator` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_ot_responder` FOREIGN KEY (`responded_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Actual OT clock in/out is distinct from regular attendance.
DROP TABLE IF EXISTS `overtime_scans`;
CREATE TABLE `overtime_scans` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `overtime_request_id` BIGINT UNSIGNED NOT NULL,
  `employee_id` BIGINT UNSIGNED NOT NULL,
  `ot_time_in` DATETIME NOT NULL,
  `ot_time_out` DATETIME NULL,
  `payable_minutes` INT UNSIGNED NOT NULL DEFAULT 0,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_ot_scan_request` (`overtime_request_id`),
  KEY `idx_ot_scan_employee` (`employee_id`),
  CONSTRAINT `fk_ot_scan_req` FOREIGN KEY (`overtime_request_id`) REFERENCES `overtime_requests` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_ot_scan_emp` FOREIGN KEY (`employee_id`) REFERENCES `employees` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================================
-- SECTION 7: ALLOWANCES / DEDUCTIONS / LOANS
-- ============================================================================

DROP TABLE IF EXISTS `allowances`;
CREATE TABLE `allowances` (
  `id`             BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `code`           VARCHAR(50)  NOT NULL,
  `name`           VARCHAR(150) NOT NULL,
  -- The master amount is the template an assignment inherits; an assignment
  -- may override it (employee_allowances.amount = 0 means "use this one").
  `amount`         DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  -- Percentage masters read `amount` as a percentage of the monthly basic
  -- salary instead of a peso value (Phase 4).
  `is_percentage`  TINYINT(1)   NOT NULL DEFAULT 0,
  -- 1 = applies to every pay period inside the effective window; 0 = a
  -- one-time component, charged only in the period covering effective_from.
  `is_recurring`   TINYINT(1)   NOT NULL DEFAULT 1,
  -- PERIOD charges the amount in full every pay period (the historic
  -- behaviour); MONTHLY reads it as a monthly figure and splits it across the
  -- pay periods of the month, exactly like a loan instalment.
  `frequency`      ENUM('PERIOD','MONTHLY') NOT NULL DEFAULT 'PERIOD',
  `effective_from` DATE         NULL,
  `effective_to`   DATE         NULL,
  `category`       VARCHAR(50)  NULL,
  `is_taxable`     TINYINT(1)   NOT NULL DEFAULT 1,
  `is_active`      TINYINT(1)   NOT NULL DEFAULT 1,
  `created_by`     BIGINT UNSIGNED NULL,
  `updated_by`     BIGINT UNSIGNED NULL,
  `description`    VARCHAR(255) NULL,
  `created_at`     DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`     DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted_at`     DATETIME     NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_allowances_code` (`code`),
  CONSTRAINT `fk_allowances_creator` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_allowances_updater` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `deductions`;
CREATE TABLE `deductions` (
  `id`             BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `code`           VARCHAR(50)  NOT NULL,
  `name`           VARCHAR(150) NOT NULL,
  `amount`         DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  -- Read as a percentage of the monthly basic salary when 1, a peso value
  -- when 0 (Phase 4 - the column existed but the engine always charged pesos).
  `is_percentage`  TINYINT(1)   NOT NULL DEFAULT 0,
  `is_recurring`   TINYINT(1)   NOT NULL DEFAULT 1,
  `frequency`      ENUM('PERIOD','MONTHLY') NOT NULL DEFAULT 'PERIOD',
  `effective_from` DATE         NULL,
  `effective_to`   DATE         NULL,
  `category`       VARCHAR(50)  NULL,
  `is_active`      TINYINT(1)   NOT NULL DEFAULT 1,
  `created_by`     BIGINT UNSIGNED NULL,
  `updated_by`     BIGINT UNSIGNED NULL,
  `description`    VARCHAR(255) NULL,
  `created_at`     DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`     DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted_at`     DATETIME     NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_deductions_code` (`code`),
  CONSTRAINT `fk_deductions_creator` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_deductions_updater` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `employee_allowances`;
CREATE TABLE `employee_allowances` (
  `id`             BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `employee_id`    BIGINT UNSIGNED NOT NULL,
  `allowance_id`   BIGINT UNSIGNED NOT NULL,
  -- 0 means "use the master's amount"; anything else overrides it.
  `amount`         DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  -- Assignment-level override of the master's effective window. Either bound
  -- may stay NULL, in which case the master's own bound applies.
  `effective_from` DATE         NULL,
  `effective_to`   DATE         NULL,
  `reason`         VARCHAR(255) NULL,
  `notes`          VARCHAR(500) NULL,
  `is_active`      TINYINT(1)   NOT NULL DEFAULT 1,
  `created_by`     BIGINT UNSIGNED NULL,
  `updated_by`     BIGINT UNSIGNED NULL,
  `created_at`     DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`     DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  -- Un-assigning soft-deletes the row so the assignment history survives.
  `deleted_at`     DATETIME     NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_emp_allowance` (`employee_id`, `allowance_id`),
  KEY `idx_empallow_active` (`employee_id`, `is_active`, `deleted_at`),
  CONSTRAINT `fk_empallow_emp` FOREIGN KEY (`employee_id`) REFERENCES `employees` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_empallow_allow` FOREIGN KEY (`allowance_id`) REFERENCES `allowances` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_empallow_creator` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_empallow_updater` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `employee_deductions`;
CREATE TABLE `employee_deductions` (
  `id`             BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `employee_id`    BIGINT UNSIGNED NOT NULL,
  `deduction_id`   BIGINT UNSIGNED NOT NULL,
  `amount`         DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  `effective_from` DATE         NULL,
  `effective_to`   DATE         NULL,
  `reason`         VARCHAR(255) NULL,
  `notes`          VARCHAR(500) NULL,
  `is_active`      TINYINT(1)   NOT NULL DEFAULT 1,
  `created_by`     BIGINT UNSIGNED NULL,
  `updated_by`     BIGINT UNSIGNED NULL,
  `created_at`     DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`     DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted_at`     DATETIME     NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_emp_deduction` (`employee_id`, `deduction_id`),
  KEY `idx_empded_active` (`employee_id`, `is_active`, `deleted_at`),
  CONSTRAINT `fk_empded_emp` FOREIGN KEY (`employee_id`) REFERENCES `employees` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_empded_ded` FOREIGN KEY (`deduction_id`) REFERENCES `deductions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_empded_creator` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_empded_updater` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `loans`;
CREATE TABLE `loans` (
  `id`                BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `employee_id`       BIGINT UNSIGNED NOT NULL,
  `loan_type`         VARCHAR(100) NOT NULL DEFAULT 'SALARY_LOAN',
  `reference_no`      VARCHAR(50)  NULL,
  `principal_amount`  DECIMAL(12,2) NOT NULL,
  `monthly_deduction` DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  `term_months`       SMALLINT UNSIGNED NULL,
  `flat_interest_percent` DECIMAL(5,2) NOT NULL DEFAULT 0.00,
  `interest_amount`   DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  `balance`           DECIMAL(12,2) NOT NULL,
  `start_date`        DATE         NOT NULL,
  `end_date`          DATE         NULL,
  -- PENDING until an approver - and never the user who filed it - approves the
  -- loan: the payroll engine only ever deducts ACTIVE loans (Phase 3B).
  `status`            ENUM('PENDING','OFFERED','READY_FOR_RELEASE','ACTIVE','PAID','REJECTED','CANCELLED') NOT NULL DEFAULT 'PENDING',
  `rejection_reason`  VARCHAR(255) NULL,
  `notes`             VARCHAR(255) NULL,
  `created_by`        BIGINT UNSIGNED NULL,
  `approved_by`       BIGINT UNSIGNED NULL,
  `approved_at`       DATETIME     NULL,
  `terms_offered_at`  DATETIME     NULL,
  `terms_accepted_at` DATETIME     NULL,
  `released_at`       DATETIME     NULL,
  `created_at`        DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`        DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_loans_reference` (`reference_no`),
  KEY `idx_loans_emp` (`employee_id`, `status`),
  CONSTRAINT `fk_loans_emp` FOREIGN KEY (`employee_id`) REFERENCES `employees` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_loans_user` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_loans_approver` FOREIGN KEY (`approved_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `loan_payments`;
CREATE TABLE `loan_payments` (
  `id`         BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `loan_id`    BIGINT UNSIGNED NOT NULL,
  `payroll_id` BIGINT UNSIGNED NULL,
  `period_id`  BIGINT UNSIGNED NULL,
  `amount`     DECIMAL(12,2) NOT NULL,
  `payment_type` ENUM('PAYROLL','MANUAL','ADJUSTMENT') NOT NULL DEFAULT 'MANUAL',
  `paid_at`    DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `remarks`    VARCHAR(255) NULL,
  `created_by` BIGINT UNSIGNED NULL,
  PRIMARY KEY (`id`),
  KEY `idx_loanpay_loan` (`loan_id`),
  KEY `idx_loanpay_period` (`period_id`),
  -- One PAYROLL repayment per (payroll period, loan), enforced at the database
  -- so marking a period paid can never charge the same instalment twice even
  -- across racing requests (Phase 3A). MANUAL/ADJUSTMENT rows keep a NULL
  -- period_id, and MySQL treats NULLs as distinct in unique keys, so a loan
  -- with any number of manual repayments is unaffected.
  UNIQUE KEY `uq_loanpay_period_loan` (`period_id`, `loan_id`),
  CONSTRAINT `fk_loanpay_loan` FOREIGN KEY (`loan_id`) REFERENCES `loans` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_loanpay_user` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================================
-- SECTION 8: PAYROLL
-- ============================================================================

DROP TABLE IF EXISTS `payroll_periods`;
CREATE TABLE `payroll_periods` (
  `id`                BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `code`              VARCHAR(50)  NOT NULL,
  `name`              VARCHAR(150) NOT NULL,
  `start_date`        DATE         NOT NULL,
  `end_date`          DATE         NOT NULL,
  `pay_date`          DATE         NOT NULL,
  `status`            ENUM('DRAFT','CALCULATING','FOR_REVIEW','APPROVED','FINALIZED','PAID') NOT NULL DEFAULT 'DRAFT',
  `total_gross`       DECIMAL(14,2) NOT NULL DEFAULT 0.00,
  `total_deductions`  DECIMAL(14,2) NOT NULL DEFAULT 0.00,
  `total_net`         DECIMAL(14,2) NOT NULL DEFAULT 0.00,
  `calculated_at`     DATETIME     NULL,
  `approved_by`       BIGINT UNSIGNED NULL,
  `approved_at`       DATETIME     NULL,
  `finalized_at`      DATETIME     NULL,
  `paid_at`           DATETIME     NULL,
  `created_by`        BIGINT UNSIGNED NULL,
  `created_at`        DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`        DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted_at`        DATETIME     NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_payperiod_code` (`code`),
  KEY `idx_payperiod_dates` (`start_date`, `end_date`),
  KEY `idx_payperiod_status` (`status`),
  CONSTRAINT `fk_payperiod_approver` FOREIGN KEY (`approved_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_payperiod_creator` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- V7 managed adjustment workflow: HR proposes, Manager decides; no direct paid-period edits.
DROP TABLE IF EXISTS `payroll_adjustments`;
CREATE TABLE `payroll_adjustments` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  `employee_id` BIGINT UNSIGNED NOT NULL,
  `payroll_period_id` BIGINT UNSIGNED NOT NULL,
  `kind` ENUM('EARNING','DEDUCTION') NOT NULL,
  `amount` DECIMAL(12,2) NOT NULL,
  `reason` VARCHAR(500) NOT NULL,
  `status` ENUM('PENDING','APPROVED','REJECTED') NOT NULL DEFAULT 'PENDING',
  `request_key` CHAR(64) NOT NULL UNIQUE,
  `created_by` BIGINT UNSIGNED NOT NULL,
  `approved_by` BIGINT UNSIGNED NULL,
  `approved_at` DATETIME NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  KEY `idx_payadj_period_emp` (`payroll_period_id`,`employee_id`,`status`),
  CONSTRAINT `fk_pa_employee` FOREIGN KEY (`employee_id`) REFERENCES `employees`(`id`),
  CONSTRAINT `fk_pa_period` FOREIGN KEY (`payroll_period_id`) REFERENCES `payroll_periods`(`id`),
  CONSTRAINT `fk_pa_created` FOREIGN KEY (`created_by`) REFERENCES `users`(`id`),
  CONSTRAINT `fk_pa_approved` FOREIGN KEY (`approved_by`) REFERENCES `users`(`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `payroll`;
CREATE TABLE `payroll` (
  `id`                   BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `payroll_period_id`    BIGINT UNSIGNED NOT NULL,
  `employee_id`          BIGINT UNSIGNED NOT NULL,
  `basic_pay`            DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  `working_days`         DECIMAL(6,2)  NOT NULL DEFAULT 0.00,
  `present_days`         DECIMAL(6,2)  NOT NULL DEFAULT 0.00,
  `absent_days`          DECIMAL(6,2)  NOT NULL DEFAULT 0.00,
  `leave_days`           DECIMAL(6,2)  NOT NULL DEFAULT 0.00,
  `late_minutes`         INT UNSIGNED  NOT NULL DEFAULT 0,
  `undertime_minutes`    INT UNSIGNED  NOT NULL DEFAULT 0,
  `overtime_hours`       DECIMAL(6,2)  NOT NULL DEFAULT 0.00,
  `overtime_pay`         DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  `allowances_total`     DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  `bonus`                DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  `gross_pay`            DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  `late_deduction`       DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  `undertime_deduction`  DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  `absence_deduction`    DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  `leave_deduction`      DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  `other_deductions`     DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  `statutory_sss`        DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  `statutory_philhealth` DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  `statutory_pagibig`    DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  `withholding_tax`      DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  `statutory_total`      DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  `employer_contributions` DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  `total_deductions`     DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  `net_pay`              DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  `amount_paid`          DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  `payment_status`       ENUM('UNPAID','PARTIAL','PAID') NOT NULL DEFAULT 'UNPAID',
  `is_locked`            TINYINT(1)    NOT NULL DEFAULT 0,
  `calculation_snapshot` LONGTEXT     NULL,
  `calculated_at`        DATETIME      NULL,
  `created_at`           DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`           DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_payroll_period_emp` (`payroll_period_id`, `employee_id`),
  KEY `idx_payroll_emp` (`employee_id`),
  KEY `idx_payroll_paystatus` (`payment_status`),
  CONSTRAINT `fk_payroll_period` FOREIGN KEY (`payroll_period_id`) REFERENCES `payroll_periods` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_payroll_emp` FOREIGN KEY (`employee_id`) REFERENCES `employees` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `payroll_items`;
CREATE TABLE `payroll_items` (
  `id`         BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `payroll_id` BIGINT UNSIGNED NOT NULL,
  `item_type`  ENUM('EARNING','DEDUCTION') NOT NULL,
  `code`       VARCHAR(50)  NOT NULL,
  `name`       VARCHAR(150) NOT NULL,
  `amount`     DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  `remarks`    VARCHAR(255) NULL,
  PRIMARY KEY (`id`),
  KEY `idx_payitems_payroll` (`payroll_id`),
  CONSTRAINT `fk_payitems_payroll` FOREIGN KEY (`payroll_id`) REFERENCES `payroll` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================================
-- SECTION 8B: THIRTEENTH-MONTH PAY (module tables)
-- Mirrors database/migrations/20261009_fifteenth_13th_month.sql so a fresh
-- main.sql import includes the module without an extra migration step.
-- ============================================================================

DROP TABLE IF EXISTS `thirteenth_payments`;
DROP TABLE IF EXISTS `thirteenth_pays`;

CREATE TABLE `thirteenth_pays` (
  `id`              BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `employee_id`     BIGINT UNSIGNED NOT NULL,
  `calendar_year`   SMALLINT UNSIGNED NOT NULL,
  `gross_total`     DECIMAL(14,2) NOT NULL DEFAULT 0.00,
  `thirteenth_pay`  DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  `status`          ENUM('DRAFT','FOR_APPROVAL','APPROVED','PAID') NOT NULL DEFAULT 'DRAFT',
  `generated_by`    BIGINT UNSIGNED NULL,
  `generated_at`    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `submitted_by`    BIGINT UNSIGNED NULL,
  `submitted_at`    DATETIME NULL,
  `approved_by`     BIGINT UNSIGNED NULL,
  `approved_at`     DATETIME NULL,
  `released_at`     DATETIME NULL,
  `paid_at`         DATETIME NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_thirteenth_emp_year` (`employee_id`,`calendar_year`),
  KEY `idx_thirteenth_status` (`status`,`calendar_year`),
  KEY `idx_thirteenth_year` (`calendar_year`),
  CONSTRAINT `fk_thirteenth_emp` FOREIGN KEY (`employee_id`) REFERENCES `employees` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_thirteenth_gen` FOREIGN KEY (`generated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_thirteenth_sub` FOREIGN KEY (`submitted_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_thirteenth_app` FOREIGN KEY (`approved_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `thirteenth_payments` (
  `id`                BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `thirteenth_pay_id` BIGINT UNSIGNED NOT NULL,
  `amount`            DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  `payment_status`    ENUM('PENDING','PARTIAL','COMPLETED','FAILED') NOT NULL DEFAULT 'PENDING',
  `paid_at`           DATETIME NULL,
  `paid_by`           BIGINT UNSIGNED NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_ltpay_payment` (`thirteenth_pay_id`),
  KEY `idx_ltpay_status` (`payment_status`),
  CONSTRAINT `fk_ltpay` FOREIGN KEY (`thirteenth_pay_id`) REFERENCES `thirteenth_pays` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_ltpay_user` FOREIGN KEY (`paid_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================================
-- SECTION 8D: INDIVIDUAL PAYROLL PAYMENTS (disbursement ledger, Phase 5)
-- Mirrors database/migrations/20261014_payroll_payments.sql so a fresh
-- main.sql import includes the module without an extra migration step.
-- Regular salary disbursements only: loan repayments live in loan_payments
-- and 13th-month payments in thirteenth_payments.
-- ============================================================================

DROP TABLE IF EXISTS `payroll_payments`;

CREATE TABLE `payroll_payments` (
  `id`                 BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `payroll_id`         BIGINT UNSIGNED NOT NULL,
  `payroll_period_id`  BIGINT UNSIGNED NOT NULL,
  `employee_id`        BIGINT UNSIGNED NOT NULL,
  `reference_no`       VARCHAR(50) NOT NULL,
  `idempotency_key`    VARCHAR(64) NULL,
  `amount`             DECIMAL(12,2) NOT NULL,
  `payment_method`     ENUM('CASH','BANK_TRANSFER','GCASH','OTHER') NOT NULL DEFAULT 'CASH',
  `method_reference`   VARCHAR(150) NULL,
  `payment_status`     ENUM('PENDING','COMPLETED','FAILED','CANCELLED') NOT NULL DEFAULT 'COMPLETED',
  `payment_date`       DATE NULL,
  `paid_at`            DATETIME NULL,
  `recorded_by`        BIGINT UNSIGNED NULL,
  `cancelled_by`       BIGINT UNSIGNED NULL,
  `cancelled_at`       DATETIME NULL,
  `cancel_reason`      VARCHAR(255) NULL,
  `notes`              VARCHAR(500) NULL,
  `created_at`         DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`         DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_payrollpay_ref` (`reference_no`),
  UNIQUE KEY `uq_payrollpay_idem` (`idempotency_key`),
  KEY `idx_payrollpay_payroll` (`payroll_id`, `payment_status`),
  KEY `idx_payrollpay_period` (`payroll_period_id`, `payment_status`),
  KEY `idx_payrollpay_employee` (`employee_id`),
  KEY `idx_payrollpay_status` (`payment_status`),
  CONSTRAINT `fk_payrollpay_payroll` FOREIGN KEY (`payroll_id`) REFERENCES `payroll` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_payrollpay_period` FOREIGN KEY (`payroll_period_id`) REFERENCES `payroll_periods` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_payrollpay_emp` FOREIGN KEY (`employee_id`) REFERENCES `employees` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_payrollpay_recorder` FOREIGN KEY (`recorded_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_payrollpay_canceller` FOREIGN KEY (`cancelled_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================================
-- SECTION 9: AUDIT LOGS & SYSTEM SETTINGS
-- ============================================================================

DROP TABLE IF EXISTS `audit_logs`;
CREATE TABLE `audit_logs` (
  `id`          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id`     BIGINT UNSIGNED NULL,
  `username`    VARCHAR(100) NULL,
  `action`      VARCHAR(100) NOT NULL,
  `entity_type` VARCHAR(50)  NULL,
  `entity_id`   VARCHAR(50)  NULL,
  `description` VARCHAR(500) NULL,
  `old_value`   LONGTEXT     NULL,
  `new_value`   LONGTEXT     NULL,
  `ip_address`  VARCHAR(45)  NULL,
  `user_agent`  VARCHAR(255) NULL,
  `created_at`  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_audit_user` (`user_id`),
  KEY `idx_audit_action` (`action`),
  KEY `idx_audit_entity` (`entity_type`, `entity_id`),
  KEY `idx_audit_created` (`created_at`),
  CONSTRAINT `fk_audit_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `system_settings`;
CREATE TABLE `system_settings` (
  `id`           BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `setting_key`  VARCHAR(100) NOT NULL,
  `setting_value` LONGTEXT     NULL,
  `category`     VARCHAR(50)  NOT NULL DEFAULT 'GENERAL',
  `label`        VARCHAR(150) NULL,
  `value_type`   ENUM('STRING','INT','DECIMAL','BOOLEAN','JSON') NOT NULL DEFAULT 'STRING',
  `description`  VARCHAR(255) NULL,
  `is_public`    TINYINT(1)   NOT NULL DEFAULT 0,
  `updated_by`   BIGINT UNSIGNED NULL,
  `created_at`   DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`   DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_settings_key` (`setting_key`),
  KEY `idx_settings_cat` (`category`),
  CONSTRAINT `fk_settings_user` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================================
-- SECTION 8C: STATUTORY DEDUCTIONS (SSS, PhilHealth, Pag-IBIG) & BIR TAX
-- Mirrors database/migrations/20261011_statutory_deductions.sql so a fresh
-- import already carries the effective-dated schedules.
-- ============================================================================

DROP TABLE IF EXISTS `payroll_statutory`;
DROP TABLE IF EXISTS `bir_withholding_brackets`;
DROP TABLE IF EXISTS `bir_withholding_schedules`;
DROP TABLE IF EXISTS `statutory_schedules`;

CREATE TABLE `statutory_schedules` (
  `id`                   BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `code`                 VARCHAR(30)   NOT NULL,
  `name`                 VARCHAR(150)  NOT NULL,
  `agency`               VARCHAR(150)  NOT NULL,
  `scheme`               ENUM('PERCENTAGE','CREDIT_RATE') NOT NULL DEFAULT 'PERCENTAGE',
  `effective_from`       DATE          NOT NULL,
  `effective_to`         DATE          NULL,
  `salary_base`          ENUM('MONTHLY_BASIC','MONTHLY_BASIC_PLUS_ALLOWANCES') NOT NULL DEFAULT 'MONTHLY_BASIC',
  `salary_floor`         DECIMAL(12,2) NULL,
  `salary_ceiling`       DECIMAL(12,2) NULL,
  `employee_rate`        DECIMAL(9,4)  NULL,
  `employer_rate`        DECIMAL(9,4)  NULL,
  `low_salary_threshold` DECIMAL(12,2) NULL,
  `low_employee_rate`    DECIMAL(9,4)  NULL,
  `low_employer_rate`    DECIMAL(9,4)  NULL,
  `credit_step`          DECIMAL(12,2) NULL,
  `credit_min`           DECIMAL(12,2) NULL,
  `credit_max`           DECIMAL(12,2) NULL,
  `ec_amount`            DECIMAL(12,2) NULL,
  `ec_amount_high`       DECIMAL(12,2) NULL,
  `ec_threshold`         DECIMAL(12,2) NULL,
  `rounding`             ENUM('CENTAVO','PESO') NOT NULL DEFAULT 'CENTAVO',
  `deduction_code`       VARCHAR(30)   NOT NULL,
  `deduction_name`       VARCHAR(150)  NOT NULL,
  `source_name`          VARCHAR(255)  NULL,
  `source_url`           VARCHAR(500)  NULL,
  `notes`                VARCHAR(500)  NULL,
  `status`               ENUM('ACTIVE','INACTIVE') NOT NULL DEFAULT 'ACTIVE',
  `created_by`           BIGINT UNSIGNED NULL,
  `created_at`           DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`           DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_statutory_code_from` (`code`, `effective_from`),
  KEY `idx_statutory_lookup` (`code`, `status`, `effective_from`),
  CONSTRAINT `fk_statutory_user` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `bir_withholding_schedules` (
  `id`             BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `frequency`      ENUM('DAILY','WEEKLY','SEMI_MONTHLY','MONTHLY') NOT NULL,
  `effective_from` DATE          NOT NULL,
  `effective_to`   DATE          NULL,
  `source_name`    VARCHAR(255)  NULL,
  `source_url`     VARCHAR(500)  NULL,
  `notes`          VARCHAR(500)  NULL,
  `status`         ENUM('ACTIVE','INACTIVE') NOT NULL DEFAULT 'ACTIVE',
  `created_by`     BIGINT UNSIGNED NULL,
  `created_at`     DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`     DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_bir_frequency_from` (`frequency`, `effective_from`),
  KEY `idx_bir_lookup` (`frequency`, `status`, `effective_from`),
  CONSTRAINT `fk_bir_schedule_user` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `bir_withholding_brackets` (
  `id`                BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `schedule_id`       BIGINT UNSIGNED NOT NULL,
  `bracket_order`     INT UNSIGNED  NOT NULL,
  `compensation_from` DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  `compensation_to`   DECIMAL(12,2) NULL,
  `base_tax`          DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  `excess_rate`       DECIMAL(9,4)  NOT NULL DEFAULT 0.0000,
  `excess_over`       DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  `notes`             VARCHAR(255)  NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_bir_bracket_order` (`schedule_id`, `bracket_order`),
  CONSTRAINT `fk_bir_bracket_schedule` FOREIGN KEY (`schedule_id`) REFERENCES `bir_withholding_schedules` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `payroll_statutory` (
  `id`                      BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `payroll_id`              BIGINT UNSIGNED NOT NULL,
  `code`                    VARCHAR(30)   NOT NULL,
  `name`                    VARCHAR(150)  NOT NULL,
  `scheme`                  VARCHAR(30)   NULL,
  `schedule_id`             BIGINT UNSIGNED NULL,
  `schedule_effective_from` DATE          NULL,
  `schedule_source`         VARCHAR(500)  NULL,
  `salary_base`             VARCHAR(30)   NULL,
  `monthly_base`            DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  `credited_base`           DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  `employee_rate`           DECIMAL(9,4)  NULL,
  `employer_rate`           DECIMAL(9,4)  NULL,
  `monthly_employee_amount` DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  `monthly_employer_amount` DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  `monthly_extra_amount`    DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  `allocation_factor`       DECIMAL(8,4)  NOT NULL DEFAULT 1.0000,
  `employee_amount`         DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  `employer_amount`         DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  `extra_amount`            DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  `withholding_period`      VARCHAR(20)   NULL,
  `bracket_order`           INT UNSIGNED  NULL,
  `remarks`                 VARCHAR(255)  NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_payroll_statutory` (`payroll_id`, `code`),
  KEY `idx_payroll_statutory_code` (`code`),
  CONSTRAINT `fk_payroll_statutory_payroll` FOREIGN KEY (`payroll_id`) REFERENCES `payroll` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================================
-- SECTION 8D: STATUTORY REPORTS & REMITTANCE TRACKING
-- Mirrors database/migrations/20261015_statutory_remittances.sql so a fresh
-- import already carries the remittance register. Snapshot rows use
-- ON DELETE SET NULL: a purged payroll keeps the filed evidence intact.
-- ============================================================================

DROP TABLE IF EXISTS `statutory_remittance_items`;
DROP TABLE IF EXISTS `statutory_remittances`;

CREATE TABLE `statutory_remittances` (
  `id`                 BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `reference_no`       VARCHAR(50)   NOT NULL,
  `agency_code`        VARCHAR(30)   NOT NULL,
  `agency_name`        VARCHAR(150)  NOT NULL,
  `period_start`       DATE          NOT NULL,
  `period_end`         DATE          NOT NULL,
  `due_date`           DATE          NULL,
  `status`             ENUM('OPEN','SUBMITTED','PAID') NOT NULL DEFAULT 'OPEN',
  `employee_count`     INT UNSIGNED  NOT NULL DEFAULT 0,
  `total_employee`     DECIMAL(14,2) NOT NULL DEFAULT 0.00,
  `total_employer`     DECIMAL(14,2) NOT NULL DEFAULT 0.00,
  `total_extra`        DECIMAL(14,2) NOT NULL DEFAULT 0.00,
  `total_amount`       DECIMAL(14,2) NOT NULL DEFAULT 0.00,
  `filing_reference`   VARCHAR(150)  NULL,
  `submitted_by`       BIGINT UNSIGNED NULL,
  `submitted_at`       DATETIME      NULL,
  `paid_reference`     VARCHAR(150)  NULL,
  `paid_date`          DATE          NULL,
  `paid_by`            BIGINT UNSIGNED NULL,
  `paid_at`            DATETIME      NULL,
  `notes`              VARCHAR(500)  NULL,
  `created_by`         BIGINT UNSIGNED NULL,
  `created_at`         DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`         DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_remittance_reference` (`reference_no`),
  UNIQUE KEY `uq_remittance_window` (`agency_code`, `period_start`, `period_end`),
  KEY `idx_remittance_status` (`status`),
  KEY `idx_remittance_period` (`period_start`, `period_end`),
  CONSTRAINT `fk_remittance_creator` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_remittance_submitter` FOREIGN KEY (`submitted_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_remittance_payer` FOREIGN KEY (`paid_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `statutory_remittance_items` (
  `id`                      BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `remittance_id`           BIGINT UNSIGNED NOT NULL,
  `payroll_id`              BIGINT UNSIGNED NULL,
  `payroll_statutory_id`    BIGINT UNSIGNED NULL,
  `payroll_period_id`       BIGINT UNSIGNED NULL,
  `employee_id`             BIGINT UNSIGNED NULL,
  `employee_number`         VARCHAR(50)   NULL,
  `employee_name`           VARCHAR(150)  NULL,
  `code`                    VARCHAR(30)   NOT NULL,
  `line_name`               VARCHAR(150)  NOT NULL,
  `schedule_source`         VARCHAR(500)  NULL,
  `salary_base`             VARCHAR(30)   NULL,
  `credited_base`           DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  `employee_rate`           DECIMAL(9,4)  NULL,
  `employer_rate`           DECIMAL(9,4)  NULL,
  `monthly_employee_amount` DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  `monthly_employer_amount` DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  `employee_amount`         DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  `employer_amount`         DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  `extra_amount`            DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  `period_start`            DATE          NULL,
  `period_end`              DATE          NULL,
  PRIMARY KEY (`id`),
  KEY `idx_remittance_items_remittance` (`remittance_id`),
  KEY `idx_remittance_items_employee` (`employee_id`),
  CONSTRAINT `fk_remittance_item_remittance` FOREIGN KEY (`remittance_id`) REFERENCES `statutory_remittances` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_remittance_item_employee` FOREIGN KEY (`employee_id`) REFERENCES `employees` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_remittance_item_payroll` FOREIGN KEY (`payroll_id`) REFERENCES `payroll` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_remittance_item_statutory` FOREIGN KEY (`payroll_statutory_id`) REFERENCES `payroll_statutory` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_remittance_item_period` FOREIGN KEY (`payroll_period_id`) REFERENCES `payroll_periods` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

SET FOREIGN_KEY_CHECKS = 1;

-- ============================================================================
-- END OF SCHEMA
-- ============================================================================

-- ============================================================
-- INITIAL REFERENCE DATA AND DEMONSTRATION ACCOUNTS
-- All demo accounts use Password123@
-- ============================================================

-- ============================================================================
-- SEED DATA — Roles, Permissions, Settings, Reference Data
-- Demo user password for all accounts: Password123@
-- ============================================================================

USE `attendance_payroll`;

SET FOREIGN_KEY_CHECKS = 0;
TRUNCATE TABLE `roles`;
TRUNCATE TABLE `system_settings`;
TRUNCATE TABLE `leave_types`;
TRUNCATE TABLE `shifts`;
TRUNCATE TABLE `work_schedules`;
TRUNCATE TABLE `work_schedule_days`;
TRUNCATE TABLE `holidays`;
TRUNCATE TABLE `departments`;
TRUNCATE TABLE `positions`;
TRUNCATE TABLE `allowances`;
TRUNCATE TABLE `deductions`;
TRUNCATE TABLE `statutory_schedules`;
TRUNCATE TABLE `bir_withholding_schedules`;
TRUNCATE TABLE `bir_withholding_brackets`;
TRUNCATE TABLE `payroll_statutory`;
TRUNCATE TABLE `statutory_remittance_items`;
TRUNCATE TABLE `statutory_remittances`;
TRUNCATE TABLE `users`;
SET FOREIGN_KEY_CHECKS = 1;

-- ---------------------------------------------------------------------------
-- ROLES + PERMISSIONS
-- ---------------------------------------------------------------------------
INSERT INTO `roles` (`code`, `name`, `description`, `permissions`, `is_system`) VALUES
('ADMIN', 'Administrator', 'System security, role settings, payroll release and final control', '["*"]', 1),
('MANAGER', 'Manager', 'Attendance, leave, overtime and payroll approval', '["dashboard.view","employees.view","attendance.view","attendance.view_own","attendance.create","attendance.update","attendance.adjust","attendance.override","schedule.view","holiday.view","leave.view","leave.view_own","leave.create","leave.approve","overtime.view_own","overtime.create","payroll.view","payroll.view_own","payroll.period.view","payroll.approve","payroll.payslip.view","payroll.payslip.view_own","payroll.payments.view","report.attendance","report.leave","report.payroll"]', 1),
('STAFF', 'Employee / Staff', 'Personal attendance, leave, loans and payslips', '["dashboard.view","attendance.view_own","attendance.scan","leave.view_own","leave.create","leave.cancel_own","overtime.view_own","payroll.view_own","payroll.payslip.view_own","profile.view_own","profile.update_own","loans.create","loans.view_own"]', 1),
('HR_PAYROLL', 'HR / Payroll Staff', 'Employee management, payroll computation and statutory processing', '["dashboard.view","employees.view","employees.create","employees.update","employees.archive","employees.restore","attendance.view","attendance.view_own","attendance.create","attendance.update","attendance.adjust","schedule.view","holiday.view","leave.view","leave.view_own","leave.create","payroll.view","payroll.view_own","payroll.period.view","payroll.period.create","payroll.calculate","payroll.payslip.view","payroll.payslip.view_own","payroll.payments.view","loans.view","loans.create","loans.update","loans.payment","report.payroll","report.attendance","report.leave","report.statutory","remittance.view","remittance.manage"]', 1),
('KIOSK', 'Attendance Kiosk', 'Company-managed scanner device only', '["attendance.scan"]', 1);

-- ---------------------------------------------------------------------------
-- SYSTEM SETTINGS  (Phase 12/19 — every payroll rule is configurable)
-- ---------------------------------------------------------------------------
INSERT INTO `system_settings`
(`setting_key`, `setting_value`, `category`, `label`, `value_type`, `description`, `is_public`) VALUES
('company.name', 'Attendance & Payroll Corp.', 'COMPANY', 'Company Name', 'STRING', 'Printed on payslips', 1),
('company.address', '123 Main Street, Manila', 'COMPANY', 'Company Address', 'STRING', 'Printed on payslips', 0),
('company.phone', '+63 2 8123 4567', 'COMPANY', 'Company Phone', 'STRING', NULL, 0),
('company.email', 'hr@company.com', 'COMPANY', 'Company Email', 'STRING', NULL, 0),
('company.logo', 'assets/system-logo.png', 'COMPANY', 'System Logo', 'STRING', 'Uploaded through General Settings', 1),
('currency.symbol', 'PHP', 'COMPANY', 'Currency Symbol', 'STRING', 'Displayed next to amounts', 1),
('currency.position', 'PREFIX', 'COMPANY', 'Symbol Position', 'STRING', 'PREFIX or SUFFIX', 1),
('attendance.grace_period_minutes', '0', 'ATTENDANCE', 'Default Grace Period (minutes)', 'INT', 'Late tolerance before deduction applies', 0),
('attendance.auto_time_out', '0', 'ATTENDANCE', 'Auto Time-Out', 'BOOLEAN', 'Close attendance at scheduled end time', 0),
('attendance.prevent_duplicate_time_in', '1', 'ATTENDANCE', 'Prevent Duplicate Time-In', 'BOOLEAN', NULL, 0),
('attendance.prevent_duplicate_time_out', '1', 'ATTENDANCE', 'Prevent Duplicate Time-Out', 'BOOLEAN', NULL, 0),
('attendance.allow_scan_on_rest_day', '0', 'ATTENDANCE', 'Allow Scanning on Rest Day', 'BOOLEAN', 'Rest-day scans count as overtime', 0),
('attendance.scan_cutoff_hours', '12', 'ATTENDANCE', 'Scan Cut-off (hours)', 'INT', 'Scans older than this are rejected', 0),
('attendance.late_cutoff_minutes', '60', 'ATTENDANCE', 'Time-In Cut-off After Shift Start (minutes)', 'INT', 'Time-in is denied and the day marked ABSENT once this many minutes past the scheduled start', 0),
('attendance.auto_absence', '1', 'ATTENDANCE', 'Automatic Absence After Cut-off', 'BOOLEAN', 'The reconciler marks ABSENT once the cut-off passes with no valid time-in', 0),
('attendance.default_time_in', '08:00:00', 'ATTENDANCE', 'Default Time In', 'STRING', 'System-wide 8AM-style start: prefilled in manual attendance and new shifts', 0),
('attendance.default_time_out', '17:00:00', 'ATTENDANCE', 'Default Time Out', 'STRING', 'System-wide 5PM-style end: prefilled in manual attendance and new shifts', 0),
('attendance.overtime_auto_minutes', '0', 'ATTENDANCE', 'Legacy automatic OT (disabled by company policy)', 'INT', 'Overtime counts automatically once it reaches these minutes', 0),
('dashboard.recent_activities_per_page', '10', 'DASHBOARD', 'Recent activities per page', 'INT', 'Rows shown in the dashboard activity feed', 0),
('payroll.pay_frequency', 'SEMI_MONTHLY', 'PAYROLL', 'Pay Frequency', 'STRING', 'WEEKLY|BI_WEEKLY|SEMI_MONTHLY|MONTHLY', 0),
('payroll.annual_paid_day_divisor', '365', 'PAYROLL', 'Annual Paid-Day Divisor', 'DECIMAL', 'Only for fully monthly-paid salary including paid rest days and holidays; validate company agreement', 0),
('payroll.rest_days_paid', '0', 'PAYROLL', 'Unworked Rest Days Paid in Daily Rate', 'BOOLEAN', '0 means use unpaid-rest-day schedule factors, not 365. Confirm compensation arrangement.', 0),
('payroll.unpaid_rest_5day_divisor', '261', 'PAYROLL', '5-Day Unpaid-Rest-Day Paid-Day Factor', 'DECIMAL', 'NWPC reference; verify special non-working days entitlement.', 0),
('payroll.unpaid_rest_6day_divisor', '313', 'PAYROLL', '6-Day Unpaid-Rest-Day Paid-Day Factor', 'DECIMAL', 'NWPC reference; verify special non-working days entitlement.', 0),
('payroll.working_days_per_month', '22', 'PAYROLL', 'Working Days per Month', 'DECIMAL', 'Divisor for the daily rate', 0),
('payroll.working_hours_per_day', '8', 'PAYROLL', 'Working Hours per Day', 'DECIMAL', 'Divisor for the hourly rate', 0),
('payroll.pro_rate_monthly', '1', 'PAYROLL', 'Prorate Monthly on Absences', 'BOOLEAN', 'Deduct per working day instead of the full month', 0),
('payroll.overtime_enabled', '1', 'PAYROLL', 'Overtime Enabled', 'BOOLEAN', NULL, 0),
('payroll.overtime_multiplier', '1.25', 'PAYROLL', 'Overtime Multiplier', 'DECIMAL', 'Applied to the regular hourly rate', 0),
('payroll.overtime_min_hours', '0.50', 'PAYROLL', 'Minimum Overtime Hours', 'DECIMAL', 'Smallest overtime block that may be requested', 0),
('payroll.overtime_max_hours', '4.00', 'PAYROLL', 'Maximum Overtime Hours', 'DECIMAL', 'Upper bound that catches mistyped start and end times', 0),
('payroll.overtime_rest_day_multiplier', '1.30', 'PAYROLL', 'OT Rest Day Multiplier', 'DECIMAL', NULL, 0),
('payroll.overtime_holiday_multiplier', '2.00', 'PAYROLL', 'OT Holiday Multiplier', 'DECIMAL', NULL, 0),
('payroll.night_differential_multiplier', '1.10', 'PAYROLL', 'Night Differential Multiplier', 'DECIMAL', NULL, 0),
('payroll.night_shift_start', '22:00:00', 'PAYROLL', 'Night Shift Start', 'STRING', 'Used to detect night-shift hours', 0),
('payroll.night_shift_end', '06:00:00', 'PAYROLL', 'Night Shift End', 'STRING', NULL, 0),
('payroll.holiday_rate_multiplier', '1.00', 'PAYROLL', 'Holiday Pay Multiplier', 'DECIMAL', NULL, 0),
('payroll.late_deduction_enabled', '1', 'PAYROLL', 'Late Deduction Enabled', 'BOOLEAN', NULL, 0),
('payroll.late_deduction_type', 'PER_MINUTE', 'PAYROLL', 'Late Deduction Method', 'STRING', 'PER_MINUTE|PER_HOUR|PER_DAY|FIXED', 0),
('payroll.late_deduction_amount', '2.00', 'PAYROLL', 'Late Deduction Value', 'DECIMAL', 'Amount per minute/hour/day as configured', 0),
('payroll.undertime_deduction_enabled', '1', 'PAYROLL', 'Undertime Deduction Enabled', 'BOOLEAN', NULL, 0),
('payroll.undertime_deduction_type', 'PER_MINUTE', 'PAYROLL', 'Undertime Deduction Method', 'STRING', 'PER_HOUR|PER_MINUTE|FIXED', 0),
('payroll.undertime_deduction_amount', '60.00', 'PAYROLL', 'Undertime Deduction Value', 'DECIMAL', NULL, 0),
('payroll.absence_deduction_enabled', '1', 'PAYROLL', 'Absence Deduction Enabled', 'BOOLEAN', NULL, 0),
('payroll.unpaid_leave_deduction_enabled', '1', 'PAYROLL', 'Unpaid Leave Deduction Enabled', 'BOOLEAN', NULL, 0),
('payroll.loan_deduction_enabled', '1', 'PAYROLL', 'Loan Deduction Enabled', 'BOOLEAN', NULL, 0),
('payroll.round_to_two_decimals', '1', 'PAYROLL', 'Round to 2 Decimals', 'BOOLEAN', NULL, 0),
('statutory.enabled', '1', 'PAYROLL', 'Government Contributions Enabled', 'BOOLEAN', 'Master switch for SSS, PhilHealth, Pag-IBIG and withholding tax', 0),
('statutory.sss_enabled', '1', 'PAYROLL', 'SSS Contribution Enabled', 'BOOLEAN', 'Deduct the employee SSS share using the effective schedule', 0),
('statutory.philhealth_enabled', '1', 'PAYROLL', 'PhilHealth Contribution Enabled', 'BOOLEAN', 'Deduct the employee PhilHealth share using the effective schedule', 0),
('statutory.pagibig_enabled', '1', 'PAYROLL', 'Pag-IBIG Contribution Enabled', 'BOOLEAN', 'Deduct the employee Pag-IBIG share using the effective schedule', 0),
('statutory.tax_enabled', '1', 'PAYROLL', 'Withholding Tax Enabled', 'BOOLEAN', 'Withhold BIR tax using the table of the payroll frequency', 0),
('statutory.allocation_basis', 'EQUAL_SPLIT', 'PAYROLL', 'Monthly Allocation Basis', 'STRING', 'CALENDAR_DAYS prorates by days covered, EQUAL_SPLIT divides by pay periods per month', 0),
('statutory.periods_per_month', '2', 'PAYROLL', 'Pay Periods Per Month', 'INT', 'Used by the EQUAL_SPLIT allocation basis', 0),
('statutory.pagibig_salary_base', 'MONTHLY_BASIC_PLUS_ALLOWANCES', 'PAYROLL', 'Pag-IBIG Fund Salary Base', 'STRING', 'MONTHLY_BASIC or MONTHLY_BASIC_PLUS_ALLOWANCES', 0),
('statutory.tax_exclude_non_taxable_allowances', '1', 'PAYROLL', 'Exclude Non-Taxable Allowances', 'BOOLEAN', 'Allowances flagged non-taxable are removed from the taxable compensation', 0),
('statutory.tax_subtract_contributions', '1', 'PAYROLL', 'Deduct Contributions Before Tax', 'BOOLEAN', 'The employee SSS, PhilHealth and Pag-IBIG shares are deducted from taxable compensation', 0),
('security.max_login_attempts', '5', 'SECURITY', 'Max Login Attempts', 'INT', NULL, 0),
('security.lockout_minutes', '15', 'SECURITY', 'Lockout Duration (minutes)', 'INT', NULL, 0),
('security.rate_limit_per_minute', '120', 'SECURITY', 'API Rate Limit (req/min)', 'INT', NULL, 0),
('security.password_min_length', '8', 'SECURITY', 'Minimum Password Length', 'INT', NULL, 0);

-- ---------------------------------------------------------------------------
-- DEPARTMENTS & POSITIONS
-- ---------------------------------------------------------------------------
INSERT INTO `departments` (`code`, `name`, `description`, `base_salary`) VALUES
('HR',   'Human Resources', 'Employee relations and staffing', 30000.00),
('IT',   'Information Technology', 'Systems and support', 35000.00),
('FIN',  'Finance', 'Accounting and payroll', 32000.00),
('OPS',  'Operations', 'Day-to-day operations', 28000.00),
('SALES','Sales', 'Client acquisition', 30000.00);

INSERT INTO `positions` (`code`, `name`, `department_id`, `job_level`) VALUES
('MGR-HR',    'HR Manager',           1, 'Manager'),
('HR-ADMIN',  'HR Administrator',     1, 'Staff'),
('MGR-IT',    'IT Manager',           2, 'Manager'),
('DEV',       'Software Developer',   2, 'Staff'),
('PAYROLL',   'Payroll Officer',      3, 'Staff'),
('ACCT',      'Accountant',           3, 'Staff'),
('SUP-OPS',   'Operations Supervisor',4, 'Supervisor'),
('STAFF-OPS', 'Operations Staff',     4, 'Staff'),
('SALES-REP', 'Sales Representative',  5, 'Staff');

-- Cashier is the only initially selectable department and position.
-- Existing reference records are preserved but inactive for FK integrity.
UPDATE `departments` SET `is_active` = 0;
UPDATE `positions` SET `is_active` = 0;
INSERT INTO `departments` (`code`, `name`, `description`, `base_salary`) VALUES
('CASH', 'Cashier', 'Retail cashier operations', 20000.00);
INSERT INTO `positions` (`code`, `name`, `department_id`, `job_level`) VALUES
('CASHIER', 'Cashier', (SELECT `id` FROM `departments` WHERE `code`='CASH'), 'Staff');

-- ---------------------------------------------------------------------------
-- SHIFTS & WORK SCHEDULES
-- ---------------------------------------------------------------------------
INSERT INTO `shifts` (`code`, `name`, `start_time`, `end_time`, `break_start`, `break_end`, `is_overnight`, `grace_period_minutes`, `required_hours`) VALUES
('DAY',   'Day Shift',      '08:00:00', '17:00:00', '12:00:00', '13:00:00', 0, 0, 8.00),
('SEMI',  'Semi Day Shift', '08:00:00', '12:00:00', NULL,        NULL,        0, 0, 4.00),
('NIGHT', 'Night Shift',    '22:00:00', '06:00:00', '02:00:00', '02:30:00', 1, 20, 7.50),
('FLEX',  'Flexible Shift', '09:00:00', '18:00:00', '13:00:00', '14:00:00', 0, 30, 8.00);

INSERT INTO `work_schedules` (`code`, `name`, `schedule_type`, `description`, `is_default`) VALUES
('STD-MF',   'Standard Mon-Fri',     'REGULAR',  'Monday to Friday, 08:00-17:00', 1),
('STD-MFS',  'Standard Mon-Sat',     'REGULAR',  'Monday to Saturday, 08:00-17:00', 0),
('NIGHT-ROT','Night Shift Rotating', 'ROTATING', 'Mon-Wed-Fri night duty', 0),
('FLEX-5',   'Flexible 5-Day',       'FLEXIBLE', '09:00-18:00 with 30 min grace', 0);

-- 0 = Sunday ... 6 = Saturday
INSERT INTO `work_schedule_days` (`work_schedule_id`, `day_of_week`, `shift_id`, `is_rest_day`) VALUES
(1, 1, 1, 0), (1, 2, 1, 0), (1, 3, 1, 0), (1, 4, 1, 0), (1, 5, 1, 0), (1, 0, NULL, 1), (1, 6, NULL, 1),
(2, 1, 1, 0), (2, 2, 1, 0), (2, 3, 1, 0), (2, 4, 1, 0), (2, 5, 1, 0), (2, 6, 1, 0), (2, 0, NULL, 1),
(3, 1, 3, 0), (3, 3, 3, 0), (3, 5, 3, 0), (3, 0, NULL, 1), (3, 2, NULL, 1), (3, 4, NULL, 1), (3, 6, NULL, 1),
(4, 1, 4, 0), (4, 2, 4, 0), (4, 3, 4, 0), (4, 4, 4, 0), (4, 5, 4, 0), (4, 0, NULL, 1), (4, 6, NULL, 1);

-- ---------------------------------------------------------------------------
-- LEAVE TYPES
-- ---------------------------------------------------------------------------
INSERT INTO `leave_types` (`code`, `name`, `is_paid`, `default_days`, `requires_attachment`, `allow_negative_balance`, `description`) VALUES
('VL',    'Vacation Leave',  1, 15.00, 0, 0, 'Paid vacation credits per year'),
('SL',    'Sick Leave',      1, 15.00, 1, 0, 'Requires a medical certificate'),
('EL',    'Emergency Leave', 1,  5.00, 0, 0, 'For urgent personal matters'),
('ML',    'Maternity Leave', 1, 60.00, 1, 0, 'For female employees'),
('PL',    'Paternity Leave', 1, 10.00, 1, 0, 'For male employees'),
('UNPAID','Unpaid Leave',    0,  0.00, 0, 1, 'Deducted from the monthly basic salary'),
('OTHER', 'Other Leave',     0,  0.00, 0, 1, 'Configurable other leave');

-- ---------------------------------------------------------------------------
-- ALLOWANCES & DEDUCTIONS (defaults assignable per employee)
-- ---------------------------------------------------------------------------
INSERT INTO `allowances` (`code`, `name`, `amount`, `is_taxable`, `description`) VALUES
('TRANSPORT',  'Transportation Allowance', 1500.00, 0, 'Monthly transport subsidy'),
('MEAL',       'Meal Allowance',           800.00, 0, 'Daily meal subsidy'),
('HAZARD',     'Hazard Pay',               500.00, 1, 'For hazardous duties'),
('LEADERSHIP', 'Leadership Allowance',    2000.00, 1, 'Supervisory allowance');

-- A monthly-figure template, charged once per month rather than once per pay
-- period: `frequency` is the only thing that has to be stated for the engine
-- to split 2,000.00 into 1,000.00 per half-month payroll (Phase 4). It is a
-- template only - nobody is assigned to it until an assignment is created.
INSERT INTO `allowances`
  (`code`, `name`, `amount`, `is_percentage`, `is_recurring`, `frequency`, `category`, `is_taxable`, `is_active`, `description`) VALUES
('RICE', 'Rice Subsidy', 2000.00, 0, 1, 'MONTHLY', 'SUBSISTENCE', 0, 1, 'Monthly rice subsidy, split across the pay periods of the month');

INSERT INTO `deductions` (`code`, `name`, `amount`, `is_percentage`, `description`) VALUES
('SSS',        'SSS Contribution', 1125.00, 0, 'Statutory social security'),
('PHILHEALTH', 'PhilHealth',          50.00, 0, 'Health insurance'),
('PAGIBIG',    'Pag-IBIG Fund',       100.00, 0, 'Housing fund'),
('TAX',        'Withholding Tax',      0.00, 1, 'Percentage of gross pay'),
('UNIFORM',    'Uniform Deduction',   250.00, 0, 'Company uniform');

-- ---------------------------------------------------------------------------
-- STATUTORY SCHEDULES (effective-dated, with the issuing document recorded)
-- The fixed SSS / PHILHEALTH / PAGIBIG / TAX deductions above are switched off
-- below: the payroll engine computes these amounts from the schedules instead,
-- so the same employee is never charged twice.
-- ---------------------------------------------------------------------------
INSERT INTO `statutory_schedules`
(`code`, `name`, `agency`, `scheme`, `effective_from`, `effective_to`, `salary_base`,
 `salary_floor`, `salary_ceiling`, `employee_rate`, `employer_rate`,
 `low_salary_threshold`, `low_employee_rate`, `low_employer_rate`,
 `credit_step`, `credit_min`, `credit_max`, `ec_amount`, `ec_amount_high`, `ec_threshold`,
 `rounding`, `deduction_code`, `deduction_name`, `source_name`, `source_url`, `notes`) VALUES
('SSS', 'SSS Contribution', 'Social Security System', 'CREDIT_RATE', '2025-01-01', NULL, 'MONTHLY_BASIC',
 NULL, NULL, '5.0000', '10.0000',
 NULL, NULL, NULL,
 '500.00', '5000.00', '35000.00', '10.00', '30.00', '14500.00',
 'CENTAVO', 'SSS_EE', 'SSS Contribution (Employee Share)',
 'SSS Circular No. 2024-006, effective 1 January 2025 (SSC Resolution No. 560-s.2024, RA 11199)',
 'https://www.sss.gov.ph/wp-content/uploads/2024/12/CI-2024-006-Publication.pdf',
 '15% of the Monthly Salary Credit - employer 10%, employee 5%. MSC P5,000.00 to P35,000.00 in P500.00 steps. Employer EC P10.00 at MSC 14,500.00 or less and P30.00 above.'),
('PHILHEALTH', 'PhilHealth Premium', 'Philippine Health Insurance Corporation', 'PERCENTAGE', '2025-01-01', NULL, 'MONTHLY_BASIC',
 '10000.00', '100000.00', '2.5000', '2.5000',
 NULL, NULL, NULL,
 NULL, NULL, NULL, NULL, NULL, NULL,
 'CENTAVO', 'PHILHEALTH_EE', 'PhilHealth Premium (Employee Share)',
 'PhilHealth Advisory No. 2025-0002 dated 8 January 2025 (PhilHealth Circular No. 2020-0005, Revision 1)',
 'https://www.philhealth.gov.ph/advisories/2025/PA2025-0002.pdf',
 '5.0% of the Monthly Basic Salary shared equally - 2.5% each. Income floor P10,000.00, income ceiling P100,000.00.'),
('PAGIBIG', 'Pag-IBIG Fund Savings', 'Home Development Mutual Fund', 'PERCENTAGE', '2024-02-01', NULL, 'MONTHLY_BASIC_PLUS_ALLOWANCES',
 NULL, '10000.00', '2.0000', '2.0000',
 '1500.00', '1.0000', '2.0000',
 NULL, NULL, NULL, NULL, NULL, NULL,
 'CENTAVO', 'PAGIBIG_EE', 'Pag-IBIG Fund (Employee Share)',
 'Pag-IBIG Fund (HDMF) Circular No. 460 dated 15 January 2024, effective February 2024',
 'https://mpm.ph/wp-content/uploads/2024/01/HDMF-Circular-No.-460-Pag-ibig-HDMF-Table-2024.pdf',
 'Employer and employee 2% each of the Fund Salary, employee 1% when the Fund Salary is P1,500.00 or less. Maximum Fund Salary P10,000.00 (increased from P5,000.00).');

INSERT INTO `bir_withholding_schedules`
(`frequency`, `effective_from`, `effective_to`, `source_name`, `source_url`, `notes`) VALUES
('DAILY', '2023-01-01', NULL, 'BIR Revenue Regulations No. 11-2018, Annex E - Revised Withholding Tax Table (effective January 1, 2023 and onwards)',
 'https://bir-cdn.bir.gov.ph/local/pdf/Annex%20E%20RR%2011-2018.pdf', 'Daily table'),
('WEEKLY', '2023-01-01', NULL, 'BIR Revenue Regulations No. 11-2018, Annex E - Revised Withholding Tax Table (effective January 1, 2023 and onwards)',
 'https://bir-cdn.bir.gov.ph/local/pdf/Annex%20E%20RR%2011-2018.pdf', 'Weekly table'),
('SEMI_MONTHLY', '2023-01-01', NULL, 'BIR Revenue Regulations No. 11-2018, Annex E - Revised Withholding Tax Table (effective January 1, 2023 and onwards)',
 'https://bir-cdn.bir.gov.ph/local/pdf/Annex%20E%20RR%2011-2018.pdf', 'Semi-monthly table - used by the default twice-monthly payroll'),
('MONTHLY', '2023-01-01', NULL, 'BIR Revenue Regulations No. 11-2018, Annex E - Revised Withholding Tax Table (effective January 1, 2023 and onwards)',
 'https://bir-cdn.bir.gov.ph/local/pdf/Annex%20E%20RR%2011-2018.pdf', 'Monthly table');

INSERT INTO `bir_withholding_brackets`
(`schedule_id`, `bracket_order`, `compensation_from`, `compensation_to`, `base_tax`, `excess_rate`, `excess_over`) VALUES
((SELECT `id` FROM `bir_withholding_schedules` WHERE `frequency` = 'DAILY' AND `effective_from` = '2023-01-01'), 1, '0.00', '685.00', '0.00', '0.0000', '0.00'),
((SELECT `id` FROM `bir_withholding_schedules` WHERE `frequency` = 'DAILY' AND `effective_from` = '2023-01-01'), 2, '685.01', '1095.00', '0.00', '15.0000', '685.00'),
((SELECT `id` FROM `bir_withholding_schedules` WHERE `frequency` = 'DAILY' AND `effective_from` = '2023-01-01'), 3, '1096.00', '2191.00', '61.65', '20.0000', '1096.00'),
((SELECT `id` FROM `bir_withholding_schedules` WHERE `frequency` = 'DAILY' AND `effective_from` = '2023-01-01'), 4, '2192.00', '5478.00', '280.85', '25.0000', '2192.00'),
((SELECT `id` FROM `bir_withholding_schedules` WHERE `frequency` = 'DAILY' AND `effective_from` = '2023-01-01'), 5, '5479.00', '21917.00', '1102.60', '30.0000', '5479.00'),
((SELECT `id` FROM `bir_withholding_schedules` WHERE `frequency` = 'DAILY' AND `effective_from` = '2023-01-01'), 6, '21918.00', NULL, '6034.00', '35.0000', '21918.00'),
((SELECT `id` FROM `bir_withholding_schedules` WHERE `frequency` = 'WEEKLY' AND `effective_from` = '2023-01-01'), 1, '0.00', '4808.00', '0.00', '0.0000', '0.00'),
((SELECT `id` FROM `bir_withholding_schedules` WHERE `frequency` = 'WEEKLY' AND `effective_from` = '2023-01-01'), 2, '4808.01', '7691.00', '0.00', '15.0000', '4808.00'),
((SELECT `id` FROM `bir_withholding_schedules` WHERE `frequency` = 'WEEKLY' AND `effective_from` = '2023-01-01'), 3, '7692.00', '15384.00', '432.60', '20.0000', '7692.00'),
((SELECT `id` FROM `bir_withholding_schedules` WHERE `frequency` = 'WEEKLY' AND `effective_from` = '2023-01-01'), 4, '15385.00', '38461.00', '1971.20', '25.0000', '15385.00'),
((SELECT `id` FROM `bir_withholding_schedules` WHERE `frequency` = 'WEEKLY' AND `effective_from` = '2023-01-01'), 5, '38462.00', '153845.00', '7740.45', '30.0000', '38462.00'),
((SELECT `id` FROM `bir_withholding_schedules` WHERE `frequency` = 'WEEKLY' AND `effective_from` = '2023-01-01'), 6, '153846.00', NULL, '42355.65', '35.0000', '153846.00'),
((SELECT `id` FROM `bir_withholding_schedules` WHERE `frequency` = 'SEMI_MONTHLY' AND `effective_from` = '2023-01-01'), 1, '0.00', '10417.00', '0.00', '0.0000', '0.00'),
((SELECT `id` FROM `bir_withholding_schedules` WHERE `frequency` = 'SEMI_MONTHLY' AND `effective_from` = '2023-01-01'), 2, '10417.01', '16666.00', '0.00', '15.0000', '10417.00'),
((SELECT `id` FROM `bir_withholding_schedules` WHERE `frequency` = 'SEMI_MONTHLY' AND `effective_from` = '2023-01-01'), 3, '16667.00', '33332.00', '937.50', '20.0000', '16667.00'),
((SELECT `id` FROM `bir_withholding_schedules` WHERE `frequency` = 'SEMI_MONTHLY' AND `effective_from` = '2023-01-01'), 4, '33333.00', '83332.00', '4270.70', '25.0000', '33333.00'),
((SELECT `id` FROM `bir_withholding_schedules` WHERE `frequency` = 'SEMI_MONTHLY' AND `effective_from` = '2023-01-01'), 5, '83333.00', '333332.00', '16770.70', '30.0000', '83333.00'),
((SELECT `id` FROM `bir_withholding_schedules` WHERE `frequency` = 'SEMI_MONTHLY' AND `effective_from` = '2023-01-01'), 6, '333333.00', NULL, '91770.70', '35.0000', '333333.00'),
((SELECT `id` FROM `bir_withholding_schedules` WHERE `frequency` = 'MONTHLY' AND `effective_from` = '2023-01-01'), 1, '0.00', '20833.00', '0.00', '0.0000', '0.00'),
((SELECT `id` FROM `bir_withholding_schedules` WHERE `frequency` = 'MONTHLY' AND `effective_from` = '2023-01-01'), 2, '20833.01', '33332.00', '0.00', '15.0000', '20833.00'),
((SELECT `id` FROM `bir_withholding_schedules` WHERE `frequency` = 'MONTHLY' AND `effective_from` = '2023-01-01'), 3, '33333.00', '66666.00', '1875.00', '20.0000', '33333.00'),
((SELECT `id` FROM `bir_withholding_schedules` WHERE `frequency` = 'MONTHLY' AND `effective_from` = '2023-01-01'), 4, '66667.00', '166666.00', '8541.80', '25.0000', '66667.00'),
((SELECT `id` FROM `bir_withholding_schedules` WHERE `frequency` = 'MONTHLY' AND `effective_from` = '2023-01-01'), 5, '166667.00', '666666.00', '33541.80', '30.0000', '166667.00'),
((SELECT `id` FROM `bir_withholding_schedules` WHERE `frequency` = 'MONTHLY' AND `effective_from` = '2023-01-01'), 6, '666667.00', NULL, '183541.80', '35.0000', '666667.00');

UPDATE `deductions`
   SET `is_active` = 0,
       `description` = CONCAT(COALESCE(`description`, ''), ' [Deactivated - computed automatically as a statutory deduction]')
 WHERE `code` IN ('SSS', 'PHILHEALTH', 'PAGIBIG', 'TAX');

-- ---------------------------------------------------------------------------
-- HOLIDAYS (editable in Settings)
-- ---------------------------------------------------------------------------
INSERT INTO `holidays` (`name`, `holiday_date`, `holiday_type`, `is_paid`, `is_recurring`, `status`, `remarks`) VALUES
('New Year''s Day',       '2026-01-01', 'REGULAR', 1, 1, 'ACTIVE', 'Regular holiday'),
('EDSA People Power Day', '2026-02-25', 'SPECIAL', 1, 1, 'ACTIVE', 'Special non-working day'),
('Sampaguita Day',        '2026-03-30', 'SPECIAL', 1, 1, 'ACTIVE', 'Special non-working day'),
('Maundy Thursday',       '2026-04-02', 'SPECIAL', 1, 0, 'ACTIVE', 'Movable holiday'),
('Good Friday',           '2026-04-03', 'REGULAR', 1, 0, 'ACTIVE', 'Regular holiday'),
('Araw ng Kagitingan',    '2026-04-09', 'REGULAR', 1, 0, 'ACTIVE', 'Regular holiday'),
('Labor Day',             '2026-05-01', 'REGULAR', 1, 1, 'ACTIVE', 'Regular holiday'),
('Independence Day',      '2026-06-12', 'REGULAR', 1, 1, 'ACTIVE', 'Regular holiday'),
('National Heroes Day',   '2026-08-31', 'REGULAR', 1, 1, 'ACTIVE', 'Regular holiday'),
('Bonifacio Day',         '2026-11-30', 'REGULAR', 1, 1, 'ACTIVE', 'Regular holiday'),
('Christmas Day',         '2026-12-25', 'REGULAR', 1, 1, 'ACTIVE', 'Regular holiday'),
('Rizal Day',             '2026-12-30', 'REGULAR', 1, 1, 'ACTIVE', 'Regular holiday');

-- ---------------------------------------------------------------------------
-- USERS  (demo password for all accounts: Password123@)
-- ---------------------------------------------------------------------------
INSERT INTO `users` (`username`, `email`, `password_hash`, `full_name`, `role_id`, `status`) VALUES
('admin',   'admin@company.com',   '$2y$10$bTbZ14x7E9Z8AplpFWcc8OOcn6Rf3y2IbJJBLJ.F4p/86oM8YxVBS', 'System Administrator', 1, 'ACTIVE'),
('manager', 'manager@company.com', '$2y$10$bTbZ14x7E9Z8AplpFWcc8OOcn6Rf3y2IbJJBLJ.F4p/86oM8YxVBS', 'Operations Manager',   2, 'ACTIVE'),
('staff',   'staff@company.com',   '$2y$10$bTbZ14x7E9Z8AplpFWcc8OOcn6Rf3y2IbJJBLJ.F4p/86oM8YxVBS', 'Demo Staff Member',    3, 'ACTIVE');

-- Manager and Staff are linked to real employee profiles so both appear in
-- Employee Management and can use employee-scoped workflows. Admin remains a
-- system-only account and is intentionally not linked to an employee.
INSERT INTO `employees`
(`employee_number`, `first_name`, `last_name`, `gender`, `email`, `department_id`,
 `position_id`, `employment_type`, `date_hired`, `salary_type`, `basic_salary`,
 `work_schedule_id`, `status`, `created_by`, `notes`) VALUES
('EMP-000001', 'Demo', 'Staff Member', 'OTHER', 'staff.member@company.com', 4,
 8, 'FULL_TIME', '2026-01-05', 'MONTHLY', 25000.00, 1, 'ACTIVE', 1,
 'Linked demo profile for the Staff account');

SET @demo_employee_id = LAST_INSERT_ID();
UPDATE `users` SET `employee_id` = @demo_employee_id WHERE `username` = 'staff';
INSERT INTO `salary_history`
(`employee_id`, `salary_type`, `basic_salary`, `effective_from`, `reason`, `changed_by`) VALUES
(@demo_employee_id, 'MONTHLY', 25000.00, '2026-01-05', 'Initial salary', 1);

INSERT INTO `employees`
(`employee_number`, `first_name`, `last_name`, `gender`, `email`, `department_id`,
 `position_id`, `employment_type`, `date_hired`, `salary_type`, `basic_salary`,
 `work_schedule_id`, `status`, `created_by`, `notes`) VALUES
('EMP-000002', 'Operations', 'Manager', 'OTHER', 'operations.manager@company.com', 4,
 7, 'FULL_TIME', '2025-06-02', 'MONTHLY', 45000.00, 1, 'ACTIVE', 1,
 'Linked employee profile for the Manager account');

SET @manager_employee_id = LAST_INSERT_ID();
UPDATE `users` SET `employee_id` = @manager_employee_id WHERE `username` = 'manager';
UPDATE `users` SET `employee_id` = NULL WHERE `username` = 'admin';
INSERT INTO `salary_history`
(`employee_id`, `salary_type`, `basic_salary`, `effective_from`, `reason`, `changed_by`) VALUES
(@manager_employee_id, 'MONTHLY', 45000.00, '2025-06-02', 'Initial salary', 1);

-- FIVE FICTIONAL SAMPLE EMPLOYEES (development/demo data only)
-- Demo-only shared login password: Password123@; change immediately for actual use.
INSERT INTO `employees` (`employee_number`,`first_name`,`last_name`,`gender`,`email`,`department_id`,`position_id`,`employment_type`,`date_hired`,`salary_type`,`basic_salary`,`work_schedule_id`,`status`,`created_by`,`notes`)
VALUES ('EMP-000003','Maria','Santos','FEMALE','cashier1@example.test',(SELECT id FROM departments WHERE code='CASH'),(SELECT id FROM positions WHERE code='CASHIER'),'FULL_TIME','2026-01-05','MONTHLY',18000.00,1,'ACTIVE',1,'FICTIONAL SAMPLE — training/demo use only');
SET @sample_employee_id = LAST_INSERT_ID();
INSERT INTO `users` (`username`,`email`,`password_hash`,`full_name`,`role_id`,`employee_id`,`status`,`must_change_password`)
VALUES ('cashier1','cashier1@example.test','$2y$10$bTbZ14x7E9Z8AplpFWcc8OOcn6Rf3y2IbJJBLJ.F4p/86oM8YxVBS','Maria Santos',(SELECT id FROM roles WHERE code='STAFF'),@sample_employee_id,'ACTIVE',1);
INSERT INTO `salary_history` (`employee_id`,`salary_type`,`basic_salary`,`effective_from`,`reason`,`changed_by`)
VALUES (@sample_employee_id,'MONTHLY',18000.00,'2026-01-05','Initial sample salary',1);
INSERT INTO `employees` (`employee_number`,`first_name`,`last_name`,`gender`,`email`,`department_id`,`position_id`,`employment_type`,`date_hired`,`salary_type`,`basic_salary`,`work_schedule_id`,`status`,`created_by`,`notes`)
VALUES ('EMP-000004','Jose','Reyes','MALE','cashier2@example.test',(SELECT id FROM departments WHERE code='CASH'),(SELECT id FROM positions WHERE code='CASHIER'),'FULL_TIME','2026-01-05','MONTHLY',19500.00,2,'ACTIVE',1,'FICTIONAL SAMPLE — training/demo use only');
SET @sample_employee_id = LAST_INSERT_ID();
INSERT INTO `users` (`username`,`email`,`password_hash`,`full_name`,`role_id`,`employee_id`,`status`,`must_change_password`)
VALUES ('cashier2','cashier2@example.test','$2y$10$bTbZ14x7E9Z8AplpFWcc8OOcn6Rf3y2IbJJBLJ.F4p/86oM8YxVBS','Jose Reyes',(SELECT id FROM roles WHERE code='STAFF'),@sample_employee_id,'ACTIVE',1);
INSERT INTO `salary_history` (`employee_id`,`salary_type`,`basic_salary`,`effective_from`,`reason`,`changed_by`)
VALUES (@sample_employee_id,'MONTHLY',19500.00,'2026-01-05','Initial sample salary',1);
INSERT INTO `employees` (`employee_number`,`first_name`,`last_name`,`gender`,`email`,`department_id`,`position_id`,`employment_type`,`date_hired`,`salary_type`,`basic_salary`,`work_schedule_id`,`status`,`created_by`,`notes`)
VALUES ('EMP-000005','Ana','Cruz','FEMALE','cashier3@example.test',(SELECT id FROM departments WHERE code='CASH'),(SELECT id FROM positions WHERE code='CASHIER'),'FULL_TIME','2026-01-05','MONTHLY',21000.00,1,'ACTIVE',1,'FICTIONAL SAMPLE — training/demo use only');
SET @sample_employee_id = LAST_INSERT_ID();
INSERT INTO `users` (`username`,`email`,`password_hash`,`full_name`,`role_id`,`employee_id`,`status`,`must_change_password`)
VALUES ('cashier3','cashier3@example.test','$2y$10$bTbZ14x7E9Z8AplpFWcc8OOcn6Rf3y2IbJJBLJ.F4p/86oM8YxVBS','Ana Cruz',(SELECT id FROM roles WHERE code='STAFF'),@sample_employee_id,'ACTIVE',1);
INSERT INTO `salary_history` (`employee_id`,`salary_type`,`basic_salary`,`effective_from`,`reason`,`changed_by`)
VALUES (@sample_employee_id,'MONTHLY',21000.00,'2026-01-05','Initial sample salary',1);
INSERT INTO `employees` (`employee_number`,`first_name`,`last_name`,`gender`,`email`,`department_id`,`position_id`,`employment_type`,`date_hired`,`salary_type`,`basic_salary`,`work_schedule_id`,`status`,`created_by`,`notes`)
VALUES ('EMP-000006','Carlo','Garcia','MALE','cashier4@example.test',(SELECT id FROM departments WHERE code='CASH'),(SELECT id FROM positions WHERE code='CASHIER'),'FULL_TIME','2026-01-05','MONTHLY',20000.00,2,'ACTIVE',1,'FICTIONAL SAMPLE — training/demo use only');
SET @sample_employee_id = LAST_INSERT_ID();
INSERT INTO `users` (`username`,`email`,`password_hash`,`full_name`,`role_id`,`employee_id`,`status`,`must_change_password`)
VALUES ('cashier4','cashier4@example.test','$2y$10$bTbZ14x7E9Z8AplpFWcc8OOcn6Rf3y2IbJJBLJ.F4p/86oM8YxVBS','Carlo Garcia',(SELECT id FROM roles WHERE code='STAFF'),@sample_employee_id,'ACTIVE',1);
INSERT INTO `salary_history` (`employee_id`,`salary_type`,`basic_salary`,`effective_from`,`reason`,`changed_by`)
VALUES (@sample_employee_id,'MONTHLY',20000.00,'2026-01-05','Initial sample salary',1);
INSERT INTO `employees` (`employee_number`,`first_name`,`last_name`,`gender`,`email`,`department_id`,`position_id`,`employment_type`,`date_hired`,`salary_type`,`basic_salary`,`work_schedule_id`,`status`,`created_by`,`notes`)
VALUES ('EMP-000007','Liza','Mendoza','FEMALE','cashier5@example.test',(SELECT id FROM departments WHERE code='CASH'),(SELECT id FROM positions WHERE code='CASHIER'),'FULL_TIME','2026-01-05','MONTHLY',22000.00,1,'ACTIVE',1,'FICTIONAL SAMPLE — training/demo use only');
SET @sample_employee_id = LAST_INSERT_ID();
INSERT INTO `users` (`username`,`email`,`password_hash`,`full_name`,`role_id`,`employee_id`,`status`,`must_change_password`)
VALUES ('cashier5','cashier5@example.test','$2y$10$bTbZ14x7E9Z8AplpFWcc8OOcn6Rf3y2IbJJBLJ.F4p/86oM8YxVBS','Liza Mendoza',(SELECT id FROM roles WHERE code='STAFF'),@sample_employee_id,'ACTIVE',1);
INSERT INTO `salary_history` (`employee_id`,`salary_type`,`basic_salary`,`effective_from`,`reason`,`changed_by`)
VALUES (@sample_employee_id,'MONTHLY',22000.00,'2026-01-05','Initial sample salary',1);


-- ---------------------------------------------------------------------------
-- V6 RETAIL DEMO ORGANIZATION + HR PAYROLL SAMPLE USER (fresh installs only)
-- ---------------------------------------------------------------------------

-- Ensure the fourth role exists even on a database missing only the role seed.
INSERT IGNORE INTO roles (code, name, description, permissions, is_system)
VALUES ('HR_PAYROLL', 'HR / Payroll Staff',
        'Employee records and payroll preparation; no payroll approval/release',
        '["dashboard.view","employees.view","employees.create","employees.update","employees.archive","employees.restore","attendance.view","attendance.view_own","attendance.create","attendance.update","attendance.adjust","schedule.view","holiday.view","leave.view","leave.view_own","leave.create","payroll.view","payroll.view_own","payroll.period.view","payroll.period.create","payroll.calculate","payroll.payslip.view","payroll.payslip.view_own","payroll.payments.view","loans.view","loans.create","loans.update","loans.payment","report.payroll","report.attendance","report.leave","report.statutory","remittance.view","remittance.manage"]', 1);

-- Activate existing codes without wiping already-configured salaries or employees.
-- Human Resources, Sales and Operations exist in the V5 seed, but were disabled.
INSERT INTO departments (code, name, description, base_salary, is_active)
VALUES
  ('CASH', 'Cashier', 'Checkout and POS operations', 20000.00, 1),
  ('HR', 'HR & Payroll', 'Employee records and payroll processing', 30000.00, 1),
  ('SALES', 'Sales Floor', 'Sales associates and merchandise display', 21000.00, 1),
  ('STOCK', 'Inventory & Stockroom', 'Stock receiving, storage and inventory', 22000.00, 1),
  ('OPS', 'Store Operations', 'Store supervision and daily coordination', 28000.00, 1)
ON DUPLICATE KEY UPDATE
  is_active = 1,
  deleted_at = NULL,
  base_salary = COALESCE(departments.base_salary, VALUES(base_salary));

-- For old V5 untouched reference names, use retail-facing display names;
-- leave custom department names unchanged.
UPDATE departments SET name='HR & Payroll' WHERE code='HR' AND name='Human Resources';
UPDATE departments SET name='Sales Floor' WHERE code='SALES' AND name='Sales';
UPDATE departments SET name='Store Operations' WHERE code='OPS' AND name='Operations';

-- Seven suggested active job positions across five departments.
-- Existing Cashier position is retained; other generic/legacy positions remain intact.
INSERT INTO positions (code, name, department_id, job_level, description, is_active)
SELECT 'CASHIER', 'Cashier', d.id, 'Staff', 'POS / cash handling', 1 FROM departments d WHERE d.code='CASH'
ON DUPLICATE KEY UPDATE is_active=1, deleted_at=NULL;
INSERT INTO positions (code, name, department_id, job_level, description, is_active)
SELECT 'HEAD-CASH', 'Head Cashier', d.id, 'Supervisor', 'Cashier station oversight', 1 FROM departments d WHERE d.code='CASH'
ON DUPLICATE KEY UPDATE is_active=1, deleted_at=NULL;
INSERT INTO positions (code, name, department_id, job_level, description, is_active)
SELECT 'SALES-ASST', 'Sales Associate', d.id, 'Staff', 'Merchandise sales and display', 1 FROM departments d WHERE d.code='SALES'
ON DUPLICATE KEY UPDATE is_active=1, deleted_at=NULL;
INSERT INTO positions (code, name, department_id, job_level, description, is_active)
SELECT 'STOCK-CLRK', 'Stock Clerk', d.id, 'Staff', 'Receiving and shelf replenishment', 1 FROM departments d WHERE d.code='STOCK'
ON DUPLICATE KEY UPDATE is_active=1, deleted_at=NULL;
INSERT INTO positions (code, name, department_id, job_level, description, is_active)
SELECT 'INV-CTRL', 'Inventory Controller', d.id, 'Staff', 'Stock movement and reconciliation', 1 FROM departments d WHERE d.code='STOCK'
ON DUPLICATE KEY UPDATE is_active=1, deleted_at=NULL;
INSERT INTO positions (code, name, department_id, job_level, description, is_active)
SELECT 'HR-PAY-OFC', 'HR/Payroll Officer', d.id, 'Staff', 'Employee and payroll preparation tasks', 1 FROM departments d WHERE d.code='HR'
ON DUPLICATE KEY UPDATE is_active=1, deleted_at=NULL;
INSERT INTO positions (code, name, department_id, job_level, description, is_active)
SELECT 'STORE-SUP', 'Store Supervisor', d.id, 'Supervisor', 'Floor operations supervision', 1 FROM departments d WHERE d.code='OPS'
ON DUPLICATE KEY UPDATE is_active=1, deleted_at=NULL;

-- Fictional HR employee. Does not reuse any personal details from user screenshots.
-- Skip creation when 'hr' is already an existing login. Never overwrite a real account.
INSERT INTO employees
  (employee_number,first_name,last_name,gender,email,department_id,position_id,
   employment_type,date_hired,salary_type,basic_salary,work_schedule_id,
   status,created_by,notes)
SELECT 'DEMO-HR-001','Demo','HR Payroll','OTHER','demo-hr-payroll@example.test',
       d.id,p.id,'FULL_TIME','2026-01-05','MONTHLY',30000.00,
       (SELECT id FROM work_schedules WHERE code='STD-MF' LIMIT 1),
       'ACTIVE',(SELECT id FROM users WHERE username='admin' LIMIT 1),
       'FICTIONAL HR/Payroll account for offline classroom testing'
  FROM departments d JOIN positions p ON p.department_id=d.id AND p.code='HR-PAY-OFC'
 WHERE d.code='HR'
   AND NOT EXISTS (SELECT 1 FROM employees WHERE employee_number='DEMO-HR-001')
   AND NOT EXISTS (SELECT 1 FROM users WHERE username='hr');

-- Default demo password = Password123@, stored as a bcrypt hash.
-- Login forces the HR demo user to choose a new password immediately.
INSERT INTO users
  (username,email,password_hash,full_name,role_id,employee_id,status,must_change_password)
SELECT 'hr','hrdemo-login@example.test',
       '$2y$10$bTbZ14x7E9Z8AplpFWcc8OOcn6Rf3y2IbJJBLJ.F4p/86oM8YxVBS',
       'Demo HR Payroll',r.id,e.id,'ACTIVE',1
  FROM employees e JOIN roles r ON r.code='HR_PAYROLL'
 WHERE e.employee_number='DEMO-HR-001'
   AND NOT EXISTS (SELECT 1 FROM users WHERE username='hr')
   AND NOT EXISTS (SELECT 1 FROM users WHERE email='hrdemo-login@example.test');

-- Insert initial salary history only once. Preserve original history on rerun.
INSERT INTO salary_history
  (employee_id,salary_type,basic_salary,effective_from,reason,changed_by)
SELECT e.id, 'MONTHLY',30000.00,'2026-01-05',
       'Initial fictional HR demo monthly salary',
       (SELECT id FROM users WHERE username='admin' LIMIT 1)
  FROM employees e
 WHERE e.employee_number='DEMO-HR-001'
   AND NOT EXISTS (SELECT 1 FROM salary_history sh WHERE sh.employee_id=e.id);

-- ============================================================================
-- END OF SEED
-- ============================================================================
