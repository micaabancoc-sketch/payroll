-- V9: SINGLE-EMPLOYEE DEFENSE FIXTURE (NON-DESTRUCTIVE) — TRAINING USE ONLY.
-- Select your PMS TEST database in phpMyAdmin FIRST (e.g. attendance_payroll_test).
-- Does not CREATE/USE a different DB, DROP or DELETE existing data.
-- Run ONCE (re-running should skip matching employee, attendance and OT rows).
-- Prerequisites: standard Cashier department/position, DAY shift, STD-MFS schedule,
-- SL leave type, STAFF role, admin/manager accounts, V7/V9 migrations.
-- Conflicts in historic records will NOT be overwritten; use verify query.
START TRANSACTION;
INSERT INTO employees (employee_number,first_name,last_name,gender,email,department_id,position_id,employment_type,date_hired,salary_type,basic_salary,work_schedule_id,status,created_by,notes)
SELECT 'TEST-SEP26-08','Max','Test','OTHER','max_sep26@example.test',
       (SELECT id FROM departments WHERE code='CASH'),
       (SELECT id FROM positions WHERE code='CASHIER'),
       'FULL_TIME','2025-01-05','SEMI_MONTHLY',20000.00,
       (SELECT id FROM work_schedules WHERE code='STD-MFS'),
       'ACTIVE',(SELECT id FROM users WHERE username='admin'),
       'FICTIONAL defense case, imported historical attendance (not QR evidence)'
FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM employees WHERE employee_number='TEST-SEP26-08')
AND NOT EXISTS (SELECT 1 FROM employees WHERE first_name='Max' AND last_name='Test' AND deleted_at IS NULL);
SET @emp_max=(SELECT id FROM employees WHERE employee_number='TEST-SEP26-08' LIMIT 1);
-- Missing required department/employee is a setup failure; verify script reveals this.
INSERT INTO users (username,email,password_hash,full_name,role_id,employee_id,status,must_change_password)
SELECT 'max_sep26','max_sep26@example.test',
'$2y$10$bTbZ14x7E9Z8AplpFWcc8OOcn6Rf3y2IbJJBLJ.F4p/86oM8YxVBS',
'Max Test',(SELECT id FROM roles WHERE code='STAFF'),@emp_max,'ACTIVE',1
FROM DUAL WHERE @emp_max IS NOT NULL AND NOT EXISTS (SELECT 1 FROM users WHERE username='max_sep26');
INSERT INTO salary_history (employee_id,salary_type,basic_salary,effective_from,reason,changed_by)
SELECT @emp_max,'SEMI_MONTHLY',20000.00,'2025-01-05','FICTIONAL defense salary',
       (SELECT id FROM users WHERE username='admin')
FROM DUAL WHERE @emp_max IS NOT NULL AND NOT EXISTS (SELECT 1 FROM salary_history WHERE employee_id=@emp_max);
INSERT INTO leave_balances (employee_id,leave_type_id,year,entitled_days,used_days,pending_days)
SELECT @emp_max,lt.id,2026,5.00,IF(lt.code='SL',1.00,0.00),0.00
FROM leave_types lt WHERE lt.code IN ('VL','SL') AND @emp_max IS NOT NULL
AND NOT EXISTS (SELECT 1 FROM leave_balances b WHERE b.employee_id=@emp_max AND b.leave_type_id=lt.id AND b.year=2026);
-- Preapproved fictional Sick Leave: for demonstrating the payroll engine, not a real approval.
INSERT INTO leave_requests (employee_id,leave_type_id,start_date,end_date,days,start_half,end_half,reason,status,approver_id,approved_at,approver_remarks)
SELECT @emp_max,(SELECT id FROM leave_types WHERE code='SL'),'2026-09-14','2026-09-14',1.00,'FULL','FULL',
'FICTIONAL paid SL for defense','APPROVED',(SELECT id FROM users WHERE username='manager'),
'2026-08-28 14:00:00','TEST IMPORT: approved leave, not actual UI decision'
FROM DUAL WHERE @emp_max IS NOT NULL AND NOT EXISTS
(SELECT 1 FROM leave_requests WHERE employee_id=@emp_max AND start_date='2026-09-14' AND end_date='2026-09-14' AND deleted_at IS NULL);
SET @leave_max=(SELECT id FROM leave_requests WHERE employee_id=@emp_max AND start_date='2026-09-14' AND end_date='2026-09-14' AND status='APPROVED' AND deleted_at IS NULL LIMIT 1);
-- 13 workday records: Sept 6/13 are Sunday rest days and deliberately absent from ledger.
INSERT INTO attendance (employee_id,attendance_date,shift_id,work_schedule_id,time_in,time_out,scheduled_start,scheduled_end,worked_hours,late_minutes,undertime_minutes,overtime_hours,status,is_rest_day,is_holiday,leave_request_id,source,remarks) SELECT @emp_max,'2026-09-01',(SELECT id FROM shifts WHERE code='DAY'),(SELECT id FROM work_schedules WHERE code='STD-MFS'),'2026-09-01 08:00:00','2026-09-01 17:00:00','08:00:00','17:00:00',8.00,0,0,0.00,'PRESENT',0,0,NULL,'IMPORT','TEST DATA - Complete regular attendance' FROM DUAL WHERE @emp_max IS NOT NULL AND NOT EXISTS (SELECT 1 FROM attendance WHERE employee_id=@emp_max AND attendance_date='2026-09-01');
INSERT INTO attendance (employee_id,attendance_date,shift_id,work_schedule_id,time_in,time_out,scheduled_start,scheduled_end,worked_hours,late_minutes,undertime_minutes,overtime_hours,status,is_rest_day,is_holiday,leave_request_id,source,remarks) SELECT @emp_max,'2026-09-02',(SELECT id FROM shifts WHERE code='DAY'),(SELECT id FROM work_schedules WHERE code='STD-MFS'),'2026-09-02 08:00:00','2026-09-02 17:00:00','08:00:00','17:00:00',8.00,0,0,0.00,'PRESENT',0,0,NULL,'IMPORT','TEST DATA - Complete regular attendance' FROM DUAL WHERE @emp_max IS NOT NULL AND NOT EXISTS (SELECT 1 FROM attendance WHERE employee_id=@emp_max AND attendance_date='2026-09-02');
INSERT INTO attendance (employee_id,attendance_date,shift_id,work_schedule_id,time_in,time_out,scheduled_start,scheduled_end,worked_hours,late_minutes,undertime_minutes,overtime_hours,status,is_rest_day,is_holiday,leave_request_id,source,remarks) SELECT @emp_max,'2026-09-03',(SELECT id FROM shifts WHERE code='DAY'),(SELECT id FROM work_schedules WHERE code='STD-MFS'),'2026-09-03 08:00:00','2026-09-03 17:00:00','08:00:00','17:00:00',8.00,0,0,0.00,'PRESENT',0,0,NULL,'IMPORT','TEST DATA - Complete regular attendance' FROM DUAL WHERE @emp_max IS NOT NULL AND NOT EXISTS (SELECT 1 FROM attendance WHERE employee_id=@emp_max AND attendance_date='2026-09-03');
INSERT INTO attendance (employee_id,attendance_date,shift_id,work_schedule_id,time_in,time_out,scheduled_start,scheduled_end,worked_hours,late_minutes,undertime_minutes,overtime_hours,status,is_rest_day,is_holiday,leave_request_id,source,remarks) SELECT @emp_max,'2026-09-04',(SELECT id FROM shifts WHERE code='DAY'),(SELECT id FROM work_schedules WHERE code='STD-MFS'),'2026-09-04 08:00:00','2026-09-04 17:00:00','08:00:00','17:00:00',8.00,0,0,0.00,'PRESENT',0,0,NULL,'IMPORT','TEST DATA - Complete regular attendance' FROM DUAL WHERE @emp_max IS NOT NULL AND NOT EXISTS (SELECT 1 FROM attendance WHERE employee_id=@emp_max AND attendance_date='2026-09-04');
INSERT INTO attendance (employee_id,attendance_date,shift_id,work_schedule_id,time_in,time_out,scheduled_start,scheduled_end,worked_hours,late_minutes,undertime_minutes,overtime_hours,status,is_rest_day,is_holiday,leave_request_id,source,remarks) SELECT @emp_max,'2026-09-05',(SELECT id FROM shifts WHERE code='DAY'),(SELECT id FROM work_schedules WHERE code='STD-MFS'),NULL,NULL,'08:00:00','17:00:00',0.00,0,0,0.00,'ABSENT',0,0,NULL,'IMPORT','TEST DATA - One verified unworked scheduled workday' FROM DUAL WHERE @emp_max IS NOT NULL AND NOT EXISTS (SELECT 1 FROM attendance WHERE employee_id=@emp_max AND attendance_date='2026-09-05');
INSERT INTO attendance (employee_id,attendance_date,shift_id,work_schedule_id,time_in,time_out,scheduled_start,scheduled_end,worked_hours,late_minutes,undertime_minutes,overtime_hours,status,is_rest_day,is_holiday,leave_request_id,source,remarks) SELECT @emp_max,'2026-09-07',(SELECT id FROM shifts WHERE code='DAY'),(SELECT id FROM work_schedules WHERE code='STD-MFS'),'2026-09-07 08:00:00','2026-09-07 17:00:00','08:00:00','17:00:00',8.00,0,0,0.00,'PRESENT',0,0,NULL,'IMPORT','TEST DATA - Complete regular attendance' FROM DUAL WHERE @emp_max IS NOT NULL AND NOT EXISTS (SELECT 1 FROM attendance WHERE employee_id=@emp_max AND attendance_date='2026-09-07');
INSERT INTO attendance (employee_id,attendance_date,shift_id,work_schedule_id,time_in,time_out,scheduled_start,scheduled_end,worked_hours,late_minutes,undertime_minutes,overtime_hours,status,is_rest_day,is_holiday,leave_request_id,source,remarks) SELECT @emp_max,'2026-09-08',(SELECT id FROM shifts WHERE code='DAY'),(SELECT id FROM work_schedules WHERE code='STD-MFS'),'2026-09-08 08:20:00','2026-09-08 17:00:00','08:00:00','17:00:00',7.67,20,0,0.00,'LATE',0,0,NULL,'IMPORT','TEST DATA - Late 20 minutes' FROM DUAL WHERE @emp_max IS NOT NULL AND NOT EXISTS (SELECT 1 FROM attendance WHERE employee_id=@emp_max AND attendance_date='2026-09-08');
INSERT INTO attendance (employee_id,attendance_date,shift_id,work_schedule_id,time_in,time_out,scheduled_start,scheduled_end,worked_hours,late_minutes,undertime_minutes,overtime_hours,status,is_rest_day,is_holiday,leave_request_id,source,remarks) SELECT @emp_max,'2026-09-09',(SELECT id FROM shifts WHERE code='DAY'),(SELECT id FROM work_schedules WHERE code='STD-MFS'),'2026-09-09 08:00:00','2026-09-09 17:00:00','08:00:00','17:00:00',8.00,0,0,0.00,'PRESENT',0,0,NULL,'IMPORT','TEST DATA - Complete regular attendance' FROM DUAL WHERE @emp_max IS NOT NULL AND NOT EXISTS (SELECT 1 FROM attendance WHERE employee_id=@emp_max AND attendance_date='2026-09-09');
INSERT INTO attendance (employee_id,attendance_date,shift_id,work_schedule_id,time_in,time_out,scheduled_start,scheduled_end,worked_hours,late_minutes,undertime_minutes,overtime_hours,status,is_rest_day,is_holiday,leave_request_id,source,remarks) SELECT @emp_max,'2026-09-10',(SELECT id FROM shifts WHERE code='DAY'),(SELECT id FROM work_schedules WHERE code='STD-MFS'),'2026-09-10 08:00:00','2026-09-10 16:30:00','08:00:00','17:00:00',7.50,0,30,0.00,'UNDERTIME',0,0,NULL,'IMPORT','TEST DATA - Undertime 30 minutes' FROM DUAL WHERE @emp_max IS NOT NULL AND NOT EXISTS (SELECT 1 FROM attendance WHERE employee_id=@emp_max AND attendance_date='2026-09-10');
INSERT INTO attendance (employee_id,attendance_date,shift_id,work_schedule_id,time_in,time_out,scheduled_start,scheduled_end,worked_hours,late_minutes,undertime_minutes,overtime_hours,status,is_rest_day,is_holiday,leave_request_id,source,remarks) SELECT @emp_max,'2026-09-11',(SELECT id FROM shifts WHERE code='DAY'),(SELECT id FROM work_schedules WHERE code='STD-MFS'),'2026-09-11 08:00:00','2026-09-11 17:00:00','08:00:00','17:00:00',8.00,0,0,0.00,'PRESENT',0,0,NULL,'IMPORT','TEST DATA - Complete regular attendance' FROM DUAL WHERE @emp_max IS NOT NULL AND NOT EXISTS (SELECT 1 FROM attendance WHERE employee_id=@emp_max AND attendance_date='2026-09-11');
INSERT INTO attendance (employee_id,attendance_date,shift_id,work_schedule_id,time_in,time_out,scheduled_start,scheduled_end,worked_hours,late_minutes,undertime_minutes,overtime_hours,status,is_rest_day,is_holiday,leave_request_id,source,remarks) SELECT @emp_max,'2026-09-12',(SELECT id FROM shifts WHERE code='DAY'),(SELECT id FROM work_schedules WHERE code='STD-MFS'),'2026-09-12 08:00:00','2026-09-12 17:00:00','08:00:00','17:00:00',8.00,0,0,2.00,'PRESENT',0,0,NULL,'IMPORT','TEST DATA - 2h approved regular OT 17:30-19:30' FROM DUAL WHERE @emp_max IS NOT NULL AND NOT EXISTS (SELECT 1 FROM attendance WHERE employee_id=@emp_max AND attendance_date='2026-09-12');
INSERT INTO attendance (employee_id,attendance_date,shift_id,work_schedule_id,time_in,time_out,scheduled_start,scheduled_end,worked_hours,late_minutes,undertime_minutes,overtime_hours,status,is_rest_day,is_holiday,leave_request_id,source,remarks) SELECT @emp_max,'2026-09-14',(SELECT id FROM shifts WHERE code='DAY'),(SELECT id FROM work_schedules WHERE code='STD-MFS'),NULL,NULL,'08:00:00','17:00:00',0.00,0,0,0.00,'LEAVE',0,0,@leave_max,'IMPORT','TEST DATA - 1 paid SL; Manager-approved' FROM DUAL WHERE @emp_max IS NOT NULL AND NOT EXISTS (SELECT 1 FROM attendance WHERE employee_id=@emp_max AND attendance_date='2026-09-14');
INSERT INTO attendance (employee_id,attendance_date,shift_id,work_schedule_id,time_in,time_out,scheduled_start,scheduled_end,worked_hours,late_minutes,undertime_minutes,overtime_hours,status,is_rest_day,is_holiday,leave_request_id,source,remarks) SELECT @emp_max,'2026-09-15',(SELECT id FROM shifts WHERE code='DAY'),(SELECT id FROM work_schedules WHERE code='STD-MFS'),'2026-09-15 08:00:00','2026-09-15 17:00:00','08:00:00','17:00:00',8.00,0,0,0.00,'PRESENT',0,0,NULL,'IMPORT','TEST DATA - Complete regular attendance' FROM DUAL WHERE @emp_max IS NOT NULL AND NOT EXISTS (SELECT 1 FROM attendance WHERE employee_id=@emp_max AND attendance_date='2026-09-15');
-- Approved 2-hour OT, with separate imported historic scan. Never add it twice.
INSERT INTO overtime_requests (employee_id,overtime_date,start_time,end_time,hours,ot_type,reason,status,approver_id,created_by,approved_at,approver_remarks,applied_hours,total_hours)
SELECT @emp_max,'2026-09-12','17:30:00','19:30:00',2.00,'REGULAR','FICTIONAL OT for defense',
'APPROVED',(SELECT id FROM users WHERE username='manager'),(SELECT id FROM users WHERE username='manager'),
'2026-09-12 21:00:00','TEST IMPORT, not live UI approval',2.00,2.00
FROM DUAL WHERE @emp_max IS NOT NULL AND NOT EXISTS
(SELECT 1 FROM overtime_requests WHERE employee_id=@emp_max AND overtime_date='2026-09-12' AND deleted_at IS NULL);
SET @ot_max=(SELECT id FROM overtime_requests WHERE employee_id=@emp_max AND overtime_date='2026-09-12' AND deleted_at IS NULL LIMIT 1);
INSERT INTO overtime_scans (overtime_request_id,employee_id,ot_time_in,ot_time_out,payable_minutes)
SELECT @ot_max,@emp_max,'2026-09-12 17:30:00','2026-09-12 19:30:00',120
FROM DUAL WHERE @ot_max IS NOT NULL AND NOT EXISTS
(SELECT 1 FROM overtime_scans WHERE overtime_request_id=@ot_max AND ot_time_in='2026-09-12 17:30:00');
-- The system creates periods automatically. This historical period is left DRAFT
-- so HR can recalculate; no actual payment is fabricated.
INSERT INTO payroll_periods (code,name,start_date,end_date,pay_date,status,created_by)
SELECT 'PP-20260901-20260915','Sep 1-15, 2026','2026-09-01','2026-09-15','2026-09-18','DRAFT',
       (SELECT id FROM users WHERE username='admin')
FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM payroll_periods WHERE start_date='2026-09-01' AND end_date='2026-09-15' AND deleted_at IS NULL);
COMMIT;
-- Verify results in database/MAX_DEFENSE_VERIFY_READ_ONLY.sql.
-- This fixture does not seed a fake annual 13th-month amount or government loan.
