-- ============================================================================
-- OT ASSIGNMENT WORKFLOW (Admin-only announcements + Accept/Decline)
-- Safe for existing databases: idempotent, preserves existing OT records.
-- Run: mysql -u root -p attendance_payroll < database/migrations/20261005_ot_assignments.sql
-- ============================================================================

-- 1. Extend status enum to support assignment responses.
--    MySQL/MariaDB: ALTER ... MODIFY is safe; existing values are preserved.
ALTER TABLE `overtime_requests`
  MODIFY COLUMN `status`
  ENUM('PENDING','ACCEPTED','DECLINED','COMPLETED','APPROVED','REJECTED','CANCELLED')
  NOT NULL DEFAULT 'PENDING';

-- 2. Employee response tracking (assignment workflow).
--    MariaDB 10.4+ has no IF NOT EXISTS for ADD COLUMN, so guard via
--    information_schema with dynamic SQL (safe to re-run).
DELIMITER $$

DROP PROCEDURE IF EXISTS `pms_ot_assign_migrate`$$

CREATE PROCEDURE `pms_ot_assign_migrate`()
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.COLUMNS
    WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'overtime_requests'
      AND COLUMN_NAME = 'created_by'
  ) THEN
    ALTER TABLE `overtime_requests`
      ADD COLUMN `created_by` BIGINT UNSIGNED NULL AFTER `approver_id`,
      ADD CONSTRAINT `fk_ot_creator` FOREIGN KEY (`created_by`)
        REFERENCES `users` (`id`) ON DELETE SET NULL;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.COLUMNS
    WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'overtime_requests'
      AND COLUMN_NAME = 'decline_reason'
  ) THEN
    ALTER TABLE `overtime_requests`
      ADD COLUMN `decline_reason` VARCHAR(500) NULL AFTER `approver_remarks`;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.COLUMNS
    WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'overtime_requests'
      AND COLUMN_NAME = 'responded_at'
  ) THEN
    ALTER TABLE `overtime_requests`
      ADD COLUMN `responded_at` DATETIME NULL AFTER `decline_reason`;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.COLUMNS
    WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'overtime_requests'
      AND COLUMN_NAME = 'responded_by'
  ) THEN
    ALTER TABLE `overtime_requests`
      ADD COLUMN `responded_by` BIGINT UNSIGNED NULL AFTER `responded_at`,
      ADD CONSTRAINT `fk_ot_responder` FOREIGN KEY (`responded_by`)
        REFERENCES `users` (`id`) ON DELETE SET NULL;
  END IF;
END$$

DELIMITER ;

CALL `pms_ot_assign_migrate`();
DROP PROCEDURE IF EXISTS `pms_ot_assign_migrate`;

-- 3. Helpful index for "Tomorrow's OT" + per-employee assignment lists.
--    CREATE INDEX has no IF NOT EXISTS on older MariaDB, so guard it too.
DELIMITER $$

DROP PROCEDURE IF EXISTS `pms_ot_assign_index`$$

CREATE PROCEDURE `pms_ot_assign_index`()
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.STATISTICS
    WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'overtime_requests'
      AND INDEX_NAME = 'idx_ot_date_status'
  ) THEN
    ALTER TABLE `overtime_requests`
      ADD INDEX `idx_ot_date_status` (`overtime_date`, `status`);
  END IF;
END$$

DELIMITER ;

CALL `pms_ot_assign_index`();
DROP PROCEDURE IF EXISTS `pms_ot_assign_index`;

-- 4. Role permissions: only ADMIN keeps announcement/approval powers.
--    MANAGER: own assignments + respond only (no create / approve / view-all).
--    STAFF:   own assignments + respond only (no create).
--    ADMIN ("*") is untouched.
--    These are SURGICAL JSON edits (not a rebuild): every custom permission
--    an admin has granted to MANAGER/STAFF is preserved; only the OT
--    management keys below are removed. Safe to re-run.
DELIMITER $$

DROP PROCEDURE IF EXISTS `pms_ot_drop_perm`$$

CREATE PROCEDURE `pms_ot_drop_perm`(IN p_role_code VARCHAR(64), IN p_permission VARCHAR(100))
BEGIN
  DECLARE v_path VARCHAR(64) DEFAULT NULL;

  SELECT JSON_UNQUOTE(JSON_SEARCH(`permissions`, 'one', p_permission))
    INTO v_path
    FROM `roles`
   WHERE `code` = p_role_code
   LIMIT 1;

  IF v_path IS NOT NULL THEN
    UPDATE `roles`
       SET `permissions` = JSON_REMOVE(`permissions`, v_path)
     WHERE `code` = p_role_code;
  END IF;
END$$

DELIMITER ;

-- MANAGER loses create/approve/view-all; keeps own-view + respond rights.
CALL `pms_ot_drop_perm`('MANAGER', 'overtime.create');
CALL `pms_ot_drop_perm`('MANAGER', 'overtime.approve');
CALL `pms_ot_drop_perm`('MANAGER', 'overtime.view');

-- STAFF loses create; keeps own-view + respond rights.
CALL `pms_ot_drop_perm`('STAFF', 'overtime.create');

-- Obsolete "edit own OT" right: assignees only respond through Accept/Decline,
-- so neither built-in role may hold it (matches database/main.sql).
CALL `pms_ot_drop_perm`('MANAGER', 'overtime.update_own');
CALL `pms_ot_drop_perm`('STAFF', 'overtime.update_own');

-- Anyone who can see overtime keeps the right the Accept/Decline routes need.
UPDATE `roles`
   SET `permissions` = JSON_ARRAY_APPEND(`permissions`, '$', 'overtime.view_own')
 WHERE `code` IN ('MANAGER', 'STAFF')
   AND JSON_CONTAINS(`permissions`, '"overtime.view_own"') = 0;

DROP PROCEDURE IF EXISTS `pms_ot_drop_perm`;
