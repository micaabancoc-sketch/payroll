-- Non-destructive migration for existing databases. Backup first.
-- Remove the Manager's broad loan ledger permission without changing
-- Employee own-loan access or Admin access. Re-login afterwards.
UPDATE roles
SET permissions = JSON_REMOVE(permissions, JSON_UNQUOTE(JSON_SEARCH(permissions, 'one', 'loans.view')))
WHERE code = 'MANAGER'
  AND JSON_VALID(permissions)
  AND JSON_SEARCH(permissions, 'one', 'loans.view') IS NOT NULL;
