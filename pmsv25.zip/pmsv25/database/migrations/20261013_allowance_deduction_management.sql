-- ============================================================================
-- Allowance & deduction management (Phase 4)
--
-- Brings an installation imported before this module existed in line with
-- database/main.sql:
--
--   allowances          + is_percentage, is_recurring, frequency,
--                         effective_from, effective_to, category
--                       + created_by / updated_by (FK -> users)
--   deductions          + is_recurring, frequency, effective_from,
--                         effective_to, category (is_percentage already
--                         existed but was never read by the payroll engine)
--                       + created_by / updated_by (FK -> users)
--   employee_allowances + effective_from, effective_to, reason, notes,
--                         created_by, updated_by, updated_at, deleted_at
--                       + KEY (employee_id, is_active, deleted_at)
--   employee_deductions + the same assignment columns and key
--   roles               + allowances.view / allowances.manage /
--                         allowances.assign and the three deduction twins,
--                         appended to MANAGER (ADMIN holds the "*" wildcard)
--
-- Every new column is additive with a default that reproduces today's
-- behaviour exactly, so no existing payroll figure changes:
--
--   is_percentage = 0  the assignment amount is a peso value (as before)
--   is_recurring  = 1  the component applies to every pay period in range
--   frequency     = 'PERIOD'  the amount is charged in full each period
--                            (a monthly split is opt-in, never implicit)
--   effective_from/_to = NULL  no date bound, i.e. always applicable
--
-- Every statement is repeatable through
-- database/migrate_allowance_deduction.php: a repeated column, key or
-- constraint raises "Duplicate ... name" and the runner reports it as already
-- in place. Nothing is dropped, truncated or reset, no allowance/deduction
-- amount is rewritten and no payroll row is touched.
-- ============================================================================

-- --- Allowance masters ------------------------------------------------------

ALTER TABLE `allowances`
  ADD COLUMN `is_percentage`  TINYINT(1)   NOT NULL DEFAULT 0 AFTER `amount`,
  ADD COLUMN `is_recurring`   TINYINT(1)   NOT NULL DEFAULT 1 AFTER `is_percentage`,
  ADD COLUMN `frequency`      ENUM('PERIOD','MONTHLY') NOT NULL DEFAULT 'PERIOD' AFTER `is_recurring`,
  ADD COLUMN `effective_from` DATE         NULL AFTER `frequency`,
  ADD COLUMN `effective_to`   DATE         NULL AFTER `effective_from`,
  ADD COLUMN `category`       VARCHAR(50)  NULL AFTER `effective_to`,
  ADD COLUMN `created_by`     BIGINT UNSIGNED NULL AFTER `is_active`,
  ADD COLUMN `updated_by`     BIGINT UNSIGNED NULL AFTER `created_by`;

ALTER TABLE `allowances`
  ADD CONSTRAINT `fk_allowances_creator` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL;

ALTER TABLE `allowances`
  ADD CONSTRAINT `fk_allowances_updater` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL;

-- --- Deduction masters ------------------------------------------------------

ALTER TABLE `deductions`
  ADD COLUMN `is_recurring`   TINYINT(1)   NOT NULL DEFAULT 1 AFTER `is_percentage`,
  ADD COLUMN `frequency`      ENUM('PERIOD','MONTHLY') NOT NULL DEFAULT 'PERIOD' AFTER `is_recurring`,
  ADD COLUMN `effective_from` DATE         NULL AFTER `frequency`,
  ADD COLUMN `effective_to`   DATE         NULL AFTER `effective_from`,
  ADD COLUMN `category`       VARCHAR(50)  NULL AFTER `effective_to`,
  ADD COLUMN `created_by`     BIGINT UNSIGNED NULL AFTER `is_active`,
  ADD COLUMN `updated_by`     BIGINT UNSIGNED NULL AFTER `created_by`;

ALTER TABLE `deductions`
  ADD CONSTRAINT `fk_deductions_creator` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL;

ALTER TABLE `deductions`
  ADD CONSTRAINT `fk_deductions_updater` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL;

-- --- Employee allowance assignments ----------------------------------------

ALTER TABLE `employee_allowances`
  ADD COLUMN `effective_from` DATE         NULL AFTER `amount`,
  ADD COLUMN `effective_to`   DATE         NULL AFTER `effective_from`,
  ADD COLUMN `reason`         VARCHAR(255) NULL AFTER `effective_to`,
  ADD COLUMN `notes`          VARCHAR(500) NULL AFTER `reason`,
  ADD COLUMN `created_by`     BIGINT UNSIGNED NULL AFTER `is_active`,
  ADD COLUMN `updated_by`     BIGINT UNSIGNED NULL AFTER `created_by`,
  ADD COLUMN `updated_at`     DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP AFTER `created_at`,
  ADD COLUMN `deleted_at`     DATETIME     NULL AFTER `updated_at`;

ALTER TABLE `employee_allowances`
  ADD CONSTRAINT `fk_empallow_creator` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL;

ALTER TABLE `employee_allowances`
  ADD CONSTRAINT `fk_empallow_updater` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL;

ALTER TABLE `employee_allowances`
  ADD KEY `idx_empallow_active` (`employee_id`, `is_active`, `deleted_at`);

-- --- Employee deduction assignments ----------------------------------------

ALTER TABLE `employee_deductions`
  ADD COLUMN `effective_from` DATE         NULL AFTER `amount`,
  ADD COLUMN `effective_to`   DATE         NULL AFTER `effective_from`,
  ADD COLUMN `reason`         VARCHAR(255) NULL AFTER `effective_to`,
  ADD COLUMN `notes`          VARCHAR(500) NULL AFTER `reason`,
  ADD COLUMN `created_by`     BIGINT UNSIGNED NULL AFTER `is_active`,
  ADD COLUMN `updated_by`     BIGINT UNSIGNED NULL AFTER `created_by`,
  ADD COLUMN `updated_at`     DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP AFTER `created_at`,
  ADD COLUMN `deleted_at`     DATETIME     NULL AFTER `updated_at`;

ALTER TABLE `employee_deductions`
  ADD CONSTRAINT `fk_empded_creator` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL;

ALTER TABLE `employee_deductions`
  ADD CONSTRAINT `fk_empded_updater` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL;

ALTER TABLE `employee_deductions`
  ADD KEY `idx_empded_active` (`employee_id`, `is_active`, `deleted_at`);

-- --- Permissions ------------------------------------------------------------

-- The allowance permissions, appended once. JSON_ARRAY_APPEND keeps the
-- existing entries and the NOT JSON_CONTAINS guard makes a second run a no-op.
UPDATE `roles`
   SET `permissions` = JSON_ARRAY_APPEND(
           `permissions`, '$', 'allowances.view', '$', 'allowances.manage', '$', 'allowances.assign')
 WHERE `code` = 'MANAGER'
   AND JSON_VALID(`permissions`)
   AND NOT JSON_CONTAINS(`permissions`, '"allowances.view"');

-- The deduction permissions, in their own statement: the UPDATE above is
-- skipped the moment an install already carries allowances.view, which would
-- otherwise leave these entries unappended. The guard makes a re-run a no-op.
UPDATE `roles`
   SET `permissions` = JSON_ARRAY_APPEND(
           `permissions`, '$', 'deductions.view', '$', 'deductions.manage', '$', 'deductions.assign')
 WHERE `code` = 'MANAGER'
   AND JSON_VALID(`permissions`)
   AND NOT JSON_CONTAINS(`permissions`, '"deductions.view"');