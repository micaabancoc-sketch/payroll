-- ============================================================================
-- THIRTEENTH-MONTH PAY MODULE — migration
-- ============================================================================
-- Creates the 13th-month pay ledger and the minimal payment-recording table
-- needed by the Release/Payment step. Only leverages existing payroll periods.
-- This file is intended to be run once on a fresh / upgraded install.
-- ============================================================================

-- Non-destructive and idempotent: missing tables are CREATEd, existing ones are
-- left alone apart from the in-place payment_status widening at the bottom.
-- The test suite re-runs this file on every pass, so it must never DROP a table
-- (that would silently discard every 13th-month record and payment ever made).

-- ---------------------------------------------------------------------------
-- 13th-month pay ledger
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `thirteenth_pays` (
    `id`              BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    `employee_id`     BIGINT UNSIGNED NOT NULL,
    `calendar_year`   SMALLINT UNSIGNED NOT NULL,
    `gross_total`     DECIMAL(14,2) NOT NULL DEFAULT 0.00,
    `thirteenth_pay`  DECIMAL(12,2) NOT NULL DEFAULT 0.00,
    `status`          ENUM('DRAFT','FOR_APPROVAL','APPROVED','PAID') NOT NULL DEFAULT 'DRAFT',
    `generated_by`    BIGINT UNSIGNED NULL,
    `generated_at`    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `submitted_by`    BIGINT UNSIGNED NULL,
    `submitted_at`    DATETIME NULL,
    `approved_by`     BIGINT UNSIGNED NULL,
    `approved_at`     DATETIME NULL,
    `released_at`     DATETIME NULL,
    `paid_at`         DATETIME NULL,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uq_thirteenth_emp_year` (`employee_id`,`calendar_year`),
    KEY `idx_thirteenth_status` (`status`,`calendar_year`),
    KEY `idx_thirteenth_year` (`calendar_year`),
    CONSTRAINT `fk_thirteenth_emp` FOREIGN KEY (`employee_id`) REFERENCES `employees` (`id`) ON DELETE CASCADE,
    CONSTRAINT `fk_thirteenth_gen` FOREIGN KEY (`generated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
    CONSTRAINT `fk_thirteenth_sub` FOREIGN KEY (`submitted_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
    CONSTRAINT `fk_thirteenth_app` FOREIGN KEY (`approved_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------------
-- 13th-month payments (linked to a pay record; does NOT affect payroll.per_period)
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `thirteenth_payments` (
    `id`                BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    `thirteenth_pay_id` BIGINT UNSIGNED NOT NULL,
    `amount`            DECIMAL(12,2) NOT NULL DEFAULT 0.00,
    `payment_status`    ENUM('PENDING','PARTIAL','COMPLETED','FAILED') NOT NULL DEFAULT 'PENDING',
    `paid_at`           DATETIME NULL,
    `paid_by`           BIGINT UNSIGNED NULL,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uq_ltpay_payment` (`thirteenth_pay_id`),
    KEY `idx_ltpay_status` (`payment_status`),
    CONSTRAINT `fk_ltpay` FOREIGN KEY (`thirteenth_pay_id`) REFERENCES `thirteenth_pays` (`id`) ON DELETE CASCADE,
    CONSTRAINT `fk_ltpay_user` FOREIGN KEY (`paid_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------------
-- No role or wildcard addition is required. The 13th-month module uses the
-- existing role-permission system: users who already hold payroll approval /
-- finalize / mark_paid (and payroll.view for read) are authorized to generate,
-- approve, and release 13th-month records. See roles seed in main.sql.
-- ---------------------------------------------------------------------------

-- ---------------------------------------------------------------------------
-- 3. Upgrade a ledger created before 'PARTIAL' existed.
--
--    Release opens the single UNIQUE ledger row as PENDING (0.00 disbursed).
--    recordPayment() then moves it to PARTIAL while a balance is outstanding
--    and only to COMPLETED once the cumulative amount settles the record, so an
--    instalment is no longer mislabelled as fully paid. MODIFY COLUMN is
--    idempotent: re-running this file is a no-op once the enum matches.
-- ---------------------------------------------------------------------------
ALTER TABLE `thirteenth_payments`
  MODIFY COLUMN `payment_status` ENUM('PENDING','PARTIAL','COMPLETED','FAILED') NOT NULL DEFAULT 'PENDING';
