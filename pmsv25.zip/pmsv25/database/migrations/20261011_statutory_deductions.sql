-- ============================================================================
-- GOVERNMENT CONTRIBUTIONS (SSS, PhilHealth, Pag-IBIG) + BIR WITHHOLDING TAX
--
-- Every rate below is effective-dated data (not code) and carries the source
-- it was taken from, so a payroll row can always be traced back to the rule
-- that produced it:
--
--   SSS          SSS Circular No. 2024-006 (effective 1 January 2025, per SSC
--                Resolution No. 560-s.2024) under RA 11199: 15% of the
--                Monthly Salary Credit, employer 10%, employee 5%, MSC
--                P5,000.00 - P35,000.00 in P500.00 steps, employer EC of
--                P10.00 when the MSC is P14,500.00 or less and P30.00 above.
--   PhilHealth   PhilHealth Advisory No. 2025-0002 (8 January 2025) and
--                PhilHealth Circular No. 2020-0005 (Revision 1): 5.0% of the
--                Monthly Basic Salary, floor P10,000.00, ceiling P100,000.00,
--                split equally between employee and employer (2.5% each).
--   Pag-IBIG     HDMF (Pag-IBIG Fund) Circular No. 460 (15 January 2024,
--                effective February 2024): 2% employee and 2% employer of the
--                Fund Salary, 1% employee when the Fund Salary is P1,500.00 or
--                less, maximum Fund Salary raised from P5,000.00 to
--                P10,000.00. Circular No. 460 defines the Fund Salary as the
--                "basic salary and other allowances", so the seeded Pag-IBIG
--                base (and the code default) is MONTHLY_BASIC_PLUS_ALLOWANCES.
--   Withholding  BIR Revenue Regulations No. 11-2018, Annex E - Revised
--                Withholding Tax Table "Effective January 1, 2023 and
--                onwards" (daily, weekly, semi-monthly and monthly tables).
--
-- Idempotent: CREATE TABLE IF NOT EXISTS / INSERT IGNORE everywhere, and the
-- single ALTER TABLE is tolerated by database/migrate_statutory_deductions.php
-- when the columns already exist.
--
-- Run on an existing database:
--   php database/migrate_statutory_deductions.php
-- ============================================================================

-- ---------------------------------------------------------------------------
-- 1. Payroll columns for the employee share, the withheld tax and the
--    employer share (the employer share never touches net pay).
-- ---------------------------------------------------------------------------
ALTER TABLE `payroll`
  ADD COLUMN `statutory_sss`          DECIMAL(12,2) NOT NULL DEFAULT 0.00 AFTER `other_deductions`,
  ADD COLUMN `statutory_philhealth`   DECIMAL(12,2) NOT NULL DEFAULT 0.00 AFTER `statutory_sss`,
  ADD COLUMN `statutory_pagibig`      DECIMAL(12,2) NOT NULL DEFAULT 0.00 AFTER `statutory_philhealth`,
  ADD COLUMN `withholding_tax`        DECIMAL(12,2) NOT NULL DEFAULT 0.00 AFTER `statutory_pagibig`,
  ADD COLUMN `statutory_total`        DECIMAL(12,2) NOT NULL DEFAULT 0.00 AFTER `withholding_tax`,
  ADD COLUMN `employer_contributions` DECIMAL(12,2) NOT NULL DEFAULT 0.00 AFTER `statutory_total`;

-- ---------------------------------------------------------------------------
-- 2. Effective-dated schedules for the three government contributions.
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `statutory_schedules` (
  `id`                   BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `code`                 VARCHAR(30)   NOT NULL,
  `name`                 VARCHAR(150)  NOT NULL,
  `agency`               VARCHAR(150)  NOT NULL,
  `scheme`               ENUM('PERCENTAGE','CREDIT_RATE') NOT NULL DEFAULT 'PERCENTAGE',
  `effective_from`       DATE          NOT NULL,
  `effective_to`         DATE          NULL,
  `salary_base`          ENUM('MONTHLY_BASIC','MONTHLY_BASIC_PLUS_ALLOWANCES') NOT NULL DEFAULT 'MONTHLY_BASIC',
  `salary_floor`         DECIMAL(12,2) NULL,
  `salary_ceiling`       DECIMAL(12,2) NULL,
  `employee_rate`        DECIMAL(9,4)  NULL,
  `employer_rate`        DECIMAL(9,4)  NULL,
  `low_salary_threshold` DECIMAL(12,2) NULL,
  `low_employee_rate`    DECIMAL(9,4)  NULL,
  `low_employer_rate`    DECIMAL(9,4)  NULL,
  `credit_step`          DECIMAL(12,2) NULL,
  `credit_min`           DECIMAL(12,2) NULL,
  `credit_max`           DECIMAL(12,2) NULL,
  `ec_amount`            DECIMAL(12,2) NULL,
  `ec_amount_high`       DECIMAL(12,2) NULL,
  `ec_threshold`         DECIMAL(12,2) NULL,
  `rounding`             ENUM('CENTAVO','PESO') NOT NULL DEFAULT 'CENTAVO',
  `deduction_code`       VARCHAR(30)   NOT NULL,
  `deduction_name`       VARCHAR(150)  NOT NULL,
  `source_name`          VARCHAR(255)  NULL,
  `source_url`           VARCHAR(500)  NULL,
  `notes`                VARCHAR(500)  NULL,
  `status`               ENUM('ACTIVE','INACTIVE') NOT NULL DEFAULT 'ACTIVE',
  `created_by`           BIGINT UNSIGNED NULL,
  `created_at`           DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`           DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_statutory_code_from` (`code`, `effective_from`),
  KEY `idx_statutory_lookup` (`code`, `status`, `effective_from`),
  CONSTRAINT `fk_statutory_user` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------------
-- 3. BIR withholding tax: one effective-dated table per payroll frequency.
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `bir_withholding_schedules` (
  `id`             BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `frequency`      ENUM('DAILY','WEEKLY','SEMI_MONTHLY','MONTHLY') NOT NULL,
  `effective_from` DATE          NOT NULL,
  `effective_to`   DATE          NULL,
  `source_name`    VARCHAR(255)  NULL,
  `source_url`     VARCHAR(500)  NULL,
  `notes`          VARCHAR(500)  NULL,
  `status`         ENUM('ACTIVE','INACTIVE') NOT NULL DEFAULT 'ACTIVE',
  `created_by`     BIGINT UNSIGNED NULL,
  `created_at`     DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`     DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_bir_frequency_from` (`frequency`, `effective_from`),
  KEY `idx_bir_lookup` (`frequency`, `status`, `effective_from`),
  CONSTRAINT `fk_bir_schedule_user` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `bir_withholding_brackets` (
  `id`                BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `schedule_id`       BIGINT UNSIGNED NOT NULL,
  `bracket_order`     INT UNSIGNED  NOT NULL,
  `compensation_from` DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  `compensation_to`   DECIMAL(12,2) NULL,
  `base_tax`          DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  `excess_rate`       DECIMAL(9,4)  NOT NULL DEFAULT 0.0000,
  `excess_over`       DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  `notes`             VARCHAR(255)  NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_bir_bracket_order` (`schedule_id`, `bracket_order`),
  CONSTRAINT `fk_bir_bracket_schedule` FOREIGN KEY (`schedule_id`) REFERENCES `bir_withholding_schedules` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------------
-- 4. Per-payroll audit trail: what was charged, from which schedule version.
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `payroll_statutory` (
  `id`                      BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `payroll_id`              BIGINT UNSIGNED NOT NULL,
  `code`                    VARCHAR(30)   NOT NULL,
  `name`                    VARCHAR(150)  NOT NULL,
  `scheme`                  VARCHAR(30)   NULL,
  `schedule_id`             BIGINT UNSIGNED NULL,
  `schedule_effective_from` DATE          NULL,
  `schedule_source`         VARCHAR(500)  NULL,
  `salary_base`             VARCHAR(30)   NULL,
  `monthly_base`            DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  `credited_base`           DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  `employee_rate`           DECIMAL(9,4)  NULL,
  `employer_rate`           DECIMAL(9,4)  NULL,
  `monthly_employee_amount` DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  `monthly_employer_amount` DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  `monthly_extra_amount`    DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  `allocation_factor`       DECIMAL(8,4)  NOT NULL DEFAULT 1.0000,
  `employee_amount`         DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  `employer_amount`         DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  `extra_amount`            DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  `withholding_period`      VARCHAR(20)   NULL,
  `bracket_order`           INT UNSIGNED  NULL,
  `remarks`                 VARCHAR(255)  NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_payroll_statutory` (`payroll_id`, `code`),
  KEY `idx_payroll_statutory_code` (`code`),
  CONSTRAINT `fk_payroll_statutory_payroll` FOREIGN KEY (`payroll_id`) REFERENCES `payroll` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------------
-- 5. Administrator switches (PAYROLL category -> shown in Settings).
-- ---------------------------------------------------------------------------
INSERT IGNORE INTO `system_settings`
(`setting_key`, `setting_value`, `category`, `label`, `value_type`, `description`, `is_public`) VALUES
('statutory.enabled', '1', 'PAYROLL', 'Government Contributions Enabled', 'BOOLEAN', 'Master switch for SSS, PhilHealth, Pag-IBIG and withholding tax', 0),
('statutory.sss_enabled', '1', 'PAYROLL', 'SSS Contribution Enabled', 'BOOLEAN', 'Deduct the employee SSS share using the effective schedule', 0),
('statutory.philhealth_enabled', '1', 'PAYROLL', 'PhilHealth Contribution Enabled', 'BOOLEAN', 'Deduct the employee PhilHealth share using the effective schedule', 0),
('statutory.pagibig_enabled', '1', 'PAYROLL', 'Pag-IBIG Contribution Enabled', 'BOOLEAN', 'Deduct the employee Pag-IBIG share using the effective schedule', 0),
('statutory.tax_enabled', '1', 'PAYROLL', 'Withholding Tax Enabled', 'BOOLEAN', 'Withhold BIR tax using the table of the payroll frequency', 0),
('statutory.allocation_basis', 'CALENDAR_DAYS', 'PAYROLL', 'Monthly Allocation Basis', 'STRING', 'CALENDAR_DAYS prorates by days covered, EQUAL_SPLIT divides by pay periods per month', 0),
('statutory.periods_per_month', '2', 'PAYROLL', 'Pay Periods Per Month', 'INT', 'Used by the EQUAL_SPLIT allocation basis', 0),
('statutory.pagibig_salary_base', 'MONTHLY_BASIC_PLUS_ALLOWANCES', 'PAYROLL', 'Pag-IBIG Fund Salary Base', 'STRING', 'MONTHLY_BASIC or MONTHLY_BASIC_PLUS_ALLOWANCES', 0),
('statutory.tax_exclude_non_taxable_allowances', '1', 'PAYROLL', 'Exclude Non-Taxable Allowances', 'BOOLEAN', 'Allowances flagged non-taxable are removed from the taxable compensation', 0),
('statutory.tax_subtract_contributions', '1', 'PAYROLL', 'Deduct Contributions Before Tax', 'BOOLEAN', 'The employee SSS, PhilHealth and Pag-IBIG shares are deducted from taxable compensation', 0);

-- ---------------------------------------------------------------------------
-- 6. Verified schedule versions.
-- ---------------------------------------------------------------------------
INSERT IGNORE INTO `statutory_schedules`
(`code`, `name`, `agency`, `scheme`, `effective_from`, `effective_to`, `salary_base`,
 `salary_floor`, `salary_ceiling`, `employee_rate`, `employer_rate`,
 `low_salary_threshold`, `low_employee_rate`, `low_employer_rate`,
 `credit_step`, `credit_min`, `credit_max`, `ec_amount`, `ec_amount_high`, `ec_threshold`,
 `rounding`, `deduction_code`, `deduction_name`, `source_name`, `source_url`, `notes`) VALUES
('SSS', 'SSS Contribution', 'Social Security System', 'CREDIT_RATE', '2025-01-01', NULL, 'MONTHLY_BASIC',
 NULL, NULL, '5.0000', '10.0000',
 NULL, NULL, NULL,
 '500.00', '5000.00', '35000.00', '10.00', '30.00', '14500.00',
 'CENTAVO', 'SSS_EE', 'SSS Contribution (Employee Share)',
 'SSS Circular No. 2024-006, effective 1 January 2025 (SSC Resolution No. 560-s.2024, RA 11199)',
 'https://www.sss.gov.ph/wp-content/uploads/2024/12/CI-2024-006-Publication.pdf',
 '15% of the Monthly Salary Credit - employer 10%, employee 5%. MSC P5,000.00 to P35,000.00 in P500.00 steps. Employer EC P10.00 at MSC 14,500.00 or less and P30.00 above.'),
('PHILHEALTH', 'PhilHealth Premium', 'Philippine Health Insurance Corporation', 'PERCENTAGE', '2025-01-01', NULL, 'MONTHLY_BASIC',
 '10000.00', '100000.00', '2.5000', '2.5000',
 NULL, NULL, NULL,
 NULL, NULL, NULL, NULL, NULL, NULL,
 'CENTAVO', 'PHILHEALTH_EE', 'PhilHealth Premium (Employee Share)',
 'PhilHealth Advisory No. 2025-0002 dated 8 January 2025 (PhilHealth Circular No. 2020-0005, Revision 1)',
 'https://www.philhealth.gov.ph/advisories/2025/PA2025-0002.pdf',
 '5.0% of the Monthly Basic Salary shared equally - 2.5% each. Income floor P10,000.00, income ceiling P100,000.00.'),
('PAGIBIG', 'Pag-IBIG Fund Savings', 'Home Development Mutual Fund', 'PERCENTAGE', '2024-02-01', NULL, 'MONTHLY_BASIC_PLUS_ALLOWANCES',
 NULL, '10000.00', '2.0000', '2.0000',
 '1500.00', '1.0000', '2.0000',
 NULL, NULL, NULL, NULL, NULL, NULL,
 'CENTAVO', 'PAGIBIG_EE', 'Pag-IBIG Fund (Employee Share)',
 'Pag-IBIG Fund (HDMF) Circular No. 460 dated 15 January 2024, effective February 2024',
 'https://mpm.ph/wp-content/uploads/2024/01/HDMF-Circular-No.-460-Pag-ibig-HDMF-Table-2024.pdf',
 'Employer and employee 2% each of the Fund Salary, employee 1% when the Fund Salary is P1,500.00 or less. Maximum Fund Salary P10,000.00 (increased from P5,000.00).');

INSERT IGNORE INTO `bir_withholding_schedules`
(`frequency`, `effective_from`, `effective_to`, `source_name`, `source_url`, `notes`) VALUES
('DAILY', '2023-01-01', NULL, 'BIR Revenue Regulations No. 11-2018, Annex E - Revised Withholding Tax Table (effective January 1, 2023 and onwards)',
 'https://bir-cdn.bir.gov.ph/local/pdf/Annex%20E%20RR%2011-2018.pdf', 'Daily table'),
('WEEKLY', '2023-01-01', NULL, 'BIR Revenue Regulations No. 11-2018, Annex E - Revised Withholding Tax Table (effective January 1, 2023 and onwards)',
 'https://bir-cdn.bir.gov.ph/local/pdf/Annex%20E%20RR%2011-2018.pdf', 'Weekly table'),
('SEMI_MONTHLY', '2023-01-01', NULL, 'BIR Revenue Regulations No. 11-2018, Annex E - Revised Withholding Tax Table (effective January 1, 2023 and onwards)',
 'https://bir-cdn.bir.gov.ph/local/pdf/Annex%20E%20RR%2011-2018.pdf', 'Semi-monthly table - used by the default twice-monthly payroll'),
('MONTHLY', '2023-01-01', NULL, 'BIR Revenue Regulations No. 11-2018, Annex E - Revised Withholding Tax Table (effective January 1, 2023 and onwards)',
 'https://bir-cdn.bir.gov.ph/local/pdf/Annex%20E%20RR%2011-2018.pdf', 'Monthly table');

INSERT IGNORE INTO `bir_withholding_brackets`
(`schedule_id`, `bracket_order`, `compensation_from`, `compensation_to`, `base_tax`, `excess_rate`, `excess_over`) VALUES
((SELECT `id` FROM `bir_withholding_schedules` WHERE `frequency` = 'DAILY' AND `effective_from` = '2023-01-01'), 1, '0.00', '685.00', '0.00', '0.0000', '0.00'),
((SELECT `id` FROM `bir_withholding_schedules` WHERE `frequency` = 'DAILY' AND `effective_from` = '2023-01-01'), 2, '685.01', '1095.00', '0.00', '15.0000', '685.00'),
((SELECT `id` FROM `bir_withholding_schedules` WHERE `frequency` = 'DAILY' AND `effective_from` = '2023-01-01'), 3, '1096.00', '2191.00', '61.65', '20.0000', '1096.00'),
((SELECT `id` FROM `bir_withholding_schedules` WHERE `frequency` = 'DAILY' AND `effective_from` = '2023-01-01'), 4, '2192.00', '5478.00', '280.85', '25.0000', '2192.00'),
((SELECT `id` FROM `bir_withholding_schedules` WHERE `frequency` = 'DAILY' AND `effective_from` = '2023-01-01'), 5, '5479.00', '21917.00', '1102.60', '30.0000', '5479.00'),
((SELECT `id` FROM `bir_withholding_schedules` WHERE `frequency` = 'DAILY' AND `effective_from` = '2023-01-01'), 6, '21918.00', NULL, '6034.00', '35.0000', '21918.00'),
((SELECT `id` FROM `bir_withholding_schedules` WHERE `frequency` = 'WEEKLY' AND `effective_from` = '2023-01-01'), 1, '0.00', '4808.00', '0.00', '0.0000', '0.00'),
((SELECT `id` FROM `bir_withholding_schedules` WHERE `frequency` = 'WEEKLY' AND `effective_from` = '2023-01-01'), 2, '4808.01', '7691.00', '0.00', '15.0000', '4808.00'),
((SELECT `id` FROM `bir_withholding_schedules` WHERE `frequency` = 'WEEKLY' AND `effective_from` = '2023-01-01'), 3, '7692.00', '15384.00', '432.60', '20.0000', '7692.00'),
((SELECT `id` FROM `bir_withholding_schedules` WHERE `frequency` = 'WEEKLY' AND `effective_from` = '2023-01-01'), 4, '15385.00', '38461.00', '1971.20', '25.0000', '15385.00'),
((SELECT `id` FROM `bir_withholding_schedules` WHERE `frequency` = 'WEEKLY' AND `effective_from` = '2023-01-01'), 5, '38462.00', '153845.00', '7740.45', '30.0000', '38462.00'),
((SELECT `id` FROM `bir_withholding_schedules` WHERE `frequency` = 'WEEKLY' AND `effective_from` = '2023-01-01'), 6, '153846.00', NULL, '42355.65', '35.0000', '153846.00'),
((SELECT `id` FROM `bir_withholding_schedules` WHERE `frequency` = 'SEMI_MONTHLY' AND `effective_from` = '2023-01-01'), 1, '0.00', '10417.00', '0.00', '0.0000', '0.00'),
((SELECT `id` FROM `bir_withholding_schedules` WHERE `frequency` = 'SEMI_MONTHLY' AND `effective_from` = '2023-01-01'), 2, '10417.01', '16666.00', '0.00', '15.0000', '10417.00'),
((SELECT `id` FROM `bir_withholding_schedules` WHERE `frequency` = 'SEMI_MONTHLY' AND `effective_from` = '2023-01-01'), 3, '16667.00', '33332.00', '937.50', '20.0000', '16667.00'),
((SELECT `id` FROM `bir_withholding_schedules` WHERE `frequency` = 'SEMI_MONTHLY' AND `effective_from` = '2023-01-01'), 4, '33333.00', '83332.00', '4270.70', '25.0000', '33333.00'),
((SELECT `id` FROM `bir_withholding_schedules` WHERE `frequency` = 'SEMI_MONTHLY' AND `effective_from` = '2023-01-01'), 5, '83333.00', '333332.00', '16770.70', '30.0000', '83333.00'),
((SELECT `id` FROM `bir_withholding_schedules` WHERE `frequency` = 'SEMI_MONTHLY' AND `effective_from` = '2023-01-01'), 6, '333333.00', NULL, '91770.70', '35.0000', '333333.00'),
((SELECT `id` FROM `bir_withholding_schedules` WHERE `frequency` = 'MONTHLY' AND `effective_from` = '2023-01-01'), 1, '0.00', '20833.00', '0.00', '0.0000', '0.00'),
((SELECT `id` FROM `bir_withholding_schedules` WHERE `frequency` = 'MONTHLY' AND `effective_from` = '2023-01-01'), 2, '20833.01', '33332.00', '0.00', '15.0000', '20833.00'),
((SELECT `id` FROM `bir_withholding_schedules` WHERE `frequency` = 'MONTHLY' AND `effective_from` = '2023-01-01'), 3, '33333.00', '66666.00', '1875.00', '20.0000', '33333.00'),
((SELECT `id` FROM `bir_withholding_schedules` WHERE `frequency` = 'MONTHLY' AND `effective_from` = '2023-01-01'), 4, '66667.00', '166666.00', '8541.80', '25.0000', '66667.00'),
((SELECT `id` FROM `bir_withholding_schedules` WHERE `frequency` = 'MONTHLY' AND `effective_from` = '2023-01-01'), 5, '166667.00', '666666.00', '33541.80', '30.0000', '166667.00'),
((SELECT `id` FROM `bir_withholding_schedules` WHERE `frequency` = 'MONTHLY' AND `effective_from` = '2023-01-01'), 6, '666667.00', NULL, '183541.80', '35.0000', '666667.00');

-- ---------------------------------------------------------------------------
-- 7. Retire the legacy fixed-amount placeholders so an employee is never
--    charged twice. The rows are kept (history and payslip renders stay
--    intact) but switched off and labelled. Custom deductions with other
--    codes are untouched, and the engine also ignores these codes when a
--    statutory schedule is enabled.
-- ---------------------------------------------------------------------------
UPDATE `deductions`
   SET `is_active` = 0,
       `description` = CONCAT(COALESCE(`description`, ''), ' [Deactivated - computed automatically as a statutory deduction]')
 WHERE `code` IN ('SSS', 'PHILHEALTH', 'PAGIBIG', 'TAX')
   AND `description` NOT LIKE '%[Deactivated%';

-- ---------------------------------------------------------------------------
-- 8. Corrigendum - Pag-IBIG Fund Salary base (verified against HDMF Circular
--    No. 460, which defines the Fund Salary as the basic salary plus other
--    allowances). Installs seeded before this fix carry the old
--    MONTHLY_BASIC value; these one-directional, idempotent UPDATEs bring the
--    live setting and the schedule metadata in line without touching any
--    payroll row. Re-running the migration is a no-op once applied.
-- ---------------------------------------------------------------------------
UPDATE `system_settings`
   SET `setting_value` = 'MONTHLY_BASIC_PLUS_ALLOWANCES'
 WHERE `setting_key` = 'statutory.pagibig_salary_base'
   AND `setting_value` = 'MONTHLY_BASIC';

UPDATE `statutory_schedules`
   SET `salary_base` = 'MONTHLY_BASIC_PLUS_ALLOWANCES'
 WHERE `code` = 'PAGIBIG'
   AND `salary_base` = 'MONTHLY_BASIC';