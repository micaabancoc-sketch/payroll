-- Safe upgrade for company-loan offers and release gates. Backup first.
-- Run once on a V4 test database (not on an unmodified V1 schema).
ALTER TABLE loans
  MODIFY COLUMN status ENUM('PENDING','OFFERED','READY_FOR_RELEASE','ACTIVE','PAID','REJECTED','CANCELLED') NOT NULL DEFAULT 'PENDING',
  ADD COLUMN term_months SMALLINT UNSIGNED NULL AFTER monthly_deduction,
  ADD COLUMN flat_interest_percent DECIMAL(5,2) NOT NULL DEFAULT 0.00 AFTER term_months,
  ADD COLUMN interest_amount DECIMAL(12,2) NOT NULL DEFAULT 0.00 AFTER flat_interest_percent,
  ADD COLUMN terms_offered_at DATETIME NULL AFTER approved_at,
  ADD COLUMN terms_accepted_at DATETIME NULL AFTER terms_offered_at,
  ADD COLUMN released_at DATETIME NULL AFTER terms_accepted_at;
-- Pre-migration ACTIVE and paid loans remain unchanged, with existing balances.
