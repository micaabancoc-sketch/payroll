-- Four-role access migration (non-destructive). BACK UP database first.
-- Code STAFF remains for backwards compatibility with existing accounts and API.
 -- This migration does NOT reset passwords or delete employee, attendance or payroll data.
INSERT INTO roles (code,name,description,permissions,is_system)
VALUES ('HR_PAYROLL','HR / Payroll Staff','Employee records, payroll preparation and statutory processing (no final approval or release)',
        '["dashboard.view","employees.view","employees.create","employees.update","employees.archive","employees.restore","attendance.view","attendance.view_own","attendance.create","attendance.update","attendance.adjust","schedule.view","holiday.view","leave.view","leave.view_own","leave.create","payroll.view","payroll.view_own","payroll.period.view","payroll.period.create","payroll.calculate","payroll.payslip.view","payroll.payslip.view_own","payroll.payments.view","loans.view","loans.create","loans.update","loans.payment","report.payroll","report.attendance","report.leave","report.statutory","remittance.view","remittance.manage"]',1)
ON DUPLICATE KEY UPDATE name=VALUES(name), description=VALUES(description), permissions=VALUES(permissions), is_system=1;
UPDATE roles SET name='Employee / Staff', description='Own attendance, requests, loans and payslips',
permissions='["dashboard.view","attendance.view_own","attendance.scan","leave.view_own","leave.create","leave.cancel_own","overtime.view_own","payroll.view_own","payroll.payslip.view_own","profile.view_own","profile.update_own","loans.create","loans.view_own"]' WHERE code='STAFF';
UPDATE roles SET description='Supervises attendance, assigns OT and approves payroll',
permissions='["dashboard.view","employees.view","attendance.view","attendance.view_own","attendance.create","attendance.update","attendance.adjust","attendance.override","schedule.view","holiday.view","leave.view","leave.view_own","leave.create","leave.approve","overtime.view_own","overtime.create","payroll.view","payroll.view_own","payroll.period.view","payroll.approve","payroll.payslip.view","payroll.payslip.view_own","payroll.payments.view","report.attendance","report.leave","report.payroll"]' WHERE code='MANAGER';
-- Admin retains all-access wildcard. Existing user role_id values do not change.
-- Logout/login after migrating to refresh cached permissions.
