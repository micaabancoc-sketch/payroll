-- ============================================================================
-- SEMI_MONTHLY SALARY TYPE (save & retrieve only, no payroll formula change)
-- Safe for existing databases: extends ENUM, preserves existing rows.
-- Run: mysql -u root attendance_payroll < database/migrations/20261006_semi_monthly_salary_type.sql
-- ============================================================================

ALTER TABLE `employees`
  MODIFY COLUMN `salary_type`
  ENUM('MONTHLY','SEMI_MONTHLY','DAILY','HOURLY')
  NOT NULL DEFAULT 'MONTHLY';

ALTER TABLE `salary_history`
  MODIFY COLUMN `salary_type`
  ENUM('MONTHLY','SEMI_MONTHLY','DAILY','HOURLY')
  NOT NULL DEFAULT 'MONTHLY';
