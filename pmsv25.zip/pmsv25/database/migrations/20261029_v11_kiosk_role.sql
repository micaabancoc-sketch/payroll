-- V11 device-only role: run once in phpMyAdmin for existing V9/V10 DBs.
-- No kiosk credential is seeded: create an individual strong password in User Accounts.
INSERT INTO roles (code, name, description, permissions, is_system)
VALUES ('KIOSK', 'Attendance Kiosk', 'Company-managed scanner device only; not an employee', '["attendance.scan"]', 1)
ON DUPLICATE KEY UPDATE name = VALUES(name), description = VALUES(description), permissions = VALUES(permissions);
