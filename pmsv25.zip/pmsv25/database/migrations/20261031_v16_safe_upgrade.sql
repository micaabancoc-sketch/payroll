-- V16 SAFE NON-DESTRUCTIVE UPGRADE for existing attendance_payroll database
-- Tested syntax target: MariaDB 10.4.32 (as reported by user SQL export).
-- Select attendance_payroll database in phpMyAdmin BEFORE importing.
-- Keep a full backup. NEVER import database/main.sql into the existing database.
-- Does not touch user passwords, QR tokens, historic time scans, salary data, or old loans.

ALTER TABLE `employees`
 ADD COLUMN IF NOT EXISTS `sss_number` VARCHAR(30) NULL,
 ADD COLUMN IF NOT EXISTS `philhealth_number` VARCHAR(30) NULL,
 ADD COLUMN IF NOT EXISTS `pagibig_number` VARCHAR(30) NULL,
 ADD COLUMN IF NOT EXISTS `tin` VARCHAR(30) NULL;

-- For repeatable testing if a prior V13/V14.1 migration was already applied.
ALTER TABLE `overtime_requests`
 ADD COLUMN IF NOT EXISTS `manager_confirmed_by` BIGINT UNSIGNED NULL,
 ADD COLUMN IF NOT EXISTS `manager_confirmed_at` DATETIME NULL,
 ADD COLUMN IF NOT EXISTS `payroll_verified_by` BIGINT UNSIGNED NULL,
 ADD COLUMN IF NOT EXISTS `payroll_verified_at` DATETIME NULL;

-- HR reviewer is a MANAGER-designated user, not a new RBAC role.
INSERT INTO `system_settings` (`setting_key`, `setting_value`, `category`, `label`, `value_type`, `description`, `is_public`)
VALUES ('hr.designated_reviewer_user_id', NULL, 'SECURITY', 'Designated HR Personal Reviewer', 'INT', 'Manager account id, set by IT Admin. Limited to HR personal adjustment review.', 0)
ON DUPLICATE KEY UPDATE `setting_key` = VALUES(`setting_key`);

-- Each finalized payroll loan deduction can be separately tracked for agency remittance.
-- No actual government payments are made by PMS.
CREATE TABLE IF NOT EXISTS `agency_loan_remittances` (
 `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
 `loan_payment_id` BIGINT UNSIGNED NOT NULL,
 `agency` ENUM('SSS','PAGIBIG') NOT NULL,
 `status` ENUM('PENDING','REMITTED') NOT NULL DEFAULT 'PENDING',
 `reference_no` VARCHAR(150) NULL,
 `remitted_on` DATE NULL,
 `recorded_by` BIGINT UNSIGNED NULL,
 `recorded_at` DATETIME NULL,
 `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 PRIMARY KEY(`id`),
 UNIQUE KEY `uq_agency_loan_payment` (`loan_payment_id`),
 INDEX `idx_agency_loan_status` (`agency`,`status`),
 CONSTRAINT `fk_agency_loanpay` FOREIGN KEY (`loan_payment_id`) REFERENCES `loan_payments`(`id`) ON DELETE RESTRICT,
 CONSTRAINT `fk_agency_recorded_by` FOREIGN KEY (`recorded_by`) REFERENCES `users`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Read-only verification: no information_schema needed.
SHOW COLUMNS FROM `employees` WHERE Field IN ('sss_number','philhealth_number','pagibig_number','tin');
SHOW COLUMNS FROM `overtime_requests` WHERE Field IN ('manager_confirmed_by','manager_confirmed_at','payroll_verified_by','payroll_verified_at');
SHOW TABLES LIKE 'agency_loan_remittances';
