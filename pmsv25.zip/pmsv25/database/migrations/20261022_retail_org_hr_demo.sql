-- PMS V6: demo retail organization + HR/Payroll login (NON-DESTRUCTIVE)
-- Run against a BACKED-UP, existing PMS V5 TEST database via phpMyAdmin SQL.
-- Do not run database/main.sql again on an existing database.
-- This script does NOT DROP/TRUNCATE tables and does not change existing employee salaries.
-- Re-running does not reset an existing user's password.
-- Sample salaries are classroom DEMO suggestions, not legal minimum-wage values.
-- The four-role migration (20261022_four_role_access.sql) should be applied first.

START TRANSACTION;

-- Ensure the fourth role exists even on a database missing only the role seed.
INSERT IGNORE INTO roles (code, name, description, permissions, is_system)
VALUES ('HR_PAYROLL', 'HR / Payroll Staff',
        'Employee records and payroll preparation; no payroll approval/release',
        '["dashboard.view","employees.view","employees.create","employees.update","employees.archive","employees.restore","attendance.view","attendance.view_own","attendance.create","attendance.update","attendance.adjust","schedule.view","holiday.view","leave.view","leave.view_own","leave.create","payroll.view","payroll.view_own","payroll.period.view","payroll.period.create","payroll.calculate","payroll.payslip.view","payroll.payslip.view_own","payroll.payments.view","loans.view","loans.create","loans.update","loans.payment","report.payroll","report.attendance","report.leave","report.statutory","remittance.view","remittance.manage"]', 1);

-- Activate existing codes without wiping already-configured salaries or employees.
-- Human Resources, Sales and Operations exist in the V5 seed, but were disabled.
INSERT INTO departments (code, name, description, base_salary, is_active)
VALUES
  ('CASH', 'Cashier', 'Checkout and POS operations', 20000.00, 1),
  ('HR', 'HR & Payroll', 'Employee records and payroll processing', 30000.00, 1),
  ('SALES', 'Sales Floor', 'Sales associates and merchandise display', 21000.00, 1),
  ('STOCK', 'Inventory & Stockroom', 'Stock receiving, storage and inventory', 22000.00, 1),
  ('OPS', 'Store Operations', 'Store supervision and daily coordination', 28000.00, 1)
ON DUPLICATE KEY UPDATE
  is_active = 1,
  deleted_at = NULL,
  base_salary = COALESCE(departments.base_salary, VALUES(base_salary));

-- For old V5 untouched reference names, use retail-facing display names;
-- leave custom department names unchanged.
UPDATE departments SET name='HR & Payroll' WHERE code='HR' AND name='Human Resources';
UPDATE departments SET name='Sales Floor' WHERE code='SALES' AND name='Sales';
UPDATE departments SET name='Store Operations' WHERE code='OPS' AND name='Operations';

-- Seven suggested active job positions across five departments.
-- Existing Cashier position is retained; other generic/legacy positions remain intact.
INSERT INTO positions (code, name, department_id, job_level, description, is_active)
SELECT 'CASHIER', 'Cashier', d.id, 'Staff', 'POS / cash handling', 1 FROM departments d WHERE d.code='CASH'
ON DUPLICATE KEY UPDATE is_active=1, deleted_at=NULL;
INSERT INTO positions (code, name, department_id, job_level, description, is_active)
SELECT 'HEAD-CASH', 'Head Cashier', d.id, 'Supervisor', 'Cashier station oversight', 1 FROM departments d WHERE d.code='CASH'
ON DUPLICATE KEY UPDATE is_active=1, deleted_at=NULL;
INSERT INTO positions (code, name, department_id, job_level, description, is_active)
SELECT 'SALES-ASST', 'Sales Associate', d.id, 'Staff', 'Merchandise sales and display', 1 FROM departments d WHERE d.code='SALES'
ON DUPLICATE KEY UPDATE is_active=1, deleted_at=NULL;
INSERT INTO positions (code, name, department_id, job_level, description, is_active)
SELECT 'STOCK-CLRK', 'Stock Clerk', d.id, 'Staff', 'Receiving and shelf replenishment', 1 FROM departments d WHERE d.code='STOCK'
ON DUPLICATE KEY UPDATE is_active=1, deleted_at=NULL;
INSERT INTO positions (code, name, department_id, job_level, description, is_active)
SELECT 'INV-CTRL', 'Inventory Controller', d.id, 'Staff', 'Stock movement and reconciliation', 1 FROM departments d WHERE d.code='STOCK'
ON DUPLICATE KEY UPDATE is_active=1, deleted_at=NULL;
INSERT INTO positions (code, name, department_id, job_level, description, is_active)
SELECT 'HR-PAY-OFC', 'HR/Payroll Officer', d.id, 'Staff', 'Employee and payroll preparation tasks', 1 FROM departments d WHERE d.code='HR'
ON DUPLICATE KEY UPDATE is_active=1, deleted_at=NULL;
INSERT INTO positions (code, name, department_id, job_level, description, is_active)
SELECT 'STORE-SUP', 'Store Supervisor', d.id, 'Supervisor', 'Floor operations supervision', 1 FROM departments d WHERE d.code='OPS'
ON DUPLICATE KEY UPDATE is_active=1, deleted_at=NULL;

-- Fictional HR employee. Does not reuse any personal details from user screenshots.
-- Skip creation when 'hr' is already an existing login. Never overwrite a real account.
INSERT INTO employees
  (employee_number,first_name,last_name,gender,email,department_id,position_id,
   employment_type,date_hired,salary_type,basic_salary,work_schedule_id,
   status,created_by,notes)
SELECT 'DEMO-HR-001','Demo','HR Payroll','OTHER','demo-hr-payroll@example.test',
       d.id,p.id,'FULL_TIME','2026-01-05','MONTHLY',30000.00,
       (SELECT id FROM work_schedules WHERE code='STD-MF' LIMIT 1),
       'ACTIVE',(SELECT id FROM users WHERE username='admin' LIMIT 1),
       'FICTIONAL HR/Payroll account for offline classroom testing'
  FROM departments d JOIN positions p ON p.department_id=d.id AND p.code='HR-PAY-OFC'
 WHERE d.code='HR'
   AND NOT EXISTS (SELECT 1 FROM employees WHERE employee_number='DEMO-HR-001')
   AND NOT EXISTS (SELECT 1 FROM users WHERE username='hr');

-- Default demo password = Password123@, stored as a bcrypt hash.
-- Login forces the HR demo user to choose a new password immediately.
INSERT INTO users
  (username,email,password_hash,full_name,role_id,employee_id,status,must_change_password)
SELECT 'hr','hrdemo-login@example.test',
       '$2y$10$bTbZ14x7E9Z8AplpFWcc8OOcn6Rf3y2IbJJBLJ.F4p/86oM8YxVBS',
       'Demo HR Payroll',r.id,e.id,'ACTIVE',1
  FROM employees e JOIN roles r ON r.code='HR_PAYROLL'
 WHERE e.employee_number='DEMO-HR-001'
   AND NOT EXISTS (SELECT 1 FROM users WHERE username='hr')
   AND NOT EXISTS (SELECT 1 FROM users WHERE email='hrdemo-login@example.test');

-- Insert initial salary history only once. Preserve original history on rerun.
INSERT INTO salary_history
  (employee_id,salary_type,basic_salary,effective_from,reason,changed_by)
SELECT e.id, 'MONTHLY',30000.00,'2026-01-05',
       'Initial fictional HR demo monthly salary',
       (SELECT id FROM users WHERE username='admin' LIMIT 1)
  FROM employees e
 WHERE e.employee_number='DEMO-HR-001'
   AND NOT EXISTS (SELECT 1 FROM salary_history sh WHERE sh.employee_id=e.id);

COMMIT;

-- Verify (read-only): the HR record should show role HR_PAYROLL and HR & Payroll dept.
SELECT u.username, r.code AS account_role, e.employee_number,
       d.name AS department, p.name AS position, e.basic_salary, u.must_change_password
FROM users u
JOIN roles r ON r.id=u.role_id
LEFT JOIN employees e ON e.id=u.employee_id
LEFT JOIN departments d ON d.id=e.department_id
LEFT JOIN positions p ON p.id=e.position_id
WHERE u.username='hr';
