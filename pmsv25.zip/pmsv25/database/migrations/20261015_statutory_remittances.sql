-- ============================================================================
-- Statutory reports & remittance tracking.
--
-- Registers what payroll_statutory already computed: one remittance per
-- agency and period window with a snapshot of the underlying contribution
-- rows, aggregate totals, and a filing/payment confirmation workflow
-- (OPEN -> SUBMITTED -> PAID). The snapshot rows survive a payroll purge
-- (ON DELETE SET NULL), so a filed remittance always keeps its evidence.
--
-- Idempotent by design: CREATE TABLE IF NOT EXISTS plus JSON grants guarded
-- with JSON_VALID/JSON_CONTAINS, so it can run against any installation.
-- It never drops, truncates or rewrites a remittance.
-- ============================================================================

CREATE TABLE IF NOT EXISTS `statutory_remittances` (
  `id`                 BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `reference_no`       VARCHAR(50)   NOT NULL,
  `agency_code`        VARCHAR(30)   NOT NULL,
  `agency_name`        VARCHAR(150)  NOT NULL,
  `period_start`       DATE          NOT NULL,
  `period_end`         DATE          NOT NULL,
  `due_date`           DATE          NULL,
  `status`             ENUM('OPEN','SUBMITTED','PAID') NOT NULL DEFAULT 'OPEN',
  `employee_count`     INT UNSIGNED  NOT NULL DEFAULT 0,
  `total_employee`     DECIMAL(14,2) NOT NULL DEFAULT 0.00,
  `total_employer`     DECIMAL(14,2) NOT NULL DEFAULT 0.00,
  `total_extra`        DECIMAL(14,2) NOT NULL DEFAULT 0.00,
  `total_amount`       DECIMAL(14,2) NOT NULL DEFAULT 0.00,
  `filing_reference`   VARCHAR(150)  NULL,
  `submitted_by`       BIGINT UNSIGNED NULL,
  `submitted_at`       DATETIME      NULL,
  `paid_reference`     VARCHAR(150)  NULL,
  `paid_date`          DATE          NULL,
  `paid_by`            BIGINT UNSIGNED NULL,
  `paid_at`            DATETIME      NULL,
  `notes`              VARCHAR(500)  NULL,
  `created_by`         BIGINT UNSIGNED NULL,
  `created_at`         DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`         DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_remittance_reference` (`reference_no`),
  UNIQUE KEY `uq_remittance_window` (`agency_code`, `period_start`, `period_end`),
  KEY `idx_remittance_status` (`status`),
  KEY `idx_remittance_period` (`period_start`, `period_end`),
  CONSTRAINT `fk_remittance_creator` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_remittance_submitter` FOREIGN KEY (`submitted_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_remittance_payer` FOREIGN KEY (`paid_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `statutory_remittance_items` (
  `id`                      BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `remittance_id`           BIGINT UNSIGNED NOT NULL,
  `payroll_id`              BIGINT UNSIGNED NULL,
  `payroll_statutory_id`    BIGINT UNSIGNED NULL,
  `payroll_period_id`       BIGINT UNSIGNED NULL,
  `employee_id`             BIGINT UNSIGNED NULL,
  `employee_number`         VARCHAR(50)   NULL,
  `employee_name`           VARCHAR(150)  NULL,
  `code`                    VARCHAR(30)   NOT NULL,
  `line_name`               VARCHAR(150)  NOT NULL,
  `schedule_source`         VARCHAR(500)  NULL,
  `salary_base`             VARCHAR(30)   NULL,
  `credited_base`           DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  `employee_rate`           DECIMAL(9,4)  NULL,
  `employer_rate`           DECIMAL(9,4)  NULL,
  `monthly_employee_amount` DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  `monthly_employer_amount` DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  `employee_amount`         DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  `employer_amount`         DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  `extra_amount`            DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  `period_start`            DATE          NULL,
  `period_end`              DATE          NULL,
  PRIMARY KEY (`id`),
  KEY `idx_remittance_items_remittance` (`remittance_id`),
  KEY `idx_remittance_items_employee` (`employee_id`),
  CONSTRAINT `fk_remittance_item_remittance` FOREIGN KEY (`remittance_id`) REFERENCES `statutory_remittances` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_remittance_item_employee` FOREIGN KEY (`employee_id`) REFERENCES `employees` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_remittance_item_payroll` FOREIGN KEY (`payroll_id`) REFERENCES `payroll` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_remittance_item_statutory` FOREIGN KEY (`payroll_statutory_id`) REFERENCES `payroll_statutory` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_remittance_item_period` FOREIGN KEY (`payroll_period_id`) REFERENCES `payroll_periods` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- MANAGER gains the statutory report and remittance permissions, exactly like
-- the payroll-payments migration did for its three keys. Each UPDATE is
-- guarded by NOT JSON_CONTAINS so a rerun, or an install that already has
-- some of them, never duplicates an entry.
UPDATE `roles` SET `permissions` = JSON_ARRAY_APPEND(`permissions`, '$', 'report.statutory')
 WHERE `code` = 'MANAGER' AND JSON_VALID(`permissions`) AND NOT JSON_CONTAINS(`permissions`, '"report.statutory"');

UPDATE `roles` SET `permissions` = JSON_ARRAY_APPEND(`permissions`, '$', 'remittance.view')
 WHERE `code` = 'MANAGER' AND JSON_VALID(`permissions`) AND NOT JSON_CONTAINS(`permissions`, '"remittance.view"');

UPDATE `roles` SET `permissions` = JSON_ARRAY_APPEND(`permissions`, '$', 'remittance.manage')
 WHERE `code` = 'MANAGER' AND JSON_VALID(`permissions`) AND NOT JSON_CONTAINS(`permissions`, '"remittance.manage"');