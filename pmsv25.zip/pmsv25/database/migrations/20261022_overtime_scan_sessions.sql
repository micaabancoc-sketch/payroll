-- Separate overtime scans for the standard 5:30PM-9:30PM policy.
-- Back up first and apply on a V4/V5 test database, only once.
CREATE TABLE IF NOT EXISTS overtime_scans (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  overtime_request_id BIGINT UNSIGNED NOT NULL,
  employee_id BIGINT UNSIGNED NOT NULL,
  ot_time_in DATETIME NOT NULL,
  ot_time_out DATETIME NULL,
  payable_minutes INT UNSIGNED NOT NULL DEFAULT 0,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY(id),
  UNIQUE KEY uq_ot_scan_request(overtime_request_id),
  KEY idx_ot_scan_employee(employee_id),
  CONSTRAINT fk_ot_scan_request FOREIGN KEY(overtime_request_id) REFERENCES overtime_requests(id) ON DELETE CASCADE,
  CONSTRAINT fk_ot_scan_emp FOREIGN KEY(employee_id) REFERENCES employees(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
ALTER TABLE attendance_logs MODIFY event_type
 ENUM('TIME_IN','TIME_OUT','OT_TIME_IN','OT_TIME_OUT','REJECTED','MANUAL','QR_REGENERATED','QR_DISABLED','ADJUSTED') NOT NULL;
