-- PMS V13: Execute ONCE on the EXISTING PMS database in phpMyAdmin.
-- Backup the database first. Do NOT re-import database/main.sql.
-- Historical APPROVED rows and applied_hours are preserved.
ALTER TABLE overtime_requests
  ADD COLUMN manager_confirmed_by BIGINT UNSIGNED NULL,
  ADD COLUMN manager_confirmed_at DATETIME NULL,
  ADD COLUMN payroll_verified_by BIGINT UNSIGNED NULL,
  ADD COLUMN payroll_verified_at DATETIME NULL;

CREATE INDEX idx_ot_manager_confirmed ON overtime_requests (manager_confirmed_at);
CREATE INDEX idx_ot_payroll_verified ON overtime_requests (payroll_verified_at);
