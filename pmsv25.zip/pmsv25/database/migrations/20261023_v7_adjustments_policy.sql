-- V7 upgrade: non-destructive. BACK UP the database before running.
-- Apply after previous V5/V6 migrations, NOT together with main.sql on populated databases.
CREATE TABLE IF NOT EXISTS payroll_adjustments (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  employee_id BIGINT UNSIGNED NOT NULL,
  payroll_period_id BIGINT UNSIGNED NOT NULL,
  kind ENUM('EARNING','DEDUCTION') NOT NULL,
  amount DECIMAL(12,2) NOT NULL,
  reason VARCHAR(500) NOT NULL,
  status ENUM('PENDING','APPROVED','REJECTED') NOT NULL DEFAULT 'PENDING',
  request_key CHAR(64) NOT NULL,
  created_by BIGINT UNSIGNED NOT NULL,
  approved_by BIGINT UNSIGNED NULL,
  approved_at DATETIME NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uq_payadj_request (request_key),
  KEY idx_payadj_period_emp (payroll_period_id,employee_id,status),
  CONSTRAINT fk_payadj_employee FOREIGN KEY (employee_id) REFERENCES employees(id),
  CONSTRAINT fk_payadj_period FOREIGN KEY (payroll_period_id) REFERENCES payroll_periods(id),
  CONSTRAINT fk_payadj_creator FOREIGN KEY (created_by) REFERENCES users(id),
  CONSTRAINT fk_payadj_approver FOREIGN KEY (approved_by) REFERENCES users(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Salary frequency is kinsenas for everyone. Legacy SEMI_MONTHLY rows are
-- interpreted as MONTHLY salary by V7, so no payroll history is rewritten.
INSERT INTO system_settings (`setting_key`, `setting_value`, `category`, `label`, `value_type`, `description`, `is_public`)
VALUES ('attendance.allow_scan_on_rest_day','0','ATTENDANCE','Allow Rest Day Scans','BOOLEAN','Disabled by default; rest-day actual work must be Manager verified and paid separately',0)
ON DUPLICATE KEY UPDATE setting_value='0';
-- DO NOT retroactively update paid payroll or alter government schedules.

-- Default 313 is for a six-day workweek arrangement, unpaid Sundays,
-- with specific legal paid-holiday assumptions. Five-day workweek or different
-- holiday arrangements require verifying and configuring the correct divisor.
-- Do not silently modify the existing 365 setting: HR/Admin must review it.

-- New reference settings are inserted only if absent. They do not overwrite
-- manually confirmed payroll configurations. Review with HR before payouts.
INSERT IGNORE INTO system_settings
 (`setting_key`,`setting_value`,`category`,`label`,`value_type`,`description`,`is_public`)
VALUES
 ('payroll.rest_days_paid','0','PAYROLL','Unworked Rest Days Paid in Daily Rate','BOOLEAN','0: derive factor from assigned 5/6-day schedule; review contract',0),
 ('payroll.unpaid_rest_5day_divisor','261','PAYROLL','5-day Rest-Unpaid Annual Divisor','DECIMAL','NWPC example; validate holidays and actual contract',0),
 ('payroll.unpaid_rest_6day_divisor','313','PAYROLL','6-day Rest-Unpaid Annual Divisor','DECIMAL','NWPC example; validate holidays and actual contract',0);
