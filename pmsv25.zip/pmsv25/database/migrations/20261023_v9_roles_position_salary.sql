-- PMS V9 additive migration. BACK UP your existing DB first. Run ONCE after V7/V8 migrations.
-- Never reimport main.sql into a populated database.
ALTER TABLE positions ADD COLUMN base_salary DECIMAL(12,2) NULL DEFAULT NULL;
-- HR gets loan approval; Admin already has wildcard for release and is checked by service roleCode.
-- JSON_ARRAY_APPEND and JSON_SEARCH operate on the stored JSON text (MySQL 8 / MariaDB 10.4).
UPDATE roles SET permissions = JSON_ARRAY_APPEND(permissions, '$', 'loans.approve')
 WHERE code='HR_PAYROLL' AND JSON_VALID(permissions)=1
   AND JSON_SEARCH(permissions, 'one', 'loans.approve') IS NULL;
-- Keep all existing employee, payroll and leave history unchanged.
INSERT INTO system_settings (setting_key,setting_value,category,label,value_type,description,is_public)
 VALUES ('attendance.late_cutoff_minutes','60','ATTENDANCE','Late cutoff in minutes','INT','Standard 8 AM shift allows 7 AM to 9:00:59, absent from 9:01 AM',0)
 ON DUPLICATE KEY UPDATE setting_value='60';
INSERT INTO system_settings (setting_key,setting_value,category,label,value_type,description,is_public)
 VALUES ('attendance.auto_absence','1','ATTENDANCE','Automatic Absence','BOOLEAN','Requires running CLI reconciler on schedule',0)
 ON DUPLICATE KEY UPDATE setting_value='1';
INSERT INTO system_settings (setting_key,setting_value,category,label,value_type,description,is_public)
 VALUES ('attendance.allow_scan_on_rest_day','0','ATTENDANCE','Rest Day Scan','BOOLEAN','Regular rest day scan blocked; verified actual work recorded separately',0)
 ON DUPLICATE KEY UPDATE setting_value='0';

-- Zero automatic expiration for valid issued employee QR codes. Invalidated/replaced codes stay invalid.
INSERT INTO system_settings (setting_key,setting_value,category,label,value_type,description,is_public)
 VALUES ('qr.token_expiry_days','0','ATTENDANCE','Employee QR expiry days','INT','0 means active QR does not expire automatically; Admin can revoke/regenerate',0)
 ON DUPLICATE KEY UPDATE setting_value='0';
UPDATE employee_qr_codes SET expires_at=NULL WHERE status='ACTIVE';
-- Equal half-month allocation for mandatory employee contributions; tax still uses BIR semi-monthly tables.
INSERT INTO system_settings (setting_key,setting_value,category,label,value_type,description,is_public)
 VALUES ('statutory.allocation_basis','EQUAL_SPLIT','PAYROLL','Monthly Contribution Allocation','STRING','Exact monthly government contribution is split across two cutoffs',0)
 ON DUPLICATE KEY UPDATE setting_value='EQUAL_SPLIT';
