-- 30-minute late cut-off + automatic absence settings (idempotent).
--
-- INSERT IGNORE keeps any value an administrator has already chosen, so the
-- migration is safe to run on every deploy and after a fresh main.sql import.
INSERT IGNORE INTO `system_settings`
(`setting_key`, `setting_value`, `category`, `label`, `value_type`, `description`, `is_public`) VALUES
('attendance.late_cutoff_minutes', '30', 'ATTENDANCE', 'Time-In Cut-off After Shift Start (minutes)', 'INT', 'Time-in is denied and the day marked ABSENT once this many minutes past the scheduled start', 0),
('attendance.auto_absence', '1', 'ATTENDANCE', 'Automatic Absence After Cut-off', 'BOOLEAN', 'The reconciler marks ABSENT once the cut-off passes with no valid time-in', 0);