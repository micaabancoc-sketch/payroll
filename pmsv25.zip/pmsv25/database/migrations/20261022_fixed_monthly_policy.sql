-- Safe V5 setting migration: never drops user tables or payroll history.
-- Assumes system_settings schema from the current V4 database.
INSERT INTO system_settings (`setting_key`, `setting_value`, `category`, `label`, `value_type`, `description`, `is_public`)
SELECT 'payroll.annual_paid_day_divisor', '365', 'PAYROLL',
       'Annual Paid-Day Divisor', 'DECIMAL',
       'For fully monthly-paid employees only; confirm paid rest-day and holiday coverage', 0
WHERE NOT EXISTS (SELECT 1 FROM system_settings WHERE `setting_key` = 'payroll.annual_paid_day_divisor');
