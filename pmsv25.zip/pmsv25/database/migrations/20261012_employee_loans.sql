-- ============================================================================
-- Employee loans & repayment ledger (Phase 3)
--
-- Brings an installation that was imported before the loans module existed in
-- line with database/main.sql:
--
--   loans          + reference_no, notes, approved_by, approved_at
--                  + UNIQUE reference_no, FK approved_by -> users
--   loans          + rejection_reason, and a status ENUM widened with PENDING
--                    and REJECTED: a loan is filed, decided and only then
--                    deducted, and it can never be decided by the user who
--                    filed it (Phase 3B)
--   loan_payments  + period_id, payment_type, remarks, created_by
--                  + KEY (period_id), FK created_by -> users
--                  + UNIQUE (period_id, loan_id) so the PAID transition can
--                    never record the same payroll repayment twice (Phase 3A)
--   roles          + loans.view / loans.create / loans.update / loans.payment /
--                    loans.approve appended to MANAGER (ADMIN holds the "*"
--                    wildcard)
--
-- Every statement is repeatable through database/migrate_employee_loans.php: a
-- repeated column, key or constraint raises "Duplicate ... name" and the
-- runner reports it as already in place. Nothing is dropped, truncated or
-- reset, no loan balance is recomputed and no payroll row is touched - the
-- existing loans and their repayments keep their figures.
--
-- `loan_payments.period_id` is indexed but deliberately carries no foreign key:
-- the loans section of main.sql is declared before payroll_periods, and the
-- pre-existing ledger pointer `loan_payments.payroll_id` has no foreign key
-- either. Keeping the two files identical matters more than the constraint.
-- ============================================================================

ALTER TABLE `loans`
  ADD COLUMN `reference_no` VARCHAR(50)  NULL AFTER `loan_type`,
  ADD COLUMN `notes`        VARCHAR(255) NULL AFTER `status`,
  ADD COLUMN `approved_by`  BIGINT UNSIGNED NULL AFTER `created_by`,
  ADD COLUMN `approved_at`  DATETIME NULL AFTER `approved_by`;

ALTER TABLE `loans`
  ADD UNIQUE KEY `uq_loans_reference` (`reference_no`);

ALTER TABLE `loans`
  ADD CONSTRAINT `fk_loans_approver` FOREIGN KEY (`approved_by`) REFERENCES `users` (`id`) ON DELETE SET NULL;

-- Phase 3B: a loan is filed PENDING and only an approver - never the user who
-- filed it - turns it ACTIVE, or stops it by REJECTING it with a reason.
--
-- MODIFY is repeatable: re-applying the identical ENUM list is a no-op, and
-- every value the old ENUM allowed (ACTIVE, PAID, CANCELLED) is still valid, so
-- no existing loan changes status. The default only affects future inserts that
-- omit the column, and LoanService always states the status explicitly.
ALTER TABLE `loans`
  MODIFY COLUMN `status` ENUM('PENDING','ACTIVE','PAID','REJECTED','CANCELLED') NOT NULL DEFAULT 'PENDING';

ALTER TABLE `loans`
  ADD COLUMN `rejection_reason` VARCHAR(255) NULL AFTER `status`;

ALTER TABLE `loan_payments`
  ADD COLUMN `period_id`    BIGINT UNSIGNED NULL AFTER `payroll_id`,
  ADD COLUMN `payment_type` ENUM('PAYROLL','MANUAL','ADJUSTMENT') NOT NULL DEFAULT 'MANUAL' AFTER `amount`,
  ADD COLUMN `remarks`      VARCHAR(255) NULL AFTER `paid_at`,
  ADD COLUMN `created_by`   BIGINT UNSIGNED NULL AFTER `remarks`;

ALTER TABLE `loan_payments`
  ADD KEY `idx_loanpay_period` (`period_id`);

ALTER TABLE `loan_payments`
  ADD CONSTRAINT `fk_loanpay_user` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL;

-- Phase 3A idempotency safeguard: one PAYROLL repayment per (period, loan).
-- Manual rows carry a NULL period_id, which MySQL's unique-key rules treat as
-- distinct, so they are untouched by this constraint.
ALTER TABLE `loan_payments`
  ADD UNIQUE KEY `uq_loanpay_period_loan` (`period_id`, `loan_id`);

-- The four loan permissions, appended once. JSON_ARRAY_APPEND keeps the
-- existing entries and the NOT JSON_CONTAINS guard makes a second run a no-op.
UPDATE `roles`
   SET `permissions` = JSON_ARRAY_APPEND(
           `permissions`, '$', 'loans.view', '$', 'loans.create', '$', 'loans.update', '$', 'loans.payment')
 WHERE `code` = 'MANAGER'
   AND JSON_VALID(`permissions`)
   AND NOT JSON_CONTAINS(`permissions`, '"loans.view"');

-- Phase 3B approval permission, appended in its own statement: the UPDATE above
-- is skipped the moment an install already carries loans.view, which would
-- otherwise leave the new entry unappended. The guard makes a re-run a no-op.
UPDATE `roles`
   SET `permissions` = JSON_ARRAY_APPEND(`permissions`, '$', 'loans.approve')
 WHERE `code` = 'MANAGER'
   AND JSON_VALID(`permissions`)
   AND NOT JSON_CONTAINS(`permissions`, '"loans.approve"');
-- STAFF may view and file their own loans only. They must not approve,
-- update, or record repayments on loans. Each permission is guarded
-- independently so a missing loans.create is still granted even when
-- loans.view already exists. The NOT JSON_CONTAINS guard makes each
-- statement a no-op on re-run, so the migration is safely repeatable.
UPDATE `roles`
   SET `permissions` = JSON_ARRAY_APPEND(`permissions`, '$', 'loans.view')
 WHERE `code` = 'STAFF'
   AND JSON_VALID(`permissions`)
   AND NOT JSON_CONTAINS(`permissions`, '"loans.view"');

UPDATE `roles`
   SET `permissions` = JSON_ARRAY_APPEND(`permissions`, '$', 'loans.create')
 WHERE `code` = 'STAFF'
   AND JSON_VALID(`permissions`)
   AND NOT JSON_CONTAINS(`permissions`, '"loans.create"');

