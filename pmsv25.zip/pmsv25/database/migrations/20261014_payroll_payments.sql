-- ============================================================================
-- Individual payroll payments & disbursement ledger (Phase 5)
-- See database/main.sql SECTION 8D mirror for the full documentation block.
-- ============================================================================

-- --- Disbursement ledger ----------------------------------------------------

CREATE TABLE IF NOT EXISTS `payroll_payments` (
    `id`                 BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    `payroll_id`         BIGINT UNSIGNED NOT NULL COMMENT 'FK to payroll.id - one employee row',
    `payroll_period_id`  BIGINT UNSIGNED NOT NULL COMMENT 'denormalised FK to payroll_periods.id',
    `employee_id`        BIGINT UNSIGNED NOT NULL COMMENT 'denormalised FK to employees.id',
    `reference_no`       VARCHAR(50) NOT NULL COMMENT 'Human reference, for example PAY-20261014-AB12CD',
    `idempotency_key`    VARCHAR(64) NULL COMMENT 'Client key - retries return the original row',
    `amount`             DECIMAL(12,2) NOT NULL COMMENT 'Disbursed (or attempted) amount in pesos',
    `payment_method`     ENUM('CASH','BANK_TRANSFER','GCASH','OTHER') NOT NULL DEFAULT 'CASH',
    `method_reference`   VARCHAR(150) NULL COMMENT 'Bank / wallet / receipt reference when available',
    `payment_status`     ENUM('PENDING','COMPLETED','FAILED','CANCELLED') NOT NULL DEFAULT 'COMPLETED',
    `payment_date`       DATE NULL COMMENT 'Business date of the disbursement (defaults to today)',
    `paid_at`            DATETIME NULL COMMENT 'Timestamp the disbursement was confirmed',
    `recorded_by`        BIGINT UNSIGNED NULL COMMENT 'FK -> users.id who confirmed it',
    `cancelled_by`       BIGINT UNSIGNED NULL COMMENT 'FK -> users.id who cancelled it',
    `cancelled_at`       DATETIME NULL,
    `cancel_reason`      VARCHAR(255) NULL,
    `notes`              VARCHAR(500) NULL,
    `created_at`         DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at`         DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uq_payrollpay_ref` (`reference_no`),
    UNIQUE KEY `uq_payrollpay_idem` (`idempotency_key`),
    KEY `idx_payrollpay_payroll` (`payroll_id`, `payment_status`),
    KEY `idx_payrollpay_period` (`payroll_period_id`, `payment_status`),
    KEY `idx_payrollpay_employee` (`employee_id`),
    KEY `idx_payrollpay_status` (`payment_status`),
    CONSTRAINT `fk_payrollpay_payroll` FOREIGN KEY (`payroll_id`) REFERENCES `payroll` (`id`) ON DELETE CASCADE,
    CONSTRAINT `fk_payrollpay_period` FOREIGN KEY (`payroll_period_id`) REFERENCES `payroll_periods` (`id`) ON DELETE CASCADE,
    CONSTRAINT `fk_payrollpay_emp` FOREIGN KEY (`employee_id`) REFERENCES `employees` (`id`) ON DELETE CASCADE,
    CONSTRAINT `fk_payrollpay_recorder` FOREIGN KEY (`recorded_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
    CONSTRAINT `fk_payrollpay_canceller` FOREIGN KEY (`cancelled_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --- Cached aggregates on each payroll row ----------------------------------
-- amount_paid / payment_status are maintained by PayrollPaymentService inside
-- the same transaction that writes the ledger, so period-completion checks are
-- a cheap indexed read instead of a SUM over the ledger on every transition.

ALTER TABLE `payroll`
  ADD COLUMN `amount_paid` DECIMAL(12,2) NOT NULL DEFAULT 0.00 AFTER `net_pay`,
  ADD COLUMN `payment_status` ENUM('UNPAID','PARTIAL','PAID') NOT NULL DEFAULT 'UNPAID' AFTER `amount_paid`;

ALTER TABLE `payroll`
  ADD KEY `idx_payroll_paystatus` (`payment_status`);

-- --- Backfill (idempotent: re-running re-applies the same values) -----------
-- Zero-net rows need no disbursement in any period status.
UPDATE `payroll`
   SET `amount_paid` = 0.00, `payment_status` = 'PAID'
 WHERE `net_pay` <= 0;

-- Rows in periods already marked PAID were considered fully disbursed before
-- the ledger existed. Mark them PAID without fabricating ledger rows.
UPDATE `payroll` p
  JOIN `payroll_periods` pp ON pp.id = p.payroll_period_id
   SET p.`amount_paid` = GREATEST(p.`net_pay`, 0.00),
       p.`payment_status` = 'PAID'
 WHERE pp.`status` = 'PAID'
   AND p.`net_pay` > 0;

-- --- Role permissions (appended once, re-runs are no-ops) -------------------

UPDATE `roles`
   SET `permissions` = JSON_ARRAY_APPEND(
           `permissions`, '$', 'payroll.payments.view', '$', 'payroll.payments.record', '$', 'payroll.payments.cancel')
 WHERE `code` = 'MANAGER'
   AND JSON_VALID(`permissions`)
   AND NOT JSON_CONTAINS(`permissions`, '"payroll.payments.view"');

UPDATE `roles`
   SET `permissions` = JSON_ARRAY_APPEND(`permissions`, '$', 'payroll.payments.record')
 WHERE `code` = 'MANAGER'
   AND JSON_VALID(`permissions`)
   AND NOT JSON_CONTAINS(`permissions`, '"payroll.payments.record"');

UPDATE `roles`
   SET `permissions` = JSON_ARRAY_APPEND(`permissions`, '$', 'payroll.payments.cancel')
 WHERE `code` = 'MANAGER'
   AND JSON_VALID(`permissions`)
   AND NOT JSON_CONTAINS(`permissions`, '"payroll.payments.cancel"');

