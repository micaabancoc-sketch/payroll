-- ============================================================================
-- REST DAY SWAP / EXCHANGE WORKFLOW
--
-- Employees can request to exchange their scheduled rest day with another
-- employee. The flow:
--   1. Requester submits a swap request (PENDING)
--   2. Other employee ACCEPTs or DECLINEs
--   3. Manager/admin APPROVEs or REJECTs after both consent
--   4. On approval, employee work_schedule_id is updated so attendance and
--      payroll use the correct effective schedule for the exchanged dates
--
-- Safe for existing databases: idempotent, preserves all existing data.
-- Run: mysql -u root -p attendance_payroll < database/migrations/20261016_rest_day_swaps.sql
-- ============================================================================

-- 1. Create the rest_day_swaps table (idempotent via CREATE TABLE IF NOT EXISTS).
CREATE TABLE IF NOT EXISTS `rest_day_swaps` (
  `id`                     BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `requester_id`           BIGINT UNSIGNED NOT NULL,
  `other_employee_id`      BIGINT UNSIGNED NOT NULL,
  `requester_original_dow` TINYINT UNSIGNED NOT NULL, -- day_of_week 0=Sun..6=Sat
  `other_original_dow`     TINYINT UNSIGNED NOT NULL, -- day_of_week 0=Sun..6=Sat
  `effective_date`         DATE         NOT NULL,     -- date the swap takes effect
  `reason`                 VARCHAR(500) NOT NULL,
  `other_consent`          ENUM('PENDING','ACCEPTED','DECLINED') NOT NULL DEFAULT 'PENDING',
  `manager_decision`       ENUM('PENDING','APPROVED','REJECTED') NOT NULL DEFAULT 'PENDING',
  `manager_id`             BIGINT UNSIGNED NULL,
  `manager_remarks`        VARCHAR(500) NULL,
  `decided_at`             DATETIME     NULL,
  `status`                 ENUM('PENDING','APPROVED','REJECTED','CANCELLED','COMPLETED') NOT NULL DEFAULT 'PENDING',
  `created_at`             DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`             DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted_at`             DATETIME     NULL,
  PRIMARY KEY (`id`),
  KEY `idx_swap_requester`  (`requester_id`, `status`),
  KEY `idx_swap_other`      (`other_employee_id`, `status`),
  KEY `idx_swap_effective`  (`effective_date`, `status`),
  KEY `idx_swap_status`     (`status`),
  CONSTRAINT `fk_swap_requester` FOREIGN KEY (`requester_id`) REFERENCES `employees` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_swap_other`     FOREIGN KEY (`other_employee_id`) REFERENCES `employees` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_swap_manager`   FOREIGN KEY (`manager_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 2. Role permissions for rest day swap workflow.
--    ADMIN ("*") is untouched.
--    MANAGER: can approve/reject, view all swaps.
--    STAFF: can create swaps, respond to own swaps, view own swaps.
DELIMITER $$

DROP PROCEDURE IF EXISTS `pms_rds_perm`$$

CREATE PROCEDURE `pms_rds_perm`()
BEGIN
  -- MANAGER: grant rest_day_swap.approve if missing.
  IF NOT EXISTS (
    SELECT 1 FROM `roles`
    WHERE `code` = 'MANAGER'
      AND JSON_CONTAINS(`permissions`, '\"rest_day_swap.approve\"')
  ) THEN
    UPDATE `roles`
       SET `permissions` = JSON_ARRAY_APPEND(`permissions`, '$', 'rest_day_swap.approve')
     WHERE `code` = 'MANAGER';
  END IF;

  -- MANAGER: grant rest_day_swap.view if missing.
  IF NOT EXISTS (
    SELECT 1 FROM `roles`
    WHERE `code` = 'MANAGER'
      AND JSON_CONTAINS(`permissions`, '\"rest_day_swap.view\"')
  ) THEN
    UPDATE `roles`
       SET `permissions` = JSON_ARRAY_APPEND(`permissions`, '$', 'rest_day_swap.view')
     WHERE `code` = 'MANAGER';
  END IF;

  -- STAFF: grant rest_day_swap.create if missing.
  IF NOT EXISTS (
    SELECT 1 FROM `roles`
    WHERE `code` = 'STAFF'
      AND JSON_CONTAINS(`permissions`, '\"rest_day_swap.create\"')
  ) THEN
    UPDATE `roles`
       SET `permissions` = JSON_ARRAY_APPEND(`permissions`, '$', 'rest_day_swap.create')
     WHERE `code` = 'STAFF';
  END IF;

  -- STAFF: grant rest_day_swap.view_own if missing.
  IF NOT EXISTS (
    SELECT 1 FROM `roles`
    WHERE `code` = 'STAFF'
      AND JSON_CONTAINS(`permissions`, '\"rest_day_swap.view_own\"')
  ) THEN
    UPDATE `roles`
       SET `permissions` = JSON_ARRAY_APPEND(`permissions`, '$', 'rest_day_swap.view_own')
     WHERE `code` = 'STAFF';
  END IF;
END$$

DELIMITER ;

CALL `pms_rds_perm`();
DROP PROCEDURE IF EXISTS `pms_rds_perm`;

-- 3. Index for preventing overlapping swap requests on the same employee/date.
--    (CREATE INDEX has no IF NOT EXISTS on older MariaDB, so guard it.)
DELIMITER $$

DROP PROCEDURE IF EXISTS `pms_rds_index`$$

CREATE PROCEDURE `pms_rds_index`()
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.STATISTICS
    WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'rest_day_swaps'
      AND INDEX_NAME = 'idx_swap_emp_date'
  ) THEN
    ALTER TABLE `rest_day_swaps`
      ADD INDEX `idx_swap_emp_date` (`requester_id`, `effective_date`, `status`);
  END IF;
END$$

DELIMITER ;

CALL `pms_rds_index`();
DROP PROCEDURE IF EXISTS `pms_rds_index`;
