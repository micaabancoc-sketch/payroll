-- PMS V25 NEW CLEAN DATABASE (SCHEMA ONLY)
-- Created from the uploaded full V23-compatible schema used by the V25 project.
-- Separate new database: attendance_payroll_v25_clean
-- All 45 tables, indexes, and foreign keys are present; ZERO stored records.
-- NO old employees, attendance, loans, payroll, payslips, activity logs, or users.
-- This file is NOT an upgrade or migration for your existing database.
-- Import into a NEW, EMPTY database only. Rerunning can fail with existing-table errors.
-- IMPORTANT: without user accounts/master settings the web app cannot log in.

CREATE DATABASE IF NOT EXISTS `attendance_payroll_v25_clean`
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `attendance_payroll_v25_clean`;

-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 03, 2027 at 06:15 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `attendance_payroll_v25_clean`
--

-- --------------------------------------------------------

--
-- Table structure for table `agency_loan_remittances`
--

CREATE TABLE `agency_loan_remittances` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `loan_payment_id` bigint(20) UNSIGNED NOT NULL,
  `agency` enum('SSS','PAGIBIG') NOT NULL,
  `status` enum('PENDING','REMITTED') NOT NULL DEFAULT 'PENDING',
  `reference_no` varchar(150) DEFAULT NULL,
  `remitted_on` date DEFAULT NULL,
  `recorded_by` bigint(20) UNSIGNED DEFAULT NULL,
  `recorded_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `allowances`
--

CREATE TABLE `allowances` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `code` varchar(50) NOT NULL,
  `name` varchar(150) NOT NULL,
  `amount` decimal(12,2) NOT NULL DEFAULT 0.00,
  `is_percentage` tinyint(1) NOT NULL DEFAULT 0,
  `is_recurring` tinyint(1) NOT NULL DEFAULT 1,
  `frequency` enum('PERIOD','MONTHLY') NOT NULL DEFAULT 'PERIOD',
  `effective_from` date DEFAULT NULL,
  `effective_to` date DEFAULT NULL,
  `category` varchar(50) DEFAULT NULL,
  `is_taxable` tinyint(1) NOT NULL DEFAULT 1,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_by` bigint(20) UNSIGNED DEFAULT NULL,
  `updated_by` bigint(20) UNSIGNED DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `deleted_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Empty by design: no historical rows
--


-- --------------------------------------------------------

--
-- Table structure for table `api_tokens`
--

CREATE TABLE `api_tokens` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `token_hash` char(64) NOT NULL,
  `expires_at` datetime NOT NULL,
  `last_used_at` datetime DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` varchar(255) DEFAULT NULL,
  `is_revoked` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Empty by design: no historical rows
--


-- --------------------------------------------------------

--
-- Table structure for table `attendance`
--

CREATE TABLE `attendance` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `employee_id` bigint(20) UNSIGNED NOT NULL,
  `attendance_date` date NOT NULL,
  `shift_id` bigint(20) UNSIGNED DEFAULT NULL,
  `work_schedule_id` bigint(20) UNSIGNED DEFAULT NULL,
  `time_in` datetime DEFAULT NULL,
  `time_out` datetime DEFAULT NULL,
  `scheduled_start` time DEFAULT NULL,
  `scheduled_end` time DEFAULT NULL,
  `worked_hours` decimal(6,2) NOT NULL DEFAULT 0.00,
  `late_minutes` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `undertime_minutes` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `overtime_hours` decimal(6,2) NOT NULL DEFAULT 0.00,
  `status` enum('PRESENT','LATE','ABSENT','UNDERTIME','REST_DAY','HOLIDAY','LEAVE','INCOMPLETE','DAY_OFF') NOT NULL DEFAULT 'PRESENT',
  `is_rest_day` tinyint(1) NOT NULL DEFAULT 0,
  `is_holiday` tinyint(1) NOT NULL DEFAULT 0,
  `leave_request_id` bigint(20) UNSIGNED DEFAULT NULL,
  `source` enum('QR','MANUAL','AUTO','IMPORT') NOT NULL DEFAULT 'QR',
  `remarks` varchar(255) DEFAULT NULL,
  `adjusted_by` bigint(20) UNSIGNED DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `deleted_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Empty by design: no historical rows
--


-- --------------------------------------------------------

--
-- Table structure for table `attendance_logs`
--

CREATE TABLE `attendance_logs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `attendance_id` bigint(20) UNSIGNED DEFAULT NULL,
  `employee_id` bigint(20) UNSIGNED DEFAULT NULL,
  `event_type` enum('TIME_IN','TIME_OUT','OT_TIME_IN','OT_TIME_OUT','REJECTED','MANUAL','QR_REGENERATED','QR_DISABLED','ADJUSTED') NOT NULL,
  `scanned_at` datetime NOT NULL DEFAULT current_timestamp(),
  `qr_code_id` bigint(20) UNSIGNED DEFAULT NULL,
  `result` enum('SUCCESS','FAILED') NOT NULL DEFAULT 'SUCCESS',
  `message` varchar(255) DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` varchar(255) DEFAULT NULL,
  `recorded_by` bigint(20) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Empty by design: no historical rows
--


-- --------------------------------------------------------

--
-- Table structure for table `audit_logs`
--

CREATE TABLE `audit_logs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `username` varchar(100) DEFAULT NULL,
  `action` varchar(100) NOT NULL,
  `entity_type` varchar(50) DEFAULT NULL,
  `entity_id` varchar(50) DEFAULT NULL,
  `description` varchar(500) DEFAULT NULL,
  `old_value` longtext DEFAULT NULL,
  `new_value` longtext DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` varchar(255) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Empty by design: no historical rows
--


-- --------------------------------------------------------

--
-- Table structure for table `bir_withholding_brackets`
--

CREATE TABLE `bir_withholding_brackets` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `schedule_id` bigint(20) UNSIGNED NOT NULL,
  `bracket_order` int(10) UNSIGNED NOT NULL,
  `compensation_from` decimal(12,2) NOT NULL DEFAULT 0.00,
  `compensation_to` decimal(12,2) DEFAULT NULL,
  `base_tax` decimal(12,2) NOT NULL DEFAULT 0.00,
  `excess_rate` decimal(9,4) NOT NULL DEFAULT 0.0000,
  `excess_over` decimal(12,2) NOT NULL DEFAULT 0.00,
  `notes` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Empty by design: no historical rows
--


-- --------------------------------------------------------

--
-- Table structure for table `bir_withholding_schedules`
--

CREATE TABLE `bir_withholding_schedules` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `frequency` enum('DAILY','WEEKLY','SEMI_MONTHLY','MONTHLY') NOT NULL,
  `effective_from` date NOT NULL,
  `effective_to` date DEFAULT NULL,
  `source_name` varchar(255) DEFAULT NULL,
  `source_url` varchar(500) DEFAULT NULL,
  `notes` varchar(500) DEFAULT NULL,
  `status` enum('ACTIVE','INACTIVE') NOT NULL DEFAULT 'ACTIVE',
  `created_by` bigint(20) UNSIGNED DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Empty by design: no historical rows
--


-- --------------------------------------------------------

--
-- Table structure for table `deductions`
--

CREATE TABLE `deductions` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `code` varchar(50) NOT NULL,
  `name` varchar(150) NOT NULL,
  `amount` decimal(12,2) NOT NULL DEFAULT 0.00,
  `is_percentage` tinyint(1) NOT NULL DEFAULT 0,
  `is_recurring` tinyint(1) NOT NULL DEFAULT 1,
  `frequency` enum('PERIOD','MONTHLY') NOT NULL DEFAULT 'PERIOD',
  `effective_from` date DEFAULT NULL,
  `effective_to` date DEFAULT NULL,
  `category` varchar(50) DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_by` bigint(20) UNSIGNED DEFAULT NULL,
  `updated_by` bigint(20) UNSIGNED DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `deleted_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Empty by design: no historical rows
--


-- --------------------------------------------------------

--
-- Table structure for table `departments`
--

CREATE TABLE `departments` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `code` varchar(50) NOT NULL,
  `name` varchar(150) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `base_salary` decimal(12,2) DEFAULT NULL COMMENT 'DEMO department base salary auto-filled into employee basic_salary',
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `deleted_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Empty by design: no historical rows
--


-- --------------------------------------------------------

--
-- Table structure for table `employees`
--

CREATE TABLE `employees` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `employee_number` varchar(50) NOT NULL,
  `first_name` varchar(100) NOT NULL,
  `middle_name` varchar(100) DEFAULT NULL,
  `last_name` varchar(100) DEFAULT NULL,
  `suffix` varchar(20) DEFAULT NULL,
  `gender` enum('MALE','FEMALE','OTHER') NOT NULL DEFAULT 'OTHER',
  `birth_date` date DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `contact_number` varchar(30) DEFAULT NULL,
  `email` varchar(150) DEFAULT NULL,
  `department_id` bigint(20) UNSIGNED DEFAULT NULL,
  `position_id` bigint(20) UNSIGNED DEFAULT NULL,
  `employment_type` enum('FULL_TIME','PART_TIME','CONTRACT','PROBATIONARY','INTERN') NOT NULL DEFAULT 'FULL_TIME',
  `date_hired` date NOT NULL,
  `salary_type` enum('MONTHLY','SEMI_MONTHLY','DAILY','HOURLY') NOT NULL DEFAULT 'MONTHLY',
  `basic_salary` decimal(12,2) NOT NULL DEFAULT 0.00,
  `work_schedule_id` bigint(20) UNSIGNED DEFAULT NULL,
  `status` enum('ACTIVE','INACTIVE','SUSPENDED','RESIGNED','TERMINATED') NOT NULL DEFAULT 'ACTIVE',
  `payroll_eligible` tinyint(1) NOT NULL DEFAULT 1,
  `archived_at` datetime DEFAULT NULL,
  `archived_by` bigint(20) UNSIGNED DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created_by` bigint(20) UNSIGNED DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `deleted_at` datetime DEFAULT NULL,
  `sss_number` varchar(30) DEFAULT NULL,
  `philhealth_number` varchar(30) DEFAULT NULL,
  `pagibig_number` varchar(30) DEFAULT NULL,
  `tin` varchar(30) DEFAULT NULL,
  `assigned_supervisor_id` bigint(20) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Empty by design: no historical rows
--


-- --------------------------------------------------------

--
-- Table structure for table `employee_allowances`
--

CREATE TABLE `employee_allowances` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `employee_id` bigint(20) UNSIGNED NOT NULL,
  `allowance_id` bigint(20) UNSIGNED NOT NULL,
  `amount` decimal(12,2) NOT NULL DEFAULT 0.00,
  `effective_from` date DEFAULT NULL,
  `effective_to` date DEFAULT NULL,
  `reason` varchar(255) DEFAULT NULL,
  `notes` varchar(500) DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_by` bigint(20) UNSIGNED DEFAULT NULL,
  `updated_by` bigint(20) UNSIGNED DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `deleted_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `employee_deductions`
--

CREATE TABLE `employee_deductions` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `employee_id` bigint(20) UNSIGNED NOT NULL,
  `deduction_id` bigint(20) UNSIGNED NOT NULL,
  `amount` decimal(12,2) NOT NULL DEFAULT 0.00,
  `effective_from` date DEFAULT NULL,
  `effective_to` date DEFAULT NULL,
  `reason` varchar(255) DEFAULT NULL,
  `notes` varchar(500) DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_by` bigint(20) UNSIGNED DEFAULT NULL,
  `updated_by` bigint(20) UNSIGNED DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `deleted_at` datetime DEFAULT NULL,
  `total_amount` decimal(12,2) DEFAULT NULL,
  `deducted_amount` decimal(12,2) NOT NULL DEFAULT 0.00,
  `authorization_reference` varchar(255) DEFAULT NULL,
  `completed_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Empty by design: no historical rows
--


-- --------------------------------------------------------

--
-- Table structure for table `employee_deduction_payments`
--

CREATE TABLE `employee_deduction_payments` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `assignment_id` bigint(20) UNSIGNED NOT NULL,
  `payroll_period_id` bigint(20) UNSIGNED NOT NULL,
  `amount` decimal(12,2) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `employee_qr_codes`
--

CREATE TABLE `employee_qr_codes` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `employee_id` bigint(20) UNSIGNED NOT NULL,
  `token_hash` char(64) NOT NULL,
  `token_hint` varchar(16) NOT NULL,
  `qr_image_path` varchar(255) DEFAULT NULL,
  `serial_no` int(10) UNSIGNED NOT NULL DEFAULT 1,
  `status` enum('ACTIVE','DISABLED','EXPIRED','REPLACED') NOT NULL DEFAULT 'ACTIVE',
  `issued_at` datetime NOT NULL DEFAULT current_timestamp(),
  `expires_at` datetime DEFAULT NULL,
  `disabled_at` datetime DEFAULT NULL,
  `disabled_reason` varchar(255) DEFAULT NULL,
  `issued_by` bigint(20) UNSIGNED DEFAULT NULL,
  `last_scanned_at` datetime DEFAULT NULL,
  `scan_count` int(10) UNSIGNED NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Empty by design: no historical rows
--


-- --------------------------------------------------------

--
-- Table structure for table `holidays`
--

CREATE TABLE `holidays` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(150) NOT NULL,
  `holiday_date` date NOT NULL,
  `holiday_type` enum('REGULAR','SPECIAL','OPTIONAL','REST') NOT NULL DEFAULT 'REGULAR',
  `is_paid` tinyint(1) NOT NULL DEFAULT 1,
  `is_recurring` tinyint(1) NOT NULL DEFAULT 0,
  `status` enum('ACTIVE','INACTIVE') NOT NULL DEFAULT 'ACTIVE',
  `remarks` varchar(255) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `deleted_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Empty by design: no historical rows
--


-- --------------------------------------------------------

--
-- Table structure for table `leave_balances`
--

CREATE TABLE `leave_balances` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `employee_id` bigint(20) UNSIGNED NOT NULL,
  `leave_type_id` bigint(20) UNSIGNED NOT NULL,
  `year` smallint(5) UNSIGNED NOT NULL,
  `entitled_days` decimal(6,2) NOT NULL DEFAULT 0.00,
  `used_days` decimal(6,2) NOT NULL DEFAULT 0.00,
  `pending_days` decimal(6,2) NOT NULL DEFAULT 0.00,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Empty by design: no historical rows
--


-- --------------------------------------------------------

--
-- Table structure for table `leave_requests`
--

CREATE TABLE `leave_requests` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `employee_id` bigint(20) UNSIGNED NOT NULL,
  `leave_type_id` bigint(20) UNSIGNED NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `days` decimal(5,2) NOT NULL DEFAULT 0.00,
  `start_half` enum('FULL','FIRST_HALF','SECOND_HALF') NOT NULL DEFAULT 'FULL',
  `end_half` enum('FULL','FIRST_HALF','SECOND_HALF') NOT NULL DEFAULT 'FULL',
  `reason` varchar(500) NOT NULL,
  `attachment_path` varchar(255) DEFAULT NULL,
  `status` enum('PENDING','APPROVED','REJECTED','CANCELLED') NOT NULL DEFAULT 'PENDING',
  `approver_id` bigint(20) UNSIGNED DEFAULT NULL,
  `approved_at` datetime DEFAULT NULL,
  `approver_remarks` varchar(500) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `cancelled_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Empty by design: no historical rows
--


-- --------------------------------------------------------

--
-- Table structure for table `leave_types`
--

CREATE TABLE `leave_types` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `code` varchar(50) NOT NULL,
  `name` varchar(150) NOT NULL,
  `is_paid` tinyint(1) NOT NULL DEFAULT 1,
  `default_days` decimal(5,2) NOT NULL DEFAULT 0.00,
  `requires_attachment` tinyint(1) NOT NULL DEFAULT 0,
  `allow_negative_balance` tinyint(1) NOT NULL DEFAULT 0,
  `max_consecutive_days` int(10) UNSIGNED DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `deleted_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Empty by design: no historical rows
--


-- --------------------------------------------------------

--
-- Table structure for table `loans`
--

CREATE TABLE `loans` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `employee_id` bigint(20) UNSIGNED NOT NULL,
  `loan_type` varchar(100) NOT NULL DEFAULT 'SALARY_LOAN',
  `reference_no` varchar(50) DEFAULT NULL,
  `principal_amount` decimal(12,2) NOT NULL,
  `monthly_deduction` decimal(12,2) NOT NULL DEFAULT 0.00,
  `term_months` smallint(5) UNSIGNED DEFAULT NULL,
  `flat_interest_percent` decimal(5,2) NOT NULL DEFAULT 0.00,
  `interest_amount` decimal(12,2) NOT NULL DEFAULT 0.00,
  `balance` decimal(12,2) NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date DEFAULT NULL,
  `status` enum('PENDING','OFFERED','READY_FOR_RELEASE','ACTIVE','PAID','REJECTED','CANCELLED') NOT NULL DEFAULT 'PENDING',
  `rejection_reason` varchar(255) DEFAULT NULL,
  `notes` varchar(255) DEFAULT NULL,
  `created_by` bigint(20) UNSIGNED DEFAULT NULL,
  `approved_by` bigint(20) UNSIGNED DEFAULT NULL,
  `approved_at` datetime DEFAULT NULL,
  `terms_offered_at` datetime DEFAULT NULL,
  `terms_accepted_at` datetime DEFAULT NULL,
  `released_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `agency_evidence_reference` varchar(255) DEFAULT NULL,
  `deduction_authorization_reference` varchar(255) DEFAULT NULL,
  `agency_verified_at` datetime DEFAULT NULL,
  `release_reference` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Empty by design: no historical rows
--


-- --------------------------------------------------------

--
-- Table structure for table `loan_payments`
--

CREATE TABLE `loan_payments` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `loan_id` bigint(20) UNSIGNED NOT NULL,
  `payroll_id` bigint(20) UNSIGNED DEFAULT NULL,
  `period_id` bigint(20) UNSIGNED DEFAULT NULL,
  `amount` decimal(12,2) NOT NULL,
  `payment_type` enum('PAYROLL','MANUAL','ADJUSTMENT') NOT NULL DEFAULT 'MANUAL',
  `paid_at` datetime NOT NULL DEFAULT current_timestamp(),
  `remarks` varchar(255) DEFAULT NULL,
  `created_by` bigint(20) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `login_attempts`
--

CREATE TABLE `login_attempts` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `identifier` varchar(150) NOT NULL,
  `ip_address` varchar(45) NOT NULL,
  `success` tinyint(1) NOT NULL DEFAULT 0,
  `user_agent` varchar(255) DEFAULT NULL,
  `attempted_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Empty by design: no historical rows
--


-- --------------------------------------------------------

--
-- Table structure for table `overtime_requests`
--

CREATE TABLE `overtime_requests` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `employee_id` bigint(20) UNSIGNED NOT NULL,
  `overtime_date` date NOT NULL,
  `start_time` time NOT NULL,
  `end_time` time NOT NULL,
  `hours` decimal(5,2) NOT NULL DEFAULT 0.00,
  `ot_type` enum('REGULAR','REST_DAY','HOLIDAY','NIGHT') NOT NULL DEFAULT 'REGULAR',
  `reason` varchar(500) NOT NULL,
  `status` enum('PENDING','ACCEPTED','DECLINED','COMPLETED','APPROVED','REJECTED','CANCELLED') NOT NULL DEFAULT 'PENDING',
  `approver_id` bigint(20) UNSIGNED DEFAULT NULL,
  `created_by` bigint(20) UNSIGNED DEFAULT NULL,
  `approved_at` datetime DEFAULT NULL,
  `approver_remarks` varchar(500) DEFAULT NULL,
  `decline_reason` varchar(500) DEFAULT NULL,
  `responded_at` datetime DEFAULT NULL,
  `responded_by` bigint(20) UNSIGNED DEFAULT NULL,
  `applied_hours` decimal(5,2) NOT NULL DEFAULT 0.00,
  `total_hours` decimal(5,2) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `deleted_at` datetime DEFAULT NULL,
  `manager_confirmed_by` bigint(20) UNSIGNED DEFAULT NULL,
  `manager_confirmed_at` datetime DEFAULT NULL,
  `payroll_verified_by` bigint(20) UNSIGNED DEFAULT NULL,
  `payroll_verified_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Empty by design: no historical rows
--


-- --------------------------------------------------------

--
-- Table structure for table `overtime_scans`
--

CREATE TABLE `overtime_scans` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `overtime_request_id` bigint(20) UNSIGNED NOT NULL,
  `employee_id` bigint(20) UNSIGNED NOT NULL,
  `ot_time_in` datetime NOT NULL,
  `ot_time_out` datetime DEFAULT NULL,
  `payable_minutes` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Empty by design: no historical rows
--


-- --------------------------------------------------------

--
-- Table structure for table `payroll`
--

CREATE TABLE `payroll` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `payroll_period_id` bigint(20) UNSIGNED NOT NULL,
  `employee_id` bigint(20) UNSIGNED NOT NULL,
  `basic_pay` decimal(12,2) NOT NULL DEFAULT 0.00,
  `working_days` decimal(6,2) NOT NULL DEFAULT 0.00,
  `present_days` decimal(6,2) NOT NULL DEFAULT 0.00,
  `absent_days` decimal(6,2) NOT NULL DEFAULT 0.00,
  `leave_days` decimal(6,2) NOT NULL DEFAULT 0.00,
  `late_minutes` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `undertime_minutes` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `overtime_hours` decimal(6,2) NOT NULL DEFAULT 0.00,
  `overtime_pay` decimal(12,2) NOT NULL DEFAULT 0.00,
  `allowances_total` decimal(12,2) NOT NULL DEFAULT 0.00,
  `bonus` decimal(12,2) NOT NULL DEFAULT 0.00,
  `gross_pay` decimal(12,2) NOT NULL DEFAULT 0.00,
  `late_deduction` decimal(12,2) NOT NULL DEFAULT 0.00,
  `undertime_deduction` decimal(12,2) NOT NULL DEFAULT 0.00,
  `absence_deduction` decimal(12,2) NOT NULL DEFAULT 0.00,
  `leave_deduction` decimal(12,2) NOT NULL DEFAULT 0.00,
  `other_deductions` decimal(12,2) NOT NULL DEFAULT 0.00,
  `statutory_sss` decimal(12,2) NOT NULL DEFAULT 0.00,
  `statutory_philhealth` decimal(12,2) NOT NULL DEFAULT 0.00,
  `statutory_pagibig` decimal(12,2) NOT NULL DEFAULT 0.00,
  `withholding_tax` decimal(12,2) NOT NULL DEFAULT 0.00,
  `statutory_total` decimal(12,2) NOT NULL DEFAULT 0.00,
  `employer_contributions` decimal(12,2) NOT NULL DEFAULT 0.00,
  `total_deductions` decimal(12,2) NOT NULL DEFAULT 0.00,
  `net_pay` decimal(12,2) NOT NULL DEFAULT 0.00,
  `amount_paid` decimal(12,2) NOT NULL DEFAULT 0.00,
  `payment_status` enum('UNPAID','PARTIAL','PAID') NOT NULL DEFAULT 'UNPAID',
  `is_locked` tinyint(1) NOT NULL DEFAULT 0,
  `calculation_snapshot` longtext DEFAULT NULL,
  `calculated_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Empty by design: no historical rows
--


-- --------------------------------------------------------

--
-- Table structure for table `payroll_adjustments`
--

CREATE TABLE `payroll_adjustments` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `employee_id` bigint(20) UNSIGNED NOT NULL,
  `payroll_period_id` bigint(20) UNSIGNED NOT NULL,
  `kind` enum('EARNING','DEDUCTION') NOT NULL,
  `amount` decimal(12,2) NOT NULL,
  `reason` varchar(500) NOT NULL,
  `status` enum('PENDING','APPROVED','REJECTED') NOT NULL DEFAULT 'PENDING',
  `request_key` char(64) NOT NULL,
  `created_by` bigint(20) UNSIGNED NOT NULL,
  `approved_by` bigint(20) UNSIGNED DEFAULT NULL,
  `approved_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Empty by design: no historical rows
--


-- --------------------------------------------------------

--
-- Table structure for table `payroll_items`
--

CREATE TABLE `payroll_items` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `payroll_id` bigint(20) UNSIGNED NOT NULL,
  `item_type` enum('EARNING','DEDUCTION') NOT NULL,
  `code` varchar(50) NOT NULL,
  `name` varchar(150) NOT NULL,
  `amount` decimal(12,2) NOT NULL DEFAULT 0.00,
  `remarks` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Empty by design: no historical rows
--


-- --------------------------------------------------------

--
-- Table structure for table `payroll_payments`
--

CREATE TABLE `payroll_payments` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `payroll_id` bigint(20) UNSIGNED NOT NULL,
  `payroll_period_id` bigint(20) UNSIGNED NOT NULL,
  `employee_id` bigint(20) UNSIGNED NOT NULL,
  `reference_no` varchar(50) NOT NULL,
  `idempotency_key` varchar(64) DEFAULT NULL,
  `amount` decimal(12,2) NOT NULL,
  `payment_method` enum('CASH','BANK_TRANSFER','GCASH','OTHER') NOT NULL DEFAULT 'CASH',
  `method_reference` varchar(150) DEFAULT NULL,
  `payment_status` enum('PENDING','COMPLETED','FAILED','CANCELLED') NOT NULL DEFAULT 'COMPLETED',
  `payment_date` date DEFAULT NULL,
  `paid_at` datetime DEFAULT NULL,
  `recorded_by` bigint(20) UNSIGNED DEFAULT NULL,
  `cancelled_by` bigint(20) UNSIGNED DEFAULT NULL,
  `cancelled_at` datetime DEFAULT NULL,
  `cancel_reason` varchar(255) DEFAULT NULL,
  `notes` varchar(500) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Empty by design: no historical rows
--


-- --------------------------------------------------------

--
-- Table structure for table `payroll_periods`
--

CREATE TABLE `payroll_periods` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `code` varchar(50) NOT NULL,
  `name` varchar(150) NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `pay_date` date NOT NULL,
  `status` enum('DRAFT','CALCULATING','FOR_REVIEW','APPROVED','FINALIZED','PAID') NOT NULL DEFAULT 'DRAFT',
  `total_gross` decimal(14,2) NOT NULL DEFAULT 0.00,
  `total_deductions` decimal(14,2) NOT NULL DEFAULT 0.00,
  `total_net` decimal(14,2) NOT NULL DEFAULT 0.00,
  `calculated_at` datetime DEFAULT NULL,
  `approved_by` bigint(20) UNSIGNED DEFAULT NULL,
  `approved_at` datetime DEFAULT NULL,
  `finalized_at` datetime DEFAULT NULL,
  `paid_at` datetime DEFAULT NULL,
  `created_by` bigint(20) UNSIGNED DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `deleted_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Empty by design: no historical rows
--


-- --------------------------------------------------------

--
-- Table structure for table `payroll_statutory`
--

CREATE TABLE `payroll_statutory` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `payroll_id` bigint(20) UNSIGNED NOT NULL,
  `code` varchar(30) NOT NULL,
  `name` varchar(150) NOT NULL,
  `scheme` varchar(30) DEFAULT NULL,
  `schedule_id` bigint(20) UNSIGNED DEFAULT NULL,
  `schedule_effective_from` date DEFAULT NULL,
  `schedule_source` varchar(500) DEFAULT NULL,
  `salary_base` varchar(30) DEFAULT NULL,
  `monthly_base` decimal(12,2) NOT NULL DEFAULT 0.00,
  `credited_base` decimal(12,2) NOT NULL DEFAULT 0.00,
  `employee_rate` decimal(9,4) DEFAULT NULL,
  `employer_rate` decimal(9,4) DEFAULT NULL,
  `monthly_employee_amount` decimal(12,2) NOT NULL DEFAULT 0.00,
  `monthly_employer_amount` decimal(12,2) NOT NULL DEFAULT 0.00,
  `monthly_extra_amount` decimal(12,2) NOT NULL DEFAULT 0.00,
  `allocation_factor` decimal(8,4) NOT NULL DEFAULT 1.0000,
  `employee_amount` decimal(12,2) NOT NULL DEFAULT 0.00,
  `employer_amount` decimal(12,2) NOT NULL DEFAULT 0.00,
  `extra_amount` decimal(12,2) NOT NULL DEFAULT 0.00,
  `withholding_period` varchar(20) DEFAULT NULL,
  `bracket_order` int(10) UNSIGNED DEFAULT NULL,
  `remarks` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Empty by design: no historical rows
--


-- --------------------------------------------------------

--
-- Table structure for table `pms_v23_previous_schedules`
--

CREATE TABLE `pms_v23_previous_schedules` (
  `employee_id` bigint(20) UNSIGNED NOT NULL,
  `work_schedule_id` bigint(20) UNSIGNED DEFAULT NULL,
  `saved_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Empty by design: no historical rows
--


-- --------------------------------------------------------

--
-- Table structure for table `positions`
--

CREATE TABLE `positions` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `code` varchar(50) NOT NULL,
  `name` varchar(150) NOT NULL,
  `department_id` bigint(20) UNSIGNED DEFAULT NULL,
  `job_level` varchar(50) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `deleted_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Empty by design: no historical rows
--


-- --------------------------------------------------------

--
-- Table structure for table `rate_limits`
--

CREATE TABLE `rate_limits` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `bucket_key` varchar(190) NOT NULL,
  `hits` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `window_start` datetime NOT NULL DEFAULT current_timestamp(),
  `blocked_until` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Empty by design: no historical rows
--


-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE `roles` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `code` varchar(50) NOT NULL,
  `name` varchar(100) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `permissions` longtext DEFAULT NULL,
  `is_system` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Empty by design: no historical rows
--


-- --------------------------------------------------------

--
-- Table structure for table `salary_history`
--

CREATE TABLE `salary_history` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `employee_id` bigint(20) UNSIGNED NOT NULL,
  `salary_type` enum('MONTHLY','SEMI_MONTHLY','DAILY','HOURLY') NOT NULL DEFAULT 'MONTHLY',
  `basic_salary` decimal(12,2) NOT NULL,
  `effective_from` date NOT NULL,
  `effective_to` date DEFAULT NULL,
  `reason` varchar(255) DEFAULT NULL,
  `changed_by` bigint(20) UNSIGNED DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Empty by design: no historical rows
--


-- --------------------------------------------------------

--
-- Table structure for table `shifts`
--

CREATE TABLE `shifts` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `code` varchar(50) NOT NULL,
  `name` varchar(150) NOT NULL,
  `start_time` time NOT NULL,
  `end_time` time NOT NULL,
  `break_start` time DEFAULT NULL,
  `break_end` time DEFAULT NULL,
  `is_overnight` tinyint(1) NOT NULL DEFAULT 0,
  `grace_period_minutes` int(10) UNSIGNED NOT NULL DEFAULT 5,
  `required_hours` decimal(5,2) NOT NULL DEFAULT 8.00,
  `description` varchar(255) DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `deleted_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Empty by design: no historical rows
--


-- --------------------------------------------------------

--
-- Table structure for table `statutory_remittances`
--

CREATE TABLE `statutory_remittances` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `reference_no` varchar(50) NOT NULL,
  `agency_code` varchar(30) NOT NULL,
  `agency_name` varchar(150) NOT NULL,
  `period_start` date NOT NULL,
  `period_end` date NOT NULL,
  `due_date` date DEFAULT NULL,
  `status` enum('OPEN','SUBMITTED','PAID') NOT NULL DEFAULT 'OPEN',
  `employee_count` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `total_employee` decimal(14,2) NOT NULL DEFAULT 0.00,
  `total_employer` decimal(14,2) NOT NULL DEFAULT 0.00,
  `total_extra` decimal(14,2) NOT NULL DEFAULT 0.00,
  `total_amount` decimal(14,2) NOT NULL DEFAULT 0.00,
  `filing_reference` varchar(150) DEFAULT NULL,
  `submitted_by` bigint(20) UNSIGNED DEFAULT NULL,
  `submitted_at` datetime DEFAULT NULL,
  `paid_reference` varchar(150) DEFAULT NULL,
  `paid_date` date DEFAULT NULL,
  `paid_by` bigint(20) UNSIGNED DEFAULT NULL,
  `paid_at` datetime DEFAULT NULL,
  `notes` varchar(500) DEFAULT NULL,
  `created_by` bigint(20) UNSIGNED DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `statutory_remittance_items`
--

CREATE TABLE `statutory_remittance_items` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `remittance_id` bigint(20) UNSIGNED NOT NULL,
  `payroll_id` bigint(20) UNSIGNED DEFAULT NULL,
  `payroll_statutory_id` bigint(20) UNSIGNED DEFAULT NULL,
  `payroll_period_id` bigint(20) UNSIGNED DEFAULT NULL,
  `employee_id` bigint(20) UNSIGNED DEFAULT NULL,
  `employee_number` varchar(50) DEFAULT NULL,
  `employee_name` varchar(150) DEFAULT NULL,
  `code` varchar(30) NOT NULL,
  `line_name` varchar(150) NOT NULL,
  `schedule_source` varchar(500) DEFAULT NULL,
  `salary_base` varchar(30) DEFAULT NULL,
  `credited_base` decimal(12,2) NOT NULL DEFAULT 0.00,
  `employee_rate` decimal(9,4) DEFAULT NULL,
  `employer_rate` decimal(9,4) DEFAULT NULL,
  `monthly_employee_amount` decimal(12,2) NOT NULL DEFAULT 0.00,
  `monthly_employer_amount` decimal(12,2) NOT NULL DEFAULT 0.00,
  `employee_amount` decimal(12,2) NOT NULL DEFAULT 0.00,
  `employer_amount` decimal(12,2) NOT NULL DEFAULT 0.00,
  `extra_amount` decimal(12,2) NOT NULL DEFAULT 0.00,
  `period_start` date DEFAULT NULL,
  `period_end` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `statutory_schedules`
--

CREATE TABLE `statutory_schedules` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `code` varchar(30) NOT NULL,
  `name` varchar(150) NOT NULL,
  `agency` varchar(150) NOT NULL,
  `scheme` enum('PERCENTAGE','CREDIT_RATE') NOT NULL DEFAULT 'PERCENTAGE',
  `effective_from` date NOT NULL,
  `effective_to` date DEFAULT NULL,
  `salary_base` enum('MONTHLY_BASIC','MONTHLY_BASIC_PLUS_ALLOWANCES') NOT NULL DEFAULT 'MONTHLY_BASIC',
  `salary_floor` decimal(12,2) DEFAULT NULL,
  `salary_ceiling` decimal(12,2) DEFAULT NULL,
  `employee_rate` decimal(9,4) DEFAULT NULL,
  `employer_rate` decimal(9,4) DEFAULT NULL,
  `low_salary_threshold` decimal(12,2) DEFAULT NULL,
  `low_employee_rate` decimal(9,4) DEFAULT NULL,
  `low_employer_rate` decimal(9,4) DEFAULT NULL,
  `credit_step` decimal(12,2) DEFAULT NULL,
  `credit_min` decimal(12,2) DEFAULT NULL,
  `credit_max` decimal(12,2) DEFAULT NULL,
  `ec_amount` decimal(12,2) DEFAULT NULL,
  `ec_amount_high` decimal(12,2) DEFAULT NULL,
  `ec_threshold` decimal(12,2) DEFAULT NULL,
  `rounding` enum('CENTAVO','PESO') NOT NULL DEFAULT 'CENTAVO',
  `deduction_code` varchar(30) NOT NULL,
  `deduction_name` varchar(150) NOT NULL,
  `source_name` varchar(255) DEFAULT NULL,
  `source_url` varchar(500) DEFAULT NULL,
  `notes` varchar(500) DEFAULT NULL,
  `status` enum('ACTIVE','INACTIVE') NOT NULL DEFAULT 'ACTIVE',
  `created_by` bigint(20) UNSIGNED DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Empty by design: no historical rows
--


-- --------------------------------------------------------

--
-- Table structure for table `system_settings`
--

CREATE TABLE `system_settings` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `setting_key` varchar(100) NOT NULL,
  `setting_value` longtext DEFAULT NULL,
  `category` varchar(50) NOT NULL DEFAULT 'GENERAL',
  `label` varchar(150) DEFAULT NULL,
  `value_type` enum('STRING','INT','DECIMAL','BOOLEAN','JSON') NOT NULL DEFAULT 'STRING',
  `description` varchar(255) DEFAULT NULL,
  `is_public` tinyint(1) NOT NULL DEFAULT 0,
  `updated_by` bigint(20) UNSIGNED DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Empty by design: no historical rows
--


-- --------------------------------------------------------

--
-- Table structure for table `thirteenth_payments`
--

CREATE TABLE `thirteenth_payments` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `thirteenth_pay_id` bigint(20) UNSIGNED NOT NULL,
  `amount` decimal(12,2) NOT NULL DEFAULT 0.00,
  `payment_status` enum('PENDING','PARTIAL','COMPLETED','FAILED') NOT NULL DEFAULT 'PENDING',
  `paid_at` datetime DEFAULT NULL,
  `paid_by` bigint(20) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `thirteenth_pays`
--

CREATE TABLE `thirteenth_pays` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `employee_id` bigint(20) UNSIGNED NOT NULL,
  `calendar_year` smallint(5) UNSIGNED NOT NULL,
  `gross_total` decimal(14,2) NOT NULL DEFAULT 0.00,
  `thirteenth_pay` decimal(12,2) NOT NULL DEFAULT 0.00,
  `status` enum('DRAFT','FOR_APPROVAL','APPROVED','PAID') NOT NULL DEFAULT 'DRAFT',
  `generated_by` bigint(20) UNSIGNED DEFAULT NULL,
  `generated_at` datetime NOT NULL DEFAULT current_timestamp(),
  `submitted_by` bigint(20) UNSIGNED DEFAULT NULL,
  `submitted_at` datetime DEFAULT NULL,
  `approved_by` bigint(20) UNSIGNED DEFAULT NULL,
  `approved_at` datetime DEFAULT NULL,
  `released_at` datetime DEFAULT NULL,
  `paid_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Empty by design: no historical rows
--


-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `username` varchar(100) NOT NULL,
  `email` varchar(150) DEFAULT NULL,
  `password_hash` varchar(255) NOT NULL,
  `full_name` varchar(150) NOT NULL,
  `role_id` bigint(20) UNSIGNED NOT NULL,
  `employee_id` bigint(20) UNSIGNED DEFAULT NULL,
  `status` enum('ACTIVE','INACTIVE','LOCKED') NOT NULL DEFAULT 'ACTIVE',
  `must_change_password` tinyint(1) NOT NULL DEFAULT 0,
  `failed_attempts` tinyint(3) UNSIGNED NOT NULL DEFAULT 0,
  `locked_until` datetime DEFAULT NULL,
  `last_login_at` datetime DEFAULT NULL,
  `last_login_ip` varchar(45) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `deleted_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Empty by design: no historical rows
--


-- --------------------------------------------------------

--
-- Table structure for table `work_schedules`
--

CREATE TABLE `work_schedules` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `code` varchar(50) NOT NULL,
  `name` varchar(150) NOT NULL,
  `schedule_type` enum('REGULAR','FLEXIBLE','NIGHT_SHIFT','ROTATING','CUSTOM') NOT NULL DEFAULT 'REGULAR',
  `description` varchar(255) DEFAULT NULL,
  `is_default` tinyint(1) NOT NULL DEFAULT 0,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `deleted_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Empty by design: no historical rows
--


-- --------------------------------------------------------

--
-- Table structure for table `work_schedule_days`
--

CREATE TABLE `work_schedule_days` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `work_schedule_id` bigint(20) UNSIGNED NOT NULL,
  `day_of_week` tinyint(3) UNSIGNED NOT NULL,
  `shift_id` bigint(20) UNSIGNED DEFAULT NULL,
  `is_rest_day` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Empty by design: no historical rows
--


--
-- Indexes for dumped tables
--

--
-- Indexes for table `agency_loan_remittances`
--
ALTER TABLE `agency_loan_remittances`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_agency_loan_payment` (`loan_payment_id`),
  ADD KEY `idx_agency_loan_status` (`agency`,`status`),
  ADD KEY `fk_agency_recorded_by` (`recorded_by`);

--
-- Indexes for table `allowances`
--
ALTER TABLE `allowances`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_allowances_code` (`code`),
  ADD KEY `fk_allowances_creator` (`created_by`),
  ADD KEY `fk_allowances_updater` (`updated_by`);

--
-- Indexes for table `api_tokens`
--
ALTER TABLE `api_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_api_tokens_hash` (`token_hash`),
  ADD KEY `idx_api_tokens_user` (`user_id`,`is_revoked`),
  ADD KEY `idx_api_tokens_exp` (`expires_at`);

--
-- Indexes for table `attendance`
--
ALTER TABLE `attendance`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_attendance_emp_date` (`employee_id`,`attendance_date`),
  ADD KEY `idx_attendance_date_status` (`attendance_date`,`status`),
  ADD KEY `idx_attendance_shift` (`shift_id`),
  ADD KEY `fk_attendance_schedule` (`work_schedule_id`),
  ADD KEY `fk_attendance_adjuster` (`adjusted_by`);

--
-- Indexes for table `attendance_logs`
--
ALTER TABLE `attendance_logs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_attlogs_date` (`scanned_at`),
  ADD KEY `idx_attlogs_emp` (`employee_id`),
  ADD KEY `idx_attlogs_result` (`result`),
  ADD KEY `fk_attlogs_attendance` (`attendance_id`),
  ADD KEY `fk_attlogs_qr` (`qr_code_id`),
  ADD KEY `fk_attlogs_user` (`recorded_by`);

--
-- Indexes for table `audit_logs`
--
ALTER TABLE `audit_logs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_audit_user` (`user_id`),
  ADD KEY `idx_audit_action` (`action`),
  ADD KEY `idx_audit_entity` (`entity_type`,`entity_id`),
  ADD KEY `idx_audit_created` (`created_at`);

--
-- Indexes for table `bir_withholding_brackets`
--
ALTER TABLE `bir_withholding_brackets`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_bir_bracket_order` (`schedule_id`,`bracket_order`);

--
-- Indexes for table `bir_withholding_schedules`
--
ALTER TABLE `bir_withholding_schedules`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_bir_frequency_from` (`frequency`,`effective_from`),
  ADD KEY `idx_bir_lookup` (`frequency`,`status`,`effective_from`),
  ADD KEY `fk_bir_schedule_user` (`created_by`);

--
-- Indexes for table `deductions`
--
ALTER TABLE `deductions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_deductions_code` (`code`),
  ADD KEY `fk_deductions_creator` (`created_by`),
  ADD KEY `fk_deductions_updater` (`updated_by`);

--
-- Indexes for table `departments`
--
ALTER TABLE `departments`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_departments_code` (`code`),
  ADD KEY `idx_departments_active` (`is_active`,`deleted_at`);

--
-- Indexes for table `employees`
--
ALTER TABLE `employees`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_employees_number` (`employee_number`),
  ADD UNIQUE KEY `uq_employees_email` (`email`),
  ADD KEY `idx_employees_dept` (`department_id`),
  ADD KEY `idx_employees_position` (`position_id`),
  ADD KEY `idx_employees_schedule` (`work_schedule_id`),
  ADD KEY `idx_employees_status` (`status`,`deleted_at`),
  ADD KEY `idx_employees_name` (`last_name`,`first_name`),
  ADD KEY `fk_employees_created_by` (`created_by`),
  ADD KEY `fk_employees_archived_by` (`archived_by`);

--
-- Indexes for table `employee_allowances`
--
ALTER TABLE `employee_allowances`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_emp_allowance` (`employee_id`,`allowance_id`),
  ADD KEY `idx_empallow_active` (`employee_id`,`is_active`,`deleted_at`),
  ADD KEY `fk_empallow_allow` (`allowance_id`),
  ADD KEY `fk_empallow_creator` (`created_by`),
  ADD KEY `fk_empallow_updater` (`updated_by`);

--
-- Indexes for table `employee_deductions`
--
ALTER TABLE `employee_deductions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_emp_deduction` (`employee_id`,`deduction_id`),
  ADD KEY `idx_empded_active` (`employee_id`,`is_active`,`deleted_at`),
  ADD KEY `fk_empded_ded` (`deduction_id`),
  ADD KEY `fk_empded_creator` (`created_by`),
  ADD KEY `fk_empded_updater` (`updated_by`);

--
-- Indexes for table `employee_deduction_payments`
--
ALTER TABLE `employee_deduction_payments`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_ed_payment_period` (`assignment_id`,`payroll_period_id`),
  ADD KEY `idx_ed_payment_period` (`payroll_period_id`);

--
-- Indexes for table `employee_qr_codes`
--
ALTER TABLE `employee_qr_codes`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_qr_token_hash` (`token_hash`),
  ADD KEY `idx_qr_employee_status` (`employee_id`,`status`),
  ADD KEY `idx_qr_hint` (`token_hint`),
  ADD KEY `fk_qr_issued_by` (`issued_by`);

--
-- Indexes for table `holidays`
--
ALTER TABLE `holidays`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_holidays_date` (`holiday_date`,`name`),
  ADD KEY `idx_holidays_status` (`status`,`deleted_at`),
  ADD KEY `idx_holidays_monthday` (`holiday_date`);

--
-- Indexes for table `leave_balances`
--
ALTER TABLE `leave_balances`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_lb` (`employee_id`,`leave_type_id`,`year`),
  ADD KEY `fk_lb_type` (`leave_type_id`);

--
-- Indexes for table `leave_requests`
--
ALTER TABLE `leave_requests`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_leave_emp` (`employee_id`,`status`),
  ADD KEY `idx_leave_status` (`status`),
  ADD KEY `idx_leave_dates` (`start_date`,`end_date`),
  ADD KEY `idx_leave_type` (`leave_type_id`),
  ADD KEY `fk_leave_approver` (`approver_id`);

--
-- Indexes for table `leave_types`
--
ALTER TABLE `leave_types`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_leave_types_code` (`code`);

--
-- Indexes for table `loans`
--
ALTER TABLE `loans`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_loans_reference` (`reference_no`),
  ADD KEY `idx_loans_emp` (`employee_id`,`status`),
  ADD KEY `fk_loans_user` (`created_by`),
  ADD KEY `fk_loans_approver` (`approved_by`);

--
-- Indexes for table `loan_payments`
--
ALTER TABLE `loan_payments`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_loanpay_period_loan` (`period_id`,`loan_id`),
  ADD KEY `idx_loanpay_loan` (`loan_id`),
  ADD KEY `idx_loanpay_period` (`period_id`),
  ADD KEY `fk_loanpay_user` (`created_by`);

--
-- Indexes for table `login_attempts`
--
ALTER TABLE `login_attempts`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_login_attempts_ident` (`identifier`,`attempted_at`),
  ADD KEY `idx_login_attempts_ip` (`ip_address`,`attempted_at`);

--
-- Indexes for table `overtime_requests`
--
ALTER TABLE `overtime_requests`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_ot_emp` (`employee_id`,`status`),
  ADD KEY `idx_ot_date` (`overtime_date`),
  ADD KEY `idx_ot_status` (`status`),
  ADD KEY `idx_ot_date_status` (`overtime_date`,`status`),
  ADD KEY `fk_ot_approver` (`approver_id`),
  ADD KEY `fk_ot_creator` (`created_by`),
  ADD KEY `fk_ot_responder` (`responded_by`);

--
-- Indexes for table `overtime_scans`
--
ALTER TABLE `overtime_scans`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_ot_scan_request` (`overtime_request_id`),
  ADD KEY `idx_ot_scan_employee` (`employee_id`);

--
-- Indexes for table `payroll`
--
ALTER TABLE `payroll`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_payroll_period_emp` (`payroll_period_id`,`employee_id`),
  ADD KEY `idx_payroll_emp` (`employee_id`),
  ADD KEY `idx_payroll_paystatus` (`payment_status`);

--
-- Indexes for table `payroll_adjustments`
--
ALTER TABLE `payroll_adjustments`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `request_key` (`request_key`),
  ADD KEY `idx_payadj_period_emp` (`payroll_period_id`,`employee_id`,`status`),
  ADD KEY `fk_pa_employee` (`employee_id`),
  ADD KEY `fk_pa_created` (`created_by`),
  ADD KEY `fk_pa_approved` (`approved_by`);

--
-- Indexes for table `payroll_items`
--
ALTER TABLE `payroll_items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_payitems_payroll` (`payroll_id`);

--
-- Indexes for table `payroll_payments`
--
ALTER TABLE `payroll_payments`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_payrollpay_ref` (`reference_no`),
  ADD UNIQUE KEY `uq_payrollpay_idem` (`idempotency_key`),
  ADD KEY `idx_payrollpay_payroll` (`payroll_id`,`payment_status`),
  ADD KEY `idx_payrollpay_period` (`payroll_period_id`,`payment_status`),
  ADD KEY `idx_payrollpay_employee` (`employee_id`),
  ADD KEY `idx_payrollpay_status` (`payment_status`),
  ADD KEY `fk_payrollpay_recorder` (`recorded_by`),
  ADD KEY `fk_payrollpay_canceller` (`cancelled_by`);

--
-- Indexes for table `payroll_periods`
--
ALTER TABLE `payroll_periods`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_payperiod_code` (`code`),
  ADD KEY `idx_payperiod_dates` (`start_date`,`end_date`),
  ADD KEY `idx_payperiod_status` (`status`),
  ADD KEY `fk_payperiod_approver` (`approved_by`),
  ADD KEY `fk_payperiod_creator` (`created_by`);

--
-- Indexes for table `payroll_statutory`
--
ALTER TABLE `payroll_statutory`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_payroll_statutory` (`payroll_id`,`code`),
  ADD KEY `idx_payroll_statutory_code` (`code`);

--
-- Indexes for table `pms_v23_previous_schedules`
--
ALTER TABLE `pms_v23_previous_schedules`
  ADD PRIMARY KEY (`employee_id`);

--
-- Indexes for table `positions`
--
ALTER TABLE `positions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_positions_code` (`code`),
  ADD KEY `idx_positions_dept` (`department_id`);

--
-- Indexes for table `rate_limits`
--
ALTER TABLE `rate_limits`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_rate_limits_key` (`bucket_key`),
  ADD KEY `idx_rate_limits_blocked` (`blocked_until`);

--
-- Indexes for table `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_roles_code` (`code`);

--
-- Indexes for table `salary_history`
--
ALTER TABLE `salary_history`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_salhist_emp` (`employee_id`,`effective_from`),
  ADD KEY `fk_salhist_user` (`changed_by`);

--
-- Indexes for table `shifts`
--
ALTER TABLE `shifts`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_shifts_code` (`code`);

--
-- Indexes for table `statutory_remittances`
--
ALTER TABLE `statutory_remittances`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_remittance_reference` (`reference_no`),
  ADD UNIQUE KEY `uq_remittance_window` (`agency_code`,`period_start`,`period_end`),
  ADD KEY `idx_remittance_status` (`status`),
  ADD KEY `idx_remittance_period` (`period_start`,`period_end`),
  ADD KEY `fk_remittance_creator` (`created_by`),
  ADD KEY `fk_remittance_submitter` (`submitted_by`),
  ADD KEY `fk_remittance_payer` (`paid_by`);

--
-- Indexes for table `statutory_remittance_items`
--
ALTER TABLE `statutory_remittance_items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_remittance_items_remittance` (`remittance_id`),
  ADD KEY `idx_remittance_items_employee` (`employee_id`),
  ADD KEY `fk_remittance_item_payroll` (`payroll_id`),
  ADD KEY `fk_remittance_item_statutory` (`payroll_statutory_id`),
  ADD KEY `fk_remittance_item_period` (`payroll_period_id`);

--
-- Indexes for table `statutory_schedules`
--
ALTER TABLE `statutory_schedules`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_statutory_code_from` (`code`,`effective_from`),
  ADD KEY `idx_statutory_lookup` (`code`,`status`,`effective_from`),
  ADD KEY `fk_statutory_user` (`created_by`);

--
-- Indexes for table `system_settings`
--
ALTER TABLE `system_settings`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_settings_key` (`setting_key`),
  ADD KEY `idx_settings_cat` (`category`),
  ADD KEY `fk_settings_user` (`updated_by`);

--
-- Indexes for table `thirteenth_payments`
--
ALTER TABLE `thirteenth_payments`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_ltpay_payment` (`thirteenth_pay_id`),
  ADD KEY `idx_ltpay_status` (`payment_status`),
  ADD KEY `fk_ltpay_user` (`paid_by`);

--
-- Indexes for table `thirteenth_pays`
--
ALTER TABLE `thirteenth_pays`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_thirteenth_emp_year` (`employee_id`,`calendar_year`),
  ADD KEY `idx_thirteenth_status` (`status`,`calendar_year`),
  ADD KEY `idx_thirteenth_year` (`calendar_year`),
  ADD KEY `fk_thirteenth_gen` (`generated_by`),
  ADD KEY `fk_thirteenth_sub` (`submitted_by`),
  ADD KEY `fk_thirteenth_app` (`approved_by`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_users_username` (`username`),
  ADD UNIQUE KEY `uq_users_email` (`email`),
  ADD KEY `idx_users_role` (`role_id`),
  ADD KEY `idx_users_employee` (`employee_id`),
  ADD KEY `idx_users_status` (`status`);

--
-- Indexes for table `work_schedules`
--
ALTER TABLE `work_schedules`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_work_schedules_code` (`code`);

--
-- Indexes for table `work_schedule_days`
--
ALTER TABLE `work_schedule_days`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_wsd` (`work_schedule_id`,`day_of_week`,`shift_id`),
  ADD KEY `idx_wsd_schedule` (`work_schedule_id`),
  ADD KEY `fk_wsd_shift` (`shift_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `agency_loan_remittances`
--
ALTER TABLE `agency_loan_remittances`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `allowances`
--
ALTER TABLE `allowances`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `api_tokens`
--
ALTER TABLE `api_tokens`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `attendance`
--
ALTER TABLE `attendance`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `attendance_logs`
--
ALTER TABLE `attendance_logs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `audit_logs`
--
ALTER TABLE `audit_logs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `bir_withholding_brackets`
--
ALTER TABLE `bir_withholding_brackets`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `bir_withholding_schedules`
--
ALTER TABLE `bir_withholding_schedules`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `deductions`
--
ALTER TABLE `deductions`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `departments`
--
ALTER TABLE `departments`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `employees`
--
ALTER TABLE `employees`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `employee_allowances`
--
ALTER TABLE `employee_allowances`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `employee_deductions`
--
ALTER TABLE `employee_deductions`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `employee_deduction_payments`
--
ALTER TABLE `employee_deduction_payments`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `employee_qr_codes`
--
ALTER TABLE `employee_qr_codes`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `holidays`
--
ALTER TABLE `holidays`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `leave_balances`
--
ALTER TABLE `leave_balances`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `leave_requests`
--
ALTER TABLE `leave_requests`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `leave_types`
--
ALTER TABLE `leave_types`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `loans`
--
ALTER TABLE `loans`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `loan_payments`
--
ALTER TABLE `loan_payments`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `login_attempts`
--
ALTER TABLE `login_attempts`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `overtime_requests`
--
ALTER TABLE `overtime_requests`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `overtime_scans`
--
ALTER TABLE `overtime_scans`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `payroll`
--
ALTER TABLE `payroll`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `payroll_adjustments`
--
ALTER TABLE `payroll_adjustments`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `payroll_items`
--
ALTER TABLE `payroll_items`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `payroll_payments`
--
ALTER TABLE `payroll_payments`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `payroll_periods`
--
ALTER TABLE `payroll_periods`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `payroll_statutory`
--
ALTER TABLE `payroll_statutory`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `positions`
--
ALTER TABLE `positions`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `rate_limits`
--
ALTER TABLE `rate_limits`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `roles`
--
ALTER TABLE `roles`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `salary_history`
--
ALTER TABLE `salary_history`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `shifts`
--
ALTER TABLE `shifts`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `statutory_remittances`
--
ALTER TABLE `statutory_remittances`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `statutory_remittance_items`
--
ALTER TABLE `statutory_remittance_items`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `statutory_schedules`
--
ALTER TABLE `statutory_schedules`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `system_settings`
--
ALTER TABLE `system_settings`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `thirteenth_payments`
--
ALTER TABLE `thirteenth_payments`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `thirteenth_pays`
--
ALTER TABLE `thirteenth_pays`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `work_schedules`
--
ALTER TABLE `work_schedules`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `work_schedule_days`
--
ALTER TABLE `work_schedule_days`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `agency_loan_remittances`
--
ALTER TABLE `agency_loan_remittances`
  ADD CONSTRAINT `fk_agency_loanpay` FOREIGN KEY (`loan_payment_id`) REFERENCES `loan_payments` (`id`),
  ADD CONSTRAINT `fk_agency_recorded_by` FOREIGN KEY (`recorded_by`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `allowances`
--
ALTER TABLE `allowances`
  ADD CONSTRAINT `fk_allowances_creator` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `fk_allowances_updater` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `api_tokens`
--
ALTER TABLE `api_tokens`
  ADD CONSTRAINT `fk_api_tokens_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `attendance`
--
ALTER TABLE `attendance`
  ADD CONSTRAINT `fk_attendance_adjuster` FOREIGN KEY (`adjusted_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `fk_attendance_emp` FOREIGN KEY (`employee_id`) REFERENCES `employees` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_attendance_schedule` FOREIGN KEY (`work_schedule_id`) REFERENCES `work_schedules` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `fk_attendance_shift` FOREIGN KEY (`shift_id`) REFERENCES `shifts` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `attendance_logs`
--
ALTER TABLE `attendance_logs`
  ADD CONSTRAINT `fk_attlogs_attendance` FOREIGN KEY (`attendance_id`) REFERENCES `attendance` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `fk_attlogs_emp` FOREIGN KEY (`employee_id`) REFERENCES `employees` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `fk_attlogs_qr` FOREIGN KEY (`qr_code_id`) REFERENCES `employee_qr_codes` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `fk_attlogs_user` FOREIGN KEY (`recorded_by`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `audit_logs`
--
ALTER TABLE `audit_logs`
  ADD CONSTRAINT `fk_audit_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `bir_withholding_brackets`
--
ALTER TABLE `bir_withholding_brackets`
  ADD CONSTRAINT `fk_bir_bracket_schedule` FOREIGN KEY (`schedule_id`) REFERENCES `bir_withholding_schedules` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `bir_withholding_schedules`
--
ALTER TABLE `bir_withholding_schedules`
  ADD CONSTRAINT `fk_bir_schedule_user` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `deductions`
--
ALTER TABLE `deductions`
  ADD CONSTRAINT `fk_deductions_creator` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `fk_deductions_updater` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `employees`
--
ALTER TABLE `employees`
  ADD CONSTRAINT `fk_employees_archived_by` FOREIGN KEY (`archived_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `fk_employees_created_by` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `fk_employees_dept` FOREIGN KEY (`department_id`) REFERENCES `departments` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `fk_employees_position` FOREIGN KEY (`position_id`) REFERENCES `positions` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `fk_employees_schedule` FOREIGN KEY (`work_schedule_id`) REFERENCES `work_schedules` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `employee_allowances`
--
ALTER TABLE `employee_allowances`
  ADD CONSTRAINT `fk_empallow_allow` FOREIGN KEY (`allowance_id`) REFERENCES `allowances` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_empallow_creator` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `fk_empallow_emp` FOREIGN KEY (`employee_id`) REFERENCES `employees` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_empallow_updater` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `employee_deductions`
--
ALTER TABLE `employee_deductions`
  ADD CONSTRAINT `fk_empded_creator` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `fk_empded_ded` FOREIGN KEY (`deduction_id`) REFERENCES `deductions` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_empded_emp` FOREIGN KEY (`employee_id`) REFERENCES `employees` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_empded_updater` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `employee_deduction_payments`
--
ALTER TABLE `employee_deduction_payments`
  ADD CONSTRAINT `fk_ed_payment_assignment` FOREIGN KEY (`assignment_id`) REFERENCES `employee_deductions` (`id`),
  ADD CONSTRAINT `fk_ed_payment_payroll_period` FOREIGN KEY (`payroll_period_id`) REFERENCES `payroll_periods` (`id`);

--
-- Constraints for table `employee_qr_codes`
--
ALTER TABLE `employee_qr_codes`
  ADD CONSTRAINT `fk_qr_employee` FOREIGN KEY (`employee_id`) REFERENCES `employees` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_qr_issued_by` FOREIGN KEY (`issued_by`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `leave_balances`
--
ALTER TABLE `leave_balances`
  ADD CONSTRAINT `fk_lb_emp` FOREIGN KEY (`employee_id`) REFERENCES `employees` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_lb_type` FOREIGN KEY (`leave_type_id`) REFERENCES `leave_types` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `leave_requests`
--
ALTER TABLE `leave_requests`
  ADD CONSTRAINT `fk_leave_approver` FOREIGN KEY (`approver_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `fk_leave_emp` FOREIGN KEY (`employee_id`) REFERENCES `employees` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_leave_type` FOREIGN KEY (`leave_type_id`) REFERENCES `leave_types` (`id`);

--
-- Constraints for table `loans`
--
ALTER TABLE `loans`
  ADD CONSTRAINT `fk_loans_approver` FOREIGN KEY (`approved_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `fk_loans_emp` FOREIGN KEY (`employee_id`) REFERENCES `employees` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_loans_user` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `loan_payments`
--
ALTER TABLE `loan_payments`
  ADD CONSTRAINT `fk_loanpay_loan` FOREIGN KEY (`loan_id`) REFERENCES `loans` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_loanpay_user` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `overtime_requests`
--
ALTER TABLE `overtime_requests`
  ADD CONSTRAINT `fk_ot_approver` FOREIGN KEY (`approver_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `fk_ot_creator` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `fk_ot_emp` FOREIGN KEY (`employee_id`) REFERENCES `employees` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_ot_responder` FOREIGN KEY (`responded_by`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `overtime_scans`
--
ALTER TABLE `overtime_scans`
  ADD CONSTRAINT `fk_ot_scan_emp` FOREIGN KEY (`employee_id`) REFERENCES `employees` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_ot_scan_req` FOREIGN KEY (`overtime_request_id`) REFERENCES `overtime_requests` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `payroll`
--
ALTER TABLE `payroll`
  ADD CONSTRAINT `fk_payroll_emp` FOREIGN KEY (`employee_id`) REFERENCES `employees` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_payroll_period` FOREIGN KEY (`payroll_period_id`) REFERENCES `payroll_periods` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `payroll_adjustments`
--
ALTER TABLE `payroll_adjustments`
  ADD CONSTRAINT `fk_pa_approved` FOREIGN KEY (`approved_by`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `fk_pa_created` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `fk_pa_employee` FOREIGN KEY (`employee_id`) REFERENCES `employees` (`id`),
  ADD CONSTRAINT `fk_pa_period` FOREIGN KEY (`payroll_period_id`) REFERENCES `payroll_periods` (`id`);

--
-- Constraints for table `payroll_items`
--
ALTER TABLE `payroll_items`
  ADD CONSTRAINT `fk_payitems_payroll` FOREIGN KEY (`payroll_id`) REFERENCES `payroll` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `payroll_payments`
--
ALTER TABLE `payroll_payments`
  ADD CONSTRAINT `fk_payrollpay_canceller` FOREIGN KEY (`cancelled_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `fk_payrollpay_emp` FOREIGN KEY (`employee_id`) REFERENCES `employees` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_payrollpay_payroll` FOREIGN KEY (`payroll_id`) REFERENCES `payroll` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_payrollpay_period` FOREIGN KEY (`payroll_period_id`) REFERENCES `payroll_periods` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_payrollpay_recorder` FOREIGN KEY (`recorded_by`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `payroll_periods`
--
ALTER TABLE `payroll_periods`
  ADD CONSTRAINT `fk_payperiod_approver` FOREIGN KEY (`approved_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `fk_payperiod_creator` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `payroll_statutory`
--
ALTER TABLE `payroll_statutory`
  ADD CONSTRAINT `fk_payroll_statutory_payroll` FOREIGN KEY (`payroll_id`) REFERENCES `payroll` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `positions`
--
ALTER TABLE `positions`
  ADD CONSTRAINT `fk_positions_dept` FOREIGN KEY (`department_id`) REFERENCES `departments` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `salary_history`
--
ALTER TABLE `salary_history`
  ADD CONSTRAINT `fk_salhist_emp` FOREIGN KEY (`employee_id`) REFERENCES `employees` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_salhist_user` FOREIGN KEY (`changed_by`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `statutory_remittances`
--
ALTER TABLE `statutory_remittances`
  ADD CONSTRAINT `fk_remittance_creator` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `fk_remittance_payer` FOREIGN KEY (`paid_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `fk_remittance_submitter` FOREIGN KEY (`submitted_by`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `statutory_remittance_items`
--
ALTER TABLE `statutory_remittance_items`
  ADD CONSTRAINT `fk_remittance_item_employee` FOREIGN KEY (`employee_id`) REFERENCES `employees` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `fk_remittance_item_payroll` FOREIGN KEY (`payroll_id`) REFERENCES `payroll` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `fk_remittance_item_period` FOREIGN KEY (`payroll_period_id`) REFERENCES `payroll_periods` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `fk_remittance_item_remittance` FOREIGN KEY (`remittance_id`) REFERENCES `statutory_remittances` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_remittance_item_statutory` FOREIGN KEY (`payroll_statutory_id`) REFERENCES `payroll_statutory` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `statutory_schedules`
--
ALTER TABLE `statutory_schedules`
  ADD CONSTRAINT `fk_statutory_user` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `system_settings`
--
ALTER TABLE `system_settings`
  ADD CONSTRAINT `fk_settings_user` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `thirteenth_payments`
--
ALTER TABLE `thirteenth_payments`
  ADD CONSTRAINT `fk_ltpay` FOREIGN KEY (`thirteenth_pay_id`) REFERENCES `thirteenth_pays` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_ltpay_user` FOREIGN KEY (`paid_by`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `thirteenth_pays`
--
ALTER TABLE `thirteenth_pays`
  ADD CONSTRAINT `fk_thirteenth_app` FOREIGN KEY (`approved_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `fk_thirteenth_emp` FOREIGN KEY (`employee_id`) REFERENCES `employees` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_thirteenth_gen` FOREIGN KEY (`generated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `fk_thirteenth_sub` FOREIGN KEY (`submitted_by`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `fk_users_employee` FOREIGN KEY (`employee_id`) REFERENCES `employees` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `fk_users_role` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`);

--
-- Constraints for table `work_schedule_days`
--
ALTER TABLE `work_schedule_days`
  ADD CONSTRAINT `fk_wsd_schedule` FOREIGN KEY (`work_schedule_id`) REFERENCES `work_schedules` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_wsd_shift` FOREIGN KEY (`shift_id`) REFERENCES `shifts` (`id`) ON DELETE SET NULL;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
