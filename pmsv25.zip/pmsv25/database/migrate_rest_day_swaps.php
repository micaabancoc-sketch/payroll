<?php
declare(strict_types=1);

/**
 * Migration: create rest_day_swaps table and grant role permissions (idempotent).
 *
 * Run once on an existing database:
 *   php database/migrate_rest_day_swaps.php
 *
 * Uses its own PDO connection (like database/migrate_13th_month.php)
 * instead of api/bootstrap.php.
 *
 * Idempotent and non-destructive:
 *   CREATE TABLE IF NOT EXISTS creates the table when missing.
 *   Permissions are only appended to role JSON arrays when absent.
 *   Index is only added when absent.
 * Never drops, truncates or rewrites existing data.
 */

$config = require __DIR__ . '/../api/config/config.php';
$db     = $config['database'];

try {
    $pdo = new PDO(
        sprintf('mysql:host=%s;port=%d;charset=%s', $db['host'], (int) $db['port'], $db['charset']),
        $db['user'],
        $db['password'],
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
    );
    $pdo->exec(sprintf('USE `%s`', str_replace('`', '', (string) $db['name'])));

    // 1. Create the table (idempotent).
    $pdo->exec(<<<'SQL'
CREATE TABLE IF NOT EXISTS `rest_day_swaps` (
  `id`                     BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `requester_id`           BIGINT UNSIGNED NOT NULL,
  `other_employee_id`      BIGINT UNSIGNED NOT NULL,
  `requester_original_dow` TINYINT UNSIGNED NOT NULL,
  `other_original_dow`     TINYINT UNSIGNED NOT NULL,
  `effective_date`         DATE         NOT NULL,
  `reason`                 VARCHAR(500) NOT NULL,
  `other_consent`          ENUM('PENDING','ACCEPTED','DECLINED') NOT NULL DEFAULT 'PENDING',
  `manager_decision`       ENUM('PENDING','APPROVED','REJECTED') NOT NULL DEFAULT 'PENDING',
  `manager_id`             BIGINT UNSIGNED NULL,
  `manager_remarks`        VARCHAR(500) NULL,
  `decided_at`             DATETIME     NULL,
  `status`                 ENUM('PENDING','APPROVED','REJECTED','CANCELLED','COMPLETED') NOT NULL DEFAULT 'PENDING',
  `created_at`             DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`             DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted_at`             DATETIME     NULL,
  PRIMARY KEY (`id`),
  KEY `idx_swap_requester`  (`requester_id`, `status`),
  KEY `idx_swap_other`      (`other_employee_id`, `status`),
  KEY `idx_swap_effective`  (`effective_date`, `status`),
  KEY `idx_swap_status`     (`status`),
  CONSTRAINT `fk_swap_requester` FOREIGN KEY (`requester_id`) REFERENCES `employees` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_swap_other`     FOREIGN KEY (`other_employee_id`) REFERENCES `employees` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_swap_manager`   FOREIGN KEY (`manager_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
SQL
    );

    // Helper: append a permission to a role's JSON permissions array if absent.
    $grant = function (string $roleCode, string $permission) use ($pdo): void {
        $stmt = $pdo->prepare(
            "SELECT id, permissions FROM roles WHERE code = :code LIMIT 1"
        );
        $stmt->execute([':code' => $roleCode]);
        $row = $stmt->fetch();
        if ($row === false) {
            return;
        }
        $perms = json_decode((string) ($row['permissions'] ?? '[]'), true);
        if (!is_array($perms)) {
            $perms = [];
        }
        if (!in_array($permission, $perms, true)) {
            $perms[] = $permission;
            $update = $pdo->prepare(
                "UPDATE roles SET permissions = :perms WHERE id = :id"
            );
            $update->execute([
                ':perms' => json_encode($perms),
                ':id'    => (int) $row['id'],
            ]);
        }
    };

    // 2. Grant MANAGER: rest_day_swap.approve, rest_day_swap.view
    $grant('MANAGER', 'rest_day_swap.approve');
    $grant('MANAGER', 'rest_day_swap.view');

    // 3. Grant STAFF: rest_day_swap.create, rest_day_swap.view_own
    $grant('STAFF', 'rest_day_swap.create');
    $grant('STAFF', 'rest_day_swap.view_own');

    // 4. Add overlap-prevention index if missing.
    $hasIndex = (bool) $pdo->query(
        "SELECT 1 FROM information_schema.STATISTICS
         WHERE TABLE_SCHEMA = DATABASE()
           AND TABLE_NAME = 'rest_day_swaps'
           AND INDEX_NAME = 'idx_swap_emp_date'
         LIMIT 1"
    )->fetch();
    if (!$hasIndex) {
        $pdo->exec(
            "ALTER TABLE `rest_day_swaps`
             ADD INDEX `idx_swap_emp_date` (`requester_id`, `effective_date`, `status`)"
        );
    }

    echo "REST_DAY_SWAP: migrated OK (table + role permissions + index)\n";
} catch (\Throwable $e) {
    echo 'REST_DAY_SWAP: MIGRATION FAILED: ' . $e->getMessage() . "\n";
    exit(1);
}