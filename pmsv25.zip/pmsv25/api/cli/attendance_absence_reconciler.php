<?php
/**
 * Automatic absence reconciler — the CLI entry point for the scheduler.
 *
 *   C:\xampp\php\php.exe C:\xampp\htdocs\pms\api\cli\attendance_absence_reconciler.php
 *
 * Run it at least once a minute (Windows Task Scheduler) so each employee is
 * marked ABSENT shortly after their own 60-minute late cut-off passes. It is
 * idempotent and safe to run concurrently — see AttendanceReconciler.
 *
 * This is intentionally NOT an HTTP endpoint: an unauthenticated URL that
 * rewrites attendance would be a security hole, so the only trigger is a
 * local process the operator configures.
 */

declare(strict_types=1);

if (PHP_SAPI !== 'cli') {
    http_response_code(403);
    exit('This script may only be run from the command line.');
}

require dirname(__DIR__) . '/autoload.php';

$config = require dirname(__DIR__) . '/config/config.php';
date_default_timezone_set((string) $config['app']['timezone']);

try {
    $result = (new App\Services\AttendanceReconciler())->run();
} catch (Throwable $e) {
    fwrite(STDERR, sprintf('[%s] absence reconciler FAILED: %s%s', date('c'), $e->getMessage(), PHP_EOL));
    exit(1);
}

$status = $result['ran']
    ? 'ran'
    : 'skipped (another run held the lock)';

printf(
    '[%s] absence reconciler %s: date=%s created=%d%s',
    date('c'),
    $status,
    $result['date'],
    $result['created'],
    PHP_EOL
);

exit(0);