<?php
/**
 * Employee loan endpoints (Phase 3).
 *
 * Route-level permissions (api/routes.php) gate every action; the controller
 * only turns service results and service exceptions into HTTP responses.
 */

declare(strict_types=1);

namespace App\Controllers;

use App\Core\Auth;
use App\Core\Request;
use App\Core\Response;
use App\Services\LoanService;

final class LoanController
{
    public function __construct(private LoanService $loans = new LoanService())
    {
    }

    /** GET /api/loans — ledger with filters. */
    public function index(Request $request, array $params): never
    {
        Auth::require($request);
        Auth::authorizeAny(['loans.view', 'loans.view_own'], $request);

        if (\App\Core\DemoStaffScope::isSystemOperator() && $request->query('mine') === '1') {
            Response::forbidden('System operators do not have personal loan access in the demo.');
        }
        $pagination = $request->pagination();
        $result     = $this->loans->list($request->query(), $pagination['page'], $pagination['per_page']);

        Response::paginated($result['items'], $result['total'], $pagination['page'], $pagination['per_page']);
    }

    /** GET /api/loans/options — loan types, statuses and payment types. */
    public function options(Request $request, array $params): never
    {
        Auth::require($request);
        Auth::authorizeAny(['loans.view', 'loans.view_own'], $request);

        Response::success($this->loans->options(), 'Loan options retrieved successfully');
    }

    /** GET /api/loans/summary — portfolio totals for the loans page. */
    public function summary(Request $request, array $params): never
    {
        Auth::require($request);
        Auth::authorizeAny(['loans.view', 'loans.view_own'], $request);

        if (\App\Core\DemoStaffScope::isSystemOperator() && $request->query('mine') === '1') {
            Response::forbidden('System operators do not have personal loan access in the demo.');
        }
        Response::success($this->loans->summary($request->query('mine') === '1'), 'Loan summary retrieved successfully');
    }

    /** GET /api/loans/{id} */
    public function show(Request $request, array $params): never
    {
        Auth::require($request);
        Auth::authorizeAny(['loans.view', 'loans.view_own'], $request);

        $loan = $this->loans->find((int) ($params['id'] ?? 0));

        if ($loan === null) {
            Response::notFound('Loan not found.');
        }

        Response::success($loan, 'Loan retrieved successfully');
    }

    /** GET /api/loans/{id}/payments — the repayment ledger. */
    public function payments(Request $request, array $params): never
    {
        Auth::require($request);
        Auth::authorizeAny(['loans.view', 'loans.view_own'], $request);

        $loanId = (int) ($params['id'] ?? 0);

        if ($this->loans->find($loanId) === null) {
            Response::notFound('Loan not found.');
        }

        Response::success($this->loans->payments($loanId), 'Loan payments retrieved successfully');
    }

    /** POST /api/loans — record a loan. */
    public function store(Request $request, array $params): never
    {
        Auth::authorize('loans.create');

        try {
            $loan = $this->loans->create($request->body(), Auth::id());
        } catch (\RuntimeException $e) {
            Response::error($e->getMessage(), 422, $e instanceof \App\Core\ValidationException ? $e->errors() : []);
        }

        Response::created($loan, 'Loan recorded successfully');
    }

    /** PUT /api/loans/{id} — edit the terms of an open loan. */
    public function update(Request $request, array $params): never
    {
        Auth::authorize('loans.update');

        try {
            $loan = $this->loans->update((int) ($params['id'] ?? 0), $request->body(), Auth::id());
        } catch (\RuntimeException $e) {
            Response::error($e->getMessage(), 422, $e instanceof \App\Core\ValidationException ? $e->errors() : []);
        }

        Response::success($loan, 'Loan updated successfully');
    }

    /** POST /api/loans/{id}/payments — record a repayment. */
    public function pay(Request $request, array $params): never
    {
        Auth::authorize('loans.payment');

        try {
            $loan = $this->loans->recordPayment((int) ($params['id'] ?? 0), $request->body(), Auth::id());
        } catch (\RuntimeException $e) {
            Response::error($e->getMessage(), 422, $e instanceof \App\Core\ValidationException ? $e->errors() : []);
        }

        Response::created($loan, 'Repayment recorded successfully');
    }

    /** POST /api/loans/{id}/cancel — stop the payroll deduction. */
    public function cancel(Request $request, array $params): never
    {
        Auth::authorize('loans.payment');

        try {
            $loan = $this->loans->cancel(
                (int) ($params['id'] ?? 0),
                Auth::id(),
                trim((string) ($request->body()['reason'] ?? ''))
            );
        } catch (\RuntimeException $e) {
            Response::error($e->getMessage(), 422);
        }

        Response::success($loan, 'Loan cancelled. Payroll will no longer deduct it.');
    }

    /**
     * POST /api/loans/{id}/approve — move a filed loan into the payroll
     * rotation. The service refuses a decision taken by the user who filed the
     * loan, so the route permission (loans.approve) is not the only guard.
     */
    public function approve(Request $request, array $params): never
    {
        Auth::authorize('loans.approve');

        try {
            $loan = $this->loans->approve((int) ($params['id'] ?? 0), Auth::id());
        } catch (\RuntimeException $e) {
            Response::error($e->getMessage(), 422, $e instanceof \App\Core\ValidationException ? $e->errors() : []);
        }

        Response::success($loan, 'Loan approved. Payroll will deduct it on the next run.');
    }

    /** POST /api/loans/{id}/offer — Admin proposes final repayment terms. */
    public function offer(Request $request, array $params): never
    {
        Auth::authorize('loans.approve');
        try {
            $loan = $this->loans->offer((int) ($params['id'] ?? 0),
                (int) ($request->body()['term_months'] ?? 0), Auth::id());
        } catch (\RuntimeException $e) {
            Response::error($e->getMessage(), 422, $e instanceof \App\Core\ValidationException ? $e->errors() : []);
        }
        Response::success($loan, 'Loan terms offered; awaiting employee acceptance.');
    }

    /** POST /api/loans/{id}/accept — employee agrees to repay on offered terms. */
    public function accept(Request $request, array $params): never
    {
        Auth::authorize('loans.view_own');
        try {
            $loan = $this->loans->accept((int) ($params['id'] ?? 0), Auth::id());
        } catch (\RuntimeException $e) {
            Response::error($e->getMessage(), 422, $e instanceof \App\Core\ValidationException ? $e->errors() : []);
        }
        Response::success($loan, 'Terms accepted. Awaiting actual loan release.');
    }

    /** POST /api/loans/{id}/verify-agency — confirm official agency notice and authorization. */
    public function verifyAgency(Request $request, array $params): never
    {
        Auth::authorize('loans.approve');
        try { $loan=$this->loans->verifyAgency((int)($params['id']??0),
            (string)$request->body('agency_evidence_reference',''),
            (string)$request->body('deduction_authorization_reference','')); }
        catch (\RuntimeException $e) { Response::error($e->getMessage(),422,$e instanceof \App\Core\ValidationException?$e->errors():[]); }
        Response::success($loan,'Official agency evidence and payroll deduction authorization verified.');
    }

    /** POST /api/loans/{id}/release — record actual release, enable future payroll deduction. */
    public function release(Request $request, array $params): never
    {
        Auth::authorize('loans.release');
        try {
            $loan = $this->loans->release((int) ($params['id'] ?? 0),
                (string)$request->body('release_reference',''),
                (string)$request->body('deduction_authorization_reference',''),Auth::id());
        } catch (\RuntimeException $e) {
            Response::error($e->getMessage(), 422, $e instanceof \App\Core\ValidationException ? $e->errors() : []);
        }
        Response::success($loan, 'Loan release recorded; repayments start on a later eligible payroll.');
    }

    /** POST /api/loans/{id}/reject — refuse a filed loan, with a reason. */
    public function reject(Request $request, array $params): never
    {
        Auth::authorize('loans.approve');

        $body = $request->body();

        try {
            $loan = $this->loans->reject(
                (int) ($params['id'] ?? 0),
                trim((string) ($body['reason'] ?? $body['rejection_reason'] ?? '')),
                Auth::id()
            );
        } catch (\RuntimeException $e) {
            Response::error($e->getMessage(), 422, $e instanceof \App\Core\ValidationException ? $e->errors() : []);
        }

        Response::success($loan, 'Loan rejected. The reason is kept on the record.');
    }

    /** POST /api/loans/{id}/restore — resume a cancelled loan. */
    public function restore(Request $request, array $params): never
    {
        Auth::authorize('loans.payment');

        try {
            $loan = $this->loans->restore((int) ($params['id'] ?? 0), Auth::id());
        } catch (\RuntimeException $e) {
            Response::error($e->getMessage(), 422);
        }

        Response::success($loan, 'Loan restored successfully');
    }
}