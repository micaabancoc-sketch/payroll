<?php
/**
 * Rest day swap / exchange endpoints.
 */

declare(strict_types=1);

namespace App\Controllers;

use App\Core\Auth;
use App\Core\Request;
use App\Core\Response;
use App\Services\RestDaySwapService;

final class RestDaySwapController
{
    public function __construct(private RestDaySwapService $swaps = new RestDaySwapService())
    {
    }

    /** GET /api/rest-day-swaps — list swap requests. */
    public function index(Request $request, array $params): never
    {
        Auth::require($request);

        $filters = $request->query();

        if (!Auth::hasAnyPermission(['rest_day_swap.view'])) {
            $employeeId = Auth::employeeId();
            if ($employeeId === null) {
                Response::forbidden('Your account is not linked to an employee record.');
            }
            $filters['requester_id'] = $employeeId;
            $filters['other_employee_id'] = $employeeId;
        }

        $pagination = $request->pagination();
        $result = $this->swaps->list($filters, $pagination['page'], $pagination['per_page']);

        Response::paginated($result['items'], $result['total'], $pagination['page'], $pagination['per_page']);
    }

    /** GET /api/rest-day-swaps/{id} — get a single swap request. */
    public function show(Request $request, array $params): never
    {
        Auth::require($request);

        $id = (int) ($params['id'] ?? 0);
        $swap = $this->swaps->find($id);

        if ($swap === null) {
            Response::notFound('Rest day swap request not found.');
        }

        if (!Auth::hasAnyPermission(['rest_day_swap.view'])) {
            $employeeId = Auth::employeeId();
            if ($employeeId === null) {
                Response::forbidden('Your account is not linked to an employee record.');
            }
            if ($employeeId !== (int) $swap['requester_id'] && $employeeId !== (int) $swap['other_employee_id']) {
                Response::forbidden('You may only view your own rest day swap requests.');
            }
        }

        Response::success($swap, 'Rest day swap request retrieved successfully');
    }

    /** POST /api/rest-day-swaps — submit a swap request. */
    public function store(Request $request, array $params): never
    {
        Auth::authorize('rest_day_swap.create');

        try {
            $swap = $this->swaps->create($request->body(), Auth::id());
        } catch (\RuntimeException $e) {
            Response::error($e->getMessage(), 422, $e instanceof \App\Core\ValidationException ? $e->errors() : []);
        }

        Response::created($swap, 'Rest day swap request submitted successfully');
    }

    /** POST /api/rest-day-swaps/{id}/respond — accept or decline (other employee). */
    public function respond(Request $request, array $params): never
    {
        Auth::require($request);

        $id = (int) ($params['id'] ?? 0);

        try {
            $swap = $this->swaps->respond(
                $id,
                $request->body(),
                Auth::id()
            );
        } catch (\RuntimeException $e) {
            Response::error($e->getMessage(), 422, $e instanceof \App\Core\ValidationException ? $e->errors() : []);
        }

        Response::success($swap, 'Rest day swap response recorded successfully');
    }

    /** POST /api/rest-day-swaps/{id}/approve — manager approves. */
    public function approve(Request $request, array $params): never
    {
        Auth::authorize('rest_day_swap.approve');

        $id = (int) ($params['id'] ?? 0);

        try {
            $swap = $this->swaps->approve(
                $id,
                $request->body(),
                Auth::id()
            );
        } catch (\RuntimeException $e) {
            Response::error($e->getMessage(), 422, $e instanceof \App\Core\ValidationException ? $e->errors() : []);
        }

        Response::success($swap, 'Rest day swap approved successfully');
    }

    /** POST /api/rest-day-swaps/{id}/reject — manager rejects. */
    public function reject(Request $request, array $params): never
    {
        Auth::authorize('rest_day_swap.approve');

        $id = (int) ($params['id'] ?? 0);

        try {
            $swap = $this->swaps->reject(
                $id,
                $request->body(),
                Auth::id()
            );
        } catch (\RuntimeException $e) {
            Response::error($e->getMessage(), 422, $e instanceof \App\Core\ValidationException ? $e->errors() : []);
        }

        Response::success($swap, 'Rest day swap rejected successfully');
    }

    /** POST /api/rest-day-swaps/{id}/cancel — cancel a pending swap. */
    public function cancel(Request $request, array $params): never
    {
        Auth::require($request);

        $id = (int) ($params['id'] ?? 0);

        try {
            $swap = $this->swaps->cancel($id, Auth::id());
        } catch (\RuntimeException $e) {
            Response::error($e->getMessage(), 422, $e instanceof \App\Core\ValidationException ? $e->errors() : []);
        }

        Response::success($swap, 'Rest day swap cancelled successfully');
    }
}
