<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Auth;
use App\Core\Request;
use App\Core\Response;
use App\Services\ThirteenthPayService;
use App\Core\ValidationException;
use RuntimeException;

/** 13th-Month Pay endpoints. */
final class ThirteenthPayController
{
    public function __construct(private ThirteenthPayService $service = new ThirteenthPayService())
    {
    }

    private static function yearOf(Request $request): int
    {
        $q = $request->query();
        $y = isset($q['calendar_year']) ? (int) $q['calendar_year'] : 0;
        if ($y === 0) {
            $b = $request->body();
            $y = isset($b['calendar_year']) ? (int) $b['calendar_year'] : 0;
        }
        return $y;
    }

    /** GET /api/thirteenth-pay?calendar_year=YYYY */
    public function index(Request $request, array $params): never
    {
        Auth::authorize('payroll.period.view');
        try {
            Response::success($this->service->listByYear(self::yearOf($request)), 'Records retrieved successfully');
        } catch (ValidationException $e) {
            Response::validationError($e->errors(), $e->getMessage());
        } catch (RuntimeException $e) {
            Response::error($e->getMessage(), 422);
        }
    }

    /** POST /api/thirteenth-pay/generate */
    public function generate(Request $request, array $params): never
    {
        Auth::authorize('payroll.calculate');
        try {
            Response::created($this->service->generate(self::yearOf($request)), 'Generated successfully');
        } catch (ValidationException $e) {
            Response::validationError($e->errors(), $e->getMessage());
        } catch (RuntimeException $e) {
            Response::error($e->getMessage(), 422);
        }
    }

    /** POST /api/thirteenth-pay/submit */
    public function submit(Request $request, array $params): never
    {
        Auth::authorize('payroll.calculate');
        try {
            Response::success($this->service->submitForApproval(self::yearOf($request)), 'Submitted for approval');
        } catch (ValidationException $e) {
            Response::validationError($e->errors(), $e->getMessage());
        } catch (RuntimeException $e) {
            Response::error($e->getMessage(), 422);
        }
    }

    /** POST /api/thirteenth-pay/approve */
    public function approve(Request $request, array $params): never
    {
        Auth::authorize('payroll.approve');
        if (Auth::roleCode() !== 'HR_PAYROLL') {
            Response::forbidden('Only HR/Payroll can approve 13th-month payroll.');
        }
        try {
            Response::success($this->service->approve(self::yearOf($request)), 'Approved successfully');
        } catch (ValidationException $e) {
            Response::validationError($e->errors(), $e->getMessage());
        } catch (RuntimeException $e) {
            Response::error($e->getMessage(), 422);
        }
    }

    /** POST /api/thirteenth-pay/release */
    public function release(Request $request, array $params): never
    {
        Auth::authorize('payroll.mark_paid');
        if (Auth::roleCode() !== 'HR_PAYROLL') {
            Response::forbidden('Only HR/Payroll can record 13th-month release.');
        }
        try {
            Response::success($this->service->releaseApproved(self::yearOf($request)), 'Released successfully');
        } catch (ValidationException $e) {
            Response::validationError($e->errors(), $e->getMessage());
        } catch (RuntimeException $e) {
            Response::error($e->getMessage(), 422);
        }
    }

    /** GET /api/thirteenth-pay/unpaid?calendar_year=YYYY */
    public function unpaid(Request $request, array $params): never
    {
        Auth::authorize('payroll.period.view');
        try {
            Response::success($this->service->unpaidReleased(self::yearOf($request)), 'Unpaid records retrieved');
        } catch (ValidationException $e) {
            Response::validationError($e->errors(), $e->getMessage());
        } catch (RuntimeException $e) {
            Response::error($e->getMessage(), 422);
        }
    }

    /** POST /api/thirteenth-pay/payments */
    public function pay(Request $request, array $params): never
    {
        Auth::authorize('payroll.mark_paid');
        $b = $request->body();
        try {
            Response::created(
                $this->service->recordPayment((int) ($b['pay_id'] ?? 0), (float) ($b['amount'] ?? 0)),
                'Payment recorded successfully'
            );
        } catch (ValidationException $e) {
            Response::validationError($e->errors(), $e->getMessage());
        } catch (RuntimeException $e) {
            Response::error($e->getMessage(), 422);
        }
    }
}
