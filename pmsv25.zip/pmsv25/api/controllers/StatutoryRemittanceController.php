<?php
/**
 * Statutory remittance register endpoints (statutory reports & remittance
 * tracking). Reads are open to anyone who can see the register or the
 * statutory reports; every write is strictly remittance.manage.
 */

declare(strict_types=1);

namespace App\Controllers;

use App\Core\Auth;
use App\Core\Request;
use App\Core\Response;
use App\Services\StatutoryRemittanceService;
use RuntimeException;

final class StatutoryRemittanceController
{
    public function __construct(private StatutoryRemittanceService $remittances = new StatutoryRemittanceService())
    {
    }

    /** GET /api/statutory/remittances — the register (filters, search, page). */
    public function index(Request $request, array $params): never
    {
        Auth::authorizeAny(['remittance.view', 'remittance.manage', 'report.statutory']);

        $pagination = $request->pagination();

        $result = $this->remittances->list(
            $request->query(),
            $pagination['page'],
            $pagination['per_page']
        );

        Response::paginated($result['items'], $result['total'], $pagination['page'], $pagination['per_page']);
    }

    /** GET /api/statutory/remittances/{id} */
    public function show(Request $request, array $params): never
    {
        Auth::authorizeAny(['remittance.view', 'remittance.manage', 'report.statutory']);

        try {
            $remittance = $this->remittances->find((int) ($params['id'] ?? 0));
        } catch (RuntimeException $e) {
            Response::notFound($e->getMessage());
        }

        Response::success($remittance, 'Statutory remittance retrieved successfully');
    }

    /** GET /api/statutory/remittances/{id}/items — the contribution snapshot. */
    public function items(Request $request, array $params): never
    {
        Auth::authorizeAny(['remittance.view', 'remittance.manage', 'report.statutory']);

        $pagination = $request->pagination();
        $id         = (int) ($params['id'] ?? 0);

        try {
            $result = $this->remittances->items($id, $pagination['page'], $pagination['per_page']);
        } catch (RuntimeException $e) {
            Response::notFound($e->getMessage());
        }

        Response::paginated($result['items'], $result['total'], $pagination['page'], $pagination['per_page']);
    }

    /** POST /api/statutory/remittances/generate — build (or rebuild) a window. */
    public function generate(Request $request, array $params): never
    {
        Auth::authorize('remittance.manage');

        try {
            $remittance = $this->remittances->generate($request->body(), Auth::id());
        } catch (RuntimeException $e) {
            Response::error($e->getMessage(), 422, $e instanceof \App\Core\ValidationException ? $e->errors() : []);
        }

        Response::created($remittance, 'Statutory remittance generated successfully');
    }

    /** POST /api/statutory/remittances/{id}/submit — file with the agency. */
    public function submit(Request $request, array $params): never
    {
        Auth::authorize('remittance.manage');

        $id = (int) ($params['id'] ?? 0);

        try {
            $remittance = $this->remittances->submit($id, $request->body(), Auth::id());
        } catch (RuntimeException $e) {
            Response::error($e->getMessage(), 422, $e instanceof \App\Core\ValidationException ? $e->errors() : []);
        }

        Response::success($remittance, 'Statutory remittance filed successfully');
    }

    /** POST /api/statutory/remittances/{id}/pay — confirm the payment. */
    public function pay(Request $request, array $params): never
    {
        Auth::authorize('remittance.manage');

        $id = (int) ($params['id'] ?? 0);

        try {
            $remittance = $this->remittances->pay($id, $request->body(), Auth::id());
        } catch (RuntimeException $e) {
            Response::error($e->getMessage(), 422, $e instanceof \App\Core\ValidationException ? $e->errors() : []);
        }

        Response::success($remittance, 'Statutory remittance payment confirmed');
    }
}