<?php
/**
 * Authentication endpoints (Phase 3).
 *
 *   POST /api/auth/login
 *   POST /api/auth/logout
 *   GET  /api/auth/me
 *   PUT  /api/auth/profile
 *   POST /api/auth/change-password
 */

declare(strict_types=1);

namespace App\Controllers;

use App\Core\AuditLogger;
use App\Core\Auth;
use App\Core\Database;
use App\Core\Logger;
use App\Core\Request;
use App\Core\Response;
use App\Core\Settings;
use App\Core\Validator;
use Throwable;

final class AuthController
{
    /** Login: issues a bearer token. */
    public function login(Request $request): never
    {
        // Rate limit login attempts per IP (Phase 20).
        \App\Middleware\RateLimiter::perIp($request, 'login');

        $validator = Validator::make(
            $request->body(),
            [
                'username' => 'required|string|min:1|max:100',
                'password' => 'required|string|min:1|max:255',
            ],
            ['username' => 'Username', 'password' => 'Password']
        );

        if ($validator->fails()) {
            Response::validationError($validator->errors());
        }

        $username = (string) $validator->validated()['username'];
        $password = (string) $validator->validated()['password'];

        $user = Database::selectOne(
            'SELECT u.*, r.code AS role_code, r.name AS role_name, r.permissions AS role_permissions
               FROM users u
               JOIN roles r ON r.id = u.role_id
              WHERE (u.username = :username OR u.email = :email)
                AND u.deleted_at IS NULL
              LIMIT 1',
            ['username' => $username, 'email' => $username]
        );

        if ($user === null || !password_verify($password, (string) $user['password_hash'])) {
            $this->recordAttempt($username, $request, false);
            AuditLogger::record(AuditLogger::LOGIN_FAILED, 'user', null, sprintf('Failed login for "%s"', $username), null, null, $request);

            // Same message for unknown user and wrong password, so the
            // endpoint cannot be used to enumerate accounts.
            Response::error('Invalid username or password.', 401);
        }

        // Account activation / lockout (Phase 3).
        if ($user['status'] === 'LOCKED') {
            if ($user['locked_until'] !== null && strtotime((string) $user['locked_until']) > time()) {
                $minutes = (int) ceil((strtotime((string) $user['locked_until']) - time()) / 60);
                Response::error(sprintf('Account temporarily locked. Try again in %d minute(s).', $minutes), 423);
            }

            Database::update('users', [
                'status' => 'ACTIVE', 'failed_attempts' => 0, 'locked_until' => null,
            ], ['id' => (int) $user['id']]);
        } elseif ($user['status'] !== 'ACTIVE') {
            Response::error('This account has been deactivated. Contact your administrator.', 403);
        }

        $this->recordAttempt($username, $request, true);

        $token = Auth::issueToken((int) $user['id'], $request);

        $permissions = json_decode((string) ($user['role_permissions'] ?? '[]'), true);

        Database::update('users', [
            'failed_attempts' => 0,
            'locked_until'    => null,
            'last_login_at'   => date('Y-m-d H:i:s'),
            'last_login_ip'   => $request->ip(),
        ], ['id' => (int) $user['id']]);

        AuditLogger::record(
            AuditLogger::LOGIN,
            'user',
            (int) $user['id'],
            sprintf('User "%s" signed in', $user['username']),
            null,
            null,
            $request
        );

        Logger::info('User logged in', ['user_id' => $user['id']]);

        Response::success([
            'token'      => $token['token'],
            'expires_at' => $token['expires_at'],
            'user'       => [
                'id'                   => (int) $user['id'],
                'username'             => $user['username'],
                'email'                => $user['email'],
                'full_name'            => $user['full_name'],
                'role'                 => $user['role_code'],
                'role_name'            => $user['role_name'],
                'permissions'          => \App\Core\RolePolicy::permissions((string) $user['role_code']),
                'employee_id'          => $user['employee_id'] === null ? null : (int) $user['employee_id'],
                'is_hr_reviewer'       => $user['role_code'] === 'MANAGER' && (int)(Database::scalar("SELECT setting_value FROM system_settings WHERE setting_key = 'hr.designated_reviewer_user_id'") ?? 0) === (int)$user['id'],
                'must_change_password' => (int) $user['must_change_password'] === 1,
            ],
        ], 'Signed in successfully');
    }
/** Logout: revokes the current token. */
    public function logout(Request $request): never
    {
        $token = $request->bearerToken();

        if ($token !== null) {
            Auth::revokeToken($token);
        }

        $user = Auth::user();

        AuditLogger::record(
            AuditLogger::LOGOUT,
            'user',
            $user !== null ? (int) $user['id'] : null,
            $user !== null ? sprintf('User "%s" signed out', $user['username']) : 'Session revoked',
            null,
            null,
            $request
        );

        Response::success(null, 'Signed out successfully');
    }

    /** Current user. */
    public function me(Request $request): never
    {
        $user = Auth::require($request);

        // Re-read the role in case it changed mid-session.
        $row = $this->profileRow((int) $user['id']);

        if ($row === null) {
            Response::unauthorized('This account no longer exists.');
        }

        if ($row['status'] !== 'ACTIVE') {
            Response::unauthorized('This account is no longer active.');
        }

        Response::success($this->profilePayload($row), 'Current user');
    }

    /** Update the signed-in user's own account and personal details. */
    public function updateProfile(Request $request): never
    {
        $user = Auth::require($request);
        $userId = (int) $user['id'];
        $current = $this->profileRow($userId);

        if ($current === null || $current['status'] !== 'ACTIVE') {
            Response::unauthorized('This account is no longer active.');
        }

        $hasEmployee = $current['employee_id'] !== null;
        $rules = [
            'username' => 'required|string|min:3|max:100|alphanumeric',
            'email'    => 'nullable|string|email|max:150',
        ];

        if ($hasEmployee) {
            $rules += [
                'first_name'     => 'required|string|max:100',
                'middle_name'    => 'nullable|string|max:100',
                'last_name'      => 'nullable|string|max:100',
                'suffix'         => 'nullable|string|max:20',
                'gender'         => 'required|string|in:MALE,FEMALE,OTHER',
                'birth_date'     => 'nullable|date',
                'address'        => 'nullable|string|max:255',
                'contact_number' => 'nullable|string|max:30',
            ];
        } else {
            $rules['full_name'] = 'required|string|max:150';
        }

        $validator = Validator::make($request->body(), $rules, [
            'username' => 'Username', 'email' => 'Email address', 'full_name' => 'Full name',
            'first_name' => 'First name', 'middle_name' => 'Middle name', 'last_name' => 'Last name',
            'contact_number' => 'Contact number', 'birth_date' => 'Birth date',
        ]);

        if ($validator->fails()) {
            Response::validationError($validator->errors());
        }

        $data = $validator->validated();
        foreach ($data as $key => $value) {
            if (is_string($value)) {
                $data[$key] = trim($value);
                if ($data[$key] === '' && !in_array($key, ['username', 'full_name', 'first_name', 'gender'], true)) {
                    $data[$key] = null;
                }
            }
        }

        $requiredAfterTrim = $hasEmployee ? ['username', 'first_name', 'gender'] : ['username', 'full_name'];
        foreach ($requiredAfterTrim as $field) {
            if (($data[$field] ?? '') === '') {
                Response::validationError([$field => 'This field cannot contain only spaces.']);
            }
        }

        $usernameExists = Database::scalar(
            'SELECT COUNT(*) FROM users WHERE username = :username AND id <> :id AND deleted_at IS NULL',
            ['username' => $data['username'], 'id' => $userId]
        );
        if ((int) $usernameExists > 0) {
            Response::validationError(['username' => 'That username is already in use.']);
        }

        if ($data['email'] !== null) {
            $emailExists = Database::scalar(
                'SELECT COUNT(*) FROM users WHERE email = :email AND id <> :id AND deleted_at IS NULL',
                ['email' => $data['email'], 'id' => $userId]
            );
            if ((int) $emailExists > 0) {
                Response::validationError(['email' => 'That email address is already in use.']);
            }

            if ($hasEmployee) {
                $employeeEmailExists = Database::scalar(
                    'SELECT COUNT(*) FROM employees WHERE email = :email AND id <> :id AND deleted_at IS NULL',
                    ['email' => $data['email'], 'id' => (int) $current['employee_id']]
                );
                if ((int) $employeeEmailExists > 0) {
                    Response::validationError(['email' => 'That email address is already assigned to another employee.']);
                }
            }
        }

        $oldUser = [
            'username' => $current['username'],
            'email' => $current['email'],
            'full_name' => $current['full_name'],
        ];
        $oldEmployee = $hasEmployee ? [
            'first_name' => $current['first_name'], 'middle_name' => $current['middle_name'],
            'last_name' => $current['last_name'], 'suffix' => $current['suffix'],
            'gender' => $current['gender'], 'birth_date' => $current['birth_date'],
            'address' => $current['address'], 'contact_number' => $current['contact_number'],
            'email' => $current['employee_email'],
        ] : [];

        $newEmployee = [];
        $fullName = (string) ($data['full_name'] ?? $current['full_name']);
        if ($hasEmployee) {
            $newEmployee = [
                'first_name' => $data['first_name'], 'middle_name' => $data['middle_name'],
                'last_name' => $data['last_name'], 'suffix' => $data['suffix'],
                'gender' => $data['gender'], 'birth_date' => $data['birth_date'],
                'address' => $data['address'], 'contact_number' => $data['contact_number'],
                'email' => $data['email'],
            ];
            $fullName = implode(' ', array_filter([
                $data['first_name'], $data['middle_name'], $data['last_name'], $data['suffix'],
            ], static fn (mixed $part): bool => $part !== null && $part !== ''));
        }

        $newUser = ['username' => $data['username'], 'email' => $data['email'], 'full_name' => $fullName];

        Database::transaction(function () use ($userId, $current, $hasEmployee, $newUser, $newEmployee): void {
            Database::update('users', $newUser, ['id' => $userId]);
            if ($hasEmployee) {
                Database::update('employees', $newEmployee, ['id' => (int) $current['employee_id']]);
            }
        });

        AuditLogger::recordChanges(AuditLogger::USER_CHANGED, 'user', $userId, $oldUser, $newUser);
        if ($hasEmployee) {
            AuditLogger::recordChanges(
                AuditLogger::EMPLOYEE_UPDATED,
                'employee',
                (int) $current['employee_id'],
                $oldEmployee,
                $newEmployee
            );
        }

        $updated = $this->profileRow($userId);
        Response::success($this->profilePayload($updated ?? $current), 'Profile updated successfully');
    }

    /** Change password (Phase 3). */
    public function changePassword(Request $request): never
    {
        $user = Auth::require($request);

        $minLength = Settings::int('security.password_min_length', 8);

        // The temporary password issued by an administrator reset must never
        // become the account's real password: accepting it would clear
        // must_change_password without the user actually choosing a new secret,
        // which is the entire point of the forced change.
        if ((string) $request->body('new_password') === Auth::TEMPORARY_PASSWORD) {
            Response::validationError([
                'new_password' => 'Choose a different password from the temporary one.',
            ]);
        }

        $validator = Validator::make(
            $request->body(),
            [
                'current_password' => 'required|string|min:1|max:255',
                'new_password'     => 'required|string|min:' . $minLength . '|max:255|different:current_password',
                'confirm_password' => 'required|string|same:new_password',
            ],
            [
                'current_password' => 'Current password',
                'new_password'     => 'New password',
                'confirm_password' => 'Password confirmation',
            ]
        );

        if ($validator->fails()) {
            Response::validationError($validator->errors());
        }

        $validated = $validator->validated();

        $row = Database::selectOne(
            'SELECT id, password_hash FROM users WHERE id = :id LIMIT 1',
            ['id' => (int) $user['id']]
        );

        if ($row === null || !password_verify((string) $validated['current_password'], (string) $row['password_hash'])) {
            Response::validationError(['current_password' => 'The current password is incorrect.']);
        }

        Database::update('users', [
            'password_hash'        => password_hash((string) $validated['new_password'], PASSWORD_DEFAULT),
            'must_change_password' => 0,
        ], ['id' => (int) $user['id']]);

        // Every other session is invalidated after a password change.
        Auth::revokeAllTokens((int) $user['id']);

        $newToken = Auth::issueToken((int) $user['id'], $request);

        AuditLogger::record(
            AuditLogger::PASSWORD_CHANGED,
            'user',
            (int) $user['id'],
            sprintf('Password changed for "%s"', $user['username']),
            null,
            null,
            $request
        );

        Response::success([
            'token'      => $newToken['token'],
            'expires_at' => $newToken['expires_at'],
        ], 'Password changed successfully');
    }
/** Record a login attempt and lock the account when needed (Phase 20). */
    private function recordAttempt(string $identifier, Request $request, bool $success): void
    {
        try {
            Database::insert('login_attempts', [
                'identifier' => mb_substr($identifier, 0, 100),
                'ip_address' => $request->ip(),
                'success'    => $success ? 1 : 0,
                'user_agent' => $request->userAgent(),
            ]);

            if ($success) {
                return;
            }

            $lockoutMinutes = Settings::int('security.lockout_minutes', 15);
            $max            = Settings::int('security.max_login_attempts', 5);

            $failed = (int) (Database::scalar(
                'SELECT COUNT(*) FROM login_attempts
                  WHERE identifier = :ident AND success = 0
                    AND attempted_at > DATE_SUB(NOW(), INTERVAL :lockout MINUTE)',
                ['ident' => mb_substr($identifier, 0, 100), 'lockout' => $lockoutMinutes]
            ) ?? 0);

            if ($failed >= $max) {
                Database::execute(
                    'UPDATE users SET status = :status, locked_until = :until
                      WHERE (username = :username OR email = :email) AND deleted_at IS NULL',
                    [
                        'status'   => 'LOCKED',
                        'until'    => date('Y-m-d H:i:s', time() + ($lockoutMinutes * 60)),
                        'username' => $identifier,
                        'email'    => $identifier,
                    ]
                );

                Logger::warning('Account locked after failed attempts', ['identifier' => $identifier]);
            }
        } catch (Throwable $e) {
            Logger::error('Failed to record login attempt', ['error' => $e->getMessage()]);
        }
    }

    /** @return array<string, mixed>|null */
    private function profileRow(int $userId): ?array
    {
        return Database::selectOne(
            'SELECT u.*, r.code AS role_code, r.name AS role_name, r.permissions AS role_permissions,
                    e.employee_number, e.first_name, e.middle_name, e.last_name, e.suffix,
                    e.gender, e.birth_date, e.address, e.contact_number, e.email AS employee_email
               FROM users u
               JOIN roles r ON r.id = u.role_id
               LEFT JOIN employees e ON e.id = u.employee_id AND e.deleted_at IS NULL
              WHERE u.id = :id AND u.deleted_at IS NULL
              LIMIT 1',
            ['id' => $userId]
        );
    }

    /** @param array<string, mixed> $row @return array<string, mixed> */
    private function profilePayload(array $row): array
    {
        $permissions = json_decode((string) ($row['role_permissions'] ?? '[]'), true);

        return [
            'id'                   => (int) $row['id'],
            'username'             => $row['username'],
            'email'                => $row['email'],
            'full_name'            => $row['full_name'],
            'role'                 => $row['role_code'],
            'role_name'            => $row['role_name'],
            'permissions'          => \App\Core\RolePolicy::permissions((string) $row['role_code']),
            'employee_id'          => $row['employee_id'] === null ? null : (int) $row['employee_id'],
            'is_hr_reviewer'       => $row['role_code'] === 'MANAGER' && (int)(Database::scalar("SELECT setting_value FROM system_settings WHERE setting_key = 'hr.designated_reviewer_user_id'") ?? 0) === (int)$row['id'],
            'employee_number'       => $row['employee_number'] ?? null,
            'must_change_password' => (int) $row['must_change_password'] === 1,
            'last_login_at'        => $row['last_login_at'],
            'first_name'           => $row['first_name'] ?? null,
            'middle_name'          => $row['middle_name'] ?? null,
            'last_name'            => $row['last_name'] ?? null,
            'suffix'               => $row['suffix'] ?? null,
            'gender'               => $row['gender'] ?? null,
            'birth_date'           => $row['birth_date'] ?? null,
            'address'              => $row['address'] ?? null,
            'contact_number'       => $row['contact_number'] ?? null,
        ];
    }
}
