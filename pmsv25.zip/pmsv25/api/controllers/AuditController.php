<?php
/**
 * Audit log endpoints (Phase 18).
 */

declare(strict_types=1);

namespace App\Controllers;

use App\Core\AuditLogger;
use App\Core\Auth;
use App\Core\Database;
use App\Core\Request;
use App\Core\Response;

final class AuditController
{
    /** GET /api/audit — the audit trail with filters. */
    public function index(Request $request, array $params): never
    {
        Auth::authorize('audit.view');

        $where       = ['1 = 1'];
        $queryParams = [];

        if (!empty($request->query('action'))) {
            $where[] = 'action = :action';
            $queryParams['action'] = (string) $request->query('action');
        }

        if (!empty($request->query('entity_type'))) {
            $where[] = 'entity_type = :entity_type';
            $queryParams['entity_type'] = (string) $request->query('entity_type');
        }

        if (!empty($request->query('entity_id'))) {
            $where[] = 'entity_id = :entity_id';
            $queryParams['entity_id'] = (string) $request->query('entity_id');
        }

        if (!empty($request->query('user_id'))) {
            $where[] = 'user_id = :user_id';
            $queryParams['user_id'] = (int) $request->query('user_id');
        }

        if (!empty($request->query('date_from'))) {
            $where[] = 'created_at >= :date_from';
            $queryParams['date_from'] = (string) $request->query('date_from') . ' 00:00:00';
        }

        if (!empty($request->query('date_to'))) {
            $where[] = 'created_at <= :date_to';
            $queryParams['date_to'] = (string) $request->query('date_to') . ' 23:59:59';
        }

        $search = trim((string) $request->query('q', ''));

        if ($search !== '') {
            $where[] = '(description LIKE :q1 OR username LIKE :q2)';
            $queryParams['q1'] = '%' . $search . '%';
            $queryParams['q2'] = '%' . $search . '%';
        }

        $whereSql = implode(' AND ', $where);

        $total = (int) (Database::scalar(
            "SELECT COUNT(*) FROM audit_logs WHERE {$whereSql}",
            $queryParams
        ) ?? 0);

        $pagination = $request->pagination();
        $offset     = max(0, ($pagination['page'] - 1) * $pagination['per_page']);
        $perPage    = $pagination['per_page'];

        $items = Database::select(
            "SELECT al.id, al.user_id, al.username, al.action, al.entity_type, al.entity_id,
                    al.description, al.old_value, al.new_value, al.ip_address, al.user_agent,
                    al.created_at
               FROM audit_logs al
              WHERE {$whereSql}
              ORDER BY al.id DESC
              LIMIT {$perPage} OFFSET {$offset}",
            $queryParams
        );

        // Decode the old/new JSON values for the UI.
        foreach ($items as &$item) {
            foreach (['old_value', 'new_value'] as $field) {
                if ($item[$field] !== null) {
                    $decoded = json_decode((string) $item[$field], true);
                    $item[$field] = is_array($decoded) ? $decoded : $item[$field];
                }
            }
        }
        unset($item);

        // Turns the user-agent sample marker into the boolean `is_sample` the
        // audit page badges on, so demo rows stay identifiable while the raw
        // fingerprint never leaves the API. See AuditLogger::SAMPLE_USER_AGENT.
        $items = AuditLogger::flagSampleRows($items);

        Response::paginated($items, $total, $pagination['page'], $pagination['per_page']);
    }

    /** GET /api/audit/actions — the distinct actions recorded. */
    public function actions(Request $request, array $params): never
    {
        Auth::authorize('audit.view');

        Response::success(
            Database::select(
                'SELECT action, COUNT(*) AS count FROM audit_logs GROUP BY action ORDER BY action'
            ),
            'Audit actions retrieved successfully'
        );
    }
}