<?php
/**
 * Dashboard endpoints (Phase 16).
 */

declare(strict_types=1);

namespace App\Controllers;

use App\Core\Auth;
use App\Core\Request;
use App\Core\Response;
use App\Core\Settings;
use App\Services\DashboardService;

final class DashboardController
{
    public function __construct(private DashboardService $dashboard = new DashboardService())
    {
    }

    /** GET /api/dashboard */
    public function index(Request $request, array $params): never
    {
        Auth::require($request);

        // An employee sees their own counts; HR/payroll see everything.
        $employeeId = (\App\Core\DemoStaffScope::enabled() || Auth::roleCode() !== 'MANAGER') && Auth::hasAnyPermission(['employees.view', 'attendance.view', 'payroll.view'])
            ? 0
            : (Auth::employeeId() ?? 0);

        $overview = $this->dashboard->overview($employeeId);
        if (Auth::roleCode() === 'ADMIN') {
            $overview['payroll'] = null;
            $overview['pending_leave'] = [];
            $overview['pending_overtime'] = [];
            if (isset($overview['charts']['payroll_trend'])) { $overview['charts']['payroll_trend'] = []; }
        }
        Response::success($overview, 'Dashboard retrieved successfully');
    }

    /** GET /api/dashboard/cards */
    public function cards(Request $request, array $params): never
    {
        Auth::authorize('dashboard.view');

        if ((\App\Core\DemoStaffScope::enabled() || Auth::roleCode() !== 'MANAGER') && Auth::hasAnyPermission(['employees.view', 'attendance.view', 'payroll.view'])) {
            Response::success($this->dashboard->cards(), 'Dashboard cards retrieved successfully');
        }

        $employeeId = Auth::employeeId();
        if ($employeeId === null) {
            Response::forbidden('Your account is not linked to an employee record.');
        }
        $overview = $this->dashboard->overview($employeeId);
        Response::success($overview['cards'], 'Dashboard cards retrieved successfully');
    }

    /** GET /api/dashboard/charts */
    public function charts(Request $request, array $params): never
    {
        Auth::authorize('dashboard.view');

        if ((\App\Core\DemoStaffScope::enabled() || Auth::roleCode() !== 'MANAGER') && Auth::hasAnyPermission(['employees.view', 'attendance.view', 'payroll.view'])) {
            Response::success($this->dashboard->charts(), 'Dashboard charts retrieved successfully');
        }

        $employeeId = Auth::employeeId();
        if ($employeeId === null) {
            Response::forbidden('Your account is not linked to an employee record.');
        }
        $overview = $this->dashboard->overview($employeeId);
        Response::success($overview['charts'], 'Dashboard charts retrieved successfully');
    }

    /** GET /api/dashboard/holidays - calendar-safe holiday data for every dashboard user. */
    public function holidays(Request $request, array $params): never
    {
        Auth::authorize('dashboard.view');
        $year = (int) ($request->query('year', date('Y')) ?: date('Y'));
        Response::success($this->dashboard->holidaysForYear($year), 'Dashboard holidays retrieved successfully');
    }

    /** GET /api/dashboard/activities - paginated, filterable activity feed. */
    public function activities(Request $request, array $params): never
    {
        Auth::authorize('audit.view');

        $page = max(1, (int) ($request->query('page', 1) ?: 1));
        $default = max(5, min(50, Settings::int('dashboard.recent_activities_per_page', 10)));
        $perPage = max(5, min(100, (int) ($request->query('per_page', $default) ?: $default)));
        $result = $this->dashboard->activityPage([
            'q'         => trim((string) $request->query('q', '')),
            'action'    => trim((string) $request->query('action', '')),
            'username'  => trim((string) $request->query('username', '')),
            'date_from' => trim((string) $request->query('date_from', '')),
            'date_to'   => trim((string) $request->query('date_to', '')),
        ], $page, $perPage);

        Response::paginated($result['items'], $result['total'], $page, $perPage, 'Activities retrieved successfully');
    }
}
