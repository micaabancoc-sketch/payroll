<?php
/**
 * Holiday admin endpoints (Phase 9).
 */

declare(strict_types=1);

namespace App\Controllers;

use App\Core\Request;
use App\Core\Response;
use App\Services\HolidayService;

final class HolidayController
{
    public function __construct(private HolidayService $holidays = new HolidayService())
    {
    }

    /** GET /api/holidays */
    public function index(Request $request, array $params): never
    {
        $year = $request->query('year');
        $type = $request->query('type');
        $archived = strtolower(trim((string) $request->query('archived', ''))) === 'only';

        Response::success(
            $this->holidays->all(
                $year !== null && $year !== '' ? (int) $year : null,
                $type !== null && $type !== '' ? (string) $type : null,
                $archived
            ),
            'Holidays retrieved successfully'
        );
    }

    /** GET /api/holidays/upcoming */
    public function upcoming(Request $request, array $params): never
    {
        Response::success($this->holidays->upcoming(6), 'Upcoming holidays retrieved successfully');
    }

    /** GET /api/holidays/{id} */
    public function show(Request $request, array $params): never
    {
        $holiday = $this->holidays->find((int) ($params['id'] ?? 0));

        if ($holiday === null) {
            Response::notFound('Holiday not found.');
        }

        Response::success($holiday, 'Holiday retrieved successfully');
    }
/** POST /api/holidays — create (Phase 9). */
    public function store(Request $request, array $params): never
    {
        try {
            $holiday = $this->holidays->create($request->body());
        } catch (\RuntimeException $e) {
            Response::error($e->getMessage(), 422, $e instanceof \App\Core\ValidationException ? $e->errors() : []);
        }

        Response::created($holiday, 'Holiday created successfully');
    }

    /** PUT /api/holidays/{id} — update (Phase 9). */
    public function update(Request $request, array $params): never
    {
        try {
            $holiday = $this->holidays->update((int) ($params['id'] ?? 0), $request->body());
        } catch (\RuntimeException $e) {
            Response::error($e->getMessage(), 422, $e instanceof \App\Core\ValidationException ? $e->errors() : []);
        }

        Response::success($holiday, 'Holiday updated successfully');
    }

    /** POST /api/holidays/{id}/restore — return an archived holiday to its list */
    public function restore(Request $request, array $params): never
    {
        try {
            $holiday = $this->holidays->restore((int) ($params['id'] ?? 0));
        } catch (\RuntimeException $e) {
            Response::error($e->getMessage(), 422, $e instanceof \App\Core\ValidationException ? $e->errors() : []);
        }

        Response::success($holiday, 'Holiday restored successfully');
    }

    /** DELETE /api/holidays/{id} */
    public function destroy(Request $request, array $params): never
    {
        try {
            $result = $this->holidays->delete((int) ($params['id'] ?? 0));
        } catch (\RuntimeException $e) {
            Response::notFound($e->getMessage());
        }

        Response::success($result, 'Holiday deleted successfully');
    }
}