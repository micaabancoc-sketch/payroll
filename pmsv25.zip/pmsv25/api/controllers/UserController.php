<?php
/**
 * User management endpoints (Phase 3).
 */

declare(strict_types=1);

namespace App\Controllers;

use App\Core\AuditLogger;
use App\Core\Auth;
use App\Core\Database;
use App\Core\Request;
use App\Core\Response;
use App\Core\Settings;
use App\Core\Validator;
use App\Services\QrCodeService;
use Throwable;

final class UserController
{
    /** GET /api/users */
    public function index(Request $request, array $params): never
    {
        Auth::authorizeAny(['user.view', 'settings.manage']);

        $where       = ['1 = 1'];
        $queryParams = [];

        $archiveMode = strtolower(trim((string) ($request->query('archived') ?? 'false')));
        if ($archiveMode === 'only') {
            $where[] = 'u.deleted_at IS NOT NULL';
        } elseif (!filter_var($archiveMode, FILTER_VALIDATE_BOOLEAN)) {
            $where[] = 'u.deleted_at IS NULL';
        }

        if (!empty($request->query('role'))) {
            $where[] = 'r.code = :role';
            $queryParams['role'] = (string) $request->query('role');
        }

        if (!empty($request->query('status'))) {
            $where[] = 'u.status = :status';
            $queryParams['status'] = (string) $request->query('status');
        }

        $search = trim((string) $request->query('q', ''));

        if ($search !== '') {
            $where[] = '(u.username LIKE :q1 OR u.full_name LIKE :q2 OR u.email LIKE :q3)';
            $queryParams['q1'] = '%' . $search . '%';
            $queryParams['q2'] = '%' . $search . '%';
            $queryParams['q3'] = '%' . $search . '%';
        }

        $whereSql = implode(' AND ', $where);

        $total = (int) (Database::scalar(
            "SELECT COUNT(*) FROM users u JOIN roles r ON r.id = u.role_id WHERE {$whereSql}",
            $queryParams
        ) ?? 0);

        $pagination = $request->pagination();
        $offset     = max(0, ($pagination['page'] - 1) * $pagination['per_page']);
        $perPage    = $pagination['per_page'];

        $items = Database::select(
            "SELECT u.id, u.username, u.email, u.full_name, u.status, u.role_id,
                    u.employee_id, u.last_login_at, u.last_login_ip, u.created_at,
                    r.code AS role_code, r.name AS role_name,
                    e.id AS linked_employee_exists,
                    qr.id AS active_qr_id, qr.qr_image_path AS active_qr_path,
                    qr.expires_at AS active_qr_expires
               FROM users u
               JOIN roles r ON r.id = u.role_id
               LEFT JOIN employees e ON e.id = u.employee_id AND e.deleted_at IS NULL
               LEFT JOIN employee_qr_codes qr ON qr.id = (
                  SELECT qr2.id FROM employee_qr_codes qr2
                  WHERE qr2.employee_id = u.employee_id AND qr2.status = 'ACTIVE'
                  ORDER BY qr2.serial_no DESC LIMIT 1
               )
              WHERE {$whereSql}
              ORDER BY u.username
              LIMIT {$perPage} OFFSET {$offset}",
            $queryParams
        );

        // Only QR metadata/status is sent; never expose the QR bearer token.
        foreach ($items as &$item) {
            if (!in_array((string)$item['role_code'], ['HR_PAYROLL', 'MANAGER', 'STAFF'], true)) {
                $item['qr_status'] = 'NOT_APPLICABLE';
            } elseif (empty($item['employee_id']) || empty($item['linked_employee_exists'])) {
                $item['qr_status'] = 'UNLINKED';
            } elseif (empty($item['active_qr_id'])) {
                $item['qr_status'] = 'MISSING';
            } elseif (!empty($item['active_qr_expires']) && strtotime((string)$item['active_qr_expires']) < time()) {
                $item['qr_status'] = 'EXPIRED';
            } else {
                $relative = (string)($item['active_qr_path'] ?? '');
                $storage = Database::config()['paths']['storage'];
                $image = $relative !== '' ? $storage . DIRECTORY_SEPARATOR . str_replace('/', DIRECTORY_SEPARATOR, $relative) : '';
                $item['qr_status'] = ($image !== '' && is_file($image) && is_readable($image)) ? 'ACTIVE' : 'MISSING_IMAGE';
            }
            unset($item['active_qr_id'], $item['active_qr_path'], $item['active_qr_expires'], $item['linked_employee_exists']);
        }
        unset($item);

        Response::paginated($items, $total, $pagination['page'], $pagination['per_page']);
    }
    /**
     * Backfill QRs for existing active employee user accounts only.
     * This does not regenerate or invalidate ANY existing ACTIVE QR credentials.
     * Only Admin (IT) may issue QR credentials; not HR/Manager/Staff/Kiosk.
     */
    public function issueMissingQrs(Request $request, array $params): never
    {
        Auth::authorize('settings.manage');
        Auth::authorize('qr.generate');

        $employeeIds = Database::select(
            "SELECT DISTINCT e.id
               FROM employees e
               JOIN users u ON u.employee_id = e.id AND u.deleted_at IS NULL AND u.status = 'ACTIVE'
               JOIN roles r ON r.id = u.role_id
              WHERE e.deleted_at IS NULL AND e.archived_at IS NULL AND e.status = 'ACTIVE'
                AND r.code IN ('HR_PAYROLL', 'MANAGER', 'STAFF')"
              . \App\Core\DemoStaffScope::excludingRoles('e.id')
              . \App\Core\DemoStaffScope::excludingDemoUsernames('e.id') . "
                AND NOT EXISTS (
                    SELECT 1 FROM employee_qr_codes qr
                     WHERE qr.employee_id = e.id AND qr.status = 'ACTIVE'
                )
              ORDER BY e.id
              LIMIT 100"
        );
        $qrService = new QrCodeService();
        $issued = 0;
        $failed = [];
        foreach ($employeeIds as $row) {
            $employeeId = (int)$row['id'];
            try {
                $issuedQr = $qrService->issue($employeeId, Auth::id(), false);
                AuditLogger::record(
                    AuditLogger::QR_GENERATED, 'employee_qr_code', $issuedQr['qr_id'],
                    sprintf('Backfilled missing attendance QR for existing employee %d', $employeeId)
                );
                ++$issued;
            } catch (\Throwable $error) {
                $failed[] = $employeeId; // No QR secret or exception details exposed to the browser.
            }
        }
        Response::success([
            'issued' => $issued,
            'failed_employee_ids' => $failed,
            'batch_limit' => 100,
            'note' => 'Active QR codes were preserved. Accounts without employee links require manual linking.'
        ], 'Existing employee QR backfill completed');
    }

    /** Verify employee linkage without guessing identity based on matching names. */
    private function assertAvailableEmployeeLink(int $employeeId, ?int $exceptUserId = null): void
    {
        $employee = Database::selectOne(
            'SELECT id FROM employees WHERE id = :id AND deleted_at IS NULL',
            ['id' => $employeeId]
        );
        if ($employee === null) {
            Response::validationError(['employee_id' => 'The selected employee ID does not exist.']);
        }
        $params = ['employee_id' => $employeeId];
        $exceptSql = '';
        if ($exceptUserId !== null) {
            $exceptSql = ' AND id <> :except_id';
            $params['except_id'] = $exceptUserId;
        }
        $owner = Database::selectOne(
            'SELECT id FROM users WHERE employee_id = :employee_id AND deleted_at IS NULL' . $exceptSql . ' LIMIT 1',
            $params
        );
        if ($owner !== null) {
            Response::validationError(['employee_id' => 'This employee is already linked to another user account.']);
        }
    }

    /** GET /api/users/roles */
    public function roles(Request $request, array $params): never
    {
        Auth::authorize('settings.manage');

        $rows = Database::select('SELECT id, code, name, description, permissions FROM roles ORDER BY id');

        foreach ($rows as &$row) {
            $decoded = json_decode((string) $row['permissions'], true);
            $row['permissions'] = \App\Core\RolePolicy::permissions((string)$row['code']);
        }
        unset($row);

        Response::success($rows, 'Roles retrieved successfully');
    }

    /** GET /api/roles/permissions - permissions available to managed roles. */
    public function permissionCatalog(Request $request, array $params): never
    {
        Auth::authorize('settings.manage');
        Response::success($this->permissionGroups(), 'Permission catalog retrieved successfully');
    }

    /** PUT /api/roles/{id}/permissions - edit non-Admin permissions with role separation. */
    public function updateRolePermissions(Request $request, array $params): never
    {
        Auth::authorize('settings.manage');
        $id = (int) ($params['id'] ?? 0);
        $role = Database::selectOne('SELECT id, code, name, permissions FROM roles WHERE id = :id', ['id' => $id]);

        if ($role === null) {
            Response::notFound('Role not found.');
        }
        if ($role['code'] === 'ADMIN') {
            Response::validationError(['role' => 'Administrator access is fixed and cannot be reduced.']);
        }

        $submitted = $request->body()['permissions'] ?? null;
        if (!is_array($submitted)) {
            Response::validationError(['permissions' => 'Permissions must be supplied as a list.']);
        }

        $allowed = [];
        foreach ($this->permissionGroups() as $group) {
            foreach ($group['permissions'] as $permission) {
                $allowed[$permission['key']] = true;
            }
        }

        $selected = ['dashboard.view'];
        foreach ($submitted as $permission) {
            if (is_string($permission) && isset($allowed[$permission])) {
                $selected[] = $permission;
            }
        }
        $selected = array_values(array_unique($selected));
        // Enforce *backend* allowlists. Hiding sidebar links alone is not access control.
        // Settings can remove role permissions, never grant cross-role duties.
        $allowedByRole = [
            'HR_PAYROLL' => ['dashboard.view', 'employees.view', 'employees.create', 'employees.update', 'employees.archive', 'employees.restore', 'attendance.view', 'attendance.view_own', 'attendance.create', 'attendance.update', 'attendance.adjust', 'schedule.view', 'holiday.view', 'leave.view', 'leave.view_own', 'leave.create', 'payroll.view', 'payroll.view_own', 'payroll.period.view', 'payroll.period.create', 'payroll.calculate', 'payroll.payslip.view', 'payroll.payslip.view_own', 'payroll.payments.view', 'loans.view', 'loans.create', 'loans.update', 'loans.payment', 'report.payroll', 'report.attendance', 'report.leave', 'report.statutory', 'remittance.view', 'remittance.manage'],
            'MANAGER' => ['dashboard.view', 'employees.view', 'attendance.view', 'attendance.view_own', 'attendance.create', 'attendance.update', 'attendance.adjust', 'attendance.override', 'schedule.view', 'holiday.view', 'leave.view', 'leave.view_own', 'leave.create', 'leave.approve', 'overtime.view_own', 'overtime.create', 'payroll.view', 'payroll.view_own', 'payroll.period.view', 'payroll.approve', 'payroll.payslip.view', 'payroll.payslip.view_own', 'payroll.payments.view', 'report.attendance', 'report.leave', 'report.payroll'],
            'STAFF' => ['dashboard.view', 'attendance.view_own', 'leave.view_own', 'leave.create', 'leave.cancel_own', 'overtime.view_own', 'payroll.view_own', 'payroll.payslip.view_own', 'profile.view_own', 'profile.update_own', 'loans.create', 'loans.view_own'],
        ];
        $invalid = array_values(array_diff($selected, $allowedByRole[(string) $role['code']] ?? []));
        if ($invalid !== []) {
            Response::validationError(['permissions' => 'Permissions reserved for another role: ' . implode(', ', $invalid)]);
        }
        $before = json_decode((string) $role['permissions'], true);
        $before = is_array($before) ? $before : [];

        Database::update('roles', [
            'permissions' => json_encode($selected, JSON_UNESCAPED_SLASHES),
        ], ['id' => $id]);

        AuditLogger::record(
            AuditLogger::SETTINGS_CHANGED,
            'role',
            $id,
            sprintf('Updated role-based access for %s', $role['name']),
            ['permissions' => $before],
            ['permissions' => $selected]
        );

        Response::success(['id' => $id, 'code' => $role['code'], 'permissions' => $selected], 'Role access updated successfully');
    }

    /** @return list<array{group:string,description:string,permissions:list<array{key:string,label:string}>}> */
    private function permissionGroups(): array
    {
        return [
            ['group' => 'Workspace', 'description' => 'Basic system entry and dashboard visibility.', 'permissions' => [
                ['key' => 'dashboard.view', 'label' => 'View dashboard'],
            ]],
            ['group' => 'Employees', 'description' => 'Employee directory and employment records.', 'permissions' => [
                ['key' => 'employees.view', 'label' => 'View employees'], ['key' => 'employees.create', 'label' => 'Create employees'],
                ['key' => 'employees.update', 'label' => 'Edit employees'], ['key' => 'employees.archive', 'label' => 'Archive employees'],
                ['key' => 'employees.restore', 'label' => 'Restore employees'], ['key' => 'employees.delete', 'label' => 'Permanently delete employees'],
            ]],
            ['group' => 'Attendance and QR', 'description' => 'Attendance records, adjustments, and QR credentials.', 'permissions' => [
                ['key' => 'attendance.view', 'label' => 'View all attendance'], ['key' => 'attendance.view_own', 'label' => 'View own attendance'],
                ['key' => 'attendance.create', 'label' => 'Record attendance'], ['key' => 'attendance.update', 'label' => 'Edit attendance'],
                ['key' => 'attendance.delete', 'label' => 'Delete attendance'], ['key' => 'attendance.scan', 'label' => 'Use QR scanner'],
                ['key' => 'attendance.adjust', 'label' => 'Adjust attendance'], ['key' => 'qr.view', 'label' => 'View QR credentials'],
                ['key' => 'qr.generate', 'label' => 'Generate QR credentials'], ['key' => 'qr.regenerate', 'label' => 'Regenerate QR credentials'],
                ['key' => 'qr.disable', 'label' => 'Disable QR credentials'],
            ]],
            ['group' => 'Schedules and holidays', 'description' => 'Work schedules, shifts, and holiday calendars.', 'permissions' => [
                ['key' => 'schedule.view', 'label' => 'View schedules'], ['key' => 'schedule.manage', 'label' => 'Manage schedules'],
                ['key' => 'holiday.view', 'label' => 'View holidays'], ['key' => 'holiday.manage', 'label' => 'Manage holidays'],
            ]],
            ['group' => 'Leave', 'description' => 'Leave balances, requests, and approvals.', 'permissions' => [
                ['key' => 'leave.view', 'label' => 'View all leave'], ['key' => 'leave.view_own', 'label' => 'View own leave'],
                ['key' => 'leave.create', 'label' => 'Create leave requests'], ['key' => 'leave.update_own', 'label' => 'Edit own leave requests'],
                ['key' => 'leave.approve', 'label' => 'Approve leave requests'], ['key' => 'leave.cancel_own', 'label' => 'Cancel own leave requests'],
            ]],
            ['group' => 'Overtime', 'description' => 'Manager-assigned overtime; employees can view their own assignments.', 'permissions' => [
                ['key' => 'overtime.view', 'label' => 'View all overtime'], ['key' => 'overtime.view_own', 'label' => 'View own overtime'],
                ['key' => 'overtime.create', 'label' => 'Assign overtime (Manager only)'],
                ['key' => 'overtime.approve', 'label' => 'Confirm overtime for payroll'],
            ]],
            ['group' => 'Payroll', 'description' => 'Payroll periods, computation, approval, and payslips.', 'permissions' => [
                ['key' => 'payroll.view', 'label' => 'View all payroll'], ['key' => 'payroll.view_own', 'label' => 'View own payroll'],
                ['key' => 'payroll.period.view', 'label' => 'View payroll periods'], ['key' => 'payroll.period.create', 'label' => 'Create payroll periods'],
                ['key' => 'payroll.calculate', 'label' => 'Calculate payroll'], ['key' => 'payroll.approve', 'label' => 'Approve payroll'],
                ['key' => 'payroll.finalize', 'label' => 'Finalize payroll'], ['key' => 'payroll.mark_paid', 'label' => 'Mark payroll paid'],
                ['key' => 'payroll.payments.view', 'label' => 'View individual payroll payments'], ['key' => 'payroll.payments.record', 'label' => 'Record individual payroll payments'],
                ['key' => 'payroll.payments.cancel', 'label' => 'Cancel or reverse payroll payments'],
                ['key' => 'payroll.payslip.view', 'label' => 'View all payslips'], ['key' => 'payroll.payslip.view_own', 'label' => 'View own payslips'],
            ]],
            ['group' => 'Loans', 'description' => 'Employee loans, repayments, and outstanding balances.', 'permissions' => [
                ['key' => 'loans.view', 'label' => 'View loans and repayment ledger'],
                ['key' => 'loans.create', 'label' => 'Record loans'],
                ['key' => 'loans.update', 'label' => 'Edit open loan terms'],
                ['key' => 'loans.payment', 'label' => 'Record repayments, cancel and restore loans'],
                ['key' => 'loans.approve', 'label' => 'Approve or reject filed loans'],
            ]],
            ['group' => 'Reports and oversight', 'description' => 'Operational reports, ledgers, and audit history.', 'permissions' => [
                ['key' => 'report.payroll', 'label' => 'Payroll reports'], ['key' => 'report.attendance', 'label' => 'Attendance reports and ledger'],
                ['key' => 'report.leave', 'label' => 'Leave reports'], ['key' => 'report.statutory', 'label' => 'Statutory contribution reports'],
                ['key' => 'audit.view', 'label' => 'View audit log'],
            ]],
            ['group' => 'Statutory remittances', 'description' => 'Government remittance register, filing and payment confirmation.', 'permissions' => [
                ['key' => 'remittance.view', 'label' => 'View statutory remittances'],
                ['key' => 'remittance.manage', 'label' => 'Generate, file and confirm statutory remittances'],
            ]],
            ['group' => 'Personal profile', 'description' => 'Employee self-service profile access.', 'permissions' => [
                ['key' => 'profile.view_own', 'label' => 'View own profile'], ['key' => 'profile.update_own', 'label' => 'Edit own profile'],
            ]],
        ];
    }
/** POST /api/users — create a user account (Phase 3). */
    public function store(Request $request, array $params): never
    {
        Auth::authorize('settings.manage');

        $validator = Validator::make(
            $request->body(),
            [
                'username'    => 'required|string|min:3|max:100|alphanumeric',
                'email'       => 'nullable|email|max:150',
                'full_name'   => 'required|string|min:2|max:150',
                'role_id'     => 'required|integer',
                'password'    => 'required|string|min:' . Settings::int('security.password_min_length', 8) . '|max:255',
                'employee_id' => 'nullable|integer',
            ],
            ['role_id' => 'Role', 'employee_id' => 'Employee']
        );

        if ($validator->fails()) {
            Response::validationError($validator->errors());
        }

        $validated = $validator->validated();

        if (Database::scalar('SELECT id FROM users WHERE username = :u', ['u' => $validated['username']]) !== null) {
            Response::validationError(['username' => 'That username is already taken.']);
        }

        $selectedRole = Database::selectOne('SELECT code FROM roles WHERE id = :role_id', ['role_id' => (int)$validated['role_id']]);
        $roleCode = (string)($selectedRole['code'] ?? '');
        if (!in_array($roleCode, ['ADMIN', 'HR_PAYROLL', 'MANAGER', 'STAFF', 'KIOSK'], true)) {
            Response::validationError(['role_id' => 'Select a supported role.']);
        }
        if (in_array($roleCode, ['ADMIN', 'KIOSK'], true) && !empty($validated['employee_id'])) {
            Response::validationError(['employee_id' => 'Technical accounts cannot link to an employee.']);
        }
        if (in_array($roleCode, ['HR_PAYROLL', 'MANAGER', 'STAFF'], true) && empty($validated['employee_id'])) {
            Response::validationError(['employee_id' => 'Employee accounts require a linked employee.']);
        }
        if (!empty($validated['employee_id'])) {
            $this->assertAvailableEmployeeLink((int)$validated['employee_id']);
        }
        $userId = Database::insert('users', [
            'username'      => $validated['username'],
            'email'         => $validated['email'] ?? null,
            'password_hash' => password_hash((string) $validated['password'], PASSWORD_DEFAULT),
            'full_name'     => $validated['full_name'],
            'role_id'       => (int) $validated['role_id'],
            'employee_id'   => $validated['employee_id'] ?? null,
            // New accounts are always usable immediately. Status is an edit-only
            // control so a crafted create request cannot silently disable a user.
            'status'        => 'ACTIVE',
        ]);

        AuditLogger::record(
            AuditLogger::USER_CHANGED,
            'user',
            $userId,
            sprintf('Created user "%s"', $validated['username'])
        );

        Response::created(['id' => $userId], 'User created successfully');
    }
/** PUT /api/users/{id} — update role, status or details (Phase 3). */
    public function update(Request $request, array $params): never
    {
        Auth::authorizeAny(['user.view', 'settings.manage']);

        $id       = (int) ($params['id'] ?? 0);
        $existing = Database::selectOne('SELECT * FROM users WHERE id = :id AND deleted_at IS NULL', ['id' => $id]);

        if ($existing === null) {
            Response::notFound('User not found.');
        }

        // Only the administrator may modify the protected administrator account.
        if ((int) $existing['role_id'] === 1 && !Auth::isSuperAdmin()) {
            Response::forbidden('Only an administrator can modify this account.');
        }

        $validated = Validator::make(
            $request->body(),
            [
                'email'       => 'nullable|email|max:150',
                'full_name'   => 'nullable|string|min:2|max:150',
                'role_id'     => 'nullable|integer',
                'status'      => 'nullable|in:ACTIVE,INACTIVE',
                'employee_id' => 'nullable|integer',
            ],
            ['role_id' => 'Role', 'employee_id' => 'Employee']
        );

        if ($validated->fails()) {
            Response::validationError($validated->errors());
        }

        $fields  = $validated->validated();
        // Validator includes nullable fields as null even when the client did not send them.
        // On PATCH-like PUT requests (e.g. {status: 'ACTIVE'}), only update fields
        // explicitly supplied by the client. Otherwise employee_id is cleared and
        // existing linked STAFF/HR/MANAGER accounts cannot be activated.
        $submitted = $request->body();
        $payload = [];

        if ($id === Auth::id() && ($fields['status'] ?? null) === 'INACTIVE') {
            Response::validationError([
                'status' => 'You cannot deactivate your own signed-in account.',
            ]);
        }

        foreach (['email', 'full_name', 'role_id', 'status', 'employee_id'] as $field) {
            if (array_key_exists($field, $submitted) && array_key_exists($field, $fields)) {
                $payload[$field] = $fields[$field];
            }
        }

        $effectiveRoleId = (int)($payload['role_id'] ?? $existing['role_id']);
        $effectiveEmployeeId = array_key_exists('employee_id', $payload) ? $payload['employee_id'] : ($existing['employee_id'] ?? null);
        $selectedRole = Database::selectOne('SELECT code FROM roles WHERE id = :role_id', ['role_id' => $effectiveRoleId]);
        $roleCode = (string)($selectedRole['code'] ?? '');
        if (!in_array($roleCode, ['ADMIN', 'HR_PAYROLL', 'MANAGER', 'STAFF', 'KIOSK'], true)) {
            Response::validationError(['role_id' => 'Unsupported role.']);
        }
        if (in_array($roleCode, ['ADMIN', 'KIOSK'], true) && $effectiveEmployeeId !== null) {
            Response::validationError(['employee_id' => 'Technical accounts cannot link to an employee.']);
        }
        if (in_array($roleCode, ['HR_PAYROLL', 'MANAGER', 'STAFF'], true) && $effectiveEmployeeId === null) {
            Response::validationError(['employee_id' => 'Employee accounts require a linked employee.']);
        }
        if ($effectiveEmployeeId !== null && in_array($roleCode, ['HR_PAYROLL', 'MANAGER', 'STAFF'], true)) {
            $this->assertAvailableEmployeeLink((int)$effectiveEmployeeId, $id);
        }
        if ($payload !== []) {
            Database::update('users', $payload, ['id' => $id]);
        }

        // Deactivating an account revokes its sessions immediately.
        if (($payload['status'] ?? '') === 'INACTIVE') {
            Auth::revokeAllTokens($id);
        }

        AuditLogger::recordChanges(
            AuditLogger::USER_CHANGED,
            'user',
            $id,
            $existing,
            array_merge($existing, $payload)
        );

        Response::success(['id' => $id], 'User updated successfully');
    }

    /** DELETE /api/users/{id} — archive a user account (purge via Data deletion). */
    public function destroy(Request $request, array $params): never
    {
        Auth::authorize('settings.manage');

        $id = (int) ($params['id'] ?? 0);
        $existing = Database::selectOne('SELECT * FROM users WHERE id = :id AND deleted_at IS NULL', ['id' => $id]);

        if ($existing === null) {
            Response::notFound('User not found.');
        }

        if ($id === Auth::id()) {
            Response::validationError(['user' => 'You cannot delete your own signed-in account.']);
        }

        if ((int) $existing['role_id'] === 1 && !Auth::isSuperAdmin()) {
            Response::forbidden('Only an administrator can delete this account.');
        }

        $now = date('Y-m-d H:i:s');
        Database::update('users', ['status' => 'INACTIVE', 'deleted_at' => $now], ['id' => $id]);
        Auth::revokeAllTokens($id);

        AuditLogger::record(
            AuditLogger::USER_CHANGED,
            'user',
            $id,
            sprintf('Deleted user "%s"', $existing['username']),
            $existing,
            null
        );

        Response::success(['id' => $id], 'User deleted successfully');
    }

    /** POST /api/users/{id}/restore — return an archived account to its list. */
    public function restore(Request $request, array $params): never
    {
        Auth::authorize('settings.manage');

        $id = (int) ($params['id'] ?? 0);
        $existing = Database::selectOne('SELECT * FROM users WHERE id = :id AND deleted_at IS NOT NULL', ['id' => $id]);

        if ($existing === null) {
            Response::notFound('User not found or is not archived.');
        }

        Database::update('users', ['status' => 'ACTIVE', 'deleted_at' => null], ['id' => $id]);

        AuditLogger::record(
            AuditLogger::USER_CHANGED,
            'user',
            $id,
            sprintf('Restored user "%s"', $existing['username']),
            ['deleted_at' => $existing['deleted_at']],
            null
        );

        Response::success(['id' => $id], 'User restored successfully');
    }

    /** POST /api/users/{id}/reset-password — issue a temporary password. */
    public function resetPassword(Request $request, array $params): never
    {
        Auth::authorize('settings.manage');

        $id       = (int) ($params['id'] ?? 0);
        $existing = Database::selectOne('SELECT * FROM users WHERE id = :id AND deleted_at IS NULL', ['id' => $id]);

        if ($existing === null) {
            Response::notFound('User not found.');
        }

        // A unique cryptographically random temporary value; must_change_password forces
        // the user to replace it before the account can be used again.
        $temporary = bin2hex(random_bytes(12));

        Database::update('users', [
            'password_hash'        => password_hash($temporary, PASSWORD_DEFAULT),
            'must_change_password' => 1,
        ], ['id' => $id]);

        Auth::revokeAllTokens($id);

        AuditLogger::record(
            AuditLogger::PASSWORD_CHANGED,
            'user',
            $id,
            sprintf('Password reset for "%s" (temporary password issued)', $existing['username'])
        );

        Response::success(['temporary_password' => $temporary], 'Password reset successfully');
    }
}
