<?php
/**
 * QR code endpoints (Phase 5): issue, regenerate, disable, render.
 */

declare(strict_types=1);

namespace App\Controllers;

use App\Core\AuditLogger;
use App\Core\Auth;
use App\Core\Database;
use App\Core\Request;
use App\Core\Response;
use App\Services\QrCodeService;
use RuntimeException;

final class QrController
{
    public function __construct(private QrCodeService $qr = new QrCodeService())
    {
    }

    /** POST /api/qr/issue/{employeeId} — issue or regenerate (Phase 5). */
    public function issue(Request $request, array $params): never
    {
        Auth::authorize('qr.generate');

        $employeeId = (int) ($params['employeeId'] ?? 0);
        $replace    = filter_var($request->body('replace', true), FILTER_VALIDATE_BOOLEAN);

        // Guard the missing-employee case here: QrCodeService::issue() signals it
        // with a RuntimeException, which would otherwise surface as a 500.
        $exists = Database::scalar(
            'SELECT id FROM employees WHERE id = :id AND deleted_at IS NULL',
            ['id' => $employeeId]
        );

        if ($exists === null) {
            Response::notFound('Employee not found.');
        }

        try {
            $qr = $this->qr->issue($employeeId, null, (bool) $replace);
        } catch (\RuntimeException $e) {
            Response::forbidden($e->getMessage());
        }

        AuditLogger::record(
            $replace ? AuditLogger::QR_REGENERATED : AuditLogger::QR_GENERATED,
            'employee_qr_code',
            $qr['qr_id'],
            sprintf(
                '%s QR code for employee %s',
                $replace ? 'Regenerated' : 'Generated',
                $employeeId
            )
        );

        Response::created([
            'qr_id'     => $qr['qr_id'],
            'token'     => $qr['token'],
            'image'     => $qr['image'],
            'serial_no' => $qr['serial_no'],
        ], $replace ? 'QR code regenerated successfully' : 'QR code generated successfully');
    }

    /** POST /api/qr/disable/{employeeId} — disable the active code (Phase 5). */
    public function disable(Request $request, array $params): never
    {
        Auth::authorize('qr.disable');

        $employeeId = (int) ($params['employeeId'] ?? 0);
        $reason     = (string) $request->body('reason', 'Revoked by administrator');

        if (!$this->qr->disable($employeeId, $reason)) {
            Response::notFound('This employee has no active QR code.');
        }

        AuditLogger::record(
            AuditLogger::QR_DISABLED,
            'employee_qr_code',
            null,
            sprintf('Employee QR code disabled: %s', $reason)
        );

        Response::success(null, 'QR code disabled successfully');
    }
    /** GET /api/qr/svg/{employeeId} — the stored QR image (Phase 5). */
    public function svg(Request $request, array $params): never
    {
        Auth::require();

        $employeeId = (int) ($params['employeeId'] ?? 0);

        Auth::requireSelfOrQrPermission($employeeId);

        try { \App\Core\DemoStaffScope::assertDemoParticipant($employeeId); }
        catch (\RuntimeException $e) { Response::forbidden($e->getMessage()); }
        $svg = $this->qr->svgContents($employeeId);

        if ($svg === null) {
            Response::notFound('This employee has no active QR image.');
        }

        if (!headers_sent()) {
            header('Content-Type: image/svg+xml; charset=utf-8');
            header('Cache-Control: no-store');
            header('X-Content-Type-Options: nosniff');
        }

        // The SVG contains the token only, never employee information.
        echo $svg;
        exit;
    }

    /** GET /api/qr/history/{employeeId} */
    public function history(Request $request, array $params): never
    {
        Auth::requireSelfOrQrPermission((int) ($params['employeeId'] ?? 0));

        Response::success(
            $this->qr->history((int) ($params['employeeId'] ?? 0)),
            'QR history retrieved successfully'
        );
    }

    /** The plaintext token of the active code, needed for rendering. */
    public function active(Request $request, array $params): never
    {
        $employeeId = (int) ($params['employeeId'] ?? 0);

        Auth::requireSelfOrQrPermission($employeeId);

        try { \App\Core\DemoStaffScope::assertDemoParticipant($employeeId); }
        catch (\RuntimeException $e) { Response::forbidden($e->getMessage()); }
        $code = $this->qr->activeCode($employeeId);

        if ($code === null) {
            Response::notFound('This employee has no active QR code.');
        }

        Response::success($code, 'QR code retrieved successfully');
    }
}
