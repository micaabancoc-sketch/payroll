<?php
declare(strict_types=1);
namespace App\Controllers;

use App\Core\Auth;
use App\Core\AuditLogger;
use App\Core\Database;
use App\Core\Request;
use App\Core\Response;
use App\Core\ValidationException;

/** Tracks only employer remittance of real PAYROLL-collected agency loan installments.
 * A remittance record is NOT a government payment; HR must confirm actual payment
 * through the official channel before recording its reference here.
 */
final class AgencyLoanRemittanceController
{
    private static function requireHr(): void
    {
        if (Auth::roleCode() !== 'HR_PAYROLL' || !Auth::hasPermission('remittance.view')) {
            Response::forbidden('Only HR/Payroll may track agency loan remittances.');
        }
    }

    public function index(Request $request, array $params): never
    {
        self::requireHr();
        $rows = Database::select(
            "SELECT lp.id AS loan_payment_id, lp.loan_id,lp.period_id,lp.amount,lp.paid_at,
                    l.loan_type,l.reference_no AS loan_reference,e.employee_number,
                    CONCAT_WS(' ',e.first_name,e.last_name) AS employee_name,
                    pp.code AS payroll_period,
                    CASE WHEN l.loan_type='SSS_SALARY_LOAN' THEN 'SSS' ELSE 'PAGIBIG' END AS agency,
                    COALESCE(alr.status,'PENDING') AS remittance_status,
                    alr.reference_no AS payment_reference, alr.remitted_on,alr.recorded_at
               FROM loan_payments lp
               JOIN loans l ON l.id=lp.loan_id
               JOIN employees e ON e.id=l.employee_id
               LEFT JOIN payroll_periods pp ON pp.id=lp.period_id
               LEFT JOIN agency_loan_remittances alr ON alr.loan_payment_id=lp.id
              WHERE l.loan_type IN ('SSS_SALARY_LOAN','PAGIBIG_MPL') AND lp.payment_type='PAYROLL'
              ORDER BY lp.paid_at DESC, lp.id DESC LIMIT 500"
        );
        Response::success($rows, 'Agency loan payroll deductions and remittance status');
    }

    public function markRemitted(Request $request, array $params): never
    {
        self::requireHr();
        if (!Auth::hasPermission('remittance.manage')) {
            Response::forbidden('You cannot update remittance records.');
        }
        $paymentId = (int)($params['id'] ?? 0);
        $reference = trim((string)$request->body('reference_no',''));
        $date = trim((string)$request->body('remitted_on',''));
        $dt = \DateTimeImmutable::createFromFormat('!Y-m-d', $date);
        if ($paymentId<=0 || strlen($reference)<3 || strlen($reference)>150 || !$dt || $dt->format('Y-m-d')!==$date || $date > date('Y-m-d')) {
            Response::validationError(['remittance'=>'Enter a valid actual payment reference (3-150 characters) and non-future remittance date.']);
        }
        try {
            $row=Database::transaction(static function () use ($paymentId,$reference,$date): array {
                $payment=Database::selectOne(
                    "SELECT lp.id,lp.loan_id,l.loan_type,lp.amount FROM loan_payments lp
                     JOIN loans l ON l.id=lp.loan_id
                     WHERE lp.id=:id AND lp.payment_type='PAYROLL' AND l.loan_type IN ('SSS_SALARY_LOAN','PAGIBIG_MPL') FOR UPDATE",
                    ['id'=>$paymentId]
                );
                if (!$payment) { throw new ValidationException(['payment'=>'Agency payroll deduction not found.']); }
                $prior=Database::selectOne('SELECT id FROM agency_loan_remittances WHERE loan_payment_id=:id',['id'=>$paymentId]);
                if ($prior) { throw new ValidationException(['remittance'=>'This loan installment already has a recorded agency remittance.']); }
                $agency=$payment['loan_type']==='SSS_SALARY_LOAN'?'SSS':'PAGIBIG';
                $id=Database::insert('agency_loan_remittances', [
                    'loan_payment_id'=>$paymentId,'agency'=>$agency,'status'=>'REMITTED',
                    'reference_no'=>$reference,'remitted_on'=>$date,
                    'recorded_by'=>Auth::id(),'recorded_at'=>date('Y-m-d H:i:s'),
                ]);
                AuditLogger::record('AGENCY_LOAN_REMITTED','loan_payment',$paymentId,
                    'HR recorded agency loan remittance '.$agency.' reference '.$reference);
                return ['id'=>$id,'loan_payment_id'=>$paymentId,'agency'=>$agency,'status'=>'REMITTED'];
            });
        } catch (ValidationException $e) { Response::validationError($e->errors()); }
        Response::success($row,'Recorded as remitted. Reconcile with the official agency account statement.');
    }
}
