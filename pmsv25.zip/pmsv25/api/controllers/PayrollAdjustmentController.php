<?php
declare(strict_types=1);
namespace App\Controllers;

use App\Core\AuditLogger;
use App\Core\Auth;
use App\Core\Database;
use App\Core\Request;
use App\Core\Response;
use App\Core\ValidationException;

/** Documented adjustment: HR prepares, Manager approves, payroll consumes on recalculation. */
final class PayrollAdjustmentController
{
    public function index(Request $request, array $params): never
    {
        Auth::authorize('payroll.period.view');
        Response::success(Database::select(
            "SELECT a.*, CONCAT_WS(' ',e.first_name,e.middle_name,e.last_name) AS employee_name,
                    pp.code AS period_code FROM payroll_adjustments a
             JOIN employees e ON e.id=a.employee_id JOIN payroll_periods pp ON pp.id=a.payroll_period_id
             ORDER BY a.created_at DESC, a.id DESC LIMIT 500"
        ));
    }

    public function create(Request $request, array $params): never
    {
        Auth::authorize('payroll.calculate');
        if (Auth::roleCode() !== 'HR_PAYROLL') { Response::forbidden('Only HR/Payroll Staff may propose an adjustment.'); }
        $body = $request->body();
        $employeeId = filter_var($body['employee_id'] ?? null, FILTER_VALIDATE_INT);
        $periodId = filter_var($body['payroll_period_id'] ?? null, FILTER_VALIDATE_INT);
        $amount = filter_var($body['amount'] ?? null, FILTER_VALIDATE_FLOAT);
        $kind = strtoupper(trim((string) ($body['kind'] ?? '')));
        $reason = trim((string) ($body['reason'] ?? ''));
        if (!$employeeId || !$periodId || $amount === false || $amount <= 0 || $amount > 1000000
            || !in_array($kind, ['EARNING','DEDUCTION'], true) || mb_strlen($reason) < 10) {
            Response::validationError(['adjustment' => 'Choose an employee, DRAFT period, earning/deduction, positive amount and reason of at least 10 characters.']);
        }
        $period = Database::selectOne('SELECT * FROM payroll_periods WHERE id=:id AND deleted_at IS NULL', ['id' => $periodId]);
        if (!$period || !in_array($period['status'], ['DRAFT','FOR_REVIEW'], true)) {
            Response::validationError(['payroll_period_id' => 'Only an unapproved, unpaid payroll period can receive an adjustment. Use a future period to correct paid payroll.']);
        }
        if (!Database::scalar("SELECT id FROM employees WHERE id=:id AND deleted_at IS NULL", ['id' => $employeeId])) {
            Response::validationError(['employee_id' => 'Employee not found.']);
        }
        $amount = round((float) $amount, 2);
        // Deterministic unique request key also stops accidental double-submission.
        $key = hash('sha256', implode('|', [$employeeId,$periodId,$kind,number_format($amount,2,'.',''),mb_strtolower($reason)]));
        $existing = Database::selectOne('SELECT * FROM payroll_adjustments WHERE request_key=:k', ['k'=>$key]);
        if ($existing) { Response::success($existing, 'Identical adjustment request already exists; duplicate not created.'); }
        $id = Database::insert('payroll_adjustments', [
            'employee_id' => $employeeId, 'payroll_period_id' => $periodId,
            'kind' => $kind, 'amount' => $amount, 'reason' => $reason, 'status' => 'PENDING',
            'request_key' => $key, 'created_by' => Auth::id(),
        ]);
        AuditLogger::record(AuditLogger::PAYROLL_CALCULATED, 'payroll_adjustment', $id, 'Adjustment proposed: ' . $reason);
        Response::created(Database::selectOne('SELECT * FROM payroll_adjustments WHERE id=:id',['id'=>$id]));
    }

    public function decision(Request $request, array $params): never
    {
        Auth::authorize('payroll.approve');
        if (Auth::roleCode() !== 'HR_PAYROLL') { Response::forbidden('Only an authorized HR/Payroll reviewer may approve payroll adjustments.'); }
        $id = (int)($params['id'] ?? 0);
        $decision = strtoupper((string) ($request->body('decision') ?? ''));
        if (!in_array($decision,['APPROVED','REJECTED'],true)) {
            Response::validationError(['decision'=>'Choose APPROVED or REJECTED.']);
        }
        $result = Database::transaction(static function () use ($id,$decision): array {
            $row = Database::selectOne(
                'SELECT a.*, pp.status AS period_status FROM payroll_adjustments a JOIN payroll_periods pp ON pp.id=a.payroll_period_id WHERE a.id=:id FOR UPDATE', ['id'=>$id]
            );
            if (!$row || $row['status'] !== 'PENDING') {
                throw new ValidationException(['adjustment'=>'Adjustment is missing or already decided.']);
            }
            if (!in_array($row['period_status'],['DRAFT','FOR_REVIEW'],true)) {
                throw new ValidationException(['payroll_period_id'=>'Adjustment cannot be approved for locked payroll. Target a future draft period.']);
            }
            if ((int)$row['created_by'] === Auth::id() || (Auth::employeeId() !== null && (int)$row['employee_id'] === Auth::employeeId())) {
                throw new ValidationException(['permission'=>'An independent reviewer is required. You cannot approve your own proposal or personal payroll adjustment.']);
            }
            Database::update('payroll_adjustments', ['status'=>$decision,'approved_by'=>Auth::id(),'approved_at'=>date('Y-m-d H:i:s')],['id'=>$id]);
            AuditLogger::record(AuditLogger::PAYROLL_CALCULATED,'payroll_adjustment',$id, 'HR review: ' . $decision);
            return Database::selectOne('SELECT * FROM payroll_adjustments WHERE id=:id',['id'=>$id]) ?? [];
        });
        Response::success($result, 'HR decision recorded; HR must recalculate the payroll period to apply the approved adjustment.');
    }
}
