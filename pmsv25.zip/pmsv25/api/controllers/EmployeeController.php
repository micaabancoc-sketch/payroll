<?php
/**
 * Employee endpoints (Phase 4).
 */

declare(strict_types=1);

namespace App\Controllers;

use App\Core\Auth;
use App\Core\Request;
use App\Core\Response;
use App\Services\EmployeeService;

final class EmployeeController
{
    public function __construct(private EmployeeService $employees = new EmployeeService())
    {
    }

    /** GET /api/employees */
    public function index(Request $request, array $params): never
    {
        $pagination = $request->pagination();

        $filters = $request->query();
        if (Auth::roleCode() === 'MANAGER') {
            $department = Auth::managerDepartmentId();
            if ($department === null) { Response::forbidden('Manager is not assigned to a department.'); }
            $filters['manager_employee_id'] = Auth::employeeId();
            $filters['manager_department_id'] = $department;
        }
        $result = $this->employees->search(
            $filters,
            $pagination['page'],
            $pagination['per_page']
        );

        if (Auth::roleCode() === 'MANAGER') {
            foreach ($result['items'] as &$row) {
                foreach (['basic_salary', 'salary_type', 'sss_number', 'philhealth_number', 'pagibig_number', 'tin'] as $field) { unset($row[$field]); }
            }
            unset($row);
        }
        Response::paginated(
            $result['items'],
            $result['total'],
            $pagination['page'],
            $pagination['per_page']
        );
    }

    /** GET /api/employees/{id} */
    public function show(Request $request, array $params): never
    {
        $id = (int) ($params['id'] ?? 0);

        // An employee may only view their own record (rules 13/14).
        Auth::requireSelfOrPermission($id, 'employees.view');

        $employee = $this->employees->find($id);

        if ($employee === null) {
            Response::notFound('Employee not found.');
        }

        if (Auth::roleCode() === 'MANAGER') {
            $employee = $this->employees->find($id);
            if ($employee !== null) { foreach (['basic_salary','salary_type','sss_number','philhealth_number','pagibig_number','tin'] as $field) { unset($employee[$field]); } }
            Response::success($employee, 'Team employee retrieved');
        }
        Response::success($employee, 'Employee retrieved successfully');
    }

    /** GET /api/employees/{id}/profile */
    public function profile(Request $request, array $params): never
    {
        $id = (int) ($params['id'] ?? 0);

        Auth::requireSelfOrPermission($id, 'employees.view');

        if (Auth::roleCode() === 'MANAGER') {
            $employee = $this->employees->find($id);
            if ($employee !== null) { foreach (['basic_salary','salary_type','sss_number','philhealth_number','pagibig_number','tin'] as $field) { unset($employee[$field]); } }
            Response::success($employee, 'Team employee retrieved');
        }
        $details = $this->employees->profile($id);
        if (Auth::roleCode() === 'MANAGER' && is_array($details)) {
            foreach (['basic_salary','salary_type','sss_number','philhealth_number','pagibig_number','tin'] as $field) { unset($details[$field]); }
        }
        Response::success($details, 'Employee profile retrieved successfully');
    }

    /** POST /api/employees */
    public function store(Request $request, array $params): never
    {
        Auth::authorize('employees.create');

        Response::created($this->employees->create($request->body()), 'Employee created successfully');
    }

    /** PUT /api/employees/{id} */
    public function update(Request $request, array $params): never
    {
        Auth::authorize('employees.update');

        Response::success(
            $this->employees->update((int) ($params['id'] ?? 0), $request->body()),
            'Employee updated successfully'
        );
    }
/** POST /api/employees/{id}/archive */
    public function archive(Request $request, array $params): never
    {
        Auth::authorize('employees.archive');

        Response::success(
            $this->employees->archive((int) ($params['id'] ?? 0)),
            'Employee archived successfully'
        );
    }

    /** POST /api/employees/{id}/reset-password */
    public function resetPassword(Request $request, array $params): never
    {
        Auth::authorize('settings.manage');

        Response::success(
            $this->employees->resetAccountPassword((int) ($params['id'] ?? 0)),
            'Temporary password issued successfully'
        );
    }

    /** POST /api/employees/{id}/restore */
    public function restore(Request $request, array $params): never
    {
        Auth::authorize('employees.restore');

        Response::success(
            $this->employees->restore((int) ($params['id'] ?? 0)),
            'Employee restored successfully'
        );
    }

    /** DELETE /api/employees/{id} */
    public function destroy(Request $request, array $params): never
    {
        Auth::authorize('employees.delete');

        Response::success(
            $this->employees->delete((int) ($params['id'] ?? 0)),
            'Employee deleted successfully'
        );
    }

    /** GET /api/employees/{id}/salary-history */
    public function salaryHistory(Request $request, array $params): never
    {
        $id = (int) ($params['id'] ?? 0);

        if (Auth::roleCode() === 'MANAGER') { Response::forbidden('Managers do not access salary history.'); }
        Auth::requireSelfOrPermission($id, 'employees.view');

        Response::success($this->employees->salaryHistory($id), 'Salary history retrieved successfully');
    }

    /** GET /api/employees/{id}/leave-balances */
    public function leaveBalances(Request $request, array $params): never
    {
        $id = (int) ($params['id'] ?? 0);

        Auth::requireSelfOrPermission($id, 'employees.view');

        Response::success($this->employees->leaveBalances($id), 'Leave balances retrieved successfully');
    }

    /** GET /api/employees/{id}/qr — the active QR code (Phase 5). */
    public function qr(Request $request, array $params): never
    {
        $id = (int) ($params['id'] ?? 0);

        Auth::requireSelfOrQrPermission($id);

        try { \App\Core\DemoStaffScope::assertDemoParticipant($id); }
        catch (\RuntimeException $e) { Response::forbidden($e->getMessage()); }
        $code = $this->employees->qrService()->activeCode($id);

        if ($code === null) {
            Response::notFound('This employee has no active QR code.');
        }

        Response::success($code, 'QR code retrieved successfully');
    }

    /** GET /api/employees/{id}/qr/history */
    public function qrHistory(Request $request, array $params): never
    {
        $id = (int) ($params['id'] ?? 0);

        Auth::requireSelfOrQrPermission($id);

        Response::success(
            $this->employees->qrService()->history($id),
            'QR history retrieved successfully'
        );
    }

    /** GET /api/meta/employees/options — lightweight list for dropdowns. */
    public function options(Request $request, array $params): never
    {
        $filters = ['archived' => 'false', 'sort' => 'name', 'status' => 'ACTIVE', 'payroll_eligible' => '1'];
        if (\App\Core\DemoStaffScope::enabled()) { $filters['demo_staff_only'] = true; }
        if (Auth::roleCode() === 'MANAGER') {
            $department = Auth::managerDepartmentId();
            if ($department === null) { Response::forbidden('Manager has no assigned department.'); }
            $filters['manager_employee_id'] = Auth::employeeId();
            $filters['manager_department_id'] = $department;
        }
        $result = $this->employees->search($filters, 1, 500);

        Response::success(
            array_map(static fn (array $e): array => [
                'id'              => (int) $e['id'],
                'employee_number' => $e['employee_number'],
                'full_name'       => $e['full_name'],
                'department'      => $e['department_name'] ?? null,
                'position'        => $e['position_name'] ?? null,
            ], $result['items']),
            'Employee options retrieved successfully'
        );
    }
}