<?php
declare(strict_types=1);
namespace App\Controllers;
use App\Core\Auth;
use App\Core\Database;
use App\Core\Response;
use App\Core\Request;
use App\Core\AuditLogger;
use App\Core\ValidationException;

/** Designated independent Manager adjustment reviewer: limited amounts/reasons, NO base salary access. */
final class HrReviewerController
{
    private static function requireReviewer(): void
    {
        if (Auth::roleCode() !== 'MANAGER' || Auth::id() === null ||
            (int)(Database::scalar("SELECT setting_value FROM system_settings WHERE setting_key = 'hr.designated_reviewer_user_id'") ?? 0) !== Auth::id()) {
            Response::forbidden('This Manager is not the designated HR personal reviewer.');
        }
    }

    public function setup(Request $request, array $params): never
    {
        Auth::authorize('settings.manage');
        $managerAccounts = Database::select("SELECT u.id, u.username, u.full_name FROM users u JOIN roles r ON r.id=u.role_id WHERE r.code='MANAGER' AND u.status='ACTIVE' AND u.deleted_at IS NULL AND u.employee_id IS NOT NULL ORDER BY u.username");
        Response::success(['managers'=>$managerAccounts, 'reviewer_id'=>(int)(Database::scalar("SELECT setting_value FROM system_settings WHERE setting_key = 'hr.designated_reviewer_user_id'") ?? 0)]);
    }

    public function assign(Request $request, array $params): never
    {
        Auth::authorize('settings.manage');
        $id = filter_var($request->body('manager_user_id'), FILTER_VALIDATE_INT);
        if (!$id || !Database::scalar("SELECT u.id FROM users u JOIN roles r ON r.id=u.role_id WHERE u.id=:id AND r.code='MANAGER' AND u.employee_id IS NOT NULL AND u.status='ACTIVE' AND u.deleted_at IS NULL", ['id'=>$id])) {
            Response::validationError(['manager_user_id'=>'Select an active employee-linked Manager account.']);
        }
        Database::execute("UPDATE system_settings SET setting_value=:val,updated_by=:uid WHERE setting_key='hr.designated_reviewer_user_id'", ['val'=>(string)$id, 'uid'=>Auth::id()]);
        AuditLogger::record('HR_REVIEWER_ASSIGNED', 'user', (int)$id, 'IT Admin assigned the limited HR personal payroll reviewer.');
        Response::success(['reviewer_id'=>(int)$id], 'HR personal reviewer assigned. Manager must log in again to see the reviewer page.');
    }

    /** Documented pending adjustments only. No payroll totals or salary data. */
    public function adjustments(Request $request, array $params): never
    {
        self::requireReviewer();
        Response::success(Database::select("SELECT a.id,a.employee_id,a.payroll_period_id,a.kind,a.amount,a.reason,a.status,a.created_at,a.created_by, pp.code AS period_code, CONCAT_WS(' ',e.first_name,e.last_name) AS employee_name FROM payroll_adjustments a JOIN employees e ON e.id=a.employee_id JOIN payroll_periods pp ON pp.id=a.payroll_period_id ORDER BY a.created_at DESC, a.id DESC LIMIT 200"));
    }

    public function decision(Request $request, array $params): never
    {
        self::requireReviewer();
        $id=(int)($params['id'] ?? 0);
        $decision=strtoupper(trim((string)$request->body('decision','')));
        if (!in_array($decision,['APPROVED','REJECTED'],true)) { Response::validationError(['decision'=>'Choose APPROVED or REJECTED.']); }
        try {
            $result=Database::transaction(static function () use ($id,$decision): array {
                $row=Database::selectOne("SELECT a.*,pp.status AS period_status FROM payroll_adjustments a JOIN payroll_periods pp ON pp.id=a.payroll_period_id WHERE a.id=:id FOR UPDATE", ['id'=>$id]);
                if (!$row || $row['status']!=='PENDING' || !in_array($row['period_status'],['DRAFT','FOR_REVIEW'],true)) { throw new ValidationException(['adjustment'=>'Only pending adjustments to an unlocked payroll can be reviewed.']); }
                if ((int)$row['created_by']===Auth::id() || (Auth::employeeId() !== null && (int)$row['employee_id']===Auth::employeeId())) { throw new ValidationException(['permission'=>'You cannot approve a personal or self-created adjustment.']); }
                Database::execute('UPDATE payroll_adjustments SET status=:st,approved_by=:uid,approved_at=NOW() WHERE id=:id AND status=\'PENDING\'', ['st'=>$decision,'uid'=>Auth::id(),'id'=>$id]);
                AuditLogger::record('INDEPENDENT_ADJUSTMENT_REVIEWED', 'payroll_adjustment', $id, 'Designated independent Manager reviewed documented adjustment: '.$decision);
                return ['id'=>$id,'status'=>$decision];
            });
        } catch (ValidationException $error) { Response::validationError($error->errors()); }
        Response::success($result,'Independent HR adjustment decision recorded.');
    }
}
