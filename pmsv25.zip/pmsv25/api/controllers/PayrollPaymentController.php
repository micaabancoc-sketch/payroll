<?php
/**
 * Individual payroll payment endpoints (Phase 5).
 *
 * Route-level permissions (api/routes.php) gate every action; the controller
 * only turns service results and service exceptions into HTTP responses.
 */

declare(strict_types=1);

namespace App\Controllers;

use App\Core\Auth;
use App\Core\Request;
use App\Core\Response;
use App\Services\PayrollPaymentService;
use RuntimeException;

final class PayrollPaymentController
{
    public function __construct(private PayrollPaymentService $payments = new PayrollPaymentService())
    {
    }

    /** GET /api/payroll/payments/options — methods + statuses for the page. */
    public function options(Request $request, array $params): never
    {
        Auth::require($request);

        Response::success($this->payments->options(), 'Payment options retrieved successfully');
    }

    /** GET /api/payroll/periods/{id}/payments — every row + its ledger. */
    public function forPeriod(Request $request, array $params): never
    {
        Auth::authorizeAny(['payroll.view', 'payroll.period.view', 'payroll.payments.view']);

        try {
            $result = $this->payments->forPeriod((int) ($params['id'] ?? 0));
        } catch (RuntimeException $e) {
            Response::notFound($e->getMessage());
        }

        Response::success($result, 'Period payments retrieved successfully');
    }

    /** GET /api/payroll/records/{id}/payments — one row + its ledger. */
    public function forPayroll(Request $request, array $params): never
    {
        Auth::authorizeAny(['payroll.view', 'payroll.period.view', 'payroll.payments.view']);

        try {
            $result = $this->payments->forPayroll((int) ($params['id'] ?? 0));
        } catch (RuntimeException $e) {
            Response::notFound($e->getMessage());
        }

        Response::success($result, 'Payroll payments retrieved successfully');
    }

    /** POST /api/payroll/records/{id}/payments — record COMPLETED/PENDING. */
    public function store(Request $request, array $params): never
    {
        if (!\App\Core\DemoStaffScope::payrollWorkflowEnabled()) {
            Response::error('Demo payroll payment workflow is disabled outside the configured local development test.', 403);
        }
        Auth::authorizeAny(['payroll.payments.record', 'payroll.mark_paid']);

        try {
            $result = $this->payments->record((int) ($params['id'] ?? 0), $request->body(), Auth::id());
        } catch (RuntimeException $e) {
            Response::error($e->getMessage(), 422, $e instanceof \App\Core\ValidationException ? $e->errors() : []);
        }

        Response::created(
            $result,
            !empty($result['replayed']) ? 'Payment already recorded (idempotent replay).' : 'Payment recorded successfully'
        );
    }

    /** POST /api/payroll/payments/{id}/complete — confirm a PENDING intent. */
    public function complete(Request $request, array $params): never
    {
        if (!\App\Core\DemoStaffScope::payrollWorkflowEnabled()) {
            Response::error('Demo payroll payment workflow is disabled outside the configured local development test.', 403);
        }
        Auth::authorizeAny(['payroll.payments.record', 'payroll.mark_paid']);

        try {
            $result = $this->payments->complete((int) ($params['id'] ?? 0), $request->body(), Auth::id());
        } catch (RuntimeException $e) {
            Response::error($e->getMessage(), 422, $e instanceof \App\Core\ValidationException ? $e->errors() : []);
        }

        Response::success($result, 'Pending payment completed successfully');
    }

    /** POST /api/payroll/payments/{id}/fail — log a failed attempt. */
    public function fail(Request $request, array $params): never
    {
        Auth::authorizeAny(['payroll.payments.record', 'payroll.mark_paid']);

        try {
            $result = $this->payments->markFailed((int) ($params['id'] ?? 0), $request->body(), Auth::id());
        } catch (RuntimeException $e) {
            Response::error($e->getMessage(), 422, $e instanceof \App\Core\ValidationException ? $e->errors() : []);
        }

        Response::success($result, 'Payment marked as failed');
    }

    /** POST /api/payroll/payments/{id}/cancel — reverse with a reason. */
    public function cancel(Request $request, array $params): never
    {
        Auth::authorizeAny(['payroll.payments.cancel', 'payroll.mark_paid']);

        try {
            $result = $this->payments->cancel((int) ($params['id'] ?? 0), $request->body(), Auth::id());
        } catch (RuntimeException $e) {
            Response::error($e->getMessage(), 422, $e instanceof \App\Core\ValidationException ? $e->errors() : []);
        }

        Response::success($result, 'Payment cancelled successfully');
    }
}
