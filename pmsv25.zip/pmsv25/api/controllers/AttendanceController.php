<?php
/**
 * Attendance endpoints (Phase 6 / Phase 7).
 *
 *   POST /api/attendance/scan     — the QR scanner (kiosk token, no session)
 *   GET  /api/attendance          — records with filters
 *   GET  /api/attendance/today    — dashboard overview
 *   POST /api/attendance          — manual entry
 *   PUT  /api/attendance/{id}     — adjustment
 *   DELETE /api/attendance/{id}   — removal
 */

declare(strict_types=1);

namespace App\Controllers;

use App\Core\AuditLogger;
use App\Core\Auth;
use App\Core\Database;
use App\Core\Request;
use App\Core\Response;
use App\Middleware\RateLimiter;
use App\Services\AttendanceService;
use DateTimeImmutable;

final class AttendanceController
{
    public function __construct(private AttendanceService $attendance = new AttendanceService())
    {
    }

    /**
     * POST /api/attendance/scan
     *
     * The dedicated KIOSK account must be authenticated. The employee
     * QR token identifies the worker, never the operator or device.
     */
    public function scan(Request $request, array $params): never
    {
        Auth::authorize('attendance.scan', $request);

        // Stricter limit: scanners can be spammed (Phase 20).
        RateLimiter::hit('scan:' . $request->ip(), 60, 60, 300);

        $token = (string) $request->body('token', $request->query('token', ''));
        $employeeId = $request->body('employee_id', $request->query('employee_id'));

        // Two ways in, deliberately different in trust:
        //   token      -- the badge IS the credential, so the request stays
        //                 anonymous; whoever holds the code can scan.
        //   employee_id -- an operator naming the person instead of presenting
        //                 a badge, so it requires a signed-in user holding
        //                 attendance.override and is audited as an override.
        $isOverride = $employeeId !== null && $employeeId !== '';

        if (!$isOverride && trim($token) === '') {
            Response::validationError([
                'token' => 'A QR token is required, or an employee ID if you are an authorised operator.',
            ]);
        }

        if ($isOverride) {
            Response::forbidden('Employee-ID overrides are not available on the QR kiosk. Use the issued QR code.');
            Auth::require($request);
            Auth::authorize('attendance.override');

            $employeeId = (int) $employeeId;

            if ($employeeId <= 0) {
                Response::validationError(['employee_id' => 'That is not a valid employee ID.']);
            }

            try {
                $result = $this->attendance->scanForEmployee($employeeId, $request);
            } catch (\RuntimeException $e) {
                Response::error($e->getMessage(), 422);
            }
        } else {
            try {
                $result = $this->attendance->scan($token, $request, $this->testClock($request));
            } catch (\RuntimeException $e) {
                // Rejections are expected business outcomes, not server errors.
                Response::error($e->getMessage(), 422);
            }
        }

        $attendance = $result['attendance'];

        AuditLogger::record(
            $isOverride ? AuditLogger::ATTENDANCE_OVERRIDE : AuditLogger::ATTENDANCE_SCAN,
            'attendance',
            (int) $attendance['id'],
            $isOverride
                ? sprintf(
                    'Manual override by %s: %s for %s (%s)',
                    Auth::user()['username'] ?? 'operator',
                    $result['event_type'],
                    $result['employee']['employee_number'],
                    $attendance['status']
                )
                : sprintf(
                    'QR scan: %s for %s (%s)',
                    $result['event_type'],
                    $result['employee']['employee_number'],
                    $attendance['status']
                ),
            null,
            null,
            $request
        );

        Response::success(
            $result,
            $isOverride
                ? 'Attendance recorded by manual override'
                : 'Attendance recorded successfully'
        );
    }

    /**
     * Test-only scan clock.
     *
     * The end-to-end suite (tests/api_test.sh) asserts the whole time-in /
     * time-out flow, which with a wall clock only ever holds inside the
     * seeded shift's cut-off window. A caller may pin the moment a token
     * scan is evaluated by sending `scanned_at` (Y-m-d H:i:s) — but only
     * when this API process was started with PMS_TEST_CLOCK=1 and the app
     * is not in production. Without that flag the field does not exist:
     * it is ignored, so every real deployment keeps evaluating scans at
     * the wall clock.
     *
     * The pinned time only flows into AttendanceService::scan()'s existing
     * $at parameter, so every rule (late cut-off, duplicate rejection,
     * overnight attendance dates, recalculation) still runs unchanged
     * against it.
     */
    private function testClock(Request $request): ?DateTimeImmutable
    {
        $env     = getenv('APP_ENV') ?: 'development';
        $enabled = filter_var(getenv('PMS_TEST_CLOCK') ?: 'false', FILTER_VALIDATE_BOOLEAN)
            && !in_array($env, ['production', 'prod'], true);

        if (!$enabled) {
            return null;
        }

        $raw = $request->body('scanned_at');

        if ($raw === null || $raw === '') {
            return null;
        }

        $parsed = is_string($raw)
            ? DateTimeImmutable::createFromFormat('Y-m-d H:i:s', $raw)
            : false;

        if ($parsed === false || $parsed->format('Y-m-d H:i:s') !== $raw) {
            Response::validationError([
                'scanned_at' => 'scanned_at must be a valid timestamp in Y-m-d H:i:s format.',
            ]);
        }

        return $parsed;
    }

    /**
     * POST /api/attendance/scan/preview — who does this badge belong to, and
     * what would recording it do? Writes nothing, so the operator can confirm
     * an uploaded image before it counts.
     */
    public function scanPreview(Request $request, array $params): never
    {
        Auth::authorize('attendance.scan', $request);
        RateLimiter::hit('scan:' . $request->ip(), 60, 60, 300);

        $token = (string) $request->body('token', $request->query('token', ''));

        if (trim($token) === '') {
            Response::validationError(['token' => 'The QR token is required.']);
        }

        try {
            $result = $this->attendance->preview($token, $request);
        } catch (\RuntimeException $e) {
            // Same rejections as a real scan -- a preview never promises an
            // outcome the scan itself would refuse.
            Response::error($e->getMessage(), 422);
        }

        Response::success($result, 'QR code recognised');
    }
/** GET /api/attendance */
    public function index(Request $request, array $params): never
    {
        Auth::require($request);

        $filters = $request->query();
        $mine = filter_var($filters['mine'] ?? false, FILTER_VALIDATE_BOOLEAN);
        if ($mine && \App\Core\DemoStaffScope::enabled() && Auth::roleCode() !== 'STAFF') {
            Response::forbidden('HR and Manager are system operators only; personal attendance is disabled for this demo.');
        }
        if ($mine && Auth::employeeId() === null) { Response::forbidden('Personal portal needs a linked employee profile.'); }
        if (Auth::roleCode() === 'MANAGER' && !$mine) {
            $department = Auth::managerDepartmentId();
            if ($department === null) { Response::forbidden('Manager is not linked to a department.'); }
            $filters['manager_employee_id'] = Auth::employeeId();
            $filters['manager_department_id'] = $department;
            unset($filters['employee_id']);
        }
        // An employee sees only their own records (rule 13).
        if (!Auth::hasAnyPermission(['attendance.view'])) {
            $employeeId = Auth::employeeId();

            if ($employeeId === null) {
                Response::forbidden('Your account is not linked to an employee record.');
            }

            $filters['employee_id'] = $employeeId;
        }

        if (!$mine && \App\Core\DemoStaffScope::enabled()) {
            $filters['demo_staff_only'] = true;
        }

        if ($mine) {
            $filters['employee_id'] = Auth::employeeId();
            unset($filters['department_id'], $filters['manager_employee_id'], $filters['manager_department_id']);
        }
        $pagination = $request->pagination();
        $result = $this->attendance->list($filters, $pagination['page'], $pagination['per_page']);

        Response::paginated($result['items'], $result['total'], $pagination['page'], $pagination['per_page']);
    }

    /** Date-only payroll cutoff options, safe for employee self-service. */
    public function periodOptions(Request $request, array $params): never
    {
        Auth::require($request);
        if (!in_array(Auth::roleCode(), ['HR_PAYROLL','MANAGER','STAFF'], true)) {
            Response::forbidden('Attendance cutoff filters are employee-only.');
        }
        $rows = Database::select(
            'SELECT id, start_date, end_date FROM payroll_periods WHERE deleted_at IS NULL ORDER BY start_date DESC LIMIT 100'
        );
        Response::success($rows);
    }

    /** GET /api/attendance/today */
    public function today(Request $request, array $params): never
    {
        Auth::require($request);

        $date = (string) $request->query('date', date('Y-m-d'));
        $employeeId = \App\Core\DemoStaffScope::enabled() && Auth::hasPermission('attendance.view')
            ? null
            : (Auth::roleCode() === 'MANAGER' ? Auth::employeeId() : (Auth::hasPermission('attendance.view') ? null : Auth::employeeId()));
        if ($employeeId === null && !Auth::hasPermission('attendance.view')) {
            Response::forbidden('Your account is not linked to an employee record.');
        }

        Response::success(
            $this->attendance->todayOverview($date, $employeeId),
            "Attendance overview for {$date} retrieved successfully"
        );
    }

    /** POST /api/attendance — manual entry (Phase 7). */
    public function store(Request $request, array $params): never
    {
        Auth::authorize('attendance.create');

        $employeeId = (int) $request->body('employee_id', 0);

        if ($employeeId <= 0) {
            Response::validationError(['employee_id' => 'The employee is required.']);
        }
        if (\App\Core\DemoStaffScope::enabled()) {
            try { \App\Core\DemoStaffScope::assertIncluded($employeeId); }
            catch (\RuntimeException $e) { Response::error($e->getMessage(), 422); }
        }

        try {
            $attendance = $this->attendance->record($employeeId, $request->body());
        } catch (\RuntimeException $e) {
            Response::error($e->getMessage(), 422);
        }

        Response::created($attendance, 'Attendance recorded successfully');
    }

    /**
     * Your own attendance history may be archived or restored with just
     * attendance.view_own; anyone else's needs attendance.delete.
     */
    private static function isOwnRecord(int $employeeId): bool
    {
        $own = Auth::employeeId();

        return $own !== null && $own === $employeeId;
    }

    /** PUT /api/attendance/{id} — adjust an existing record (Phase 7 / 18). */
    public function update(Request $request, array $params): never
    {
        Auth::authorize('attendance.update');

        $id       = (int) ($params['id'] ?? 0);
        $existing = $this->attendance->findById($id);

        if ($existing === null) {
            Response::notFound('Attendance record not found.');
        }

        try {
            $attendance = $this->attendance->correctRecord($id, $request->body());
        } catch (\RuntimeException $e) {
            Response::error($e->getMessage(), 422);
        }

        Response::success($attendance, 'Attendance adjusted successfully');
    }

    /** POST /api/attendance/{id}/restore — return an archived record to its list */
    public function restore(Request $request, array $params): never
    {
        Auth::require($request);

        $id = (int) ($params['id'] ?? 0);
        $archived = Database::selectOne(
            'SELECT employee_id FROM attendance WHERE id = :id AND deleted_at IS NOT NULL',
            ['id' => $id]
        );

        if ($archived === null) {
            Response::notFound('Attendance record not found or is not archived.');
        }
        try { \App\Core\DemoStaffScope::assertDemoParticipant((int) $archived['employee_id']); }
        catch (\RuntimeException $e) { Response::forbidden($e->getMessage()); }

        // Staff and managers may restore their own history; anyone else's
        // record still needs attendance.delete.
        if (!self::isOwnRecord((int) $archived['employee_id'])) {
            Auth::authorize('attendance.delete');
        }

        try {
            $result = $this->attendance->restore($id);
        } catch (\RuntimeException $e) {
            Response::error($e->getMessage(), 422);
        }

        Response::success($result, 'Attendance record restored successfully');
    }

    /** DELETE /api/attendance/{id} */
    public function destroy(Request $request, array $params): never
    {
        Auth::require($request);

        $id = (int) ($params['id'] ?? 0);
        $existing = $this->attendance->findById($id);

        if ($existing === null) {
            Response::notFound('Attendance record not found.');
        }
        try { \App\Core\DemoStaffScope::assertDemoParticipant((int) $existing['employee_id']); }
        catch (\RuntimeException $e) { Response::forbidden($e->getMessage()); }

        // Staff and managers may archive their own history; anyone else's
        // record still needs attendance.delete.
        if (!self::isOwnRecord((int) $existing['employee_id'])) {
            Auth::authorize('attendance.delete');
        }

        try {
            $result = $this->attendance->delete($id);
        } catch (\RuntimeException $e) {
            Response::notFound($e->getMessage());
        }

        Response::success($result, 'Attendance record moved to archive. Purge it in Data deletion.');
    }
}
