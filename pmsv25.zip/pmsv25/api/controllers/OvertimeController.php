<?php
/**
 * Overtime assignment endpoints (Manager assignments, HR authorization, QR verification).
 */

declare(strict_types=1);

namespace App\Controllers;

use App\Core\Auth;
use App\Core\Request;
use App\Core\Response;
use App\Services\OvertimeService;

final class OvertimeController
{
    public function __construct(private OvertimeService $overtime = new OvertimeService())
    {
    }

    /** GET /api/overtime */
    public function index(Request $request, array $params): never
    {
        Auth::require($request);

        $filters = $request->query();
        $mine = filter_var($filters['mine'] ?? false, FILTER_VALIDATE_BOOLEAN);
        if ($mine && \App\Core\DemoStaffScope::isSystemOperator()) {
            Response::forbidden('System operators do not have personal overtime in this demo.');
        }
        if ($mine && Auth::employeeId() === null) { Response::forbidden('Personal portal needs a linked employee profile.'); }
        if (Auth::roleCode() === 'MANAGER' && !$mine) {
            $departmentId = Auth::managerDepartmentId();
            if ($departmentId === null) { Response::forbidden('Manager must be linked to a department.'); }
            $filters['manager_employee_id'] = Auth::employeeId();
            $filters['manager_department_id'] = $departmentId;
            unset($filters['employee_id']);
        }
        $filters['archived'] = 'false';

        if (!Auth::hasAnyPermission(['overtime.view'])) {
            $employeeId = Auth::employeeId();

            if ($employeeId === null) {
                Response::forbidden('Your account is not linked to an employee record.');
            }

            $filters['employee_id'] = $employeeId;
        }

        if ($mine) {
            $filters['employee_id'] = Auth::employeeId();
            unset($filters['department_id'], $filters['manager_employee_id'], $filters['manager_department_id']);
        }
        $pagination = $request->pagination();
        $result = $this->overtime->list($filters, $pagination['page'], $pagination['per_page']);

        if (Auth::roleCode() !== 'HR_PAYROLL') {
            foreach ($result['items'] as &$item) { unset($item['basic_salary'], $item['salary_type']); }
            unset($item);
        }
        Response::paginated($result['items'], $result['total'], $pagination['page'], $pagination['per_page']);
    }

    /** GET /api/overtime/{id} */
    public function show(Request $request, array $params): never
    {
        Auth::require($request);

        $id     = (int) ($params['id'] ?? 0);
        $record = $this->overtime->find($id);

        if ($record === null) {
            Response::notFound('Overtime assignment not found.');
        }

        if (!Auth::hasAnyPermission(['overtime.view'])) {
            Auth::requireSelfOrPermission((int) $record['employee_id'], 'overtime.view_own');
        }
        if (Auth::roleCode() === 'MANAGER') { Auth::requireTeamEmployee((int) $record['employee_id']); }

        if (Auth::roleCode() !== 'HR_PAYROLL') { unset($record['basic_salary'], $record['salary_type']); }
        Response::success($record, 'Overtime assignment retrieved successfully');
    }

    /** POST /api/overtime — Admin announces an assignment (one/many employees). */
    public function store(Request $request, array $params): never
    {
        Auth::authorize('overtime.create');

        $body = $request->body();
        $ids = $body['employee_ids'] ?? [$body['employee_id'] ?? 0];
        if (!is_array($ids)) { $ids = [$ids]; }
        foreach ($ids as $id) {
            if (Auth::employeeId() !== null && (int) $id === Auth::employeeId()) {
                Response::forbidden('You cannot assign your own overtime. A separate authorized manager must assign it.');
            }
            Auth::requireTeamEmployee((int) $id);
        }
        try {
            $record = $this->overtime->create($body);
        } catch (\RuntimeException $e) {
            Response::error($e->getMessage(), 422, $e instanceof \App\Core\ValidationException ? $e->errors() : []);
        }

        $message = isset($record['items'])
            ? sprintf('Overtime assigned to %d employee(s) successfully', count($record['items']))
            : 'Overtime assignment published successfully';

        Response::created($record, $message);
    }
    /** PUT /api/overtime/{id} — Admin edits a pending/accepted assignment. */
    public function update(Request $request, array $params): never
    {
        Auth::authorize('overtime.create');

        $existing = $this->overtime->find((int) ($params['id'] ?? 0));
        if ($existing === null) { Response::notFound('OT not found.'); }
        Auth::requireTeamEmployee((int) $existing['employee_id']);
        try {
            $record = $this->overtime->update((int) ($params['id'] ?? 0), $request->body());
        } catch (\RuntimeException $e) {
            Response::error($e->getMessage(), 422, $e instanceof \App\Core\ValidationException ? $e->errors() : []);
        }

        Response::success($record, 'Overtime assignment updated successfully');
    }

    /** POST /api/overtime/{id}/approve — Admin confirms assignment for payroll. */
    public function approve(Request $request, array $params): never
    {
        Auth::authorize('overtime.approve');
        $target = $this->overtime->find((int) ($params['id'] ?? 0));
        if ($target !== null && Auth::employeeId() !== null && (int)$target['employee_id'] === Auth::employeeId()) {
            Response::forbidden('You cannot authorize your own overtime.');
        }

        try {
            $record = $this->overtime->approve(
                (int) ($params['id'] ?? 0),
                (string) $request->body('remarks', '')
            );
        } catch (\RuntimeException $e) {
            Response::error($e->getMessage(), 422, $e instanceof \App\Core\ValidationException ? $e->errors() : []);
        }

        Response::success($record, 'Overtime authorized. Complete actual OT QR scans before payroll verification.');
    }

    /** POST /api/overtime/{id}/confirm-actual — team Manager confirms scanned work. */
    public function confirmActual(Request $request, array $params): never
    {
        Auth::authorize('overtime.create');
        try {
            $record = $this->overtime->confirmActual((int) ($params['id'] ?? 0));
        } catch (\RuntimeException $e) {
            Response::error($e->getMessage(), 422, $e instanceof \App\Core\ValidationException ? $e->errors() : []);
        }
        Response::success($record, 'Actual OT confirmed. HR must verify for payroll.');
    }

    /** POST /api/overtime/{id}/verify-payroll — HR verifies actual payable time. */
    public function verifyPayroll(Request $request, array $params): never
    {
        Auth::authorize('overtime.approve');
        try {
            $record = $this->overtime->verifyPayroll((int) ($params['id'] ?? 0));
        } catch (\RuntimeException $e) {
            Response::error($e->getMessage(), 422, $e instanceof \App\Core\ValidationException ? $e->errors() : []);
        }
        Response::success($record, 'Verified actual OT hours are now eligible for payroll.');
    }

    /** POST /api/overtime/{id}/reject — Admin rejects an assignment. */
    public function reject(Request $request, array $params): never
    {
        Auth::authorize('overtime.approve');
        $target = $this->overtime->find((int) ($params['id'] ?? 0));
        if ($target !== null && Auth::employeeId() !== null && (int)$target['employee_id'] === Auth::employeeId()) {
            Response::forbidden('You cannot authorize your own overtime.');
        }

        try {
            $record = $this->overtime->reject(
                (int) ($params['id'] ?? 0),
                (string) $request->body('remarks', '')
            );
        } catch (\RuntimeException $e) {
            Response::error($e->getMessage(), 422);
        }

        Response::success($record, 'Overtime assignment rejected successfully');
    }

    /** Retired response endpoints: employee acknowledgement is not a gate. */
    public function accept(Request $request, array $params): never
    {
        Auth::require($request);
        Response::error('Employee Accept/Decline is no longer required. Manager assignment proceeds to independent HR authorization.', 410);
    }

    public function decline(Request $request, array $params): never
    {
        Auth::require($request);
        Response::error('Employee Accept/Decline was removed. Contact your Manager or HR if you cannot perform assigned OT.', 410);
    }

    /** GET /api/overtime/tomorrow — admin "Tomorrow's OT" monitoring section. */
    public function tomorrow(Request $request, array $params): never
    {
        Auth::require($request);

        if (!Auth::hasAnyPermission(['overtime.view'])) {
            $employeeId = Auth::employeeId();

            if ($employeeId === null) {
                Response::forbidden('Your account is not linked to an employee record.');
            }

            $pagination = $request->pagination();
            $result = $this->overtime->tomorrow($pagination['page'], $pagination['per_page']);

            // Non-admins only see their own rows even in the tomorrow feed.
            $result['items'] = array_values(array_filter(
                $result['items'],
                static fn (array $row): bool => (int) $row['employee_id'] === $employeeId
            ));
            $result['total'] = count($result['items']);

            if (Auth::roleCode() !== 'HR_PAYROLL') {
            foreach ($result['items'] as &$item) { unset($item['basic_salary'], $item['salary_type']); }
            unset($item);
        }
        Response::paginated($result['items'], $result['total'], $pagination['page'], $pagination['per_page']);
        }

        $pagination = $request->pagination();
        $result = $this->overtime->tomorrow($pagination['page'], $pagination['per_page']);

        if (Auth::roleCode() === 'MANAGER') {
            $dept = Auth::managerDepartmentId();
            $result['items'] = array_values(array_filter($result['items'], static function(array $row) use ($dept): bool {
                return $dept !== null && (int)(\App\Core\Database::scalar('SELECT department_id FROM employees WHERE id = :id', ['id' => (int)$row['employee_id']]) ?? 0) === $dept;
            }));
            $result['total'] = count($result['items']);
        }
        if (Auth::roleCode() !== 'HR_PAYROLL') {
            foreach ($result['items'] as &$item) { unset($item['basic_salary'], $item['salary_type']); }
            unset($item);
        }
        Response::paginated($result['items'], $result['total'], $pagination['page'], $pagination['per_page']);
    }

    /** DELETE /api/overtime/{id} — Admin archives an assignment. */
    public function destroy(Request $request, array $params): never
    {
        Response::forbidden('Archive/restore has been disabled by company policy.');
    }

    /** POST /api/overtime/{id}/restore — Admin returns an archived assignment. */
    public function restore(Request $request, array $params): never
    {
        Response::forbidden('Archive/restore has been disabled by company policy.');
    }

    /** POST /api/overtime/{id}/cancel — Admin cancels an assignment. */
    public function cancel(Request $request, array $params): never
    {
        Auth::authorize('overtime.create');
        $existing = $this->overtime->find((int) ($params['id'] ?? 0));
        if ($existing === null) { Response::notFound('OT not found.'); }
        Auth::requireTeamEmployee((int) $existing['employee_id']);
        try {
            $record = $this->overtime->cancel((int) ($params['id'] ?? 0));
        } catch (\RuntimeException $e) {
            Response::error($e->getMessage(), 422);
        }

        Response::success($record, 'Overtime assignment cancelled successfully');
    }

    /** GET /api/overtime/rates — configurable multipliers (Phase 12). */
    public function rates(Request $request, array $params): never
    {
        Auth::require($request);

        Response::success([
            'overtime_enabled'             => \App\Core\Settings::bool('payroll.overtime_enabled', true),
            'overtime_multiplier'          => \App\Core\Settings::float('payroll.overtime_multiplier', 1.25),
            'overtime_rest_day_multiplier' => \App\Core\Settings::float('payroll.overtime_rest_day_multiplier', 1.30),
            'overtime_holiday_multiplier'  => \App\Core\Settings::float('payroll.overtime_holiday_multiplier', 2.00),
            'overtime_min_hours'           => \App\Core\Settings::float('payroll.overtime_min_hours', 0.0),
        ], 'Overtime rates retrieved successfully');
    }
}