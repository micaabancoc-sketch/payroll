<?php
/**
 * Report endpoints (Phase 17).
 */

declare(strict_types=1);

namespace App\Controllers;

use App\Core\Auth;
use App\Core\Request;
use App\Core\Response;
use App\Services\ReportService;

final class ReportController
{
    public function __construct(private ReportService $reports = new ReportService())
    {
    }

    /** GET /api/reports/attendance/daily */
    public function attendanceDaily(Request $request, array $params): never
    {
        Auth::authorizeAny(['report.attendance', 'attendance.view']);

        $pagination = $request->pagination();

        $result = $this->reports->dailyAttendance(
            $this->filters($request),
            $pagination['page'],
            $pagination['per_page']
        );

        $this->respondOrCsv($request, $result['items'], $result['total'], $pagination, 'attendance-daily');
    }

    /** GET /api/reports/attendance/monthly */
    public function attendanceMonthly(Request $request, array $params): never
    {
        Auth::authorizeAny(['report.attendance', 'attendance.view']);

        $rows = $this->reports->monthlyAttendance($this->filters($request));

        $this->respondOrCsv($request, $rows, count($rows), null, 'attendance-monthly');
    }

    /** GET /api/reports/attendance/late */
    public function attendanceLate(Request $request, array $params): never
    {
        Auth::authorizeAny(['report.attendance', 'attendance.view']);

        $pagination = $request->pagination();

        $result = $this->reports->lateReport(
            $this->filters($request),
            $pagination['page'],
            $pagination['per_page']
        );

        $this->respondOrCsv($request, $result['items'], $result['total'], $pagination, 'attendance-late');
    }
/** GET /api/reports/attendance/absent */
    public function attendanceAbsent(Request $request, array $params): never
    {
        Auth::authorizeAny(['report.attendance', 'attendance.view']);

        $pagination = $request->pagination();

        $result = $this->reports->absenceReport(
            $this->filters($request),
            $pagination['page'],
            $pagination['per_page']
        );

        $this->respondOrCsv($request, $result['items'], $result['total'], $pagination, 'attendance-absent');
    }

    /** GET /api/reports/attendance/undertime */
    public function attendanceUndertime(Request $request, array $params): never
    {
        Auth::authorizeAny(['report.attendance', 'attendance.view']);

        $pagination = $request->pagination();

        $result = $this->reports->undertimeReport(
            $this->filters($request),
            $pagination['page'],
            $pagination['per_page']
        );

        $this->respondOrCsv($request, $result['items'], $result['total'], $pagination, 'attendance-undertime');
    }

    /** GET /api/reports/attendance/employee/{employeeId} */
    public function attendanceEmployee(Request $request, array $params): never
    {
        Auth::require($request);

        $employeeId = (int) ($params['employeeId'] ?? 0);

        Auth::requireSelfOrPermission($employeeId, 'attendance.view');

        $filters = $this->filters($request);
        $filters['employee_id'] = $employeeId;

        $pagination = $request->pagination();
        $result = $this->reports->attendanceReport($filters, $pagination['page'], $pagination['per_page']);

        $this->respondOrCsv($request, $result['items'], $result['total'], $pagination, 'attendance-employee');
    }

    /** GET /api/reports/attendance-leave-ledger */
    public function attendanceLeaveLedger(Request $request, array $params): never
    {
        Auth::authorizeAny(['report.attendance', 'attendance.view']);

        $filters = $this->filters($request);
        $employeeId = (int) ($filters['employee_id'] ?? 0);
        if ($employeeId <= 0) {
            Response::validationError(['employee_id' => 'Select an employee to generate the ledger.']);
        }

        $pagination = $request->pagination();
        $result = $this->reports->attendanceLeaveLedger(
            $employeeId,
            $filters,
            $pagination['page'],
            $pagination['per_page']
        );

        $this->respondOrCsv($request, $result['items'], $result['total'], $pagination, 'attendance-leave-ledger');
    }

    /** GET /api/reports/attendance-leave-ledger/summary — executive KPIs + chart data */
    public function attendanceLeaveLedgerSummary(Request $request, array $params): never
    {
        Auth::authorizeAny(['report.attendance', 'attendance.view']);

        $filters = $this->filters($request);
        $employeeId = (int) ($filters['employee_id'] ?? 0);
        if ($employeeId <= 0) {
            Response::validationError(['employee_id' => 'Select an employee to generate the ledger.']);
        }

        Response::success(
            $this->reports->attendanceLeaveLedgerSummary($employeeId, $filters),
            'Ledger summary retrieved successfully'
        );
    }

    /** GET /api/reports/overtime */
    public function overtime(Request $request, array $params): never
    {
        Auth::authorizeAny(['report.payroll', 'report.attendance', 'overtime.view']);

        $pagination = $request->pagination();

        $result = $this->reports->overtimeReport(
            $this->filters($request),
            $pagination['page'],
            $pagination['per_page']
        );

        $this->respondOrCsv($request, $result['items'], $result['total'], $pagination, 'overtime');
    }
/** GET /api/reports/leave/history */
    public function leaveHistory(Request $request, array $params): never
    {
        Auth::authorizeAny(['report.leave', 'leave.view']);

        $rows = $this->reports->leaveHistory($this->filters($request));

        $this->respondOrCsv($request, $rows, count($rows), null, 'leave-history');
    }

    /** GET /api/reports/leave/balance */
    public function leaveBalance(Request $request, array $params): never
    {
        Auth::authorizeAny(['report.leave', 'leave.view']);

        $rows = $this->reports->leaveBalanceReport($this->filters($request));

        $this->respondOrCsv($request, $rows, count($rows), null, 'leave-balance');
    }

    /** GET /api/reports/payroll/summary */
    public function payrollSummary(Request $request, array $params): never
    {
        Auth::authorizeAny(['report.payroll', 'payroll.view']);

        $rows = $this->reports->payrollSummary($this->filters($request));

        $this->respondOrCsv($request, $rows, count($rows), null, 'payroll-summary');
    }

    /** GET /api/reports/payroll/employee */
    public function payrollEmployee(Request $request, array $params): never
    {
        Auth::authorizeAny(['report.payroll', 'payroll.view']);

        $rows = $this->reports->employeePayroll($this->filters($request));

        $this->respondOrCsv($request, $rows, count($rows), null, 'payroll-employee');
    }

    /** GET /api/reports/payroll/department */
    public function payrollDepartment(Request $request, array $params): never
    {
        Auth::authorizeAny(['report.payroll', 'payroll.view']);

        $rows = $this->reports->departmentPayroll($this->filters($request));

        $this->respondOrCsv($request, $rows, count($rows), null, 'payroll-department');
    }

    /** GET /api/reports/payroll/deductions */
    public function payrollDeductions(Request $request, array $params): never
    {
        Auth::authorizeAny(['report.payroll', 'payroll.view']);

        $rows = $this->reports->deductionReport($this->filters($request));

        $this->respondOrCsv($request, $rows, count($rows), null, 'payroll-deductions');
    }

    /** GET /api/reports/statutory/contributions — employee-level contribution register */
    public function statutoryContributions(Request $request, array $params): never
    {
        Auth::authorizeAny(['report.statutory']);

        $pagination = $request->pagination();

        $result = $this->reports->statutoryContributions(
            $this->filters($request),
            $pagination['page'],
            $pagination['per_page']
        );

        $this->respondOrCsv($request, $result['items'], $result['total'], $pagination, 'statutory-contributions');
    }

    /** GET /api/reports/statutory/remittances — the remittance register itself */
    public function statutoryRemittances(Request $request, array $params): never
    {
        Auth::authorizeAny(['report.statutory']);

        $rows = $this->reports->statutoryRemittances($this->filters($request));

        $this->respondOrCsv($request, $rows, count($rows), null, 'statutory-remittances');
    }

    /** GET /api/reports/statutory/summary — due totals by agency and month */
    public function statutorySummary(Request $request, array $params): never
    {
        Auth::authorizeAny(['report.statutory']);

        $rows = $this->reports->statutorySummary($this->filters($request));

        $this->respondOrCsv($request, $rows, count($rows), null, 'statutory-summary');
    }

    /**
     * Return JSON or stream CSV when the caller asked for an export.
     *
     * @param list<array<string, mixed>> $items
     * @param array<string, int>|null $pagination
     */
    private function respondOrCsv(
        Request $request,
        array $items,
        int $total,
        ?array $pagination,
        string $name
    ): never {
        if (strtolower((string) $request->query('format', '')) === 'csv') {
            ReportService::toCsv($items, $name . '-' . date('Y-m-d') . '.csv');
        }

        if ($pagination === null) {
            Response::success($items, 'Report retrieved successfully', 200, ['total' => $total]);
        }

        Response::paginated($items, $total, $pagination['page'], $pagination['per_page']);
    }

    /**
     * Filters taken from the query string, scoping an employee to their own data.
     *
     * @return array<string, mixed>
     */
    private function filters(Request $request): array
    {
        $filters = $request->query();

        // An employee can only report on their own records (rule 13).
        if (!Auth::hasAnyPermission(['attendance.view', 'employees.view', 'payroll.view', 'leave.view'])) {
            $employeeId = Auth::employeeId();

            if ($employeeId !== null) {
                $filters['employee_id'] = $employeeId;
            }
        }

        return $filters;
    }
}
