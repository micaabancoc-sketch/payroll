<?php
/**
 * Leave endpoints (Phase 10).
 */

declare(strict_types=1);

namespace App\Controllers;

use App\Core\Auth;
use App\Core\Request;
use App\Core\Response;
use App\Services\EmployeeService;
use App\Services\LeaveService;

final class LeaveController
{
    public function __construct(
        private LeaveService $leave = new LeaveService(),
        private EmployeeService $employees = new EmployeeService()
    ) {
    }

    /** Save a verified document outside the web root; returns a tokenized relative path. */
    public function uploadAttachment(Request $request, array $params): never
    {
        Auth::authorize('leave.create', $request);
        $file = $request->files()['attachment'] ?? null;
        if (!is_array($file) || (int) ($file['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) {
            Response::validationError(['attachment' => 'Select a valid PDF, JPEG or PNG attachment.']);
        }
        $size = (int) ($file['size'] ?? 0);
        if ($size < 1 || $size > 2 * 1024 * 1024 || !is_uploaded_file((string) ($file['tmp_name'] ?? ''))) {
            Response::validationError(['attachment' => 'Attachment must be a valid uploaded document up to 2 MB.']);
        }
        $mime = (new \finfo(FILEINFO_MIME_TYPE))->file((string) $file['tmp_name']);
        $allowed = ['application/pdf'=>'pdf', 'image/jpeg'=>'jpg', 'image/png'=>'png'];
        if (!isset($allowed[$mime])) { Response::validationError(['attachment' => 'Only PDF, JPG, or PNG documents are supported.']); }
        $directory = dirname(__DIR__, 2) . '/storage/uploads/leave';
        if (!is_dir($directory) && !mkdir($directory, 0700, true) && !is_dir($directory)) {
            Response::error('Secure attachment storage unavailable.', 500);
        }
        $name = bin2hex(random_bytes(24)) . '.' . $allowed[$mime];
        if (!move_uploaded_file((string) $file['tmp_name'], $directory . '/' . $name)) {
            Response::error('Unable to store attachment.', 500);
        }
        Response::success(['attachment_path' => 'uploads/leave/' . $name], 'Document uploaded securely.');
    }

    /** GET /api/leave/working-days — actual scheduled days, excludes rest days and holidays. */
    public function workingDays(Request $request, array $params): never
    {
        Auth::require($request);
        $employeeId=(int)($request->query('employee_id') ?? 0);
        $start=(string)($request->query('start_date') ?? '');
        $end=(string)($request->query('end_date') ?? '');
        if (!$employeeId || !preg_match('/^\d{4}-\d{2}-\d{2}$/',$start)
            || !preg_match('/^\d{4}-\d{2}-\d{2}$/',$end) || $end<$start) {
            Response::validationError(['dates'=>'Choose an employee and valid start/end dates.']);
        }
        if (!Auth::hasAnyPermission(['leave.view','employees.update']) && Auth::employeeId() !== $employeeId) {
            Response::forbidden('You may preview only your own leave dates.');
        }
        $startDate=new \DateTimeImmutable($start);
        $endDate=new \DateTimeImmutable($end);
        if ($startDate->diff($endDate)->days > 366) {
            Response::validationError(['dates'=>'Leave preview may span at most 366 days.']);
        }
        Response::success(['days'=>$this->leave->countWorkingDays($employeeId,$start,$end)]);
    }

    /** GET /api/leave — requests with filters. */
    public function index(Request $request, array $params): never
    {
        Auth::require($request);

        $filters = $request->query();
        $mine = filter_var($filters['mine'] ?? false, FILTER_VALIDATE_BOOLEAN);
        if ($mine && \App\Core\DemoStaffScope::isSystemOperator()) {
            Response::forbidden('HR and Manager are system operators; personal leave is disabled for the demo.');
        }
        if ($mine && Auth::employeeId() === null) { Response::forbidden('Personal portal needs a linked employee profile.'); }
        if (Auth::roleCode() === 'MANAGER' && !$mine) {
            $departmentId = Auth::managerDepartmentId();
            if ($departmentId === null) { Response::forbidden('Manager must be linked to a department.'); }
            $filters['manager_employee_id'] = Auth::employeeId();
            $filters['manager_department_id'] = $departmentId;
            unset($filters['employee_id']);
        }
        $filters['archived'] = 'false';

        if (Auth::roleCode() === 'MANAGER') {
            $department = Auth::managerDepartmentId();
            if ($department === null) { Response::forbidden('Manager has no department.'); }
            $filters['manager_employee_id'] = Auth::employeeId();
            $filters['manager_department_id'] = $department;
        }
        if (!Auth::hasAnyPermission(['leave.view'])) {
            $employeeId = Auth::employeeId();

            if ($employeeId === null) {
                Response::forbidden('Your account is not linked to an employee record.');
            }

            $filters['employee_id'] = $employeeId;
        }

        if ($mine) {
            $filters['employee_id'] = Auth::employeeId();
            unset($filters['department_id'], $filters['manager_employee_id'], $filters['manager_department_id']);
        }
        $pagination = $request->pagination();
        $result = $this->leave->list($filters, $pagination['page'], $pagination['per_page']);

        Response::paginated($result['items'], $result['total'], $pagination['page'], $pagination['per_page']);
    }

    /** GET /api/leave/{id} */
    public function show(Request $request, array $params): never
    {
        Auth::require($request);

        $id    = (int) ($params['id'] ?? 0);
        $leave = $this->leave->find($id);

        if ($leave === null) {
            Response::notFound('Leave request not found.');
        }

        if (!Auth::hasAnyPermission(['leave.view'])) {
            Auth::requireSelfOrPermission((int) $leave['employee_id'], 'leave.view_own');
        }
        if (Auth::roleCode() === 'MANAGER') { Auth::requireTeamEmployee((int) $leave['employee_id']); }

        Response::success($leave, 'Leave request retrieved successfully');
    }

    /** POST /api/leave — submit a request (Phase 10). */
    public function store(Request $request, array $params): never
    {
        Auth::authorize('leave.create');

        try {
            $leave = $this->leave->create($request->body());
        } catch (\RuntimeException $e) {
            Response::error($e->getMessage(), 422, $e instanceof \App\Core\ValidationException ? $e->errors() : []);
        }

        Response::created($leave, 'Leave request submitted successfully');
    }
    /** PUT /api/leave/{id} — edit a pending request */
    public function update(Request $request, array $params): never
    {
        Auth::authorize('leave.create');

        try {
            $leave = $this->leave->update((int) ($params['id'] ?? 0), $request->body());
        } catch (\RuntimeException $e) {
            Response::error($e->getMessage(), 422, $e instanceof \App\Core\ValidationException ? $e->errors() : []);
        }

        Response::success($leave, 'Leave request updated successfully');
    }

    /** DELETE /api/leave/{id} — remove a pending/rejected/cancelled request */
    public function destroy(Request $request, array $params): never
    {
        Auth::authorize('leave.create');

        try {
            $result = $this->leave->delete((int) ($params['id'] ?? 0));
        } catch (\RuntimeException $e) {
            Response::error($e->getMessage(), 422);
        }

        Response::success($result, 'Leave request moved to archive. Purge it in Data deletion.');
    }

    /** POST /api/leave/{id}/restore — return an archived request to its list */
    public function restore(Request $request, array $params): never
    {
        Auth::authorize('leave.create');

        try {
            $leave = $this->leave->restore((int) ($params['id'] ?? 0));
        } catch (\RuntimeException $e) {
            Response::error($e->getMessage(), 422);
        }

        Response::success($leave, 'Leave request restored successfully');
    }

/** POST /api/leave/{id}/approve */
    public function approve(Request $request, array $params): never
    {
        Auth::authorize('leave.approve');
        if (Auth::roleCode() === 'MANAGER') {
            $existing = $this->leave->find((int) ($params['id'] ?? 0));
            if ($existing === null) { Response::notFound('Leave not found.'); }
            Auth::requireTeamEmployee((int) $existing['employee_id']);
        }
        try {
            $leave = $this->leave->approve(
                (int) ($params['id'] ?? 0),
                (string) $request->body('remarks', '')
            );
        } catch (\RuntimeException $e) {
            Response::error($e->getMessage(), 422);
        }

        Response::success($leave, 'Leave request approved successfully');
    }

    /** POST /api/leave/{id}/reject */
    public function reject(Request $request, array $params): never
    {
        Auth::authorize('leave.approve');
        if (Auth::roleCode() === 'MANAGER') {
            $existing = $this->leave->find((int) ($params['id'] ?? 0));
            if ($existing === null) { Response::notFound('Leave not found.'); }
            Auth::requireTeamEmployee((int) $existing['employee_id']);
        }
        try {
            $leave = $this->leave->reject(
                (int) ($params['id'] ?? 0),
                (string) $request->body('remarks', '')
            );
        } catch (\RuntimeException $e) {
            Response::error($e->getMessage(), 422);
        }

        Response::success($leave, 'Leave request rejected successfully');
    }

    /** POST /api/leave/{id}/cancel */
    public function cancel(Request $request, array $params): never
    {
        Auth::require($request);

        try {
            $leave = $this->leave->cancel(
                (int) ($params['id'] ?? 0),
                (string) $request->body('remarks', '')
            );
        } catch (\RuntimeException $e) {
            Response::error($e->getMessage(), 422);
        }

        Response::success($leave, 'Leave request cancelled successfully');
    }

    /** GET /api/leave/types */
    public function types(Request $request, array $params): never
    {
        Auth::require($request);

        Response::success($this->leave->leaveTypes(), 'Leave types retrieved successfully');
    }

    /** GET /api/leave/balances/{employeeId} */
    public function balances(Request $request, array $params): never
    {
        Auth::require($request);

        $employeeId = (int) ($params['employeeId'] ?? 0);

        Auth::requireSelfOrPermission($employeeId, 'leave.view_own');

        Response::success(
            $this->employees->leaveBalances($employeeId),
            'Leave balances retrieved successfully'
        );
    }

    /** GET /api/leave/balance-summary */
    public function balanceSummary(Request $request, array $params): never
    {
        if (Auth::roleCode() === 'MANAGER') { Response::forbidden('This leave administration function is HR-only.'); }
        Auth::authorizeAny(['leave.view', 'report.leave']);

        Response::success(
            $this->leave->balanceSummary((int) $request->query('year', date('Y'))),
            'Leave balance summary retrieved successfully'
        );
    }

    /** GET /api/leave/employee-balances */
    public function employeeBalances(Request $request, array $params): never
    {
        Auth::require($request);

        $employeeId = null;
        if (Auth::roleCode() === 'MANAGER') {
            $department = Auth::managerDepartmentId();
            if ($department === null) { Response::forbidden('Manager has no department.'); }
            $filters['manager_employee_id'] = Auth::employeeId();
            $filters['manager_department_id'] = $department;
        }
        if (!Auth::hasAnyPermission(['leave.view'])) {
            $employeeId = Auth::employeeId();
            if ($employeeId === null) {
                Response::forbidden('Your account is not linked to an employee record.');
            }
        }

        Response::success(
            $this->leave->employeeBalanceSummary($employeeId, (int) $request->query('year', date('Y'))),
            'Employee leave balances retrieved successfully'
        );
    }

    /** POST /api/leave/balances/adjust — correct an employee's entitled days. */
    public function adjustBalance(Request $request, array $params): never
    {
        if (Auth::roleCode() === 'MANAGER') { Response::forbidden('This leave administration function is HR-only.'); }
        Auth::authorize('leave.approve');

        $body = $request->body();

        try {
            $balances = $this->leave->adjustBalance(
                (int) ($body['employee_id'] ?? 0),
                (int) ($body['leave_type_id'] ?? 0),
                (int) ($body['year'] ?? date('Y')),
                (float) ($body['entitled_days'] ?? -1),
                (string) ($body['reason'] ?? '')
            );
        } catch (\RuntimeException $e) {
            Response::error($e->getMessage(), 422, $e instanceof \App\Core\ValidationException ? $e->errors() : []);
        }

        Response::success($balances, 'Leave balance updated successfully');
    }

    /** GET /api/leave/calendar — approved leave for a month. */
    public function calendar(Request $request, array $params): never
    {
        Auth::require($request);

        $filters = [
            'status'    => 'APPROVED',
            'date_from' => (string) $request->query('date_from', date('Y-m-01')),
            'date_to'   => (string) $request->query('date_to', date('Y-m-t')),
        ];

        if (Auth::roleCode() === 'MANAGER') {
            $department = Auth::managerDepartmentId();
            if ($department === null) { Response::forbidden('Manager has no department.'); }
            $filters['manager_employee_id'] = Auth::employeeId();
            $filters['manager_department_id'] = $department;
        }
        if (!Auth::hasAnyPermission(['leave.view'])) {
            $employeeId = Auth::employeeId();

            if ($employeeId === null) {
                Response::forbidden('Your account is not linked to an employee record.');
            }

            $filters['employee_id'] = $employeeId;
        } elseif (!empty($request->query('employee_id'))) {
            $filters['employee_id'] = (int) $request->query('employee_id');
        }

        Response::success($this->leave->list($filters, 1, 500), 'Leave calendar retrieved successfully');
    }
}
