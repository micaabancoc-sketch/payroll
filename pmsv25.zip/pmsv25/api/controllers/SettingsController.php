<?php
/**
 * Settings endpoints (Phase 19) — configurable business rules.
 */

declare(strict_types=1);

namespace App\Controllers;

use App\Core\AuditLogger;
use App\Core\Auth;
use App\Core\Database;
use App\Core\Request;
use App\Core\Response;
use App\Core\Settings;
use App\Services\EmployeeService;
use App\Services\HolidayService;
use App\Services\PayrollEngine;
use App\Services\ScheduleService;
use App\Services\StatutoryDeductionService;
use InvalidArgumentException;
use Throwable;

final class SettingsController
{
    private const ARCHIVES = [
        'employees'         => ['label' => 'Employees',          'table' => 'employees',         'where' => 'archived_at IS NOT NULL OR deleted_at IS NOT NULL'],
        'users'             => ['label' => 'Users',              'table' => 'users',              'where' => 'deleted_at IS NOT NULL'],
        'departments'       => ['label' => 'Departments',        'table' => 'departments',       'where' => 'deleted_at IS NOT NULL'],
        'positions'         => ['label' => 'Positions',          'table' => 'positions',         'where' => 'deleted_at IS NOT NULL'],
        'schedules'         => ['label' => 'Work schedules',     'table' => 'work_schedules',    'where' => 'deleted_at IS NOT NULL'],
        'shifts'            => ['label' => 'Shifts',             'table' => 'shifts',            'where' => 'deleted_at IS NOT NULL'],
        'holidays'          => ['label' => 'Holidays',           'table' => 'holidays',          'where' => 'deleted_at IS NOT NULL'],
        'leave_types'       => ['label' => 'Leave types',        'table' => 'leave_types',       'where' => 'deleted_at IS NOT NULL'],
        'attendance'        => ['label' => 'Attendance records', 'table' => 'attendance',        'where' => 'deleted_at IS NOT NULL'],
        'leave_requests'    => ['label' => 'Leave requests',     'table' => 'leave_requests',    'where' => 'deleted_at IS NOT NULL'],
        'overtime_requests' => ['label' => 'Overtime assignments', 'table' => 'overtime_requests', 'where' => 'deleted_at IS NOT NULL'],
        'allowances'        => ['label' => 'Allowances',         'table' => 'allowances',        'where' => 'deleted_at IS NOT NULL'],
        'deductions'        => ['label' => 'Deductions',         'table' => 'deductions',        'where' => 'deleted_at IS NOT NULL'],
        'payroll_periods'   => ['label' => 'Payroll periods',    'table' => 'payroll_periods',   'where' => 'deleted_at IS NOT NULL'],
    ];

    /** GET /api/settings — all settings (super admin only). */
    public function index(Request $request, array $params): never
    {
        Auth::authorize('settings.manage');

        Response::success($this->managedSettings(), 'Settings retrieved successfully');
    }

    /** GET /api/settings/public — values safe to expose to any signed-in user. */
    public function publicSettings(Request $request, array $params): never
    {
        Auth::require($request);

        Response::success(
            $this->publicKeys(),
            'Public settings retrieved successfully'
        );
    }

    /** PUT /api/settings — update settings (Phase 19). */
    public function update(Request $request, array $params): never
    {
        Auth::authorize('settings.manage');

        $body = $request->body();

        if (!is_array($body) || $body === []) {
            Response::validationError(['settings' => 'At least one setting must be supplied.']);
        }

        // Capture the previous values so the audit trail shows the change.
        $before = Settings::all();

        $pairs = [];
        foreach ($body as $key => $value) {
            if (!is_string($key) || !$this->isManagedSetting($key)) {
                continue;
            }
            $pairs[$key] = is_scalar($value) ? (string) $value : (string) json_encode($value);
        }

        if ($pairs === []) {
            Response::validationError(['settings' => 'No editable settings were supplied.']);
        }

        Settings::setMany($pairs);

        $after = Settings::all();

        $changed = [];
        foreach ($pairs as $key => $value) {
            $old = $before[$key] ?? null;
            if ((string) $old !== (string) $value) {
                $changed[$key] = ['old' => $old, 'new' => $value];
            }
        }

        AuditLogger::record(
            AuditLogger::SETTINGS_CHANGED,
            'system_settings',
            null,
            $changed === []
                ? 'Settings saved (no changes)'
                : sprintf('Settings changed: %s', implode(', ', array_keys($changed))),
            $changed === [] ? null : array_map(static fn (array $c): mixed => $c['old'], $changed),
            $changed === [] ? null : array_map(static fn (array $c): mixed => $c['new'], $changed)
        );

        Response::success($this->managedSettings(), 'Settings updated successfully');
    }

    /** GET /api/settings/branding - public logo used by the sign-in page and shell. */
    public function branding(Request $request, array $params): never
    {
        Response::success($this->brandingValues(), 'Branding retrieved successfully');
    }

    /** POST /api/settings/logo - upload the system logo. */
    public function uploadLogo(Request $request, array $params): never
    {
        Auth::authorize('settings.manage');
        $file = $request->files()['logo'] ?? null;

        if (!is_array($file) || (int) ($file['error'] ?? UPLOAD_ERR_NO_FILE) === UPLOAD_ERR_NO_FILE) {
            Response::validationError(['logo' => 'Choose a PNG, JPEG, JPG, or WebP image.']);
        }
        if ((int) ($file['error'] ?? UPLOAD_ERR_OK) !== UPLOAD_ERR_OK) {
            Response::validationError(['logo' => 'The logo could not be uploaded. Please try again.']);
        }
        if ((int) ($file['size'] ?? 0) <= 0 || (int) $file['size'] > 5 * 1024 * 1024) {
            Response::validationError(['logo' => 'The logo must be no larger than 5 MB.']);
        }

        $temporaryPath = (string) ($file['tmp_name'] ?? '');
        if ($temporaryPath === '' || !is_uploaded_file($temporaryPath)) {
            Response::validationError(['logo' => 'The uploaded logo is not valid.']);
        }

        $mime = (new \finfo(FILEINFO_MIME_TYPE))->file($temporaryPath);
        $extensions = [
            'image/png' => 'png',
            'image/jpeg' => 'jpg',
            'image/webp' => 'webp',
        ];
        if (!is_string($mime) || !isset($extensions[$mime]) || @getimagesize($temporaryPath) === false) {
            Response::validationError(['logo' => 'Only valid PNG, JPEG, JPG, or WebP images are allowed.']);
        }

        $uploadDirectory = dirname(__DIR__, 2) . '/frontend/assets/uploads';
        if (!is_dir($uploadDirectory) && !mkdir($uploadDirectory, 0755, true) && !is_dir($uploadDirectory)) {
            Response::error('The logo storage directory could not be created.', 500);
        }

        $filename = sprintf('system-logo-%s-%s.%s', date('YmdHis'), bin2hex(random_bytes(4)), $extensions[$mime]);
        $destination = $uploadDirectory . '/' . $filename;
        if (!move_uploaded_file($temporaryPath, $destination)) {
            Response::error('The logo could not be saved.', 500);
        }

        $logoPath = 'assets/uploads/' . $filename;
        $oldLogo = Settings::string('company.logo', 'assets/system-logo.png');
        Settings::set('company.logo', $logoPath, Auth::id());

        AuditLogger::record(
            AuditLogger::SETTINGS_CHANGED,
            'system_settings',
            null,
            'System logo updated',
            ['company.logo' => $oldLogo],
            ['company.logo' => $logoPath]
        );

        Response::success($this->brandingValues(), 'System logo updated successfully');
    }
/** Public settings safe to expose to any signed-in user. */
    public function publicKeys(): array
    {
        return array_filter(
            Settings::all(),
            static fn (mixed $value, string $key): bool => in_array($key, [
                'company.name',
                'company.address',
                'company.phone',
                'company.email',
                'company.logo',
                'currency.symbol',
                'currency.position',
                'attendance.default_time_in',
                'attendance.default_time_out',
                'attendance.overtime_auto_minutes',
            ], true),
            ARRAY_FILTER_USE_BOTH
        );
    }

    /** Company information for payslips and headers. */
    public function company(Request $request, array $params): never
    {
        Auth::require($request);

        Response::success($this->publicKeys(), 'Company information retrieved successfully');
    }

    /** GET /api/settings/departments */
    public function departments(Request $request, array $params): never
    {
        Auth::require($request);

        $archived = strtolower(trim((string) $request->query('archived', ''))) === 'only';

        Response::success(
            (new EmployeeService())->departments($archived),
            'Departments retrieved successfully'
        );
    }

    /** POST /api/settings/departments/{id}/restore — return an archived department to its list */
    public function restoreDepartment(Request $request, array $params): never
    {
        Auth::authorize('settings.manage');
        $id = (int) ($params['id'] ?? 0);
        $existing = Database::selectOne('SELECT * FROM departments WHERE id = :id AND deleted_at IS NOT NULL', ['id' => $id]);
        if ($existing === null) {
            Response::notFound('Department not found or is not archived.');
        }
        Database::update('departments', ['deleted_at' => null], ['id' => $id]);
        AuditLogger::record(
            AuditLogger::SETTINGS_CHANGED,
            'department',
            $id,
            sprintf('Restored department "%s"', $existing['name']),
            ['deleted_at' => $existing['deleted_at']],
            null
        );
        Response::success(['id' => $id], 'Department restored successfully');
    }

    /** GET /api/settings/positions */
    public function positions(Request $request, array $params): never
    {
        Auth::require($request);

        $departmentId = $request->query('department_id');
        $archived = strtolower(trim((string) $request->query('archived', ''))) === 'only';

        Response::success($this->positionList($departmentId, $archived), 'Positions retrieved successfully');
    }

    /** POST /api/settings/positions/{id}/restore — return an archived position to its list */
    public function restorePosition(Request $request, array $params): never
    {
        Auth::authorize('settings.manage');
        $id = (int) ($params['id'] ?? 0);
        $existing = Database::selectOne('SELECT * FROM positions WHERE id = :id AND deleted_at IS NOT NULL', ['id' => $id]);
        if ($existing === null) {
            Response::notFound('Position not found or is not archived.');
        }
        Database::update('positions', ['deleted_at' => null], ['id' => $id]);
        AuditLogger::record(
            AuditLogger::SETTINGS_CHANGED,
            'position',
            $id,
            sprintf('Restored position "%s"', $existing['name']),
            ['deleted_at' => $existing['deleted_at']],
            null
        );
        Response::success(['id' => $id], 'Position restored successfully');
    }

    /** POST /api/settings/departments — create a department */
    public function createDepartment(Request $request, array $params): never
    {
        Auth::authorize('settings.manage');
        $body = $request->body();
        $name = trim((string) ($body['name'] ?? ''));
        if ($name === '') {
            Response::validationError(['name' => 'Department name is required.']);
        }
        $code = strtoupper(trim((string) ($body['code'] ?? '')));
        if ($code === '') {
            $code = strtoupper((string) preg_replace('/[^A-Z0-9]+/i', '', $name));
            $code = substr($code, 0, 10) !== '' ? substr($code, 0, 10) : 'DEPT';
        }
        if (Database::scalar('SELECT id FROM departments WHERE code = :c AND deleted_at IS NULL', ['c' => $code]) !== null) {
            Response::validationError(['code' => 'That department code is already in use.']);
        }
        $active = $body['is_active'] ?? 1;
        $baseSalary = parseDepartmentBaseSalary($body['base_salary'] ?? null);
        $id = Database::insert('departments', [
            'code' => $code,
            'name' => $name,
            'description' => trim((string) ($body['description'] ?? '')) !== '' ? trim((string) $body['description']) : null,
            'base_salary' => $baseSalary,
            'is_active' => ((int) $active === 1 || $active === true || $active === '1') ? 1 : 0,
        ]);
        AuditLogger::record(AuditLogger::SETTINGS_CHANGED, 'department', $id, sprintf('Created department "%s"', $name));
        Response::created(['id' => $id], 'Department created successfully');
    }

    /** PUT /api/settings/departments/{id} */
    public function updateDepartment(Request $request, array $params): never
    {
        Auth::authorize('settings.manage');
        $id = (int) ($params['id'] ?? 0);
        $existing = Database::selectOne('SELECT * FROM departments WHERE id = :id AND deleted_at IS NULL', ['id' => $id]);
        if ($existing === null) {
            Response::notFound('Department not found.');
        }
        $body = $request->body();
        $payload = [];
        if (array_key_exists('code', $body) && trim((string) $body['code']) !== '') {
            $newCode = strtoupper(trim((string) $body['code']));
            $taken = Database::scalar(
                'SELECT id FROM departments WHERE code = :c AND deleted_at IS NULL AND id != :id',
                ['c' => $newCode, 'id' => $id]
            );
            if ($taken !== null) {
                Response::validationError(['code' => 'That department code is already in use.']);
            }
            $payload['code'] = $newCode;
        }
        if (array_key_exists('name', $body) && trim((string) $body['name']) !== '') {
            $payload['name'] = trim((string) $body['name']);
        }
        if (array_key_exists('description', $body)) {
            $desc = trim((string) $body['description']);
            $payload['description'] = $desc !== '' ? $desc : null;
        }
        if (array_key_exists('is_active', $body)) {
            $payload['is_active'] = ((int) $body['is_active'] === 1 || $body['is_active'] === true || $body['is_active'] === '1') ? 1 : 0;
        }
        if (array_key_exists('base_salary', $body)) {
            $payload['base_salary'] = parseDepartmentBaseSalary($body['base_salary']);
        }
        if ($payload !== []) {
            Database::update('departments', $payload, ['id' => $id]);
        }
        AuditLogger::recordChanges(AuditLogger::SETTINGS_CHANGED, 'department', $id, $existing, array_merge($existing, $payload));
        Response::success(['id' => $id], 'Department updated successfully');
    }

    /** DELETE /api/settings/departments/{id} — archive (purge via Data deletion) */
    public function deleteDepartment(Request $request, array $params): never
    {
        Auth::authorize('settings.manage');
        $id = (int) ($params['id'] ?? 0);
        $existing = Database::selectOne('SELECT * FROM departments WHERE id = :id AND deleted_at IS NULL', ['id' => $id]);
        if ($existing === null) {
            Response::notFound('Department not found.');
        }
        $inUse = (int) (Database::scalar('SELECT COUNT(*) FROM employees WHERE department_id = :id AND deleted_at IS NULL AND archived_at IS NULL', ['id' => $id]) ?? 0);
        if ($inUse > 0) {
            Response::error('This department still has active employees. Reassign them before deleting.', 422);
        }
        Database::update('departments', ['deleted_at' => date('Y-m-d H:i:s')], ['id' => $id]);
        AuditLogger::record(AuditLogger::SETTINGS_CHANGED, 'department', $id, sprintf('Deleted department "%s"', $existing['name']), $existing, null);
        Response::success(['id' => $id], 'Department deleted successfully');
    }

    /** POST /api/settings/positions — create (Staff/Manager only) */
    public function createPosition(Request $request, array $params): never
    {
        Auth::authorize('settings.manage');
        $body = $request->body();
        $name = trim((string) ($body['name'] ?? ''));
        if ($name === '') {
            Response::validationError(['name' => 'Position name is required.']);
        }
        $level = strtoupper(trim((string) ($body['job_level'] ?? 'STAFF')));
        if (!in_array($level, ['STAFF', 'MANAGER'], true)) {
            $level = preg_match('/manager/i', $name) ? 'MANAGER' : 'STAFF';
        }
        $levelLabel = $level === 'MANAGER' ? 'Manager' : 'Staff';
        $code = strtoupper(trim((string) ($body['code'] ?? '')));
        if ($code === '') {
            $base = strtoupper((string) preg_replace('/[^A-Z0-9]+/i', '', $name));
            $code = substr($base, 0, 20) !== '' ? substr($base, 0, 20) : $level;
        }
        if (Database::scalar('SELECT id FROM positions WHERE code = :c AND deleted_at IS NULL', ['c' => $code]) !== null) {
            Response::validationError(['code' => 'That position code is already in use.']);
        }
        $deptId = $body['department_id'] ?? null;
        if ($deptId === '' || $deptId === null) {
            $deptId = null;
        } else {
            $deptId = (int) $deptId;
            if (Database::scalar('SELECT id FROM departments WHERE id = :id AND deleted_at IS NULL', ['id' => $deptId]) === null) {
                Response::validationError(['department_id' => 'The selected department does not exist.']);
            }
        }
        $active = $body['is_active'] ?? 1;
        $salaryValue = trim((string) ($body['base_salary'] ?? ''));
        if ($salaryValue !== '' && (!is_numeric($salaryValue) || (float)$salaryValue <= 0)) { Response::validationError(['base_salary'=>'Enter a positive monthly salary or leave blank to use department default.']); }
        $id = Database::insert('positions', [
            'code' => $code,
            'name' => $name,
            'department_id' => $deptId,
            'job_level' => $levelLabel,
            'base_salary' => $salaryValue === '' ? null : round((float)$salaryValue, 2),
            'description' => trim((string) ($body['description'] ?? '')) !== '' ? trim((string) $body['description']) : null,
            'is_active' => ((int) $active === 1 || $active === true || $active === '1') ? 1 : 0,
        ]);
        AuditLogger::record(AuditLogger::SETTINGS_CHANGED, 'position', $id, sprintf('Created position "%s"', $name));
        Response::created(['id' => $id], 'Position created successfully');
    }

    /** PUT /api/settings/positions/{id} */
    public function updatePosition(Request $request, array $params): never
    {
        Auth::authorize('settings.manage');
        $id = (int) ($params['id'] ?? 0);
        $existing = Database::selectOne('SELECT * FROM positions WHERE id = :id AND deleted_at IS NULL', ['id' => $id]);
        if ($existing === null) {
            Response::notFound('Position not found.');
        }
        $body = $request->body();
        $payload = [];
        if (array_key_exists('code', $body) && trim((string) $body['code']) !== '') {
            $newCode = strtoupper(trim((string) $body['code']));
            $taken = Database::scalar(
                'SELECT id FROM positions WHERE code = :c AND deleted_at IS NULL AND id != :id',
                ['c' => $newCode, 'id' => $id]
            );
            if ($taken !== null) {
                Response::validationError(['code' => 'That position code is already in use.']);
            }
            $payload['code'] = $newCode;
        }
        if (array_key_exists('name', $body) && trim((string) $body['name']) !== '') {
            $payload['name'] = trim((string) $body['name']);
        }
        if (array_key_exists('job_level', $body)) {
            $lvl = strtoupper(trim((string) $body['job_level']));
            if (in_array($lvl, ['STAFF', 'MANAGER'], true)) {
                $payload['job_level'] = $lvl === 'MANAGER' ? 'Manager' : 'Staff';
            }
        }
        if (array_key_exists('department_id', $body)) {
            $d = $body['department_id'];
            $payload['department_id'] = ($d === '' || $d === null) ? null : (int) $d;
        }
        if (array_key_exists('base_salary', $body)) {
            $salaryValue = trim((string) $body['base_salary']);
            if ($salaryValue !== '' && (!is_numeric($salaryValue) || (float)$salaryValue <= 0)) {
                Response::validationError(['base_salary' => 'Enter a positive salary or leave blank to use the Department default.']);
            }
            $payload['base_salary'] = $salaryValue === '' ? null : round((float) $salaryValue, 2);
        }
        if (array_key_exists('description', $body)) {
            $desc = trim((string) $body['description']);
            $payload['description'] = $desc !== '' ? $desc : null;
        }
        if (array_key_exists('is_active', $body)) {
            $payload['is_active'] = ((int) $body['is_active'] === 1 || $body['is_active'] === true || $body['is_active'] === '1') ? 1 : 0;
        }
        if ($payload !== []) {
            Database::update('positions', $payload, ['id' => $id]);
        }
        AuditLogger::recordChanges(AuditLogger::SETTINGS_CHANGED, 'position', $id, $existing, array_merge($existing, $payload));
        Response::success(['id' => $id], 'Position updated successfully');
    }

    /** DELETE /api/settings/positions/{id} */
    public function deletePosition(Request $request, array $params): never
    {
        Auth::authorize('settings.manage');
        $id = (int) ($params['id'] ?? 0);
        $existing = Database::selectOne('SELECT * FROM positions WHERE id = :id AND deleted_at IS NULL', ['id' => $id]);
        if ($existing === null) {
            Response::notFound('Position not found.');
        }
        $inUse = (int) (Database::scalar('SELECT COUNT(*) FROM employees WHERE position_id = :id AND deleted_at IS NULL AND archived_at IS NULL', ['id' => $id]) ?? 0);
        if ($inUse > 0) {
            Response::error('This position is assigned to active employees. Reassign them before deleting.', 422);
        }
        Database::update('positions', ['deleted_at' => date('Y-m-d H:i:s')], ['id' => $id]);
        AuditLogger::record(AuditLogger::SETTINGS_CHANGED, 'position', $id, sprintf('Deleted position "%s"', $existing['name']), $existing, null);
        Response::success(['id' => $id], 'Position deleted successfully');
    }

    /** GET /api/settings/leave-types */
    public function leaveTypes(Request $request, array $params): never
    {
        Auth::require($request);
        $archived = strtolower(trim((string) $request->query('archived', ''))) === 'only';
        Response::success(
            Database::select(
                $archived
                    ? 'SELECT * FROM leave_types WHERE deleted_at IS NOT NULL ORDER BY name'
                    : 'SELECT * FROM leave_types WHERE deleted_at IS NULL ORDER BY is_active DESC, name'
            ),
            'Leave types retrieved successfully'
        );
    }

    /** POST /api/settings/leave-types/{id}/restore — return an archived leave type to its list */
    public function restoreLeaveType(Request $request, array $params): never
    {
        Auth::authorize('settings.manage');
        $id = (int) ($params['id'] ?? 0);
        $existing = Database::selectOne('SELECT * FROM leave_types WHERE id = :id AND deleted_at IS NOT NULL', ['id' => $id]);
        if ($existing === null) {
            Response::notFound('Leave type not found or is not archived.');
        }
        Database::update('leave_types', ['deleted_at' => null], ['id' => $id]);
        AuditLogger::record(
            AuditLogger::SETTINGS_CHANGED,
            'leave_type',
            $id,
            sprintf('Restored leave type "%s"', $existing['name']),
            ['deleted_at' => $existing['deleted_at']],
            null
        );
        Response::success(['id' => $id], 'Leave type restored successfully');
    }

    /** POST /api/settings/leave-types */
    public function createLeaveType(Request $request, array $params): never
    {
        Auth::authorize('settings.manage');
        $body = $request->body();
        $name = trim((string) ($body['name'] ?? ''));
        if ($name === '') {
            Response::validationError(['name' => 'Leave type name is required.']);
        }
        $code = strtoupper(trim((string) ($body['code'] ?? '')));
        if ($code === '') {
            $code = strtoupper(substr((string) preg_replace('/[^A-Z0-9]+/i', '', $name), 0, 10));
        }
        if (Database::scalar('SELECT id FROM leave_types WHERE code = :c AND deleted_at IS NULL', ['c' => $code]) !== null) {
            Response::validationError(['code' => 'That leave code is already in use.']);
        }
        $id = Database::insert('leave_types', [
            'code' => $code,
            'name' => $name,
            'is_paid' => isset($body['is_paid']) && ((int) $body['is_paid'] === 0 || $body['is_paid'] === false || $body['is_paid'] === '0') ? 0 : 1,
            'default_days' => isset($body['default_days']) && is_numeric($body['default_days']) ? (float) $body['default_days'] : 0,
            'description' => trim((string) ($body['description'] ?? '')) !== '' ? trim((string) $body['description']) : null,
            'is_active' => 1,
        ]);
        AuditLogger::record(AuditLogger::SETTINGS_CHANGED, 'leave_type', $id, sprintf('Created leave type "%s"', $name));
        Response::created(['id' => $id], 'Leave type created successfully');
    }

    /** PUT /api/settings/leave-types/{id} */
    public function updateLeaveType(Request $request, array $params): never
    {
        Auth::authorize('settings.manage');
        $id = (int) ($params['id'] ?? 0);
        $existing = Database::selectOne('SELECT * FROM leave_types WHERE id = :id AND deleted_at IS NULL', ['id' => $id]);
        if ($existing === null) {
            Response::notFound('Leave type not found.');
        }
        $body = $request->body();
        $payload = [];
        if (array_key_exists('name', $body) && trim((string) $body['name']) !== '') {
            $payload['name'] = trim((string) $body['name']);
        }
        if (array_key_exists('is_paid', $body)) {
            $v = $body['is_paid'];
            $payload['is_paid'] = ($v === false || $v === 0 || $v === '0' || $v === 0.0) ? 0 : 1;
        }
        if (array_key_exists('default_days', $body) && is_numeric($body['default_days'])) {
            $payload['default_days'] = (float) $body['default_days'];
        }
        if (array_key_exists('description', $body)) {
            $d = trim((string) $body['description']);
            $payload['description'] = $d !== '' ? $d : null;
        }
        if (array_key_exists('is_active', $body)) {
            $v = $body['is_active'];
            $payload['is_active'] = ($v === false || $v === 0 || $v === '0') ? 0 : 1;
        }
        if ($payload !== []) {
            Database::update('leave_types', $payload, ['id' => $id]);
        }
        AuditLogger::recordChanges(AuditLogger::SETTINGS_CHANGED, 'leave_type', $id, $existing, array_merge($existing, $payload));
        Response::success(['id' => $id], 'Leave type updated successfully');
    }

    /** DELETE /api/settings/leave-types/{id} */
    public function deleteLeaveType(Request $request, array $params): never
    {
        Auth::authorize('settings.manage');
        $id = (int) ($params['id'] ?? 0);
        $existing = Database::selectOne('SELECT * FROM leave_types WHERE id = :id AND deleted_at IS NULL', ['id' => $id]);
        if ($existing === null) {
            Response::notFound('Leave type not found.');
        }
        Database::update('leave_types', ['deleted_at' => date('Y-m-d H:i:s')], ['id' => $id]);
        AuditLogger::record(AuditLogger::SETTINGS_CHANGED, 'leave_type', $id, sprintf('Deleted leave type "%s"', $existing['name']), $existing, null);
        Response::success(['id' => $id], 'Leave type deleted successfully');
    }

    /** GET /api/settings/schedules — work schedules and shifts (Phase 8). */
    public function schedules(Request $request, array $params): never
    {
        Auth::require($request);

        $service = new ScheduleService();

        Response::success([
            'schedules' => $service->all(),
            'shifts'    => $service->shifts(),
        ], 'Work schedules retrieved successfully');
    }

    /** GET /api/settings/holidays — holidays (Phase 9). */
    public function holidays(Request $request, array $params): never
    {
        Auth::require($request);

        $service = new HolidayService();
        $year    = $request->query('year');

        Response::success(
            $service->all($year !== null ? (int) $year : null),
            'Holidays retrieved successfully'
        );
    }

    /** GET /api/settings/archive - permanent-deletion inventory. */
    public function archiveSummary(Request $request, array $params): never
    {
        Auth::authorize('settings.manage');
        $items = [];

        foreach (self::ARCHIVES as $key => $definition) {
            $items[] = [
                'key' => $key,
                'label' => $definition['label'],
                'count' => (int) (Database::scalar(
                    "SELECT COUNT(*) FROM `{$definition['table']}` WHERE {$definition['where']}"
                ) ?? 0),
            ];
        }

        Response::success($items, 'Archived data summary retrieved successfully');
    }

    /** POST /api/settings/archive/purge - permanently remove one archive category. */
    public function purgeArchive(Request $request, array $params): never
    {
        Auth::authorize('settings.manage');
        $body = $request->body();
        $category = (string) ($body['category'] ?? '');

        if (!isset(self::ARCHIVES[$category])) {
            Response::validationError(['category' => 'Select a valid archive category.']);
        }
        if (($body['confirmation'] ?? '') !== 'DELETE') {
            Response::validationError(['confirmation' => 'Type DELETE to confirm permanent removal.']);
        }

        $definition = self::ARCHIVES[$category];
        try {
            $deleted = Database::transaction(static function () use ($definition): int {
                return Database::execute(
                    "DELETE FROM `{$definition['table']}` WHERE {$definition['where']}"
                );
            });
        } catch (Throwable $error) {
            Response::error(
                'These records are still linked to retained history and cannot be deleted yet.',
                409
            );
        }

        AuditLogger::record(
            AuditLogger::SETTINGS_CHANGED,
            'archived_data',
            null,
            sprintf('Permanently deleted %d archived %s record(s)', $deleted, $definition['label'])
        );

        Response::success(['deleted' => $deleted], 'Archived data permanently deleted');
    }

    /**
     * GET /api/settings/statutory - effective-dated SSS, PhilHealth, Pag-IBIG
     * and BIR schedules (Settings -> Contributions).
     */
    public function statutory(Request $request, array $params): never
    {
        Auth::authorize('settings.manage');

        Response::success(
            (new StatutoryDeductionService())->adminOverview(),
            'Statutory schedules retrieved successfully'
        );
    }

    /** PUT /api/settings/statutory/schedule/{id} - edit one schedule version. */
    public function updateStatutorySchedule(Request $request, array $params): never
    {
        Auth::authorize('settings.manage');

        try {
            $schedule = (new StatutoryDeductionService())->updateSchedule(
                (int) ($params['id'] ?? 0),
                $request->body(),
                Auth::id()
            );
        } catch (InvalidArgumentException $e) {
            Response::validationError(['schedule' => $e->getMessage()]);
        } catch (Throwable $e) {
            Response::error($e->getMessage(), 404);
        }

        Response::success($schedule, 'Statutory schedule updated successfully');
    }

    /** PUT /api/settings/statutory/bir-bracket/{id} - edit one tax bracket. */
    public function updateBirBracket(Request $request, array $params): never
    {
        Auth::authorize('settings.manage');

        try {
            $bracket = (new StatutoryDeductionService())->updateBirBracket(
                (int) ($params['id'] ?? 0),
                $request->body()
            );
        } catch (InvalidArgumentException $e) {
            Response::validationError(['bracket' => $e->getMessage()]);
        } catch (Throwable $e) {
            Response::error($e->getMessage(), 404);
        }

        Response::success($bracket, 'BIR withholding bracket updated successfully');
    }

    /**
     * POST /api/settings/statutory/versions - publish a new effective-dated
     * version by copying the current one (type = SSS | PHILHEALTH | PAGIBIG |
     * BIR | DAILY | WEEKLY | SEMI_MONTHLY | MONTHLY).
     */
    public function createStatutoryVersion(Request $request, array $params): never
    {
        Auth::authorize('settings.manage');

        $body = $request->body();

        try {
            $created = (new StatutoryDeductionService())->createVersion(
                (string) ($body['type'] ?? ''),
                (string) ($body['effective_from'] ?? ''),
                Auth::id()
            );
        } catch (InvalidArgumentException $e) {
            Response::validationError(['type' => $e->getMessage()]);
        } catch (Throwable $e) {
            Response::error($e->getMessage(), 422);
        }

        Response::created($created, 'New statutory schedule version published successfully');
    }

    private function positionList(mixed $departmentId, bool $archivedOnly = false): array
    {
        return (new EmployeeService())->positions(
            $departmentId !== null && $departmentId !== '' ? (int) $departmentId : null,
            $archivedOnly
        );
    }

    /** @return array{name: string, logo: string} */
    private function brandingValues(): array
    {
        $logo = Settings::string('company.logo', 'assets/system-logo.png');
        if (!preg_match('#^assets/(?:uploads/)?[a-zA-Z0-9._-]+$#', $logo)) {
            $logo = 'assets/system-logo.png';
        }

        return [
            'name' => Settings::string('company.name', 'Attendance & Payroll'),
            'logo' => $logo,
        ];
    }

    /** @return array<string, mixed> */
    private function managedSettings(): array
    {
        return array_filter(
            Settings::all(),
            fn (mixed $value, string $key): bool => $this->isManagedSetting($key) || $key === 'company.logo',
            ARRAY_FILTER_USE_BOTH
        );
    }

    private function isManagedSetting(string $key): bool
    {
        return $key !== 'company.logo'
            && $key !== 'security.token_lifetime_hours'
            && !str_starts_with($key, 'qr.');
    }
}

/**
 * Validate an Admin-supplied department base salary.
 *
 * Empty string / null clears the mapping (form then leaves Basic Salary
 * blank instead of inventing a value). Numeric values must be >= 0.
 *
 * @return float|null
 */
function parseDepartmentBaseSalary(mixed $value): float|null
{
    if ($value === null || $value === '') {
        return null;
    }
    if (!is_numeric($value) || (float) $value < 0) {
        Response::validationError(['base_salary' => 'Department basic salary must be a number 0 or greater.']);
    }
    return round((float) $value, 2);
}
