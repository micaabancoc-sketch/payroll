<?php
/**
 * Work schedule (Phase 8) and holiday (Phase 9) admin endpoints.
 */

declare(strict_types=1);

namespace App\Controllers;

use App\Core\Request;
use App\Core\Response;
use App\Services\ScheduleService;

final class ScheduleController
{
    public function __construct(private ScheduleService $schedules = new ScheduleService())
    {
    }

    /** GET /api/schedules */
    public function index(Request $request, array $params): never
    {
        $archived = strtolower(trim((string) $request->query('archived', ''))) === 'only';

        Response::success($this->schedules->all($archived), 'Work schedules retrieved successfully');
    }

    /** GET /api/schedules/{id} */
    public function show(Request $request, array $params): never
    {
        $schedule = $this->schedules->find((int) ($params['id'] ?? 0));

        if ($schedule === null) {
            Response::notFound('Work schedule not found.');
        }

        Response::success($schedule, 'Work schedule retrieved successfully');
    }

    /** POST /api/schedules — create (Phase 8). */
    public function store(Request $request, array $params): never
    {
        Response::created($this->schedules->save($request->body()), 'Work schedule created successfully');
    }

    /** PUT /api/schedules/{id} — update (Phase 8). */
    public function update(Request $request, array $params): never
    {
        Response::success(
            $this->schedules->save($request->body(), (int) ($params['id'] ?? 0)),
            'Work schedule updated successfully'
        );
    }

    /** GET /api/schedules/shifts */
    public function shifts(Request $request, array $params): never
    {
        $archived = strtolower(trim((string) $request->query('archived', ''))) === 'only';

        Response::success($this->schedules->shifts($archived), 'Shifts retrieved successfully');
    }
/** POST /api/schedules/shifts — create a shift (Phase 8). */
    public function storeShift(Request $request, array $params): never
    {
        Response::created($this->schedules->saveShift($request->body()), 'Shift created successfully');
    }

    /** PUT /api/schedules/shifts/{id} — update a shift (Phase 8). */
    public function updateShift(Request $request, array $params): never
    {
        Response::success(
            $this->schedules->saveShift($request->body(), (int) ($params['id'] ?? 0)),
            'Shift updated successfully'
        );
    }

    /** DELETE /api/schedules/{id} — archive a schedule */
    public function destroy(Request $request, array $params): never
    {
        try {
            $result = $this->schedules->delete((int) ($params['id'] ?? 0));
        } catch (\RuntimeException $e) {
            Response::error($e->getMessage(), 422, $e instanceof \App\Core\ValidationException ? $e->errors() : []);
        }

        Response::success($result, 'Work schedule deleted successfully');
    }

    /** DELETE /api/schedules/shifts/{id} — archive a shift */
    public function destroyShift(Request $request, array $params): never
    {
        try {
            $result = $this->schedules->deleteShift((int) ($params['id'] ?? 0));
        } catch (\RuntimeException $e) {
            Response::error($e->getMessage(), 422, $e instanceof \App\Core\ValidationException ? $e->errors() : []);
        }

        Response::success($result, 'Shift deleted successfully');
    }

    /** POST /api/schedules/{id}/restore — return an archived schedule to its list */
    public function restore(Request $request, array $params): never
    {
        try {
            $result = $this->schedules->restore((int) ($params['id'] ?? 0));
        } catch (\RuntimeException $e) {
            Response::error($e->getMessage(), 422, $e instanceof \App\Core\ValidationException ? $e->errors() : []);
        }

        Response::success($result, 'Work schedule restored successfully');
    }

    /** POST /api/schedules/shifts/{id}/restore — return an archived shift to its list */
    public function restoreShift(Request $request, array $params): never
    {
        try {
            $result = $this->schedules->restoreShift((int) ($params['id'] ?? 0));
        } catch (\RuntimeException $e) {
            Response::error($e->getMessage(), 422, $e instanceof \App\Core\ValidationException ? $e->errors() : []);
        }

        Response::success($result, 'Shift restored successfully');
    }

    /** POST /api/schedules/assign/{employeeId} — employee-specific schedule. */
    public function assign(Request $request, array $params): never
    {
        $scheduleId = $request->body('work_schedule_id');

        Response::success(
            $this->schedules->assignToEmployee(
                (int) ($params['employeeId'] ?? 0),
                $scheduleId === null || $scheduleId === '' ? null : (int) $scheduleId
            ),
            'Work schedule assigned successfully'
        );
    }
}