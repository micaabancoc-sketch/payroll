<?php
/**
 * Payroll endpoints (Phase 14) and payslips (Phase 15).
 */

declare(strict_types=1);

namespace App\Controllers;

use App\Core\Auth;
use App\Core\Request;
use App\Core\Response;
use App\Services\PayslipService;
use App\Services\PayrollService;
use RuntimeException;

final class PayrollController
{
    public function __construct(
        private PayrollService $payroll = new PayrollService(),
        private PayslipService $payslips = new PayslipService()
    ) {
    }

    /** GET /api/payroll/periods */
    public function periods(Request $request, array $params): never
    {
        Auth::require($request);

        // An employee sees no payroll administration, only their own payslips.
        if (!Auth::hasAnyPermission(['payroll.view', 'payroll.period.view'])) {
            Response::forbidden('Your role does not have access to payroll periods.');
        }

        $pagination = $request->pagination();
        $result = $this->payroll->listPeriods($request->query(), $pagination['page'], $pagination['per_page']);

        Response::paginated($result['items'], $result['total'], $pagination['page'], $pagination['per_page']);
    }

    /** GET /api/payroll/periods/{id} */
    public function period(Request $request, array $params): never
    {
        Auth::authorizeAny(['payroll.view', 'payroll.period.view']);

        $period = $this->payroll->findPeriod((int) ($params['id'] ?? 0));

        if ($period === null) {
            Response::notFound('Payroll period not found.');
        }

        Response::success($period, 'Payroll period retrieved successfully');
    }

    /** POST /api/payroll/periods — create a period (Phase 14). */
    public function createPeriod(Request $request, array $params): never
    {
        Auth::authorize('payroll.period.create');

        try {
            $period = $this->payroll->createPeriod($request->body());
        } catch (RuntimeException $e) {
            Response::error($e->getMessage(), 422, $e instanceof \App\Core\ValidationException ? $e->errors() : []);
        }

        Response::created($period, 'Payroll period created successfully');
    }
    /** GET: read-only employee preview, never a partial payroll release. */
    public function employeePreview(Request $request, array $params): never
    {
        Auth::authorize('payroll.calculate');
        $employeeId=filter_var($request->query('employee_id'), FILTER_VALIDATE_INT);
        if (!$employeeId) { Response::validationError(['employee_id'=>'Choose an employee.']); }
        try { $result=$this->payroll->previewEmployee((int)($params['id'] ?? 0),(int)$employeeId); }
        catch (RuntimeException $e) { Response::error($e->getMessage(),422); }
        Response::success($result);
    }

    /** GET /api/payroll/periods/{id}/attendance-exceptions — no writes. */
    public function attendanceExceptions(Request $request, array $params): never
    {
        Auth::authorize('payroll.calculate');
        if (Auth::roleCode() !== 'HR_PAYROLL') {
            Response::forbidden('Only HR/Payroll may inspect the payroll exception list.');
        }
        try { $result=$this->payroll->periodAttendanceExceptions((int)($params['id'] ?? 0)); }
        catch (RuntimeException $e) { Response::error($e->getMessage(),422); }
        Response::success($result);
    }

    /** POST /api/payroll/periods/{id}/calculate-employee (single DRAFT only). */
    public function calculateEmployee(Request $request, array $params): never
    {
        Auth::authorize('payroll.calculate');
        if (Auth::roleCode() !== 'HR_PAYROLL') {
            Response::forbidden('Only HR/Payroll can calculate employee payroll.');
        }
        $employeeId = filter_var($request->body('employee_id'), FILTER_VALIDATE_INT);
        if (!$employeeId || (int)$employeeId < 1) {
            Response::validationError(['employee_id'=>'Choose an employee.']);
        }
        try {
            $result=$this->payroll->calculateSingleEmployee((int)($params['id'] ?? 0),(int)$employeeId);
        } catch (RuntimeException $e) {
            Response::error($e->getMessage(),422);
        }
        Response::success($result,'Employee DRAFT payroll saved. This is not a finalized or paid payroll.');
    }

    /** POST /api/payroll/periods/{id}/attendance-exceptions/confirm-absence. */
    public function confirmMissingAbsence(Request $request, array $params): never
    {
        Auth::authorize('attendance.adjust');
        if (Auth::roleCode() !== 'HR_PAYROLL') {
            Response::forbidden('Only HR/Payroll may confirm a missing attendance day. Independent review is required for HR own records.');
        }
        $employeeId = filter_var($request->body('employee_id'), FILTER_VALIDATE_INT);
        if (!$employeeId || (int)$employeeId < 1) {
            Response::validationError(['employee_id'=>'Choose an employee.']);
        }
        try {
            $result = $this->payroll->confirmMissingAbsence(
                (int)($params['id'] ?? 0), (int)$employeeId,
                (string)$request->body('date', ''), (string)$request->body('reason', '')
            );
        } catch (RuntimeException $e) { Response::error($e->getMessage(), 422); }
        Response::success($result, 'Verified absence recorded. Recalculate All to refresh the draft.');
    }

/** POST /api/payroll/periods/{id}/calculate — run the engine (Phase 13/14). */
    public function calculate(Request $request, array $params): never
    {
        Auth::authorize('payroll.calculate');
        if (Auth::roleCode() !== 'HR_PAYROLL') {
            Response::forbidden('Only HR/Payroll may calculate a company payroll batch.');
        }

        try {
            $result = $this->payroll->calculate((int) ($params['id'] ?? 0));
        } catch (RuntimeException $e) {
            Response::error($e->getMessage(), 422);
        }

        Response::success($result, (string)($result['message'] ?? 'Payroll DRAFT calculation saved.'));
    }

    /** PUT /api/payroll/periods/{id} — edit a DRAFT period */
    public function updatePeriod(Request $request, array $params): never
    {
        Auth::authorize('payroll.period.create');

        try {
            $period = $this->payroll->updatePeriod((int) ($params['id'] ?? 0), $request->body());
        } catch (RuntimeException $e) {
            Response::error($e->getMessage(), 422, $e instanceof \App\Core\ValidationException ? $e->errors() : []);
        }

        Response::success($period, 'Payroll period updated successfully');
    }

    /** DELETE /api/payroll/periods/{id} — archive a DRAFT period (purge via Data deletion) */
    public function deletePeriod(Request $request, array $params): never
    {
        Auth::authorize('payroll.period.create');

        try {
            $result = $this->payroll->deletePeriod((int) ($params['id'] ?? 0));
        } catch (RuntimeException $e) {
            Response::error($e->getMessage(), 422);
        }

        Response::success($result, 'Payroll period deleted successfully');
    }

    /** POST /api/payroll/periods/{id}/restore — return an archived period to its list */
    public function restorePeriod(Request $request, array $params): never
    {
        Auth::authorize('payroll.period.create');

        try {
            $period = $this->payroll->restorePeriod((int) ($params['id'] ?? 0));
        } catch (RuntimeException $e) {
            Response::error($e->getMessage(), 422);
        }

        Response::success($period, 'Payroll period restored successfully');
    }

    /** POST /api/payroll/periods/{id}/transition — move through the workflow. */
    public function transition(Request $request, array $params): never
    {
        $status = strtoupper((string) $request->body('status', ''));

        // Each workflow step requires its own permission.
        $permission = match ($status) {
            'APPROVED'  => 'payroll.approve',
            'FINALIZED' => 'payroll.finalize',
            'PAID'      => 'payroll.mark_paid',
            default     => 'payroll.calculate',
        };

        Auth::authorize($permission);
        if ($status === 'APPROVED' && Auth::roleCode() !== 'HR_PAYROLL') {
            Response::forbidden('Only HR/Payroll can approve payroll.');
        }
        if (in_array($status, ['FINALIZED', 'PAID'], true) && Auth::roleCode() !== 'HR_PAYROLL') {
            Response::forbidden('Only HR/Payroll can finalize or record disbursement.');
        }

        try {
            $period = $this->payroll->transition((int) ($params['id'] ?? 0), $status);
        } catch (RuntimeException $e) {
            Response::error($e->getMessage(), 422);
        }

        Response::success($period, "Payroll period moved to {$status} successfully");
    }

    /** GET /api/payroll/periods/{id}/payroll — rows for the period. */
    public function periodPayroll(Request $request, array $params): never
    {
        Auth::authorizeAny(['payroll.view', 'payroll.period.view']);

        Response::success(
            $this->payroll->periodPayroll((int) ($params['id'] ?? 0)),
            'Payroll records retrieved successfully'
        );
    }
/** GET /api/payroll/payslips/{id} — a single payslip (Phase 15). */
    public function payslip(Request $request, array $params): never
    {
        Auth::require($request);

        $id = (int) ($params['id'] ?? 0);

        try {
            $this->payslips->assertCanView(
                $id,
                Auth::employeeId() ?? 0,
                Auth::hasAnyPermission(['payroll.view', 'payroll.payslip.view'])
            );

            $payslip = $this->payslips->render($id);
        } catch (RuntimeException $e) {
            Response::notFound($e->getMessage());
        }

        Response::success($payslip, 'Payslip retrieved successfully');
    }

    /** GET /api/payroll/payslips/employee/{employeeId} — payslip history. */
    public function payslipHistory(Request $request, array $params): never
    {
        Auth::require($request);

        $employeeId = (int) ($params['employeeId'] ?? 0);

        if (\App\Core\DemoStaffScope::isSystemOperator() && Auth::employeeId() === $employeeId) {
            Response::forbidden('HR/Manager are operators only; personal payslips are disabled for this demo.');
        }
        Auth::requireSelfOrPermission($employeeId, 'payroll.payslip.view');

        Response::success($this->payslips->history($employeeId, !Auth::hasAnyPermission(['payroll.view', 'payroll.payslip.view'])), 'Payslip history retrieved successfully');
    }

    /** GET /api/payroll/payslips/period/{periodId} — all payslips in a period. */
    public function payslipsForPeriod(Request $request, array $params): never
    {
        Auth::authorizeAny(['payroll.view', 'payroll.payslip.view']);

        Response::success(
            $this->payslips->forPeriod((int) ($params['periodId'] ?? 0)),
            'Payslips retrieved successfully'
        );
    }

    /** GET /api/payroll/settings — configurable rules (Phase 12). */
    public function settings(Request $request, array $params): never
    {
        Auth::require($request);

        Response::success(
            (new \App\Services\PayrollEngine())->settings(),
            'Payroll settings retrieved successfully'
        );
    }
}