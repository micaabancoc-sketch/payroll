<?php
/**
 * Application configuration: app, database, CORS, security, storage paths,
 * uploads and pagination defaults. Values may be overridden through
 * environment variables (see README, section 2.2).
 */

declare(strict_types=1);

if (!defined('APP_ROOT')) {
    define('APP_ROOT', dirname(__DIR__));
}
if (!defined('BASE_PATH')) {
    define('BASE_PATH', dirname(APP_ROOT));
}

return [
    'app' => [
        'name'        => 'Attendance & Payroll Management System',
        'version'     => '25.1-operators-only-demo-payroll-workflow',
        'env'         => getenv('APP_ENV') ?: 'development',   // development | production
        'debug'       => filter_var(getenv('APP_DEBUG') ?: 'true', FILTER_VALIDATE_BOOLEAN),
        'timezone'    => getenv('APP_TIMEZONE') ?: 'Asia/Manila',
        'date_format' => 'Y-m-d',
        'datetime_format' => 'Y-m-d H:i:s',
    ],

    // Defense test only. HR/Manager keep their accounts and historical employee data.
    // Isolated local defense TEST DATA ONLY. Never use simulated payroll disbursements in production.
    'demo' => [
        'staff_only' => true, // Only EMP-000001 may participate as employee.
        'enable_payroll_workflow' => true, // DEVELOPMENT ONLY: run demo review, approval, finalization and payment ledger.
        'excluded_usernames' => '', // V22: deprecated. Use employees.payroll_eligible instead.
    ],

    'database' => [
        'host'     => getenv('DB_HOST') ?: '127.0.0.1',
        'port'     => (int) (getenv('DB_PORT') ?: 3306),
        'name'     => getenv('DB_NAME') ?: 'attendance_payroll_v25_clean',
        'user'     => getenv('DB_USER') ?: 'root',
        'password' => getenv('DB_PASS') !== false ? getenv('DB_PASS') : '',
        'charset'  => 'utf8mb4',
    ],

    'cors' => [
        // Empty => reflect the request origin (development convenience).
        // In production set CORS_ALLOWED_ORIGINS to a comma-separated allow-list.
        'allowed_origins' => array_values(array_filter(array_map(
            'trim',
            explode(',', (string) (getenv('CORS_ALLOWED_ORIGINS') ?: '*'))
        ))),
        'allowed_methods' => ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS'],
        'allowed_headers' => ['Content-Type', 'Authorization', 'X-Requested-With', 'X-Device-Id'],
        'max_age'         => 3600,
    ],

    'security' => [
        // Salt pepper for token generation. CHANGE THIS in production.
        'token_pepper'  => getenv('APP_TOKEN_PEPPER') ?: 'change-this-pepper-in-production',
        'qr_pepper'     => getenv('APP_QR_PEPPER') ?: 'change-this-qr-pepper-in-production',
        'max_body_size' => 5 * 1024 * 1024, // 5 MB to accommodate multipart leave documents up to 2 MB
    ],

    'paths' => [
        'storage'      => BASE_PATH . '/storage',
        'qrcodes'      => BASE_PATH . '/storage/qrcodes',
        'uploads'      => BASE_PATH . '/storage/uploads',
        'logs'         => BASE_PATH . '/storage/logs',
    ],

    'uploads' => [
        'leave_dir'          => 'uploads/leave',
        'max_bytes'          => 2 * 1024 * 1024,
        'allowed_extensions' => ['jpg', 'jpeg', 'png', 'pdf'],
        'allowed_mime'       => ['image/jpeg', 'image/png', 'application/pdf'],
    ],

    'pagination' => [
        'default_per_page' => 25,
        'max_per_page'     => 200,
    ],
];