<?php
/**
 * Shared PDO connection factory (connection-pdo).
 *
 * Single place that builds the application's PDO instance: same DSN,
 * attributes and strict session mode everywhere. Usable standalone:
 *
 *   require 'api/config/connection-pdo.php';
 *   $pdo = pdo_connection(); // uses api/config/config.php credentials
 *
 * The `Database` class (`api/core/Database.php`) delegates its connection to
 * this factory, so every query in the system flows through it.
 */

declare(strict_types=1);

if (!function_exists('pdo_connection')) {
    /**
     * @param array{host:string,port:int,name:string,user:string,password:string,charset:string}|null $db
     */
    function pdo_connection(?array $db = null): PDO
    {
        static $pdo = null;

        if ($pdo instanceof PDO) {
            return $pdo;
        }

        if ($db === null) {
            $config = require __DIR__ . '/config.php';
            $db = $config['database'];
        }

        $dsn = sprintf(
            'mysql:host=%s;port=%d;dbname=%s;charset=%s',
            $db['host'],
            $db['port'],
            $db['name'],
            $db['charset']
        );

        $pdo = new PDO($dsn, $db['user'], $db['password'], [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
            PDO::ATTR_STRINGIFY_FETCHES  => false,
        ]);

        // Strict mode so silent data truncation can never happen.
        $pdo->exec("SET SESSION sql_mode='STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION'");

        return $pdo;
    }
}
