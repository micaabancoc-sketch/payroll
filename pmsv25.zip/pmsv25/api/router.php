<?php
/**
 * PHP built-in server router for the PMS API.
 * Every request that does not map to an existing file is forwarded to index.php
 * (the front controller), so the App\Core\Router can handle URI-based routing.
 */
$uri = urldecode(parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH));

// Serve existing files directly (e.g. static assets under the doc root).
if ($uri !== '/' && file_exists(__DIR__ . $uri)) {
    return false;
}

require __DIR__ . '/index.php';
