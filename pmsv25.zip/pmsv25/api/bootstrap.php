<?php
/**
 * API bootstrap: autoloading, error handling, CORS, logging (Phase 1).
 *
 * PHP is API-only here — no HTML is ever emitted by the backend.
 */

declare(strict_types=1);

use App\Core\Database;
use App\Core\Logger;
use App\Core\Request;
use App\Core\Response;
use App\Middleware\Cors;
use App\Middleware\RateLimiter;
use App\Middleware\SecurityHeaders;

define('API_START_TIME', microtime(true));

// ---------------------------------------------------------------------------
// Autoloader (PSR-4 style: App\Core\X => api/core/X.php) — shared with the CLI
// ---------------------------------------------------------------------------
require __DIR__ . '/autoload.php';

// ---------------------------------------------------------------------------
// Configuration / error handling
// ---------------------------------------------------------------------------
/** @var array<string, mixed> $config */
$config = require __DIR__ . '/config/config.php';

date_default_timezone_set((string) $config['app']['timezone']);
mb_internal_encoding('UTF-8');

ini_set('display_errors', $config['app']['debug'] ? '1' : '0');
ini_set('log_errors', '1');
error_reporting(E_ALL);

SecurityHeaders::apply();

set_error_handler(static function (int $severity, string $message, string $file = '', int $line = 0): bool {
    if ((error_reporting() & $severity) === 0) {
        return false;
    }
    throw new ErrorException($message, 0, $severity, $file, $line);
});

set_exception_handler(static function (Throwable $e) use ($config): void {
    // Validation failures are expected outcomes, not server errors.
    if ($e instanceof \App\Core\ValidationException) {
        Response::validationError($e->errors(), $e->getMessage());
    }

    Logger::exception($e, 'Unhandled exception');

    $isClientError = $e instanceof PDOException && str_contains($e->getMessage(), 'SQLSTATE');

    if ($config['app']['debug']) {
        Response::error('An unexpected error occurred', 500, [], [
            'exception' => get_class($e),
            'message'   => $e->getMessage(),
            'file'      => $e->getFile(),
            'line'      => $e->getLine(),
            'trace'     => explode("\n", $e->getTraceAsString()),
        ]);
    }

    Response::error(
        $isClientError ? 'A database error occurred' : 'An unexpected error occurred',
        500
    );
});

$request = new Request();
Cors::handle($request);

// ---------------------------------------------------------------------------
// Storage directories must exist and be writable (Phase 22)
// ---------------------------------------------------------------------------
foreach ([$config['paths']['storage'], $config['paths']['qrcodes'], $config['paths']['uploads'], $config['paths']['logs']] as $directory) {
    if (!is_dir($directory)) {
        @mkdir($directory, 0775, true);
    }
}
if (!is_writable($config['paths']['qrcodes'])) {
    Logger::error('QR storage directory is not writable', ['path' => $config['paths']['qrcodes']]);
}

// ---------------------------------------------------------------------------
// Global rate limiting
// ---------------------------------------------------------------------------
if ($request->method() !== 'OPTIONS') {
    RateLimiter::perIp($request, 'global');
}

// ---------------------------------------------------------------------------
// Dispatch
// ---------------------------------------------------------------------------
$router = new \App\Core\Router();
require __DIR__ . '/routes.php';

$router->dispatch($request, []);