<?php
/**
 * PSR-4 style autoloader: App\Core\X => api/core/X.php
 *
 * Shared by the HTTP bootstrap (api/bootstrap.php) and the CLI entry points
 * (api/cli/...) so every process resolves the same classes from one place.
 */

declare(strict_types=1);

spl_autoload_register(static function (string $class): void {
    $prefix = 'App\\';
    if (!str_starts_with($class, $prefix)) {
        return;
    }

    $relative = substr($class, strlen($prefix));
    $parts    = explode('\\', $relative);
    $file     = array_pop($parts);
    $subDir   = $parts === [] ? '' : strtolower(implode('/', $parts)) . '/';

    $path = __DIR__ . '/' . $subDir . strtolower($file) . '.php';
    if (is_file($path)) {
        require_once $path;
    }
});