<?php
/**
 * The whole route table — every endpoint with the permission it requires.
 */

declare(strict_types=1);

use App\Controllers\AttendanceController;
use App\Controllers\AuthController;
use App\Controllers\AuditController;
use App\Controllers\DashboardController;
use App\Controllers\EmployeeController;
use App\Controllers\HolidayController;
use App\Controllers\LeaveController;
use App\Controllers\LoanController;
use App\Controllers\OvertimeController;
use App\Controllers\PayrollController;
use App\Controllers\PayrollPaymentController;
use App\Controllers\QrController;
use App\Controllers\ReportController;
use App\Controllers\ScheduleController;
use App\Controllers\SettingsController;
use App\Controllers\StatutoryRemittanceController;
use App\Controllers\ThirteenthPayController;
use App\Controllers\RestDaySwapController;
use App\Controllers\PayrollAdjustmentController;
use App\Controllers\PayrollDeductionController;
use App\Controllers\UserController;

// ---------------------------------------------------------------------------
// Authentication (Phase 3) — manages its own access
// ---------------------------------------------------------------------------
$router->post('/api/auth/login', [AuthController::class, 'login']);
$router->post('/api/auth/logout', [AuthController::class, 'logout']);
$router->get('/api/auth/me', [AuthController::class, 'me']);
$router->put('/api/auth/profile', [AuthController::class, 'updateProfile']);
$router->post('/api/auth/change-password', [AuthController::class, 'changePassword']);

// Health check — no authentication required.
$router->get('/api/health', static function (): never {
    \App\Core\Response::success([
        'status'  => 'ok',
        'service' => 'attendance-payroll-api',
        'version' => \App\Core\Database::config()['app']['version'],
        'time'    => date('c'),
    ], 'API is running');
});
// ---------------------------------------------------------------------------
// Employees (Phase 4)
// ---------------------------------------------------------------------------
$router->get('/api/employees', [EmployeeController::class, 'index'], 'employees.view');
$router->post('/api/employees', [EmployeeController::class, 'store'], 'employees.create');
$router->get('/api/employees/options', [EmployeeController::class, 'options'], 'employees.view');
$router->get('/api/employees/{id}', [EmployeeController::class, 'show'], 'employees.view');
$router->put('/api/employees/{id}', [EmployeeController::class, 'update'], 'employees.update');
$router->get('/api/employees/{id}/profile', [EmployeeController::class, 'profile'], 'employees.view');
$router->get('/api/employees/{id}/salary-history', [EmployeeController::class, 'salaryHistory'], 'employees.view');
$router->get('/api/employees/{id}/leave-balances', [EmployeeController::class, 'leaveBalances'], 'employees.view');
// QR *reads* carry no route-level permission on purpose: a QR belongs to the
// employee who owns it, so every user must be able to reach their own. The
// per-employee check lives in the controller (Auth::requireSelfOrQrPermission),
// which allows your own QR unconditionally and anyone else's only for qr.view.
$router->get('/api/employees/{id}/qr', [EmployeeController::class, 'qr']);
$router->get('/api/employees/{id}/qr/history', [EmployeeController::class, 'qrHistory']);
$router->post('/api/employees/{id}/reset-password', [EmployeeController::class, 'resetPassword'], 'settings.manage');

// ---------------------------------------------------------------------------
// QR codes (Phase 5)
// ---------------------------------------------------------------------------
// Generating a QR code is an administrator-only action. Reading one is
// personal -- see the note on the employee QR routes above.
$router->post('/api/qr/issue/{employeeId}', [QrController::class, 'issue'], 'qr.generate');
$router->post('/api/qr/disable/{employeeId}', [QrController::class, 'disable'], 'qr.disable');
$router->get('/api/qr/active/{employeeId}', [QrController::class, 'active']);
$router->get('/api/qr/svg/{employeeId}', [QrController::class, 'svg']);
$router->get('/api/qr/history/{employeeId}', [QrController::class, 'history']);
// ---------------------------------------------------------------------------
// Attendance: scanner and scan preview require a dedicated authenticated KIOSK session
// ---------------------------------------------------------------------------
$router->post('/api/attendance/scan', [AttendanceController::class, 'scan'], 'attendance.scan');
// Resolves a QR badge without recording, for the authorized kiosk preview only.
$router->post('/api/attendance/scan/preview', [AttendanceController::class, 'scanPreview'], 'attendance.scan');
$router->get('/api/attendance', [AttendanceController::class, 'index'], 'attendance.view_own');
$router->get('/api/attendance/period-options', [AttendanceController::class, 'periodOptions'], 'attendance.view_own');
$router->get('/api/attendance/today', [AttendanceController::class, 'today'], 'dashboard.view');
$router->post('/api/attendance', [AttendanceController::class, 'store'], 'attendance.create');
$router->put('/api/attendance/{id}', [AttendanceController::class, 'update'], 'attendance.update');

// ---------------------------------------------------------------------------
// Work schedules & shifts (Phase 8)
// ---------------------------------------------------------------------------
$router->get('/api/schedules', [ScheduleController::class, 'index'], 'schedule.view');
$router->post('/api/schedules', [ScheduleController::class, 'store'], 'schedule.manage');
$router->get('/api/schedules/shifts', [ScheduleController::class, 'shifts'], 'schedule.view');
$router->post('/api/schedules/shifts', [ScheduleController::class, 'storeShift'], 'schedule.manage');
$router->get('/api/schedules/{id}', [ScheduleController::class, 'show'], 'schedule.view');
$router->put('/api/schedules/{id}', [ScheduleController::class, 'update'], 'schedule.manage');
$router->put('/api/schedules/shifts/{id}', [ScheduleController::class, 'updateShift'], 'schedule.manage');
$router->post('/api/schedules/assign/{employeeId}', [ScheduleController::class, 'assign'], 'schedule.manage');
// ---------------------------------------------------------------------------
// Holidays (Phase 9)
// ---------------------------------------------------------------------------
$router->get('/api/holidays', [HolidayController::class, 'index'], 'holiday.view');
$router->get('/api/holidays/upcoming', [HolidayController::class, 'upcoming'], 'dashboard.view');
$router->post('/api/holidays', [HolidayController::class, 'store'], 'holiday.manage');
$router->get('/api/holidays/{id}', [HolidayController::class, 'show'], 'holiday.view');
$router->put('/api/holidays/{id}', [HolidayController::class, 'update'], 'holiday.manage');
// ---------------------------------------------------------------------------
// Leave (Phase 10)
// ---------------------------------------------------------------------------
$router->get('/api/leave', [LeaveController::class, 'index'], 'leave.view_own');
$router->post('/api/leave', [LeaveController::class, 'store'], 'leave.create');
$router->post('/api/leave/attachment', [LeaveController::class, 'uploadAttachment'], 'leave.create');
$router->get('/api/leave/types', [LeaveController::class, 'types'], 'dashboard.view');
$router->get('/api/leave/working-days', [LeaveController::class, 'workingDays'], 'leave.view_own');
$router->get('/api/leave/calendar', [LeaveController::class, 'calendar'], 'leave.view_own');
$router->get('/api/leave/balance-summary', [LeaveController::class, 'balanceSummary'], 'leave.view');
$router->get('/api/leave/employee-balances', [LeaveController::class, 'employeeBalances'], 'leave.view_own');
$router->get('/api/leave/balances/{employeeId}', [LeaveController::class, 'balances'], 'leave.view_own');
$router->post('/api/leave/balances/adjust', [LeaveController::class, 'adjustBalance'], 'leave.approve');
$router->get('/api/leave/{id}', [LeaveController::class, 'show'], 'leave.view_own');
$router->put('/api/leave/{id}', [LeaveController::class, 'update'], 'leave.create');
$router->post('/api/leave/{id}/approve', [LeaveController::class, 'approve'], 'leave.approve');
$router->post('/api/leave/{id}/reject', [LeaveController::class, 'reject'], 'leave.approve');
$router->post('/api/leave/{id}/cancel', [LeaveController::class, 'cancel'], 'leave.view_own');

// ---------------------------------------------------------------------------
// Manager assigns OT; HR verifies/authorizes; Staff may view own assignment only.
// Only Manager holds overtime.create; only HR holds overtime.approve.
// ---------------------------------------------------------------------------
$router->get('/api/overtime', [OvertimeController::class, 'index'], 'overtime.view_own');
$router->post('/api/overtime', [OvertimeController::class, 'store'], 'overtime.create');
$router->get('/api/overtime/rates', [OvertimeController::class, 'rates'], 'dashboard.view');
$router->get('/api/overtime/tomorrow', [OvertimeController::class, 'tomorrow'], 'overtime.view_own');
$router->get('/api/overtime/{id}', [OvertimeController::class, 'show'], 'overtime.view_own');
$router->put('/api/overtime/{id}', [OvertimeController::class, 'update'], 'overtime.create');
$router->post('/api/overtime/{id}/approve', [OvertimeController::class, 'approve'], 'overtime.approve');
$router->post('/api/overtime/{id}/accept', [OvertimeController::class, 'accept'], 'overtime.view_own');
$router->post('/api/overtime/{id}/decline', [OvertimeController::class, 'decline'], 'overtime.view_own');
$router->post('/api/overtime/{id}/confirm-actual', [OvertimeController::class, 'confirmActual'], 'overtime.create');
$router->post('/api/overtime/{id}/verify-payroll', [OvertimeController::class, 'verifyPayroll'], 'overtime.approve');
$router->post('/api/overtime/{id}/reject', [OvertimeController::class, 'reject'], 'overtime.approve');
$router->post('/api/overtime/{id}/cancel', [OvertimeController::class, 'cancel'], 'overtime.create');
$router->get('/api/hr-reviewer/setup', [\App\Controllers\HrReviewerController::class, 'setup'], 'settings.manage');
$router->post('/api/hr-reviewer/assign', [\App\Controllers\HrReviewerController::class, 'assign'], 'settings.manage');
$router->get('/api/hr-reviewer/adjustments', [\App\Controllers\HrReviewerController::class, 'adjustments']);
$router->post('/api/hr-reviewer/adjustments/{id}/decision', [\App\Controllers\HrReviewerController::class, 'decision']);
// Company-authorized deductions are distinct from statutory/attendance deductions.
$router->get('/api/payroll/deduction-types', [PayrollDeductionController::class, 'types'], 'payroll.period.view');
$router->post('/api/payroll/deduction-types', [PayrollDeductionController::class, 'create'], 'payroll.calculate');
$router->put('/api/payroll/deduction-types/{id}', [PayrollDeductionController::class, 'toggle'], 'payroll.calculate');
$router->get('/api/payroll/deduction-assignments', [PayrollDeductionController::class, 'assignments'], 'payroll.period.view');
$router->post('/api/payroll/deduction-assignments', [PayrollDeductionController::class, 'assign'], 'payroll.calculate');
$router->put('/api/payroll/deduction-assignments/{id}/disable', [PayrollDeductionController::class, 'disable'], 'payroll.calculate');

// Documented payroll adjustments: HR creates/reviews with separation of duties; payslips
// include only approved items after HR recalculates an unlocked period.
$router->get('/api/payroll/adjustments', [PayrollAdjustmentController::class, 'index'], 'payroll.period.view');
$router->post('/api/payroll/adjustments', [PayrollAdjustmentController::class, 'create'], 'payroll.calculate');
$router->post('/api/payroll/adjustments/{id}/decision', [PayrollAdjustmentController::class, 'decision'], 'payroll.approve');

// ---------------------------------------------------------------------------
// Payroll & payslips (Phase 12-15)
// ---------------------------------------------------------------------------
$router->get('/api/payroll/periods', [PayrollController::class, 'periods'], 'payroll.period.view');
$router->post('/api/payroll/periods', [PayrollController::class, 'createPeriod'], 'payroll.period.create');
$router->get('/api/payroll/settings', [PayrollController::class, 'settings'], 'dashboard.view');
$router->get('/api/payroll/periods/{id}', [PayrollController::class, 'period'], 'payroll.period.view');
$router->put('/api/payroll/periods/{id}', [PayrollController::class, 'updatePeriod'], 'payroll.period.create');
$router->get('/api/payroll/periods/{id}/employee-preview', [PayrollController::class, 'employeePreview'], 'payroll.calculate');
$router->get('/api/payroll/periods/{id}/attendance-exceptions', [PayrollController::class, 'attendanceExceptions'], 'payroll.calculate');
$router->post('/api/payroll/periods/{id}/attendance-exceptions/confirm-absence', [PayrollController::class, 'confirmMissingAbsence'], 'attendance.adjust');
$router->post('/api/payroll/periods/{id}/calculate-employee', [PayrollController::class, 'calculateEmployee'], 'payroll.calculate');
$router->post('/api/payroll/periods/{id}/calculate', [PayrollController::class, 'calculate'], 'payroll.calculate');
$router->post('/api/payroll/periods/{id}/transition', [PayrollController::class, 'transition']);
$router->get('/api/payroll/periods/{id}/payroll', [PayrollController::class, 'periodPayroll'], 'payroll.period.view');
$router->get('/api/payroll/payslips/employee/{employeeId}', [PayrollController::class, 'payslipHistory'], 'payroll.payslip.view_own');
$router->get('/api/payroll/payslips/period/{periodId}', [PayrollController::class, 'payslipsForPeriod'], 'payroll.payslip.view');
$router->get('/api/payroll/payslips/{id}', [PayrollController::class, 'payslip'], 'payroll.payslip.view_own');

// Individual payroll payments & disbursement ledger (Phase 5).
// Reads accept the payroll view permissions so reviewers without the
// disbursement permission can still follow the money; writes require the
// dedicated payment permissions (route falls back to payroll.mark_paid for
// installs created before the Phase 5 migration granted the new keys).
// Kept separate from loan repayments (/api/loans) and 13th-month payments
// (/api/thirteenth-pay/payments): a salary disbursement never writes there.
$router->get('/api/payroll/payments/options', [PayrollPaymentController::class, 'options']);
$router->get('/api/payroll/periods/{id}/payments', [PayrollPaymentController::class, 'forPeriod'], 'payroll.period.view');
$router->get('/api/payroll/records/{id}/payments', [PayrollPaymentController::class, 'forPayroll'], 'payroll.period.view');
$router->post('/api/payroll/records/{id}/payments', [PayrollPaymentController::class, 'store']);
$router->post('/api/payroll/payments/{id}/complete', [PayrollPaymentController::class, 'complete']);
$router->post('/api/payroll/payments/{id}/fail', [PayrollPaymentController::class, 'fail']);
$router->post('/api/payroll/payments/{id}/cancel', [PayrollPaymentController::class, 'cancel']);

// ---------------------------------------------------------------------------
// 13th-Month Pay
// ---------------------------------------------------------------------------
// ---------------------------------------------------------------------------
// Employee loans & repayment ledger (Phase 3)
//
// Loans are managed by whoever holds the loan permissions; the payroll run
// writes the PAYROLL ledger rows itself, so there is no endpoint for those.
// A filed loan is PENDING and only an approver (loans.approve, and never the
// user who filed it) can move it into the payroll rotation (Phase 3B).
// ---------------------------------------------------------------------------
$router->get('/api/loans', [LoanController::class, 'index']);
$router->post('/api/loans', [LoanController::class, 'store'], 'loans.create');
$router->get('/api/loans/options', [LoanController::class, 'options']);
$router->get('/api/loans/summary', [LoanController::class, 'summary']);
$router->get('/api/loans/{id}', [LoanController::class, 'show']);
$router->put('/api/loans/{id}', [LoanController::class, 'update'], 'loans.update');
$router->get('/api/loans/{id}/payments', [LoanController::class, 'payments']);
$router->post('/api/loans/{id}/payments', [LoanController::class, 'pay'], 'loans.payment');
$router->post('/api/loans/{id}/offer', [LoanController::class, 'offer'], 'loans.approve');
$router->post('/api/loans/{id}/accept', [LoanController::class, 'accept'], 'loans.view_own');
$router->post('/api/loans/{id}/verify-agency', [LoanController::class, 'verifyAgency'], 'loans.approve');
$router->post('/api/loans/{id}/release', [LoanController::class, 'release'], 'loans.release');
$router->post('/api/loans/{id}/approve', [LoanController::class, 'approve'], 'loans.approve');
$router->post('/api/loans/{id}/reject', [LoanController::class, 'reject'], 'loans.approve');
$router->post('/api/loans/{id}/cancel', [LoanController::class, 'cancel'], 'loans.payment');
$router->get('/api/agency-loan-remittances', [\App\Controllers\AgencyLoanRemittanceController::class, 'index'], 'remittance.view');
$router->post('/api/agency-loan-remittances/{id}/remit', [\App\Controllers\AgencyLoanRemittanceController::class, 'markRemitted'], 'remittance.manage');

// ---------------------------------------------------------------------------
// 13th-Month Pay
// ---------------------------------------------------------------------------
$router->get('/api/thirteenth-pay', [ThirteenthPayController::class, 'index'], 'payroll.period.view');
$router->post('/api/thirteenth-pay/generate', [ThirteenthPayController::class, 'generate'], 'payroll.calculate');
$router->post('/api/thirteenth-pay/submit', [ThirteenthPayController::class, 'submit'], 'payroll.calculate');
$router->post('/api/thirteenth-pay/approve', [ThirteenthPayController::class, 'approve'], 'payroll.approve');
$router->post('/api/thirteenth-pay/release', [ThirteenthPayController::class, 'release'], 'payroll.mark_paid');
$router->get('/api/thirteenth-pay/unpaid', [ThirteenthPayController::class, 'unpaid'], 'payroll.period.view');
$router->post('/api/thirteenth-pay/payments', [ThirteenthPayController::class, 'pay'], 'payroll.mark_paid');

// ---------------------------------------------------------------------------
// Dashboard (Phase 16)
// ---------------------------------------------------------------------------
$router->get('/api/dashboard', [DashboardController::class, 'index'], 'dashboard.view');
$router->get('/api/dashboard/cards', [DashboardController::class, 'cards'], 'dashboard.view');
$router->get('/api/dashboard/charts', [DashboardController::class, 'charts'], 'dashboard.view');
$router->get('/api/dashboard/holidays', [DashboardController::class, 'holidays'], 'dashboard.view');
$router->get('/api/dashboard/activities', [DashboardController::class, 'activities'], 'audit.view');
// ---------------------------------------------------------------------------
// Reports (Phase 17)
// ---------------------------------------------------------------------------
$router->get('/api/reports/attendance/daily', [ReportController::class, 'attendanceDaily'], 'report.attendance');
$router->get('/api/reports/attendance/monthly', [ReportController::class, 'attendanceMonthly'], 'report.attendance');
$router->get('/api/reports/attendance/late', [ReportController::class, 'attendanceLate'], 'report.attendance');
$router->get('/api/reports/attendance/absent', [ReportController::class, 'attendanceAbsent'], 'report.attendance');
$router->get('/api/reports/attendance/undertime', [ReportController::class, 'attendanceUndertime'], 'report.attendance');
$router->get('/api/reports/attendance-leave-ledger', [ReportController::class, 'attendanceLeaveLedger'], 'report.attendance');
$router->get('/api/reports/attendance-leave-ledger/summary', [ReportController::class, 'attendanceLeaveLedgerSummary'], 'report.attendance');
$router->get('/api/reports/attendance/employee/{employeeId}', [ReportController::class, 'attendanceEmployee'], 'attendance.view_own');
$router->get('/api/reports/overtime', [ReportController::class, 'overtime'], 'report.attendance');
$router->get('/api/reports/leave/history', [ReportController::class, 'leaveHistory'], 'report.leave');
$router->get('/api/reports/leave/balance', [ReportController::class, 'leaveBalance'], 'report.leave');
$router->get('/api/reports/payroll/summary', [ReportController::class, 'payrollSummary'], 'report.payroll');
$router->get('/api/reports/payroll/employee', [ReportController::class, 'payrollEmployee'], 'report.payroll');
$router->get('/api/reports/payroll/department', [ReportController::class, 'payrollDepartment'], 'report.payroll');
$router->get('/api/reports/payroll/deductions', [ReportController::class, 'payrollDeductions'], 'report.payroll');
// ---------------------------------------------------------------------------
// Statutory reports & remittance tracking
// ---------------------------------------------------------------------------
$router->get('/api/reports/statutory/contributions', [ReportController::class, 'statutoryContributions'], 'report.statutory');
$router->get('/api/reports/statutory/remittances', [ReportController::class, 'statutoryRemittances'], 'report.statutory');
$router->get('/api/reports/statutory/summary', [ReportController::class, 'statutorySummary'], 'report.statutory');
$router->get('/api/statutory/remittances', [StatutoryRemittanceController::class, 'index'], 'remittance.view');
$router->post('/api/statutory/remittances/generate', [StatutoryRemittanceController::class, 'generate'], 'remittance.manage');
$router->get('/api/statutory/remittances/{id}', [StatutoryRemittanceController::class, 'show'], 'remittance.view');
$router->get('/api/statutory/remittances/{id}/items', [StatutoryRemittanceController::class, 'items'], 'remittance.view');
$router->post('/api/statutory/remittances/{id}/submit', [StatutoryRemittanceController::class, 'submit'], 'remittance.manage');
$router->post('/api/statutory/remittances/{id}/pay', [StatutoryRemittanceController::class, 'pay'], 'remittance.manage');
// ---------------------------------------------------------------------------
// Settings (Phase 19)
// ---------------------------------------------------------------------------
$router->get('/api/settings', [SettingsController::class, 'index'], 'settings.manage');
$router->put('/api/settings', [SettingsController::class, 'update'], 'settings.manage');
$router->post('/api/settings/logo', [SettingsController::class, 'uploadLogo'], 'settings.manage');
$router->get('/api/settings/branding', [SettingsController::class, 'branding']);
$router->get('/api/settings/company', [SettingsController::class, 'company'], 'dashboard.view');

// Values that any signed-in user may read (company name, currency, timezone).
$router->get('/api/settings/public', [SettingsController::class, 'publicSettings']);

$router->get('/api/settings/departments', [SettingsController::class, 'departments'], 'dashboard.view');
$router->post('/api/settings/departments', [SettingsController::class, 'createDepartment'], 'settings.manage');
$router->put('/api/settings/departments/{id}', [SettingsController::class, 'updateDepartment'], 'settings.manage');
$router->get('/api/settings/positions', [SettingsController::class, 'positions'], 'dashboard.view');
$router->post('/api/settings/positions', [SettingsController::class, 'createPosition'], 'settings.manage');
$router->put('/api/settings/positions/{id}', [SettingsController::class, 'updatePosition'], 'settings.manage');
$router->get('/api/settings/leave-types', [SettingsController::class, 'leaveTypes'], 'dashboard.view');
$router->post('/api/settings/leave-types', [SettingsController::class, 'createLeaveType'], 'settings.manage');
$router->put('/api/settings/leave-types/{id}', [SettingsController::class, 'updateLeaveType'], 'settings.manage');
$router->get('/api/settings/schedules', [SettingsController::class, 'schedules'], 'schedule.view');
$router->get('/api/settings/holidays', [SettingsController::class, 'holidays'], 'holiday.view');

// Government contributions & withholding tax schedules (Settings -> Contributions)
$router->get('/api/settings/statutory', [SettingsController::class, 'statutory'], 'settings.manage');
$router->put('/api/settings/statutory/schedule/{id}', [SettingsController::class, 'updateStatutorySchedule'], 'settings.manage');
$router->put('/api/settings/statutory/bir-bracket/{id}', [SettingsController::class, 'updateBirBracket'], 'settings.manage');
$router->post('/api/settings/statutory/versions', [SettingsController::class, 'createStatutoryVersion'], 'settings.manage');

// ---------------------------------------------------------------------------
// Users (Phase 3)
// ---------------------------------------------------------------------------
$router->get('/api/users', [UserController::class, 'index'], 'user.view');
$router->post('/api/users', [UserController::class, 'store'], 'settings.manage');
$router->post('/api/users/issue-missing-qrs', [UserController::class, 'issueMissingQrs'], 'settings.manage');
$router->get('/api/users/roles', [UserController::class, 'roles'], 'settings.manage');
$router->get('/api/roles/permissions', [UserController::class, 'permissionCatalog'], 'settings.manage');
$router->put('/api/users/{id}', [UserController::class, 'update'], 'user.view');
$router->post('/api/users/{id}/reset-password', [UserController::class, 'resetPassword'], 'settings.manage');

// ---------------------------------------------------------------------------
// Audit logs (Phase 18)
// ---------------------------------------------------------------------------
$router->get('/api/audit', [AuditController::class, 'index'], 'audit.view');
$router->get('/api/audit/actions', [AuditController::class, 'actions'], 'audit.view');

// ---------------------------------------------------------------------------
// Rest Day Swap / Exchange (rest-day-swap workflow)
// ---------------------------------------------------------------------------
$router->get('/api/rest-day-swaps', [RestDaySwapController::class, 'index'], 'rest_day_swap.view_own');
$router->get('/api/rest-day-swaps/{id}', [RestDaySwapController::class, 'show'], 'rest_day_swap.view_own');
$router->post('/api/rest-day-swaps', [RestDaySwapController::class, 'store'], 'rest_day_swap.create');
$router->post('/api/rest-day-swaps/{id}/respond', [RestDaySwapController::class, 'respond'], 'rest_day_swap.view_own');
$router->post('/api/rest-day-swaps/{id}/approve', [RestDaySwapController::class, 'approve'], 'rest_day_swap.approve');
$router->post('/api/rest-day-swaps/{id}/reject', [RestDaySwapController::class, 'reject'], 'rest_day_swap.approve');
$router->post('/api/rest-day-swaps/{id}/cancel', [RestDaySwapController::class, 'cancel'], 'rest_day_swap.view_own');
