<?php
/**
 * Middleware helpers (Phase 1 / Phase 20).
 */

declare(strict_types=1);

namespace App\Middleware;

use App\Core\Database;
use App\Core\Request;
use App\Core\Response;
use App\Core\Settings;

final class Cors
{
    public static function handle(Request $request): void
    {
        /** @var array<string, mixed> $config */
        $config = Database::config()['cors'];

        $origin  = $request->header('origin');
        $allowed = (array) $config['allowed_origins'];

        if ($origin !== null) {
            $isWildcard = in_array('*', $allowed, true);
            $isListed   = in_array($origin, $allowed, true);
            $reflect    = $isWildcard || $allowed === [];

            if ($reflect || $isListed) {
                header('Access-Control-Allow-Origin: ' . ($isListed ? $origin : $origin));
                header('Access-Control-Allow-Credentials: true');
                header('Vary: Origin');
            } else {
                // Not on the allow-list: no CORS headers => browser blocks it.
                return;
            }
        }

        header('Access-Control-Allow-Methods: ' . implode(', ', (array) $config['allowed_methods']));
        header('Access-Control-Allow-Headers: ' . implode(', ', (array) $config['allowed_headers']));
        header('Access-Control-Max-Age: ' . (int) $config['max_age']);
        header('Access-Control-Expose-Headers: X-Total-Count, Retry-After');

        if ($request->method() === 'OPTIONS') {
            http_response_code(204);
            exit;
        }
    }
}