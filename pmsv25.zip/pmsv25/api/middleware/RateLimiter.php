<?php
/**
 * Middleware helpers (Phase 1 / Phase 20).
 */

declare(strict_types=1);

namespace App\Middleware;

use App\Core\Database;
use App\Core\Logger;
use App\Core\Request;
use App\Core\Response;
use App\Core\Settings;

final class RateLimiter
{
    /**
     * Sliding-window limiter backed by MySQL so it works across PHP processes.
     *
     * @param int $maxHits  requests allowed per window
     * @param int $window   window length in seconds
     * @param int $blockFor seconds a blocked client stays blocked
     */
    public static function hit(string $bucket, int $maxHits, int $window = 60, int $blockFor = 300): void
    {
        // Local XAMPP development only: avoid a shared-IP 429 lockout while testing.
        // Check the actual peer address (never trust X-Forwarded-For here) AND the
        // local hostname so that remote / production requests remain protected.
        if (self::isLocalDevelopmentRequest()) {
            return;
        }

        $key = substr($bucket, 0, 190);

        $row = Database::selectOne(
            'SELECT id, hits, window_start, blocked_until FROM rate_limits WHERE bucket_key = :key',
            ['key' => $key]
        );

        $now = time();

        if ($row !== null) {
            $windowStart = strtotime((string) $row['window_start']) ?: $now;

            if ($row['blocked_until'] !== null && strtotime((string) $row['blocked_until']) > $now) {
                $retryAfter = strtotime((string) $row['blocked_until']) - $now;
                Logger::warning('Rate limit blocked', ['bucket' => $bucket, 'retry_after' => $retryAfter]);
                Response::tooManyRequests('Too many requests. Please try again shortly.', $retryAfter);
            }

            if (($now - $windowStart) >= $window) {
                Database::update('rate_limits', [
                    'hits'         => 1,
                    'window_start' => date('Y-m-d H:i:s', $now),
                ], ['id' => (int) $row['id']]);
                return;
            }

            $hits = (int) $row['hits'] + 1;
            $data = ['hits' => $hits];

            if ($hits > $maxHits) {
                $data['blocked_until'] = date('Y-m-d H:i:s', $now + $blockFor);
            }

            Database::update('rate_limits', $data, ['id' => (int) $row['id']]);

            if ($hits > $maxHits) {
                header('Retry-After: ' . $blockFor);
                Response::tooManyRequests('Too many requests. Please try again shortly.', $blockFor);
            }

            return;
        }

        Database::insert('rate_limits', [
            'bucket_key'   => $key,
            'hits'         => 1,
            'window_start' => date('Y-m-d H:i:s', $now),
        ]);
    }

    /**
     * Do not throttle requests made *from this computer to localhost* while
     * APP_ENV=development. Production and LAN clients keep all rate limits.
     */
    private static function isLocalDevelopmentRequest(): bool
    {
        $env = strtolower(trim((string) (getenv('APP_ENV') ?: 'development')));
        if ($env !== 'development') {
            return false;
        }

        $clientIp = (string) ($_SERVER['REMOTE_ADDR'] ?? '');
        if (!in_array($clientIp, ['127.0.0.1', '::1'], true)) {
            return false;
        }

        $host = strtolower((string) ($_SERVER['HTTP_HOST'] ?? ''));
        $hostName = strtolower((string) (parse_url('http://' . $host, PHP_URL_HOST) ?: ''));
        return in_array(trim($hostName, '[]'), ['localhost', '127.0.0.1', '::1'], true);
    }

    /** Convenience: per-IP limit driven by the security settings. */
    public static function perIp(Request $request, string $scope): void
    {
        $limit = (int) Settings::get('security.rate_limit_per_minute', 120);
        self::hit('ip:' . $scope . ':' . $request->ip(), $limit > 0 ? $limit : 120, 60, 300);
    }
}