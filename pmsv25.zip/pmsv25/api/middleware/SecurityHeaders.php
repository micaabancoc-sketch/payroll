<?php
/**
 * Middleware helpers (Phase 1 / Phase 20).
 */

declare(strict_types=1);

namespace App\Middleware;

use App\Core\Database;
use App\Core\Request;
use App\Core\Response;
use App\Core\Settings;

final class SecurityHeaders
{
    public static function apply(): void
    {
        if (headers_sent()) {
            return;
        }

        header('X-Content-Type-Options: nosniff');
        header('X-Frame-Options: DENY');
        header('Referrer-Policy: no-referrer');
        header('Permissions-Policy: geolocation=(), microphone=(), camera=(self)');
        header('Cross-Origin-Resource-Policy: same-site');

        // The API only ever returns JSON; nothing should be cached by intermediaries.
        header('Cache-Control: no-store, no-cache, must-revalidate');
    }
}