<?php
/**
 * Front controller — every API request enters here.
 * Serves http://localhost/pms/api/... with the frontend completely separated.
 */

declare(strict_types=1);

require __DIR__ . '/bootstrap.php';
