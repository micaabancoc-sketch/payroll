<?php
/**
 * Server-side input validation (Phase 20).
 *
 * All important operations are validated here, never only in JavaScript.
 */

declare(strict_types=1);

namespace App\Core;

final class Validator
{
    /** @var array<string, string> */
    private array $errors = [];
    /** @var array<string, mixed> */
    private array $validated = [];

    /**
     * @param array<string, mixed>  $data
     * @param array<string, string> $rules   field => "required|string|max:150"
     * @param array<string, string> $labels
     */
    public function __construct(
        private array $data,
        private array $rules,
        private array $labels = []
    ) {
        $this->run();
    }

    /** @param array<string, string> $rules */
    public static function make(array $data, array $rules, array $labels = []): self
    {
        return new self($data, $rules, $labels);
    }

    public function passes(): bool
    {
        return $this->errors === [];
    }

    public function fails(): bool
    {
        return $this->errors !== [];
    }

    /** @return array<string, string> */
    public function errors(): array
    {
        return $this->errors;
    }

    /** @return array<string, mixed> */
    public function validated(): array
    {
        return $this->validated;
    }

    private function run(): void
    {
        foreach ($this->rules as $field => $ruleString) {
            $value = $this->data[$field] ?? null;
            $rules = explode('|', $ruleString);
            // Rule names declared for this field (e.g. `string` vs `numeric`),
            // so min/max can use length semantics for string fields even when
            // the value looks numeric (contact numbers like "09970923320").
            $ruleNames = array_map(
                static fn (string $r): string => explode(':', $r, 2)[0],
                $rules
            );

            if (in_array('required', $rules, true)
                && ($value === null || $value === '' || (is_array($value) && $value === []))
            ) {
                $this->addError($field, 'is required');
                continue;
            }

            if ($value === null || $value === '') {
                $this->validated[$field] = $value;
                continue;
            }

            foreach ($rules as $rule) {
                if ($rule === '' || $rule === 'required' || $rule === 'nullable') {
                    continue;
                }
                if (!$this->applyRule($field, $value, $rule, $ruleNames)) {
                    break;
                }
            }

            $this->validated[$field] = $value;
        }
    }

    private function applyRule(string $field, mixed $value, string $rule, array $fieldRules = []): bool
    {
        [$name, $parameter] = array_pad(explode(':', $rule, 2), 2, null);

        // String-declared fields (without numeric/integer) measure min/max by
        // length: contact numbers are strings, so "09970923320" must not be
        // compared numerically against 30.
        $measuresLength = in_array('string', $fieldRules, true)
            && !in_array('numeric', $fieldRules, true)
            && !in_array('integer', $fieldRules, true);

        switch ($name) {
            case 'string':
                if (!is_string($value)) {
                    return $this->addError($field, 'must be a string');
                }
                break;

            case 'integer':
                if (filter_var($value, FILTER_VALIDATE_INT) === false) {
                    return $this->addError($field, 'must be an integer');
                }
                $this->validated[$field] = (int) $value;
                break;

            case 'numeric':
                if (!is_numeric($value)) {
                    return $this->addError($field, 'must be a number');
                }
                break;

            case 'boolean':
                $bool = filter_var($value, FILTER_VALIDATE_BOOLEAN, FILTER_NULL_ON_FAILURE);
                if ($bool === null) {
                    return $this->addError($field, 'must be a boolean');
                }
                $this->validated[$field] = $bool ? 1 : 0;
                break;

            case 'date':
                if (!self::isValidDate((string) $value)) {
                    return $this->addError($field, 'must be a valid date (Y-m-d)');
                }
                break;

            case 'time':
                if (!preg_match('/^\d{2}:\d{2}(:\d{2})?$/', (string) $value)) {
                    return $this->addError($field, 'must be a valid time (HH:MM or HH:MM:SS)');
                }
                break;

            case 'email':
                if (!filter_var((string) $value, FILTER_VALIDATE_EMAIL)) {
                    return $this->addError($field, 'must be a valid email address');
                }
                break;

            case 'min':
                if (!$measuresLength && is_numeric($value) && is_numeric($parameter)) {
                    if ((float) $value < (float) $parameter) {
                        return $this->addError($field, "must be at least {$parameter}");
                    }
                } elseif (self::length((string) $value) < (int) $parameter) {
                    return $this->addError($field, "must be at least {$parameter} characters");
                }
                break;

            case 'max':
                if (!$measuresLength && is_numeric($value) && is_numeric($parameter)) {
                    if ((float) $value > (float) $parameter) {
                        return $this->addError($field, "must not exceed {$parameter}");
                    }
                } elseif (self::length((string) $value) > (int) $parameter) {
                    return $this->addError($field, "must not exceed {$parameter} characters");
                }
                break;

            case 'in':
                $allowed = explode(',', (string) $parameter);
                if (!in_array((string) $value, $allowed, true)) {
                    return $this->addError($field, 'must be one of: ' . implode(', ', $allowed));
                }
                break;

            case 'regex':
                if (!preg_match((string) $parameter, (string) $value)) {
                    return $this->addError($field, 'has an invalid format');
                }
                break;

            case 'array':
                if (!is_array($value)) {
                    return $this->addError($field, 'must be a list');
                }
                break;

            case 'same':
                if ((string) $value !== (string) ($this->data[$parameter] ?? '')) {
                    return $this->addError($field, "must match {$parameter}");
                }
                break;

            case 'different':
                if ((string) $value === (string) ($this->data[$parameter] ?? '')) {
                    return $this->addError($field, "must be different from {$parameter}");
                }
                break;

            case 'alpha':
                if (!preg_match('/^[a-zA-Z\s\-\.\']+$/', (string) $value)) {
                    return $this->addError($field, 'may only contain letters, spaces, hyphens and apostrophes');
                }
                break;

            case 'alphanumeric':
                if (!preg_match('/^[a-zA-Z0-9_\-]+$/', (string) $value)) {
                    return $this->addError($field, 'may only contain letters, numbers, hyphens and underscores');
                }
                break;

            case 'after_or_equal':
                $other = (string) ($this->data[$parameter] ?? '');
                if ($other !== '' && (string) $value < $other) {
                    return $this->addError($field, "must be on or after {$parameter}");
                }
                break;

            case 'before_or_equal':
                $other = (string) ($this->data[$parameter] ?? '');
                if ($other !== '' && (string) $value > $other) {
                    return $this->addError($field, "must be on or before {$parameter}");
                }
                break;
        }

        return true;
    }

    private function addError(string $field, string $message): bool
    {
        $label = $this->labels[$field] ?? ucwords(str_replace('_', ' ', $field));
        $this->errors[$field] = "The {$label} {$message}.";
        return false;
    }

    private static function isValidDate(string $value): bool
    {
        $date = \DateTime::createFromFormat('Y-m-d', $value);
        return $date !== false && $date->format('Y-m-d') === $value;
    }

    /**
     * Character length for min/max rules.
     *
     * Uses mb_strlen() when the mbstring extension is available, otherwise
     * falls back to strlen(). Only Validator.php is changed; the min/max
     * length semantics (contact numbers stay strings, max:30 = 30 chars)
     * are untouched. Global qualification (\mb_strlen) avoids the previous
     * App\Core\mb_strlen() resolution failure.
     */
    private static function length(string $value): int
    {
        return \function_exists('mb_strlen') ? \mb_strlen($value) : \strlen($value);
    }
}