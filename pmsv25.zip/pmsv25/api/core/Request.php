<?php
/**
 * Sanitised view of the incoming HTTP request (Phase 1 / Phase 20).
 */

declare(strict_types=1);

namespace App\Core;

final class Request
{
    private string $method;
    private string $path;
    /** @var array<string, mixed> */
    private array $query;
    /** @var array<string, mixed> */
    private array $body;
    /** @var array<string, mixed> */
    private array $files;
    /** @var array<string, string> */
    private array $headers;

    public function __construct()
    {
        $this->method  = strtoupper($_SERVER['REQUEST_METHOD'] ?? 'GET');
        $this->path    = self::resolvePath();
        $this->query   = $_GET;
        $this->body    = self::parseBody();
        $this->files   = $_FILES;
        $this->headers = self::collectHeaders();
    }

    /**
     * The request path, relative to the project root.
     *
     * Routes are registered as '/api/...', so the project's own base path has
     * to come off first. Without this the API only answers when it is deployed
     * at a domain root; at http://localhost/pms/api/health the router would be
     * handed '/pms/api/health' and match nothing.
     *
     * The base is derived from where this script actually lives:
     *   /pms/api/index.php  ->  base /pms   ->  /pms/api/health  =>  /api/health
     *   /api/index.php      ->  base /      ->  /api/health      =>  /api/health
     */
    private static function resolvePath(): string
    {
        $uri  = $_SERVER['REQUEST_URI'] ?? '/';
        $path = parse_url($uri, PHP_URL_PATH) ?: '/';

        $script = str_replace('\\', '/', $_SERVER['SCRIPT_NAME'] ?? '');

        if ($script !== '') {
            // Step up out of the api folder, then take that folder's parent.
            $apiDirectory = rtrim(str_replace('\\', '/', dirname($script)), '/');
            $base         = rtrim(str_replace('\\', '/', dirname($apiDirectory)), '/');

            if ($base !== '' && str_starts_with($path, $base . '/')) {
                $path = substr($path, strlen($base));
            } elseif ($base !== '' && $path === $base) {
                $path = '/';
            }
        }

        return '/' . trim($path, '/');
    }

    public function method(): string
    {
        return $this->method;
    }

    public function path(): string
    {
        return $this->path;
    }

    /** @return array<string, mixed> */
    public function query(?string $key = null, mixed $default = null): mixed
    {
        if ($key === null) {
            return $this->query;
        }
        return $this->query[$key] ?? $default;
    }

    /** @return array<string, mixed> */
    public function body(?string $key = null, mixed $default = null): mixed
    {
        if ($key === null) {
            return $this->body;
        }
        return $this->body[$key] ?? $default;
    }

    /** @return array<string, mixed> */
    public function files(): array
    {
        return $this->files;
    }

    public function header(string $name, ?string $default = null): ?string
    {
        return $this->headers[strtolower($name)] ?? $default;
    }

    /** @return array<string, string> */
    public function headers(): array
    {
        return $this->headers;
    }

    public function bearerToken(): ?string
    {
        $header = $this->header('authorization');
        if ($header !== null && preg_match('/^Bearer\s+(\S+)$/i', $header, $m) === 1) {
            return $m[1];
        }
        // Fallback for the scanner kiosk which cannot set custom headers.
        $token = $this->query('token');
        return is_string($token) && $token !== '' ? $token : null;
    }

    public function ip(): string
    {
        // Only trust X-Forwarded-For when explicitly configured behind a proxy.
        if (filter_var(getenv('TRUST_PROXY') ?: 'false', FILTER_VALIDATE_BOOLEAN)) {
            $forwarded = $this->header('x-forwarded-for');
            if ($forwarded !== null) {
                $first = trim(explode(',', $forwarded)[0]);
                if (filter_var($first, FILTER_VALIDATE_IP)) {
                    return $first;
                }
            }
        }
        $ip = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
        return is_string($ip) ? $ip : '0.0.0.0';
    }

    public function userAgent(): string
    {
        return substr($this->header('user-agent') ?? 'unknown', 0, 255);
    }

    public function isJson(): bool
    {
        return str_contains(strtolower($this->header('content-type', '') ?? ''), 'application/json');
    }

    public function wantsJson(): bool
    {
        return $this->isJson()
            || str_contains(strtolower($this->header('accept', '') ?? ''), 'application/json');
    }

    /**
     * Pagination values clamped to configured limits.
     *
     * @return array{page: int, per_page: int, offset: int}
     */
    public function pagination(): array
    {
        $config = Database::config()['pagination'];

        $page    = max(1, (int) ($this->query('page', 1) ?: 1));
        $perPage = (int) ($this->query('per_page', $config['default_per_page']) ?: $config['default_per_page']);
        $perPage = max(1, min($perPage, (int) $config['max_per_page']));

        return [
            'page'     => $page,
            'per_page' => $perPage,
            'offset'   => ($page - 1) * $perPage,
        ];
    }

    /**
     * @return array<string, mixed>
     */
    private static function parseBody(): array
    {
        $contentType = strtolower($_SERVER['CONTENT_TYPE'] ?? '');

        if (str_contains($contentType, 'application/json')) {
            $raw = file_get_contents('php://input');
            if ($raw === false || trim($raw) === '') {
                return [];
            }
            $decoded = json_decode($raw, true);
            return is_array($decoded) ? $decoded : [];
        }

        if (str_contains($contentType, 'multipart/form-data')) {
            return $_POST;
        }

        // application/x-www-form-urlencoded and fallback
        $raw = file_get_contents('php://input');
        if ($raw !== false && trim($raw) !== '' && str_contains($contentType, 'x-www-form-urlencoded')) {
            parse_str($raw, $parsed);
            return $parsed;
        }

        return $_POST;
    }

    /**
     * @return array<string, string>
     */
    private static function collectHeaders(): array
    {
        $headers = [];

        if (function_exists('getallheaders')) {
            foreach (getallheaders() as $name => $value) {
                $headers[strtolower((string) $name)] = (string) $value;
            }
        }

        foreach ($_SERVER as $key => $value) {
            if (str_starts_with((string) $key, 'HTTP_')) {
                $name = strtolower(str_replace('_', '-', substr((string) $key, 5)));
                $headers[$name] ??= (string) $value;
            }
        }

        if (isset($_SERVER['CONTENT_TYPE'])) {
            $headers['content-type'] = (string) $_SERVER['CONTENT_TYPE'];
        }

        return $headers;
    }
}