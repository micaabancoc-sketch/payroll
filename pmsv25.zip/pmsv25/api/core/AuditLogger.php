<?php
/**
 * Audit trail for every important action (Phase 18).
 *
 * Old/new values are stored as JSON so a salary change or attendance
 * adjustment can always be reconstructed.
 */

declare(strict_types=1);

namespace App\Core;

final class AuditLogger
{
    public const LOGIN              = 'LOGIN';
    public const LOGIN_FAILED       = 'LOGIN_FAILED';
    public const LOGOUT             = 'LOGOUT';
    public const PASSWORD_CHANGED   = 'PASSWORD_CHANGED';
    public const EMPLOYEE_CREATED   = 'EMPLOYEE_CREATED';
    public const EMPLOYEE_UPDATED   = 'EMPLOYEE_UPDATED';
    public const EMPLOYEE_ARCHIVED  = 'EMPLOYEE_ARCHIVED';
    public const EMPLOYEE_RESTORED  = 'EMPLOYEE_RESTORED';
    public const EMPLOYEE_DELETED   = 'EMPLOYEE_DELETED';
    public const SALARY_CHANGED     = 'SALARY_CHANGED';
    public const QR_GENERATED       = 'QR_GENERATED';
    public const QR_REGENERATED     = 'QR_REGENERATED';
    public const QR_DISABLED        = 'QR_DISABLED';
    public const ATTENDANCE_SCAN    = 'ATTENDANCE_SCAN';
    public const ATTENDANCE_OVERRIDE = 'ATTENDANCE_OVERRIDE';
    public const ATTENDANCE_CREATE  = 'ATTENDANCE_CREATED';
    public const ATTENDANCE_UPDATE  = 'ATTENDANCE_UPDATED';
    public const ATTENDANCE_DELETE  = 'ATTENDANCE_DELETED';
    public const ATTENDANCE_ADJUST  = 'ATTENDANCE_ADJUSTED';
    public const LEAVE_CREATED      = 'LEAVE_CREATED';
    public const LEAVE_APPROVED     = 'LEAVE_APPROVED';
    public const LEAVE_REJECTED     = 'LEAVE_REJECTED';
    public const LEAVE_CANCELLED    = 'LEAVE_CANCELLED';
    public const OVERTIME_CREATED   = 'OVERTIME_CREATED';
    public const OVERTIME_APPROVED  = 'OVERTIME_APPROVED';
    public const OVERTIME_REJECTED  = 'OVERTIME_REJECTED';
    public const OVERTIME_CANCELLED = 'OVERTIME_CANCELLED';
    public const OVERTIME_COMPLETED = 'OVERTIME_COMPLETED';
    public const OVERTIME_ACCEPTED  = 'OVERTIME_ACCEPTED';
    public const OVERTIME_DECLINED  = 'OVERTIME_DECLINED';
    public const OVERTIME_ASSIGNED  = 'OVERTIME_ASSIGNED';
    public const PAYROLL_CALCULATED = 'PAYROLL_CALCULATED';
    public const PAYROLL_APPROVED   = 'PAYROLL_APPROVED';
    public const PAYROLL_FINALIZED  = 'PAYROLL_FINALIZED';
    public const PAYROLL_PAID       = 'PAYROLL_PAID';
    public const PAYROLL_PAYMENT_RECORDED  = 'PAYROLL_PAYMENT_RECORDED';
    public const PAYROLL_PAYMENT_COMPLETED = 'PAYROLL_PAYMENT_COMPLETED';
    public const PAYROLL_PAYMENT_FAILED    = 'PAYROLL_PAYMENT_FAILED';
    public const PAYROLL_PAYMENT_CANCELLED = 'PAYROLL_PAYMENT_CANCELLED';
    public const USER_CHANGED       = 'USER_CHANGED';
    public const SETTINGS_CHANGED   = 'SETTINGS_CHANGED';
    public const SCHEDULE_CHANGED   = 'SCHEDULE_CHANGED';
    public const HOLIDAY_CHANGED    = 'HOLIDAY_CHANGED';
    public const STATUTORY_SCHEDULE_CHANGED = 'STATUTORY_SCHEDULE_CHANGED';
    public const LOAN_CREATED       = 'LOAN_CREATED';
    public const LOAN_UPDATED       = 'LOAN_UPDATED';
    public const LOAN_PAYMENT       = 'LOAN_PAYMENT';
    public const LOAN_CANCELLED     = 'LOAN_CANCELLED';
    public const LOAN_RESTORED      = 'LOAN_RESTORED';
    public const LOAN_APPROVED      = 'LOAN_APPROVED';
    public const LOAN_REJECTED      = 'LOAN_REJECTED';
    public const STATUTORY_REMITTANCE_GENERATED = 'STATUTORY_REMITTANCE_GENERATED';
    public const STATUTORY_REMITTANCE_SUBMITTED = 'STATUTORY_REMITTANCE_SUBMITTED';
    public const STATUTORY_REMITTANCE_PAID      = 'STATUTORY_REMITTANCE_PAID';
    public const REST_DAY_SWAP_CREATED   = 'REST_DAY_SWAP_CREATED';
    public const REST_DAY_SWAP_RESPONDED = 'REST_DAY_SWAP_RESPONDED';
    public const REST_DAY_SWAP_APPROVED  = 'REST_DAY_SWAP_APPROVED';
    public const REST_DAY_SWAP_REJECTED  = 'REST_DAY_SWAP_REJECTED';
    public const REST_DAY_SWAP_CANCELLED = 'REST_DAY_SWAP_CANCELLED';

    /**
     * The `user_agent` value database/seed_audit_logs.php stamps on every
     * sample row it writes.
     *
     * It is the only thing separating seeded demo activity from genuine
     * history, so it lives here, beside the actions those rows imitate: the
     * seeder and the pages that read this table both resolve the marker from
     * this constant instead of keeping their own copy of the string.
     */
    public const SAMPLE_USER_AGENT = 'PMS-SEED/1.0';

    /**
     * Replace the raw user-agent column with a flag the frontend can badge on.
     *
     * `user_agent` doubles as the sample-data marker, but it is also a
     * browser/OS fingerprint the pages have no use for, so it is dropped and
     * only `is_sample` travels to the client. Anything a real request wrote
     * comes back as `false`.
     *
     * @param list<array<string, mixed>> $rows rows selected with a `user_agent` column
     * @return list<array<string, mixed>>
     */
    public static function flagSampleRows(array $rows): array
    {
        foreach ($rows as &$row) {
            $row['is_sample'] = ($row['user_agent'] ?? null) === self::SAMPLE_USER_AGENT;
            unset($row['user_agent']);
        }
        unset($row);

        return $rows;
    }

    /**
     * @param array<string, mixed>|null $oldValue
     * @param array<string, mixed>|null $newValue
     */
    public static function record(
        string $action,
        ?string $entityType = null,
        int|string|null $entityId = null,
        string $description = '',
        ?array $oldValue = null,
        ?array $newValue = null,
        ?Request $request = null
    ): void {
        try {
            $request = $request ?? new Request();

            Database::insert('audit_logs', [
                'user_id'     => Auth::id(),
                'username'    => Auth::user()['username'] ?? 'system',
                'action'      => $action,
                'entity_type' => $entityType,
                'entity_id'   => $entityId === null ? null : (string) $entityId,
                'description' => mb_substr($description, 0, 500),
                'old_value'   => $oldValue === null ? null : self::encode($oldValue),
                'new_value'   => $newValue === null ? null : self::encode($newValue),
                'ip_address'  => $request->ip(),
                'user_agent'  => $request->userAgent(),
            ]);
        } catch (\Throwable $e) {
            // Auditing must never break the business operation.
            Logger::error('Failed to write audit log', [
                'action' => $action,
                'error'  => $e->getMessage(),
            ]);
        }
    }

    /**
     * Record only the fields that actually changed, so the log stays readable.
     *
     * @param array<string, mixed> $old
     * @param array<string, mixed> $new
     */
    public static function recordChanges(
        string $action,
        string $entityType,
        int|string $entityId,
        array $old,
        array $new
    ): void {
        $changed = [];
        foreach ($new as $field => $value) {
            $before = $old[$field] ?? null;
            // Compare through summarise() so non-scalar values (e.g. a decoded
            // JSON/QR array injected by find()) never trigger the
            // "Array to string conversion" fatal that broke employee updates.
            if (self::summarise($before) !== self::summarise($value)) {
                $changed[$field] = ['old' => $before, 'new' => $value];
            }
        }

        if ($changed === []) {
            return;
        }

        $oldSubset = [];
        $newSubset = [];
        foreach ($changed as $field => $pair) {
            $oldSubset[$field] = $pair['old'];
            $newSubset[$field] = $pair['new'];
        }

        $summary = implode(', ', array_map(
            static fn (string $field, array $pair): string => sprintf(
                '%s: %s -> %s',
                $field,
                self::summarise($pair['old'] ?? null),
                self::summarise($pair['new'] ?? null)
            ),
            array_keys($changed),
            $changed
        ));

        self::record($action, $entityType, $entityId, $summary, $oldSubset, $newSubset);
    }

    /**
     * Scalar preview for audit summaries. Arrays (e.g. decoded JSON columns)
     * are JSON-encoded instead of cast, preventing the
     * "Array to string conversion" crash that broke employee updates.
     */
    private static function summarise(mixed $value): string
    {
        if ($value === null) {
            return 'null';
        }
        if (is_array($value)) {
            $encoded = json_encode($value, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PARTIAL_OUTPUT_ON_ERROR);
            return $encoded === false ? '[array]' : (string) $encoded;
        }
        if (is_bool($value)) {
            return $value ? '1' : '0';
        }
        return (string) $value;
    }

    /**
     * Human-readable summary of a money value change (salary example in the brief).
     */
    public static function recordSalaryChange(
        int $employeeId,
        string $employeeName,
        float $oldSalary,
        float $newSalary,
        ?int $changedBy = null
    ): void {
        $symbol   = Settings::string('currency.symbol', 'PHP');
        $prefix   = Settings::string('currency.position', 'PREFIX') === 'PREFIX' ? $symbol . ' ' : '';

        self::record(
            self::SALARY_CHANGED,
            'employee',
            $employeeId,
            sprintf(
                'Changed employee salary for %s: %s%s -> %s%s',
                $employeeName,
                $prefix,
                number_format($oldSalary, 2),
                $prefix,
                number_format($newSalary, 2)
            ),
            ['basic_salary' => $oldSalary],
            ['basic_salary' => $newSalary, 'changed_by' => $changedBy]
        );
    }

    /** @param array<string, mixed> $value */
    private static function encode(array $value): string
    {
        return (string) json_encode(
            $value,
            JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PARTIAL_OUTPUT_ON_ERROR
        );
    }
}
