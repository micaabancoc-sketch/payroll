<?php
/**
 * Configurable business rules (Phase 12 / Phase 19).
 *
 * Nothing about payroll, attendance or QR rules is hard-coded: every value
 * an administrator can change lives in `system_settings` and is read here.
 */

declare(strict_types=1);

namespace App\Core;

final class Settings
{
    /** @var array<string, mixed>|null */
    private static ?array $cache = null;

    /** @return array<string, mixed> */
    public static function all(bool $includePrivate = true): array
    {
        if (self::$cache === null) {
            self::load();
        }
        return $includePrivate ? self::$cache : array_filter(
            self::$cache,
            static fn (mixed $v, string $k): bool => !str_starts_with($k, '__private'),
            ARRAY_FILTER_USE_BOTH
        );
    }

    public static function get(string $key, mixed $default = null): mixed
    {
        if (self::$cache === null) {
            self::load();
        }
        return self::$cache[$key] ?? $default;
    }

    public static function int(string $key, int $default = 0): int
    {
        $value = self::get($key, $default);
        return is_numeric($value) ? (int) $value : $default;
    }

    public static function float(string $key, float $default = 0.0): float
    {
        $value = self::get($key, $default);
        return is_numeric($value) ? (float) $value : $default;
    }

    public static function bool(string $key, bool $default = false): bool
    {
        $value = self::get($key, $default);
        if (is_bool($value)) {
            return $value;
        }
        return filter_var($value, FILTER_VALIDATE_BOOLEAN);
    }

    public static function string(string $key, string $default = ''): string
    {
        $value = self::get($key, $default);
        return is_scalar($value) ? (string) $value : $default;
    }

    public static function set(string $key, string $value, ?int $userId = null): void
    {
        $existing = Database::scalar(
            'SELECT id FROM system_settings WHERE setting_key = :key',
            ['key' => $key]
        );

        if ($existing === null) {
            Database::insert('system_settings', [
                'setting_key'   => $key,
                'setting_value' => $value,
                'category'      => 'CUSTOM',
                'value_type'    => 'STRING',
                'updated_by'    => $userId,
            ]);
        } else {
            Database::execute(
                'UPDATE system_settings SET setting_value = :value, updated_by = :user WHERE id = :id',
                ['value' => $value, 'user' => $userId, 'id' => (int) $existing]
            );
        }

        self::$cache = null;
    }

    /** @param array<string, string> $pairs */
    public static function setMany(array $pairs, ?int $userId = null): void
    {
        foreach ($pairs as $key => $value) {
            self::set($key, (string) $value, $userId);
        }
    }

    public static function flush(): void
    {
        self::$cache = null;
    }

    /** @return array<string, mixed> */
    public static function publicSettings(): array
    {
        if (self::$cache === null) {
            self::load();
        }
        $public = [];
        foreach (self::$publicKeys ?? [] as $key) {
            if (array_key_exists($key, self::$cache)) {
                $public[$key] = self::$cache[$key];
            }
        }
        return $public;
    }

    /** @var list<string>|null */
    private static ?array $publicKeys = null;

    private static function load(): void
    {
        $rows = Database::select('SELECT setting_key, setting_value, value_type, is_public FROM system_settings');

        $settings = [];
        self::$publicKeys = [];

        foreach ($rows as $row) {
            $key   = (string) $row['setting_key'];
            $value = self::cast($row['setting_value'], (string) $row['value_type']);

            $settings[$key] = $value;
            if ((int) $row['is_public'] === 1) {
                self::$publicKeys[] = $key;
            }
        }

        self::$cache = $settings;
    }

    private static function cast(?string $value, string $type): mixed
    {
        $value = (string) $value;

        return match ($type) {
            'INT'     => (int) $value,
            'DECIMAL' => (float) $value,
            'BOOLEAN' => filter_var($value, FILTER_VALIDATE_BOOLEAN),
            'JSON'    => json_decode($value, true) ?? [],
            default   => $value,
        };
    }
}