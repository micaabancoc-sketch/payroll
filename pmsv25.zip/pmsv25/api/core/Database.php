<?php
/**
 * PDO connection factory + query helpers.
 * Every query in the system goes through prepared statements (Phase 20).
 */

declare(strict_types=1);

namespace App\Core;

use PDO;
use PDOException;
use PDOStatement;
use RuntimeException;

final class Database
{
    private static ?PDO $connection = null;
    private static int $transactionDepth = 0;

    public static function config(): array
    {
        static $config = null;
        if ($config === null) {
            /** @var array<string, mixed> $config */
            $config = require dirname(__DIR__) . '/config/config.php';
        }
        return $config;
    }

    public static function connection(): PDO
    {
        if (self::$connection instanceof PDO) {
            return self::$connection;
        }

        // Single shared factory (api/config/connection-pdo.php): identical
        // DSN, attributes and strict session mode as before.
        require_once dirname(__DIR__) . '/config/connection-pdo.php';

        try {
            self::$connection = pdo_connection(self::config()['database']);
        } catch (PDOException $e) {
            Logger::critical('Database connection failed', ['error' => $e->getMessage()]);
            throw new RuntimeException('Unable to connect to the database server.', 0, $e);
        }

        return self::$connection;
    }

    /** @param array<string|int, mixed> $params */
    public static function run(string $sql, array $params = []): PDOStatement
    {
        $statement = self::connection()->prepare($sql);
        foreach ($params as $key => $value) {
            $paramType = PDO::PARAM_STR;
            if (is_int($value)) {
                $paramType = PDO::PARAM_INT;
            } elseif (is_bool($value)) {
                $paramType = PDO::PARAM_BOOL;
            } elseif ($value === null) {
                $paramType = PDO::PARAM_NULL;
            }
            $statement->bindValue(
                is_int($key) ? $key + 1 : $key,
                $value,
                $paramType
            );
        }
        $statement->execute();
        return $statement;
    }

    /**
     * @param array<string|int, mixed> $params
     * @return array<int, array<string, mixed>>
     */
    public static function select(string $sql, array $params = []): array
    {
        return self::run($sql, $params)->fetchAll();
    }

    /**
     * @param array<string|int, mixed> $params
     * @return array<string, mixed>|null
     */
    public static function selectOne(string $sql, array $params = []): ?array
    {
        $row = self::run($sql, $params)->fetch();
        return $row === false ? null : $row;
    }

    /** @param array<string|int, mixed> $params */
    public static function scalar(string $sql, array $params = []): mixed
    {
        $value = self::run($sql, $params)->fetchColumn();
        return $value === false ? null : $value;
    }

    /** @param array<string|int, mixed> $params */
    public static function execute(string $sql, array $params = []): int
    {
        return self::run($sql, $params)->rowCount();
    }

    /** @param array<string, mixed> $data */
    public static function insert(string $table, array $data): int
    {
        $columns      = array_keys($data);
        $placeholders = array_map(static fn (string $c): string => ':' . $c, $columns);

        $sql = sprintf(
            'INSERT INTO `%s` (`%s`) VALUES (%s)',
            $table,
            implode('`, `', $columns),
            implode(', ', $placeholders)
        );

        self::run($sql, self::prefixed($data));
        return (int) self::connection()->lastInsertId();
    }

    /**
     * @param array<string, mixed> $data
     * @param array<string, mixed> $where
     */
    public static function update(string $table, array $data, array $where): int
    {
        if ($data === []) {
            return 0;
        }

        $setParts = [];
        foreach (array_keys($data) as $column) {
            $setParts[] = sprintf('`%s` = :set_%s', $column, $column);
        }

        $whereParts = [];
        foreach (array_keys($where) as $column) {
            $whereParts[] = sprintf('`%s` = :where_%s', $column, $column);
        }

        $params = [];
        foreach ($data as $k => $v) {
            $params['set_' . $k] = $v;
        }
        foreach ($where as $k => $v) {
            $params['where_' . $k] = $v;
        }

        $sql = sprintf(
            'UPDATE `%s` SET %s WHERE %s',
            $table,
            implode(', ', $setParts),
            implode(' AND ', $whereParts)
        );

        return self::execute($sql, $params);
    }

    /** @param array<string, mixed> $where */
    public static function delete(string $table, array $where): int
    {
        $whereParts = [];
        foreach (array_keys($where) as $column) {
            $whereParts[] = sprintf('`%s` = :%s', $column, $column);
        }

        $sql = sprintf('DELETE FROM `%s` WHERE %s', $table, implode(' AND ', $whereParts));
        return self::execute($sql, $where);
    }

    /** @param array<string, mixed> $data */
    private static function prefixed(array $data): array
    {
        $out = [];
        foreach ($data as $key => $value) {
            $out[':' . $key] = $value;
        }
        return $out;
    }

    /**
     * Nested-safe transactions (Phase 20: multi-step operations are atomic).
     */
    public static function beginTransaction(): void
    {
        if (self::$transactionDepth === 0) {
            self::connection()->beginTransaction();
        } else {
            self::connection()->exec('SAVEPOINT trx_' . self::$transactionDepth);
        }
        self::$transactionDepth++;
    }

    public static function commit(): void
    {
        if (self::$transactionDepth === 0) {
            return;
        }
        self::$transactionDepth--;
        if (self::$transactionDepth === 0) {
            self::connection()->commit();
        } else {
            self::connection()->exec('RELEASE SAVEPOINT trx_' . self::$transactionDepth);
        }
    }

    public static function rollBack(): void
    {
        if (self::$transactionDepth === 0) {
            return;
        }
        self::$transactionDepth--;
        if (self::$transactionDepth === 0) {
            if (self::connection()->inTransaction()) {
                self::connection()->rollBack();
            }
        } else {
            self::connection()->exec('ROLLBACK TO SAVEPOINT trx_' . self::$transactionDepth);
        }
    }

    public static function inTransaction(): bool
    {
        return self::$transactionDepth > 0;
    }

    /**
     * Run a callable inside a transaction, committing on success and rolling
     * back on any throwable. Nested calls use savepoints.
     *
     * @template T
     * @param callable(): T $callback
     * @return T
     */
    public static function transaction(callable $callback): mixed
    {
        self::beginTransaction();

        try {
            $result = $callback();
            self::commit();
            return $result;
        } catch (\Throwable $e) {
            self::rollBack();
            throw $e;
        }
    }
}