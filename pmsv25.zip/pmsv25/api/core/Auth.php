<?php
/**
 * Token-based authentication and role/permission checks (Phase 3).
 *
 * Tokens are random 64-char strings; only their SHA-256 hash is persisted,
 * so a database leak cannot be replayed against the API.
 */

declare(strict_types=1);

namespace App\Core;

final class Auth
{
    /** @var array<string, mixed>|null */
    private static ?array $user = null;
    private static bool $resolved = false;

    /**
     * Authenticate the request from its Bearer token.
     * Returns null when the token is missing/invalid/expired.
     */
    public static function authenticate(?Request $request = null): ?array
    {
        if (self::$resolved && self::$user !== null) {
            return self::$user;
        }

        $request = $request ?? new Request();
        $token   = $request->bearerToken();

        if ($token === null || $token === '') {
            return null;
        }

        $row = Database::selectOne(
            'SELECT u.id, u.username, u.email, u.full_name, u.role_id, u.status,
                    u.employee_id, u.must_change_password,
                    r.code AS role_code, r.name AS role_name, r.permissions AS role_permissions,
                    t.id AS token_id, t.expires_at
               FROM api_tokens t
               JOIN users u ON u.id = t.user_id
               JOIN roles r ON r.id = u.role_id
              WHERE t.token_hash = :hash
                AND t.is_revoked = 0
                AND u.deleted_at IS NULL
              LIMIT 1',
            ['hash' => self::hashToken($token)]
        );

        if ($row === null) {
            return null;
        }

        if (strtotime((string) $row['expires_at']) < time()) {
            Database::execute('UPDATE api_tokens SET is_revoked = 1 WHERE id = :id', ['id' => (int) $row['token_id']]);
            return null;
        }

        if ($row['status'] !== 'ACTIVE') {
            return null;
        }

        // Refresh last_used_at at most once a minute to avoid a write per request.
        Database::execute(
            'UPDATE api_tokens SET last_used_at = NOW()
              WHERE id = :id
                AND (last_used_at IS NULL OR last_used_at < DATE_SUB(NOW(), INTERVAL 1 MINUTE))',
            ['id' => (int) $row['token_id']]
        );

        $permissions = json_decode((string) ($row['role_permissions'] ?? '[]'), true);
        $row['permissions'] = RolePolicy::permissions((string) $row['role_code']);

        unset($row['role_permissions']);
        self::$user = $row;
        self::$resolved = true;

        return self::$user;
    }

    /** A known weak value banned for new passwords; resets generate random tokens. */
    public const TEMPORARY_PASSWORD = '123';

    /**
     * The only requests an account awaiting a forced password change may make.
     *
     * The change screen itself, plus the two calls that screen needs: read the
     * signed-in user, and sign out. Everything else is refused in require(), so
     * the browser redirect is a convenience and never the only guard.
     *
     * @var list<string>
     */
    private const FORCED_CHANGE_ALLOWED_PATHS = [
        '/api/auth/change-password',
        '/api/auth/me',
        '/api/auth/logout',
    ];

    /** Require a valid session; emits 401 otherwise. */
    public static function require(?Request $request = null): array
    {
        $user = self::authenticate($request);
        if ($user === null) {
            Response::unauthorized('Your session has expired or is invalid. Please sign in again.');
        }

        // An administrator reset flags the account: until the temporary
        // password is replaced the session is chained to the change flow. This
        // is the single gate that covers the whole API — the router calls
        // require() for every permitted route, and authorize()/authorizeAny()
        // resolve the user through here as well.
        if ((int) ($user['must_change_password'] ?? 0) === 1) {
            $request ??= new Request();

            if (!in_array($request->path(), self::FORCED_CHANGE_ALLOWED_PATHS, true)) {
                Logger::warning('Blocked request while a password change is required', [
                    'user_id' => (int) $user['id'],
                    'path'    => $request->path(),
                ]);
                Response::forbidden(
                    'You must change your temporary password before you can use the system.'
                );
            }
        }

        return $user;
    }

    /** @return array<string, mixed>|null */
    public static function user(): ?array
    {
        return self::$user;
    }

    public static function id(): ?int
    {
        return self::$user === null ? null : (int) self::$user['id'];
    }

    public static function employeeId(): ?int
    {
        $id = self::$user['employee_id'] ?? null;
        return $id === null ? null : (int) $id;
    }

    public static function roleCode(): ?string
    {
        return self::$user['role_code'] ?? null;
    }

    public static function isSuperAdmin(): bool
    {
        return in_array(self::roleCode(), ['ADMIN', 'SUPER_ADMIN'], true);
    }

    public static function hasPermission(string $permission): bool
    {
        if (self::$user === null) {
            return false;
        }
        $permissions = (array) (self::$user['permissions'] ?? []);
        return in_array($permission, $permissions, true);
    }

    /** @param list<string> $permissions */
    public static function hasAnyPermission(array $permissions): bool
    {
        foreach ($permissions as $permission) {
            if (self::hasPermission($permission)) {
                return true;
            }
        }
        return false;
    }

    /** Gate a request: emits 403 when the permission is missing. */
    public static function authorize(string $permission, ?Request $request = null): void
    {
        // Routes that carry no permission still need the user resolved here,
        // so controllers can check permissions without a second lookup.
        $request = $request ?? new Request();
        self::require($request);

        if (!self::hasPermission($permission)) {
            Logger::warning('Permission denied', [
                'user_id'    => self::id(),
                'permission' => $permission,
            ]);
            Response::forbidden(sprintf('Your role does not have the "%s" permission.', $permission));
        }
    }

    /**
     * Gate a request allowing any one of several permissions.
     *
     * @param list<string> $permissions
     */
    public static function authorizeAny(array $permissions, ?Request $request = null): void
    {
        $request = $request ?? new Request();
        self::require($request);

        if (!self::hasAnyPermission($permissions)) {
            Response::forbidden(sprintf(
                'Your role does not have any of these permissions: %s.',
                implode(', ', $permissions)
            ));
        }
    }

    /**
     * Ensure the caller may act on the given employee.
     * HR/payroll/admin can act on everyone; an employee only on their own record.
     */
    public static function canAccessEmployee(int $employeeId): bool
    {
        if (self::employeeId() === $employeeId) { return true; }
        $role = self::roleCode();
        if ($role === 'HR_PAYROLL') { return true; }
        if ($role !== 'MANAGER') { return false; }
        $departmentId = self::managerDepartmentId();
        if ($departmentId === null) { return false; }
        $record = Database::selectOne('SELECT department_id,assigned_supervisor_id FROM employees WHERE id = :id AND deleted_at IS NULL', ['id' => $employeeId]);
        return $record !== null && ((int)($record['assigned_supervisor_id'] ?? 0) === (int)self::employeeId() ||
            ($record['assigned_supervisor_id'] === null && (int)$record['department_id'] === $departmentId));
    }


    /** Department-based team scope until the company supplies a manager->team roster. */
    public static function managerDepartmentId(): ?int {
        if (self::roleCode() !== 'MANAGER' || self::employeeId() === null) { return null; }
        $row = Database::selectOne('SELECT department_id FROM employees WHERE id = :id AND deleted_at IS NULL', ['id' => self::employeeId()]);
        return $row !== null && !empty($row['department_id']) ? (int) $row['department_id'] : null;
    }
    public static function requireTeamEmployee(int $id): void {
        if (!self::canAccessEmployee($id)) { Response::forbidden('Outside your assigned department/team.'); }
    }

    public static function requireSelfOrPermission(int $employeeId, string $permission): void
    {
        if (str_starts_with($permission, 'payroll.payslip') && self::roleCode() === 'MANAGER' && self::employeeId() !== $employeeId) {
            Response::forbidden('Managers can view only their own payslips.');
        }
        if (!self::canAccessEmployee($employeeId)) { Response::forbidden('Record outside your authorized scope.'); }
    }

    /**
     * QR codes are personal: always your own, anyone else's only with the
     * explicit qr.view permission (administrators, who hold "*").
     *
     * Deliberately stricter than requireSelfOrPermission(), which also accepts
     * employees.view — a manager may open any employee record, but must not
     * read that employee's attendance credential.
     */
    public static function requireSelfOrQrPermission(int $employeeId): void
    {
        self::require();

        if (self::employeeId() !== null && self::employeeId() === $employeeId) {
            return;
        }

        if (!self::hasPermission('qr.view')) {
            Response::forbidden('You may only access your own QR code.');
        }
    }

    // -----------------------------------------------------------------------
    // Token lifecycle
    // -----------------------------------------------------------------------

    /** @return array{token: string, expires_at: string} */
    public static function issueToken(int $userId, Request $request, ?int $lifetimeHours = null): array
    {
        $lifetimeHours = $lifetimeHours ?? (int) Settings::get('security.token_lifetime_hours', 12);
        $lifetimeHours = $lifetimeHours > 0 ? $lifetimeHours : 12;

        // 32 random bytes -> 64 hex characters.
        $token = bin2hex(random_bytes(32));
        $expiresAt = date('Y-m-d H:i:s', time() + ($lifetimeHours * 3600));

        Database::insert('api_tokens', [
            'user_id'    => $userId,
            'token_hash' => self::hashToken($token),
            'expires_at' => $expiresAt,
            'ip_address' => $request->ip(),
            'user_agent' => $request->userAgent(),
            'is_revoked' => 0,
        ]);

        return ['token' => $token, 'expires_at' => $expiresAt];
    }

    public static function revokeToken(string $token): void
    {
        Database::execute(
            'UPDATE api_tokens SET is_revoked = 1 WHERE token_hash = :hash',
            ['hash' => self::hashToken($token)]
        );
    }

    public static function revokeAllTokens(int $userId): void
    {
        Database::execute(
            'UPDATE api_tokens SET is_revoked = 1 WHERE user_id = :user_id',
            ['user_id' => $userId
            ]
        );
    }

    /** Drop tokens that expired more than 30 days ago. */
    public static function purgeExpiredTokens(): int
    {
        return Database::execute(
            'DELETE FROM api_tokens WHERE expires_at < DATE_SUB(NOW(), INTERVAL 30 DAY)'
        );
    }

    private static function hashToken(string $token): string
    {
        $pepper = Database::config()['security']['token_pepper'];
        return hash('sha256', $token . '|' . $pepper);
    }
}
