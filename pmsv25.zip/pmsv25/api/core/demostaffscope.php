<?php
/**
 * V25 staff-only defense demonstration (NON-DESTRUCTIVE).
 * EMP-000001 (Demo Staff Member) is the only attendance, leave, OT, loan and payroll participant.
 * Roles / login accounts / old attendance / finalized payslips stay intact.
 * Full payroll workflow is enabled only for explicitly configured local development tests.
 */
declare(strict_types=1);

namespace App\Core;

use RuntimeException;

final class DemoStaffScope
{
    public static function enabled(): bool
    {
        $cfg = Database::config();
        return (bool) ($cfg['demo']['staff_only'] ?? false);
    }

    /** SQL fragment safe for developer-controlled, static aliases only. */
    public static function excludingRoles(string $employeeIdExpression): string
    {
        // Explicit allow-list prevents SQL injection if used with a variable.
        if (!in_array($employeeIdExpression, ['e.id', 'employees.id', 'a.employee_id', 'attendance.employee_id', 'al.employee_id'], true)) {
            throw new RuntimeException('Unsupported employee ID expression for demo filtering.');
        }
        if (!self::enabled()) { return ''; }
        return " AND NOT EXISTS (SELECT 1 FROM users scope_u JOIN roles scope_r ON scope_r.id=scope_u.role_id "
            . "WHERE scope_u.employee_id={$employeeIdExpression} AND scope_u.deleted_at IS NULL "
            . "AND scope_r.code IN ('HR_PAYROLL','MANAGER','ADMIN','KIOSK'))";
    }

    /** Active payroll/attendance population; no reliance on a UI-only filter. */
    public static function excludingDemoUsernames(string $employeeIdExpression): string
    {
        if (!in_array($employeeIdExpression, ['e.id', 'employees.id', 'a.employee_id', 'attendance.employee_id', 'al.employee_id'], true)) {
            throw new RuntimeException('Unsupported employee ID expression.');
        }
        $employeeTable = match ($employeeIdExpression) {
            'employees.id' => 'employees',
            'e.id' => 'e',
            default => null,
        };
        $demoNumber = 'EMP-000001'; // Verified against uploaded V25 SQL: Demo Staff Member.
        $onlyDemo = self::enabled();
        if ($employeeTable !== null) {
            return ' AND ' . $employeeTable . '.payroll_eligible = 1'
                . ($onlyDemo ? ' AND ' . $employeeTable . ".employee_number = '" . $demoNumber . "'" : '');
        }
        return ' AND EXISTS (SELECT 1 FROM employees payroll_scope_employee'
            . ' WHERE payroll_scope_employee.id=' . $employeeIdExpression
            . ' AND payroll_scope_employee.payroll_eligible=1'
            . ($onlyDemo ? " AND payroll_scope_employee.employee_number='" . $demoNumber . "'" : '')
            . ')';
    }

    /** Require a demo STAFF participant for every new employee-side transaction.
     * This rejects HR, Manager, Admin, other demo employees, and inactive payroll accounts
     * while retaining old financial/attendance histories for audit access.
     */
    public static function assertDemoParticipant(int $employeeId): void
    {
        if (self::enabled()) {
            self::assertIncluded($employeeId);
        }
    }

    /** Used by HR employee registration/restoration to skip unusable demo QR issuance. */
    public static function participates(int $employeeId): bool
    {
        if (!self::enabled()) { return true; }
        try { self::assertIncluded($employeeId); return true; }
        catch (RuntimeException $e) { return false; }
    }

    /** True for an administrative user who is not a personal attendance/payroll participant. */
    public static function isSystemOperator(): bool
    {
        return self::enabled() && in_array(Auth::roleCode(), ['ADMIN', 'HR_PAYROLL', 'MANAGER', 'KIOSK'], true);
    }

    /** Whether employee participation is limited to one test staff member. */
    public static function limitedDemoScope(): bool
    {
        return self::enabled();
    }

    /** Explicit local-only exception for the defense test payroll workflow.
     * Staff-only roster restrictions remain in effect; production cannot use this switch.
     */
    public static function payrollWorkflowEnabled(): bool
    {
        if (!self::limitedDemoScope()) { return true; }
        $cfg = Database::config();
        return ($cfg['app']['env'] ?? 'production') === 'development'
            && ($cfg['demo']['enable_payroll_workflow'] ?? false) === true;
    }

    /** Fail closed for any per-employee payroll or absence-verification API. */
    public static function assertIncluded(int $employeeId): void
    {
        $allowed = Database::scalar(
            'SELECT e.id FROM employees e WHERE e.id=:eid'
            . self::excludingRoles('e.id') . self::excludingDemoUsernames('e.id') . ' LIMIT 1',
            ['eid'=>$employeeId]
        );
        if ($allowed === null) {
            throw new RuntimeException('STAFF-only demo: only Demo Staff Member (EMP-000001) can record attendance or be included in payroll. Existing data is preserved.');
        }
    }
}
