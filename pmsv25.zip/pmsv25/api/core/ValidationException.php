<?php
/**
 * Validation failure carrying field-level messages (Phase 20).
 */

declare(strict_types=1);

namespace App\Core;

use RuntimeException;

final class ValidationException extends RuntimeException
{
    /** @param array<string, string> $errors */
    public function __construct(
        private array $errors,
        string $message = 'The given data was invalid.'
    ) {
        parent::__construct($message);
    }

    /** @return array<string, string> */
    public function errors(): array
    {
        return $this->errors;
    }
}