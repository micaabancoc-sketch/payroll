<?php
/**
 * Minimal, explicit router for the REST API (Phase 1).
 *
 * Routes are declared with {placeholders}; matching is exact so a route can
 * never be reached by accident.
 */

declare(strict_types=1);

namespace App\Core;

final class Router
{
    /** @var list<array{method: string, pattern: string, regex: string, params: list<string>, handler: array|callable, permission: string|null}> */
    private array $routes = [];

    private string $groupPrefix = '';
    private ?string $groupPermission = null;

    /** Register a route. $handler is [ControllerClass::class, 'method'] or a closure. */
    public function add(string $method, string $path, array|callable $handler, ?string $permission = null): void
    {
        $fullPath = $this->groupPrefix . $path;
        $params   = [];

        $regex = preg_replace_callback(
            '/\{([a-zA-Z_][a-zA-Z0-9_]*)\??\}/',
            static function (array $m) use (&$params): string {
                $params[] = $m[1];
                return str_ends_with($m[0], '?') ? '?([^/]+)' : '([^/]+)';
            },
            $fullPath
        );

        $this->routes[] = [
            'method'     => strtoupper($method),
            'pattern'    => $fullPath,
            'regex'      => '#^' . $regex . '$#',
            'params'     => $params,
            'handler'    => $handler,
            'permission' => $permission ?? $this->groupPermission,
        ];
    }

    public function get(string $path, array|callable $handler, ?string $permission = null): void
    {
        $this->add('GET', $path, $handler, $permission);
    }

    public function post(string $path, array|callable $handler, ?string $permission = null): void
    {
        $this->add('POST', $path, $handler, $permission);
    }

    public function put(string $path, array|callable $handler, ?string $permission = null): void
    {
        $this->add('PUT', $path, $handler, $permission);
    }

    public function patch(string $path, array|callable $handler, ?string $permission = null): void
    {
        $this->add('PATCH', $path, $handler, $permission);
    }

    public function delete(string $path, array|callable $handler, ?string $permission = null): void
    {
        $this->add('DELETE', $path, $handler, $permission);
    }

    /**
     * Group routes under a common prefix.
     *
     * @param callable(Router): void $callback
     */
    public function group(string $prefix, callable $callback, ?string $permission = null): void
    {
        $previousPrefix     = $this->groupPrefix;
        $previousPermission = $this->groupPermission;

        $this->groupPrefix     = rtrim($previousPrefix . $prefix, '/');
        $this->groupPermission = $permission;

        $callback($this);

        $this->groupPrefix     = $previousPrefix;
        $this->groupPermission = $previousPermission;
    }

    /**
     * Resolve and execute the request.
     *
     * @param array<string, string> $routeParams
     */
    public function dispatch(Request $request, array $routeParams): never
    {
        $method      = $request->method();
        $path        = $request->path();
        // Removed UI is not enough: archived records are not a supported feature.
        if (in_array(strtolower((string)($_GET['archived'] ?? '')), ['only','true','1'], true)) {
            Response::forbidden('Archive browsing is disabled by company policy.');
        }
        $pathMatched = false;

        foreach ($this->routes as $route) {
            if (preg_match($route['regex'], $path, $matches) !== 1) {
                continue;
            }

            $pathMatched = true;

            if ($route['method'] !== $method && !($method === 'HEAD' && $route['method'] === 'GET')) {
                continue;
            }

            array_shift($matches);
            $params = array_map('strval', $matches);
            $named  = array_combine($route['params'], $params) ?: [];

            // Merge query string parameters (used for filters such as employee_id).
            $args = array_merge($routeParams, $named);

            if ($route['permission'] !== null) {
                Auth::require($request);
                Auth::authorize($route['permission']);
            } elseif (!in_array($path, ['/api/health', '/api/auth/login', '/api/attendance/scan', '/api/attendance/scan/preview'], true)) {
                Auth::require($request);
            }

            // Controller@method handlers are instantiated here; closures are
            // invoked directly (used for the health check).
            if (is_array($route['handler'])) {
                [$class, $action] = $route['handler'];

                if (!class_exists($class) || !method_exists($class, $action)) {
                    Logger::critical('Route handler not found', ['handler' => $class . '@' . $action]);
                    Response::error('Endpoint handler is not available', 500);
                }

                /** @var callable $callable */
                $callable = [new $class(), $action];
            } else {
                /** @var callable $callable */
                $callable = $route['handler'];
            }

            $callable($request, $args);

            Response::error('Handler did not return a response', 500);
        }

        if ($pathMatched) {
            Response::methodNotAllowed(sprintf('%s is not supported on this endpoint.', $method));
        }

        Response::notFound(sprintf('Endpoint %s %s does not exist.', $method, $path));
    }

    /** @return list<array{method: string, pattern: string}> */
    public function list(): array
    {
        return array_map(
            static fn (array $r): array => ['method' => $r['method'], 'pattern' => $r['pattern']],
            $this->routes
        );
    }
}