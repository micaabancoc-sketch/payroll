<?php
/**
 * File-based logger with daily rotation (Phase 1 / Phase 20).
 */

declare(strict_types=1);

namespace App\Core;

use Throwable;

final class Logger
{
    private const LEVELS = [
        'DEBUG'     => 100,
        'INFO'      => 200,
        'WARNING'   => 300,
        'ERROR'     => 400,
        'CRITICAL'  => 500,
    ];

    private static ?string $channel = null;

    public static function channel(string $name): void
    {
        self::$channel = preg_replace('/[^a-z0-9_\-]/i', '', $name) ?: 'app';
    }

    /** @param array<string, mixed> $context */
    public static function debug(string $message, array $context = []): void
    {
        self::write('DEBUG', $message, $context);
    }

    /** @param array<string, mixed> $context */
    public static function info(string $message, array $context = []): void
    {
        self::write('INFO', $message, $context);
    }

    /** @param array<string, mixed> $context */
    public static function warning(string $message, array $context = []): void
    {
        self::write('WARNING', $message, $context);
    }

    /** @param array<string, mixed> $context */
    public static function error(string $message, array $context = []): void
    {
        self::write('ERROR', $message, $context);
    }

    /** @param array<string, mixed> $context */
    public static function critical(string $message, array $context = []): void
    {
        self::write('CRITICAL', $message, $context);
    }

    /** @param array<string, mixed> $context */
    public static function exception(Throwable $e, string $message = ''): void
    {
        self::write('ERROR', $message !== '' ? $message : $e->getMessage(), [
            'exception' => get_class($e),
            'message'   => $e->getMessage(),
            'file'      => $e->getFile(),
            'line'      => $e->getLine(),
            'trace'     => self::config()['app']['debug'] ? $e->getTraceAsString() : null,
        ]);
    }

    /** @param array<string, mixed> $context */
    private static function write(string $level, string $message, array $context): void
    {
        $config = self::config();
        $minLevel = self::LEVELS[strtoupper((string) ($config['app']['log_level'] ?? 'INFO'))] ?? 200;

        if ((self::LEVELS[$level] ?? 200) < $minLevel) {
            return;
        }

        $directory = $config['paths']['logs'];
        if (!is_dir($directory)) {
            @mkdir($directory, 0775, true);
        }

        $channel = self::$channel ?? 'app';
        $file = sprintf('%s/%s-%s.log', $directory, $channel, date('Y-m-d'));

        $record = [
            'timestamp' => date('c'),
            'level'     => $level,
            'channel'   => $channel,
            'message'   => $message,
            'context'   => $context === [] ? null : self::sanitise($context),
        ];

        $line = json_encode($record, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_PARTIAL_OUTPUT_ON_ERROR);

        @file_put_contents($file, $line . PHP_EOL, FILE_APPEND | LOCK_EX);
    }

    /**
     * Redact anything that looks like a credential before it reaches disk.
     *
     * @param array<string, mixed> $context
     * @return array<string, mixed>
     */
    private static function sanitise(array $context): array
    {
        $sensitive = ['password', 'password_hash', 'token', 'api_token', 'secret', 'pepper', 'authorization'];
        foreach ($context as $key => $value) {
            if (in_array(strtolower((string) $key), $sensitive, true)) {
                $context[$key] = '***redacted***';
            } elseif (is_array($value)) {
                $context[$key] = self::sanitise($value);
            }
        }
        return $context;
    }

    /** @return array<string, mixed> */
    private static function config(): array
    {
        /** @var array<string, mixed> $config */
        $config = require dirname(__DIR__) . '/config/config.php';
        return $config;
    }

    /** Remove log files older than the retention window. */
    public static function prune(int $days = 30): int
    {
        $directory = self::config()['paths']['logs'];
        if (!is_dir($directory)) {
            return 0;
        }

        $removed = 0;
        $cutoff  = time() - ($days * 86400);
        foreach (glob($directory . '/*.log') ?: [] as $file) {
            if (filemtime($file) < $cutoff && @unlink($file)) {
                $removed++;
            }
        }
        return $removed;
    }
}