<?php
/**
 * Uniform API response envelope (Phase 1).
 *
 *   { "success": true, "message": "...", "data": { ... } }
 */

declare(strict_types=1);

namespace App\Core;

final class Response
{
    /**
     * @param array<string, mixed>|list<mixed>|null $data
     */
    public static function success(
        mixed $data = null,
        string $message = 'Request completed successfully',
        int $statusCode = 200,
        array $meta = []
    ): never {
        self::send(true, $message, $data, $statusCode, $meta);
    }

    /**
     * @param array<string, mixed>|list<mixed>|null $data
     */
    public static function created(mixed $data = null, string $message = 'Resource created successfully'): never
    {
        self::send(true, $message, $data, 201);
    }

    /** @param array<string, string> $errors */
    public static function error(
        string $message = 'An error occurred',
        int $statusCode = 400,
        array $errors = [],
        mixed $data = null
    ): never {
        $payload = ['success' => false, 'message' => $message, 'data' => $data];
        if ($errors !== []) {
            $payload['errors'] = $errors;
        }
        self::emit($payload, $statusCode);
    }

    /** @param array<string, string> $errors */
    public static function validationError(array $errors, string $message = 'Validation failed'): never
    {
        self::error($message, 422, $errors);
    }

    public static function unauthorized(string $message = 'Authentication required'): never
    {
        self::error($message, 401);
    }

    public static function forbidden(string $message = 'You do not have permission to perform this action'): never
    {
        self::error($message, 403);
    }

    public static function notFound(string $message = 'Resource not found'): never
    {
        self::error($message, 404);
    }

    public static function methodNotAllowed(string $message = 'Method not allowed'): never
    {
        self::error($message, 405);
    }

    public static function tooManyRequests(string $message = 'Too many requests, please slow down', int $retryAfter = 60): never
    {
        header('Retry-After: ' . $retryAfter);
        self::error($message, 429);
    }

    /**
     * Standard paginated envelope.
     *
     * @param list<mixed> $items
     */
    public static function paginated(
        array $items,
        int $total,
        int $page,
        int $perPage,
        string $message = 'Records retrieved successfully'
    ): never {
        $lastPage = $perPage > 0 ? (int) ceil($total / $perPage) : 1;

        self::send(true, $message, $items, 200, [
            'pagination' => [
                'current_page' => $page,
                'per_page'     => $perPage,
                'total_records'=> $total,
                'total_pages'  => $lastPage,
                'has_next'     => $page < $lastPage,
                'has_prev'     => $page > 1,
            ],
        ]);
    }

    /** @param array<string, mixed> $meta */
    private static function send(bool $success, string $message, mixed $data, int $statusCode, array $meta = []): never
    {
        $payload = [
            'success' => $success,
            'message' => $message,
            'data'    => $data,
        ];
        if ($meta !== []) {
            $payload['meta'] = $meta;
        }
        self::emit($payload, $statusCode);
    }

    /** @param array<string, mixed> $payload */
    private static function emit(array $payload, int $statusCode): never
    {
        if (!headers_sent()) {
            http_response_code($statusCode);
            header('Content-Type: application/json; charset=utf-8');
            header('X-Content-Type-Options: nosniff');
            header('Cache-Control: no-store');
        }

        echo json_encode(
            $payload,
            JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PARTIAL_OUTPUT_ON_ERROR
        );

        exit;
    }
}