<?php
/** Canonical RBAC ceiling; old database role JSON cannot add unauthorized capabilities. */
declare(strict_types=1);
namespace App\Core;
final class RolePolicy {
    private const MAP = [
        'KIOSK' => ['attendance.scan'],
        'ADMIN' => ['dashboard.view', 'settings.manage', 'user.view', 'schedule.view', 'schedule.manage', 'holiday.view', 'holiday.manage', 'qr.generate', 'qr.disable', 'qr.view', 'audit.view', 'profile.view_own', 'profile.update_own'],
        'HR_PAYROLL' => ['dashboard.view', 'employees.view', 'employees.create', 'employees.update', 'attendance.view', 'attendance.view_own', 'attendance.create', 'attendance.update', 'attendance.adjust', 'schedule.view', 'holiday.view', 'leave.view', 'leave.view_own', 'leave.create', 'leave.approve', 'overtime.view', 'overtime.view_own', 'overtime.approve', 'payroll.view', 'payroll.period.view', 'payroll.period.create', 'payroll.calculate', 'payroll.approve', 'payroll.finalize', 'payroll.mark_paid', 'payroll.payslip.view', 'payroll.payslip.view_own', 'payroll.payments.view', 'payroll.payments.record', 'payroll.payments.cancel', 'loans.view', 'loans.create', 'loans.update', 'loans.approve', 'loans.payment', 'loans.release', 'remittance.view', 'remittance.manage', 'report.payroll', 'report.attendance', 'report.leave', 'report.statutory', 'audit.view', 'profile.view_own', 'profile.update_own'],
        'MANAGER' => ['dashboard.view', 'employees.view', 'attendance.view', 'attendance.view_own', 'leave.view', 'leave.view_own', 'leave.create', 'leave.approve', 'overtime.view', 'overtime.view_own', 'overtime.create', 'payroll.view_own', 'payroll.payslip.view_own', 'loans.view_own', 'loans.create', 'profile.view_own', 'profile.update_own'],
        'STAFF' => ['dashboard.view', 'attendance.view_own', 'leave.view_own', 'leave.create', 'leave.cancel_own', 'overtime.view_own', 'payroll.view_own', 'payroll.payslip.view_own', 'loans.view_own', 'loans.create', 'profile.view_own', 'profile.update_own'],
    ];
    public static function permissions(string $role): array {
        return self::MAP[$role] ?? [];
    }
    public static function allows(string $role, string $permission): bool {
        return in_array($permission, self::permissions($role), true);
    }
}
