<?php
/**
 * Payslips (Phase 15).
 *
 * EARNINGS / DEDUCTIONS / GROSS PAY / TOTAL DEDUCTIONS / NET PAY, printed
 * from the frontend. Payslips of a finalized period are read-only (rule 10).
 */

declare(strict_types=1);

namespace App\Services;

use App\Core\Database;
use App\Core\Settings;
use RuntimeException;

final class PayslipService
{
    /** @return array<string, mixed> */
    public function render(int $payrollId): array
    {
        $payroll = Database::selectOne(
            'SELECT p.*, e.employee_number, e.first_name, e.middle_name, e.last_name, e.suffix,
                    e.salary_type, e.employment_type, e.date_hired,
                    d.name AS department_name, pos.name AS position_name,
                    pp.code AS period_code, pp.name AS period_name,
                    pp.start_date, pp.end_date, pp.pay_date, pp.status AS period_status
               FROM payroll p
               JOIN employees e ON e.id = p.employee_id
               LEFT JOIN departments d ON d.id = e.department_id
               LEFT JOIN positions pos ON pos.id = e.position_id
               LEFT JOIN payroll_periods pp ON pp.id = p.payroll_period_id
              WHERE p.id = :id
              LIMIT 1',
            ['id' => $payrollId]
        );

        if ($payroll === null) {
            throw new RuntimeException('Payslip not found.');
        }

        $items = Database::select(
            'SELECT item_type, code, name, amount, remarks
               FROM payroll_items
              WHERE payroll_id = :id
              ORDER BY item_type, id',
            ['id' => $payrollId]
        );

        $earnings   = [];
        $deductions = [];

        foreach ($items as $item) {
            if ((string) $item['item_type'] === 'EARNING') {
                $earnings[] = $item;
            } else {
                $deductions[] = $item;
            }
        }

        $settings = Settings::all();
        $payment = $this->paymentSummary((int) $payroll['id'], (float) $payroll['net_pay']);

        // Employer shares (SSS + EC, PhilHealth, Pag-IBIG) are listed for
        // reference only: they are never deducted from the employee's pay.
        $employerContributions = array_values(array_filter(
            Database::select(
                'SELECT code, name, employer_amount, extra_amount
                   FROM payroll_statutory
                  WHERE payroll_id = :id
                  ORDER BY id',
                ['id' => $payrollId]
            ),
            static fn (array $row): bool => ((float) $row['employer_amount'] + (float) $row['extra_amount']) > 0
        ));

        $employee = [
            'id'              => (int) $payroll['employee_id'],
            'employee_number' => $payroll['employee_number'],
            'full_name'       => trim(implode(' ', array_filter([
                $payroll['first_name'], $payroll['middle_name'],
                $payroll['last_name'], $payroll['suffix'],
            ], static fn (mixed $v): bool => (string) $v !== ''))),
            'department'      => $payroll['department_name'],
            'position'        => $payroll['position_name'],
            'salary_type'     => $payroll['salary_type'],
            'employment_type' => $payroll['employment_type'],
            'date_hired'      => $payroll['date_hired'],
        ];

        return [
            'payslip' => [
                'id'       => (int) $payroll['id'],
                'company'  => [
                    'name'    => $settings['company.name'] ?? 'Company',
                    'address' => $settings['company.address'] ?? '',
                    'phone'   => $settings['company.phone'] ?? '',
                    'email'   => $settings['company.email'] ?? '',
                ],
                'employee' => $employee,
                'period'   => [
                    'code'     => $payroll['period_code'],
                    'name'     => $payroll['period_name'],
                    'start'    => $payroll['start_date'],
                    'end'      => $payroll['end_date'],
                    'pay_date' => $payroll['pay_date'],
                    'status'   => $payroll['period_status'],
                ],
                'payment'  => $payment,
                'earnings'   => $earnings,
                'deductions' => $deductions,
                'employer_contributions' => array_map(
                    static fn (array $row): array => [
                        'code'   => $row['code'],
                        'name'   => $row['name'],
                        'amount' => round((float) $row['employer_amount'] + (float) $row['extra_amount'], 2),
                    ],
                    $employerContributions
                ),
                'totals'     => [
                    'basic_pay'           => (float) $payroll['basic_pay'],
                    'overtime_hours'      => (float) $payroll['overtime_hours'],
                    'overtime_pay'        => (float) $payroll['overtime_pay'],
                    'allowances_total'    => (float) $payroll['allowances_total'],
                    'bonus'               => (float) $payroll['bonus'],
                    'gross_pay'           => (float) $payroll['gross_pay'],
                    'late_minutes'        => (int) $payroll['late_minutes'],
                    'undertime_minutes'   => (int) $payroll['undertime_minutes'],
                    'late_deduction'      => (float) $payroll['late_deduction'],
                    'undertime_deduction' => (float) $payroll['undertime_deduction'],
                    'absence_deduction'   => (float) $payroll['absence_deduction'],
                    'leave_deduction'     => (float) $payroll['leave_deduction'],
                    'other_deductions'    => (float) $payroll['other_deductions'],
                    'statutory_sss'       => (float) ($payroll['statutory_sss'] ?? 0.0),
                    'statutory_philhealth' => (float) ($payroll['statutory_philhealth'] ?? 0.0),
                    'statutory_pagibig'   => (float) ($payroll['statutory_pagibig'] ?? 0.0),
                    'withholding_tax'     => (float) ($payroll['withholding_tax'] ?? 0.0),
                    'statutory_total'     => (float) ($payroll['statutory_total'] ?? 0.0),
                    'employer_contributions' => (float) ($payroll['employer_contributions'] ?? 0.0),
                    'total_deductions'    => (float) $payroll['total_deductions'],
                    'net_pay'             => (float) $payroll['net_pay'],
                ],
                'working_days'  => (float) $payroll['working_days'],
                'present_days'  => (float) $payroll['present_days'],
                'absent_days'   => (float) $payroll['absent_days'],
                'leave_days'    => (float) $payroll['leave_days'],
                'is_locked'     => (int) $payroll['is_locked'],
                'calculated_at' => $payroll['calculated_at'],
                'currency'      => [
                    'symbol'   => Settings::string('currency.symbol', 'PHP'),
                    'position' => Settings::string('currency.position', 'PREFIX'),
                ],
            ],
        ];
    }
/**
     * Employee-visible payment status comes from CONFIRMED payments only.
     * Pending/failed/cancelled entries do not count, and FINALIZED alone is
     * never evidence that money was actually disbursed.
     */
    private function paymentSummary(int $payrollId, float $netPay): array
    {
        $paid = Database::selectOne(
            "SELECT COALESCE(SUM(amount), 0) AS completed_amount,
                    MAX(payment_date) AS last_payment_date
               FROM payroll_payments
              WHERE payroll_id = :id AND payment_status = 'COMPLETED'",
            ['id' => $payrollId]
        );
        return self::paymentFromCompletedAmount(
            $netPay,
            (float) ($paid['completed_amount'] ?? 0),
            $paid['last_payment_date'] ?? null
        );
    }

    private static function paymentFromCompletedAmount(float $netPay, float $completed, mixed $lastDate): array
    {
        $net = round(max(0.0, $netPay), 2);
        $paid = round(min($net, max(0.0, $completed)), 2);
        $balance = round(max(0.0, $net - $paid), 2);
        $status = $balance <= 0.005 ? 'PAID' : ($paid > 0 ? 'PARTIAL' : 'UNPAID');
        return [
            'status' => $status,
            'amount_paid' => $paid,
            'balance_due' => $balance,
            'last_payment_date' => $lastDate,
        ];
    }

    /**
     * Payslip history for an employee (Phase 15).
     *
     * @return list<array<string, mixed>>
     */
    public function history(int $employeeId, bool $releasedOnly = false): array
    {
        $rows = Database::select(
            'SELECT p.id, p.gross_pay, p.net_pay, p.total_deductions, p.is_locked, p.calculated_at,
                    pp.id AS period_id, pp.code AS period_code, pp.name AS period_name,
                    pp.start_date, pp.end_date, pp.pay_date, pp.status AS period_status,
                    COALESCE(pm.completed_amount, 0) AS completed_amount,
                    pm.last_payment_date
               FROM payroll p
               JOIN payroll_periods pp ON pp.id = p.payroll_period_id
               LEFT JOIN (
                   SELECT payroll_id, SUM(amount) AS completed_amount,
                          MAX(payment_date) AS last_payment_date
                     FROM payroll_payments
                    WHERE payment_status = \'COMPLETED\'
                    GROUP BY payroll_id
               ) pm ON pm.payroll_id = p.id
              WHERE p.employee_id = :emp
                AND (:released = 0 OR pp.status IN (\'FINALIZED\',\'PAID\'))
              ORDER BY pp.start_date DESC, pp.id DESC',
            ['emp' => $employeeId, 'released' => $releasedOnly ? 1 : 0]
        );
        foreach ($rows as &$row) {
            $payment = self::paymentFromCompletedAmount(
                (float) $row['net_pay'],
                (float) $row['completed_amount'],
                $row['last_payment_date']
            );
            $row['payment'] = $payment;
            $row['payment_status'] = $payment['status'];
            $row['amount_paid'] = $payment['amount_paid'];
            $row['balance_due'] = $payment['balance_due'];
            unset($row['completed_amount']);
        }
        unset($row);
        return $rows;
    }

    /**
     * Payslips in a period (Phase 15).
     *
     * @return list<array<string, mixed>>
     */
    public function forPeriod(int $periodId): array
    {
        return Database::select(
            'SELECT p.id, p.employee_id, p.gross_pay, p.net_pay, p.total_deductions, p.is_locked,
                    e.employee_number, e.first_name, e.middle_name, e.last_name, e.suffix,
                    d.name AS department_name
               FROM payroll p
               JOIN employees e ON e.id = p.employee_id
               LEFT JOIN departments d ON d.id = e.department_id
              WHERE p.payroll_period_id = :pid
              ORDER BY e.employee_number',
            ['pid' => $periodId]
        );
    }

    /** Guard: an employee may only read their own payslips (rules 13/14). */
    public function assertCanView(int $payrollId, int $employeeId, bool $hasPayrollPermission): void
    {
        if ($hasPayrollPermission) {
            return;
        }

        $owner = Database::scalar(
            'SELECT p.employee_id FROM payroll p JOIN payroll_periods pp ON pp.id=p.payroll_period_id WHERE p.id = :id AND pp.status IN (\'FINALIZED\',\'PAID\')',
            ['id' => $payrollId]
        );

        if ($owner === null) {
            throw new RuntimeException('Payslip not found.');
        }

        if ((int) $owner !== $employeeId) {
            throw new RuntimeException('You may only view your own payslips.');
        }
    }
}