<?php
/**
 * Attendance recording: the QR scan flow (Phase 6) and manual adjustments.
 * Every scan is written to attendance_logs as an immutable evidence trail
 * (Phase 18), including rejected attempts.
 *
 * Scan process: Scan QR -> Validate token -> Find employee -> Check today's
 * attendance -> Determine IN / OUT -> Apply rules -> Save -> Display result.
 */

declare(strict_types=1);

namespace App\Services;

use App\Core\Database;
use App\Core\Logger;
use App\Core\Request;
use App\Core\Settings;
use DateTimeImmutable;
use RuntimeException;
use Throwable;

final class AttendanceService
{
    public function __construct(
        private QrCodeService $qrService = new QrCodeService(),
        private AttendanceEngine $engine = new AttendanceEngine()
    ) {
    }

    /**
     * Record a scan from a QR token.
     *
     * @return array<string, mixed>
     * @throws RuntimeException with an operator-readable reason on rejection
     */
    public function scan(string $token, ?Request $request = null, ?DateTimeImmutable $at = null): array
    {
        $request   = $request ?? new Request();
        $scannedAt = $at ?? new DateTimeImmutable('now');

        try {
            $resolved = $this->qrService->resolve($token);
        } catch (RuntimeException $e) {
            $this->logScan(null, null, 'REJECTED', 'FAILED', null, $e->getMessage(), $request, $scannedAt);
            throw $e;
        } catch (Throwable $e) {
            Logger::error('QR resolve failed unexpectedly', ['error' => $e->getMessage()]);
            $this->logScan(null, null, 'REJECTED', 'FAILED', null, 'Invalid QR code.', $request, $scannedAt);
            throw new RuntimeException('Invalid QR code.');
        }

        if ($resolved === null) {
            $this->logScan(null, null, 'REJECTED', 'FAILED', null, 'Invalid QR code.', $request, $scannedAt);
            throw new RuntimeException('Invalid QR code.');
        }

        return $this->recordScan($resolved, $request, $scannedAt);
    }

    /**
     * Resolve a badge without recording anything.
     *
     * Used when a code arrives from an uploaded image rather than the camera:
     * the operator sees who it belongs to and whether it would be a time-in or
     * a time-out, and confirms before anything is written. Every rule in
     * recordScan() still applies, so the preview cannot promise an outcome the
     * real scan would refuse.
     *
     * @return array<string, mixed>
     */
    public function preview(string $token, ?Request $request = null, ?DateTimeImmutable $at = null): array
    {
        $request = $request ?? new Request();

        $resolved = $this->qrService->resolve($token);

        if ($resolved === null) {
            throw new RuntimeException('Invalid QR code.');
        }

        return $this->recordScan($resolved, $request, $at ?? new DateTimeImmutable('now'), true);
    }

    /**
     * Manual entry by employee, for an authenticated operator who cannot use a
     * camera. The caller is responsible for authorising the override.
     *
     * @return array<string, mixed>
     */
    public function scanForEmployee(int $employeeId, ?Request $request = null, ?DateTimeImmutable $at = null): array
    {
        $request   = $request ?? new Request();
        $scannedAt = $at ?? new DateTimeImmutable('now');

        try {
            $resolved = $this->qrService->resolveByEmployee($employeeId);
        } catch (RuntimeException $e) {
            $this->logScan(null, $employeeId, 'REJECTED', 'FAILED', null, $e->getMessage(), $request, $scannedAt);
            throw $e;
        } catch (Throwable $e) {
            Logger::error('Employee override resolve failed unexpectedly', ['error' => $e->getMessage()]);
            throw new RuntimeException('Unable to record attendance for that employee.');
        }

        return $this->recordScan($resolved, $request, $scannedAt);
    }

    /**
     * Apply a resolved badge to today's attendance.
     *
     * Shared by the token scan and the authenticated manual override so both
     * obey exactly the same rest-day, duplicate and completion rules.
     *
     * @param array{employee_id: int, qr_id: int, employee: array<string, mixed>} $resolved
     * @return array<string, mixed>
     */
    private function recordScan(array $resolved, Request $request, DateTimeImmutable $scannedAt, bool $dryRun = false): array
    {
        $employeeId = $resolved['employee_id'];
        if (\App\Core\DemoStaffScope::enabled()) {
            try { \App\Core\DemoStaffScope::assertIncluded($employeeId); }
            catch (RuntimeException $e) {
                if (!$dryRun) {
                    $this->logScan(null, $employeeId, 'REJECTED', 'FAILED', (int)$resolved['qr_id'],
                        $e->getMessage(), $request, $scannedAt);
                }
                throw $e;
            }
        }
        $qrId       = $resolved['qr_id'];
        $employee   = $resolved['employee'];
        // The row belongs to the shift occurrence, not necessarily the scan's
        // calendar day: an overnight badge read at 00:30 belongs to yesterday.
        $date       = $this->engine->attendanceDateFor($employeeId, $scannedAt);

        $existing = $this->engine->findAttendance($employeeId, $date);

        // Determine IN or OUT from today's attendance.
        $eventType = 'TIME_IN';
        $otAssignment = null;
        $otSession = null;
        if ($existing !== null && $existing['time_in'] !== null && $existing['time_out'] === null) {
            $eventType = 'TIME_OUT';
        } elseif ($existing !== null && $existing['time_in'] !== null && $existing['time_out'] !== null) {
            // After regular Time Out, a second pair of QR scans belongs ONLY
            // to a Manager-assigned OT request, never another regular session.
            $otAssignment = Database::selectOne(
                "SELECT * FROM overtime_requests
                  WHERE employee_id = :employee AND overtime_date = :day
                    AND status = 'APPROVED'
                    AND deleted_at IS NULL ORDER BY id DESC LIMIT 1",
                ['employee' => $employeeId, 'day' => $date]
            );
            if ($otAssignment === null) {
                $message = 'Regular attendance is already complete. No authorized OT session is assigned.';
                if (!$dryRun) { $this->logScan((int) $existing['id'], $employeeId, 'REJECTED', 'FAILED', $qrId, $message, $request, $scannedAt); }
                throw new RuntimeException($message);
            }
            $otSession = Database::selectOne(
                'SELECT * FROM overtime_scans WHERE overtime_request_id = :id LIMIT 1',
                ['id' => (int) $otAssignment['id']]
            );
            if ($otSession === null) {
                $eventType = 'OT_TIME_IN';
            } elseif ($otSession['ot_time_out'] === null) {
                $eventType = 'OT_TIME_OUT';
            } else {
                throw new RuntimeException('Authorized OT attendance is already complete. Duplicate scans are blocked.');
            }
            $assignedStart = new DateTimeImmutable($date . ' ' . (string) $otAssignment['start_time']);
            // For a regular 5:00 PM shift, early OT QR scans from 5:00 PM
            // are permitted. 5:00–5:30 PM is duty-free and nonpayable.
            $earlyScanAllowed = $assignedStart->format('H:i:s') === '17:30:00'
                ? new DateTimeImmutable($date . ' 17:00:00') : $assignedStart;
            if ($eventType === 'OT_TIME_IN' && $scannedAt < $earlyScanAllowed) {
                throw new RuntimeException('OT Time In is too early for the authorized assignment.');
            }
            $assignedEnd = new DateTimeImmutable($date . ' ' . (string) $otAssignment['end_time']);
            if ($assignedEnd <= $assignedStart) { $assignedEnd = $assignedEnd->modify('+1 day'); }
            if ($eventType === 'OT_TIME_IN' && $scannedAt >= $assignedEnd) {
                throw new RuntimeException('This OT assignment has ended. Request an attendance correction.');
            }
            if ($eventType === 'OT_TIME_OUT' && $scannedAt < new DateTimeImmutable((string) $otSession['ot_time_in'])) {
                throw new RuntimeException('OT Time Out cannot precede OT Time In.');
            }
        }

        // Duplicate scans of the same event type are rejected (Phase 7).
        $this->assertNotDuplicate($employeeId, $qrId, $request, $scannedAt, $eventType, $dryRun);

        $context = $this->engine->contextFor($employeeId, $date);

        // Standard regular QR window: one hour before regular shift start
        // through one hour after start (07:00 to 09:00 for an 08:00 shift).
        // This is checked SERVER-SIDE for preview and actual scan alike.
        // An employee who truly worked after cutoff can be recorded via an
        // authorised correction, never erased from their lawful earnings.
        if ($eventType === 'TIME_IN' && !$context['is_rest_day'] && $context['holiday'] === null) {
            $shiftStart = (string) ($context['shift']['start_time'] ?? Settings::string('attendance.default_time_in', '08:00:00'));
            $start = new DateTimeImmutable($date . ' ' . $shiftStart);
            $early = $start->modify('-60 minutes');
            $cutoff = $start->modify('+' . max(0, Settings::int('attendance.late_cutoff_minutes', 60)) . ' minutes')->modify('+59 seconds');
            if ($scannedAt < $early || $scannedAt > $cutoff) {
                $message = sprintf('Regular Time In is available only from %s to %s. Contact your Manager for verified attendance correction.',
                    $early->format('g:i A'), $cutoff->format('g:i A'));
                if (!$dryRun) {
                    $this->logScan($existing !== null ? (int) $existing['id'] : null,
                        $employeeId, 'REJECTED', 'FAILED', $qrId, $message, $request, $scannedAt);
                }
                throw new RuntimeException($message);
            }
        }

        if ($context['is_rest_day'] && !Settings::bool('attendance.allow_scan_on_rest_day', true)) {
            $message = 'Today is a scheduled rest day for this employee. Scanning is disabled.';
            if (!$dryRun) {
                $this->logScan(
                    $existing !== null ? (int) $existing['id'] : null,
                    $employeeId, 'REJECTED', 'FAILED', $qrId, $message, $request, $scannedAt
                );
            }
            throw new RuntimeException($message);
        }

        // A preview runs every check above and then stops here, so the operator
        // confirms the outcome the real scan would actually produce. Nothing
        // is written -- not the attendance row, not the scan count, not a log.
        if ($dryRun) {
            return [
                'event_type' => $eventType,
                'preview'    => true,
                'employee'   => [
                    'id'              => (int) $employee['id'],
                    'employee_number' => $employee['employee_number'],
                    'full_name'       => $this->fullName($employee),
                ],
            ];
        }

        return Database::transaction(
            function () use ($eventType, $employeeId, $date, $scannedAt, $context, $qrId, $employee, $request, $existing, $otAssignment, $otSession): array {
                $attendanceId = $existing !== null ? (int) $existing['id'] : null;

                if ($eventType === 'OT_TIME_IN' || $eventType === 'OT_TIME_OUT') {
                    $requestId = (int) $otAssignment['id'];
                    if ($eventType === 'OT_TIME_IN') {
                        Database::insert('overtime_scans', [
                            'overtime_request_id' => $requestId,
                            'employee_id' => $employeeId,
                            'ot_time_in' => $scannedAt->format('Y-m-d H:i:s'),
                            'payable_minutes' => 0,
                        ]);
                    } else {
                        $assignedStart = new DateTimeImmutable($date . ' ' . $otAssignment['start_time']);
                        $assignedEnd = new DateTimeImmutable($date . ' ' . $otAssignment['end_time']);
                        if ($assignedEnd <= $assignedStart) { $assignedEnd = $assignedEnd->modify('+1 day'); }
                        $actualIn = new DateTimeImmutable((string) $otSession['ot_time_in']);
                        $start = $actualIn > $assignedStart ? $actualIn : $assignedStart;
                        // Never count mandatory 5:00–5:30 PM duty-free break as OT.
                        if ($assignedStart->format('H:i:s') === '17:30:00') {
                            $breakEnd = new DateTimeImmutable($date . ' 17:30:00');
                            if ($start < $breakEnd) { $start = $breakEnd; }
                        }
                        $end = $scannedAt < $assignedEnd ? $scannedAt : $assignedEnd;
                        $minutes = $end > $start ? intdiv($end->getTimestamp() - $start->getTimestamp(), 60) : 0;
                        $minutes = min($minutes, max(0, (int) round((float) $otAssignment['hours'] * 60)), 240);
                        Database::update('overtime_scans', [
                            'ot_time_out' => $scannedAt->format('Y-m-d H:i:s'),
                            'payable_minutes' => $minutes,
                        ], ['id' => (int) $otSession['id']]);
                        Database::update('overtime_requests', ['total_hours' => round($minutes / 60, 2)], ['id' => $requestId]);
                    }
                    $updatedSession = Database::selectOne(
                        'SELECT * FROM overtime_scans WHERE overtime_request_id = :id', ['id' => $requestId]
                    );
                    $this->qrService->markScanned($qrId);
                    $this->logScan($attendanceId, $employeeId, $eventType, 'SUCCESS', $qrId, null, $request, $scannedAt);
                    return [
                        'event_type' => $eventType, 'attendance' => $existing,
                        'ot_session' => $updatedSession,
                        'employee' => [
                            'id' => (int) $employee['id'],
                            'employee_number' => $employee['employee_number'],
                            'full_name' => $this->fullName($employee),
                        ],
                    ];
                }

                if ($eventType === 'TIME_IN') {
                    if ($attendanceId === null) {
                        $attendanceId = Database::insert('attendance', [
                            'employee_id'     => $employeeId,
                            'attendance_date' => $date,
                            'time_in'         => $scannedAt->format('Y-m-d H:i:s'),
                            'source'          => 'QR',
                            'status'          => 'INCOMPLETE',
                            'is_rest_day'     => $context['is_rest_day'] ? 1 : 0,
                            'is_holiday'      => $context['holiday'] !== null ? 1 : 0,
                        ]);
                    } else {
                        Database::update('attendance', [
                            'time_in' => $scannedAt->format('Y-m-d H:i:s'),
                            'source'  => 'QR',
                        ], ['id' => $attendanceId]);
                    }
                } else {
                    Database::update('attendance', [
                        'time_out' => $scannedAt->format('Y-m-d H:i:s'),
                        'source'   => 'QR',
                    ], ['id' => $attendanceId]);
                }

                // Apply the attendance rules (Phase 7).
                $attendance = $this->engine->recalculate(
                    $this->engine->findAttendance($employeeId, $date)
                );

                $this->qrService->markScanned($qrId);
                $this->logScan($attendanceId, $employeeId, $eventType, 'SUCCESS', $qrId, null, $request, $scannedAt);

                return [
                    'event_type' => $eventType,
                    'attendance' => $attendance,
                    'employee'   => [
                        'id'              => (int) $employee['id'],
                        'employee_number' => $employee['employee_number'],
                        'full_name'       => $this->fullName($employee),
                        'department_id'   => $employee['department_id'],
                        'position_id'     => $employee['position_id'],
                    ],
                ];
            }
        );
    }
/**
     * Manual attendance entry or adjustment (Phase 7 / Phase 18).
     * Times are validated server-side and the engine recalculates the row.
     *
     * @param array<string, mixed> $data
     * @return array<string, mixed>
     */
    public function record(int $employeeId, array $data, ?int $userId = null): array
    {
        if (\App\Core\DemoStaffScope::enabled()) {
            \App\Core\DemoStaffScope::assertIncluded($employeeId);
        }
        $validator = \App\Core\Validator::make(
            $data,
            [
                'attendance_date' => 'required|date',
                'time_in'         => 'nullable|time',
                'time_out'        => 'nullable|time',
                'status'          => 'nullable|in:PRESENT,LATE,ABSENT,UNDERTIME,REST_DAY,HOLIDAY,LEAVE,INCOMPLETE',
                'remarks'         => 'nullable|string|max:255',
            ],
            ['attendance_date' => 'Attendance date']
        );

        if ($validator->fails()) {
            throw new \App\Core\ValidationException($validator->errors());
        }

        $validated = $validator->validated();
        $date      = (string) $validated['attendance_date'];
        $userId    = $userId ?? \App\Core\Auth::id();

        $timeIn  = $validated['time_in'] ?? null;
        $timeOut = $validated['time_out'] ?? null;

        // Overnight shifts (Phase 8) span midnight, so time-out may fall on
        // the calendar day after time-in. A time-out earlier than time-in is
        // therefore valid only for overnight shifts, and the stored timestamp
        // must use the following date. A time-out on the same date as time-in
        // must always be later.
        $context = $this->engine->contextFor($employeeId, $date);
        // A manual Time In/Out is permitted on Sunday as a time log only.
        // Sunday cannot become PRESENT, ABSENT, or ordinary overtime because
        // a caller selected an explicit status. Actual work is separately
        // verified/compensated through the authorized rest-day work process.
        if ($context['is_rest_day']) {
            $validated['status'] = 'REST_DAY';
        }
        $isOvernight = ($context['shift'] !== null && (int) ($context['shift']['is_overnight'] ?? 0) === 1);

        // Manual entries must not bypass the 09:00 regular Time In cutoff.
        // A supervisor may separately record independently VERIFIED work after
        // a correction approval; this is never a routine manual Time In.
        if ($timeIn !== null && !$context['is_rest_day'] && $context['holiday'] === null) {
            $shiftStart = (string) ($context['shift']['start_time'] ?? Settings::string('attendance.default_time_in', '08:00:00'));
            $shift = new DateTimeImmutable($date . ' ' . $shiftStart);
            $cutoff = $shift->modify('+' . max(0, Settings::int('attendance.late_cutoff_minutes', 60)) . ' minutes')->modify('+59 seconds');
            $early = $shift->modify('-60 minutes');
            $given = new DateTimeImmutable($date . ' ' . $this->normaliseTime((string) $timeIn));
            if ($given > $cutoff || $given < $early) {
                $correction = filter_var($data['verified_correction'] ?? false, FILTER_VALIDATE_BOOLEAN);
                $reason = trim((string) ($data['verification_reason'] ?? ''));
                $isManager = \App\Core\Auth::roleCode() === 'MANAGER';
                if (!$correction || !$isManager || mb_strlen($reason) < 10) {
                    throw new \App\Core\ValidationException(['time_in' =>
                        'Ordinary manual Time In is allowed only 7:00-9:00 AM for the standard 8:00 AM shift. Outside this window, Manager-approved verified correction with a reason is required.']);
                }
                $data['remarks'] = trim(($data['remarks'] ?? '') . ' [Verified correction: ' . $reason . ']');
                $validated['remarks'] = mb_substr($data['remarks'], 0, 255);
            }
        }

        if ($timeIn !== null && $timeOut !== null) {
            $inDatetime = new DateTimeImmutable($date . ' ' . $this->normaliseTime($timeIn));
            $outDatetime = new DateTimeImmutable($date . ' ' . $this->normaliseTime($timeOut));

            if ($isOvernight && $outDatetime <= $inDatetime) {
                $outDatetime = $outDatetime->modify('+1 day');
            }

            if ($outDatetime <= $inDatetime) {
                throw new \App\Core\ValidationException(['time_out' => 'Time-out must be after time-in.']);
            }

            $timeOut = $outDatetime->format('Y-m-d H:i:s');
        }

        $payload = [
            'time_in'     => $timeIn !== null ? $date . ' ' . $this->normaliseTime($timeIn) : null,
            'time_out'    => $timeOut !== null ? $timeOut : null,
            'source'      => 'MANUAL',
            'remarks'     => $validated['remarks'] ?? null,
            'adjusted_by' => $userId,
        ];

        return \App\Core\Database::transaction(function () use ($employeeId, $date, $payload, $userId, $validated): array {
            // A removed (soft-deleted) row still holds the unique (employee,
            // date) key: restore it instead of inserting a duplicate.
            $removed = \App\Core\Database::selectOne(
                'SELECT id FROM attendance WHERE employee_id = :emp AND attendance_date = :date AND deleted_at IS NOT NULL LIMIT 1',
                ['emp' => $employeeId, 'date' => $date]
            );
            if ($removed !== null) {
                \App\Core\Database::update('attendance', ['deleted_at' => null], ['id' => (int) $removed['id']]);
            }

            $existing = $this->engine->findAttendance($employeeId, $date);
            if ($existing !== null && strtoupper((string)($existing['source'] ?? '')) === 'QR') {
                throw new RuntimeException('An original QR attendance record already exists for this date. Preserve its raw scans and use the authorized correction workflow.');
            }

            if ($existing === null) {
                $attendanceId = \App\Core\Database::insert('attendance', array_merge($payload, [
                    'employee_id'     => $employeeId,
                    'attendance_date' => $date,
                    'status'          => $validated['status'] ?? 'INCOMPLETE',
                ]));

                \App\Core\AuditLogger::record(
                    \App\Core\AuditLogger::ATTENDANCE_CREATE,
                    'attendance',
                    $attendanceId,
                    sprintf('Created manual attendance for %s', $date),
                    null,
                    $payload
                );
            } else {
                \App\Core\AuditLogger::recordChanges(
                    \App\Core\AuditLogger::ATTENDANCE_UPDATE,
                    'attendance',
                    (int) $existing['id'],
                    $existing,
                    array_merge($existing, $payload)
                );

                \App\Core\Database::update('attendance', $payload, ['id' => (int) $existing['id']]);
                $attendanceId = (int) $existing['id'];
            }

            // Recalculate from the times (Phase 7).
            $attendance = $this->engine->recalculate(
                $this->engine->findAttendance($employeeId, $date)
            );

            // An explicit status overrides the engine only when supplied.
            if (isset($validated['status']) && $validated['status'] !== $attendance['status']) {
                \App\Core\Database::execute(
                    'UPDATE attendance SET status = :status WHERE id = :id',
                    ['status' => $validated['status'], 'id' => (int) $attendance['id']]
                );

                \App\Core\AuditLogger::record(
                    \App\Core\AuditLogger::ATTENDANCE_ADJUST,
                    'attendance',
                    (int) $attendance['id'],
                    sprintf('Status overridden for %s: %s -> %s', $date, $attendance['status'], $validated['status']),
                    ['status' => $attendance['status']],
                    ['status' => $validated['status']]
                );

                $attendance = $this->engine->findAttendance($employeeId, $date) ?? $attendance;
            }

            $this->logScan($attendanceId, $employeeId, 'MANUAL', 'SUCCESS', null, null, null);

            return $attendance;
        });
    }

    /**
     * Audited, record-ID based correction. QR raw scans are immutable.
     * A new date never inserts another attendance record. The payroll must be
     * calculated again if any DRAFT/FOR_REVIEW period was affected.
     */
    public function correctRecord(int $attendanceId, array $data): array
    {
        $existing = $this->findById($attendanceId);
        if ($existing === null) { throw new RuntimeException('Attendance record not found.'); }
        if (\App\Core\DemoStaffScope::enabled()) {
            \App\Core\DemoStaffScope::assertIncluded((int)$existing['employee_id']);
        }
        if (strtoupper((string)$existing['source']) === 'QR') {
            throw new RuntimeException('QR attendance timestamps are immutable. Use the verified correction workflow.');
        }
        if (\App\Core\Auth::employeeId() === (int)$existing['employee_id']) {
            throw new RuntimeException('Self-correction is not allowed. Ask the independent reviewer.');
        }
        $newDate = trim((string)($data['attendance_date'] ?? $existing['attendance_date']));
        $date = \DateTimeImmutable::createFromFormat('!Y-m-d', $newDate);
        if (!$date || $date->format('Y-m-d') !== $newDate) {
            throw new RuntimeException('Enter a valid attendance date.');
        }
        $reason = trim((string)($data['correction_reason'] ?? ''));
        if (mb_strlen($reason) < 10) {
            throw new RuntimeException('A correction reason of at least 10 characters is required.');
        }
        foreach (['time_in','time_out'] as $field) {
            $value = trim((string)($data[$field] ?? ''));
            if ($value !== '' && !preg_match('/^(?:[01]\d|2[0-3]):[0-5]\d$/', $value)) {
                throw new RuntimeException('Time In/Out must use HH:MM format.');
            }
        }
        $in = trim((string)($data['time_in'] ?? ''));
        $out = trim((string)($data['time_out'] ?? ''));
        if (($in === '') !== ($out === '')) {
            throw new RuntimeException('Both Time In and Time Out must be supplied for correction.');
        }
        if ($in !== '' && $out <= $in) {
            throw new RuntimeException('Time Out must be later than Time In for standard Mon-Sat shifts.');
        }
        $empId = (int)$existing['employee_id'];
        return \App\Core\Database::transaction(function() use ($attendanceId,$existing,$empId,$newDate,$reason,$in,$out): array {
            // Lock the row and check collisions in the same transaction.
            \App\Core\Database::run('SELECT id FROM attendance WHERE id = :id FOR UPDATE', ['id'=>$attendanceId]);
            $duplicate = \App\Core\Database::scalar(
                'SELECT id FROM attendance WHERE employee_id = :emp AND attendance_date = :date AND id <> :id LIMIT 1',
                ['emp'=>$empId,'date'=>$newDate,'id'=>$attendanceId]);
            if ($duplicate !== null) {
                throw new RuntimeException('Attendance already exists for the target date. Resolve the duplicate first.');
            }
            $dates = array_unique([(string)$existing['attendance_date'],$newDate]);
            foreach ($dates as $d) {
                $paid = \App\Core\Database::scalar(
                    "SELECT id FROM payroll_periods WHERE :d BETWEEN start_date AND end_date
                      AND status IN ('APPROVED','FINALIZED','PAID') AND deleted_at IS NULL LIMIT 1", ['d'=>$d]);
                if ($paid !== null) { throw new RuntimeException('Approved/finalized payroll is locked. Use an authorized audited payroll correction.'); }
            }
            $fields = [
                'attendance_date'=>$newDate,
                'time_in'=>$in === '' ? null : $newDate . ' ' . $in . ':00',
                'time_out'=>$out === '' ? null : $newDate . ' ' . $out . ':00',
                'source'=>'MANUAL',
                'adjusted_by'=>\App\Core\Auth::id(),
                'remarks'=>mb_substr(trim((string)($existing['remarks'] ?? '') . ' [Correction: ' . $reason . ']'),0,255),
            ];
            \App\Core\Database::update('attendance', $fields, ['id'=>$attendanceId]);
            $updated = $this->engine->recalculate($this->findById($attendanceId));
            \App\Core\AuditLogger::record(
                \App\Core\AuditLogger::ATTENDANCE_ADJUST, 'attendance', $attendanceId,
                'Attendance corrected: ' . $reason,
                ['attendance_date'=>$existing['attendance_date'],'time_in'=>$existing['time_in'],
                 'time_out'=>$existing['time_out'],'status'=>$existing['status']],
                ['attendance_date'=>$updated['attendance_date'],'time_in'=>$updated['time_in'],
                 'time_out'=>$updated['time_out'],'status'=>$updated['status']]
            );
            foreach ($dates as $d) {
                // Any already calculated, editable payroll is stale until re-run.
                \App\Core\Database::execute(
                    "UPDATE payroll_periods SET status='DRAFT' WHERE :d BETWEEN start_date AND end_date
                      AND status='FOR_REVIEW' AND deleted_at IS NULL", ['d'=>$d]);
            }
            return $updated;
        });
    }

/** Remove an attendance record: archived (soft delete), purged only via Data deletion. */
    public function delete(int $attendanceId, ?int $userId = null): array
    {
        $row = $this->findById($attendanceId);
        if ($row === null) {
            throw new RuntimeException('Attendance record not found.');
        }

        \App\Core\Database::update('attendance', ['deleted_at' => date('Y-m-d H:i:s')], ['id' => $attendanceId]);

        \App\Core\AuditLogger::record(
            \App\Core\AuditLogger::ATTENDANCE_DELETE,
            'attendance',
            $attendanceId,
            sprintf('Deleted attendance record on %s', $row['attendance_date']),
            $row,
            null
        );

        return ['id' => $attendanceId, 'deleted_at' => date('Y-m-d H:i:s')];
    }

    /** Restore a removed attendance record to its list. */
    public function restore(int $attendanceId, ?int $userId = null): array
    {
        $row = \App\Core\Database::selectOne(
            'SELECT * FROM attendance WHERE id = :id AND deleted_at IS NOT NULL',
            ['id' => $attendanceId]
        );

        if ($row === null) {
            throw new RuntimeException('Attendance record not found or is not archived.');
        }

        \App\Core\Database::update('attendance', ['deleted_at' => null], ['id' => $attendanceId]);

        \App\Core\AuditLogger::record(
            \App\Core\AuditLogger::ATTENDANCE_UPDATE,
            'attendance',
            $attendanceId,
            sprintf('Restored attendance record on %s', $row['attendance_date']),
            ['deleted_at' => $row['deleted_at']],
            null
        );

        return ['id' => $attendanceId];
    }

    /** @return array<string, mixed>|null */
    public function findById(int $attendanceId): ?array
    {
        return \App\Core\Database::selectOne(
            'SELECT a.*, e.employee_number, e.first_name, e.middle_name, e.last_name, e.suffix
               FROM attendance a
               JOIN employees e ON e.id = a.employee_id
              WHERE a.id = :id AND a.deleted_at IS NULL
              LIMIT 1',
            ['id' => $attendanceId]
        );
    }
/**
     * Attendance listing with filters (Phase 4 / Phase 17).
     *
     * @param array<string, mixed> $filters
     * @return array{items: list<array<string, mixed>>, total: int}
     */
    public function list(array $filters, int $page = 1, int $perPage = 25): array
    {
        $where  = ['1 = 1'];
        $params = [];
        if (!empty($filters['demo_staff_only'])) {
            $where[] = '1=1' . \App\Core\DemoStaffScope::excludingRoles('e.id')
                . \App\Core\DemoStaffScope::excludingDemoUsernames('e.id');
        }

        // Archive scope: false (default) hides removed rows, true shows
        // everything, only powers the per-list archive storage page.
        $archiveMode = strtolower(trim((string) ($filters['archived'] ?? 'false')));
        if ($archiveMode === 'only') {
            $where[] = 'a.deleted_at IS NOT NULL';
        } elseif (!filter_var($archiveMode, FILTER_VALIDATE_BOOLEAN)) {
            $where[] = 'a.deleted_at IS NULL';
        }

        if (!empty($filters['manager_employee_id'])) {
            $where[] = '(e.assigned_supervisor_id = :team_manager_id OR (e.assigned_supervisor_id IS NULL AND e.department_id = :team_department_id))';
            $params['team_manager_id'] = (int)$filters['manager_employee_id'];
            $params['team_department_id'] = (int)$filters['manager_department_id'];
        }

        if (!empty($filters['employee_id'])) {
            $where[] = 'a.employee_id = :employee_id';
            $params['employee_id'] = (int) $filters['employee_id'];
        }

        foreach (['date_from' => 'a.attendance_date >= :date_from', 'date_to' => 'a.attendance_date <= :date_to'] as $key => $clause) {
            if (!empty($filters[$key])) {
                $where[] = $clause;
                $params[$key] = (string) $filters[$key];
            }
        }

        // Sunday records may carry historical PRESENT labels even though the
        // current company rule makes every Sunday REST_DAY. Filter by the
        // effective classification, not the stale stored status.
        if (!empty($filters['status'])) {
            $where[] = "(CASE WHEN DAYOFWEEK(a.attendance_date) = 1 THEN 'REST_DAY' ELSE a.status END) = :status";
            $params['status'] = (string)$filters['status'];
        }
        if (!empty($filters['department_id'])) {
            $where[] = 'e.department_id = :department_id';
            $params['department_id'] = (int)$filters['department_id'];
        }

        $whereSql = implode(' AND ', $where);

        $total = (int) (\App\Core\Database::scalar(
            "SELECT COUNT(*) FROM attendance a JOIN employees e ON e.id = a.employee_id WHERE {$whereSql}",
            $params
        ) ?? 0);

        $perPage = max(1, $perPage);
        $offset  = max(0, ($page - 1) * $perPage);

        $items = \App\Core\Database::select(
            "SELECT a.*, e.employee_number, e.first_name, e.middle_name, e.last_name, e.suffix,
                    d.name AS department_name,
                    s.name AS shift_name,
                    u.username AS adjusted_by_username
               FROM attendance a
               JOIN employees e ON e.id = a.employee_id
               LEFT JOIN departments d ON d.id = e.department_id
               LEFT JOIN shifts s ON s.id = a.shift_id
               LEFT JOIN users u ON u.id = a.adjusted_by
              WHERE {$whereSql}
              ORDER BY a.attendance_date DESC, e.employee_number ASC
              LIMIT {$perPage} OFFSET {$offset}",
            $params
        );

        foreach ($items as &$item) {
            $item['full_name'] = $this->fullName($item);
            if ((new DateTimeImmutable((string)$item['attendance_date']))->format('w') === '0') {
                // Display the current Sunday classification even for older
                // manually recorded PRESENCE/OT data. No historical row is
                // silently overwritten by a read-only page request.
                $item['status'] = 'REST_DAY';
                $item['is_rest_day'] = 1;
                $item['late_minutes'] = 0;
                $item['undertime_minutes'] = 0;
                if (strtoupper((string)($item['source'] ?? '')) === 'MANUAL') {
                    $item['worked_hours'] = 0.0;
                    // Only VERIFIED OT requests may supply Sunday OT hours;
                    // never reuse a legacy manually inferred 9-hour value.
                    $item['overtime_hours'] = round((float)(Database::scalar(
                        "SELECT COALESCE(SUM(applied_hours), 0) FROM overtime_requests
                         WHERE employee_id = :emp AND overtime_date = :date
                           AND status = 'APPROVED' AND payroll_verified_at IS NOT NULL",
                        ['emp'=>(int)$item['employee_id'], 'date'=>(string)$item['attendance_date']]
                    ) ?? 0), 2);
                }
            }
        }
        unset($item);

        return ['items' => $items, 'total' => $total];
    }
/**
     * Today's attendance overview for the dashboard (Phase 16).
     *
     * @return array{summary: array<string, int>, recent: list<array<string, mixed>>}
     */
    public function todayOverview(?string $date = null, ?int $employeeId = null): array
    {
        $date = $date ?? date('Y-m-d');
        $attendanceScope = $employeeId !== null
            ? ' AND employee_id = :summary_employee'
            : \App\Core\DemoStaffScope::excludingRoles('attendance.employee_id') . \App\Core\DemoStaffScope::excludingDemoUsernames('attendance.employee_id');
        $logScope = $employeeId !== null
            ? ' AND al.employee_id = :log_employee'
            : \App\Core\DemoStaffScope::excludingRoles('al.employee_id') . \App\Core\DemoStaffScope::excludingDemoUsernames('al.employee_id');
        $summaryParams = [
            'date'      => $date,
            'present'   => 'PRESENT',
            'late'      => 'LATE',
            'absent'    => 'ABSENT',
            'undertime' => 'UNDERTIME',
            'leave'     => 'LEAVE',
            'holiday'   => 'HOLIDAY',
            'rest'      => 'REST_DAY',
        ];
        $logParams = ['date' => $date];
        if ($employeeId !== null) {
            $summaryParams['summary_employee'] = $employeeId;
            $logParams['log_employee'] = $employeeId;
        }

        $summary = Database::selectOne(
            'SELECT
                COUNT(*) AS total,
                COALESCE(SUM(CASE WHEN status = :present THEN 1 ELSE 0 END), 0) AS present,
                COALESCE(SUM(CASE WHEN status = :late THEN 1 ELSE 0 END), 0) AS late,
                COALESCE(SUM(CASE WHEN status = :absent THEN 1 ELSE 0 END), 0) AS absent,
                COALESCE(SUM(CASE WHEN status = :undertime THEN 1 ELSE 0 END), 0) AS undertime,
                COALESCE(SUM(CASE WHEN status = :leave THEN 1 ELSE 0 END), 0) AS on_leave,
                COALESCE(SUM(CASE WHEN status = :holiday THEN 1 ELSE 0 END), 0) AS holiday,
                COALESCE(SUM(CASE WHEN status = :rest THEN 1 ELSE 0 END), 0) AS rest_day,
                COALESCE(SUM(overtime_hours), 0) AS overtime_hours
               FROM attendance
              WHERE attendance_date = :date AND deleted_at IS NULL' . $attendanceScope,
            $summaryParams
        ) ?? [];

        $recent = Database::select(
            'SELECT al.id, al.event_type, al.scanned_at, al.result, al.message,
                    a.status AS attendance_status, a.time_in, a.time_out,
                    e.employee_number, e.first_name, e.middle_name, e.last_name, e.suffix,
                    d.name AS department_name
               FROM attendance_logs al
               LEFT JOIN attendance a ON a.id = al.attendance_id
               LEFT JOIN employees e ON e.id = al.employee_id
               LEFT JOIN departments d ON d.id = e.department_id
              WHERE DATE(al.scanned_at) = :date' . $logScope . '
                AND (a.id IS NULL OR a.deleted_at IS NULL)
              ORDER BY al.id DESC
              LIMIT 25',
            $logParams
        );

        foreach ($recent as &$item) {
            $item['full_name'] = $this->fullName($item);
        }
        unset($item);

        return ['summary' => $summary, 'recent' => $recent];
    }

    /** Reject a repeated scan of the same event type inside the cut-off window. */
    private function assertNotDuplicate(
        int $employeeId,
        int $qrId,
        Request $request,
        DateTimeImmutable $scannedAt,
        string $eventType,
        bool $dryRun = false
    ): void {
        $cutoffHours = Settings::int('attendance.scan_cutoff_hours', 12);
        if ($cutoffHours <= 0) {
            return;
        }

        // Only the same event type is a duplicate: a time-out must be allowed
        // after a time-in.
        $last = Database::selectOne(
            'SELECT id, event_type, scanned_at FROM attendance_logs
              WHERE employee_id = :emp
                AND event_type = :event_type
                AND result = :success
              ORDER BY id DESC
              LIMIT 1',
            ['emp' => $employeeId, 'event_type' => $eventType, 'success' => 'SUCCESS']
        );

        if ($last === null) {
            return;
        }

        $seconds = $scannedAt->getTimestamp() - strtotime((string) $last['scanned_at']);

        if ($seconds < ($cutoffHours * 3600)) {
            $message = sprintf(
                'A %s was already recorded at %s. Duplicate scans are not allowed.',
                strtolower(str_replace('_', '-', (string) $last['event_type'])),
                date('g:i A', strtotime((string) $last['scanned_at']))
            );

            if (!$dryRun) {
                $this->logScan(null, $employeeId, 'REJECTED', 'FAILED', $qrId, $message, $request, $scannedAt);
            }
            throw new RuntimeException($message);
        }
    }

    /** Immutable evidence-trail entry (Phase 18). */
    private function logScan(
        ?int $attendanceId,
        ?int $employeeId,
        string $eventType,
        string $result,
        ?int $qrId,
        ?string $message,
        ?Request $request,
        ?DateTimeImmutable $scannedAt = null
    ): void {
        // `result` is ENUM('SUCCESS','FAILED'): anything else is rejected by
        // MySQL in strict mode and the evidence-trail row would be lost, so
        // normalise it here and every caller stays safe.
        $result = in_array($result, ['SUCCESS', 'FAILED'], true) ? $result : 'FAILED';

        try {
            Database::insert('attendance_logs', [
                'attendance_id' => $attendanceId,
                'employee_id'   => $employeeId,
                'event_type'    => $eventType,
                'scanned_at'    => ($scannedAt ?? new DateTimeImmutable())->format('Y-m-d H:i:s'),
                'qr_code_id'    => $qrId,
                'result'        => $result,
                'message'       => $message === null ? null : mb_substr($message, 0, 255),
                'ip_address'    => $request?->ip(),
                'user_agent'    => $request?->userAgent(),
                'recorded_by'   => \App\Core\Auth::id(),
            ]);
        } catch (Throwable $e) {
            Logger::error('Failed to write attendance log', ['error' => $e->getMessage()]);
        }
    }

    /** Human-readable "First Middle Last Suffix". */
    private function fullName(array $employee): string
    {
        return trim(implode(' ', array_filter([
            $employee['first_name'] ?? '',
            $employee['middle_name'] ?? '',
            $employee['last_name'] ?? '',
            $employee['suffix'] ?? '',
        ], static fn (mixed $v): bool => (string) $v !== '')));
    }

    /** Accept HH:MM or HH:MM:SS and always return HH:MM:SS. */
    private function normaliseTime(string $time): string
    {
        return strlen($time) === 5 ? $time . ':00' : $time;
    }
}
