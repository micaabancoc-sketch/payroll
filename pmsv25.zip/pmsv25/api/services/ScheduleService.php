<?php
/**
 * Work schedules and shifts (Phase 8).
 *
 * Supports multiple shifts per day, breaks, rest days, overnight shifts,
 * configurable grace periods and employee-specific schedules.
 */

declare(strict_types=1);

namespace App\Services;

use App\Core\AuditLogger;
use App\Core\Database;
use App\Core\ValidationException;
use App\Core\Validator;
use RuntimeException;

final class ScheduleService
{
    public const SCHEDULE_TYPES = ['REGULAR', 'FLEXIBLE', 'NIGHT_SHIFT', 'ROTATING', 'CUSTOM'];
    public const DAYS = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];

    /** @return list<array<string, mixed>> */
    public function all(bool $archivedOnly = false): array
    {
        $schedules = Database::select(
            $archivedOnly
                ? 'SELECT * FROM work_schedules WHERE deleted_at IS NOT NULL ORDER BY name'
                : 'SELECT * FROM work_schedules WHERE deleted_at IS NULL ORDER BY is_default DESC, name'
        );

        foreach ($schedules as &$schedule) {
            $schedule['days'] = $this->days((int) $schedule['id']);
        }
        unset($schedule);

        return $schedules;
    }

    /** @return array<string, mixed>|null */
    public function find(int $id): ?array
    {
        $schedule = Database::selectOne(
            'SELECT * FROM work_schedules WHERE id = :id AND deleted_at IS NULL',
            ['id' => $id]
        );

        if ($schedule === null) {
            return null;
        }

        $schedule['days'] = $this->days($id);
        $schedule['employee_count'] = (int) (Database::scalar(
            'SELECT COUNT(*) FROM employees
              WHERE work_schedule_id = :id AND deleted_at IS NULL AND archived_at IS NULL',
            ['id' => $id]
        ) ?? 0);

        return $schedule;
    }

    /**
     * Per-weekday rows for a schedule, always returning all seven days.
     *
     * @return list<array<string, mixed>>
     */
    public function days(int $scheduleId): array
    {
        $rows = Database::select(
            'SELECT wsd.day_of_week, wsd.shift_id, wsd.is_rest_day,
                    s.code AS shift_code, s.name AS shift_name,
                    s.start_time, s.end_time, s.break_start, s.break_end,
                    s.is_overnight, s.grace_period_minutes, s.required_hours
               FROM work_schedule_days wsd
               LEFT JOIN shifts s ON s.id = wsd.shift_id
              WHERE wsd.work_schedule_id = :id
              ORDER BY wsd.day_of_week',
            ['id' => $scheduleId]
        );

        $byDay = [];
        foreach ($rows as $row) {
            $byDay[(int) $row['day_of_week']] = $row;
        }

        // Always return the full week so the UI can render every day.
        $out = [];
        for ($day = 0; $day <= 6; $day++) {
            if (isset($byDay[$day])) {
                $out[] = $byDay[$day];
                continue;
            }

            $out[] = [
                'day_of_week'          => $day,
                'shift_id'             => null,
                'is_rest_day'          => 1,
                'shift_code'           => null,
                'shift_name'           => null,
                'start_time'           => null,
                'end_time'             => null,
                'break_start'          => null,
                'break_end'            => null,
                'is_overnight'         => 0,
                'grace_period_minutes' => null,
                'required_hours'       => null,
            ];
        }

        return $out;
    }
/**
     * Create or update a schedule with its weekday rows (Phase 8).
     *
     * @param array<string, mixed> $data
     * @return array<string, mixed>
     */
    public function save(array $data, ?int $id = null): array
    {
        $validator = Validator::make(
            $data,
            [
                'code'          => 'required|string|max:50',
                'name'          => 'required|string|max:150',
                'schedule_type' => 'nullable|in:' . implode(',', self::SCHEDULE_TYPES),
                'description'   => 'nullable|string|max:255',
                'is_default'    => 'nullable|boolean',
                'is_active'     => 'nullable|boolean',
                'days'          => 'nullable|array',
            ]
        );

        if ($validator->fails()) {
            throw new ValidationException($validator->errors());
        }

        $validated = $validator->validated();

        $scheduleId = Database::transaction(function () use ($data, $validated, $id): int {
            $payload = [
                'code'          => $validated['code'],
                'name'          => $validated['name'],
                'schedule_type' => $validated['schedule_type'] ?? 'REGULAR',
                'description'   => $validated['description'] ?? null,
                'is_default'    => (int) ($validated['is_default'] ?? 0),
                'is_active'     => (int) ($validated['is_active'] ?? 1),
            ];

            // Only one default schedule may exist.
            if ((int) $payload['is_default'] === 1) {
                Database::execute('UPDATE work_schedules SET is_default = 0 WHERE is_default = 1');
            }

            if ($id === null) {
                $scheduleId = Database::insert('work_schedules', $payload);
            } else {
                Database::update('work_schedules', $payload, ['id' => $id]);
                $scheduleId = $id;
            }

            // Replace the weekday rows.
            Database::delete('work_schedule_days', ['work_schedule_id' => $scheduleId]);

            $days = $data['days'] ?? [];
            if (is_array($days)) {
                foreach ($days as $day) {
                    if (!is_array($day) || !isset($day['day_of_week'])) {
                        continue;
                    }

                    $dayOfWeek = (int) $day['day_of_week'];
                    if ($dayOfWeek < 0 || $dayOfWeek > 6) {
                        continue;
                    }

                    $shiftId = $day['shift_id'] ?? null;

                    Database::insert('work_schedule_days', [
                        'work_schedule_id' => $scheduleId,
                        'day_of_week'      => $dayOfWeek,
                        'shift_id'         => $shiftId !== null && $shiftId !== '' ? (int) $shiftId : null,
                        'is_rest_day'      => (int) ($day['is_rest_day'] ?? ($shiftId === null || $shiftId === '' ? 1 : 0)),
                    ]);
                }
            }

            AuditLogger::record(
                AuditLogger::SCHEDULE_CHANGED,
                'work_schedule',
                $scheduleId,
                sprintf('%s work schedule "%s"', $id === null ? 'Created' : 'Updated', $validated['name'])
            );

            return $scheduleId;
        });

        return $this->find($scheduleId) ?? [];
    }

    /** @return list<array<string, mixed>> */
    public function shifts(bool $archivedOnly = false): array
    {
        return Database::select(
            $archivedOnly
                ? 'SELECT * FROM shifts WHERE deleted_at IS NOT NULL ORDER BY name'
                : 'SELECT * FROM shifts WHERE deleted_at IS NULL ORDER BY is_active DESC, name'
        );
    }
/**
     * Create or update a shift (Phase 8).
     *
     * @param array<string, mixed> $data
     * @return array<string, mixed>
     */
    public function saveShift(array $data, ?int $id = null): array
    {
        $validator = Validator::make(
            $data,
            [
                'code'                 => 'required|string|max:50',
                'name'                 => 'required|string|max:150',
                'start_time'           => 'required|time',
                'end_time'             => 'required|time',
                'break_start'          => 'nullable|time',
                'break_end'            => 'nullable|time',
                'is_overnight'         => 'nullable|boolean',
                'grace_period_minutes' => 'nullable|integer',
                'required_hours'       => 'nullable|numeric|min:0',
                'description'          => 'nullable|string|max:255',
                'is_active'            => 'nullable|boolean',
            ]
        );

        if ($validator->fails()) {
            throw new ValidationException($validator->errors());
        }

        $validated = $validator->validated();

        $payload = [
            'code'                 => $validated['code'],
            'name'                 => $validated['name'],
            'start_time'           => $this->normaliseTime((string) $validated['start_time']),
            'end_time'             => $this->normaliseTime((string) $validated['end_time']),
            'break_start'          => isset($validated['break_start']) ? $this->normaliseTime((string) $validated['break_start']) : null,
            'break_end'            => isset($validated['break_end']) ? $this->normaliseTime((string) $validated['break_end']) : null,
            'is_overnight'         => (int) ($validated['is_overnight'] ?? 0),
            'grace_period_minutes' => (int) ($validated['grace_period_minutes'] ?? 5),
            'required_hours'       => (float) ($validated['required_hours'] ?? 8.00),
            'description'          => $validated['description'] ?? null,
            'is_active'            => (int) ($validated['is_active'] ?? 1),
        ];

        // A non-overnight shift must not cross midnight.
        if ((int) $payload['is_overnight'] === 0 && strcmp($payload['end_time'], $payload['start_time']) <= 0) {
            throw new ValidationException([
                'end_time' => 'End time must be after start time (or mark the shift as overnight).',
            ]);
        }

        $shiftId = Database::transaction(function () use ($payload, $id): int {
            if ($id === null) {
                return Database::insert('shifts', $payload);
            }

            Database::update('shifts', $payload, ['id' => $id]);

            return $id;
        });

        AuditLogger::record(
            AuditLogger::SCHEDULE_CHANGED,
            'shift',
            $shiftId,
            sprintf('%s shift "%s"', $id === null ? 'Created' : 'Updated', $validated['name'])
        );

        return Database::selectOne('SELECT * FROM shifts WHERE id = :id', ['id' => $shiftId]) ?? [];
    }

    /** Soft-delete a work schedule (archived → Data deletion can purge it). */
    public function delete(int $id): array
    {
        $existing = $this->find($id);
        if ($existing === null) {
            throw new RuntimeException('Work schedule not found.');
        }
        $inUse = (int) (Database::scalar(
            'SELECT COUNT(*) FROM employees WHERE work_schedule_id = :id AND deleted_at IS NULL AND archived_at IS NULL',
            ['id' => $id]
        ) ?? 0);
        if ($inUse > 0) {
            throw new ValidationException(['schedule' => 'This schedule is assigned to employees. Reassign them before deleting.']);
        }
        Database::update('work_schedules', ['deleted_at' => date('Y-m-d H:i:s')], ['id' => $id]);
        AuditLogger::record(AuditLogger::SCHEDULE_CHANGED, 'work_schedule', $id, sprintf('Deleted work schedule "%s"', $existing['name'] ?? $id), $existing, null);
        return ['id' => $id];
    }

    /** Soft-delete a shift. */
    public function deleteShift(int $id): array
    {
        $existing = Database::selectOne('SELECT * FROM shifts WHERE id = :id AND deleted_at IS NULL', ['id' => $id]);
        if ($existing === null) {
            throw new RuntimeException('Shift not found.');
        }
        $inUse = (int) (Database::scalar('SELECT COUNT(*) FROM work_schedule_days WHERE shift_id = :id', ['id' => $id]) ?? 0);
        if ($inUse > 0) {
            throw new ValidationException(['shift' => 'This shift is used by work schedules. Remove it from schedules before deleting.']);
        }
        Database::update('shifts', ['deleted_at' => date('Y-m-d H:i:s')], ['id' => $id]);
        AuditLogger::record(AuditLogger::SCHEDULE_CHANGED, 'shift', $id, sprintf('Deleted shift "%s"', $existing['name'] ?? $id), $existing, null);
        return ['id' => $id];
    }

    /** Restore an archived work schedule to its list. */
    public function restore(int $id): array
    {
        $existing = Database::selectOne(
            'SELECT * FROM work_schedules WHERE id = :id AND deleted_at IS NOT NULL',
            ['id' => $id]
        );

        if ($existing === null) {
            throw new RuntimeException('Work schedule not found or is not archived.');
        }

        Database::update('work_schedules', ['deleted_at' => null], ['id' => $id]);

        AuditLogger::record(
            AuditLogger::SCHEDULE_CHANGED,
            'work_schedule',
            $id,
            sprintf('Restored work schedule "%s"', $existing['name'] ?? $id),
            ['deleted_at' => $existing['deleted_at']],
            null
        );

        return $this->find($id) ?? [];
    }

    /** Restore an archived shift to its list. */
    public function restoreShift(int $id): array
    {
        $existing = Database::selectOne(
            'SELECT * FROM shifts WHERE id = :id AND deleted_at IS NOT NULL',
            ['id' => $id]
        );

        if ($existing === null) {
            throw new RuntimeException('Shift not found or is not archived.');
        }

        Database::update('shifts', ['deleted_at' => null], ['id' => $id]);

        AuditLogger::record(
            AuditLogger::SCHEDULE_CHANGED,
            'shift',
            $id,
            sprintf('Restored shift "%s"', $existing['name'] ?? $id),
            ['deleted_at' => $existing['deleted_at']],
            null
        );

        return Database::selectOne('SELECT * FROM shifts WHERE id = :id', ['id' => $id]) ?? [];
    }

    /** Assign a schedule to an employee (Phase 8: employee-specific schedules). */
    public function assignToEmployee(int $employeeId, ?int $scheduleId): array
    {
        if ($scheduleId !== null) {
            $exists = Database::scalar(
                'SELECT id FROM work_schedules WHERE id = :id AND deleted_at IS NULL',
                ['id' => $scheduleId]
            );

            if ($exists === null) {
                throw new ValidationException(['work_schedule_id' => 'The selected schedule does not exist.']);
            }
        }

        $employee = Database::selectOne(
            'SELECT id, first_name, middle_name, last_name, suffix FROM employees WHERE id = :id AND deleted_at IS NULL',
            ['id' => $employeeId]
        );

        if ($employee === null) {
            throw new RuntimeException('Employee not found.');
        }

        Database::update('employees', ['work_schedule_id' => $scheduleId], ['id' => $employeeId]);

        AuditLogger::record(
            AuditLogger::SCHEDULE_CHANGED,
            'employee',
            $employeeId,
            sprintf('Assigned work schedule to employee %s', trim(implode(' ', array_filter([
                $employee['first_name'], $employee['middle_name'], $employee['last_name'], $employee['suffix'],
            ])))),
            null,
            ['work_schedule_id' => $scheduleId]
        );

        return ['id' => $employeeId, 'work_schedule_id' => $scheduleId];
    }

    private function normaliseTime(string $time): string
    {
        return strlen($time) === 5 ? $time . ':00' : $time;
    }
}
