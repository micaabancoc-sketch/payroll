<?php
/**
 * Holiday management (Phase 9).
 *
 * Attendance and payroll automatically recognise holidays: the attendance
 * engine checks this table for every date and payroll pays paid holidays.
 */

declare(strict_types=1);

namespace App\Services;

use App\Core\AuditLogger;
use App\Core\Database;
use App\Core\ValidationException;
use App\Core\Validator;
use DateTimeImmutable;
use RuntimeException;

final class HolidayService
{
    public const TYPES = ['REGULAR', 'SPECIAL', 'OPTIONAL', 'REST'];

    /** @return list<array<string, mixed>> */
    public function all(?int $year = null, ?string $type = null, bool $archivedOnly = false): array
    {
        $where  = [$archivedOnly ? 'h.deleted_at IS NOT NULL' : 'h.deleted_at IS NULL'];
        $params = [];

        if (!$archivedOnly) {
            $where[] = "h.status = 'ACTIVE'";
        }

        if ($year !== null) {
            $where[] = '(YEAR(h.holiday_date) = :year OR h.is_recurring = 1)';
            $params['year'] = $year;
        }

        if ($type !== null) {
            $where[] = 'h.holiday_type = :type';
            $params['type'] = $type;
        }

        return Database::select(
            sprintf(
                'SELECT h.* FROM holidays h WHERE %s ORDER BY h.holiday_date',
                implode(' AND ', $where)
            ),
            $params
        );
    }

    /** @return array<string, mixed>|null */
    public function find(int $id): ?array
    {
        return Database::selectOne(
            'SELECT * FROM holidays WHERE id = :id AND deleted_at IS NULL',
            ['id' => $id]
        );
    }

    /**
     * Create a holiday (Phase 9).
     *
     * @param array<string, mixed> $data
     * @return array<string, mixed>
     */
    public function create(array $data): array
    {
        $validator = Validator::make(
            $data,
            [
                'name'         => 'required|string|min:2|max:150',
                'holiday_date' => 'required|date',
                'holiday_type' => 'nullable|in:' . implode(',', self::TYPES),
                'is_paid'      => 'nullable|boolean',
                'is_recurring' => 'nullable|boolean',
                'status'       => 'nullable|in:ACTIVE,INACTIVE',
                'remarks'      => 'nullable|string|max:255',
            ]
        );

        if ($validator->fails()) {
            throw new ValidationException($validator->errors());
        }

        $validated = $validator->validated();

        // Only one holiday per date.
        $existing = Database::scalar(
            'SELECT id FROM holidays WHERE holiday_date = :date AND deleted_at IS NULL',
            ['date' => $validated['holiday_date']]
        );

        if ($existing !== null) {
            throw new ValidationException(['holiday_date' => 'A holiday already exists on this date.']);
        }

        $id = Database::insert('holidays', [
            'name'         => $validated['name'],
            'holiday_date' => $validated['holiday_date'],
            'holiday_type' => $validated['holiday_type'] ?? 'REGULAR',
            'is_paid'      => (int) ($validated['is_paid'] ?? 1),
            'is_recurring' => (int) ($validated['is_recurring'] ?? 0),
            'status'       => $validated['status'] ?? 'ACTIVE',
            'remarks'      => $validated['remarks'] ?? null,
        ]);

        AuditLogger::record(
            AuditLogger::HOLIDAY_CHANGED,
            'holiday',
            $id,
            sprintf('Created holiday "%s" on %s', $validated['name'], $validated['holiday_date'])
        );

        return $this->find($id) ?? [];
    }
/**
     * Update a holiday (Phase 9).
     *
     * @param array<string, mixed> $data
     * @return array<string, mixed>
     */
    public function update(int $id, array $data): array
    {
        $existing = $this->find($id);

        if ($existing === null) {
            throw new RuntimeException('Holiday not found.');
        }

        $validator = Validator::make(
            $data,
            [
                'name'         => 'nullable|string|min:2|max:150',
                'holiday_date' => 'nullable|date',
                'holiday_type' => 'nullable|in:' . implode(',', self::TYPES),
                'is_paid'      => 'nullable|boolean',
                'is_recurring' => 'nullable|boolean',
                'status'       => 'nullable|in:ACTIVE,INACTIVE',
                'remarks'      => 'nullable|string|max:255',
            ]
        );

        if ($validator->fails()) {
            throw new ValidationException($validator->errors());
        }

        $validated = $validator->validated();

        $payload = [];
        foreach (['name', 'holiday_date', 'holiday_type', 'status', 'remarks'] as $field) {
            if (isset($validated[$field])) {
                $payload[$field] = $validated[$field];
            }
        }

        foreach (['is_paid', 'is_recurring'] as $field) {
            if (isset($validated[$field])) {
                $payload[$field] = (int) $validated[$field];
            }
        }

        if (isset($payload['holiday_date'])) {
            $clash = Database::scalar(
                'SELECT id FROM holidays WHERE holiday_date = :date AND deleted_at IS NULL AND id != :id',
                ['date' => $payload['holiday_date'], 'id' => $id]
            );

            if ($clash !== null) {
                throw new ValidationException(['holiday_date' => 'A holiday already exists on this date.']);
            }
        }

        if ($payload !== []) {
            Database::update('holidays', $payload, ['id' => $id]);
        }

        AuditLogger::recordChanges(
            AuditLogger::HOLIDAY_CHANGED,
            'holiday',
            $id,
            $existing,
            array_merge($existing, $payload)
        );

        return $this->find($id) ?? [];
    }

    /** Restore an archived holiday to its list. */
    public function restore(int $id): array
    {
        $existing = Database::selectOne(
            'SELECT * FROM holidays WHERE id = :id AND deleted_at IS NOT NULL',
            ['id' => $id]
        );

        if ($existing === null) {
            throw new RuntimeException('Holiday not found or is not archived.');
        }

        Database::update('holidays', ['deleted_at' => null], ['id' => $id]);

        AuditLogger::record(
            AuditLogger::HOLIDAY_CHANGED,
            'holiday',
            $id,
            sprintf('Restored holiday "%s"', $existing['name']),
            ['deleted_at' => $existing['deleted_at']],
            null
        );

        return $this->find($id) ?? [];
    }

    /** Delete a holiday (Phase 9). */
    public function delete(int $id): array
    {
        $existing = $this->find($id);

        if ($existing === null) {
            throw new RuntimeException('Holiday not found.');
        }

        Database::update('holidays', ['deleted_at' => date('Y-m-d H:i:s')], ['id' => $id]);

        AuditLogger::record(
            AuditLogger::HOLIDAY_CHANGED,
            'holiday',
            $id,
            sprintf('Deleted holiday "%s"', $existing['name']),
            $existing,
            null
        );

        return ['id' => $id];
    }
/**
     * Upcoming holidays, used by the dashboard (Phase 16).
     *
     * @return list<array<string, mixed>>
     */
    public function upcoming(int $limit = 6): array
    {
        $today = new DateTimeImmutable('today');

        $rows = array_merge(
            $this->all((int) $today->format('Y')),
            $this->all((int) $today->format('Y') + 1)
        );

        $upcoming = [];

        foreach ($rows as $row) {
            $date = new DateTimeImmutable((string) $row['holiday_date']);

            // Recurring holidays shift to the current year.
            if ((int) $row['is_recurring'] === 1) {
                $date = $today->setDate(
                    (int) $today->format('Y'),
                    (int) $date->format('n'),
                    (int) $date->format('j')
                );

                if ($date < $today) {
                    $date = $date->modify('+1 year');
                }
            }

            if ($date < $today) {
                continue;
            }

            $upcoming[] = [
                'id'           => (int) $row['id'],
                'name'         => $row['name'],
                'holiday_date' => $date->format('Y-m-d'),
                'holiday_type' => $row['holiday_type'],
                'is_paid'      => (int) $row['is_paid'],
                'is_recurring' => (int) $row['is_recurring'],
            ];
        }

        usort($upcoming, static fn (array $a, array $b): int => strcmp($a['holiday_date'], $b['holiday_date']));

        return array_slice($upcoming, 0, max(1, $limit));
    }
}