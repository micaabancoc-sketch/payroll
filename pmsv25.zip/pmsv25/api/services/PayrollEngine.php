<?php
/**
 * Payroll calculation engine (Phase 13).
 *
 * Combines: Employee + Schedule + Attendance + Leave + Overtime + Holidays +
 * Allowances + Deductions -> PAYROLL.
 *
 * Every rate, multiplier and deduction rule is read from system_settings
 * (Phase 12 / Phase 19) — nothing about payroll is hard-coded.
 *
 * Development rules enforced here:
 *   9.  Attendance automatically feeds payroll calculations.
 *   8.  Only approved overtime is paid.
 *   10. Finalized payroll is locked.
 */

declare(strict_types=1);

namespace App\Services;

use App\Core\Database;
use App\Core\Settings;

final class PayrollEngine
{
    public function __construct(private AttendanceEngine $engine = new AttendanceEngine())
    {
    }

    /** @return array<string, float|int|string> */
    public function settings(): array
    {
        return [
            'pay_frequency'                  => Settings::string('payroll.pay_frequency', 'SEMI_MONTHLY'),
            'annual_paid_day_divisor'       => Settings::float('payroll.annual_paid_day_divisor', 313.0),
            'fixed_monthly_policy'          => true,
            // Fixed salary is paid per cutoff; unworked rest days receive no
            // separate extra earnings under this demo compensation plan.
            'rest_days_paid'               => Settings::bool('payroll.rest_days_paid', false),
            'working_days_per_month'         => Settings::float('payroll.working_days_per_month', 22.0),
            'working_hours_per_day'          => Settings::float('payroll.working_hours_per_day', 8.0),
            'pro_rate_monthly'               => Settings::bool('payroll.pro_rate_monthly', true),
            'overtime_enabled'               => Settings::bool('payroll.overtime_enabled', true),
            'overtime_multiplier'            => Settings::float('payroll.overtime_multiplier', 1.25),
            'overtime_rest_day_multiplier'   => Settings::float('payroll.overtime_rest_day_multiplier', 1.30),
            'overtime_holiday_multiplier'    => Settings::float('payroll.overtime_holiday_multiplier', 2.00),
            'night_differential_multiplier'  => Settings::float('payroll.night_differential_multiplier', 1.10),
            'night_shift_start'              => Settings::string('payroll.night_shift_start', '22:00:00'),
            'night_shift_end'                => Settings::string('payroll.night_shift_end', '06:00:00'),
            'holiday_rate_multiplier'        => Settings::float('payroll.holiday_rate_multiplier', 1.00),
            'late_deduction_enabled'         => Settings::bool('payroll.late_deduction_enabled', true),
            'late_deduction_type'            => Settings::string('payroll.late_deduction_type', 'PER_MINUTE'),
            'late_deduction_amount'          => Settings::float('payroll.late_deduction_amount', 2.00),
            'undertime_deduction_enabled'    => Settings::bool('payroll.undertime_deduction_enabled', true),
            'undertime_deduction_type'       => Settings::string('payroll.undertime_deduction_type', 'PER_HOUR'),
            'undertime_deduction_amount'     => Settings::float('payroll.undertime_deduction_amount', 60.00),
            'absence_deduction_enabled'      => Settings::bool('payroll.absence_deduction_enabled', true),
            'unpaid_leave_deduction_enabled' => Settings::bool('payroll.unpaid_leave_deduction_enabled', true),
            'loan_deduction_enabled'         => Settings::bool('payroll.loan_deduction_enabled', true),
            // Government contributions and withholding tax (effective-dated
            // schedules maintained in Settings -> Contributions).
            'statutory_enabled'                        => Settings::bool('statutory.enabled', true),
            'statutory_sss_enabled'                    => Settings::bool('statutory.sss_enabled', true),
            'statutory_philhealth_enabled'             => Settings::bool('statutory.philhealth_enabled', true),
            'statutory_pagibig_enabled'                => Settings::bool('statutory.pagibig_enabled', true),
            'statutory_tax_enabled'                    => Settings::bool('statutory.tax_enabled', true),
            'statutory_allocation_basis'               => Settings::string('statutory.allocation_basis', 'CALENDAR_DAYS'),
            'statutory_periods_per_month'              => Settings::int('statutory.periods_per_month', 2),
            'statutory_pagibig_salary_base'            => Settings::string('statutory.pagibig_salary_base', 'MONTHLY_BASIC_PLUS_ALLOWANCES'),
            'statutory_tax_exclude_non_taxable_allowances' => Settings::bool('statutory.tax_exclude_non_taxable_allowances', true),
            'statutory_tax_subtract_contributions'     => Settings::bool('statutory.tax_subtract_contributions', true),
        ];
    }

    /**
     * Choose the paid-day factor separately from the fixed kinsenas salary.
     * The 2024 NWPC guide illustrates 313 for six-day and 261 for five-day
     * schedules when unworked rest days are excluded but listed statutory days
     * are accounted for. Different holidays/contracts require an HR review.
     * The company can override the two factors in Settings.
     */
    private function paidDayDivisor(array $employee): float
    {
        if (Settings::bool('payroll.rest_days_paid', false)) {
            return Settings::float('payroll.annual_paid_day_divisor', 365.0);
        }
        $days = 6;
        $scheduleId = (int) ($employee['work_schedule_id'] ?? 0);
        if ($scheduleId > 0) {
            $configured = Database::scalar(
                'SELECT COUNT(DISTINCT day_of_week) FROM work_schedule_days
                   WHERE work_schedule_id = :id AND is_rest_day = 0 AND shift_id IS NOT NULL',
                ['id'=>$scheduleId]
            );
            if ($configured !== null && (int)$configured > 0) {
                $days = (int)$configured;
            }
        }
        return $days <= 5
            ? Settings::float('payroll.unpaid_rest_5day_divisor', 261.0)
            : Settings::float('payroll.unpaid_rest_6day_divisor', 313.0);
    }

    /** Daily rate for an employee. */
    public function dailyRate(array $employee): float
    {
        $basic = (float) $employee['basic_salary'];

        return match ((string) $employee['salary_type']) {
            'DAILY'  => $basic,
            'HOURLY' => $basic * Settings::float('payroll.working_hours_per_day', 8.0),
            // Fixed basic kinsenas is independent of this divisor. Select the
            // valid annual paid-day factor for the contractual workweek.
            'MONTHLY', 'SEMI_MONTHLY' => FixedMonthlyPolicy::dailyRate($basic, $this->paidDayDivisor($employee)),
            default  => $basic / max(1, Settings::float('payroll.working_days_per_month', 22.0)),
        };
    }

    /** Hourly rate for an employee. */
    public function hourlyRate(array $employee): float
    {
        return match ((string) $employee['salary_type']) {
            'HOURLY' => (float) $employee['basic_salary'],
            default  => $this->dailyRate($employee) / max(1, Settings::float('payroll.working_hours_per_day', 8.0)),
        };
    }

    /** Leave type of an approved leave request. */
    private function leaveTypeIdFor(int $leaveRequestId): int
    {
        return (int) (Database::scalar(
            'SELECT leave_type_id FROM leave_requests WHERE id = :id',
            ['id' => $leaveRequestId]
        ) ?? 0);
    }
/**
     * Calculate one employee's payroll for a period.
     *
     * @param array<string, mixed> $employee
     * @return array<string, mixed>
     */
    /**
     * A missing scan in a COMPLETED cutoff is a reversible, payroll-only
     * presumed absence. In an open/future cutoff it remains an exception.
     * Incomplete scans and unverified QR rest-day work still require review.
     */
    public function attendanceExceptions(array $employee, string $startDate, string $endDate): array
    {
        $employeeId = (int) $employee['id'];
        $hiredOn = (string) ($employee['date_hired'] ?? '');
        $today = (new \DateTimeImmutable('today'))->format('Y-m-d');
        $cutoffFinished = $endDate < $today;
        $rows = Database::select('SELECT attendance_date,status,time_in,time_out,source FROM attendance WHERE employee_id=:id AND deleted_at IS NULL AND attendance_date BETWEEN :start AND :end',
            ['id'=>$employeeId,'start'=>$startDate,'end'=>$endDate]);
        $byDay = [];
        foreach ($rows as $row) { $byDay[(string)$row['attendance_date']] = $row; }
        $exceptions = [];
        for ($day=new \DateTimeImmutable($startDate); $day<=new \DateTimeImmutable($endDate); $day=$day->modify('+1 day')) {
            $date = $day->format('Y-m-d');
            if (($hiredOn !== '' && $date < $hiredOn) || $date > $today) { continue; }
            $context = $this->engine->contextFor($employeeId,$date);
            if ($context['is_rest_day']) {
                $restRow = $byDay[$date] ?? null;
                // Manual rest-day Time In/Out is a non-payable TIME LOG by
                // default, not proof of actual authorized Sunday work. QR
                // scans are stronger evidence and stay for work verification.
                // Independently verified rest-day OT is paid through its own
                // authorized overtime request, never via attendance hours.
                if ($restRow !== null && $restRow['time_in'] !== null && $restRow['time_out'] !== null
                    && strtoupper((string)($restRow['source'] ?? '')) !== 'MANUAL') {
                    $verified = Database::scalar(
                        "SELECT COUNT(*) FROM overtime_requests
                         WHERE employee_id=:emp AND overtime_date=:date
                           AND status='APPROVED' AND payroll_verified_at IS NOT NULL",
                        ['emp'=>$employeeId,'date'=>$date]
                    );
                    if ((int)$verified === 0) {
                        $exceptions[] = ['date'=>$date,'reason'=>'REST_DAY_WORK_REQUIRES_VERIFIED_PREMIUM_REVIEW'];
                    }
                }
                continue;
            }
            if ($context['holiday'] !== null) { continue; }
            $row = $byDay[$date] ?? null;
            if ($row === null) {
                if (!$cutoffFinished && $this->engine->leaveFor($employeeId, $date) === null) {
                    $exceptions[] = ['date'=>$date,'reason'=>'MISSING_SCAN_REQUIRES_HR_VERIFICATION'];
                }
            } elseif ($row['status'] === 'INCOMPLETE' ||
                     (in_array($row['status'], ['PRESENT','LATE','UNDERTIME'], true) && ($row['time_in'] === null || $row['time_out'] === null))) {
                $exceptions[] = ['date'=>$date,'reason'=>'INCOMPLETE_ATTENDANCE_REQUIRES_HR_VERIFICATION'];
            } elseif ($row['status'] === 'ABSENT' && $row['source'] === 'AUTO' && !$cutoffFinished) {
                $exceptions[] = ['date'=>$date,'reason'=>'AUTO_ABSENCE_REQUIRES_HR_CONFIRMATION'];
            }
        }
        return $exceptions;
    }

    private function assertAttendanceVerified(array $employee, string $startDate, string $endDate): void
    {
        $issues = $this->attendanceExceptions($employee,$startDate,$endDate);
        if ($issues !== []) {
            $first = $issues[0];
            throw new \RuntimeException(sprintf('Attendance verification required for employee #%d: %d unresolved date(s); first %s (%s). No payroll calculated or absence created.',
                (int)$employee['id'],count($issues),$first['date'],$first['reason']));
        }
    }

    public function calculateEmployee(array $employee, string $startDate, string $endDate, bool $provisionalDraft = false): array
    {
        $settings = $this->settings();
        $employeeId = (int) $employee['id'];

        // In an OPEN cutoff, missing scans stay unresolved. In a COMPLETED
        // cutoff they become reversible payroll-only presumed absences.
        // Raw attendance/QR evidence is never manufactured or overwritten.
        $attendanceIssues = $provisionalDraft
            ? $this->attendanceExceptions($employee, $startDate, $endDate)
            : [];
        if (!$provisionalDraft) {
            $this->assertAttendanceVerified($employee, $startDate, $endDate);
        }

        $attendance = Database::select(
            'SELECT * FROM attendance
              WHERE employee_id = :emp
                AND deleted_at IS NULL
                AND attendance_date >= :start
                AND attendance_date <= :end
              ORDER BY attendance_date',
            ['emp' => $employeeId, 'start' => $startDate, 'end' => $endDate]
        );

        if ($provisionalDraft && $attendanceIssues !== []) {
            // An incomplete scan is not a confirmed PRESENT, and legacy AUTO
            // ABSENT is not a confirmed ABSENT. Exclude those dates entirely
            // from the estimate, keeping their raw attendance rows untouched.
            $unresolvedDates = array_fill_keys(array_column($attendanceIssues, 'date'), true);
            $attendance = array_values(array_filter(
                $attendance,
                static fn(array $row): bool => !isset($unresolvedDates[(string)$row['attendance_date']])
            ));
        }

        $dailyRate  = $this->dailyRate($employee);
        $hourlyRate = $this->hourlyRate($employee);

        // A Sunday time log is not a scheduled workday or an extra paid day.
        $workingDays = 0.0;
        $presentDays = 0.0;
        $absentDays  = 0.0;
        $leaveDays   = 0.0;
        $unpaidLeaveDays = 0.0;
        $lateMinutes = 0;
        $undertimeMinutes = 0;

        $basicPay      = 0.0;
        $overtimeHours = 0.0;
        $overtimePay   = 0.0;
        $holidayPay    = 0.0;
        $nightHours    = 0.0;
        $attendanceDates = [];

        foreach ($attendance as $row) {
            $isSunday = (new \DateTimeImmutable((string)$row['attendance_date']))->format('w') === '0';
            // Older manually entered Sundays might still say PRESENT and 9h
            // OT. Do not let stale labels create regular pay or deductions.
            $status = $isSunday ? 'REST_DAY' : (string)$row['status'];
            $attendanceDates[(string) $row['attendance_date']] = true;
            if ($status !== 'REST_DAY') { $workingDays += 1.0; }

            switch ($status) {
                case 'PRESENT':
                case 'LATE':
                case 'UNDERTIME':
                case 'INCOMPLETE':
                    $presentDays += 1.0;
                    $basicPay    += $dailyRate;
                    break;

                case 'ABSENT':
                    $absentDays += 1.0;
                    break;

                case 'LEAVE':
                    $leaveDays += 1.0;

                    // Paid leave still earns basic pay; unpaid leave is deducted below.
                    $leaveTypeId = (int) $row['leave_request_id'] !== 0
                        ? $this->leaveTypeIdFor((int) $row['leave_request_id'])
                        : 0;

                    $isPaid = true;
                    if ($leaveTypeId > 0) {
                        $isPaid = (int) (Database::scalar(
                            'SELECT is_paid FROM leave_types WHERE id = :id',
                            ['id' => $leaveTypeId]
                        ) ?? 1) === 1;
                    }

                    if ($isPaid) {
                        $basicPay += $dailyRate;
                    } else {
                        $unpaidLeaveDays += 1.0;
                    }
                    break;

                case 'HOLIDAY':
                    // A day the attendance ledger classified as HOLIDAY.
                    // Holiday pay is a separately classified earning (code
                    // 'HOLIDAY') and is NOT part of basic salary, so it must
                    // not inflate $basicPay: the 13th-month computation and the
                    // "Basic Pay" line both rely on basic_pay holding only
                    // regular basic earnings. It is added once to $holidayPay
                    // and counted exactly once in gross pay. Paid holidays that
                    // nobody recorded are picked up by the calendar sweep after
                    // this loop (see below), never in addition to this branch.
                    $holiday = $this->engine->holidayFor((string) $row['attendance_date']);

                    if ($holiday !== null && (int) $holiday['is_paid'] === 1) {
                        $holidayPay += $dailyRate * (float) $settings['holiday_rate_multiplier'];
                    }
                    break;

                case 'REST_DAY':
                    // No extra regular day pay or automatic deduction. If
                    // there was genuine authorized Sunday work it is paid
                    // separately via verified overtime_requests below.
                    break;
            }

            if ($status !== 'REST_DAY') {
                $lateMinutes      += (int) $row['late_minutes'];
                $undertimeMinutes += (int) $row['undertime_minutes'];
            }

            if ((float) $row['overtime_hours'] > 0) {
                $overtimeHours += (float) $row['overtime_hours'];
            }
        }

        // Payroll-only automatic absence after the COMPLETE cutoff ends.
        // A non-scan is a presumed absence, not proof of actual absence:
        // keep each date in the snapshot for correction and audit, and never
        // forge a QR scan or persist a confirmed attendance row here.
        $autoAbsentDates = [];
        $hiredOn = (string) ($employee['date_hired'] ?? '');
        if ($endDate < (new \DateTimeImmutable('today'))->format('Y-m-d')) {
            for ($day = new \DateTimeImmutable($startDate); $day <= new \DateTimeImmutable($endDate); $day = $day->modify('+1 day')) {
                $date = $day->format('Y-m-d');
                if (($hiredOn !== '' && $date < $hiredOn) || isset($attendanceDates[$date])) { continue; }
                $context = $this->engine->contextFor($employeeId, $date);
                if ($context['is_rest_day'] || $context['holiday'] !== null) { continue; }
                $leave = $this->engine->leaveFor($employeeId, $date);
                $workingDays += 1.0;
                $attendanceDates[$date] = true;
                if ($leave !== null) {
                    $leaveDays += 1.0;
                    if ((int)$leave['is_paid'] === 1) {
                        $basicPay += $dailyRate;
                    } else {
                        $unpaidLeaveDays += 1.0;
                    }
                    continue;
                }
                $absentDays += 1.0;
                $autoAbsentDates[] = $date;
            }
        }

        // Paid holidays are a calendar entitlement, not an attendance event.
        // Nothing ever writes a HOLIDAY attendance row for a holiday nobody
        // worked or scanned (markAbsences() and the reconciler deliberately skip
        // rest days and holidays), so reading the attendance ledger alone paid a
        // regular holiday 0.00 - the 'HOLIDAY' branch above was effectively
        // unreachable outside manual attendance. Walk the period calendar
        // instead and pay every *paid* holiday that has no attendance row of its
        // own:
        //   - a date that does have a row was already settled above (basic pay,
        //     paid leave, overtime or the 'HOLIDAY' branch), so it is skipped
        //     and the day can never be paid twice;
        //   - a holiday dated before date_hired is not paid at all.
        // The amount and the classification are identical to the 'HOLIDAY'
        // branch, so gross pay, payroll items and the snapshot stay consistent.
        $hiredOn = (string) ($employee['date_hired'] ?? '');

        for (
            $calendarDay = new \DateTimeImmutable($startDate);
            $calendarDay <= new \DateTimeImmutable($endDate);
            $calendarDay = $calendarDay->modify('+1 day')
        ) {
            $dateString = $calendarDay->format('Y-m-d');

            if (isset($attendanceDates[$dateString])) {
                continue;
            }

            if ($hiredOn !== '' && $dateString < $hiredOn) {
                continue;
            }

            $holiday = $this->engine->holidayFor($dateString);

            if ($holiday !== null && (int) $holiday['is_paid'] === 1) {
                $holidayPay += $dailyRate * (float) $settings['holiday_rate_multiplier'];
            }
        }

        // Our fixed-monthly employee policy: the STANDARD kinsenas basic is
        // always monthly salary / 2, NOT (count of attendance rows * day rate).
        // A different number of workdays in either half does not change basic.
        // Salary is prorated only for a hire date within this cutoff.  A real
        // termination date requires the final-pay workflow to calculate it.
        $fixedMonthly = in_array(strtoupper((string) $employee['salary_type']), ['MONTHLY', 'SEMI_MONTHLY'], true);
        if ($fixedMonthly) {
            $basicPay = FixedMonthlyPolicy::cutoffBasic(
                (float) $employee['basic_salary'], $startDate, $endDate, $hiredOn
            );
            // No separate extra payment for an unworked paid regular holiday:
            // the fixed salary already includes it. Holiday duty premiums
            // still require verified attendance/assignment-based treatment.
            $holidayPay = 0.0;
        }

        // Overtime pay: only APPROVED overtime is paid (rule 8). The multiplier
        // is picked per request type, so rest-day and holiday OT are higher.
        // DECLINED assignments are never payable: decline() reverses applied
        // attendance hours, and the status filter below excludes them, so no
        // declined hours can leak into pay (no duplicates either — applied_hours
        // is the single source of truth, capped at recorded attendance).
        // Archived requests are still honoured here: archiving hides a request
        // from the lists but does not undo an approval — cancel/revoke it
        // instead if the hours should no longer be paid.
        if ((bool) $settings['overtime_enabled']) {
            $approved = Database::select(
                "SELECT ot_type, COALESCE(SUM(applied_hours), 0) AS hours
                   FROM overtime_requests
                  WHERE employee_id = :emp
                    AND status = 'APPROVED'
                    AND payroll_verified_at IS NOT NULL
                    AND overtime_date >= :start
                    AND overtime_date <= :end
                  GROUP BY ot_type",
                ['emp' => $employeeId, 'start' => $startDate, 'end' => $endDate]
            );

            $paidHours = 0.0;

            foreach ($approved as $group) {
                $type  = (string) $group['ot_type'];
                $hours = (float) $group['hours'];
                $rate  = $hourlyRate * $this->multiplierFor($type);

                $overtimePay += $hours * $rate;
                $paidHours   += $hours;
            }

            // Manual/legacy attendance.overtime_hours is never evidence of OT.
            // The verified request's applied_hours is the single payable source.
            $overtimeHours = $paidHours;
        }

        if (!(bool)$settings['overtime_enabled'] || $overtimePay <= 0) { $overtimeHours = 0.0; }

        // Night differential is paid only for hours inside the night window.
        $nightHours = $this->nightHoursFor($employeeId, $startDate, $endDate);
        $nightPay   = 0.0;

        if ($nightHours > 0 && (float) $settings['night_differential_multiplier'] > 1.0) {
            $nightPay = round(
                $nightHours * $hourlyRate
                * ((float) $settings['night_differential_multiplier'] - 1.0),
                2
            );
        }

        // Allowances assigned to the employee (Phase 12).
        $allowancesTotal      = 0.0;
        $nonTaxableAllowances = 0.0;
        $earnings             = [];
        $deductions           = [];

        if ($basicPay > 0) {
            $earnings[] = ['code' => 'BASIC', 'name' => 'Basic Pay', 'amount' => round($basicPay, 2)];
        }

        if ($overtimePay > 0) {
            $earnings[] = [
                'code'    => 'OT',
                'name'    => 'Overtime',
                'amount'  => $overtimePay,
                'remarks' => sprintf('%.2f hour(s)', $overtimeHours),
            ];
        }

        if ($nightPay > 0) {
            $earnings[] = [
                'code'    => 'ND',
                'name'    => 'Night Differential',
                'amount'  => $nightPay,
                'remarks' => sprintf('%.2f hour(s)', $nightHours),
            ];
        }

        if ($holidayPay > 0) {
            $earnings[] = ['code' => 'HOLIDAY', 'name' => 'Holiday Pay', 'amount' => round($holidayPay, 2)];
        }

        // No allowances under the approved project scope. Keep historic columns
        // for compatibility, but never issue or include allowance earnings.
        $allowancesTotal = 0.0;
        $nonTaxableAllowances = 0.0;

        // Manual adjustments are NEVER silent payroll edits. HR proposes,
        // Manager approves, and only the target unlocked period receives them.
        $adjustmentEarnings = 0.0;
        $adjustmentDeductions = 0.0;
        $approvedAdjustments = Database::select(
            "SELECT a.id,a.kind,a.amount,a.reason FROM payroll_adjustments a
              JOIN payroll_periods pp ON pp.id=a.payroll_period_id
             WHERE a.employee_id=:emp AND pp.start_date=:start AND pp.end_date=:end
               AND a.status='APPROVED' AND pp.deleted_at IS NULL",
            ['emp'=>$employeeId,'start'=>$startDate,'end'=>$endDate]
        );
        foreach ($approvedAdjustments as $adjustment) {
            $amount = round((float)$adjustment['amount'],2);
            $line = ['code'=>'ADJ-' . $adjustment['id'],
                'name'=>'Approved Payroll Adjustment', 'amount'=>$amount,
                'remarks'=>(string)$adjustment['reason']];
            if ($adjustment['kind'] === 'EARNING') {
                $adjustmentEarnings += $amount;
                $earnings[] = $line;
            } else {
                $adjustmentDeductions += $amount;
                $deductions[] = $line;
            }
        }

        // Late deduction (Phase 12 — configurable method and amount).
        $lateDeduction = 0.0;

        if ((bool) $settings['late_deduction_enabled'] && $lateMinutes > 0) {
            $lateDeduction = $this->lateDeduction($lateMinutes, $hourlyRate, $dailyRate, $settings);
        }

        // Undertime deduction.
        $undertimeDeduction = 0.0;

        if ((bool) $settings['undertime_deduction_enabled'] && $undertimeMinutes > 0) {
            $undertimeDeduction = $this->undertimeDeduction($undertimeMinutes, $hourlyRate, $dailyRate, $settings);
        }

        // Absence deduction (Phase 13) - "no work, no pay", charged ONCE.
        //
        // An ABSENT day is already unpaid: the attendance loop above accrues
        // basic pay only for days actually worked or covered by a paid leave,
        // so an absent day contributes 0.00 to $basicPay and therefore 0.00 to
        // gross pay - the day's rate is removed by the accrual itself.
        // Withholding absent_days x daily_rate on top of that charged the same
        // absent day twice; in a period where nothing was recorded it left a
        // whole period of wages as deductions against a 0.00 gross and produced
        // a NEGATIVE net pay (the employee owed the company money). The rule is
        // now enforced once, by the accrual, and the column stays 0.00 so the
        // payroll table, the itemised payslip and the existing API shape are
        // unchanged. payroll.absence_deduction_enabled is no longer consulted:
        // "no work, no pay" is delivered by the accrual, and honouring the switch
        // would mean charging the day twice when it is on (the old, broken
        // behaviour) or paying absent days when it is off.
        $absenceDeduction = $fixedMonthly ? round($absentDays * $dailyRate, 2) : 0.0;

        // Unpaid leave deduction (Phase 10 / Phase 13) - same rule as absence.
        //
        // A LEAVE row whose leave type is unpaid accrues no basic pay above, so
        // deducting those days again here withheld the day twice for exactly the
        // same reason. The days are still recorded in leave_days (and in the
        // payroll row), and unpaidLeaveDeduction() still reports what the leave
        // is worth, so nothing is hidden - it is simply not charged twice.
        // payroll.unpaid_leave_deduction_enabled is no longer consulted for the
        // same reason as the absence switch above.
        $leaveDeduction = $fixedMonthly ? round($unpaidLeaveDays * $dailyRate, 2) : 0.0;

        // Fixed deductions assigned to the employee (Phase 12).
        $otherDeductions = round($adjustmentDeductions, 2);

        // Loan instalments proposed in this run, keyed back to the loan they pay
        // for. The engine stays read-only: PayrollService stores the list in the
        // payslip snapshot at calculation time and commits the rows to the
        // loan_payments ledger (moving the balances) only when the period is
        // marked PAID, never while a draft is being calculated (Phase 3A).
        $loanAllocations = [];

        // Statutory contributions and withholding tax are computed from the
        // effective-dated schedules, never from a fixed employee deduction.
        $statutoryService = new StatutoryDeductionService();
        $statutoryEnabled = $statutoryService->enabled($settings);

        $employeeDeductions = Database::select(
            "SELECT ed.amount,ed.total_amount,ed.deducted_amount,ed.id AS assignment_id, d.name, d.code, d.frequency
               FROM employee_deductions ed
               JOIN deductions d ON d.id = ed.deduction_id
              WHERE ed.employee_id = :emp AND ed.is_active = 1 AND ed.deleted_at IS NULL
                AND ed.total_amount IS NOT NULL AND ed.authorization_reference IS NOT NULL
                AND d.is_active = 1 AND d.deleted_at IS NULL
                AND (COALESCE(ed.effective_from, d.effective_from) IS NULL
                     OR COALESCE(ed.effective_from, d.effective_from) <= :cutoff_end)
                AND (COALESCE(ed.effective_to, d.effective_to) IS NULL
                     OR COALESCE(ed.effective_to, d.effective_to) >= :cutoff_start)",
            ['emp' => $employeeId, 'cutoff_start' => $startDate, 'cutoff_end' => $endDate]
        );

        foreach ($employeeDeductions as $item) {
            $amount = (float) $item['amount'];

            // Assignments carrying a statutory code are ignored while the
            // statutory engine is on, so SSS / PhilHealth / Pag-IBIG / TAX can
            // never be charged twice (they are kept for history and for
            // installs that switch the feature off).
            if ($statutoryEnabled
                && in_array(strtoupper((string) $item['code']), StatutoryDeductionService::RESERVED_DEDUCTION_CODES, true)) {
                continue;
            }

            if ($amount <= 0) {
                continue;
            }
            // Monthly company-authorized deduction is split over two kinsenas.
            // Keep the odd centavo in the first cutoff; both parts reconcile.
            if (strtoupper((string) ($item['frequency'] ?? 'PERIOD')) === 'MONTHLY') {
                $cents = (int) round($amount * 100);
                $amount = (((int) substr($endDate, 8, 2)) === 15
                    ? (int) ceil($cents / 2) : (int) floor($cents / 2)) / 100;
            }
            // Cap per-cutoff amount to remaining authorized balance. Only confirmed PAID
            // periods advance ed.deducted_amount; drafts never change the ledger.
            $remaining = round(max(0, (float)$item['total_amount']-(float)$item['deducted_amount']),2);
            $amount = round(min($amount,$remaining), 2);
            if ($amount <= 0) { continue; }
            $otherDeductions += $amount;
            $deductions[] = [
                'code'   => $item['code'],
                'name'   => $item['name'],
                'amount' => round($amount, 2),
            ];
        }
        // Active loans are repaid in instalments spread across the pay periods
        // of one month (Phase 3A). A SEMI_MONTHLY payroll withdraws HALF the
        // monthly deduction per period, not the whole figure: charging the
        // full month on every run repaid the same money twice. The instalment
        // is capped at the outstanding balance, which makes the final payment
        // exact. The engine only proposes; the ledger write happens at PAID.
        if ((bool) $settings['loan_deduction_enabled']) {
            $loans = Database::select(
                "SELECT id, loan_type, monthly_deduction, balance
                   FROM loans
                  WHERE employee_id = :emp AND status = 'ACTIVE' AND balance > 0
                    AND start_date <= :end_date
                    AND ((loan_type IN ('SSS_SALARY_LOAN','PAGIBIG_MPL') AND agency_verified_at IS NOT NULL AND deduction_authorization_reference IS NOT NULL)
                         OR (loan_type NOT IN ('SSS_SALARY_LOAN','PAGIBIG_MPL') AND released_at IS NOT NULL AND deduction_authorization_reference IS NOT NULL))
                    AND DATE(released_at) <= :end_date2
                  ORDER BY CASE WHEN loan_type IN ('SSS_SALARY_LOAN','PAGIBIG_MPL') THEN 0 ELSE 1 END, id",
                ['emp' => $employeeId, 'end_date' => $endDate, 'end_date2' => $endDate]
            );

            foreach ($loans as $loan) {
                $outstanding = round((float) $loan['balance'], 2);
                $amount      = round(min(
                    $this->loanInstalmentForPeriod((float) $loan['monthly_deduction'], $settings),
                    $outstanding
                ), 2);

                if ($amount <= 0) {
                    continue;
                }

                $otherDeductions += $amount;
                $loanAllocations[] = [
                    'loan_id'        => (int) $loan['id'],
                    'amount'         => $amount,
                    'balance_before' => $outstanding,
                    'balance_after'  => round($outstanding - $amount, 2),
                ];
                $deductions[] = [
                    'code'    => 'LOAN',
                    'loan_id' => (int) $loan['id'],
                    'name'    => sprintf('Loan (%s)', $loan['loan_type']),
                    'amount'  => $amount,
                    'remarks' => sprintf('Balance %.2f', $outstanding),
                ];
            }
        }
// Gross pay and totals (Phase 13 example layout).
        $grossPay = round($basicPay + $overtimePay + $nightPay + $holidayPay + $allowancesTotal + $adjustmentEarnings, 2);

        // Government contributions (SSS, PhilHealth, Pag-IBIG) and BIR
        // withholding tax. Contributions are monthly amounts allocated to the
        // period, the tax uses the table of the payroll frequency, and only the
        // employee share is deducted - employer shares are reported separately.
        $statutory = $statutoryService->calculate([
            'employee'               => $employee,
            'start_date'             => $startDate,
            'end_date'               => $endDate,
            'monthly_basic'          => $fixedMonthly ? round((float) $employee['basic_salary'], 2) : round($dailyRate * max(1.0, (float) $settings['working_days_per_month']), 2),
            'monthly_allowances'     => round($allowancesTotal, 2),
            // BIR regular taxable compensation must account for unpaid basic time.
            'gross_pay'              => max(0, round($grossPay - $lateDeduction - $undertimeDeduction - $absenceDeduction - $leaveDeduction, 2)),
            'non_taxable_allowances' => round($nonTaxableAllowances, 2),
            'settings'               => $settings,
        ]);

        $statutoryDeductions = (float) $statutory['employee_total'];

        // Protect net salary from overdraft caused by optional company loans.
        // Mandatory/other dues are measured first; agency loans have priority
        // in the preceding query. No loan payment is recorded for an unpaid
        // installment; the shortfall remains in the outstanding loan balance.
        $loanShortfalls = [];
        $requestedLoanTotal = array_sum(array_map(
            static fn(array $item): float => (float) $item['amount'], $loanAllocations
        ));
        $nonLoanDeductions = round(
            $lateDeduction + $undertimeDeduction + $absenceDeduction + $leaveDeduction
            + ($otherDeductions - $requestedLoanTotal) + $statutoryDeductions, 2
        );
        if ($nonLoanDeductions > $grossPay + 0.001) {
            throw new \RuntimeException('Non-loan deductions exceed gross pay for employee #' . $employeeId
                . '. Resolve the payroll exception before approval.');
        }
        $loanAvailable = round(max(0, $grossPay - $nonLoanDeductions), 2);
        $newAllocations = [];
        $loanApprovedAmounts = [];
        foreach ($loanAllocations as $allocated) {
            $wanted = round((float) $allocated['amount'], 2);
            $approved = round(min($wanted, $loanAvailable), 2);
            if ($approved < $wanted) {
                $loanShortfalls[] = [
                    'loan_id' => (int) $allocated['loan_id'],
                    'scheduled_amount' => $wanted, 'deducted_amount' => $approved,
                    'shortfall' => round($wanted - $approved, 2),
                    'reason' => 'INSUFFICIENT_SALARY_ADMIN_REVIEW',
                ];
            }
            $loanApprovedAmounts[(int) $allocated['loan_id']] = $approved;
            if ($approved > 0) {
                $allocated['amount'] = $approved;
                $allocated['balance_after'] = round((float) $allocated['balance_before'] - $approved, 2);
                $newAllocations[] = $allocated;
            }
            $loanAvailable = round($loanAvailable - $approved, 2);
        }
        $loanAllocations = $newAllocations;
        $actualLoans = array_sum(array_map(static fn(array $a): float => (float) $a['amount'], $loanAllocations));
        $otherDeductions = round($otherDeductions - $requestedLoanTotal + $actualLoans, 2);
        $deductions = array_values(array_filter(array_map(static function (array $line) use ($loanApprovedAmounts): ?array {
            if (($line['code'] ?? '') !== 'LOAN') { return $line; }
            $new = $loanApprovedAmounts[(int) ($line['loan_id'] ?? 0)] ?? 0.0;
            if ($new <= 0) { return null; }
            $line['amount'] = $new;
            unset($line['loan_id']);
            return $line;
        }, $deductions)));

        $totalDeductions = round(
            $lateDeduction + $undertimeDeduction + $absenceDeduction + $leaveDeduction
            + $otherDeductions + $statutoryDeductions,
            2
        );

        $netPay = round($grossPay - $totalDeductions, 2);

        if ($absenceDeduction > 0) {
            $deductions[] = [
                'code' => 'ABSENCE', 'name' => 'Unpaid Absence',
                'amount' => $absenceDeduction,
                'remarks' => sprintf('%.2f day(s)', $absentDays),
            ];
        }
        if ($leaveDeduction > 0) {
            $deductions[] = [
                'code' => 'UNPAID_LEAVE', 'name' => 'Unpaid Leave',
                'amount' => $leaveDeduction,
                'remarks' => sprintf('%.2f day(s)', $unpaidLeaveDays),
            ];
        }

        if ($lateDeduction > 0) {
            $deductions[] = [
                'code'    => 'LATE',
                'name'    => 'Late Deduction',
                'amount'  => $lateDeduction,
                'remarks' => sprintf('%d minute(s)', $lateMinutes),
            ];
        }

        if ($undertimeDeduction > 0) {
            $deductions[] = [
                'code'    => 'UNDERTIME',
                'name'    => 'Undertime Deduction',
                'amount'  => $undertimeDeduction,
                'remarks' => sprintf('%d minute(s)', $undertimeMinutes),
            ];
        }

        // Statutory lines last, so a payslip reads attendance deductions first
        // and government contributions / withholding tax after them.
        $deductions = array_merge($deductions, (array) $statutory['deductions']);

        return [
            'basic_pay'           => round($basicPay, 2),
            'working_days'        => $workingDays,
            'present_days'        => round($presentDays, 2),
            'absent_days'         => round($absentDays, 2),
            'leave_days'          => round($leaveDays, 2),
            'late_minutes'        => $lateMinutes,
            'undertime_minutes'   => $undertimeMinutes,
            'overtime_hours'      => round($overtimeHours, 2),
            'overtime_pay'        => round($overtimePay, 2),
            'night_hours'         => round($nightHours, 2),
            'night_pay'           => round($nightPay, 2),
            'holiday_pay'         => round($holidayPay, 2),
            'allowances_total'    => round($allowancesTotal, 2),
            'bonus'               => round($adjustmentEarnings, 2),
            'gross_pay'           => $grossPay,
            'late_deduction'      => round($lateDeduction, 2),
            'undertime_deduction' => round($undertimeDeduction, 2),
            'absence_deduction'   => round($absenceDeduction, 2),
            'leave_deduction'     => round($leaveDeduction, 2),
            'other_deductions'    => round($otherDeductions, 2),
            'statutory_sss'       => round((float) ($statutory['contributions']['SSS']['employee_amount'] ?? 0.0), 2),
            'statutory_philhealth' => round((float) ($statutory['contributions']['PHILHEALTH']['employee_amount'] ?? 0.0), 2),
            'statutory_pagibig'   => round((float) ($statutory['contributions']['PAGIBIG']['employee_amount'] ?? 0.0), 2),
            'withholding_tax'     => round((float) ($statutory['withholding_tax']['amount'] ?? 0.0), 2),
            'statutory_total'     => $statutoryDeductions,
            'employer_contributions' => round((float) $statutory['employer_total'], 2),
            'total_deductions'    => $totalDeductions,
            'net_pay'             => $netPay,
            'earnings'            => $earnings,
            'deductions'          => $deductions,
            // The loan instalments above, with the loan id each one repays.
            'loan_allocations'    => $loanAllocations,
            'loan_shortfalls'    => $loanShortfalls,
            'statutory'           => $statutory,
            'daily_rate'          => round($dailyRate, 2),
            'hourly_rate'         => round($hourlyRate, 2),
            'provisional'        => $provisionalDraft && $attendanceIssues !== [],
            'attendance_exceptions' => $attendanceIssues,
            'snapshot'            => [
                // Missing scans in completed cutoffs are transparent,
                // reversible presumptions; not evidence of employee absence.
                'auto_absent_dates' => $autoAbsentDates,
                'auto_absent_count' => count($autoAbsentDates),
                'provisional' => $provisionalDraft && $attendanceIssues !== [],
                'attendance_exceptions' => $attendanceIssues,
                'provisional_absent_days' => count($attendanceIssues),
                'settings'        => $settings,
                'daily_rate'      => round($dailyRate, 2),
                'hourly_rate'     => round($hourlyRate, 2),
                'attendance_rows' => count($attendance),
                'period'          => ['start' => $startDate, 'end' => $endDate],
                'statutory'       => $statutory['snapshot'] ?? null,
                // The loan each LOAN deduction line repaid, so a stored
                // snapshot can be traced back to the repayment ledger.
                'loan_allocations' => $loanAllocations,
                'approved_adjustment_ids' => array_map(static fn(array $a): int => (int)$a['id'], $approvedAdjustments),
                // Records how basic_pay was composed. Payroll rows written
                // before this marker existed embedded holiday pay inside
                // basic_pay; the 13th-month service detects the missing marker
                // and subtracts the payroll_items 'HOLIDAY' earning when it
                // reads those legacy rows (see ThirteenthPayService).
                'accounting'      => ['holiday_pay_included_in_basic' => false],
            ],
        ];
    }

    // -----------------------------------------------------------------------
    // Deduction formulas (all configurable through settings — Phase 12)
    // -----------------------------------------------------------------------

    /**
     * How many pay periods one calendar month has for the configured
     * frequency.
     *
     * This is the divisor that spreads a monthly loan deduction across the
     * periods the employee is actually paid for - the same notion the
     * statutory module uses to allocate monthly contributions.
     *
     * @param array<string, float|int|string> $settings
     */
    public function periodsPerMonth(array $settings): int
    {
        return match (strtoupper((string) $settings['pay_frequency'])) {
            'WEEKLY'    => 4,
            'BI_WEEKLY' => 2,
            'MONTHLY'   => 1,
            'DAILY'     => max(1, (int) round((float) $settings['working_days_per_month'])),
            // SEMI_MONTHLY - and anything unset - pays twice a month.
            default     => 2,
        };
    }

    /**
     * The instalment ONE pay period withdraws from a monthly loan deduction.
     *
     * The monthly figure is halved (or quartered, etc.) and rounded to the
     * nearest centavo. Because every instalment is capped at the outstanding
     * balance before it is recorded (see LoanService::recordPayrollDeductions),
     * the final payment of a loan is trimmed to exactly what is owed: the
     * employee never repays more than the principal, even when splitting a
     * monthly odd-centavo figure leaves a stray cent.
     *
     * @param array<string, float|int|string> $settings
     */
    public function loanInstalmentForPeriod(float $monthlyDeduction, array $settings): float
    {
        $periods = $this->periodsPerMonth($settings);
        $amount  = round($monthlyDeduction / $periods, 2);

        // A sub-centavo split would otherwise propose 0.00 and never repay a
        // 0.01 loan; keep the loan moving instead.
        return max(0.01, $amount);
    }

    /**
     * Late deduction using the configured method.
     *
     * @param array<string, float|int|string> $settings
     */
    public function lateDeduction(int $lateMinutes, float $hourlyRate, float $dailyRate, array $settings): float
    {
        $amount = (float) $settings['late_deduction_amount'];

        return match (strtoupper((string) $settings['late_deduction_type'])) {
            'PER_MINUTE' => round($lateMinutes * ((bool) ($settings['fixed_monthly_policy'] ?? false) ? $hourlyRate / 60.0 : $amount), 2),
            'PER_HOUR'   => round(($lateMinutes / 60) * $amount, 2),
            'PER_DAY'    => round(($lateMinutes / 60 / max(1, (float) $settings['working_hours_per_day'])) * $amount, 2),
            'FIXED'      => round($amount, 2),
            // Default: deduct the actual pay value of the late minutes.
            default      => round(($lateMinutes / 60) * $hourlyRate, 2),
        };
    }

    /**
     * Undertime deduction using the configured method.
     *
     * @param array<string, float|int|string> $settings
     */
    public function undertimeDeduction(int $undertimeMinutes, float $hourlyRate, float $dailyRate, array $settings): float
    {
        $amount = (float) $settings['undertime_deduction_amount'];

        return match (strtoupper((string) $settings['undertime_deduction_type'])) {
            'PER_MINUTE' => round($undertimeMinutes * ((bool) ($settings['fixed_monthly_policy'] ?? false) ? $hourlyRate / 60.0 : $amount), 2),
            'PER_HOUR'   => round(($undertimeMinutes / 60) * $amount, 2),
            'FIXED'      => round($amount, 2),
            // Default: deduct the actual pay value of the missing minutes.
            default      => round(($undertimeMinutes / 60) * $hourlyRate, 2),
        };
    }

    /**
     * Unpaid-leave value for the period, based on approved unpaid leave.
     *
     * Reference figure only: calculateEmployee() no longer subtracts it,
     * because an unpaid-leave day already accrues no basic pay (charging it
     * again would withhold the same day twice). Kept because it is the
     * documented worth of the unpaid leave and part of this engine's public
     * surface.
     */
    public function unpaidLeaveDeduction(int $employeeId, string $startDate, string $endDate, float $dailyRate): float
    {
        $unpaidDays = (float) (Database::scalar(
            "SELECT COALESCE(SUM(lr.days), 0)
               FROM leave_requests lr
               JOIN leave_types lt ON lt.id = lr.leave_type_id
              WHERE lr.employee_id = :emp
                AND lr.status = 'APPROVED'
                AND lt.is_paid = 0
                AND lr.start_date <= :end
                AND lr.end_date >= :start",
            ['emp' => $employeeId, 'start' => $startDate, 'end' => $endDate]
        ) ?? 0);

        return round($unpaidDays * $dailyRate, 2);
    }

    /**
     * Night-differential hours inside the period (Phase 12).
     */
    public function nightHoursFor(int $employeeId, string $startDate, string $endDate): float
    {
        $rows = Database::select(
            "SELECT a.time_in, a.time_out, a.attendance_date, a.source,
                    EXISTS(SELECT 1 FROM overtime_requests ot
                           WHERE ot.employee_id=a.employee_id AND ot.overtime_date=a.attendance_date
                             AND ot.status='APPROVED' AND ot.payroll_verified_at IS NOT NULL) AS verified_rest_work
               FROM attendance a
              WHERE a.employee_id = :emp
                AND a.deleted_at IS NULL
                AND a.time_in IS NOT NULL AND a.time_out IS NOT NULL
                AND a.attendance_date >= :start
                AND a.attendance_date <= :end",
            ['emp' => $employeeId, 'start' => $startDate, 'end' => $endDate]
        );

        $settings = $this->settings();
        $total    = 0.0;

        [$nsH, $nsM, $nsS] = array_pad(explode(':', (string) $settings['night_shift_start']), 3, 0);
        [$neH, $neM, $neS] = array_pad(explode(':', (string) $settings['night_shift_end']), 3, 0);

        foreach ($rows as $row) {
            if ((new \DateTimeImmutable((string)$row['attendance_date']))->format('w') === '0'
                && (int)$row['verified_rest_work'] !== 1) {
                // Sunday time logs alone never generate extra night pay.
                continue;
            }
            $in  = new \DateTimeImmutable((string) $row['time_in']);
            $out = new \DateTimeImmutable((string) $row['time_out']);

            $minutes = 0.0;

            // Walk day by day so overnight windows are covered. The night
            // window starts at night_shift_start and ends at night_shift_end
            // on the following day.
            for ($day = $in->setTime(0, 0); $day <= $out->setTime(0, 0); $day = $day->modify('+1 day')) {
                $from = $day->setTime((int) $nsH, (int) $nsM, (int) $nsS);
                $to   = $day->modify('+1 day')->setTime((int) $neH, (int) $neM, (int) $neS);

                $overlapStart = $in > $from ? $in : $from;
                $overlapEnd   = $out < $to ? $out : $to;

                if ($overlapEnd > $overlapStart) {
                    $minutes += ($overlapEnd->getTimestamp() - $overlapStart->getTimestamp()) / 60;
                }
            }

            $total += $minutes;
        }

        return round($total / 60, 2);
    }

    /** Configurable multiplier for an overtime type (Phase 11 / Phase 12). */
    public function multiplierFor(string $otType): float
    {
        return match (strtoupper($otType)) {
            'REST_DAY', 'NIGHT' => Settings::float('payroll.overtime_rest_day_multiplier', 1.30),
            'HOLIDAY'           => Settings::float('payroll.overtime_holiday_multiplier', 2.00),
            default             => Settings::float('payroll.overtime_multiplier', 1.25),
        };
    }
}