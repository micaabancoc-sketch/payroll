<?php
/**
 * Employee loans and the repayment ledger (Phase 3 / Phase 3B).
 *
 * A loan is a principal, a monthly deduction and a running balance. Every
 * movement of that balance is a row in `loan_payments`, written either by an
 * authorised user (MANUAL / ADJUSTMENT) or by the payroll run - and the payroll
 * only writes its PAYROLL rows when the period is marked PAID, never while a
 * draft is being calculated (Phase 3A). The ledger is the single source of
 * truth, so `loans.balance` is always derived from it and a fully repaid loan
 * flips to PAID by itself.
 *
 * A loan is also filed before it is deducted (Phase 3B): create() records it as
 * PENDING, an approver who is NOT the user who filed it moves it into the
 * payroll rotation (approve) or stops it for good (reject, with a reason), and
 * only an ACTIVE loan is ever deducted.
 */

declare(strict_types=1);

namespace App\Services;

use App\Core\Auth;
use App\Core\AuditLogger;
use App\Core\Database;
use App\Core\DemoStaffScope;
use App\Core\ValidationException;
use App\Core\Validator;
use RuntimeException;

final class LoanService
{
    /**
     * Loan categories. `loans.loan_type` is a VARCHAR (the pre-existing
     * column), so the vocabulary lives here and both the validator and the
     * pages read it back through options().
     */
    public const TYPES = [
        'SALARY_LOAN'    => 'Company Loan',
        'CASH_ADVANCE'   => 'Salary Advance',
        'EMERGENCY_LOAN' => 'Emergency Loan',
        'EQUIPMENT_LOAN' => 'Equipment Loan',
        'OTHER'          => 'Other',
        'SSS_SALARY_LOAN' => 'SSS Salary Loan (Agency)',
        'PAGIBIG_MPL' => 'Pag-IBIG Multi-Purpose Loan (Agency)',
    ];

    /**
     * The loan lifecycle.
     *
     * PENDING   filed, waiting for an approver - payroll never deducts it;
     * ACTIVE    approved: the payroll run deducts its instalment;
     * PAID      fully repaid (derived from the ledger);
     * REJECTED  refused with a reason - terminal, file a new loan instead;
     * CANCELLED stopped by an authorised user.
     */
    public const STATUSES = [
        'PENDING'   => 'Awaiting review / agency verification',
        'OFFERED' => 'Terms offered (employee acceptance required)',
        'READY_FOR_RELEASE' => 'Accepted — awaiting actual loan release',
        'ACTIVE'    => 'Active',
        'PAID'      => 'Fully Paid',
        'REJECTED'  => 'Rejected',
        'CANCELLED' => 'Cancelled',
    ];

    /** Ledger row kinds, matching the `loan_payments.payment_type` enum. */
    public const PAYMENT_TYPES = [
        'MANUAL'     => 'Manual payment',
        'PAYROLL'    => 'Payroll deduction',
        'ADJUSTMENT' => 'Adjustment',
    ];

    /**
     * Payment types an API caller may post. A PAYROLL row is only ever written
     * by PayrollService, so accepting it here would let a client forge the
     * source of a deduction.
     */
    public const MANUAL_PAYMENT_TYPES = ['MANUAL', 'ADJUSTMENT'];

    /** Columns shared by list() and find(). */
    private const SELECT_COLUMNS = "l.*, e.employee_number, e.first_name, e.middle_name, e.last_name, e.suffix,
                    e.department_id, d.name AS department_name, u.username AS approved_by_username,
                    cu.username AS created_by_username,
                    COALESCE(paid.paid_total, 0) AS paid_total,
                    COALESCE(paid.payment_count, 0) AS payment_count";

    /** The ledger aggregate is a subquery so a loan without payments still appears. */
    private const FROM_JOINS = "FROM loans l
               JOIN employees e ON e.id = l.employee_id
               LEFT JOIN departments d ON d.id = e.department_id
               LEFT JOIN users u ON u.id = l.approved_by
               LEFT JOIN users cu ON cu.id = l.created_by
               LEFT JOIN (SELECT loan_id, SUM(amount) AS paid_total, COUNT(*) AS payment_count
                            FROM loan_payments
                           GROUP BY loan_id) paid ON paid.loan_id = l.id";

    /**
     * Full loan row for one employee, ledger included.
     *
     * @param array<string, mixed> $filters employee_id, department_id, status, loan_type, search
     * @return array{items: list<array<string, mixed>>, total: int}
     */
    public function list(array $filters, int $page = 1, int $perPage = 25): array
    {
        $where  = ['1 = 1'];
        $params = [];
        if (DemoStaffScope::enabled()) {
            $where[] = '1=1' . DemoStaffScope::excludingRoles('e.id')
                . DemoStaffScope::excludingDemoUsernames('e.id');
        }

        // A user without broad employee/payroll permissions (e.g. STAFF) may
        // only ever see their own loans. Ignore any client-supplied employee_id
        // filter and scope to the authenticated employee instead. When no user
        // is authenticated (direct service calls), no restriction applies.
        $authUser = Auth::user();
        $isRestricted = $authUser !== null && (!Auth::hasPermission('loans.view') || !empty($filters['mine']));
        if ($isRestricted) {
            $ownEmployeeId = Auth::employeeId();
            if ($ownEmployeeId === null) {
                return ['items' => [], 'total' => 0];
            }
            $where[] = 'l.employee_id = :own_employee_id';
            $params['own_employee_id'] = $ownEmployeeId;
        } elseif (!empty($filters['employee_id'])) {
            $where[] = 'l.employee_id = :employee_id';
            $params['employee_id'] = (int) $filters['employee_id'];
        }

        if (!empty($filters['department_id'])) {
            $where[] = 'e.department_id = :department_id';
            $params['department_id'] = (int) $filters['department_id'];
        }

        $status = strtoupper(trim((string) ($filters['status'] ?? '')));
        if ($status !== '' && isset(self::STATUSES[$status])) {
            $where[] = 'l.status = :status';
            $params['status'] = $status;
        }

        $loanType = strtoupper(trim((string) ($filters['loan_type'] ?? '')));
        if ($loanType !== '' && isset(self::TYPES[$loanType])) {
            $where[] = 'l.loan_type = :loan_type';
            $params['loan_type'] = $loanType;
        }

        $search = trim((string) ($filters['search'] ?? ''));
        if ($search !== '') {
            // One placeholder per column: PDO refuses to reuse a named token
            // inside a single statement.
            $where[] = '(e.first_name LIKE :search_first
                         OR e.last_name LIKE :search_last
                         OR e.employee_number LIKE :search_number
                         OR l.reference_no LIKE :search_reference)';
            $params['search_first']     = '%' . $search . '%';
            $params['search_last']      = '%' . $search . '%';
            $params['search_number']    = '%' . $search . '%';
            $params['search_reference'] = '%' . $search . '%';
        }

        $whereSql = implode(' AND ', $where);

        $total = (int) (Database::scalar(
            "SELECT COUNT(*)
               FROM loans l
               JOIN employees e ON e.id = l.employee_id
              WHERE {$whereSql}",
            $params
        ) ?? 0);

        $perPage = max(1, $perPage);
        $offset  = max(0, ($page - 1) * $perPage);

        // Filed loans first (they need a decision), then the deducting ones,
        // then the settled, rejected and cancelled ones.
        $items = Database::select(
            'SELECT ' . self::SELECT_COLUMNS . ' ' . self::FROM_JOINS . "
              WHERE {$whereSql}
              ORDER BY FIELD(l.status, 'PENDING', 'OFFERED', 'READY_FOR_RELEASE', 'ACTIVE', 'PAID', 'REJECTED', 'CANCELLED'), e.last_name, e.first_name, l.id DESC
              LIMIT {$perPage} OFFSET {$offset}",
            $params
        );

        foreach ($items as &$item) {
            $item = $this->decorate($item);
        }
        unset($item);

        return ['items' => $items, 'total' => $total];
    }

    /** @return array<string, mixed>|null one loan with its ledger totals */
    public function find(int $loanId): ?array
    {
        $loan = Database::selectOne(
            'SELECT ' . self::SELECT_COLUMNS . ' ' . self::FROM_JOINS . ' WHERE l.id = :id LIMIT 1',
            ['id' => $loanId]
        );

        if ($loan === null) {
            return null;
        }

        // A user without broad employee/payroll permissions may only view
        // their own loans. The controller already returned 404 for missing
        // loans; here we return null (404) for loans belonging to others.
        // When no user is authenticated (direct service calls), no restriction applies.
        $authUser = Auth::user();
        if ($authUser !== null && !Auth::hasPermission('loans.view')) {
            $ownEmployeeId = Auth::employeeId();
            if ($ownEmployeeId === null || (int) $loan['employee_id'] !== $ownEmployeeId) {
                return null;
            }
        }

        return $this->decorate($loan);
    }

    /**
     * The repayment ledger of one loan, newest first.
     *
     * @return list<array<string, mixed>>
     */
    public function payments(int $loanId): array
    {
        $rows = Database::select(
            "SELECT lp.*, u.username AS created_by_username,
                    pp.code AS period_code, pp.name AS period_name
               FROM loan_payments lp
               LEFT JOIN users u ON u.id = lp.created_by
               LEFT JOIN payroll_periods pp ON pp.id = lp.period_id
              WHERE lp.loan_id = :loan_id
              ORDER BY lp.paid_at DESC, lp.id DESC",
            ['loan_id' => $loanId]
        );

        foreach ($rows as &$row) {
            $row['amount']             = round((float) $row['amount'], 2);
            $row['payment_type_label'] = self::PAYMENT_TYPES[(string) $row['payment_type']] ?? (string) $row['payment_type'];
        }
        unset($row);

        return $rows;
    }

    /**
     * Portfolio figures for the loans page: how much is still owed, how much
     * the next payroll run will withdraw, and how much has already been
     * collected through the ledger.
     *
     * @return array<string, mixed>
     */
    public function summary(bool $selfOnly = false): array
    {
        // A user without broad employee/payroll permissions sees only their
        // own loans in the summary. When no user is authenticated (direct
        // service calls), no restriction applies.
        $authUser = Auth::user();
        $isRestricted = $authUser !== null && (!Auth::hasPermission('loans.view') || $selfOnly);
        $ownEmployeeId = $isRestricted ? Auth::employeeId() : null;
        $ownFilter = '';
        $ownParams = [];
        if ($isRestricted) {
            if ($ownEmployeeId === null) {
                $ownFilter = ' WHERE 1 = 0';
            } else {
                $ownFilter = ' WHERE employee_id = :own_employee_id';
                $ownParams['own_employee_id'] = $ownEmployeeId;
            }
        }

        if (DemoStaffScope::enabled()) {
            $participantClause = DemoStaffScope::excludingRoles('e.id')
                . DemoStaffScope::excludingDemoUsernames('e.id');
            $scopeSql = 'employee_id IN (SELECT e.id FROM employees e WHERE 1=1' . $participantClause . ')';
            $ownFilter .= ($ownFilter === '' ? ' WHERE ' : ' AND ') . $scopeSql;
        }

        $loans = Database::selectOne(
            "SELECT COUNT(*) AS loan_count,
                    SUM(CASE WHEN status = 'PENDING'   THEN 1 ELSE 0 END) AS pending_count,
                    SUM(CASE WHEN status = 'ACTIVE'    THEN 1 ELSE 0 END) AS active_count,
                    SUM(CASE WHEN status = 'PAID'      THEN 1 ELSE 0 END) AS paid_count,
                    SUM(CASE WHEN status = 'REJECTED'  THEN 1 ELSE 0 END) AS rejected_count,
                    SUM(CASE WHEN status = 'CANCELLED' THEN 1 ELSE 0 END) AS cancelled_count,
                    COALESCE(SUM(CASE WHEN status = 'PENDING' THEN principal_amount END), 0) AS requested,
                    COALESCE(SUM(CASE WHEN status = 'ACTIVE' THEN principal_amount END), 0)  AS principal,
                    COALESCE(SUM(CASE WHEN status = 'ACTIVE' THEN balance END), 0)            AS outstanding,
                    COALESCE(SUM(CASE WHEN status = 'ACTIVE' THEN monthly_deduction END), 0)  AS monthly
               FROM loans{$ownFilter}"
        , $ownParams) ?? [];

        $ledgerParams = $ownParams;
        $ledgerFilter = '';
        if ($isRestricted) {
            // A staff account with no linked employee must not see company-wide
            // repayment totals when it cannot view any loans at all.
            $ledgerFilter = $ownEmployeeId === null
                ? ' WHERE 1 = 0'
                : ' WHERE loan_id IN (SELECT id FROM loans WHERE employee_id = :own_employee_id)';
        }
        if (DemoStaffScope::enabled()) {
            $ledgerFilter .= ($ledgerFilter === '' ? ' WHERE ' : ' AND ')
                . 'loan_id IN (SELECT id FROM loans WHERE ' . $scopeSql . ')';
        }
        $ledger = Database::selectOne(
            'SELECT COUNT(*) AS payment_count, COALESCE(SUM(amount), 0) AS paid_total
               FROM loan_payments' . $ledgerFilter
        , $ledgerParams) ?? [];

        return [
            'loans'            => (int) ($loans['loan_count'] ?? 0),
            // Filed loans still waiting for an approver.
            'pending'          => (int) ($loans['pending_count'] ?? 0),
            'active'           => (int) ($loans['active_count'] ?? 0),
            'paid'             => (int) ($loans['paid_count'] ?? 0),
            'rejected'         => (int) ($loans['rejected_count'] ?? 0),
            'cancelled'        => (int) ($loans['cancelled_count'] ?? 0),
            // Requested = the principal sitting in PENDING, not yet deducted.
            'requested'        => round((float) ($loans['requested'] ?? 0), 2),
            'principal'        => round((float) ($loans['principal'] ?? 0), 2),
            'outstanding'      => round((float) ($loans['outstanding'] ?? 0), 2),
            'monthly'          => round((float) ($loans['monthly'] ?? 0), 2),
            'payments'         => (int) ($ledger['payment_count'] ?? 0),
            'collected'        => round((float) ($ledger['paid_total'] ?? 0), 2),
        ];
    }

    /** Vocabulary for the UI selects. @return array<string, list<array{value: string, label: string}>> */
    public function options(): array
    {
        // The finalized module supports only four types. Legacy labels remain
        // readable for historical loans; they cannot be selected for new ones.
        $allowed = Auth::roleCode() === 'STAFF'
            ? ['SALARY_LOAN', 'CASH_ADVANCE']
            : ['SALARY_LOAN', 'CASH_ADVANCE', 'SSS_SALARY_LOAN', 'PAGIBIG_MPL'];
        $types = array_intersect_key(self::TYPES, array_flip($allowed));
        return [
            'types'         => self::pairs($types),
            'statuses'      => self::pairs(self::STATUSES),
            'payment_types' => self::pairs(self::MANUAL_PAYMENT_TYPES),
        ];
    }

    /**
     * File a loan for approval (Phase 3B).
     *
     * The loan is recorded as PENDING with no approver: the payroll engine
     * only ever reads `status = 'ACTIVE'`, so nothing is deducted until an
     * approver - who must not be the user who filed it - calls approve().
     *
     * @param array<string, mixed> $data
     * @return array<string, mixed>
     */
    public function create(array $data, ?int $userId = null): array
    {
        // A user without broad employee/payroll permissions (e.g. STAFF) may
        // only file loans for themselves. The backend determines the employee
        // from the authenticated session; the frontend-supplied employee_id is
        // ignored for restricted users. When no user is authenticated (direct
        // service calls), no restriction applies.
        $authUser = Auth::user();
        $isRestricted = $authUser !== null && !Auth::hasPermission('loans.view');
        $ownEmployeeId = $isRestricted ? Auth::employeeId() : null;

        // Employee files a *request* for a loan amount; Admin later sets
        // terms. A zero instalment is only allowed while the loan is PENDING.
        // The approval method explicitly refuses unconfigured instalments.
        $availableTypes = $isRestricted
            ? ['SALARY_LOAN', 'CASH_ADVANCE']
            : ['SALARY_LOAN', 'CASH_ADVANCE', 'SSS_SALARY_LOAN', 'PAGIBIG_MPL'];
        $validator = Validator::make($data, [
            'employee_id'       => $isRestricted ? 'nullable|integer' : 'required|integer',
            'loan_type'         => 'required|string|in:' . implode(',', $availableTypes),
            'principal_amount'  => 'required|numeric|min:0.01',
            'monthly_deduction' => 'nullable|numeric|min:0',
            'balance'           => 'nullable|numeric|min:0',
            'start_date'        => 'nullable|date',
            'end_date'          => 'nullable|date|after_or_equal:start_date',
            'reference_no'      => 'nullable|string|max:50',
            'notes'             => $isRestricted ? 'required|string|min:2|max:255' : 'nullable|string|max:255',
        ]);

        if ($validator->fails()) {
            throw new ValidationException($validator->errors());
        }

        $input = $validator->validated();

        // Restricted users can only file for themselves; ignore any
        // client-supplied employee_id and use the authenticated employee.
        if ($isRestricted) {
            if ($ownEmployeeId === null) {
                throw new ValidationException(['employee_id' => 'No employee account is linked to your user account.']);
            }
            $input['employee_id'] = $ownEmployeeId;
        }

        $employee = Database::selectOne(
            'SELECT id, employee_number, first_name, middle_name, last_name, suffix, status
               FROM employees
              WHERE id = :id AND deleted_at IS NULL
              LIMIT 1',
            ['id' => (int) $input['employee_id']]
        );

        if ($employee === null) {
            throw new ValidationException(['employee_id' => 'The selected employee does not exist.']);
        }

        if ((string) $employee['status'] !== 'ACTIVE') {
            throw new ValidationException(['employee_id' => 'Loans can only be recorded for active employees.']);
        }

        // HR/Manager operate the loan module but can never borrow themselves in this demo.
        DemoStaffScope::assertDemoParticipant((int) $employee['id']);

        $loanType = (string) $input['loan_type'];
        if (in_array($loanType, ['SALARY_LOAN', 'CASH_ADVANCE'], true)) {
            $salaryRow = Database::selectOne(
                'SELECT basic_salary FROM employees WHERE id = :id LIMIT 1',
                ['id' => (int) $employee['id']]
            );
            $maxAmount = CompanyLoanPolicy::maxPrincipal($loanType, (float) ($salaryRow['basic_salary'] ?? 0));
            if ((float) $input['principal_amount'] > $maxAmount) {
                throw new ValidationException(['principal_amount' =>
                    sprintf('Maximum %s is PHP %.2f based on monthly basic salary.', self::TYPES[$loanType], $maxAmount)]);
            }
            if ($loanType === 'SALARY_LOAN' && (int) Database::scalar(
                "SELECT COUNT(*) FROM loans WHERE employee_id = :emp AND loan_type = 'SALARY_LOAN' AND status IN ('PENDING','OFFERED','READY_FOR_RELEASE','ACTIVE')",
                ['emp' => (int) $employee['id']]
            ) > 0) {
                throw new ValidationException(['loan_type' => 'Only one outstanding company loan application/loan is allowed.']);
            }
        }
        $isAgency = in_array($loanType, ['SSS_SALARY_LOAN','PAGIBIG_MPL'], true);
        if ($isAgency) {
            if (Auth::roleCode() !== 'HR_PAYROLL') {
                throw new ValidationException(['permission' => 'Only HR/Payroll can register agency-verified loan obligations.']);
            }
            if (empty($input['reference_no']) || empty($input['start_date']) ||
                (float) ($input['monthly_deduction'] ?? 0) <= 0) {
                throw new ValidationException(['reference_no' =>
                    'Official agency loan reference, deduction start date, and official monthly amortization are required.']);
            }
        }

        $principal = round((float) $input['principal_amount'], 2);
        // Never trust employee-supplied amortization; pending requests have none.
        $monthly   = $isRestricted ? 0.0 : round((float) $input['monthly_deduction'], 2);
        $balance   = $isRestricted || $input['balance'] === null ? $principal : round((float) $input['balance'], 2);

        if ($balance > $principal) {
            throw new ValidationException(['balance' => 'The outstanding balance cannot exceed the principal amount.']);
        }

        if ($monthly > $principal) {
            throw new ValidationException([
                'monthly_deduction' => 'The instalment cannot exceed the principal amount.',
            ]);
        }

        $loanType  = (string) $input['loan_type'];
        $startDate = $isRestricted || empty($input['start_date']) ? date('Y-m-d') : (string) $input['start_date'];
        $reference = $this->reference($isRestricted ? '' : (string) ($input['reference_no'] ?? ''), $startDate);

        $loanId = Database::insert('loans', [
            'employee_id'       => (int) $employee['id'],
            'loan_type'         => $loanType,
            'reference_no'      => $reference,
            'principal_amount'  => $principal,
            'monthly_deduction' => $monthly,
            'balance'           => $balance,
            'start_date'        => $startDate,
            'end_date'          => $isRestricted || $input['end_date'] === null ? null : (string) $input['end_date'],
            'status'            => 'PENDING',
            'rejection_reason'  => null,
            'notes'             => $input['notes'] === null ? null : (string) $input['notes'],
            'created_by'        => $userId,
            // No approver yet: approve() stamps these, and a loan can never
            // carry its own approval from the moment it is filed.
            'approved_by'       => null,
            'approved_at'       => null,
            'released_at'       => null,
        ]);

        AuditLogger::record(
            AuditLogger::LOAN_CREATED,
            'loan',
            $loanId,
            sprintf(
                '%s %s of %s for %s (%s)',
                $isAgency ? 'Registered pending agency verification' : 'Filed',
                self::TYPES[$loanType] ?? $loanType,
                number_format($principal, 2),
                $this->employeeName($employee),
                $reference
            ),
            null,
            [
                'employee_id'       => (int) $employee['id'],
                'loan_type'         => $loanType,
                'principal_amount'  => $principal,
                'monthly_deduction' => $monthly,
                'balance'           => $balance,
                'status'            => 'PENDING',
            ]
        );

        return $this->find($loanId) ?? [];
    }

    /**
     * Edit a loan's terms. Money figures are frozen once a repayment exists,
     * and a fully paid loan only accepts annotations.
     *
     * @param array<string, mixed> $data
     * @return array<string, mixed>
     */
    public function update(int $loanId, array $data, ?int $userId = null): array
    {
        $this->assertDemoBorrower($loanId);
        $loan = $this->row($loanId);

        if ((string) $loan['status'] === 'CANCELLED') {
            throw new RuntimeException('Restore this loan before editing it.');
        }

        if ((string) $loan['status'] === 'REJECTED') {
            throw new RuntimeException('This loan was rejected. File a new loan instead of editing it.');
        }

        $validator = Validator::make($data, [
            'loan_type'         => 'nullable|string|in:' . implode(',', array_keys(self::TYPES)),
            'principal_amount'  => 'nullable|numeric|min:0.01',
            'monthly_deduction' => 'nullable|numeric|min:0.01',
            'start_date'        => 'nullable|date',
            'end_date'          => 'nullable|date',
            'reference_no'      => 'nullable|string|max:50',
            'notes'             => 'nullable|string|max:255',
        ]);

        if ($validator->fails()) {
            throw new ValidationException($validator->errors());
        }

        $input    = $validator->validated();
        $provided = [];
        foreach ($input as $field => $value) {
            // validated() also carries the keys that were absent from the body.
            if (array_key_exists($field, $data)) {
                $provided[$field] = $value;
            }
        }

        if ($provided === []) {
            throw new RuntimeException('No changes were submitted.');
        }

        $editable = (string) $loan['status'] === 'PENDING'
            ? ['loan_type', 'principal_amount', 'monthly_deduction', 'start_date', 'end_date', 'reference_no', 'notes']
            : ['notes'];

        foreach (array_keys($provided) as $field) {
            if (!in_array($field, $editable, true)) {
                throw new ValidationException([$field => 'This field cannot be changed on a fully paid loan.']);
            }
        }

        $moneyFields = ['principal_amount', 'monthly_deduction'];
        $changes     = [];
        $before      = [];

        foreach ($provided as $field => $value) {
            $old = $loan[$field] ?? null;

            if (in_array($field, $moneyFields, true)) {
                $new = $value === null ? null : round((float) $value, 2);
                $old = $old === null ? null : round((float) $old, 2);
            } else {
                $new = $value === null ? null : (string) $value;
                $old = $old === null ? null : (string) $old;
            }

            if ($new !== $old) {
                $changes[$field] = $new;
                $before[$field]  = $old;
            }
        }

        if ($changes === []) {
            // Nothing moved; no audit row for a no-op save.
            return $this->find($loanId) ?? [];
        }

        if (array_key_exists('reference_no', $changes)) {
            $reference = trim((string) $changes['reference_no']);
            if ($reference === '') {
                throw new ValidationException(['reference_no' => 'The reference number cannot be empty.']);
            }
            if ($this->referenceExists($reference, $loanId)) {
                throw new ValidationException(['reference_no' => 'That reference number is already in use.']);
            }
            $changes['reference_no'] = $reference;
        }

        if (array_key_exists('principal_amount', $changes)) {
            if ($this->paymentCount($loanId) > 0) {
                throw new ValidationException([
                    'principal_amount' => 'The principal cannot be changed once a repayment has been recorded.',
                ]);
            }

            // Nothing has been repaid, so the whole principal is outstanding.
            $changes['balance'] = $changes['principal_amount'];
            $before['balance']  = round((float) $loan['balance'], 2);

            // Only an approved loan carries a repayment status to recompute.
            // Editing what was filed must never move a loan out of PENDING
            // (that is approve()'s job) nor revive one from REJECTED.
            if ((string) $loan['status'] === 'ACTIVE') {
                $changes['status'] = (float) $changes['principal_amount'] > 0 ? 'ACTIVE' : 'PAID';
                $before['status']  = (string) $loan['status'];
            }
        }

        $startDate = (string) ($changes['start_date'] ?? $loan['start_date']);
        $endDate   = array_key_exists('end_date', $changes) ? $changes['end_date'] : $loan['end_date'];

        if ($endDate !== null && (string) $endDate < $startDate) {
            throw new ValidationException(['end_date' => 'End date must be on or after the start date.']);
        }

        Database::update('loans', $changes, ['id' => $loanId]);

        AuditLogger::recordChanges(AuditLogger::LOAN_UPDATED, 'loan', $loanId, $before, $changes);

        return $this->find($loanId) ?? [];
    }

    /**
     * Approve a filed loan, putting it into the payroll rotation (Phase 3B).
     *
     * Only a PENDING loan can be approved, and never by the user who filed it:
     * the person who records a loan is not the person who authorises the
     * deduction. The whole transition is one transaction over a locked row, so
     * two approvers racing the same request cannot both move it - the second
     * one reads ACTIVE and is refused.
     *
     * @return array<string, mixed>
     */
    public function approve(int $loanId, ?int $userId = null): array
    {
        throw new ValidationException(['loan' =>
            'Immediate approval has been disabled. Admin must offer terms, employee must accept, then Admin records release.']);
    }

    /** Admin proposes company loan terms; no payroll deduction yet. */
    public function offer(int $loanId, int $months, ?int $userId = null): array
    {
        $this->assertDemoBorrower($loanId);
        if (Auth::roleCode() !== 'HR_PAYROLL') {
            throw new ValidationException(['permission' => 'Only HR/Payroll may offer and approve Company Loan terms.']);
        }
        return Database::transaction(function () use ($loanId, $months, $userId): array {
            $loan = $this->lockForDecision($loanId, 'offered');
            $this->refuseSelfDecision($loan, $userId, 'approve');
            if (Auth::employeeId() !== null && (int) $loan['employee_id'] === (int) Auth::employeeId()) {
                throw new ValidationException(['permission' => 'HR cannot approve their own loan. Assign an independent HR approver.']);
            }
            $type = (string) $loan['loan_type'];
            try {
                $terms = CompanyLoanPolicy::terms($type, (float) $loan['principal_amount'], $months);
            } catch (\InvalidArgumentException $ex) {
                throw new ValidationException(['term_months' => $ex->getMessage()]);
            }
            Database::update('loans', [
                'status' => 'OFFERED',
                'term_months' => $months,
                'flat_interest_percent' => $terms['interest_rate'],
                'interest_amount' => $terms['interest_amount'],
                'balance' => $terms['total_repayment'],
                'monthly_deduction' => $terms['monthly_deduction'],
                'terms_offered_at' => date('Y-m-d H:i:s'),
                'approved_by' => $userId,
                'approved_at' => date('Y-m-d H:i:s'),
            ], ['id' => $loanId]);
            AuditLogger::record(AuditLogger::LOAN_APPROVED, 'loan', $loanId,
                'HR approved and offered fixed company loan terms; awaiting employee acceptance',
                ['status' => 'PENDING'], ['status' => 'OFFERED', 'terms' => $terms]);
            return $this->find($loanId) ?? [];
        });
    }

    /** Employee accepts the actual offer, not one reconstructed on their device. */
    public function accept(int $loanId, ?int $userId = null): array
    {
        $this->assertDemoBorrower($loanId);
        return Database::transaction(function () use ($loanId, $userId): array {
            $loan = Database::selectOne('SELECT * FROM loans WHERE id = :id FOR UPDATE', ['id' => $loanId]);
            if ($loan === null || (string) $loan['status'] !== 'OFFERED') {
                throw new ValidationException(['loan' => 'No active offer for this loan.']);
            }
            if ((int) ($loan['employee_id'] ?? 0) !== (int) (Auth::employeeId() ?? 0) || Auth::employeeId() === null) {
                throw new ValidationException(['permission' => 'Only the loan owner can accept these terms.']);
            }
            Database::update('loans', ['status' => 'READY_FOR_RELEASE', 'terms_accepted_at' => date('Y-m-d H:i:s')], ['id' => $loanId]);
            AuditLogger::record(AuditLogger::LOAN_UPDATED, 'loan', $loanId,
                'Employee accepted offered loan terms and payroll repayment authorization',
                ['status' => 'OFFERED'], ['status' => 'READY_FOR_RELEASE', 'accepted_by' => $userId]);
            return $this->find($loanId) ?? [];
        });
    }

    /** Agency loans never start deducting just because HR registered a reference. */
    public function verifyAgency(int $loanId, string $evidence, string $authorization): array
    {
        $this->assertDemoBorrower($loanId);
        if (Auth::roleCode() !== 'HR_PAYROLL') { throw new ValidationException(['permission'=>'Only HR may verify official agency loan evidence.']); }
        if (mb_strlen(trim($evidence)) < 8 || mb_strlen(trim($authorization)) < 8) {
            throw new ValidationException(['evidence'=>'Official agency notice/payment schedule reference and written payroll deduction authorization reference are required.']);
        }
        return Database::transaction(function () use ($loanId,$evidence,$authorization): array {
            $loan=Database::selectOne('SELECT * FROM loans WHERE id=:id FOR UPDATE',['id'=>$loanId]);
            if (!$loan || !in_array($loan['loan_type'],['SSS_SALARY_LOAN','PAGIBIG_MPL'],true) || $loan['status']!=='PENDING') {
                throw new ValidationException(['loan'=>'Select a pending SSS or Pag-IBIG agency loan; already active loans cannot be reverified.']);
            }
            if (empty($loan['reference_no']) || (float)$loan['monthly_deduction']<=0) {
                throw new ValidationException(['loan'=>'Official loan number and amortization schedule are required.']);
            }
            if (Auth::employeeId() !== null && Auth::employeeId()===(int)$loan['employee_id']) {
                throw new ValidationException(['permission'=>'HR cannot activate deductions on their own agency loan without independent approval.']);
            }
            Database::update('loans',[
                'status'=>'ACTIVE','agency_evidence_reference'=>trim($evidence),
                'deduction_authorization_reference'=>trim($authorization),
                'agency_verified_at'=>date('Y-m-d H:i:s'),'approved_by'=>Auth::id(),
                'approved_at'=>date('Y-m-d H:i:s'),'released_at'=>date('Y-m-d H:i:s'),
            ],['id'=>$loanId]);
            AuditLogger::record(AuditLogger::LOAN_APPROVED,'loan',$loanId,
                'HR verified official agency loan evidence and payroll deduction consent; agency must actually have released loan proceeds.');
            return $this->find($loanId)??[];
        });
    }

    /** Admin confirms actual disbursement; this is the ONLY way new loans become active. */
    public function release(int $loanId, string $reference, string $authorization, ?int $userId = null): array
    {
        $this->assertDemoBorrower($loanId);
        if (Auth::roleCode() !== 'HR_PAYROLL') {
            throw new ValidationException(['permission' => 'Only HR/Payroll can record a company loan release.']);
        }
        if (mb_strlen(trim($reference))<8 || mb_strlen(trim($authorization))<8) {
            throw new ValidationException(['evidence'=>'Actual company loan disbursement reference and written deduction authorization reference are required.']);
        }
        return Database::transaction(function () use ($loanId,$reference,$authorization): array {
            $loan = Database::selectOne('SELECT * FROM loans WHERE id = :id FOR UPDATE', ['id' => $loanId]);
            if ($loan !== null && Auth::employeeId() !== null && (int)$loan['employee_id'] === (int)Auth::employeeId()) {
                throw new ValidationException(['permission' => 'HR cannot release their own loan; independent authorization is required.']);
            }
            if ($loan === null || (string) $loan['status'] !== 'READY_FOR_RELEASE' || !$loan['terms_accepted_at']) {
                throw new ValidationException(['loan' => 'Employee must accept offered loan terms before release.']);
            }
            Database::update('loans', [
                'status' => 'ACTIVE', 'released_at' => date('Y-m-d H:i:s'),
                'start_date' => date('Y-m-d'),
                'release_reference'=>trim($reference),
                'deduction_authorization_reference'=>trim($authorization),
            ], ['id' => $loanId]);
            AuditLogger::record(AuditLogger::LOAN_APPROVED, 'loan', $loanId,
                'HR confirmed actual company loan release; payroll repayments enabled',
                ['status' => 'READY_FOR_RELEASE'], ['status' => 'ACTIVE']);
            return $this->find($loanId) ?? [];
        });
    }

    /**
     * Reject a filed loan, recording why it was refused (Phase 3B).
     *
     * A rejection is terminal: the loan is never deducted and the reason stays
     * on the record for the employee, so a new loan has to be filed instead.
     * The decision is stamped in approved_by / approved_at - the same pair of
     * columns records who decided a loan and when, whichever way it went
     * (the convention LeaveService uses for approver_id / approved_at).
     *
     * @return array<string, mixed>
     */
    public function reject(int $loanId, string $reason, ?int $userId = null): array
    {
        $this->assertDemoBorrower($loanId);
        if (Auth::roleCode() !== 'HR_PAYROLL') {
            throw new ValidationException(['permission' => 'Only HR/Payroll can reject company loan applications.']);
        }
        $validator = Validator::make(['reason' => trim($reason)], [
            'reason' => 'required|string|max:255',
        ]);

        if ($validator->fails()) {
            throw new ValidationException([
                'rejection_reason' => 'A reason is required to reject a loan (255 characters at most).',
            ]);
        }

        $reason = (string) $validator->validated()['reason'];

        return Database::transaction(function () use ($loanId, $reason, $userId): array {
            $loan = $this->lockForDecision($loanId, 'rejected');

            $this->refuseSelfDecision($loan, $userId, 'reject');

            Database::update('loans', [
                'status'           => 'REJECTED',
                'rejection_reason' => $reason,
                'approved_by'      => $userId,
                'approved_at'      => date('Y-m-d H:i:s'),
            ], ['id' => $loanId]);

            AuditLogger::record(
                AuditLogger::LOAN_REJECTED,
                'loan',
                $loanId,
                sprintf(
                    'Rejected loan %s of %s: %s',
                    (string) $loan['reference_no'],
                    number_format(round((float) $loan['principal_amount'], 2), 2),
                    $reason
                ),
                ['status' => 'PENDING'],
                ['status' => 'REJECTED', 'approved_by' => $userId, 'rejection_reason' => $reason]
            );

            return $this->find($loanId) ?? [];
        });
    }

    /**
     * Record a repayment made outside payroll.
     *
     * Runs inside a transaction and locks the loan row: two concurrent
     * payments both read the outstanding balance here, and locking means the
     * second one sees the balance the first already reduced, so a loan can
     * never be overpaid by a race (Phase 3A).
     *
     * Values: amount, payment_type, paid_at, remarks.
     *
     * @param array<string, mixed> $data amount, payment_type, paid_at, remarks
     * @return array<string, mixed>
     */
    public function recordPayment(int $loanId, array $data, ?int $userId = null): array
    {
        $this->assertDemoBorrower($loanId);
        $validator = Validator::make($data, [
            'amount'       => 'required|numeric|min:0.01',
            'payment_type' => 'nullable|string|in:' . implode(',', self::MANUAL_PAYMENT_TYPES),
            'paid_at'      => 'nullable|date',
            'remarks'      => 'nullable|string|max:255',
        ]);

        if ($validator->fails()) {
            throw new ValidationException($validator->errors());
        }

        $input  = $validator->validated();
        $amount = round((float) $input['amount'], 2);
        $type    = $input['payment_type'] === null ? 'MANUAL' : (string) $input['payment_type'];
        $paidAt  = $input['paid_at'] === null ? null : date('Y-m-d H:i:s', (int) strtotime((string) $input['paid_at']));
        $remarks = $input['remarks'] === null ? null : (string) $input['remarks'];

        $result = Database::transaction(function () use ($loanId, $amount, $type, $paidAt, $remarks, $userId): array {
            // Lock the loan row for the whole check-and-write sequence.
            $loan = Database::selectOne(
                'SELECT * FROM loans WHERE id = :id LIMIT 1 FOR UPDATE',
                ['id' => $loanId]
            );

            if ($loan === null) {
                throw new RuntimeException('Loan not found.');
            }

            if ((string) $loan['status'] === 'CANCELLED') {
                throw new RuntimeException('This loan is cancelled. Restore it before recording a payment.');
            }

            if (in_array((string) $loan['status'], ['PENDING','OFFERED','READY_FOR_RELEASE'], true)) {
                throw new RuntimeException('The loan has not been released; repayments cannot start yet.');
            }

            if ((string) $loan['status'] === 'REJECTED') {
                throw new RuntimeException('This loan was rejected. Ask for a new loan to be filed instead.');
            }

            $balance = round((float) $loan['balance'], 2);

            if ($balance <= 0) {
                throw new RuntimeException('This loan is already fully paid.');
            }

            if ($amount > $balance) {
                throw new ValidationException([
                    'amount' => sprintf(
                        'The amount cannot exceed the outstanding balance of %s.',
                        number_format($balance, 2)
                    ),
                ]);
            }

            $result = $this->addPayment($loan, $amount, $type, null, null, $remarks, $paidAt, $userId);

            AuditLogger::record(
                AuditLogger::LOAN_PAYMENT,
                'loan',
                $loanId,
                sprintf(
                    'Recorded %s of %s on loan %s%s',
                    self::PAYMENT_TYPES[$type] ?? $type,
                    number_format($amount, 2),
                    (string) $loan['reference_no'],
                    $result['balance'] > 0
                        ? sprintf(', %s remaining', number_format($result['balance'], 2))
                        : ' - loan fully paid'
                ),
                ['balance' => $balance],
                ['balance' => $result['balance'], 'amount' => $amount, 'payment_type' => $type]
            );

            return $result;
        });

        return $this->find($loanId) ?? [];
    }

    /**
     * Stop the payroll deduction without deleting the history.
     *
     * The balance is deliberately left where it was: the figure is what the
     * employee still owed when the loan was cancelled, and the payroll engine
     * only ever reads `status = 'ACTIVE'`.
     *
     * @return array<string, mixed>
     */
    public function cancel(int $loanId, ?int $userId = null, string $reason = ''): array
    {
        $this->assertDemoBorrower($loanId);
        $loan   = $this->row($loanId);
        $status = (string) $loan['status'];

        if ($status === 'CANCELLED') {
            throw new RuntimeException('This loan is already cancelled.');
        }

        if ($status === 'PAID') {
            throw new RuntimeException('A fully paid loan cannot be cancelled.');
        }

        if ($status === 'REJECTED') {
            throw new RuntimeException('This loan was already rejected. File a new loan instead.');
        }

        Database::update('loans', ['status' => 'CANCELLED'], ['id' => $loanId]);

        AuditLogger::record(
            AuditLogger::LOAN_CANCELLED,
            'loan',
            $loanId,
            sprintf(
                'Cancelled loan %s of %s outstanding%s',
                (string) $loan['reference_no'],
                number_format(round((float) $loan['balance'], 2), 2),
                $reason !== '' ? ': ' . $reason : ''
            ),
            ['status' => $status],
            ['status' => 'CANCELLED', 'reason' => $reason === '' ? null : $reason]
        );

        return $this->find($loanId) ?? [];
    }

    /**
     * Resume a cancelled loan.
     *
     * A loan that was cancelled while it still awaited approval returns to
     * PENDING, so the approver - not whoever cancelled it - decides whether it
     * is deducted. Only a loan whose decision was already made goes straight
     * back into the payroll rotation.
     *
     * @return array<string, mixed>
     */
    public function restore(int $loanId, ?int $userId = null): array
    {
        $this->assertDemoBorrower($loanId);
        $loan = $this->row($loanId);

        if ((string) $loan['status'] !== 'CANCELLED') {
            throw new RuntimeException('Only a cancelled loan can be restored.');
        }

        // A cancelled loan that was never approved goes back to PENDING, never
        // straight to ACTIVE: restoring must not be a back door around
        // approve() (Phase 3B). A loan that already carried a decision resumes
        // its repayment status.
        $decided = $loan['approved_by'] !== null || $loan['approved_at'] !== null;

        // A cancelled loan cannot bypass offer acceptance and actual release.
        $status = !empty($loan['released_at'])
            ? (round((float) $loan['balance'], 2) > 0 ? 'ACTIVE' : 'PAID')
            : (!empty($loan['terms_accepted_at']) ? 'READY_FOR_RELEASE'
                : (!empty($loan['terms_offered_at']) ? 'OFFERED' : 'PENDING'));

        Database::update('loans', ['status' => $status], ['id' => $loanId]);

        AuditLogger::record(
            AuditLogger::LOAN_RESTORED,
            'loan',
            $loanId,
            sprintf('Restored loan %s as %s', (string) $loan['reference_no'], self::STATUSES[$status] ?? $status),
            ['status' => 'CANCELLED'],
            ['status' => $status]
        );

        return $this->find($loanId) ?? [];
    }

    /**
     * Commit the loan repayments one payroll period charged.
     *
     * Called by PayrollService at the PAID transition only (Phase 3A) - never
     * while a draft is being calculated - and inside the same transaction as
     * the status change, so a period either records every repayment or none.
     * Each allocation is clamped to the outstanding balance (the final
     * instalment is exact) and one ledger row per (period, loan) is written:
     * a pair that is already there is skipped, so replaying a commit never
     * charges an instalment twice.
     *
     * @param list<array<string, mixed>> $allocations loan_id + amount rows from the
     *                                                 engine snapshot, optionally with payroll_id
     * @return array{recorded: int, skipped: int, total: float, payments: list<array<string, mixed>>}
     */
    public function recordPayrollDeductions(int $periodId, array $allocations, ?int $userId = null): array
    {
        $recorded = 0;
        $skipped  = 0;
        $total    = 0.0;
        $payments = [];

        foreach ($allocations as $allocation) {
            $loanId    = (int) ($allocation['loan_id'] ?? 0);
            $amount    = round((float) ($allocation['amount'] ?? 0), 2);
            $payrollId = isset($allocation['payroll_id']) && $allocation['payroll_id'] !== null
                ? (int) $allocation['payroll_id']
                : null;

            if ($loanId <= 0 || $amount <= 0) {
                continue;
            }

            // Idempotency guard: this period has already repaid this loan.
            $existing = Database::scalar(
                "SELECT id FROM loan_payments
                  WHERE period_id = :period_id AND loan_id = :loan_id
                    AND payment_type = 'PAYROLL'
                  LIMIT 1",
                ['period_id' => $periodId, 'loan_id' => $loanId]
            );

            if ($existing !== null) {
                $skipped++;
                continue;
            }

            // Lock the loan row so a commit racing a manual payment (or a
            // second commit) reads the same balance and never overpays the
            // loan. Requires being inside a transaction, which PayrollService
            // guarantees for the PAID transition.
            $loan = Database::selectOne(
                'SELECT * FROM loans WHERE id = :id LIMIT 1 FOR UPDATE',
                ['id' => $loanId]
            );

            if ($loan === null || (string) $loan['status'] !== 'ACTIVE') {
                $skipped++;
                continue;
            }

            $outstanding = round((float) $loan['balance'], 2);
            if ($outstanding <= 0) {
                $skipped++;
                continue;
            }

            $amount = min($amount, $outstanding);

            $result = $this->addPayment(
                $loan,
                $amount,
                'PAYROLL',
                $payrollId,
                $periodId,
                sprintf('Payroll deduction for period #%d', $periodId),
                null,
                $userId
            );

            $recorded++;
            $total = round($total + $amount, 2);
            $payments[] = [
                'loan_id'    => $loanId,
                'payment_id' => $result['payment_id'],
                'amount'     => $amount,
                'balance'    => $result['balance'],
            ];
        }

        return ['recorded' => $recorded, 'skipped' => $skipped, 'total' => $total, 'payments' => $payments];
    }

    /**
     * Undo the repayments a period already charged.
     *
     * The payroll flow no longer uses this: since Phase 3A a calculation only
     * proposes instalments and the ledger moves at PAID, so there is nothing
     * to reverse on a recalculation. It is kept for repairing installs where a
     * draft was CALCULATED before the fix (those runs already wrote ledger
     * rows), and it is exercised by the loan test suite so the arithmetic
     * cannot drift. Only rows the payroll runs wrote for this period are
     * touched - manual payments and other periods are never affected.
     *
     * @return array{reversed: int, total: float}
     */
    public function reversePayrollDeductions(int $periodId): array
    {
        $rows = Database::select(
            "SELECT id, loan_id, amount
               FROM loan_payments
              WHERE period_id = :period_id AND payment_type = 'PAYROLL'
              ORDER BY id",
            ['period_id' => $periodId]
        );

        $reversed = 0;
        $total    = 0.0;

        foreach ($rows as $row) {
            $amount = round((float) $row['amount'], 2);

            $loan = Database::selectOne(
                'SELECT id, principal_amount, balance, status FROM loans WHERE id = :id LIMIT 1',
                ['id' => (int) $row['loan_id']]
            );

            if ($loan !== null) {
                // Never give back more than the principal: a manual payment
                // recorded after the run must not be swallowed by the reversal.
                $balance = round((float) $loan['balance'] + $amount, 2);
                $balance = min($balance, round((float) $loan['principal_amount'], 2));

                $status = (string) $loan['status'];
                if ($status === 'PAID' && $balance > 0) {
                    $status = 'ACTIVE';
                }

                Database::update('loans', ['balance' => $balance, 'status' => $status], ['id' => (int) $loan['id']]);
            }

            Database::delete('loan_payments', ['id' => (int) $row['id']]);

            $reversed++;
            $total = round($total + $amount, 2);
        }

        return ['reversed' => $reversed, 'total' => $total];
    }

    /** Outstanding balance of one employee's active loans. */
    public function outstandingTotal(int $employeeId): float
    {
        return round((float) (Database::scalar(
            "SELECT COALESCE(SUM(balance), 0)
               FROM loans
              WHERE employee_id = :employee_id AND status = 'ACTIVE' AND balance > 0",
            ['employee_id' => $employeeId]
        ) ?? 0), 2);
    }

    /** Disable any new loan action affecting an excluded operator/demo employee.
     * Existing loan and repayment ledgers are kept for historical audit viewing.
     */
    private function assertDemoBorrower(int $loanId): void
    {
        if (!DemoStaffScope::enabled()) { return; }
        $employeeId = Database::scalar(
            'SELECT employee_id FROM loans WHERE id=:id LIMIT 1', ['id'=>$loanId]
        );
        if ($employeeId !== null) {
            DemoStaffScope::assertIncluded((int) $employeeId);
        }
    }

    // -----------------------------------------------------------------------
    // Internals
    // -----------------------------------------------------------------------

    /**
     * Append one ledger row and move the balance it pays for.
     *
     * @param array<string, mixed> $loan
     * @return array{payment_id: int, amount: float, balance: float, status: string}
     */
    private function addPayment(
        array $loan,
        float $amount,
        string $paymentType,
        ?int $payrollId,
        ?int $periodId,
        ?string $remarks,
        ?string $paidAt,
        ?int $userId
    ): array {
        $loanId = (int) $loan['id'];
        $amount = round($amount, 2);

        $paymentId = Database::insert('loan_payments', [
            'loan_id'      => $loanId,
            'payroll_id'   => $payrollId,
            'period_id'    => $periodId,
            'amount'       => $amount,
            'payment_type' => $paymentType,
            'paid_at'      => $paidAt ?? date('Y-m-d H:i:s'),
            'remarks'      => $remarks,
            'created_by'   => $userId,
        ]);

        $balance = round(max(0.0, round((float) $loan['balance'], 2) - $amount), 2);

        // A cancelled loan keeps its status; otherwise the last instalment
        // settles the loan by itself.
        $status = (string) $loan['status'] === 'CANCELLED'
            ? 'CANCELLED'
            : ($balance <= 0 ? 'PAID' : 'ACTIVE');

        Database::update('loans', ['balance' => $balance, 'status' => $status], ['id' => $loanId]);

        return ['payment_id' => $paymentId, 'amount' => $amount, 'balance' => $balance, 'status' => $status];
    }

    /** @return array<string, mixed> the raw row, or a RuntimeException */
    private function row(int $loanId): array
    {
        $loan = Database::selectOne('SELECT * FROM loans WHERE id = :id LIMIT 1', ['id' => $loanId]);

        if ($loan === null) {
            throw new RuntimeException('Loan not found.');
        }

        return $loan;
    }

    /**
     * Lock a filed loan for a decision, or explain why it cannot be decided.
     *
     * Callers run inside a transaction (approve() / reject() open one): the
     * lock is what stops two approvers deciding the same request twice.
     *
     * @return array<string, mixed>
     */
    private function lockForDecision(int $loanId, string $participle): array
    {
        $loan = Database::selectOne(
            'SELECT * FROM loans WHERE id = :id LIMIT 1 FOR UPDATE',
            ['id' => $loanId]
        );

        if ($loan === null) {
            throw new RuntimeException('Loan not found.');
        }

        if ((string) $loan['status'] !== 'PENDING') {
            throw new RuntimeException(sprintf(
                'Only a loan awaiting approval can be %s (current status: %s).',
                $participle,
                self::STATUSES[(string) $loan['status']] ?? (string) $loan['status']
            ));
        }

        return $loan;
    }

    /**
     * Refuse a decision taken by the user who filed the loan (Phase 3B).
     *
     * A loan filed by somebody with the approval permission stays PENDING for
     * an approver too: nothing in this service lets a filing approve itself.
     * A row with no filer (imported history) has nobody to exclude.
     *
     * @param array<string, mixed> $loan
     */
    private function refuseSelfDecision(array $loan, ?int $userId, string $action): void
    {
        if ($userId === null || $loan['created_by'] === null) {
            return;
        }

        if ((int) $loan['created_by'] !== $userId) {
            return;
        }

        throw new RuntimeException($action === 'approve'
            ? 'You cannot approve a loan you filed yourself. A different approver must decide it.'
            : 'You cannot reject a loan you filed yourself. Cancel it instead if it was filed by mistake.');
    }

    /**
     * Decorate a joined row with the labels and figures the pages render.
     *
     * @param array<string, mixed> $loan
     * @return array<string, mixed>
     */
    private function decorate(array $loan): array
    {
        $parts = array_filter([
            trim((string) ($loan['first_name'] ?? '')),
            trim((string) ($loan['middle_name'] ?? '')),
            trim((string) ($loan['last_name'] ?? '')),
            trim((string) ($loan['suffix'] ?? '')),
        ], static fn (string $part): bool => $part !== '');

        $principal = round((float) $loan['principal_amount'], 2);
        $paid      = round((float) ($loan['paid_total'] ?? 0), 2);
        $balance   = round((float) $loan['balance'], 2);

        $loan['full_name']         = implode(' ', $parts);
        $loan['principal_amount']  = $principal;
        $loan['monthly_deduction'] = round((float) $loan['monthly_deduction'], 2);
        $loan['balance']           = $balance;
        $loan['paid_total']        = $paid;
        $loan['payment_count']     = (int) ($loan['payment_count'] ?? 0);
        $loan['loan_type_label']   = self::TYPES[(string) $loan['loan_type']] ?? (string) $loan['loan_type'];
        $loan['status_label']      = self::STATUSES[(string) $loan['status']] ?? (string) $loan['status'];
        $loan['progress_percent']  = ($principal + (float) ($loan['interest_amount'] ?? 0)) > 0
            ? round(min(100.0, ($paid / ($principal + (float) ($loan['interest_amount'] ?? 0))) * 100), 1)
            : 0.0;
        // The remaining figure a cancelled loan still shows for the record.
        $loan['outstanding']       = $balance;
        $loan['is_deducting']      = (string) $loan['status'] === 'ACTIVE' && $balance > 0;
        $loan['is_pending']        = (string) $loan['status'] === 'PENDING';
        $loan['is_rejected']       = (string) $loan['status'] === 'REJECTED';
        // Who decided the loan, and why it was refused (Phase 3B): both are on
        // the joined row, normalised here so the pages render them directly.
        $loan['rejection_reason']  = $loan['rejection_reason'] ?? null;
        $loan['approved_at']       = $loan['approved_at'] ?? null;

        return $loan;
    }

    /** @param array<string, string> $map @return list<array{value: string, label: string}> */
    private static function pairs(array $map): array
    {
        $pairs = [];
        foreach ($map as $value => $label) {
            $pairs[] = ['value' => (string) $value, 'label' => $label];
        }

        return $pairs;
    }

    /**
     * Use the supplied reference when it is unique, otherwise mint one.
     */
    private function reference(string $requested, string $startDate): string
    {
        $requested = trim($requested);

        if ($requested !== '') {
            if ($this->referenceExists($requested)) {
                throw new ValidationException(['reference_no' => 'That reference number is already in use.']);
            }

            return $requested;
        }

        $stamp = date('Ymd', (int) strtotime($startDate));

        for ($attempt = 0; $attempt < 5; $attempt++) {
            $candidate = sprintf('LN-%s-%s', $stamp, strtoupper(bin2hex(random_bytes(2))));
            if (!$this->referenceExists($candidate)) {
                return $candidate;
            }
        }

        // A longer random tail so a create() never fails on a clash.
        return sprintf('LN-%s-%s', $stamp, strtoupper(bin2hex(random_bytes(4))));
    }

    private function referenceExists(string $reference, ?int $exceptLoanId = null): bool
    {
        $sql    = 'SELECT COUNT(*) FROM loans WHERE reference_no = :reference';
        $params = ['reference' => $reference];

        if ($exceptLoanId !== null) {
            $sql .= ' AND id <> :except_id';
            $params['except_id'] = $exceptLoanId;
        }

        return (int) (Database::scalar($sql, $params) ?? 0) > 0;
    }

    private function paymentCount(int $loanId): int
    {
        return (int) (Database::scalar(
            'SELECT COUNT(*) FROM loan_payments WHERE loan_id = :loan_id',
            ['loan_id' => $loanId]
        ) ?? 0);
    }

    /** @param array<string, mixed> $employee */
    private function employeeName(array $employee): string
    {
        $parts = array_filter([
            trim((string) ($employee['first_name'] ?? '')),
            trim((string) ($employee['middle_name'] ?? '')),
            trim((string) ($employee['last_name'] ?? '')),
            trim((string) ($employee['suffix'] ?? '')),
        ], static fn (string $part): bool => $part !== '');

        return $parts === [] ? (string) ($employee['employee_number'] ?? 'employee') : implode(' ', $parts);
    }
}