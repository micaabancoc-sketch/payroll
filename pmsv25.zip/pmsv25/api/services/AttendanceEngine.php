<?php
/**
 * Attendance engine (Phase 7).
 *
 * Determines PRESENT / LATE / ABSENT / UNDERTIME / REST_DAY / HOLIDAY / LEAVE
 * from the employee's schedule, the holiday calendar and approved leave
 * (Phase 8 / Phase 9 / Phase 10 all feed in here).
 *
 * All tolerances come from system_settings, so the administrator can change
 * grace periods and rules without touching PHP source (Phase 12 / Phase 19).
 */

declare(strict_types=1);

namespace App\Services;

use App\Core\AuditLogger;
use App\Core\Database;
use App\Core\Settings;
use DateTimeImmutable;
use Throwable;

final class AttendanceEngine
{
    /** @return array<string, mixed>|null */
    public function findAttendance(int $employeeId, string $date): ?array
    {
        return Database::selectOne(
            'SELECT * FROM attendance WHERE employee_id = :emp AND attendance_date = :date AND deleted_at IS NULL LIMIT 1',
            ['emp' => $employeeId, 'date' => $date]
        );
    }

    /**
     * Resolve the schedule context for a date: the assigned shift, the
     * rest-day flag and any holiday that applies.
     *
     * @return array{
     *   shift: array<string, mixed>|null,
     *   schedule_id: int|null,
     *   is_rest_day: bool,
     *   holiday: array<string, mixed>|null,
     *   grace_minutes: int
     * }
     */
    public function contextFor(int $employeeId, string $date): array
    {
        $employee = Database::selectOne(
            'SELECT work_schedule_id FROM employees WHERE id = :id AND deleted_at IS NULL',
            ['id' => $employeeId]
        );

        // Company standard: Monday-Saturday 08:00-17:00, Sunday rest day.
        // Historical attendance rows are preserved. A correction recalculates only the selected record.
        $standardId = Database::scalar(
            "SELECT id FROM work_schedules WHERE code = 'STD-MFS' AND is_active = 1 AND deleted_at IS NULL LIMIT 1"
        );
        $scheduleId = $standardId !== null ? (int)$standardId : ($employee['work_schedule_id'] ?? null);
        $dayOfWeek  = (int) date('w', strtotime($date)); // 0 = Sunday

        $shift  = null;
        $isRest = true;

        if ($scheduleId !== null) {
            $day = Database::selectOne(
                'SELECT shift_id, is_rest_day FROM work_schedule_days
                  WHERE work_schedule_id = :sid AND day_of_week = :dow
                  LIMIT 1',
                ['sid' => (int) $scheduleId, 'dow' => $dayOfWeek]
            );

            if ($day !== null) {
                $isRest = $dayOfWeek === 0 || (int) $day['is_rest_day'] === 1 || $day['shift_id'] === null;

                if ($day['shift_id'] !== null) {
                    $shift = Database::selectOne(
                        'SELECT * FROM shifts WHERE id = :id AND is_active = 1 AND deleted_at IS NULL',
                        ['id' => (int) $day['shift_id']]
                    );

                    if ($shift === null) {
                        $isRest = true;
                    }
                }
            }
        }

        // A zero-minute grace period is intentional (8:01 is already late).
        // Do not replace it with an old fallback of 5 minutes.
        $graceMinutes = isset($shift['grace_period_minutes'])
            ? (int) $shift['grace_period_minutes']
            : Settings::int('attendance.grace_period_minutes', 0);

        return [
            'shift'         => $shift,
            'schedule_id'   => $scheduleId === null ? null : (int) $scheduleId,
            'is_rest_day'   => $isRest,
            'holiday'       => $this->holidayFor($date),
            'grace_minutes' => $graceMinutes,
        ];
    }

    /**
     * The holiday that applies to a date, honouring recurring holidays.
     *
     * @return array<string, mixed>|null
     */
    public function holidayFor(string $date): ?array
    {
        $exact = Database::selectOne(
            "SELECT * FROM holidays
              WHERE status = 'ACTIVE' AND deleted_at IS NULL AND holiday_date = :date
              ORDER BY FIELD(holiday_type, 'REGULAR', 'SPECIAL', 'OPTIONAL', 'REST')
              LIMIT 1",
            ['date' => $date]
        );

        if ($exact !== null) {
            return $exact;
        }

        // Recurring holidays repeat every year on the same month/day.
        return Database::selectOne(
            "SELECT * FROM holidays
              WHERE status = 'ACTIVE' AND deleted_at IS NULL
                AND is_recurring = 1
                AND MONTH(holiday_date) = :month AND DAY(holiday_date) = :day
              ORDER BY FIELD(holiday_type, 'REGULAR', 'SPECIAL', 'OPTIONAL', 'REST')
              LIMIT 1",
            ['month' => (int) date('n', strtotime($date)), 'day' => (int) date('j', strtotime($date))]
        );
    }

    /**
     * Approved leave that covers a date, if any (rule 7).
     *
     * @return array<string, mixed>|null
     */
    public function leaveFor(int $employeeId, string $date): ?array
    {
        return Database::selectOne(
            "SELECT lr.id, lr.leave_type_id, lr.start_date, lr.end_date,
                    lt.code AS leave_code, lt.name AS leave_name, lt.is_paid
               FROM leave_requests lr
               JOIN leave_types lt ON lt.id = lr.leave_type_id
               WHERE lr.employee_id = :emp
                 AND lr.status = 'APPROVED'
                 AND lr.deleted_at IS NULL
                 AND lr.start_date <= :date_from
                 AND lr.end_date >= :date_to
               LIMIT 1",
            ['emp' => $employeeId, 'date_from' => $date, 'date_to' => $date]
        );
    }
/**
     * Recalculate and persist a whole attendance row from its times.
     *
     * @param array<string, mixed> $row existing attendance record
     * @return array<string, mixed> the updated record
     */
    public function recalculate(array $row): array
    {
        $employeeId = (int) $row['employee_id'];
        $date       = (string) $row['attendance_date'];

        $context = $this->contextFor($employeeId, $date);
        $shift   = $context['shift'];

        $timeIn  = $row['time_in'] !== null ? new DateTimeImmutable((string) $row['time_in']) : null;
        $timeOut = $row['time_out'] !== null ? new DateTimeImmutable((string) $row['time_out']) : null;

        // Auto-overtime threshold (manageable in Settings): overtime below
        // these minutes is not counted at all.
        $otThreshold = max(0, Settings::int('attendance.overtime_auto_minutes', 20));

        $workedHours      = 0.0;
        $lateMinutes      = 0;
        $undertimeMinutes = 0;
        $overtimeHours    = 0.0;

        $leave  = $this->leaveFor($employeeId, $date);
        $status = 'ABSENT';

        // The company Sunday is always REST_DAY, including when a manual
        // Time In/Out is recorded. An approved leave cannot consume Sunday.
        if ($context['is_rest_day']) {
            $status = 'REST_DAY';
        } elseif ($leave !== null) {
            $status = 'LEAVE';
        } elseif ($context['holiday'] !== null) {
            $status = 'HOLIDAY';
        }

        if ($timeIn !== null && $timeOut !== null) {
            $workedMinutes = $this->minutesBetween($timeIn, $timeOut);

            // Subtract the break when the shift defines one.
            if ($shift !== null && $shift['break_start'] !== null && $shift['break_end'] !== null) {
                $workedMinutes -= $this->overlappingBreakMinutes($timeIn, $timeOut, $shift);
            }

            // Sundays have no assigned shift; the standard 12:00-13:00 meal
            // break must still be deducted from a manually entered 08:00-17:00 span.
            if ($shift === null) {
                $lunchStart = new DateTimeImmutable($date . ' 12:00:00');
                $lunchEnd = new DateTimeImmutable($date . ' 13:00:00');
                $overlapStart = max($timeIn->getTimestamp(), $lunchStart->getTimestamp());
                $overlapEnd = min($timeOut->getTimestamp(), $lunchEnd->getTimestamp());
                $workedMinutes -= max(0, (int)floor(($overlapEnd - $overlapStart) / 60));
            }
            $workedHours = round(max(0, $workedMinutes) / 60, 2);

            if ($shift !== null) {
                $scheduledStart = $this->shiftStartOn($shift, $date);
                $scheduledEnd   = $this->shiftEndOn($shift, $date);

                // Late: actual minutes after the scheduled start, minus the
                // grace period (5 minutes by default, overridable per shift or
                // via attendance.grace_period_minutes setting).
                $rawLate = $this->minutesBetween($scheduledStart, $timeIn);
                $lateMinutes = max(0, $rawLate - $context['grace_minutes']);

                // Undertime: minutes left before the scheduled end.
                $undertimeMinutes = max(0, $this->minutesBetween($timeOut, $scheduledEnd));

                // Never infer payable OT merely because a scan is late.
                // The verified overtime request below is the sole OT source.
            }

            if ($status === 'ABSENT') {
                $status = $lateMinutes > 0 ? 'LATE' : 'PRESENT';

                if ($lateMinutes === 0 && $undertimeMinutes > 0) {
                    $status = 'UNDERTIME';
                }
            }

            if ($context['is_rest_day'] && strtoupper((string)($row['source'] ?? '')) === 'MANUAL') {
                // Manual Sunday Time In/Out is an attendance time log, NOT a
                // verified work shift. Preserve raw times but report 0 regular
                // worked hours, late, undertime and inferred overtime.
                $workedHours = 0.0;
            }
        } elseif ($timeIn !== null) {
            // An unfinished Sunday scan remains a rest-day record. Ordinary
            // working days still require completion/verification.
            if (!$context['is_rest_day']) { $status = 'INCOMPLETE'; }

            if ($shift !== null) {
                $scheduledStart = $this->shiftStartOn($shift, $date);
                $rawLate        = $this->minutesBetween($scheduledStart, $timeIn);
                $lateMinutes    = max(0, $rawLate - $context['grace_minutes']);
            }
        }

        // Source of truth for payable overtime is HR payroll VERIFIED QR OT.
        // Keep the ledger display consistent with payroll and do not derive OT
        // from imported or manual attendance timestamps.
        $verifiedMinutes = Database::scalar(
            "SELECT COALESCE(SUM(applied_hours), 0) FROM overtime_requests
              WHERE employee_id = :emp AND overtime_date = :date
                AND status = 'APPROVED' AND payroll_verified_at IS NOT NULL",
            ['emp' => $employeeId, 'date' => $date]
        );
        $overtimeHours = round(max(0.0, (float)$verifiedMinutes), 2);

        // Late and undertime only accrue on days the employee was expected to
        // work. Approved leave, holidays and rest days are non-workday statuses:
        // scans on those days may record worked hours (overtime) but never
        // lateness or early departure (rule 7).
        if ($status === 'LEAVE' || $status === 'HOLIDAY' || $status === 'REST_DAY') {
            $lateMinutes      = 0;
            $undertimeMinutes = 0;
        }

        $data = [
            'shift_id'          => $shift['id'] ?? null,
            'work_schedule_id'  => $context['schedule_id'],
            'scheduled_start'   => $shift !== null ? substr((string) $shift['start_time'], 0, 8) : null,
            'scheduled_end'     => $shift !== null ? substr((string) $shift['end_time'], 0, 8) : null,
            'worked_hours'      => $workedHours,
            'late_minutes'      => $lateMinutes,
            'undertime_minutes' => $undertimeMinutes,
            'overtime_hours'    => $overtimeHours,
            'status'            => $status,
            'is_rest_day'       => $context['is_rest_day'] ? 1 : 0,
            'is_holiday'        => $context['holiday'] !== null ? 1 : 0,
            'leave_request_id'  => $leave['id'] ?? null,
        ];

        Database::update('attendance', $data, ['id' => (int) $row['id']]);

        return $this->findAttendance($employeeId, $date) ?? array_merge($row, $data);
    }
/**
     * Close attendance rows left open once the shift has ended (Phase 7).
     *
     * @return int number of rows closed
     */
    public function closeOpenAttendance(?string $date = null): int
    {
        $date = $date ?? date('Y-m-d');

        $open = Database::select(
            'SELECT a.* FROM attendance a
               JOIN shifts s ON s.id = a.shift_id
              WHERE a.attendance_date = :date
                AND a.deleted_at IS NULL
                AND a.time_in IS NOT NULL
                AND a.time_out IS NULL
                AND a.status = :incomplete
                AND s.end_time < :now_time',
            ['date' => $date, 'incomplete' => 'INCOMPLETE', 'now_time' => date('H:i:s')]
        );

        $closed = 0;

        foreach ($open as $row) {
            $shift = Database::selectOne('SELECT * FROM shifts WHERE id = :id', ['id' => (int) $row['shift_id']]);
            if ($shift === null) {
                continue;
            }

            $scheduledEnd = $this->shiftEndOn($shift, (string) $row['attendance_date']);

            Database::execute(
                'UPDATE attendance SET time_out = :out, source = :source WHERE id = :id',
                [
                    'out'    => $scheduledEnd->format('Y-m-d H:i:s'),
                    'source' => 'AUTO',
                    'id'     => (int) $row['id'],
                ]
            );

            $this->recalculate($this->findAttendance((int) $row['employee_id'], (string) $row['attendance_date']));
            $closed++;
        }

        return $closed;
    }

    /**
     * Mark working days in a period with no attendance record as ABSENT so
     * absence is real, not implied (rule 9).
     *
     * @return int number of rows created
     */
    public function markAbsences(int $employeeId, string $startDate, string $endDate): int
    {
        $created = 0;
        $start   = new DateTimeImmutable($startDate);
        $end     = new DateTimeImmutable($endDate);

        for ($date = $start; $date <= $end; $date = $date->modify('+1 day')) {
            $dateString = $date->format('Y-m-d');

            if ($this->findAttendance($employeeId, $dateString) !== null) {
                continue;
            }

            // Archived rows still hold the unique key: leave them out of the
            // books instead of crashing on a duplicate insert.
            $archived = Database::selectOne(
                'SELECT id FROM attendance WHERE employee_id = :emp AND attendance_date = :date AND deleted_at IS NOT NULL LIMIT 1',
                ['emp' => $employeeId, 'date' => $dateString]
            );
            if ($archived !== null) {
                continue;
            }

            $context = $this->contextFor($employeeId, $dateString);

            // Rest days and holidays are never absences.
            if ($context['is_rest_day'] || $context['holiday'] !== null) {
                continue;
            }

            $leave  = $this->leaveFor($employeeId, $dateString);
            $status = $leave !== null ? 'LEAVE' : 'ABSENT';

            Database::insert('attendance', [
                'employee_id'      => $employeeId,
                'attendance_date'  => $dateString,
                'shift_id'         => $context['shift']['id'] ?? null,
                'work_schedule_id' => $context['schedule_id'],
                'scheduled_start'  => $context['shift'] !== null ? substr((string) $context['shift']['start_time'], 0, 8) : null,
                'scheduled_end'    => $context['shift'] !== null ? substr((string) $context['shift']['end_time'], 0, 8) : null,
                'worked_hours'     => 0.00,
                'status'           => $status,
                'is_rest_day'      => $context['is_rest_day'] ? 1 : 0,
                'is_holiday'       => $context['holiday'] !== null ? 1 : 0,
                'leave_request_id' => $leave['id'] ?? null,
                'source'           => 'AUTO',
            ]);

            $created++;
        }

        return $created;
    }
    // -----------------------------------------------------------------------
    // 30-minute late cut-off and automatic absence
    // -----------------------------------------------------------------------

    /**
     * Minutes past the scheduled start after which a time-in is refused.
     * Configurable (attendance.late_cutoff_minutes); 30 by default.
     */
    public function lateCutoffMinutes(): int
    {
        return max(0, Settings::int('attendance.late_cutoff_minutes', 60));
    }

    /**
     * The exact moment a time-in stops being allowed: scheduled start + the
     * late cut-off.
     *
     * The boundary is inclusive, so "exactly 30 minutes late" is already too
     * late and the comparison must be `>=`.
     */
    public function lateCutoffOn(array $shift, string $date): DateTimeImmutable
    {
        return $this->shiftStartOn($shift, $date)
            ->modify(sprintf('+%d minutes', $this->lateCutoffMinutes()))
            ->modify('+59 seconds'); // 9:00:00–9:00:59 remains allowed; 9:01:00 is ABSENT.
    }

    /**
     * Which attendance day a moment belongs to.
     *
     * For a day shift this is simply the calendar day. For an overnight shift
     * the early-morning tail still belongs to the shift that started the
     * previous evening, so a badge read at 00:30 belongs to yesterday -- not
     * "today", whose shift has not started yet.
     */
    public function attendanceDateFor(int $employeeId, DateTimeImmutable $at): string
    {
        $today   = $at->format('Y-m-d');
        $current = $this->contextFor($employeeId, $today);

        if ($current['shift'] !== null && $at < $this->shiftStartOn($current['shift'], $today)) {
            $yesterday = (new DateTimeImmutable($today))->modify('-1 day')->format('Y-m-d');
            $previous  = $this->contextFor($employeeId, $yesterday);
            $shift     = $previous['shift'];

            if ($shift !== null && (int) ($shift['is_overnight'] ?? 0) === 1) {
                $start = $this->shiftStartOn($shift, $yesterday);
                $end   = $this->shiftEndOn($shift, $yesterday);

                if ($at >= $start && $at < $end) {
                    return $yesterday;
                }
            }
        }

        return $today;
    }

    /**
     * Whether an absence may be recorded for this employee/date: the cut-off
     * has passed, the employee is due to work, and nothing already proves the
     * day is accounted for.
     *
     * Read-only, so the QR preview can report exactly the absence the real
     * scan would write. Every legitimate exception is honoured here (Phase 8/9/10).
     */
    public function canMarkAbsence(int $employeeId, string $date, ?DateTimeImmutable $now = null): bool
    {
        if (!Settings::bool('attendance.auto_absence', true)) {
            return false;
        }

        $now     = $now ?? new DateTimeImmutable('now');
        $context = $this->contextFor($employeeId, $date);

        // No assigned shift, a rest day or a holiday is never an absence.
        if ($context['shift'] === null || $context['is_rest_day'] || $context['holiday'] !== null) {
            return false;
        }

        // Approved leave is a valid exception, not an absence.
        if ($this->leaveFor($employeeId, $date) !== null) {
            return false;
        }

        // Any existing record -- a valid time-in, an earlier absence, an
        // auto leave row -- is left exactly as it is. This is what makes the
        // process idempotent and stops it overwriting real attendance.
        if ($this->findAttendance($employeeId, $date) !== null) {
            return false;
        }

        // Only once this employee's OWN cut-off has passed.
        return $now > $this->lateCutoffOn($context['shift'], $date);
    }

    /**
     * Record ABSENT for one employee/date once the cut-off passed with no
     * time-in. Returns true only when a new row was created.
     */
    public function markAbsenceAfterCutoff(int $employeeId, string $date, ?DateTimeImmutable $now = null): bool
    {
        if (!$this->canMarkAbsence($employeeId, $date, $now)) {
            return false;
        }

        $context = $this->contextFor($employeeId, $date);

        try {
            $id = Database::insert('attendance', [
                'employee_id'      => $employeeId,
                'attendance_date'  => $date,
                'shift_id'         => $context['shift']['id'] ?? null,
                'work_schedule_id' => $context['schedule_id'],
                'scheduled_start'  => $context['shift'] !== null ? substr((string) $context['shift']['start_time'], 0, 8) : null,
                'scheduled_end'    => $context['shift'] !== null ? substr((string) $context['shift']['end_time'], 0, 8) : null,
                'worked_hours'     => 0.00,
                'status'           => 'ABSENT',
                'is_rest_day'      => 0,
                'is_holiday'       => 0,
                'source'           => 'AUTO',
            ]);
        } catch (Throwable $e) {
            // The (employee_id, attendance_date) unique key means a concurrent
            // pass already wrote the row: that is success, not a failure.
            return false;
        }

        AuditLogger::record(
            AuditLogger::ATTENDANCE_CREATE,
            'attendance',
            $id,
            sprintf('Automatically marked ABSENT for %s (no time-in within the late cut-off)', $date)
        );

        return true;
    }

    /**
     * Reconcile scheduled employees against their own cut-off, so absence is
     * real even when nobody ever opens the scanner.
     *
     * @param list<int>|null $employeeIds restrict to specific employees (tests)
     * @return int rows created
     */
    public function markAbsencesAfterCutoff(?string $date = null, ?DateTimeImmutable $now = null, ?array $employeeIds = null): int
    {
        $now  = $now ?? new DateTimeImmutable('now');
        $date = $date ?? $now->format('Y-m-d');

        if ($employeeIds === null) {
            $rows = Database::select(
                'SELECT id FROM employees
                  WHERE deleted_at IS NULL
                    AND status = :status
                    AND work_schedule_id IS NOT NULL',
                ['status' => 'ACTIVE']
            );

            $employeeIds = array_map(static fn (array $row): int => (int) $row['id'], $rows);
        }

        $created = 0;

        foreach ($employeeIds as $employeeId) {
            $employeeId = (int) $employeeId;

            if ($this->markAbsenceAfterCutoff($employeeId, $date, $now)) {
                $created++;
            }

            // Also reconcile the early-morning tail of an overnight shift: at
            // 00:30 the current shift belongs to yesterday, whose cut-off has
            // already passed. attendanceDateFor() returns today for every
            // ordinary day shift, so this never reaches back historically.
            $currentDate = $this->attendanceDateFor($employeeId, $now);

            if ($currentDate !== $date && $this->markAbsenceAfterCutoff($employeeId, $currentDate, $now)) {
                $created++;
            }
        }

        return $created;
    }

    // -----------------------------------------------------------------------
    // Time helpers
    // -----------------------------------------------------------------------

    /** Whole minutes between two datetimes (never negative). */
    public function minutesBetween(DateTimeImmutable $from, DateTimeImmutable $to): int
    {
        return max(0, (int) round(($to->getTimestamp() - $from->getTimestamp()) / 60));
    }

    /** Shift start on a given date, as a datetime. */
    public function shiftStartOn(array $shift, string $date): DateTimeImmutable
    {
        return new DateTimeImmutable($date . ' ' . substr((string) $shift['start_time'], 0, 8));
    }

    /**
     * Shift end on a given date, as a datetime. Overnight shifts end the
     * following calendar day (Phase 8).
     */
    public function shiftEndOn(array $shift, string $date): DateTimeImmutable
    {
        $end = new DateTimeImmutable($date . ' ' . substr((string) $shift['end_time'], 0, 8));

        if ((int) ($shift['is_overnight'] ?? 0) === 1) {
            $end = $end->modify('+1 day');
        }

        return $end;
    }

    /**
     * Minutes of a defined break that fall inside the scanned window.
     *
     * @param array<string, mixed> $shift
     */
    public function overlappingBreakMinutes(DateTimeImmutable $timeIn, DateTimeImmutable $timeOut, array $shift): int
    {
        $breakStart = new DateTimeImmutable($timeIn->format('Y-m-d') . ' ' . substr((string) $shift['break_start'], 0, 8));
        $breakEnd   = new DateTimeImmutable($timeIn->format('Y-m-d') . ' ' . substr((string) $shift['break_end'], 0, 8));

        $overlapStart = max($timeIn, $breakStart);
        $overlapEnd   = min($timeOut, $breakEnd);

        if ($overlapEnd <= $overlapStart) {
            return 0;
        }

        return (int) round(($overlapEnd->getTimestamp() - $overlapStart->getTimestamp()) / 60);
    }

    /**
     * Night-differential hours inside a scanned window (Phase 12).
     */
    public function nightDifferentialHours(DateTimeImmutable $timeIn, DateTimeImmutable $timeOut): float
    {
        [$nsH, $nsM] = array_pad(explode(':', Settings::string('payroll.night_shift_start', '22:00:00')), 2, 0);
        [$neH, $neM] = array_pad(explode(':', Settings::string('payroll.night_shift_end', '06:00:00')), 2, 0);

        $minutes = 0;

        // Walk day by day so long shifts and overnight windows are covered.
        for ($day = $timeIn->setTime(0, 0); $day <= $timeOut->setTime(0, 0); $day = $day->modify('+1 day')) {
            $from = $day->setTime((int) $nsH, (int) $nsM);
            $to   = $day->modify('+1 day')->setTime((int) $neH, (int) $neM);

            $overlapStart = max($timeIn, $from);
            $overlapEnd   = min($timeOut, $to);

            if ($overlapEnd > $overlapStart) {
                $minutes += ($overlapEnd->getTimestamp() - $overlapStart->getTimestamp()) / 60;
            }
        }

        return round($minutes / 60, 2);
    }
}