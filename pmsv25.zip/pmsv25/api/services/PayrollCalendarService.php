<?php
/** Automatic fixed semi-monthly periods. No salary release is performed here. */
declare(strict_types=1);
namespace App\Services;

use App\Core\Database;
use DateTimeImmutable;
use DateTimeZone;

final class PayrollCalendarService
{
    public static function periodsForMonth(int $year, int $month): array
    {
        $first = new DateTimeImmutable(sprintf('%04d-%02d-01', $year, $month), new DateTimeZone('Asia/Manila'));
        return [
            [$first->format('Y-m-01'), $first->format('Y-m-15'), $first->format('Y-m-20')],
            [$first->format('Y-m-16'), $first->format('Y-m-t'), $first->modify('first day of next month')->format('Y-m-05')],
        ];
    }

    /** @param string[] $holidays Exact known bank-closure/holiday dates. */
    public static function adjustedPayday(string $date, array $holidays = []): string
    {
        $day = new DateTimeImmutable($date, new DateTimeZone('Asia/Manila'));
        $blocked = array_fill_keys($holidays, true);
        for ($i = 0; $i < 30; $i++) {
            if ((int) $day->format('N') < 6 && !isset($blocked[$day->format('Y-m-d')])) {
                return $day->format('Y-m-d');
            }
            $day = $day->modify('-1 day');
        }
        throw new \RuntimeException('No banking day within 30 days; verify holiday calendar.');
    }

    /** Idempotent creation for a month; never overwrites an approved period. */
    public function ensureMonth(int $year, int $month): int
    {
        $created = 0;
        foreach (self::periodsForMonth($year, $month) as [$start, $end, $payday]) {
            $existing = Database::scalar('SELECT id FROM payroll_periods WHERE start_date = :s AND end_date = :e LIMIT 1', ['s'=>$start, 'e'=>$end]);
            if ($existing !== null) continue;
            $overlap = Database::scalar('SELECT id FROM payroll_periods WHERE deleted_at IS NULL AND NOT(end_date < :s OR start_date > :e) LIMIT 1', ['s'=>$start,'e'=>$end]);
            if ($overlap !== null) continue;
            // Only approved active entries in the holiday calendar; statutory holidays may require yearly updates.
            $holidayRows = Database::select("SELECT holiday_date FROM holidays WHERE status='ACTIVE' AND deleted_at IS NULL AND holiday_date BETWEEN :from_date AND :to_date", ['from_date'=>date('Y-m-d',strtotime($payday.' -30 days')), 'to_date'=>$payday]);
            $holidays = array_column($holidayRows, 'holiday_date');
            $adjusted = self::adjustedPayday($payday, $holidays);
            $code = 'PP-' . str_replace('-', '', $start) . '-' . str_replace('-', '', $end);
            try {
                Database::insert('payroll_periods', [
                    'code'=>$code, 'name'=>date('M j', strtotime($start)) . '–' . date('j, Y',strtotime($end)),
                    'start_date'=>$start, 'end_date'=>$end, 'pay_date'=>$adjusted,
                    'status'=>'DRAFT', 'created_by'=>null,
                ]);
                $created++;
            } catch (\PDOException $e) {
                // Concurrent jobs may create the same unique period. Do not mask unrelated database errors.
                if ((string)$e->getCode() !== '23000') throw $e;
            }
        }
        return $created;
    }
}
