<?php
/**
 * New payroll cutoffs must be chronological, never retrospective.
 * Existing payroll history is not changed, and genuine historical
 * backfills require a separately authorized audited migration.
 */
declare(strict_types=1);

namespace App\Services;

use DateTimeImmutable;
use DateTimeZone;

final class PayrollPeriodPolicy
{
    /** @return array<string, string> Field-specific validation messages. */
    public static function validateNewPeriod(
        string $startDate,
        string $endDate,
        ?string $latestExistingEndDate,
        ?string $today = null
    ): array {
        $today ??= (new DateTimeImmutable('now', new DateTimeZone('Asia/Manila')))->format('Y-m-d');
        if ($endDate < $today) {
            return ['end_date' => 'Cannot create a past payroll period: the cutoff already ended before today ('.$today.').'];
        }
        if ($latestExistingEndDate !== null && $startDate <= $latestExistingEndDate) {
            return ['start_date' => 'Cannot add an earlier payroll cutoff. The latest existing period ends on '
                . $latestExistingEndDate . '. Create the next cutoff after that date.'];
        }
        return [];
    }
}
