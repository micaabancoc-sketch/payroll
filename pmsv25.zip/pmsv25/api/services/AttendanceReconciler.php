<?php
/**
 * Absence reconciliation (60-minute late cut-off rule).
 *
 * Marks every scheduled employee ABSENT once their own cut-off has passed
 * without a valid time-in, so absence is real even when nobody opens the
 * scanner. Safe to run as often as you like:
 *
 *  - a MySQL advisory lock (GET_LOCK) serialises overlapping runs, so two
 *    Task Scheduler passes cannot process the same employees at once;
 *  - the engine itself is idempotent -- an employee is only marked once and
 *    an existing record is never overwritten.
 */

declare(strict_types=1);

namespace App\Services;

use App\Core\Database;
use App\Core\Logger;
use DateTimeImmutable;

final class AttendanceReconciler
{
    /** Named advisory lock: unique to this process across all connections. */
    private const LOCK_NAME = 'pms_attendance_absence_reconciler';

    public function __construct(private AttendanceEngine $engine = new AttendanceEngine())
    {
    }

    /**
     * Reconcile scheduled employees against their own cut-off.
     *
     * @param list<int>|null $employeeIds restrict to specific employees (tests)
     * @return array{date: string, created: int, ran: bool, locked: bool}
     */
    public function run(?DateTimeImmutable $now = null, ?array $employeeIds = null): array
    {
        // Safety policy V17: no QR scan is not proof of ABSENT. HR must verify manually.
        // The old scheduler must not silently create AUTO ABSENT rows.
        return ['date'=>($now ?? new DateTimeImmutable('now'))->format('Y-m-d'), 'created'=>0, 'ran'=>false, 'locked'=>false];
        $now  = $now ?? new DateTimeImmutable('now');
        $date = $now->format('Y-m-d');

        // GET_LOCK returns 1 when acquired, 0 when another session already
        // holds it, and NULL on error. Without it two overlapping runs would
        // do the same work twice -- harmless because the engine is idempotent,
        // but wasteful.
        $acquired = (int) (Database::scalar(
            'SELECT GET_LOCK(:name, 5) AS locked',
            ['name' => self::LOCK_NAME]
        ) ?? 0);

        if ($acquired !== 1) {
            return ['date' => $date, 'created' => 0, 'ran' => false, 'locked' => true];
        }

        try {
            $created = $this->engine->markAbsencesAfterCutoff($date, $now, $employeeIds);
        } finally {
            Database::scalar('SELECT RELEASE_LOCK(:name) AS released', ['name' => self::LOCK_NAME]);
        }

        if ($created > 0) {
            Logger::info('Absence reconciliation created rows', ['date' => $date, 'created' => $created]);
        }

        return ['date' => $date, 'created' => $created, 'ran' => true, 'locked' => false];
    }
}