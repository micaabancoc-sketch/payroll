<?php
/**
 * Employee QR issuing and validation (Phase 5).
 *
 * Security rules from the brief:
 *  - the QR contains ONLY a random token, never employee data;
 *  - the token is stored only as a peppered SHA-256 hash;
 *  - the plaintext is returned exactly once, at generation time.
 */

declare(strict_types=1);

namespace App\Services;

use App\Core\Auth;
use App\Core\Database;
use App\Core\Logger;
use App\Core\Settings;
use RuntimeException;

final class QrCodeService
{
    /** Unambiguous alphabet: no 0/O or 1/I/L confusion when printed. */
    private const ALPHABET = '23456789ABCDEFGHJKLMNPQRSTUVWXYZ';

    public function __construct(private QrCodeGenerator $generator = new QrCodeGenerator())
    {
    }

    /**
     * Issue a fresh QR code for an employee.
     *
     * @return array{qr_id: int, token: string, image: string, serial_no: int}
     * @throws RuntimeException
     */
    public function issue(int $employeeId, ?int $issuedBy = null, bool $replace = false): array
    {
        \App\Core\DemoStaffScope::assertDemoParticipant($employeeId);
        $employee = Database::scalar(
            'SELECT id FROM employees WHERE id = :id AND deleted_at IS NULL',
            ['id' => $employeeId]
        );

        if ($employee === null) {
            throw new RuntimeException('Employee not found.');
        }

        return Database::transaction(
            function () use ($employeeId, $issuedBy, $replace): array {
                // Only one ACTIVE code may exist per employee at a time.
                $existing = Database::scalar(
                    'SELECT id FROM employee_qr_codes
                      WHERE employee_id = :emp AND status = :status
                      ORDER BY serial_no DESC LIMIT 1',
                    ['emp' => $employeeId, 'status' => 'ACTIVE']
                );

                if ($existing !== null) {
                    if (!$replace) {
                        throw new RuntimeException(
                            'This employee already has an active QR code. Regenerate to issue a replacement.'
                        );
                    }

                    // The old code is permanently invalidated before the new one exists.
                    Database::execute(
                        'UPDATE employee_qr_codes
                            SET status = :status, disabled_at = NOW(), disabled_reason = :reason
                          WHERE id = :id',
                        [
                            'status' => 'REPLACED',
                            'reason' => 'Replaced by a newly issued QR code',
                            'id'     => (int) $existing,
                        ]
                    );
                }

                $serialNo = (int) (Database::scalar(
                    'SELECT COALESCE(MAX(serial_no), 0) + 1 FROM employee_qr_codes WHERE employee_id = :emp',
                    ['emp' => $employeeId]
                ) ?? 1);

                $token = $this->generateToken();

                $qrId = Database::insert('employee_qr_codes', [
                    'employee_id'   => $employeeId,
                    'token_hash'    => $this->hashToken($token),
                    'token_hint'    => substr($token, -8),
                    'serial_no'     => $serialNo,
                    'status'        => 'ACTIVE',
                    'issued_at'     => date('Y-m-d H:i:s'),
                    'expires_at'    => $this->expiryDate(),
                    'issued_by'     => $issuedBy ?? Auth::id(),
                    'qr_image_path' => null,
                ]);

                // The payload is the token only: no name, no employee number.
                $image = $this->writeSvg($employeeId, $serialNo, $token);

                Database::update('employee_qr_codes', ['qr_image_path' => $image], ['id' => $qrId]);

                return [
                    'qr_id'     => $qrId,
                    'token'     => $token,
                    'image'     => $image,
                    'serial_no' => $serialNo,
                ];
            }
        );
    }
/**
     * Resolve a scanned token into its owner.
     *
     * @return array{employee_id: int, qr_id: int, employee: array<string, mixed>}|null
     *         null when the token is unknown; throws a RuntimeException with a
     *         human-readable reason when the code is disabled/replaced/expired
     *         or the employee is no longer active.
     */
    public function resolve(string $token): ?array
    {
        $token = trim($token);
        if ($token === '') {
            return null;
        }

        $row = Database::selectOne(
            'SELECT id, employee_id, status, expires_at
               FROM employee_qr_codes
              WHERE token_hash = :hash
              LIMIT 1',
            ['hash' => $this->hashToken($token)]
        );

        if ($row === null) {
            return null;
        }

        $status = (string) $row['status'];

        if ($status === 'DISABLED') {
            throw new RuntimeException('This QR code has been disabled. Please use your replacement code.');
        }

        if ($status === 'REPLACED') {
            throw new RuntimeException('This QR code was replaced. Please use your current QR code.');
        }

        if ($row['expires_at'] !== null && strtotime((string) $row['expires_at']) < time()) {
            Database::update('employee_qr_codes', ['status' => 'EXPIRED'], ['id' => (int) $row['id']]);
            throw new RuntimeException('This QR code has expired. Please request a new one.');
        }

        $employee = Database::selectOne(
            'SELECT id, employee_number, first_name, middle_name, last_name, suffix,
                    status, department_id, position_id, work_schedule_id,
                    basic_salary, salary_type, employment_type, archived_at
               FROM employees
              WHERE id = :id AND deleted_at IS NULL',
            ['id' => (int) $row['employee_id']]
        );

        if ($employee === null) {
            throw new RuntimeException('The employee linked to this QR code no longer exists.');
        }

        if ($employee['status'] !== 'ACTIVE' || $employee['archived_at'] !== null) {
            throw new RuntimeException(sprintf(
                'This QR code belongs to an employee whose record is %s.',
                strtolower((string) $employee['status'])
            ));
        }

        return [
            'employee_id' => (int) $row['employee_id'],
            'qr_id'       => (int) $row['id'],
            'employee'    => $employee,
        ];
    }

    /**
     * Resolve an employee straight to their currently active code.
     *
     * This is the manual-entry path: the operator names the person instead of
     * presenting a badge, so there is no token to verify. It exists only for
     * authenticated operators and is recorded as an override by the caller --
     * it must never be reachable from an unauthenticated request.
     *
     * @return array{employee_id: int, qr_id: int, employee: array<string, mixed>}
     */
    public function resolveByEmployee(int $employeeId): array
    {
        $employee = Database::selectOne(
            'SELECT id, employee_number, first_name, middle_name, last_name, suffix,
                    status, department_id, position_id, work_schedule_id,
                    basic_salary, salary_type, employment_type, archived_at
               FROM employees
              WHERE id = :id AND deleted_at IS NULL',
            ['id' => $employeeId]
        );

        if ($employee === null) {
            throw new RuntimeException('Employee not found.');
        }

        if ($employee['status'] !== 'ACTIVE' || $employee['archived_at'] !== null) {
            throw new RuntimeException(sprintf(
                'Cannot record attendance for an employee whose record is %s.',
                strtolower((string) $employee['status'])
            ));
        }

        $code = Database::selectOne(
            'SELECT id FROM employee_qr_codes
              WHERE employee_id = :emp AND status = :active
              ORDER BY serial_no DESC LIMIT 1',
            ['emp' => $employeeId, 'active' => 'ACTIVE']
        );

        if ($code === null) {
            throw new RuntimeException('This employee has no active QR code to record against.');
        }

        return [
            'employee_id' => (int) $employee['id'],
            'qr_id'       => (int) $code['id'],
            'employee'    => $employee,
        ];
    }
/** Invalidate the active code for an employee. */
    public function disable(int $employeeId, string $reason = 'Revoked by administrator'): bool
    {
        $affected = Database::execute(
            'UPDATE employee_qr_codes
                SET status = :status, disabled_at = NOW(), disabled_reason = :reason
              WHERE employee_id = :emp AND status = :active',
            ['status' => 'DISABLED', 'reason' => $reason, 'emp' => $employeeId, 'active' => 'ACTIVE']
        );

        return $affected > 0;
    }

    /** @return array<string, mixed>|null */
    public function activeCode(int $employeeId): ?array
    {
        return Database::selectOne(
            'SELECT qr.id, qr.serial_no, qr.status, qr.issued_at, qr.expires_at, qr.scan_count,
                    qr.last_scanned_at, qr.token_hint, qr.qr_image_path,
                    u.username AS issued_by_username
               FROM employee_qr_codes qr
               LEFT JOIN users u ON u.id = qr.issued_by
              WHERE qr.employee_id = :emp AND qr.status = :status
              ORDER BY qr.serial_no DESC LIMIT 1',
            ['emp' => $employeeId, 'status' => 'ACTIVE']
        );
    }

    /** @return list<array<string, mixed>> */
    public function history(int $employeeId): array
    {
        return Database::select(
            'SELECT qr.id, qr.serial_no, qr.status, qr.issued_at, qr.expires_at,
                    qr.disabled_at, qr.disabled_reason, qr.token_hint, qr.scan_count,
                    u.username AS issued_by_username
               FROM employee_qr_codes qr
               LEFT JOIN users u ON u.id = qr.issued_by
              WHERE qr.employee_id = :emp
              ORDER BY qr.serial_no DESC',
            ['emp' => $employeeId]
        );
    }

    /** Render a QR as SVG without touching the filesystem (e.g. for printing). */
    public function renderSvg(string $payload, int $scale = 8): string
    {
        try {
            $result = $this->generator->encode($payload, 'M');
            return $this->generator->toSvg($result['matrix'], $scale);
        } catch (\Throwable $e) {
            Logger::error('Failed to render QR SVG', ['error' => $e->getMessage()]);
            throw new RuntimeException('Unable to generate the QR image for this token.', 0, $e);
        }
    }

    /**
     * Return the SVG stored for the employee's active code.
     *
     * The token itself is only held as a hash, so the file written at issue
     * time is the canonical QR image.
     */
    public function svgContents(int $employeeId): ?string
    {
        $code = $this->activeCode($employeeId);

        if ($code === null || $code['qr_image_path'] === null) {
            return null;
        }

        $directory = Database::config()['paths']['storage'];
        $path      = $directory . DIRECTORY_SEPARATOR . str_replace('/', DIRECTORY_SEPARATOR, (string) $code['qr_image_path']);

        if (!is_file($path) || !is_readable($path)) {
            return null;
        }

        $contents = @file_get_contents($path);

        return $contents === false ? null : $contents;
    }

    public function markScanned(int $qrId): void
    {
        Database::execute(
            'UPDATE employee_qr_codes SET scan_count = scan_count + 1, last_scanned_at = NOW()
              WHERE id = :id',
            ['id' => $qrId]
        );
    }

    // -----------------------------------------------------------------------

    /** Cryptographically strong, printable, grouped token. */
    private function generateToken(): string
    {
        $prefix   = preg_replace('/[^A-Z0-9]/i', '', Settings::string('qr.token_prefix', 'ATT')) ?: 'ATT';
        $length   = max(8, Settings::int('qr.token_length', 24));
        $maxIndex = strlen(self::ALPHABET) - 1;

        $body = '';
        for ($i = 0; $i < $length; $i++) {
            $body .= self::ALPHABET[random_int(0, $maxIndex)];
        }

        // Grouped for readability when printed: ATT-XXXX-XXXX-XXXX-XXXX
        return $prefix . '-' . implode('-', str_split($body, 4));
    }

    private function hashToken(string $token): string
    {
        $pepper = Database::config()['security']['qr_pepper'];
        return hash('sha256', $token . '|' . $pepper);
    }

    private function expiryDate(): ?string
    {
        $days = Settings::int('qr.token_expiry_days', 0);
        return $days > 0 ? date('Y-m-d H:i:s', strtotime("+{$days} days")) : null;
    }

    /** Persist the SVG next to the other QR assets. */
    private function writeSvg(int $employeeId, int $serialNo, string $payload): string
    {
        $directory = Database::config()['paths']['qrcodes'];
        if (!is_dir($directory) && !@mkdir($directory, 0775, true) && !is_dir($directory)) {
            throw new RuntimeException('QR storage directory is not writable.');
        }

        $fileName = sprintf('emp-%d-qr%d.svg', $employeeId, $serialNo);
        $fullPath = $directory . DIRECTORY_SEPARATOR . $fileName;

        // Contains the token only, so no employee information reaches disk here.
        if (@file_put_contents($fullPath, $this->renderSvg($payload, 10)) === false) {
            throw new RuntimeException('Unable to write the QR image to storage.');
        }

        @chmod($fullPath, 0644);

        return 'qrcodes/' . $fileName;
    }
}