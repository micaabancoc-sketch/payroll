<?php
/**
 * Rest day swap / exchange workflow.
 *
 * Flow:
 *   1. Employee A (requester) submits a swap request -> PENDING
 *   2. Employee B (other) ACCEPTs or DECLINEs
 *   3. Manager/admin APPROVEs or REJECTs after both employees consent
 *   4. On approval, each employee's work_schedule_id is updated via
 *      ScheduleService::assignToEmployee() so attendance and payroll use
 *      the correct effective schedule for the exchanged dates.
 *
 * No schedule is touched before final manager approval.
 */

declare(strict_types=1);

namespace App\Services;

use App\Core\AuditLogger;
use App\Core\Auth;
use App\Core\Database;
use App\Core\ValidationException;
use App\Core\Validator;
use RuntimeException;

final class RestDaySwapService
{
    public const STATUS_PENDING   = 'PENDING';
    public const STATUS_APPROVED  = 'APPROVED';
    public const STATUS_REJECTED  = 'REJECTED';
    public const STATUS_CANCELLED = 'CANCELLED';
    public const STATUS_COMPLETED = 'COMPLETED';

    public const CONSENT_PENDING  = 'PENDING';
    public const CONSENT_ACCEPTED = 'ACCEPTED';
    public const CONSENT_DECLINED = 'DECLINED';

    public const DECISION_PENDING  = 'PENDING';
    public const DECISION_APPROVED = 'APPROVED';
    public const DECISION_REJECTED = 'REJECTED';

    /** @return array<string, string> */
    public static function rules(): array
    {
        return [
            'requester_id'           => 'required|integer',
            'other_employee_id'      => 'required|integer',
            'requester_original_dow' => 'required|integer',
            'other_original_dow'     => 'required|integer',
            'effective_date'         => 'required|date',
            'reason'                 => 'required|string|min:3|max:500',
        ];
    }

    /** @return array<string, string> */
    public static function respondRules(): array
    {
        return [
            'action'  => 'required|in:ACCEPT,DECLINE',
            'reason'  => 'nullable|string|max:500',
        ];
    }

    /** Create a new rest day swap request (PENDING). */
    public function create(array $data): array
    {
        $validator = Validator::make($data, self::rules());
        if ($validator->fails()) {
            throw new ValidationException($validator->errors());
        }

        $v = $validator->validated();

        $requesterId      = (int) $v['requester_id'];
        $otherId          = (int) $v['other_employee_id'];
        $requesterDow     = (int) $v['requester_original_dow'];
        $otherDow         = (int) $v['other_original_dow'];
        $effectiveDate    = (string) $v['effective_date'];
        $reason           = trim((string) $v['reason']);

        if ($requesterId === $otherId) {
            throw new ValidationException([
                'other_employee_id' => 'You cannot request a swap with yourself.',
            ]);
        }

        // Both employees must exist and be active.
        $requester = $this->activeEmployee($requesterId, 'requester_id');
        $other     = $this->activeEmployee($otherId, 'other_employee_id');

        // Each employee's original rest day must match their assigned schedule.
        $this->assertRestDayMatches($requesterId, $requesterDow, 'requester');
        $this->assertRestDayMatches($otherId, $otherDow, 'other employee');

        // No pending/approved swap already exists for either employee on the same effective date.
        $conflict = Database::selectOne(
            'SELECT id FROM rest_day_swaps
               WHERE deleted_at IS NULL
                 AND status IN (:pending, :approved)
                 AND effective_date = :date
                 AND (requester_id = :me_requester OR other_employee_id = :me_other)',
            [
                'pending'      => self::STATUS_PENDING,
                'approved'     => self::STATUS_APPROVED,
                'date'         => $effectiveDate,
                'me_requester' => $requesterId,
                'me_other'     => $otherId,
            ]
        );
        if ($conflict !== null) {
            throw new ValidationException([
                'effective_date' => 'A rest day swap already exists for one of the employees on this date.',
            ]);
        }

        // Both target schedules (where the *other* original dow is a rest day) must exist.
        $requesterTarget = $this->findScheduleWithRestDay($otherDow);
        $otherTarget     = $this->findScheduleWithRestDay($requesterDow);
        if ($requesterTarget === null || $otherTarget === null) {
            throw new ValidationException([
                'effective_date' => 'No suitable schedule exists for one of the employees\' swapped rest day.',
            ]);
        }

        $now = date('Y-m-d H:i:s');

        $id = Database::insert('rest_day_swaps', [
            'requester_id'           => $requesterId,
            'other_employee_id'      => $otherId,
            'requester_original_dow' => $requesterDow,
            'other_original_dow'     => $otherDow,
            'effective_date'         => $effectiveDate,
            'reason'                 => $reason,
            'other_consent'          => self::CONSENT_PENDING,
            'manager_decision'       => self::DECISION_PENDING,
            'status'                 => self::STATUS_PENDING,
            'created_at'             => $now,
            'updated_at'             => $now,
        ]);

        AuditLogger::record(
            AuditLogger::REST_DAY_SWAP_CREATED,
            'rest_day_swap',
            (int) $id,
            sprintf('Rest day swap requested for %s: emp #%d <-> emp #%d', $effectiveDate, $requesterId, $otherId),
            [],
            ['requester_id' => $requesterId, 'other_employee_id' => $otherId, 'effective_date' => $effectiveDate]
        );

        return $this->find((int) $id);
    }
    /** Validate that an employee exists and is active. */
    private function activeEmployee(int $id, string $field): array
    {
        $row = Database::selectOne(
            'SELECT id, status, archived_at, work_schedule_id FROM employees
               WHERE id = :id AND deleted_at IS NULL LIMIT 1',
            ['id' => $id]
        );

        if ($row === null) {
            throw new ValidationException([$field => 'This employee does not exist.']);
        }

        if ($row['status'] !== 'ACTIVE' || $row['archived_at'] !== null) {
            throw new ValidationException([$field => 'This employee must be active.']);
        }

        return $row;
    }

    /** The other employee accepts or declines a swap request. */
    public function respond(int $swapId, array $data, ?int $userId = null): array
    {
        $validator = Validator::make($data, self::respondRules());
        if ($validator->fails()) {
            throw new ValidationException($validator->errors());
        }

        $v = $validator->validated();
        $action = strtoupper((string) $v['action']);
        $reason = trim((string) ($v['reason'] ?? ''));

        $existing = $this->find($swapId);
        if ($existing === null) {
            throw new RuntimeException('Rest day swap request not found.');
        }

        if ($existing['status'] !== self::STATUS_PENDING) {
            throw new RuntimeException(
                sprintf('Only pending swap requests can be responded to (current: %s).', $existing['status'])
            );
        }

        $this->requireOtherOrAdmin($existing);

        if ($action === 'DECLINE') {
            if ($reason === '') {
                throw new ValidationException([
                    'reason' => 'A reason is required when declining a rest day swap.',
                ]);
            }
            if (mb_strlen($reason) > 500) {
                throw new ValidationException([
                    'reason' => 'The decline reason must not exceed 500 characters.',
                ]);
            }
        }

        $now = date('Y-m-d H:i:s');
        $respondingUserId = $userId ?? Auth::id();
        $newConsent = match ($action) {
            'ACCEPT'  => self::CONSENT_ACCEPTED,
            'DECLINE' => self::CONSENT_DECLINED,
            default   => self::CONSENT_DECLINED,
        };

        Database::update('rest_day_swaps', [
            'other_consent' => $newConsent,
        ], ['id' => (int) $existing['id']]);

        AuditLogger::record(
            AuditLogger::REST_DAY_SWAP_RESPONDED,
            'rest_day_swap',
            (int) $existing['id'],
            sprintf('Rest day swap %s for %s', strtolower($action), (string) $existing['effective_date']),
            ['other_consent' => $existing['other_consent'], 'status' => $existing['status']],
            ['other_consent' => $newConsent, 'responded_at' => $now, 'responded_by' => $respondingUserId]
        );

        if ($action === 'DECLINE') {
            Database::update('rest_day_swaps', [
                'status'        => self::STATUS_REJECTED,
                'manager_remarks' => 'Declined by other employee: ' . $reason,
                'decided_at'    => $now,
            ], ['id' => (int) $existing['id']]);

            AuditLogger::record(
                AuditLogger::REST_DAY_SWAP_REJECTED,
                'rest_day_swap',
                (int) $existing['id'],
                sprintf('Rest day swap declined for %s: %s', (string) $existing['effective_date'], $reason),
                ['status' => self::STATUS_PENDING],
                ['status' => self::STATUS_REJECTED, 'decided_at' => $now]
            );
        }

        return $this->find((int) $existing['id']);
    }
    /** Manager/admin approves a rest day swap after both employees consent. */
    public function approve(int $swapId, array $data, ?int $approverId = null): array
    {
        $this->requireManagerOrAdmin();

        $existing = $this->find($swapId);
        if ($existing === null) {
            throw new RuntimeException('Rest day swap request not found.');
        }

        if ($existing['status'] !== self::STATUS_PENDING) {
            throw new RuntimeException(
                sprintf('Only pending swap requests can be approved (current: %s).', $existing['status'])
            );
        }

        if ($existing['other_consent'] !== self::CONSENT_ACCEPTED) {
            throw new RuntimeException('The other employee has not accepted this swap request.');
        }

        $remarks = trim((string) ($data['remarks'] ?? ''));
        $approverUserId = $approverId ?? Auth::id();
        $now = date('Y-m-d H:i:s');

        return Database::transaction(function () use ($existing, $remarks, $approverUserId, $now): array {
            $requesterId = (int) $existing['requester_id'];
            $otherId     = (int) $existing['other_employee_id'];

            // New rest days after the swap: each takes the other's original rest day.
            $requesterNewDow = (int) $existing['other_original_dow'];
            $otherNewDow     = (int) $existing['requester_original_dow'];

            $requesterTarget = $this->findScheduleWithRestDay($requesterNewDow);
            $otherTarget     = $this->findScheduleWithRestDay($otherNewDow);

            if ($requesterTarget === null || $otherTarget === null) {
                throw new RuntimeException(
                    'No suitable schedule exists for one of the employees\' new rest day. Cannot approve.'
                );
            }

            // Update official schedules via the existing scheduling architecture.
            $scheduleService = new ScheduleService();
            $scheduleService->assignToEmployee($requesterId, (int) $requesterTarget['id']);
            $scheduleService->assignToEmployee($otherId, (int) $otherTarget['id']);

            Database::update('rest_day_swaps', [
                'manager_id'        => $approverUserId,
                'manager_remarks'   => $remarks !== '' ? $remarks : null,
                'decided_at'        => $now,
                'manager_decision'  => self::DECISION_APPROVED,
                'status'            => self::STATUS_APPROVED,
            ], ['id' => (int) $existing['id']]);

            AuditLogger::record(
                AuditLogger::REST_DAY_SWAP_APPROVED,
                'rest_day_swap',
                (int) $existing['id'],
                sprintf(
                    'Rest day swap approved: emp #%d rests %s, emp #%d rests %s, eff %s',
                    $requesterId,
                    $this->dayName($requesterNewDow),
                    $otherId,
                    $this->dayName($otherNewDow),
                    (string) $existing['effective_date']
                ),
                ['manager_decision' => $existing['manager_decision'], 'status' => $existing['status']],
                [
                    'manager_decision' => self::DECISION_APPROVED,
                    'status'           => self::STATUS_APPROVED,
                    'manager_id'       => $approverUserId,
                    'decided_at'       => $now,
                ]
            );

            return $this->find((int) $existing['id']);
        });
    }
    /** Manager/admin rejects a rest day swap request. */
    public function reject(int $swapId, array $data, ?int $approverId = null): array
    {
        $this->requireManagerOrAdmin();

        $existing = $this->find($swapId);
        if ($existing === null) {
            throw new RuntimeException('Rest day swap request not found.');
        }

        if ($existing['status'] !== self::STATUS_PENDING) {
            throw new RuntimeException(
                sprintf('Only pending swap requests can be rejected (current: %s).', $existing['status'])
            );
        }

        $remarks = trim((string) ($data['remarks'] ?? ''));
        $approverUserId = $approverId ?? Auth::id();
        $now = date('Y-m-d H:i:s');

        Database::update('rest_day_swaps', [
            'manager_id'       => $approverUserId,
            'manager_remarks'  => $remarks !== '' ? $remarks : null,
            'decided_at'       => $now,
            'manager_decision' => self::DECISION_REJECTED,
            'status'           => self::STATUS_REJECTED,
        ], ['id' => (int) $existing['id']]);

        AuditLogger::record(
            AuditLogger::REST_DAY_SWAP_REJECTED,
            'rest_day_swap',
            (int) $existing['id'],
            sprintf('Rest day swap rejected for %s', (string) $existing['effective_date']),
            ['manager_decision' => $existing['manager_decision'], 'status' => $existing['status']],
            [
                'manager_decision' => self::DECISION_REJECTED,
                'status'           => self::STATUS_REJECTED,
                'manager_id'       => $approverUserId,
                'decided_at'       => $now,
            ]
        );

        return $this->find((int) $existing['id']);
    }
    /** Cancel a pending swap (requester or admin only). */
    public function cancel(int $swapId, ?int $userId = null): array
    {
        $existing = $this->find($swapId);
        if ($existing === null) {
            throw new RuntimeException('Rest day swap request not found.');
        }

        if ($existing['status'] !== self::STATUS_PENDING) {
            throw new RuntimeException(
                sprintf('Only pending swap requests can be cancelled (current: %s).', $existing['status'])
            );
        }

        $user = Auth::user();
        if ($user === null) {
            throw new ValidationException(['permission' => 'Authentication is required.']);
        }

        $permissions = (array) ($user['permissions'] ?? []);
        $isAdmin = in_array('*', $permissions, true) || (($user['role_code'] ?? '') === 'ADMIN');

        if (!$isAdmin && Auth::employeeId() !== (int) $existing['requester_id']) {
            throw new ValidationException([
                'permission' => 'Only the requester or an administrator may cancel this swap.',
            ]);
        }

        $now = date('Y-m-d H:i:s');

        Database::update('rest_day_swaps', [
            'status'           => self::STATUS_CANCELLED,
            'manager_decision' => self::DECISION_REJECTED,
            'decided_at'       => $now,
        ], ['id' => (int) $existing['id']]);

        AuditLogger::record(
            AuditLogger::REST_DAY_SWAP_CANCELLED,
            'rest_day_swap',
            (int) $existing['id'],
            sprintf('Rest day swap cancelled for %s', (string) $existing['effective_date']),
            ['status' => $existing['status']],
            ['status' => self::STATUS_CANCELLED, 'decided_at' => $now]
        );

        return $this->find((int) $existing['id']);
    }
    /** @return array<string, mixed>|null */
    public function find(int $swapId): ?array
    {
        $record = Database::selectOne(
            'SELECT rds.*,
                    re.employee_number AS requester_employee_number,
                    re.first_name      AS requester_first_name,
                    re.last_name       AS requester_last_name,
                    oe.employee_number AS other_employee_number,
                    oe.first_name      AS other_first_name,
                    oe.last_name       AS other_last_name,
                    u.username         AS manager_username
               FROM rest_day_swaps rds
               JOIN employees re ON re.id = rds.requester_id
               JOIN employees oe ON oe.id = rds.other_employee_id
               LEFT JOIN users u ON u.id = rds.manager_id
              WHERE rds.id = :id AND rds.deleted_at IS NULL
              LIMIT 1',
            ['id' => $swapId]
        );

        return $record === null ? null : $record;
    }

    /**
     * @param array<string, mixed> $filters
     * @return array{items: list<array<string, mixed>>, total: int}
     */
    public function list(array $filters, int $page = 1, int $perPage = 25): array
    {
        $where  = ['rds.deleted_at IS NULL'];
        $params = [];

        if (!empty($filters['requester_id'])) {
            $where[] = 'rds.requester_id = :requester_id';
            $params['requester_id'] = (int) $filters['requester_id'];
        }

        if (!empty($filters['other_employee_id'])) {
            $where[] = 'rds.other_employee_id = :other_employee_id';
            $params['other_employee_id'] = (int) $filters['other_employee_id'];
        }

        if (!empty($filters['status'])) {
            $where[] = 'rds.status = :status';
            $params['status'] = (string) $filters['status'];
        }

        if (!empty($filters['other_consent'])) {
            $where[] = 'rds.other_consent = :other_consent';
            $params['other_consent'] = (string) $filters['other_consent'];
        }

        if (!empty($filters['manager_decision'])) {
            $where[] = 'rds.manager_decision = :manager_decision';
            $params['manager_decision'] = (string) $filters['manager_decision'];
        }

        foreach (['date_from' => 'rds.effective_date >= :date_from', 'date_to' => 'rds.effective_date <= :date_to'] as $key => $clause) {
            if (!empty($filters[$key])) {
                $where[] = $clause;
                $params[$key] = (string) $filters[$key];
            }
        }

        $user = Auth::user();
        if ($user !== null) {
            $permissions = (array) ($user['permissions'] ?? []);
            $canViewAll = in_array('*', $permissions, true)
                || in_array('rest_day_swap.view', $permissions, true);

            if (!$canViewAll) {
                $empId = Auth::employeeId();
                if ($empId !== null) {
                    $where[] = '(rds.requester_id = :me_requester OR rds.other_employee_id = :me_other)';
                    $params['me_requester'] = $empId;
                    $params['me_other'] = $empId;
                } else {
                    $where[] = '1 = 0';
                }
            }
        }

        $whereSql = implode(' AND ', $where);

        $total = (int) (Database::scalar(
            "SELECT COUNT(*) FROM rest_day_swaps rds WHERE {$whereSql}",
            $params
        ) ?? 0);

        $perPage = max(1, $perPage);
        $offset  = max(0, ($page - 1) * $perPage);

        $items = Database::select(
            'SELECT rds.*,
                    re.employee_number AS requester_employee_number,
                    re.first_name      AS requester_first_name,
                    re.last_name       AS requester_last_name,
                    oe.employee_number AS other_employee_number,
                    oe.first_name      AS other_first_name,
                    oe.last_name       AS other_last_name,
                    u.username         AS manager_username
               FROM rest_day_swaps rds
               JOIN employees re ON re.id = rds.requester_id
               JOIN employees oe ON oe.id = rds.other_employee_id
               LEFT JOIN users u ON u.id = rds.manager_id
              WHERE ' . $whereSql . '
              ORDER BY rds.created_at DESC
              LIMIT :limit OFFSET :offset',
            array_merge($params, ['limit' => $perPage, 'offset' => $offset])
        );

        return ['items' => $items, 'total' => $total];
    }
    // -----------------------------------------------------------------------
    // Private helpers
    // -----------------------------------------------------------------------

    /** Verify that the given day_of_week is currently a rest day for the employee's schedule. */
    private function assertRestDayMatches(int $employeeId, int $dow, string $label): void
    {
        $employee = Database::selectOne(
            'SELECT work_schedule_id FROM employees WHERE id = :id AND deleted_at IS NULL LIMIT 1',
            ['id' => $employeeId]
        );

        if ($employee === null) {
            return;
        }

        $scheduleId = $employee['work_schedule_id'] ?? null;
        if ($scheduleId === null) {
            throw new ValidationException([
                $label . '_id' => "The {$label} has no work schedule assigned.",
            ]);
        }

        $day = Database::selectOne(
            'SELECT is_rest_day FROM work_schedule_days
              WHERE work_schedule_id = :sid AND day_of_week = :dow
              LIMIT 1',
            ['sid' => (int) $scheduleId, 'dow' => $dow]
        );

        if ($day === null || (int) $day['is_rest_day'] !== 1) {
            throw new ValidationException([
                $label . '_original_dow' => sprintf(
                    '%s is not currently a rest day for the %s in their assigned schedule.',
                    $this->dayName($dow),
                    $label
                ),
            ]);
        }
    }

    /** Find an active schedule where the given day_of_week is a rest day. */
    private function findScheduleWithRestDay(int $dow): ?array
    {
        return Database::selectOne(
            'SELECT ws.id, ws.code, ws.name
               FROM work_schedules ws
               JOIN work_schedule_days wsd ON wsd.work_schedule_id = ws.id
              WHERE ws.deleted_at IS NULL
                AND ws.is_active = 1
                AND wsd.day_of_week = :dow
                AND wsd.is_rest_day = 1
              ORDER BY ws.is_default DESC, ws.name
              LIMIT 1',
            ['dow' => $dow]
        );
    }

    private function dayName(int $dow): string
    {
        $names = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
        return $names[$dow] ?? 'Unknown';
    }

    private function requireManagerOrAdmin(): void
    {
        $user = Auth::user();
        if ($user === null) {
            throw new ValidationException(['permission' => 'Authentication is required.']);
        }

        $permissions = (array) ($user['permissions'] ?? []);
        if (in_array('*', $permissions, true)) {
            return;
        }

        if (in_array('rest_day_swap.approve', $permissions, true)
            || (($user['role_code'] ?? '') === 'ADMIN' && Auth::hasPermission('rest_day_swap.approve'))
        ) {
            return;
        }

        throw new ValidationException([
            'permission' => 'Only a manager or administrator may approve or reject rest day swaps.',
        ]);
    }

    private function requireOtherOrAdmin(array $record): void
    {
        $user = Auth::user();
        if ($user === null) {
            throw new ValidationException(['permission' => 'Authentication is required.']);
        }

        $permissions = (array) ($user['permissions'] ?? []);
        if (in_array('*', $permissions, true) || (($user['role_code'] ?? '') === 'ADMIN')) {
            return;
        }

        $employeeId = Auth::employeeId();
        if ($employeeId !== null && $employeeId === (int) $record['other_employee_id']) {
            return;
        }

        throw new ValidationException([
            'permission' => 'Only the other employee may respond to this swap request.',
        ]);
    }
}