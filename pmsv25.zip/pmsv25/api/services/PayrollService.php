<?php
/**
 * Payroll periods and processing (Phase 14).
 *
 * Workflow from the brief:
 *   Draft -> Calculate -> Review -> Approve -> Finalize -> Paid
 *
 * Once finalized, records are locked to prevent accidental changes (rule 10).
 */

declare(strict_types=1);

namespace App\Services;

use App\Core\AuditLogger;
use App\Core\Auth;
use App\Core\Database;
use App\Core\DemoStaffScope;
use App\Core\Settings;
use RuntimeException;

final class PayrollService
{
    /** Allowed status transitions (Phase 14). */
    private const TRANSITIONS = [
        'DRAFT'       => ['CALCULATING'],
        'CALCULATING' => ['FOR_REVIEW', 'DRAFT'],
        'FOR_REVIEW'  => ['APPROVED', 'CALCULATING'],
        'APPROVED'    => ['FINALIZED', 'CALCULATING'],
        'FINALIZED'   => ['PAID'],
        'PAID'        => [],
    ];

    public const STATUSES = ['DRAFT', 'CALCULATING', 'FOR_REVIEW', 'APPROVED', 'FINALIZED', 'PAID'];

    public function __construct(
        private PayrollEngine $engine = new PayrollEngine(),
        private LoanService $loans = new LoanService()
    ) {
    }

    /**
     * Create a payroll period (Phase 14).
     *
     * @param array<string, mixed> $data
     * @return array<string, mixed>
     */
    public function createPeriod(array $data, ?int $userId = null): array
    {
        $validator = \App\Core\Validator::make(
            $data,
            [
                'start_date' => 'required|date',
                'end_date'   => 'required|date|after_or_equal:start_date',
                'pay_date'   => 'required|date',
                'name'       => 'nullable|string|max:150',
            ],
            ['start_date' => 'Start date', 'end_date' => 'End date', 'pay_date' => 'Pay date']
        );

        if ($validator->fails()) {
            throw new \App\Core\ValidationException($validator->errors());
        }

        $validated = $validator->validated();
        $startDate = (string) $validated['start_date'];
        $endDate   = (string) $validated['end_date'];
        $validated['pay_date'] = $this->officialPayday($startDate, $endDate);

        // Reject retroactive periods even when a non-overlapping gap exists.
        // This check is enforced on the API, not only in the Add Period modal.
        $latestEnd = Database::scalar(
            'SELECT MAX(end_date) FROM payroll_periods WHERE deleted_at IS NULL'
        );
        $dateErrors = PayrollPeriodPolicy::validateNewPeriod($startDate, $endDate,
            $latestEnd === null ? null : (string)$latestEnd);
        if ($dateErrors !== []) {
            throw new \App\Core\ValidationException($dateErrors);
        }

        // Overlapping periods are rejected so attendance is never paid twice.
        $overlap = Database::scalar(
            'SELECT id FROM payroll_periods
              WHERE deleted_at IS NULL
                AND NOT (end_date < :start OR start_date > :end)
              LIMIT 1',
            ['start' => $startDate, 'end' => $endDate]
        );

        if ($overlap !== null) {
            throw new \App\Core\ValidationException([
                'start_date' => 'A payroll period already exists that overlaps these dates.',
            ]);
        }

        $userId = $userId ?? Auth::id();

        return Database::transaction(function () use ($validated, $startDate, $endDate, $userId): array {
            $code = sprintf('PP-%s-%s', date('Ymd', strtotime($startDate)), date('Ymd', strtotime($endDate)));

            $periodId = Database::insert('payroll_periods', [
                'code'       => $code,
                'name'       => $validated['name'] ?? $this->periodName($startDate, $endDate),
                'start_date' => $startDate,
                'end_date'   => $endDate,
                'pay_date'   => (string) $validated['pay_date'],
                'status'     => 'DRAFT',
                'created_by' => $userId,
            ]);

            AuditLogger::record(
                AuditLogger::PAYROLL_CALCULATED,
                'payroll_period',
                $periodId,
                sprintf('Payroll period created: %s', $code),
                null,
                [
                    'start_date'     => $startDate,
                    'end_date'       => $endDate,
                    'pay_frequency'  => Settings::string('payroll.pay_frequency', 'SEMI_MONTHLY'),
                ]
            );

            return $this->findPeriod($periodId);
        });
    }
    /** Safe per-employee diagnostic preview; cannot create/approve a partial payroll run. */
    public function previewEmployee(int $periodId, int $employeeId): array
    {
        $period = $this->findPeriod($periodId);
        if (!$period || in_array($period['status'], ['FINALIZED','PAID'], true)) {
            throw new RuntimeException('Select an unlocked payroll period for the employee preview.');
        }
        if ((string)$period['end_date'] >= date('Y-m-d')) {
            return ['employee_id'=>$employeeId,'period_code'=>$period['code'],'ready'=>false,'exceptions'=>[],
                'message'=>'Payroll cutoff is not finished. Check attendance again after the period ends.'];
        }
        DemoStaffScope::assertIncluded($employeeId);
        $employee = Database::selectOne("SELECT * FROM employees WHERE id=:id AND status='ACTIVE' AND deleted_at IS NULL", ['id'=>$employeeId]);
        if (!$employee) { throw new RuntimeException('Active employee not found.'); }
        $issues = $this->engine->attendanceExceptions($employee, (string)$period['start_date'], (string)$period['end_date']);
        if ($issues !== []) {
            return ['employee_id'=>$employeeId,'period_code'=>$period['code'],'ready'=>false,'exceptions'=>$issues,
                'message'=>'Incomplete scans, unfinished cutoffs or rest-day QR evidence require review. No payroll data was changed.'];
        }
        $calculation = $this->engine->calculateEmployee($employee, (string)$period['start_date'], (string)$period['end_date']);
        return ['employee_id'=>$employeeId,'period_code'=>$period['code'],'ready'=>true,'exceptions'=>[],
            'basic_pay'=>$calculation['basic_pay'],'gross_pay'=>$calculation['gross_pay'],
            'total_deductions'=>$calculation['total_deductions'],'net_pay'=>$calculation['net_pay'],
            'earnings'=>$calculation['earnings'], 'deductions'=>$calculation['deductions'],
            'message'=>'Read-only diagnostic; not an approved or paid payroll item.'];
    }

    /** Read-only, complete attendance exception report for a cutoff. */
    public function periodAttendanceExceptions(int $periodId): array
    {
        $period = $this->findPeriod($periodId);
        if ($period === null || !empty($period['deleted_at'])) {
            throw new RuntimeException('Payroll period not found.');
        }
        $employees = Database::select(
            "SELECT * FROM employees WHERE status='ACTIVE' AND archived_at IS NULL AND deleted_at IS NULL"
             . DemoStaffScope::excludingRoles('employees.id') . DemoStaffScope::excludingDemoUsernames('employees.id') . " ORDER BY employee_number"
        );
        $groups = [];
        $total = 0;
        foreach ($employees as $employee) {
            $issues = $this->engine->attendanceExceptions($employee, (string)$period['start_date'], (string)$period['end_date']);
            if (!$issues) { continue; }
            $total += count($issues);
            $groups[] = [
                'employee_id'=>(int)$employee['id'],
                'employee_number'=>$employee['employee_number'],
                'employee_name'=>trim(implode(' ',array_filter([
                    $employee['first_name']??'', $employee['last_name']??''
                ]))),
                'exceptions'=>$issues,
            ];
        }
        return [
            'period_id'=>$periodId, 'period_code'=>$period['code'],
            'employee_count'=>count($employees), 'affected_count'=>count($groups),
            'unresolved_count'=>$total, 'employees'=>$groups,
            'message'=>'Missing scans in closed cutoffs are payroll-only presumed absences; incomplete scans and genuine conflicts still require review.'
        ];
    }

    /**
     * Save ONLY the selected employee's unlocked DRAFT payroll. This deliberately
     * leaves the period in DRAFT: a partial batch is never approvable, payable,
     * or finalized. All attendance exceptions must be resolved first.
     *
     * A repeat request atomically replaces ONLY this employee's unlocked row;
     * no other employees' snapshots, adjustments, or paid ledger entries move.
     */
    public function calculateSingleEmployee(int $periodId, int $employeeId, ?int $userId = null): array
    {
        $userId = $userId ?? Auth::id();
        if ($employeeId <= 0) {
            throw new RuntimeException('Choose an active employee.');
        }
        DemoStaffScope::assertIncluded($employeeId);
        return Database::transaction(function () use ($periodId, $employeeId, $userId): array {
            // Serialize requests for one cutoff, including full-batch recalculation.
            $period = Database::selectOne(
                'SELECT * FROM payroll_periods WHERE id = :id AND deleted_at IS NULL FOR UPDATE',
                ['id' => $periodId]
            );
            if ($period === null || (string)$period['status'] !== 'DRAFT' || $period['finalized_at'] !== null) {
                throw new RuntimeException('Employee-only calculation is allowed only for a DRAFT, unlocked payroll period.');
            }
            $start = (string)$period['start_date'];
            $end = (string)$period['end_date'];
            if ($end >= date('Y-m-d')) {
                throw new RuntimeException('This cutoff has not ended. Calculate after the end date.');
            }
            $employee = Database::selectOne(
                "SELECT * FROM employees WHERE id = :id AND status = 'ACTIVE' AND archived_at IS NULL AND deleted_at IS NULL",
                ['id' => $employeeId]
            );
            if (!$employee) {
                throw new RuntimeException('Active employee not found.');
            }
            // The engine presumes missing scheduled days ABSENT only after
            // cutoff close, without fabricating source attendance records.
            $calculation = $this->engine->calculateEmployee($employee, $start, $end);
            $existing = Database::selectOne(
                'SELECT id, is_locked, amount_paid, payment_status FROM payroll WHERE payroll_period_id=:pid AND employee_id=:eid FOR UPDATE',
                ['pid'=>$periodId, 'eid'=>$employeeId]
            );
            if ($existing !== null) {
                if ((int)$existing['is_locked'] !== 0 || (float)$existing['amount_paid'] > 0 ||
                    (string)$existing['payment_status'] === 'PARTIAL') {
                    throw new RuntimeException('This employee already has a locked or disbursed payroll record. It cannot be replaced.');
                }
                Database::execute('DELETE FROM payroll_items WHERE payroll_id=:id', ['id'=>(int)$existing['id']]);
                Database::execute('DELETE FROM payroll_statutory WHERE payroll_id=:id', ['id'=>(int)$existing['id']]);
                Database::execute('DELETE FROM payroll WHERE id=:id', ['id'=>(int)$existing['id']]);
            }
            $payrollId = $this->insertPayrollRow($periodId, $employee, $calculation);
            foreach ($calculation['earnings'] as $item) {
                Database::insert('payroll_items', [
                    'payroll_id'=>$payrollId, 'item_type'=>'EARNING', 'code'=>$item['code'],
                    'name'=>$item['name'], 'amount'=>$item['amount'], 'remarks'=>$item['remarks'] ?? null,
                ]);
            }
            foreach ($calculation['deductions'] as $item) {
                Database::insert('payroll_items', [
                    'payroll_id'=>$payrollId, 'item_type'=>'DEDUCTION', 'code'=>$item['code'],
                    'name'=>$item['name'], 'amount'=>$item['amount'], 'remarks'=>$item['remarks'] ?? null,
                ]);
            }
            foreach ((array)($calculation['statutory']['rows'] ?? []) as $row) {
                Database::insert('payroll_statutory', array_merge($row, ['payroll_id'=>$payrollId]));
            }
            $totals = Database::selectOne(
                'SELECT COUNT(*) AS employees, COALESCE(SUM(gross_pay),0) AS gross, '
                .'COALESCE(SUM(total_deductions),0) AS deductions, COALESCE(SUM(net_pay),0) AS net '
                .'FROM payroll WHERE payroll_period_id=:pid', ['pid'=>$periodId]
            );
            Database::execute(
                'UPDATE payroll_periods SET total_gross=:gross, total_deductions=:deductions, '
                .'total_net=:net, calculated_at=NOW() WHERE id=:id AND status=\'DRAFT\'',
                ['gross'=>$totals['gross'], 'deductions'=>$totals['deductions'],
                 'net'=>$totals['net'], 'id'=>$periodId]
            );
            AuditLogger::record(
                AuditLogger::PAYROLL_CALCULATED, 'payroll', $payrollId,
                sprintf('DRAFT payroll calculated for employee #%d, period %s (individual only)', $employeeId, $period['code']),
                null,
                ['employee_id'=>$employeeId, 'payroll_period_id'=>$periodId,
                 'gross_pay'=>$calculation['gross_pay'], 'net_pay'=>$calculation['net_pay'],
                 'partial_period'=>true, 'created_by'=>$userId]
            );
            return [
                'payroll_id'=>$payrollId, 'employee_id'=>$employeeId,
                'period_id'=>$periodId, 'period_status'=>'DRAFT',
                'employees_in_draft'=>(int)$totals['employees'],
                'basic_pay'=>$calculation['basic_pay'], 'gross_pay'=>$calculation['gross_pay'],
                'total_deductions'=>$calculation['total_deductions'], 'net_pay'=>$calculation['net_pay'],
                'earnings'=>$calculation['earnings'], 'deductions'=>$calculation['deductions'],
                'message'=>'Saved employee DRAFT only. Not approved, finalized, or paid. All employees must be reconciled before batch approval.'
            ];
        });
    }

/**
     * Calculate payroll for every active employee in a period (Phase 14).
     *
     * @return array<string, mixed>
     */
    public function calculate(int $periodId, ?int $userId = null): array
    {
        $period = $this->findPeriod($periodId);

        if ($period === null) {
            throw new RuntimeException('Payroll period not found.');
        }

        $this->assertTransition($period, 'CALCULATING');

        // Finalized periods are locked (rule 10).
        if ($period['finalized_at'] !== null) {
            throw new RuntimeException('This payroll period has been finalized and is locked.');
        }

        // Never silently replace already paid or locked employee payroll rows.
        $protected = (int)(Database::scalar(
            "SELECT COUNT(*) FROM payroll WHERE payroll_period_id=:pid AND "
            ."(is_locked<>0 OR amount_paid>0 OR payment_status='PARTIAL')",
            ['pid'=>$periodId]
        ) ?? 0);
        if ($protected > 0) {
            throw new RuntimeException('Cannot recalculate a period with locked or partly paid employee records.');
        }

        $userId    = $userId ?? Auth::id();
        $startDate = (string) $period['start_date'];
        $endDate   = (string) $period['end_date'];
        if ($endDate >= date('Y-m-d')) {
            throw new RuntimeException('Cannot calculate a current/future cutoff. Recalculate only on the day after the cutoff ends.');
        }
        // Legacy test data may contain arbitrary 5–20 cutoffs or a wrong payday.
        // Do not generate a legally relevant payslip from those dates.
        $correctPayday = $this->officialPayday($startDate, $endDate);
        if ((string) $period['pay_date'] !== $correctPayday) {
            if (($period['status'] ?? '') !== 'DRAFT') {
                throw new \App\Core\ValidationException(['pay_date' => 'This old payroll has an incorrect pay date. Do not recalculate or pay it until reviewed and safely corrected.']);
            }
            Database::execute('UPDATE payroll_periods SET pay_date=:pay WHERE id=:id AND status=\'DRAFT\'',
                ['pay'=>$correctPayday,'id'=>$periodId]);
        }

        $employees = Database::select(
            "SELECT * FROM employees
              WHERE status = 'ACTIVE' AND archived_at IS NULL AND deleted_at IS NULL"
            . DemoStaffScope::excludingRoles('employees.id') . DemoStaffScope::excludingDemoUsernames('employees.id') . " ORDER BY employee_number"
        );

        Database::execute(
            'UPDATE payroll_periods SET status = :status WHERE id = :id',
            ['status' => 'CALCULATING', 'id' => $periodId]
        );

        $processed       = 0;
        $totalGross      = 0.0;
        $totalDeductions = 0.0;
        $totalNet        = 0.0;
        $loanInstalments = 0;
        $loanTotal       = 0.0;
        $affectedEmployees = 0;
        $unresolvedDays = 0;
        $provisionalNames = [];

        try {
        Database::transaction(function () use ($periodId, $employees, $startDate, $endDate, $userId, &$processed, &$loanInstalments, &$loanTotal, &$totalGross, &$totalDeductions, &$totalNet, &$affectedEmployees, &$unresolvedDays, &$provisionalNames): void {
            // A recalculation replaces the previous unlocked figures.
            // Loan repayments are NOT written, moved or reversed here (Phase
            // 3A): a draft is purely presentational and the ledger only moves
            // once the period is marked PAID (see transition()).
            Database::execute(
                'DELETE pi FROM payroll_items pi
                   JOIN payroll p ON p.id = pi.payroll_id
                  WHERE p.payroll_period_id = :pid AND p.is_locked = 0',
                ['pid' => $periodId]
            );
            Database::execute(
                'DELETE FROM payroll WHERE payroll_period_id = :pid AND is_locked = 0',
                ['pid' => $periodId]
            );

            foreach ($employees as $employee) {
                // Saved DRAFTs: missing closed-cutoff days are presumed absent;
                // incomplete scans and unverified rest-day work remain blocked.
                try {
                    $calculation = $this->engine->calculateEmployee($employee, $startDate, $endDate, true);
                } catch (RuntimeException $payrollError) {
                    // Only the known insufficient gross/non-loan exception may
                    // become an explicit blocked DRAFT placeholder. Any DB,
                    // policy, or other unexpected failure rolls back the run.
                    if (!str_starts_with($payrollError->getMessage(), 'Non-loan deductions exceed gross pay')) {
                        throw $payrollError;
                    }
                    $calculation = $this->blockedFinancialDraft($employee, $startDate, $endDate, $payrollError->getMessage());
                }
                $issues = $calculation['attendance_exceptions'] ?? [];
                if (!empty($calculation['financial_exception']) && $issues === []) {
                    $issues = [['date'=>$endDate, 'reason'=>'FINANCIAL_CALCULATION_EXCEPTION']];
                }
                if ($issues !== [] || !empty($calculation['provisional'])) {
                    $affectedEmployees++;
                    $unresolvedDays += count($issues);
                    if ($issues === [] && !empty($calculation['financial_exception'])) {
                        $unresolvedDays++; // financial exception requires payroll review
                    }
                    $provisionalNames[] = (string)($employee['employee_number'] ?? $employee['id']);
                }

                $payrollId = $this->insertPayrollRow($periodId, $employee, $calculation);

                // Itemised breakdown for the payslip (Phase 15).
                foreach ($calculation['earnings'] as $earning) {
                    Database::insert('payroll_items', [
                        'payroll_id' => $payrollId,
                        'item_type'  => 'EARNING',
                        'code'       => $earning['code'],
                        'name'       => $earning['name'],
                        'amount'     => $earning['amount'],
                        'remarks'    => $earning['remarks'] ?? null,
                    ]);
                }

                foreach ($calculation['deductions'] as $deduction) {
                    Database::insert('payroll_items', [
                        'payroll_id' => $payrollId,
                        'item_type'  => 'DEDUCTION',
                        'code'       => $deduction['code'],
                        'name'       => $deduction['name'],
                        'amount'     => $deduction['amount'],
                        'remarks'    => $deduction['remarks'] ?? null,
                    ]);
                }

                // Audit trail for every statutory amount: the schedule version
                // that produced it, the base it was computed from and the
                // employer share that is never charged to the employee.
                foreach ((array) ($calculation['statutory']['rows'] ?? []) as $row) {
                    Database::insert('payroll_statutory', array_merge($row, ['payroll_id' => $payrollId]));
                }

                // The instalments above stay proposals until PAID: count them
                // so the run can report what the payslips will deduct. The
                // amounts themselves live in the calculation snapshot saved by
                // insertPayrollRow() and are committed to the repayment ledger
                // - atomically and idempotently - at the PAID transition.
                foreach ((array) ($calculation['loan_allocations'] ?? []) as $allocation) {
                    if ((float) ($allocation['amount'] ?? 0) <= 0) {
                        continue;
                    }

                    $loanInstalments++;
                    $loanTotal = round($loanTotal + (float) $allocation['amount'], 2);
                }

                $totalGross      += (float) $calculation['gross_pay'];
                $totalDeductions += (float) $calculation['total_deductions'];
                $totalNet        += (float) $calculation['net_pay'];
                $processed++;
            }
        });
        } catch (\Throwable $failure) {
            // A failed calculation must never leave an unapproved payroll
            // stranded as CALCULATING. Its detail writes were rolled back.
            Database::execute(
                'UPDATE payroll_periods SET status=:old_status WHERE id=:id AND status=:calculating',
                ['old_status'=>(string)$period['status'], 'id'=>$periodId, 'calculating'=>'CALCULATING']
            );
            throw $failure;
        }

        // Incomplete/problematic calculations remain DRAFT. A fully verified
        // batch may enter review, including in explicitly enabled local demo mode.
        $nextStatus = ($unresolvedDays > 0 || !DemoStaffScope::payrollWorkflowEnabled())
            ? 'DRAFT' : 'FOR_REVIEW';
        Database::execute(
            'UPDATE payroll_periods
                SET status = :status, total_gross = :gross, total_deductions = :deductions,
                    total_net = :net, calculated_at = NOW()
              WHERE id = :id',
            [
                'status'     => $nextStatus,
                'gross'      => $totalGross,
                'deductions' => $totalDeductions,
                'net'        => $totalNet,
                'id'         => $periodId,
            ]
        );

        AuditLogger::record(
            AuditLogger::PAYROLL_CALCULATED,
            'payroll_period',
            $periodId,
            sprintf('Payroll calculated for %d employee(s)', $processed),
            null,
            [
                'total_gross'      => round($totalGross, 2),
                'total_deductions' => round($totalDeductions, 2),
                'total_net'        => round($totalNet, 2),
                'loan_instalments' => $loanInstalments,
                'loan_repayment_total' => round($loanTotal, 2),
                'provisional_employees' => $affectedEmployees,
                'unresolved_attendance_dates' => $unresolvedDays,
            ]
        );

        return [
            'period'              => $this->findPeriod($periodId),
            'provisional'         => $unresolvedDays > 0,
            'provisional_employees' => $affectedEmployees,
            'unresolved_attendance_dates' => $unresolvedDays,
            'provisional_employee_numbers' => $provisionalNames,
            'message'             => $unresolvedDays > 0
                ? sprintf('%d DRAFT estimates created. %d employee(s) with %d unresolved attendance date(s); approval and payment blocked.', $processed, $affectedEmployees, $unresolvedDays)
                : sprintf('%d employees calculated and ready for payroll review.', $processed),
            'employees_processed' => $processed,
            'total_gross'         => round($totalGross, 2),
            'total_deductions'    => round($totalDeductions, 2),
            'total_net'           => round($totalNet, 2),
            // Phase 3A: a calculation only PROPOSES the loan instalments. The
            // ledger rows are written (and the balances reduced) atomically
            // when the period is marked PAID - see transition().
            'loan_instalments_proposed' => $loanInstalments,
            'loan_repayment_total'      => round($loanTotal, 2),
        ];
    }
    /** Unsafe pay math becomes an explicitly blocked zero DRAFT, not an invented payslip. */
    private function blockedFinancialDraft(array $employee, string $start, string $end, string $reason): array
    {
        $keys = [
            'basic_pay','working_days','present_days','absent_days','leave_days',
            'late_minutes','undertime_minutes','overtime_hours','overtime_pay',
            'allowances_total','bonus','gross_pay','late_deduction','undertime_deduction',
            'absence_deduction','leave_deduction','other_deductions', 'statutory_sss',
            'statutory_philhealth','statutory_pagibig','withholding_tax','statutory_total',
            'employer_contributions','total_deductions','net_pay'
        ];
        $calc = array_fill_keys($keys, 0);
        $exceptions = $this->engine->attendanceExceptions($employee, $start, $end);
        $calc['provisional'] = true;
        $calc['financial_exception'] = $reason;
        $calc['attendance_exceptions'] = $exceptions;
        $calc['earnings'] = [];
        $calc['deductions'] = [];
        $calc['loan_allocations'] = [];
        $calc['statutory'] = ['rows'=>[]];
        $calc['snapshot'] = [
            'provisional'=>true, 'financial_exception'=>$reason,
            'attendance_exceptions'=>$exceptions,
            'provisional_absent_days'=>count($exceptions),
            'period'=>['start'=>$start,'end'=>$end]
        ];
        return $calc;
    }

/** Insert one payroll row from an engine calculation. */
    private function insertPayrollRow(int $periodId, array $employee, array $calculation): int
    {
        return Database::insert('payroll', [
            'payroll_period_id'    => $periodId,
            'employee_id'          => (int) $employee['id'],
            'basic_pay'            => $calculation['basic_pay'],
            'working_days'         => $calculation['working_days'],
            'present_days'         => $calculation['present_days'],
            'absent_days'          => $calculation['absent_days'],
            'leave_days'           => $calculation['leave_days'],
            'late_minutes'         => $calculation['late_minutes'],
            'undertime_minutes'    => $calculation['undertime_minutes'],
            'overtime_hours'       => $calculation['overtime_hours'],
            'overtime_pay'         => $calculation['overtime_pay'],
            'allowances_total'     => $calculation['allowances_total'],
            'bonus'                => $calculation['bonus'],
            'gross_pay'            => $calculation['gross_pay'],
            'late_deduction'       => $calculation['late_deduction'],
            'undertime_deduction'  => $calculation['undertime_deduction'],
            'absence_deduction'    => $calculation['absence_deduction'],
            'leave_deduction'      => $calculation['leave_deduction'],
            'other_deductions'     => $calculation['other_deductions'],
            'statutory_sss'        => $calculation['statutory_sss'],
            'statutory_philhealth' => $calculation['statutory_philhealth'],
            'statutory_pagibig'    => $calculation['statutory_pagibig'],
            'withholding_tax'      => $calculation['withholding_tax'],
            'statutory_total'      => $calculation['statutory_total'],
            'employer_contributions' => $calculation['employer_contributions'],
            'total_deductions'     => $calculation['total_deductions'],
            'net_pay'              => $calculation['net_pay'],
            'amount_paid'          => 0.00,
            'payment_status'       => !empty($calculation['provisional']) ? 'UNPAID' : (round((float) $calculation['net_pay'], 2) <= 0 ? 'PAID' : 'UNPAID'),
            'is_locked'            => 0,
            'calculation_snapshot' => (string) json_encode(
                $calculation['snapshot'],
                JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES
            ),
            'calculated_at'        => date('Y-m-d H:i:s'),
        ]);
    }

    /**
     * Explicit evidence-backed resolution of a genuinely missing scheduled scan.
     * This is NEVER called by Calculate All and cannot approve HR's own absence.
     * Payroll must be recalculated afterwards; existing DRAFT rows stay provisional.
     */
    public function confirmMissingAbsence(int $periodId, int $employeeId, string $date, string $reason): array
    {
        $reason = trim($reason);
        if (mb_strlen($reason) < 15 || mb_strlen($reason) > 210) {
            throw new RuntimeException('Provide 15–210 characters of factual attendance verification evidence/reason.');
        }
        if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $date)) {
            throw new RuntimeException('Invalid attendance date.');
        }
        if (Auth::roleCode() !== 'HR_PAYROLL') {
            throw new RuntimeException('Only HR/Payroll may confirm team attendance exceptions.');
        }
        if (Auth::employeeId() === $employeeId) {
            throw new RuntimeException('HR cannot verify their own absence. Refer this date to the independent Manager Reviewer.');
        }
        DemoStaffScope::assertIncluded($employeeId);
        return Database::transaction(function () use ($periodId, $employeeId, $date, $reason): array {
            $period = Database::selectOne(
                'SELECT * FROM payroll_periods WHERE id=:id AND deleted_at IS NULL FOR UPDATE',
                ['id'=>$periodId]
            );
            if (!$period || $period['status'] !== 'DRAFT' || $period['finalized_at'] !== null) {
                throw new RuntimeException('Attendance verification from this queue requires an unlocked DRAFT period.');
            }
            if ($date < (string)$period['start_date'] || $date > (string)$period['end_date'] || $date > date('Y-m-d')) {
                throw new RuntimeException('Date is outside the elapsed payroll cutoff.');
            }
            $employee = Database::selectOne(
                "SELECT * FROM employees WHERE id=:eid AND status='ACTIVE' AND archived_at IS NULL AND deleted_at IS NULL",
                ['eid'=>$employeeId]
            );
            if (!$employee) { throw new RuntimeException('Active employee not found.'); }
            $issues = $this->engine->attendanceExceptions($employee, $date, $date);
            $reasonCode = $issues[0]['reason'] ?? '';
            if (!in_array($reasonCode, ['MISSING_SCAN_REQUIRES_HR_VERIFICATION', 'AUTO_ABSENCE_REQUIRES_HR_CONFIRMATION'], true)) {
                throw new RuntimeException('This day is not an unconfirmed missing/auto absence. Investigate its QR logs or approved leave instead.');
            }
            $annotation = 'HR-confirmed absence: '.$reason;
            $existing = Database::selectOne(
                'SELECT * FROM attendance WHERE employee_id=:eid AND attendance_date=:date AND deleted_at IS NULL FOR UPDATE',
                ['eid'=>$employeeId, 'date'=>$date]
            );
            if ($existing) {
                if ($existing['source'] !== 'AUTO' || $existing['status'] !== 'ABSENT') {
                    throw new RuntimeException('This attendance record is not an automatic absence and cannot be overridden here.');
                }
                Database::update('attendance', [
                    'source'=>'MANUAL', 'remarks'=>$annotation,
                    'adjusted_by'=>Auth::id()
                ], ['id'=>(int)$existing['id']]);
                $id=(int)$existing['id'];
            } else {
                $record=(new AttendanceService())->record($employeeId, [
                    'attendance_date'=>$date, 'status'=>'ABSENT', 'remarks'=>$annotation
                ]);
                $id=(int)$record['id'];
            }
            AuditLogger::record(
                AuditLogger::ATTENDANCE_ADJUST, 'attendance', $id,
                sprintf('Verified actual ABSENT for employee #%d on %s, separate from provisional payroll detection', $employeeId, $date),
                null, ['reason'=>$reason, 'period_id'=>$periodId, 'verified_by'=>Auth::id()]
            );
            return [
                'employee_id'=>$employeeId, 'date'=>$date, 'attendance_id'=>$id,
                'status'=>'ABSENT', 'source'=>'MANUAL',
                'message'=>'Absence verified and audited. Recalculate All to refresh estimated payroll figures.'
            ];
        });
    }

    /** A saved estimate must not become an approved/payable payroll. */
    private function assertBatchVerifiedForRelease(int $periodId, array $period): void
    {
        if ((string)$period['end_date'] >= date('Y-m-d')) {
            throw new RuntimeException('Cannot approve or finalize payroll before the entire cutoff has ended.');
        }
        // Only the explicitly configured DEVELOPMENT demo can release its
        // test payroll; production and unconfigured limited-scope demos fail closed.
        if (!DemoStaffScope::payrollWorkflowEnabled()) {
            throw new RuntimeException('Demo payroll release is disabled outside the configured local development test.');
        }
        $check = $this->periodAttendanceExceptions($periodId);
        if ((int)$check['unresolved_count'] > 0) {
            throw new RuntimeException(sprintf(
                'Cannot approve/finalize: %d scheduled attendance date(s) for %d employee(s) still require verification.',
                (int)$check['unresolved_count'], (int)$check['affected_count']
            ));
        }
        $activeEmployees = (int)$check['employee_count'];
        if ($activeEmployees === 0) {
            throw new RuntimeException('Cannot approve/finalize an empty payroll. Add an eligible active staff member and recalculate.');
        }
        $rows = Database::select(
            'SELECT p.employee_id, p.calculation_snapshot, p.is_locked, p.amount_paid '
            .'FROM payroll p WHERE p.payroll_period_id=:pid',
            ['pid'=>$periodId]
        );
        if (count($rows) !== $activeEmployees) {
            throw new RuntimeException(sprintf(
                'Cannot approve/finalize: %d employee payroll row(s) recorded, %d eligible employees expected. Recalculate All after verification.',
                count($rows), $activeEmployees
            ));
        }
        $ids = [];
        foreach ($rows as $row) {
            $id = (int)$row['employee_id'];
            if (isset($ids[$id])) {
                throw new RuntimeException('Duplicate employee payroll row detected. Cannot approve this period.');
            }
            $ids[$id] = true;
            $snapshot = json_decode((string)($row['calculation_snapshot'] ?? ''), true);
            if (!is_array($snapshot) || !empty($snapshot['provisional']) ||
                !empty($snapshot['attendance_exceptions']) || !empty($snapshot['financial_exception'])) {
                throw new RuntimeException('Provisional or invalid employee draft still exists. Recalculate All after attendance verification.');
            }
        }
        // Compare against precisely the SAME roster used by Calculate All.
        // Operators and other excluded demo employees must NOT reappear during
        // approval merely because a historic payroll_eligible flag is set.
        $activeIds = Database::select(
            "SELECT employees.id FROM employees WHERE status='ACTIVE' AND archived_at IS NULL AND deleted_at IS NULL"
            . DemoStaffScope::excludingRoles('employees.id')
            . DemoStaffScope::excludingDemoUsernames('employees.id')
        );
        if (count($activeIds) !== $activeEmployees || count($ids) !== count($activeIds)) {
            throw new RuntimeException('Payroll roster changed. Recalculate All before approval.');
        }
        $expected = [];
        foreach ($activeIds as $emp) { $expected[(int)$emp['id']] = true; }
        foreach ($expected as $id => $_) {
            if (!isset($ids[$id])) {
                throw new RuntimeException('One or more eligible employees are missing from this payroll. Recalculate All.');
            }
        }
        foreach ($ids as $id => $_) {
            if (!isset($expected[$id])) {
                throw new RuntimeException('Payroll includes an excluded or inactive employee. Recalculate All before approval.');
            }
        }
    }

    /** Write finite company deductions exactly once after all salaries are actually paid. */
    private function commitCompanyDeductions(int $periodId): void
    {
        $items = Database::select("SELECT ed.id AS assignment_id, ed.total_amount, ed.deducted_amount,
                p.employee_id, pi.amount FROM payroll_items pi
            JOIN payroll p ON p.id=pi.payroll_id
            JOIN deductions d ON d.code=pi.code
            JOIN employee_deductions ed ON ed.employee_id=p.employee_id AND ed.deduction_id=d.id
            WHERE p.payroll_period_id=:pid AND pi.item_type='DEDUCTION'
              AND ed.total_amount IS NOT NULL AND ed.authorization_reference IS NOT NULL",
            ['pid'=>$periodId]);
        foreach ($items as $item) {
            $id=(int)$item['assignment_id'];
            $locked=Database::selectOne('SELECT id,total_amount,deducted_amount,is_active FROM employee_deductions WHERE id=:id FOR UPDATE',['id'=>$id]);
            if (!$locked) { throw new RuntimeException('Company deduction assignment missing at payment.'); }
            $paidAlready=Database::scalar('SELECT id FROM employee_deduction_payments WHERE assignment_id=:aid AND payroll_period_id=:pid',
                ['aid'=>$id,'pid'=>$periodId]);
            if ($paidAlready !== null) { continue; }
            $amount=round((float)$item['amount'],2);
            $remaining=round((float)$locked['total_amount']-(float)$locked['deducted_amount'],2);
            if ($amount<=0 || $amount>$remaining+0.001) {
                throw new RuntimeException('Company deduction balance conflict. Do not pay twice; reconcile the employee installment schedule first.');
            }
            Database::insert('employee_deduction_payments',['assignment_id'=>$id,'payroll_period_id'=>$periodId,'amount'=>$amount]);
            $newPaid=round((float)$locked['deducted_amount']+$amount,2);
            Database::update('employee_deductions',[
                'deducted_amount'=>$newPaid,
                'is_active'=>$newPaid+0.001>=(float)$locked['total_amount']?0:(int)$locked['is_active'],
                'completed_at'=>$newPaid+0.001>=(float)$locked['total_amount']?date('Y-m-d H:i:s'):null,
            ],['id'=>$id]);
            AuditLogger::record(AuditLogger::PAYROLL_PAID,'employee_deduction',$id,
                sprintf('Confirmed installment %.2f at paid period #%d (cumulative %.2f)', $amount,$periodId,$newPaid));
        }
    }

    /**
     * Move a period to the next status in the workflow (Phase 14).
     *
     * The PAID step also commits the loan repayments the calculation
     * proposed: marking a period paid is the only payroll action that writes
     * to the repayment ledger (Phase 3A). The commit and the status change
     * share one transaction, and the commit itself is idempotent, so the same
     * instalment can never be charged twice.
     *
     * @return array<string, mixed>
     */
    public function transition(int $periodId, string $toStatus, ?int $userId = null): array
    {
        $period = $this->findPeriod($periodId);

        if ($period === null) {
            throw new RuntimeException('Payroll period not found.');
        }

        $this->assertTransition($period, $toStatus);

        // Server-enforced; bypassing/altering frontend buttons cannot release
        // a provisional batch, omit an eligible employee, or use stale snapshots.
        if (in_array($toStatus, ['FOR_REVIEW','APPROVED','FINALIZED','PAID'], true)) {
            $this->assertBatchVerifiedForRelease($periodId, $period);
        }

        if (in_array($toStatus, ['APPROVED','FINALIZED','PAID'], true)) {
            $payday = $this->officialPayday((string)$period['start_date'], (string)$period['end_date']);
            if ((string)$period['pay_date'] !== $payday) {
                throw new \App\Core\ValidationException(['pay_date' =>
                    'Invalid legacy payroll pay date. Rebuild the unapproved period with the official 1–15 / 16–month-end calendar before approval or release.']);
            }
        }

        $userId = $userId ?? Auth::id();

        $action = match ($toStatus) {
            'APPROVED'  => AuditLogger::PAYROLL_APPROVED,
            'FINALIZED' => AuditLogger::PAYROLL_FINALIZED,
            'PAID'      => AuditLogger::PAYROLL_PAID,
            default     => AuditLogger::PAYROLL_CALCULATED,
        };

        // Every status change is a transaction. Marking the period PAID
        // additionally commits the loan repayments, and both must succeed
        // together: a failure halfway would leave a paid period with unpaid
        // loans (or the reverse).
        $repayments = Database::transaction(function () use ($periodId, $toStatus, $userId, $period, $action): array {
            $payload    = ['status' => $toStatus];
            $repayments = ['recorded' => 0, 'skipped' => 0, 'total' => 0.0, 'payments' => []];

            if ($toStatus === 'APPROVED') {
                $payload['approved_by'] = $userId;
                $payload['approved_at'] = date('Y-m-d H:i:s');
            }

            if ($toStatus === 'FINALIZED') {
                $payload['finalized_at'] = date('Y-m-d H:i:s');

                // Finalized payroll is locked (rule 10).
                Database::execute(
                    'UPDATE payroll SET is_locked = 1 WHERE payroll_period_id = :pid',
                    ['pid' => $periodId]
                );
            }

            if ($toStatus === 'PAID') {
                // Two concurrent PAID calls serialise on the period row: the
                // second waits for the first to commit, then sees the ledger
                // already written and adds nothing (idempotent commit).
                Database::selectOne(
                    'SELECT id FROM payroll_periods WHERE id = :id FOR UPDATE',
                    ['id' => $periodId]
                );

                // Phase 5: the period must not read PAID while any required
                // salary disbursement is outstanding. This runs BEFORE the loan
                // commit so a blocked period writes nothing: no half-committed
                // loan ledger, no duplicate loan rows on a retried request.
                $readiness = (new PayrollPaymentService())->periodReadiness($periodId);
                if (!$readiness['ready']) {
                    throw new RuntimeException(sprintf(
                        'Cannot mark this period paid: %d of %d payroll record(s) still unpaid%s. Disburse every employee through Payments first.',
                        ((int) $readiness['unpaid']) + ((int) $readiness['partial']),
                        (int) $readiness['total'],
                        ((int) $readiness['partial']) > 0 ? sprintf(' (%d partially paid)', (int) $readiness['partial']) : ''
                    ));
                }

                $repayments = $this->commitLoanRepayments($periodId, $userId);
                $this->commitCompanyDeductions($periodId);

                $payload['paid_at'] = date('Y-m-d H:i:s');
            }

            Database::update('payroll_periods', $payload, ['id' => $periodId]);

            AuditLogger::record(
                $action,
                'payroll_period',
                $periodId,
                sprintf('Payroll period %s moved to %s', $period['code'], $toStatus),
                ['status' => $period['status']],
                $toStatus === 'PAID'
                    ? array_merge($payload, [
                        'loan_repayments_recorded' => $repayments['recorded'],
                        'loan_repayments_skipped'  => $repayments['skipped'],
                        'loan_repayment_total'     => round($repayments['total'], 2),
                    ])
                    : $payload
            );

            return $repayments;
        });

        $result = $this->findPeriod($periodId);

        // Report what the PAID step settled so the API caller can verify the
        // ledger without a second request.
        if ($toStatus === 'PAID' && is_array($result)) {
            $result['loan_repayments'] = $repayments;
        }

        return $result;
    }

    /**
     * Commit the loan repayments the payslips of one period proposed.
     *
     * Phase 3A: only a PAID transition calls this, inside its transaction.
     * The instalments are read back from each payroll row's stored
     * calculation snapshot, so the ledger can never disagree with what the
     * payslip showed. LoanService skips a (period, loan) pair that is already
     * in the ledger, which keeps the commit idempotent across retries.
     *
     * @return array{recorded: int, skipped: int, total: float, payments: list<array<string, mixed>>}
     */
    private function commitLoanRepayments(int $periodId, ?int $userId): array
    {
        $rows = Database::select(
            'SELECT id, calculation_snapshot FROM payroll WHERE payroll_period_id = :pid ORDER BY id',
            ['pid' => $periodId]
        );

        $allocations = [];

        foreach ($rows as $row) {
            $snapshot = json_decode((string) ($row['calculation_snapshot'] ?? ''), true);

            if (!is_array($snapshot)) {
                continue;
            }

            $payrollId = (int) $row['id'];

            foreach ((array) ($snapshot['loan_allocations'] ?? []) as $allocation) {
                if ((int) ($allocation['loan_id'] ?? 0) <= 0 || (float) ($allocation['amount'] ?? 0) <= 0) {
                    continue;
                }

                $allocations[] = [
                    'loan_id'    => (int) $allocation['loan_id'],
                    'amount'     => round((float) $allocation['amount'], 2),
                    'payroll_id' => $payrollId,
                ];
            }
        }

        return $this->loans->recordPayrollDeductions($periodId, $allocations, $userId);
    }
    /** Snapshot-only provisional indicators for the payroll-period summary. */
    private function provisionalPeriodSummary(int $periodId): array
    {
        $snapshots = Database::select(
            'SELECT calculation_snapshot FROM payroll WHERE payroll_period_id=:pid',
            ['pid'=>$periodId]
        );
        $count=0; $days=0; $financial=0;
        foreach ($snapshots as $row) {
            $snapshot=json_decode((string)($row['calculation_snapshot']??''), true);
            if (!is_array($snapshot)) {continue;}
            if (!empty($snapshot['provisional'])) {
                $count++;
                $days += (int)($snapshot['provisional_absent_days']??0);
            }
            if (!empty($snapshot['financial_exception'])) {$financial++;}
        }
        return [
            'provisional_employee_count'=>$count,
            'pending_verification_days'=>$days,
            'financial_exception_count'=>$financial
        ];
    }

/** @return array<string, mixed>|null */
    public function findPeriod(int $periodId): ?array
    {
        $period = Database::selectOne(
            'SELECT pp.*, u.username AS created_by_username,
                    a.username AS approved_by_username,
                    (SELECT COUNT(*) FROM payroll p WHERE p.payroll_period_id = pp.id) AS employee_count
               FROM payroll_periods pp
               LEFT JOIN users u ON u.id = pp.created_by
               LEFT JOIN users a ON a.id = pp.approved_by
              WHERE pp.id = :id
              LIMIT 1',
            ['id' => $periodId]
        );

        if ($period !== null) {
            $period['allowed_transitions'] = self::TRANSITIONS[$period['status']] ?? [];
            $period = array_merge($period, $this->provisionalPeriodSummary($periodId));
        }

        return $period;
    }

    /**
     * Payroll periods with filters (Phase 14).
     *
     * @param array<string, mixed> $filters
     * @return array{items: list<array<string, mixed>>, total: int}
     */
    public function listPeriods(array $filters, int $page = 1, int $perPage = 25): array
    {
        // V21: A read-only list must not silently backfill old payroll periods.
        // HR creates the next period explicitly; createPeriod enforces chronological order.
        $where  = ['1 = 1'];
        $params = [];

        $archiveMode = strtolower(trim((string) ($filters['archived'] ?? 'false')));
        if ($archiveMode === 'only') {
            $where[] = 'pp.deleted_at IS NOT NULL';
        } elseif (!filter_var($archiveMode, FILTER_VALIDATE_BOOLEAN)) {
            $where[] = 'pp.deleted_at IS NULL';
        }

        if (!empty($filters['status'])) {
            $where[] = 'pp.status = :status';
            $params['status'] = (string) $filters['status'];
        }

        foreach (['date_from' => 'pp.end_date >= :date_from', 'date_to' => 'pp.start_date <= :date_to'] as $key => $clause) {
            if (!empty($filters[$key])) {
                $where[] = $clause;
                $params[$key] = (string) $filters[$key];
            }
        }

        $whereSql = implode(' AND ', $where);

        $total = (int) (Database::scalar(
            "SELECT COUNT(*) FROM payroll_periods pp WHERE {$whereSql}",
            $params
        ) ?? 0);

        $perPage = max(1, $perPage);
        $offset  = max(0, ($page - 1) * $perPage);

        $items = Database::select(
            "SELECT pp.*, u.username AS created_by_username, a.username AS approved_by_username,
                    (SELECT COUNT(*) FROM payroll p WHERE p.payroll_period_id = pp.id) AS employee_count
               FROM payroll_periods pp
               LEFT JOIN users u ON u.id = pp.created_by
               LEFT JOIN users a ON a.id = pp.approved_by
              WHERE {$whereSql}
              ORDER BY pp.start_date DESC, pp.id DESC
              LIMIT {$perPage} OFFSET {$offset}",
            $params
        );

        foreach ($items as &$item) {
            $item['allowed_transitions'] = self::TRANSITIONS[$item['status']] ?? [];
            $item = array_merge($item, $this->provisionalPeriodSummary((int)$item['id']));
        }
        unset($item);

        return ['items' => $items, 'total' => $total];
    }

    /**
     * Payroll rows for a period (Phase 14).
     *
     * @return list<array<string, mixed>>
     */
    public function periodPayroll(int $periodId): array
    {
        return Database::select(
            'SELECT p.*, e.employee_number, e.first_name, e.middle_name, e.last_name, e.suffix,
                    d.name AS department_name, e.employment_type
               FROM payroll p
               JOIN employees e ON e.id = p.employee_id
               LEFT JOIN departments d ON d.id = e.department_id
              WHERE p.payroll_period_id = :pid
              ORDER BY e.employee_number',
            ['pid' => $periodId]
        );
    }

    /** Calendar-locked semi-monthly ranges, with previous available banking day. */
    public function officialPayday(string $startDate, string $endDate): string
    {
        $date = \DateTimeImmutable::createFromFormat('!Y-m-d', $startDate);
        if ($date === false || $date->format('Y-m-d') !== $startDate) {
            throw new \App\Core\ValidationException(['start_date' => 'Choose a valid calendar month.']);
        }
        $ranges = PayrollCalendarService::periodsForMonth((int) $date->format('Y'), (int) $date->format('m'));
        $scheduled = null;
        foreach ($ranges as [$start, $end, $pay]) {
            if ($start === $startDate && $end === $endDate) { $scheduled = $pay; break; }
        }
        if ($scheduled === null) {
            throw new \App\Core\ValidationException(['start_date' =>
                'Payroll dates are fixed: day 1-15 or day 16-last day of the same month. Custom periods are not allowed.']);
        }
        $holidays = Database::select(
            "SELECT holiday_date FROM holidays WHERE status = 'ACTIVE' AND deleted_at IS NULL
                 AND holiday_date BETWEEN :since AND :until",
            ['since' => date('Y-m-d', strtotime($scheduled . ' -30 days')), 'until' => $scheduled]
        );
        return PayrollCalendarService::adjustedPayday($scheduled, array_column($holidays, 'holiday_date'));
    }

    /** Edit a DRAFT payroll period (dates / pay date / name). */
    public function updatePeriod(int $periodId, array $data): array
    {
        $period = $this->findPeriod($periodId);
        if ($period === null || !empty($period['deleted_at'])) {
            throw new RuntimeException('Payroll period not found.');
        }
        if (($period['status'] ?? '') !== 'DRAFT') {
            throw new RuntimeException('Only DRAFT periods can be edited. Calculated periods are locked.');
        }
        $validator = \App\Core\Validator::make($data, [
            'start_date' => 'nullable|date',
            'end_date' => 'nullable|date',
            'pay_date' => 'nullable|date',
            'name' => 'nullable|string|max:150',
        ]);
        if ($validator->fails()) {
            throw new \App\Core\ValidationException($validator->errors());
        }
        $fields = $validator->validated();
        $payload = [];
        foreach (['start_date', 'end_date', 'pay_date', 'name'] as $f) {
            if (array_key_exists($f, $fields) && $fields[$f] !== null && $fields[$f] !== '') {
                $payload[$f] = $fields[$f];
            }
        }
        if (isset($payload['start_date']) || isset($payload['end_date'])) {
            $s = $payload['start_date'] ?? $period['start_date'];
            $e = $payload['end_date'] ?? $period['end_date'];
            if ($e < $s) {
                throw new \App\Core\ValidationException(['end_date' => 'End date must be on or after start date.']);
            }
            // Changing period dates via a direct API request must not bypass the
            // same no-retroactive rule enforced for new periods.
            if ($s !== $period['start_date'] || $e !== $period['end_date']) {
                $latestOther = Database::scalar(
                    'SELECT MAX(end_date) FROM payroll_periods WHERE deleted_at IS NULL AND id != :id',
                    ['id' => $periodId]
                );
                $policyErrors = PayrollPeriodPolicy::validateNewPeriod((string)$s, (string)$e,
                    $latestOther === null ? null : (string)$latestOther);
                if ($policyErrors !== []) {
                    throw new \App\Core\ValidationException($policyErrors);
                }
            }
            $overlap = Database::scalar(
                'SELECT id FROM payroll_periods WHERE deleted_at IS NULL AND id != :id AND NOT (end_date < :start OR start_date > :end) LIMIT 1',
                ['id' => $periodId, 'start' => $s, 'end' => $e]
            );
            if ($overlap !== null) {
                throw new \App\Core\ValidationException(['start_date' => 'Another payroll period overlaps these dates.']);
            }
        }
        // Pay date is never user-editable; calculate and validate on the server.
        $payload['pay_date'] = $this->officialPayday(
            (string) ($payload['start_date'] ?? $period['start_date']),
            (string) ($payload['end_date'] ?? $period['end_date'])
        );
        if ($payload !== []) {
            Database::update('payroll_periods', $payload, ['id' => $periodId]);
            AuditLogger::recordChanges(AuditLogger::PAYROLL_CALCULATED, 'payroll_period', $periodId, $period, array_merge($period, $payload));
        }
        return $this->findPeriod($periodId);
    }

    /** Archive a DRAFT period (purge via Data deletion). */
    public function deletePeriod(int $periodId): array
    {
        $period = $this->findPeriod($periodId);
        if ($period === null || !empty($period['deleted_at'])) {
            throw new RuntimeException('Payroll period not found.');
        }
        if (($period['status'] ?? '') !== 'DRAFT') {
            throw new RuntimeException('Only DRAFT periods can be deleted. Finalized payroll is locked for audit.');
        }
        Database::update('payroll_periods', ['deleted_at' => date('Y-m-d H:i:s')], ['id' => $periodId]);
        AuditLogger::record(AuditLogger::PAYROLL_CALCULATED, 'payroll_period', $periodId, sprintf('Deleted payroll period %s', $period['code'] ?? $periodId), $period, null);
        return ['id' => $periodId];
    }

    /** Restore an archived DRAFT period to its list. */
    public function restorePeriod(int $periodId): array
    {
        $period = Database::selectOne(
            'SELECT * FROM payroll_periods WHERE id = :id AND deleted_at IS NOT NULL',
            ['id' => $periodId]
        );

        if ($period === null) {
            throw new RuntimeException('Payroll period not found or is not archived.');
        }

        Database::update('payroll_periods', ['deleted_at' => null], ['id' => $periodId]);

        AuditLogger::record(
            AuditLogger::PAYROLL_CALCULATED,
            'payroll_period',
            $periodId,
            sprintf('Restored payroll period %s', $period['code'] ?? $periodId),
            ['deleted_at' => $period['deleted_at']],
            null
        );

        return $this->findPeriod($periodId);
    }

    /** Guard the status workflow (Phase 14). */
    private function assertTransition(array $period, string $toStatus): void
    {
        $from   = (string) $period['status'];
        $allowed = self::TRANSITIONS[$from] ?? [];

        if (!in_array($toStatus, $allowed, true)) {
            throw new RuntimeException(sprintf(
                'A payroll period in %s status cannot move to %s. Allowed: %s.',
                $from,
                $toStatus,
                $allowed === [] ? 'none' : implode(', ', $allowed)
            ));
        }
    }

    private function periodName(string $startDate, string $endDate): string
    {
        return sprintf(
            '%s - %s',
            date('M d, Y', strtotime($startDate)),
            date('M d, Y', strtotime($endDate))
        );
    }
}