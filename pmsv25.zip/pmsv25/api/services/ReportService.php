<?php
/**
 * Reports (Phase 17).
 *
 * Attendance, leave and payroll reports with search, filters, date ranges and
 * CSV export. All queries are prepared statements.
 */

declare(strict_types=1);

namespace App\Services;

use App\Core\Database;

final class ReportService
{
    /** Daily attendance report (Phase 17). */
    public function dailyAttendance(array $filters): array
    {
        return $this->attendanceReport($filters);
    }

    /**
     * Attendance report with filters and pagination.
     *
     * @param array<string, mixed> $filters
     * @return array{items: list<array<string, mixed>>, total: int}
     */
    public function attendanceReport(array $filters, int $page = 1, int $perPage = 50): array
    {
        $where  = ['a.deleted_at IS NULL'];
        $params = [];

        if (!empty($filters['date_from'])) {
            $where[] = 'a.attendance_date >= :date_from';
            $params['date_from'] = (string) $filters['date_from'];
        }

        if (!empty($filters['date_to'])) {
            $where[] = 'a.attendance_date <= :date_to';
            $params['date_to'] = (string) $filters['date_to'];
        }

        if (!empty($filters['date'])) {
            $where[] = 'a.attendance_date = :date';
            $params['date'] = (string) $filters['date'];
        }

        foreach (['employee_id' => 'a.employee_id', 'department_id' => 'e.department_id', 'status' => 'a.status'] as $key => $column) {
            if (!empty($filters[$key])) {
                $where[] = sprintf('%s = :%s', $column, $key);
                $params[$key] = in_array($key, ['employee_id', 'department_id'], true)
                    ? (int) $filters[$key]
                    : (string) $filters[$key];
            }
        }

        // Undertime report lists any row that actually recorded undertime
        // minutes, regardless of its single status value (a LATE day that ended
        // early still carried an undertime deduction).
        if (!empty($filters['with_undertime_minutes'])) {
            $where[] = 'a.undertime_minutes > 0';
        }

        $whereSql = implode(' AND ', $where);

        $total = (int) (Database::scalar(
            "SELECT COUNT(*) FROM attendance a JOIN employees e ON e.id = a.employee_id WHERE {$whereSql}",
            $params
        ) ?? 0);

        $perPage = max(1, $perPage);
        $offset  = max(0, ($page - 1) * $perPage);

        $items = Database::select(
            "SELECT a.id, a.attendance_date, a.time_in, a.time_out, a.worked_hours,
                    a.late_minutes, a.undertime_minutes, a.overtime_hours, a.status,
                    a.is_rest_day, a.is_holiday, a.remarks,
                    e.employee_number, e.first_name, e.middle_name, e.last_name, e.suffix,
                    d.name AS department_name, s.name AS shift_name
               FROM attendance a
               JOIN employees e ON e.id = a.employee_id
               LEFT JOIN departments d ON d.id = e.department_id
               LEFT JOIN shifts s ON s.id = a.shift_id
              WHERE {$whereSql}
              ORDER BY a.attendance_date DESC, e.employee_number ASC
              LIMIT {$perPage} OFFSET {$offset}",
            $params
        );

        foreach ($items as &$item) {
            $item['full_name'] = trim(implode(' ', array_filter([
                $item['first_name'], $item['middle_name'], $item['last_name'], $item['suffix'],
            ], static fn (mixed $v): bool => (string) $v !== '')));
        }
        unset($item);

        return ['items' => $items, 'total' => $total];
    }
/**
     * Monthly attendance summary per employee (Phase 17).
     *
     * @param array<string, mixed> $filters
     * @return list<array<string, mixed>>
     */
    public function monthlyAttendance(array $filters): array
    {
        $params = [
            'year'  => (int) ($filters['year'] ?? date('Y')),
            'month' => (int) ($filters['month'] ?? date('n')),
        ];

        $where = 'a.deleted_at IS NULL AND MONTH(a.attendance_date) = :month AND YEAR(a.attendance_date) = :year';

        if (!empty($filters['employee_id'])) {
            $where .= ' AND a.employee_id = :employee_id';
            $params['employee_id'] = (int) $filters['employee_id'];
        }

        if (!empty($filters['department_id'])) {
            $where .= ' AND e.department_id = :department_id';
            $params['department_id'] = (int) $filters['department_id'];
        }

        return Database::select(
            "SELECT e.id, e.employee_number, e.first_name, e.middle_name, e.last_name, e.suffix,
                    d.name AS department_name,
                    COUNT(a.id) AS total_days,
                    COALESCE(SUM(CASE WHEN a.status IN ('PRESENT','LATE','UNDERTIME') THEN 1 ELSE 0 END), 0) AS present_days,
                    COALESCE(SUM(CASE WHEN a.status = 'LATE' THEN 1 ELSE 0 END), 0) AS late_days,
                    COALESCE(SUM(CASE WHEN a.status = 'ABSENT' THEN 1 ELSE 0 END), 0) AS absent_days,
                    COALESCE(SUM(CASE WHEN a.status = 'LEAVE' THEN 1 ELSE 0 END), 0) AS leave_days,
                    COALESCE(SUM(CASE WHEN a.status = 'HOLIDAY' THEN 1 ELSE 0 END), 0) AS holiday_days,
                    COALESCE(SUM(CASE WHEN a.status = 'REST_DAY' THEN 1 ELSE 0 END), 0) AS rest_days,
                    COALESCE(SUM(a.late_minutes), 0) AS late_minutes,
                    COALESCE(SUM(a.undertime_minutes), 0) AS undertime_minutes,
                    COALESCE(SUM(a.overtime_hours), 0) AS overtime_hours,
                    COALESCE(SUM(a.worked_hours), 0) AS worked_hours
               FROM employees e
               LEFT JOIN attendance a ON a.employee_id = e.id AND {$where}
               LEFT JOIN departments d ON d.id = e.department_id
              WHERE e.deleted_at IS NULL AND e.archived_at IS NULL
              GROUP BY e.id, e.employee_number, e.first_name, e.middle_name, e.last_name, e.suffix, d.name
              ORDER BY e.employee_number",
            $params
        );
    }

    /** Late report (Phase 17). */
    public function lateReport(array $filters, int $page = 1, int $perPage = 50): array
    {
        $filters['status'] = 'LATE';

        return $this->attendanceReport($filters, $page, $perPage);
    }

    /** Absence report (Phase 17). */
    public function absenceReport(array $filters, int $page = 1, int $perPage = 50): array
    {
        $filters['status'] = 'ABSENT';

        return $this->attendanceReport($filters, $page, $perPage);
    }

    /** Undertime report (Phase 17). */
    public function undertimeReport(array $filters, int $page = 1, int $perPage = 50): array
    {
        $filters['with_undertime_minutes'] = true;

        return $this->attendanceReport($filters, $page, $perPage);
    }

    /**
     * Chronological attendance/leave ledger for one employee. Attendance and
     * leave events share a stable set of columns so the same data is useful on
     * screen, in print, and as a CSV demonstration record.
     *
     * @return array{items: list<array<string, mixed>>, total: int}
     */
    public function attendanceLeaveLedger(
        int $employeeId,
        array $filters,
        int $page = 1,
        int $perPage = 100
    ): array {
        $attendanceWhere = ['a.employee_id = :attendance_employee', 'a.deleted_at IS NULL'];
        $leaveWhere = ['lr.employee_id = :leave_employee', 'lr.deleted_at IS NULL'];
        $params = [
            'attendance_employee' => $employeeId,
            'leave_employee' => $employeeId,
        ];

        if (!empty($filters['date_from'])) {
            $attendanceWhere[] = 'a.attendance_date >= :attendance_from';
            $leaveWhere[] = 'lr.end_date >= :leave_from';
            $params['attendance_from'] = (string) $filters['date_from'];
            $params['leave_from'] = (string) $filters['date_from'];
        }

        if (!empty($filters['date_to'])) {
            $attendanceWhere[] = 'a.attendance_date <= :attendance_to';
            $leaveWhere[] = 'lr.start_date <= :leave_to';
            $params['attendance_to'] = (string) $filters['date_to'];
            $params['leave_to'] = (string) $filters['date_to'];
        }

        $attendanceSql = implode(' AND ', $attendanceWhere);
        $leaveSql = implode(' AND ', $leaveWhere);
        $union = "SELECT a.attendance_date AS record_date, 'ATTENDANCE' AS record_type,
                         a.status, a.time_in, a.time_out, a.worked_hours,
                         a.late_minutes, a.undertime_minutes, a.overtime_hours,
                         NULL AS leave_type, NULL AS leave_days,
                         COALESCE(a.remarks, '') AS details,
                         e.employee_number,
                         CONCAT_WS(' ', e.first_name, e.middle_name, e.last_name, e.suffix) AS full_name,
                         d.name AS department_name
                    FROM attendance a
                    JOIN employees e ON e.id = a.employee_id
                    LEFT JOIN departments d ON d.id = e.department_id
                   WHERE {$attendanceSql}
                  UNION ALL
                  SELECT lr.start_date AS record_date, 'LEAVE' AS record_type,
                         lr.status, NULL AS time_in, NULL AS time_out, NULL AS worked_hours,
                         NULL AS late_minutes, NULL AS undertime_minutes, NULL AS overtime_hours,
                         lt.name AS leave_type, lr.days AS leave_days,
                         CONCAT(DATE_FORMAT(lr.start_date, '%b %e'), ' - ', DATE_FORMAT(lr.end_date, '%b %e, %Y'),
                                ': ', lr.reason) AS details,
                         e.employee_number,
                         CONCAT_WS(' ', e.first_name, e.middle_name, e.last_name, e.suffix) AS full_name,
                         d.name AS department_name
                    FROM leave_requests lr
                    JOIN leave_types lt ON lt.id = lr.leave_type_id
                    JOIN employees e ON e.id = lr.employee_id
                    LEFT JOIN departments d ON d.id = e.department_id
                   WHERE {$leaveSql}";

        $total = (int) (Database::scalar("SELECT COUNT(*) FROM ({$union}) ledger", $params) ?? 0);
        $perPage = max(1, min(200, $perPage));
        $offset = max(0, ($page - 1) * $perPage);
        $items = Database::select(
            "SELECT * FROM ({$union}) ledger
              ORDER BY record_date DESC, record_type ASC
              LIMIT {$perPage} OFFSET {$offset}",
            $params
        );

        return ['items' => $items, 'total' => $total];
    }
    /**
     * Executive summary for the Attendance / Leave Ledger.
     *
     * Powers the FX-style dashboard: MTD KPI cards, breakdowns by status /
     * leave type / counterparty analogue (department), and a monthly trend
     * for the line chart. All values come from live system data.
     *
     * @return array<string, mixed>
     */
    public function attendanceLeaveLedgerSummary(int $employeeId, array $filters): array
    {
        $dateFrom = !empty($filters['date_from']) ? (string) $filters['date_from'] : date('Y-m-01');
        $dateTo = !empty($filters['date_to']) ? (string) $filters['date_to'] : date('Y-m-t');

        $ledger = $this->attendanceLeaveLedger($employeeId, ['date_from' => $dateFrom, 'date_to' => $dateTo], 1, 200);
        $items = $ledger['items'];

        $kpis = ['present' => 0, 'late' => 0, 'absent' => 0, 'leave' => 0, 'ot_hours' => 0.0, 'late_minutes' => 0, 'worked_hours' => 0.0, 'records' => count($items)];
        $byStatus = [];
        $byLeaveType = [];
        $byDay = [];

        foreach ($items as $row) {
            $type = (string) ($row['record_type'] ?? '');
            if ($type === 'ATTENDANCE') {
                $status = strtoupper((string) ($row['status'] ?? ''));
                $byStatus[$status] = ($byStatus[$status] ?? 0) + 1;
                if (in_array($status, ['PRESENT', 'LATE', 'UNDERTIME'], true)) {
                    $kpis['present']++;
                }
                if ($status === 'LATE') {
                    $kpis['late']++;
                }
                if ($status === 'ABSENT') {
                    $kpis['absent']++;
                }
                $kpis['ot_hours'] += (float) ($row['overtime_hours'] ?? 0);
                $kpis['late_minutes'] += (int) ($row['late_minutes'] ?? 0);
                $kpis['worked_hours'] += (float) ($row['worked_hours'] ?? 0);
                $day = substr((string) ($row['record_date'] ?? ''), 0, 10);
                if ($day !== '') {
                    if (!isset($byDay[$day])) {
                        $byDay[$day] = ['date' => $day, 'present' => 0, 'leave' => 0, 'ot' => 0.0];
                    }
                    $byDay[$day]['present']++;
                    $byDay[$day]['ot'] += (float) ($row['overtime_hours'] ?? 0);
                }
            } elseif (strtoupper((string) ($row['status'] ?? '')) === 'APPROVED') {
                // Detailed audit rows retain REJECTED/CANCELLED, but KPI and chart must exclude them.
                $kpis['leave'] += (float) ($row['leave_days'] ?? 0);
                $lt = (string) ($row['leave_type'] ?? 'Leave');
                $byLeaveType[$lt] = ($byLeaveType[$lt] ?? 0) + (float) ($row['leave_days'] ?? 0);
                $day = substr((string) ($row['record_date'] ?? ''), 0, 10);
                if ($day !== '') {
                    if (!isset($byDay[$day])) {
                        $byDay[$day] = ['date' => $day, 'present' => 0, 'leave' => 0, 'ot' => 0.0];
                    }
                    $byDay[$day]['leave'] += (float) ($row['leave_days'] ?? 0);
                }
            }
        }

        ksort($byDay);

        // Department coverage analogue: present days per department (all staff in range).
        $deptParams = ['from' => $dateFrom, 'to' => $dateTo];
        $byDepartment = Database::select(
            "SELECT d.name AS name,
                    COALESCE(SUM(CASE WHEN a.status IN ('PRESENT','LATE','UNDERTIME') THEN 1 ELSE 0 END), 0) AS present_days,
                    COALESCE(SUM(CASE WHEN a.status = 'LEAVE' THEN 1 ELSE 0 END), 0) AS leave_days,
                    COUNT(a.id) AS records
               FROM departments d
               LEFT JOIN employees e ON e.department_id = d.id AND e.deleted_at IS NULL AND e.archived_at IS NULL
               LEFT JOIN attendance a ON a.employee_id = e.id AND a.deleted_at IS NULL AND a.attendance_date BETWEEN :from AND :to
              WHERE d.deleted_at IS NULL AND d.is_active = 1
              GROUP BY d.id, d.name
              ORDER BY present_days DESC",
            $deptParams
        );

        // Monthly trend for the line chart (last 6 months incl. current).
        $monthly = Database::select(
            "SELECT DATE_FORMAT(a.attendance_date, '%Y-%m') AS month,
                    COALESCE(SUM(CASE WHEN a.status IN ('PRESENT','LATE','UNDERTIME') THEN 1 ELSE 0 END), 0) AS present_days,
                    COALESCE(SUM(a.overtime_hours), 0) AS ot_hours
               FROM attendance a
              WHERE a.employee_id = :emp AND a.deleted_at IS NULL AND a.attendance_date >= DATE_SUB(:to, INTERVAL 6 MONTH)
              GROUP BY month ORDER BY month",
            ['emp' => $employeeId, 'to' => $dateTo]
        );

        $balances = Database::select(
            'SELECT lt.name, lb.entitled_days, lb.used_days, lb.pending_days,
                    (lb.entitled_days - lb.used_days - lb.pending_days) AS remaining_days
               FROM leave_balances lb
               JOIN leave_types lt ON lt.id = lb.leave_type_id
              WHERE lb.employee_id = :emp AND lb.year = :year
              ORDER BY lt.name',
            ['emp' => $employeeId, 'year' => (int) substr($dateFrom, 0, 4)]
        );

        return [
            'employee_id' => $employeeId,
            'date_from' => $dateFrom,
            'date_to' => $dateTo,
            'kpis' => $kpis,
            'by_status' => array_map(static fn ($k, $v): array => ['status' => $k, 'count' => $v], array_keys($byStatus), array_values($byStatus)),
            'by_leave_type' => array_map(static fn ($k, $v): array => ['name' => $k, 'days' => $v], array_keys($byLeaveType), array_values($byLeaveType)),
            'by_day' => array_values($byDay),
            'by_department' => $byDepartment,
            'monthly' => $monthly,
            'balances' => $balances,
            'total' => $ledger['total'],
        ];
    }

/**
     * Overtime report (Phase 17).
     *
     * @param array<string, mixed> $filters
     * @return array{items: list<array<string, mixed>>, total: int}
     */
    public function overtimeReport(array $filters, int $page = 1, int $perPage = 50): array
    {
        $where  = ["o.deleted_at IS NULL", "o.status IN ('APPROVED','PENDING','ACCEPTED','COMPLETED','REJECTED','CANCELLED')"];
        $params = [];

        foreach (['employee_id' => 'o.employee_id', 'department_id' => 'e.department_id', 'status' => 'o.status'] as $key => $column) {
            if (!empty($filters[$key])) {
                $where[] = sprintf('%s = :%s', $column, $key);
                $params[$key] = $key === 'department_id' || $key === 'employee_id'
                    ? (int) $filters[$key]
                    : (string) $filters[$key];
            }
        }

        foreach (['date_from' => 'o.overtime_date >= :date_from', 'date_to' => 'o.overtime_date <= :date_to'] as $key => $clause) {
            if (!empty($filters[$key])) {
                $where[] = $clause;
                $params[$key] = (string) $filters[$key];
            }
        }

        $whereSql = implode(' AND ', $where);

        $total = (int) (Database::scalar(
            "SELECT COUNT(*) FROM overtime_requests o JOIN employees e ON e.id = o.employee_id WHERE {$whereSql}",
            $params
        ) ?? 0);

        $perPage = max(1, $perPage);
        $offset  = max(0, ($page - 1) * $perPage);

        $items = Database::select(
            "SELECT o.id, o.overtime_date, o.start_time, o.end_time, o.hours, o.applied_hours,
                    o.ot_type, o.status, o.reason,
                    e.employee_number, e.first_name, e.middle_name, e.last_name, e.suffix,
                    d.name AS department_name
               FROM overtime_requests o
               JOIN employees e ON e.id = o.employee_id
               LEFT JOIN departments d ON d.id = e.department_id
              WHERE {$whereSql}
              ORDER BY o.overtime_date DESC
              LIMIT {$perPage} OFFSET {$offset}",
            $params
        );

        foreach ($items as &$item) {
            $item['full_name'] = trim(implode(' ', array_filter([
                $item['first_name'], $item['middle_name'], $item['last_name'], $item['suffix'],
            ], static fn (mixed $v): bool => (string) $v !== '')));
        }
        unset($item);

        return ['items' => $items, 'total' => $total];
    }
/**
     * Payroll reports (Phase 17): summary, per employee, per department.
     *
     * @param array<string, mixed> $filters
     * @return list<array<string, mixed>>
     */
    public function payrollSummary(array $filters): array
    {
        $params = [];
        $where  = 'pp.deleted_at IS NULL';

        if (!empty($filters['period_id'])) {
            $where .= ' AND pp.id = :period_id';
            $params['period_id'] = (int) $filters['period_id'];
        }

        foreach (['date_from' => 'pp.end_date >= :date_from', 'date_to' => 'pp.start_date <= :date_to'] as $key => $clause) {
            if (!empty($filters[$key])) {
                $where .= ' AND ' . $clause;
                $params[$key] = (string) $filters[$key];
            }
        }

        return Database::select(
            "SELECT pp.id, pp.code, pp.name, pp.status, pp.start_date, pp.end_date, pp.pay_date,
                    pp.total_gross, pp.total_deductions, pp.total_net,
                    (SELECT COUNT(*) FROM payroll p WHERE p.payroll_period_id = pp.id) AS employee_count
               FROM payroll_periods pp
              WHERE {$where}
              ORDER BY pp.start_date DESC",
            $params
        );
    }

    /**
     * Employee payroll report (Phase 17).
     *
     * @param array<string, mixed> $filters
     * @return list<array<string, mixed>>
     */
    public function employeePayroll(array $filters): array
    {
        $params = [];
        $where  = 'pp.deleted_at IS NULL';

        if (!empty($filters['employee_id'])) {
            $where .= ' AND p.employee_id = :employee_id';
            $params['employee_id'] = (int) $filters['employee_id'];
        }

        if (!empty($filters['department_id'])) {
            $where .= ' AND e.department_id = :department_id';
            $params['department_id'] = (int) $filters['department_id'];
        }

        if (!empty($filters['period_id'])) {
            $where .= ' AND pp.id = :period_id';
            $params['period_id'] = (int) $filters['period_id'];
        }

        foreach (['date_from' => 'pp.end_date >= :date_from', 'date_to' => 'pp.start_date <= :date_to'] as $key => $clause) {
            if (!empty($filters[$key])) {
                $where .= ' AND ' . $clause;
                $params[$key] = (string) $filters[$key];
            }
        }

        return Database::select(
            "SELECT p.id, e.employee_number, e.first_name, e.middle_name, e.last_name, e.suffix,
                    d.name AS department_name,
                    pp.code AS period_code, pp.name AS period_name, pp.start_date, pp.end_date,
                    p.basic_pay, p.overtime_hours, p.overtime_pay, p.allowances_total, p.bonus,
                    p.gross_pay, p.late_deduction, p.undertime_deduction, p.absence_deduction,
                    p.leave_deduction, p.other_deductions, p.total_deductions, p.net_pay,
                    p.late_minutes, p.undertime_minutes, p.working_days, p.present_days,
                    p.absent_days, p.leave_days, p.is_locked, p.calculated_at
               FROM payroll p
               JOIN employees e ON e.id = p.employee_id
               JOIN payroll_periods pp ON pp.id = p.payroll_period_id
               LEFT JOIN departments d ON d.id = e.department_id
              WHERE {$where}
              ORDER BY pp.start_date DESC, e.employee_number",
            $params
        );
    }
/**
     * Department payroll report (Phase 17).
     *
     * @param array<string, mixed> $filters
     * @return list<array<string, mixed>>
     */
    public function departmentPayroll(array $filters): array
    {
        $params = [];
        $where  = 'pp.deleted_at IS NULL';

        if (!empty($filters['period_id'])) {
            $where .= ' AND pp.id = :period_id';
            $params['period_id'] = (int) $filters['period_id'];
        }

        foreach (['date_from' => 'pp.end_date >= :date_from', 'date_to' => 'pp.start_date <= :date_to'] as $key => $clause) {
            if (!empty($filters[$key])) {
                $where .= ' AND ' . $clause;
                $params[$key] = (string) $filters[$key];
            }
        }

        return Database::select(
            "SELECT d.id, d.name AS department_name, d.code,
                    COUNT(p.id) AS employee_count,
                    COALESCE(SUM(p.basic_pay), 0) AS basic_pay,
                    COALESCE(SUM(p.overtime_pay), 0) AS overtime_pay,
                    COALESCE(SUM(p.allowances_total), 0) AS allowances_total,
                    COALESCE(SUM(p.gross_pay), 0) AS gross_pay,
                    COALESCE(SUM(p.total_deductions), 0) AS total_deductions,
                    COALESCE(SUM(p.net_pay), 0) AS net_pay
               FROM payroll p
               JOIN employees e ON e.id = p.employee_id
               JOIN payroll_periods pp ON pp.id = p.payroll_period_id
               LEFT JOIN departments d ON d.id = e.department_id
              WHERE {$where}
              GROUP BY d.id, d.name, d.code
              ORDER BY net_pay DESC",
            $params
        );
    }

    /**
     * Deduction report (Phase 17).
     *
     * @param array<string, mixed> $filters
     * @return list<array<string, mixed>>
     */
    public function deductionReport(array $filters): array
    {
        $params = [];
        $where  = 'pp.deleted_at IS NULL';

        if (!empty($filters['period_id'])) {
            $where .= ' AND pp.id = :period_id';
            $params['period_id'] = (int) $filters['period_id'];
        }

        foreach (['date_from' => 'pp.end_date >= :date_from', 'date_to' => 'pp.start_date <= :date_to'] as $key => $clause) {
            if (!empty($filters[$key])) {
                $where .= ' AND ' . $clause;
                $params[$key] = (string) $filters[$key];
            }
        }

        return Database::select(
            "SELECT pi.code, pi.name,
                    COUNT(pi.id) AS entry_count,
                    COALESCE(SUM(pi.amount), 0) AS total_amount
               FROM payroll_items pi
               JOIN payroll p ON p.id = pi.payroll_id
               JOIN payroll_periods pp ON pp.id = p.payroll_period_id
              WHERE pi.item_type = 'DEDUCTION' AND {$where}
              GROUP BY pi.code, pi.name
              ORDER BY total_amount DESC",
            $params
        );
    }
/**
     * Leave reports (Phase 17): history and balance.
     *
     * @param array<string, mixed> $filters
     * @return list<array<string, mixed>>
     */
    public function leaveHistory(array $filters): array
    {
        $params = [];
        $where  = ['lr.deleted_at IS NULL'];

        if (!empty($filters['employee_id'])) {
            $where[] = 'lr.employee_id = :employee_id';
            $params['employee_id'] = (int) $filters['employee_id'];
        }

        if (!empty($filters['leave_type_id'])) {
            $where[] = 'lr.leave_type_id = :leave_type_id';
            $params['leave_type_id'] = (int) $filters['leave_type_id'];
        }

        if (!empty($filters['department_id'])) {
            $where[] = 'e.department_id = :department_id';
            $params['department_id'] = (int) $filters['department_id'];
        }

        if (!empty($filters['status'])) {
            $where[] = 'lr.status = :status';
            $params['status'] = (string) $filters['status'];
        }

        foreach (['date_from' => 'lr.start_date >= :date_from', 'date_to' => 'lr.end_date <= :date_to'] as $key => $clause) {
            if (!empty($filters[$key])) {
                $where[] = $clause;
                $params[$key] = (string) $filters[$key];
            }
        }

        return Database::select(
            "SELECT lr.id, e.employee_number, e.first_name, e.middle_name, e.last_name, e.suffix,
                    d.name AS department_name,
                    lt.code AS leave_type_code, lt.name AS leave_type_name, lt.is_paid,
                    lr.start_date, lr.end_date, lr.days, lr.status, lr.reason,
                    lr.approver_remarks, u.username AS approver_username, lr.created_at
               FROM leave_requests lr
               JOIN employees e ON e.id = lr.employee_id
               JOIN leave_types lt ON lt.id = lr.leave_type_id
               LEFT JOIN departments d ON d.id = e.department_id
               LEFT JOIN users u ON u.id = lr.approver_id
              WHERE " . implode(' AND ', $where) . '
              ORDER BY lr.start_date DESC',
            $params
        );
    }

    /**
     * Leave balance report (Phase 17).
     *
     * @param array<string, mixed> $filters
     * @return list<array<string, mixed>>
     */
    public function leaveBalanceReport(array $filters): array
    {
        $params = ['year' => (int) ($filters['year'] ?? date('Y'))];
        $where  = '';

        if (!empty($filters['employee_id'])) {
            $where .= ' AND e.id = :employee_id';
            $params['employee_id'] = (int) $filters['employee_id'];
        }

        if (!empty($filters['department_id'])) {
            $where .= ' AND e.department_id = :department_id';
            $params['department_id'] = (int) $filters['department_id'];
        }

        return Database::select(
            "SELECT e.id, e.employee_number, e.first_name, e.middle_name, e.last_name, e.suffix,
                    d.name AS department_name,
                    lt.code, lt.name AS leave_type_name, lt.is_paid,
                    COALESCE(SUM(lb.entitled_days), 0) AS entitled_days,
                    COALESCE(SUM(lb.used_days), 0) AS used_days,
                    COALESCE(SUM(lb.pending_days), 0) AS pending_days,
                    COALESCE(SUM(lb.entitled_days - lb.used_days - lb.pending_days), 0) AS remaining_days
               FROM employees e
               LEFT JOIN leave_balances lb ON lb.employee_id = e.id AND lb.year = :year
               LEFT JOIN leave_types lt ON lt.id = lb.leave_type_id
               LEFT JOIN departments d ON d.id = e.department_id
              WHERE e.deleted_at IS NULL AND e.archived_at IS NULL {$where}
              GROUP BY e.id, e.employee_number, e.first_name, e.middle_name, e.last_name, e.suffix,
                       d.name, lt.code, lt.name, lt.is_paid
              ORDER BY e.employee_number, lt.name",
            $params
        );
    }
    /**
     * Employee-level statutory contribution register (statutory reports).
     *
     * Reads the same evidence a remittance is built from — payroll_statutory
     * rows on locked periods (FOR_REVIEW onwards). A DRAFT can still be
     * recalculated, so its contributions are never reported as filing
     * evidence, mirroring StatutoryRemittanceService. Paginated so a wide
     * window stays cheap, and CSV-exportable through the controller.
     *
     * @param array<string, mixed> $filters date_from, date_to, agency_code, code, employee_id
     * @return array{items: list<array<string, mixed>>, total: int}
     */
    public function statutoryContributions(array $filters, int $page = 1, int $perPage = 50): array
    {
        [$where, $params] = $this->statutoryEvidenceWhere($filters);

        $total = (int) (Database::scalar(
            "SELECT COUNT(*)
               FROM payroll_statutory ps
               JOIN payroll p ON p.id = ps.payroll_id
               JOIN payroll_periods pp ON pp.id = p.payroll_period_id
               LEFT JOIN employees e ON e.id = p.employee_id
              WHERE {$where}",
            $params
        ) ?? 0);

        $perPage = max(1, $perPage);
        $offset  = max(0, ($page - 1) * $perPage);

        $items = Database::select(
            "SELECT ps.id AS statutory_id, ps.code, ps.name AS line_name, ps.scheme,
                    ps.schedule_source, ps.salary_base, ps.credited_base,
                    ps.employee_rate, ps.employer_rate,
                    ps.monthly_employee_amount, ps.monthly_employer_amount,
                    ps.employee_amount, ps.employer_amount, ps.extra_amount,
                    p.id AS payroll_id, p.employee_id,
                    e.employee_number, e.first_name, e.middle_name, e.last_name, e.suffix,
                    pp.id AS period_id, pp.code AS period_code, pp.name AS period_name,
                    pp.start_date, pp.end_date, pp.status AS period_status
               FROM payroll_statutory ps
               JOIN payroll p ON p.id = ps.payroll_id
               JOIN payroll_periods pp ON pp.id = p.payroll_period_id
               LEFT JOIN employees e ON e.id = p.employee_id
              WHERE {$where}
              ORDER BY pp.start_date ASC, pp.end_date ASC, e.employee_number ASC, ps.code ASC
              LIMIT {$perPage} OFFSET {$offset}",
            $params
        );

        foreach ($items as &$item) {
            $item['employee_name'] = trim(implode(' ', array_filter([
                $item['first_name'], $item['middle_name'], $item['last_name'], $item['suffix'],
            ], static fn (mixed $part): bool => $part !== null && trim((string) $part) !== '')));
            unset($item['first_name'], $item['middle_name'], $item['last_name'], $item['suffix']);

            $item['agency_code'] = StatutoryRemittanceService::agencyForCode((string) $item['code']);

            foreach (['credited_base', 'monthly_employee_amount', 'monthly_employer_amount',
                      'employee_amount', 'employer_amount', 'extra_amount'] as $money) {
                $item[$money] = (float) $item[$money];
            }
            foreach (['employee_rate', 'employer_rate'] as $rate) {
                $item[$rate] = $item[$rate] === null ? null : (float) $item[$rate];
            }
        }
        unset($item);

        return ['items' => $items, 'total' => $total];
    }


/**
    /**
     * The remittance register itself (statutory reports).
     *
     * Lists filed statutory_remittances with their filing/payment state, so a
     * reviewer can see what is OPEN (owed), SUBMITTED (filed, awaiting
     * payment) or PAID. It reads only the filed register — it never recomputes
     * a contribution — so the figures always match what
     * StatutoryRemittanceService committed.
     *
     * @param array<string, mixed> $filters agency_code, status, date_from, date_to
     * @return list<array<string, mixed>>
     */
    public function statutoryRemittances(array $filters): array
    {
        $where  = ['1 = 1'];
        $params = [];

        if (!empty($filters['agency_code'])) {
            $where[] = 'r.agency_code = :agency_code';
            $params['agency_code'] = (string) $filters['agency_code'];
        }

        if (!empty($filters['status'])) {
            $where[] = 'r.status = :status';
            $params['status'] = strtoupper((string) $filters['status']);
        }

        if (!empty($filters['date_from'])) {
            $where[] = 'r.period_start >= :date_from';
            $params['date_from'] = (string) $filters['date_from'];
        }

        if (!empty($filters['date_to'])) {
            $where[] = 'r.period_end <= :date_to';
            $params['date_to'] = (string) $filters['date_to'];
        }

        $rows = Database::select(
            "SELECT r.id, r.reference_no, r.agency_code, r.agency_name,
                    r.period_start, r.period_end, r.due_date, r.status,
                    r.employee_count, r.total_employee, r.total_employer,
                    r.total_extra, r.total_amount,
                    r.filing_reference, r.submitted_at,
                    r.paid_reference, r.paid_date, r.notes, r.created_at
               FROM statutory_remittances r
              WHERE " . implode(' AND ', $where) . "
              ORDER BY r.period_start DESC, r.agency_code ASC",
            $params
        );

        foreach ($rows as &$row) {
            $row['employee_count'] = (int) $row['employee_count'];
            foreach (['total_employee', 'total_employer', 'total_extra', 'total_amount'] as $money) {
                $row[$money] = (float) $row[$money];
            }
        }
        unset($row);

        return $rows;
    }


    /**
     * Due contribution totals by agency and month (statutory reports).
     *
     * Aggregates the same locked-period evidence as the register into the
     * per-agency, per-month totals an accountant reconciles against what was
     * actually remitted. The agency mapping is sourced from
     * StatutoryRemittanceService::AGENCIES, so a payroll_statutory code always
     * lands under the agency that files it — the report can never disagree
     * with the remittance register about an agency.
     *
     * @param array<string, mixed> $filters date_from, date_to, agency_code, code, employee_id
     * @return list<array<string, mixed>>
     */
    public function statutorySummary(array $filters): array
    {
        [$where, $params] = $this->statutoryEvidenceWhere($filters);
        $agency  = $this->statutoryAgencyCaseSql();
        $codesIn = $this->statutoryAllCodesIn();

        $rows = Database::select(
            "SELECT agency_code, agency_name, year, month,
                    COUNT(DISTINCT employee_id) AS employee_count,
                    ROUND(SUM(total_employee), 2) AS total_employee,
                    ROUND(SUM(total_employer), 2) AS total_employer,
                    ROUND(SUM(total_extra), 2)    AS total_extra,
                    ROUND(SUM(total_employee + total_employer + total_extra), 2) AS total_amount
               FROM (
                    SELECT p.employee_id,
                           {$agency['code']} AS agency_code,
                           {$agency['name']} AS agency_name,
                           YEAR(pp.start_date)  AS year,
                           MONTH(pp.start_date) AS month,
                           ps.employee_amount AS total_employee,
                           ps.employer_amount AS total_employer,
                           ps.extra_amount    AS total_extra
                      FROM payroll_statutory ps
                      JOIN payroll p ON p.id = ps.payroll_id
                      JOIN payroll_periods pp ON pp.id = p.payroll_period_id
                     WHERE {$where}
                       AND ps.code IN ({$codesIn})
                    ) evidence
              GROUP BY agency_code, agency_name, year, month
              ORDER BY year DESC, month DESC, agency_code ASC",
            $params
        );

        foreach ($rows as &$row) {
            $row['employee_count'] = (int) $row['employee_count'];
            $row['year']           = (int) $row['year'];
            $row['month']          = (int) $row['month'];
            $row['period_label']   = sprintf('%04d-%02d', (int) $row['year'], (int) $row['month']);
            foreach (['total_employee', 'total_employer', 'total_extra', 'total_amount'] as $money) {
                $row[$money] = (float) $row[$money];
            }
        }
        unset($row);

        return $rows;
    }

    /**
     * Shared WHERE clause for the statutory evidence queries. Locked periods
     * only (a DRAFT can still be recalculated) plus the optional date-range,
     * agency, code and employee filters. agency_code is expanded through
     * StatutoryRemittanceService::codesFor() so the report and the remittance
     * register always agree on which payroll_statutory codes an agency files.
     *
     * @param array<string, mixed> $filters
     * @return array{0: string, 1: array<string, int|string>}
     */
    private function statutoryEvidenceWhere(array $filters): array
    {
        // Mirrors StatutoryRemittanceService::LOCKED_STATUSES.
        $where = [
            'pp.deleted_at IS NULL',
            "pp.status IN ('FOR_REVIEW','APPROVED','FINALIZED','PAID')",
        ];
        $params = [];

        if (!empty($filters['date_from'])) {
            $where[] = 'pp.start_date >= :date_from';
            $params['date_from'] = (string) $filters['date_from'];
        }

        if (!empty($filters['date_to'])) {
            $where[] = 'pp.end_date <= :date_to';
            $params['date_to'] = (string) $filters['date_to'];
        }

        if (!empty($filters['agency_code'])) {
            $codes = StatutoryRemittanceService::codesFor((string) $filters['agency_code']);
            if ($codes === []) {
                $where[] = '1 = 0'; // Unknown agency: match nothing, not everything.
            } else {
                $placeholders = [];
                foreach (array_values($codes) as $index => $code) {
                    $key = 'agency_code_' . $index;
                    $placeholders[] = ':' . $key;
                    $params[$key] = $code;
                }
                $where[] = 'ps.code IN (' . implode(', ', $placeholders) . ')';
            }
        }

        if (!empty($filters['code'])) {
            $where[] = 'ps.code = :code';
            $params['code'] = (string) $filters['code'];
        }

        if (!empty($filters['employee_id'])) {
            $where[] = 'p.employee_id = :employee_id';
            $params['employee_id'] = (int) $filters['employee_id'];
        }

        return [implode(' AND ', $where), $params];
    }


    /**
     * SQL CASE expressions mapping a payroll_statutory code to the agency that
     * files it, built from StatutoryRemittanceService::AGENCIES so the summary
     * can never disagree with the remittance register about an agency.
     *
     * @return array{code: string, name: string}
     */
    private function statutoryAgencyCaseSql(): array
    {
        $codeWhens = [];
        $nameWhens = [];

        foreach (StatutoryRemittanceService::AGENCIES as $agencyCode => $meta) {
            $agencyLiteral = "'" . str_replace("'", "''", $agencyCode) . "'";
            $nameLiteral   = "'" . str_replace("'", "''", (string) $meta['name']) . "'";
            foreach ($meta['codes'] as $code) {
                $codeLiteral = "'" . str_replace("'", "''", $code) . "'";
                $codeWhens[] = "WHEN {$codeLiteral} THEN {$agencyLiteral}";
                $nameWhens[] = "WHEN {$codeLiteral} THEN {$nameLiteral}";
            }
        }

        return [
            'code' => 'CASE ps.code ' . implode(' ', $codeWhens) . ' END',
            'name' => 'CASE ps.code ' . implode(' ', $nameWhens) . ' END',
        ];
    }

    /**
     * A quoted, comma-separated IN list of every payroll_statutory code the
     * system files, taken from StatutoryRemittanceService::AGENCIES.
     */
    private function statutoryAllCodesIn(): string
    {
        $codes = [];
        foreach (StatutoryRemittanceService::AGENCIES as $meta) {
            foreach ($meta['codes'] as $code) {
                $codes[] = "'" . str_replace("'", "''", $code) . "'";
            }
        }

        return $codes === [] ? "''" : implode(', ', $codes);
    }


    /**
     * CSV export: streams a report as text/csv (Phase 17).
     *
     * @param list<array<string, mixed>> $rows
     */
    public static function toCsv(array $rows, ?string $filename = null): never
    {
        if (!headers_sent()) {
            header('Content-Type: text/csv; charset=utf-8');
            header('Cache-Control: no-store');

            if ($filename !== null) {
                header(sprintf('Content-Disposition: attachment; filename="%s"', $filename));
            }
        }

        $out = fopen('php://output', 'w');

        if ($out === false) {
            \App\Core\Response::error('Unable to generate the CSV export.', 500);
        }

        // BOM so Excel opens UTF-8 correctly.
        fwrite($out, "\xEF\xBB\xBF");

        if ($rows !== []) {
            fputcsv($out, array_keys($rows[0]));

            foreach ($rows as $row) {
                fputcsv($out, array_map(static fn (mixed $v): string => (string) $v, $row));
            }
        }

        fclose($out);
        exit;
    }
}
