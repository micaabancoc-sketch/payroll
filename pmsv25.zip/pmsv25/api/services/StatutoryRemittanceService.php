<?php
/**
 * Statutory remittance tracking (SSS, PhilHealth, Pag-IBIG, BIR withholding).
 *
 * payroll_statutory already holds every computed contribution; this service
 * turns those rows into a remittance per agency and period window — a filed
 * record with a snapshot of the underlying rows, its aggregate totals, and a
 * confirmation workflow (OPEN -> SUBMITTED -> PAID) that mirrors how the
 * company actually files and pays: nothing can be marked paid without a
 * payment reference and a payment date, and a payment date can never be in
 * the future.
 *
 * Generation only ever reads locked periods (FOR_REVIEW onwards): a draft can
 * still be recalculated, so its rows are not evidence. Regenerating an OPEN
 * remittance replaces its snapshot in place (same reference, new totals); a
 * SUBMITTED or PAID remittance is frozen.
 */

declare(strict_types=1);

namespace App\Services;

use App\Core\AuditLogger;
use App\Core\Database;
use App\Core\ValidationException;
use App\Core\Validator;
use DateTimeImmutable;
use RuntimeException;

final class StatutoryRemittanceService
{
    /**
     * The four agencies a remittance can be filed with, keyed by agency code.
     * Each lists the payroll_statutory codes it collects (BIR collects the
     * WITHHOLDING_TAX rows), so a remittance is always traceable to the exact
     * contribution rows it was built from.
     */
    public const AGENCIES = [
        'SSS'             => ['name' => 'Social Security System', 'codes' => ['SSS']],
        'PHILHEALTH'      => ['name' => 'PhilHealth',             'codes' => ['PHILHEALTH']],
        'PAGIBIG'         => ['name' => 'Pag-IBIG Fund',          'codes' => ['PAGIBIG']],
        'BIR_WITHHOLDING' => ['name' => 'BIR Withholding Tax',    'codes' => ['WITHHOLDING_TAX']],
    ];

    public const STATUSES = ['OPEN', 'SUBMITTED', 'PAID'];

    /**
     * Period statuses whose rows count as filing evidence. A draft can still
     * be recalculated, so its contributions are never included.
     */
    private const LOCKED_STATUSES = ['FOR_REVIEW', 'APPROVED', 'FINALIZED', 'PAID'];

    /** A single window may not span more than ~13 months. */
    public const MAX_WINDOW_DAYS = 400;

    /** payroll_statutory codes per agency code. Unknown agency → empty list. */
    public static function codesFor(string $agencyCode): array
    {
        return self::AGENCIES[$agencyCode]['codes'] ?? [];
    }

    /** The agency that collects a payroll_statutory code, or null. */
    public static function agencyForCode(string $code): ?string
    {
        foreach (self::AGENCIES as $agency => $meta) {
            if (in_array($code, $meta['codes'], true)) {
                return $agency;
            }
        }

        return null;
    }

    /**
     * Build a remittance for one agency over a period window.
     *
     * @param array<string, mixed> $data agency_code, period_start, period_end, optional due_date / notes
     */
    public function generate(array $data, ?int $userId = null): array
    {
        $validator = Validator::make(
            $data,
            [
                'agency_code'  => 'required|string|max:30',
                'period_start' => 'required|date',
                'period_end'   => 'required|date|after_or_equal:period_start',
                'due_date'     => 'nullable|date',
                'notes'        => 'nullable|string|max:500',
            ],
            ['agency_code' => 'Agency']
        );

        if ($validator->fails()) {
            throw new ValidationException($validator->errors());
        }

        $agencyCode = (string) $data['agency_code'];
        $start      = (string) $data['period_start'];
        $end        = (string) $data['period_end'];

        if (!isset(self::AGENCIES[$agencyCode])) {
            throw new ValidationException([
                'agency_code' => sprintf(
                    'The selected agency is not valid. Expected one of: %s.',
                    implode(', ', array_keys(self::AGENCIES))
                ),
            ]);
        }

        // One window may not sprawl across years; that is almost always a typo.
        $startDate = self::strictDate($start, 'period_start');
        $endDate   = self::strictDate($end, 'period_end');
        if ($startDate->diff($endDate)->days + 1 > self::MAX_WINDOW_DAYS) {
            throw new ValidationException([
                'period_end' => sprintf(
                    'A remittance window may not span more than %d days.',
                    self::MAX_WINDOW_DAYS
                ),
            ]);
        }

        $agency       = self::AGENCIES[$agencyCode];
        $source       = [];
        $existing     = null;
        $totals       = ['employee' => 0.0, 'employer' => 0.0, 'extra' => 0.0];
        $remittanceId = 0;

        Database::beginTransaction();

        try {
            $source = $this->sourceRows($agency['codes'], $start, $end);

            if ($source === []) {
                throw new ValidationException([
                    'period_start' => sprintf(
                        'No statutory contributions were found for %s in locked payroll periods between %s and %s. '
                        . 'Calculate and approve the payroll period first — draft periods are never filed.',
                        $agency['name'],
                        $start,
                        $end
                    ),
                ]);
            }

            $existing = Database::selectOne(
                'SELECT * FROM statutory_remittances WHERE agency_code = :agency_code AND period_start = :period_start AND period_end = :period_end',
                ['agency_code' => $agencyCode, 'period_start' => $start, 'period_end' => $end]
            );

            if ($existing !== null && $existing['status'] !== 'OPEN') {
                throw new ValidationException([
                    'period_start' => sprintf(
                        'The %s remittance for %s to %s has already been %s and can no longer be regenerated.',
                        $agency['name'],
                        $start,
                        $end,
                        strtolower((string) $existing['status'])
                    ),
                ]);
            }

            $dueDate = isset($data['due_date']) && (string) $data['due_date'] !== ''
                ? self::strictDate((string) $data['due_date'], 'due_date')->format('Y-m-d')
                : ($existing['due_date'] ?? null);

            if ($existing === null) {
                $remittanceId = Database::insert('statutory_remittances', [
                    'reference_no' => $this->newReference(),
                    'agency_code'  => $agencyCode,
                    'agency_name'  => $agency['name'],
                    'period_start' => $start,
                    'period_end'   => $end,
                    'due_date'     => $dueDate,
                    'status'       => 'OPEN',
                    'notes'        => isset($data['notes']) ? (string) $data['notes'] : null,
                    'created_by'   => $userId,
                ]);
            } else {
                $remittanceId = (int) $existing['id'];
                Database::delete('statutory_remittance_items', ['remittance_id' => $remittanceId]);

                if (isset($data['notes'])) {
                    Database::update('statutory_remittances', ['notes' => (string) $data['notes']], ['id' => $remittanceId]);
                }
            }

            $contributing = [];

            foreach ($source as $row) {
                Database::insert('statutory_remittance_items', [
                    'remittance_id'           => $remittanceId,
                    'payroll_id'              => (int) $row['payroll_id'],
                    'payroll_statutory_id'    => (int) $row['statutory_id'],
                    'payroll_period_id'       => (int) $row['period_id'],
                    'employee_id'             => $row['employee_id'] === null ? null : (int) $row['employee_id'],
                    'employee_number'         => $row['employee_number'],
                    'employee_name'           => $row['employee_name'],
                    'code'                    => (string) $row['code'],
                    'line_name'               => (string) $row['line_name'],
                    'schedule_source'         => $row['schedule_source'],
                    'salary_base'             => $row['salary_base'],
                    'credited_base'           => (float) $row['credited_base'],
                    'employee_rate'           => $row['employee_rate'] === null ? null : (float) $row['employee_rate'],
                    'employer_rate'           => $row['employer_rate'] === null ? null : (float) $row['employer_rate'],
                    'monthly_employee_amount' => (float) $row['monthly_employee_amount'],
                    'monthly_employer_amount' => (float) $row['monthly_employer_amount'],
                    'employee_amount'         => (float) $row['employee_amount'],
                    'employer_amount'         => (float) $row['employer_amount'],
                    'extra_amount'            => (float) $row['extra_amount'],
                    'period_start'            => (string) $row['period_start'],
                    'period_end'              => (string) $row['period_end'],
                ]);

                $totals['employee'] += (float) $row['employee_amount'];
                $totals['employer'] += (float) $row['employer_amount'];
                $totals['extra']    += (float) $row['extra_amount'];

                $rowTotal = (float) $row['employee_amount'] + (float) $row['employer_amount'] + (float) $row['extra_amount'];
                if ($rowTotal > 0.0 && $row['employee_id'] !== null) {
                    $contributing[(int) $row['employee_id']] = true;
                }
            }

            // Totals are recomputed from the snapshot just written, so the
            // header can never drift away from its items.
            Database::update('statutory_remittances', [
                'employee_count' => count($contributing),
                'total_employee' => round($totals['employee'], 2),
                'total_employer' => round($totals['employer'], 2),
                'total_extra'    => round($totals['extra'], 2),
                'total_amount'   => round($totals['employee'] + $totals['employer'] + $totals['extra'], 2),
                'due_date'       => $dueDate,
            ], ['id' => $remittanceId]);

            Database::commit();
        } catch (\Throwable $e) {
            Database::rollBack();
            throw $e;
        }

        AuditLogger::record(
            AuditLogger::STATUTORY_REMITTANCE_GENERATED,
            'statutory_remittance',
            $remittanceId,
            sprintf(
                '%s remittance %s for %s to %s built from %d contribution rows.',
                $agency['name'],
                $this->referenceFor($remittanceId),
                $start,
                $end,
                count($source)
            ),
            $existing === null ? null : [
                'total_employee' => (float) $existing['total_employee'],
                'total_employer' => (float) $existing['total_employer'],
                'total_extra'    => (float) $existing['total_extra'],
            ],
            [
                'total_employee' => round($totals['employee'], 2),
                'total_employer' => round($totals['employer'], 2),
                'total_extra'    => round($totals['extra'], 2),
                'due_date'       => $dueDate,
            ]
        );

        return self::present($this->findOrFail($remittanceId));
    }

    /**
     * File a remittance with the agency — records the filing reference.
     *
     * @param array<string, mixed> $data filing_reference (required)
     */
    public function submit(int $id, array $data, ?int $userId = null): array
    {
        $remittance = $this->findOrFail($id);

        if ($remittance['status'] !== 'OPEN') {
            throw new ValidationException([
                'status' => sprintf(
                    'A remittance can only be filed while it is OPEN; this one is %s.',
                    (string) $remittance['status']
                ),
            ]);
        }

        $validator = Validator::make($data, [
            'filing_reference' => 'required|string|min:3|max:150',
        ]);

        if ($validator->fails()) {
            throw new ValidationException($validator->errors());
        }

        $this->requireItems($id);
        $filingReference = trim((string) $data['filing_reference']);

        Database::update('statutory_remittances', [
            'filing_reference' => $filingReference,
            'status'           => 'SUBMITTED',
            'submitted_by'     => $userId,
            'submitted_at'     => date('Y-m-d H:i:s'),
        ], ['id' => $id]);

        AuditLogger::record(
            AuditLogger::STATUTORY_REMITTANCE_SUBMITTED,
            'statutory_remittance',
            $id,
            sprintf(
                'Remittance %s (%s, %s to %s) filed as %s.',
                (string) $remittance['reference_no'],
                (string) $remittance['agency_name'],
                (string) $remittance['period_start'],
                (string) $remittance['period_end'],
                $filingReference
            ),
            ['status' => 'OPEN', 'filing_reference' => $remittance['filing_reference']],
            ['status' => 'SUBMITTED', 'filing_reference' => $filingReference]
        );

        return self::present($this->findOrFail($id));
    }

    /**
     * Confirm the payment of a filed remittance — requires the payment
     * reference and the payment date; a future date is refused.
     *
     * @param array<string, mixed> $data paid_reference, paid_date (both required)
     */
    public function pay(int $id, array $data, ?int $userId = null): array
    {
        $remittance = $this->findOrFail($id);

        if ($remittance['status'] !== 'SUBMITTED') {
            throw new ValidationException([
                'status' => sprintf(
                    'A remittance can only be marked paid after it has been filed; this one is %s.',
                    (string) $remittance['status']
                ),
            ]);
        }

        $validator = Validator::make($data, [
            'paid_reference' => 'required|string|min:3|max:150',
            'paid_date'      => 'required|date',
        ]);

        if ($validator->fails()) {
            throw new ValidationException($validator->errors());
        }

        $paidDate = self::strictDate(trim((string) $data['paid_date']), 'paid_date');
        if ($paidDate->format('Y-m-d') > date('Y-m-d')) {
            throw new ValidationException(['paid_date' => 'The payment date cannot be in the future.']);
        }

        $this->requireItems($id);
        $paidReference = trim((string) $data['paid_reference']);

        Database::update('statutory_remittances', [
            'status'         => 'PAID',
            'paid_reference' => $paidReference,
            'paid_date'      => $paidDate->format('Y-m-d'),
            'paid_by'        => $userId,
            'paid_at'        => date('Y-m-d H:i:s'),
        ], ['id' => $id]);

        AuditLogger::record(
            AuditLogger::STATUTORY_REMITTANCE_PAID,
            'statutory_remittance',
            $id,
            sprintf(
                'Remittance %s (%s, %s to %s) paid %s on %s.',
                (string) $remittance['reference_no'],
                (string) $remittance['agency_name'],
                (string) $remittance['period_start'],
                (string) $remittance['period_end'],
                $paidReference,
                $paidDate->format('Y-m-d')
            ),
            ['status' => 'SUBMITTED', 'paid_reference' => $remittance['paid_reference'], 'paid_date' => $remittance['paid_date']],
            ['status' => 'PAID', 'paid_reference' => $paidReference, 'paid_date' => $paidDate->format('Y-m-d')]
        );

        return self::present($this->findOrFail($id));
    }

    /**
     * The register with search, filters and pagination.
     *
     * @param array<string, mixed> $filters agency_code / status / date_from / date_to / q
     * @return array{items: list<array<string, mixed>>, total: int}
     */
    public function list(array $filters, int $page = 1, int $perPage = 50): array
    {
        $where  = ['1 = 1'];
        $params = [];

        if (!empty($filters['agency_code'])) {
            $where[] = 'agency_code = :agency_code';
            $params['agency_code'] = (string) $filters['agency_code'];
        }

        if (!empty($filters['status'])) {
            $where[] = 'status = :status';
            $params['status'] = (string) $filters['status'];
        }

        // Overlap: any remittance whose window intersects the requested range.
        if (!empty($filters['date_from'])) {
            $where[] = 'period_end >= :date_from';
            $params['date_from'] = (string) $filters['date_from'];
        }

        if (!empty($filters['date_to'])) {
            $where[] = 'period_start <= :date_to';
            $params['date_to'] = (string) $filters['date_to'];
        }

        if (!empty($filters['q'])) {
            $where[] = '(reference_no LIKE :q OR agency_name LIKE :q OR filing_reference LIKE :q OR paid_reference LIKE :q)';
            $params['q'] = '%' . (string) $filters['q'] . '%';
        }

        $whereSql = implode(' AND ', $where);

        $total = (int) (Database::scalar(
            "SELECT COUNT(*) FROM statutory_remittances WHERE {$whereSql}",
            $params
        ) ?? 0);

        $perPage = max(1, $perPage);
        $offset  = max(0, ($page - 1) * $perPage);

        $rows = Database::select(
            "SELECT * FROM statutory_remittances
              WHERE {$whereSql}
              ORDER BY period_start DESC, agency_code ASC, id DESC
              LIMIT {$perPage} OFFSET {$offset}",
            $params
        );

        return [
            'items' => array_map(static fn (array $row): array => self::present($row), $rows),
            'total' => $total,
        ];
    }

    /** One remittance, presented. */
    public function find(int $id): array
    {
        return self::present($this->findOrFail($id));
    }

    /**
     * The snapshot rows of one remittance.
     *
     * @return array{items: list<array<string, mixed>>, total: int}
     */
    public function items(int $id, int $page = 1, int $perPage = 200): array
    {
        $this->findOrFail($id);

        $perPage = max(1, $perPage);
        $offset  = max(0, ($page - 1) * $perPage);

        $total = (int) (Database::scalar(
            'SELECT COUNT(*) FROM statutory_remittance_items WHERE remittance_id = :remittance_id',
            ['remittance_id' => $id]
        ) ?? 0);

        $items = Database::select(
            "SELECT * FROM statutory_remittance_items
              WHERE remittance_id = :remittance_id
              ORDER BY employee_number ASC, code ASC
              LIMIT {$perPage} OFFSET {$offset}",
            ['remittance_id' => $id]
        );

        foreach ($items as &$item) {
            $item['credited_base']           = (float) $item['credited_base'];
            $item['monthly_employee_amount'] = (float) $item['monthly_employee_amount'];
            $item['monthly_employer_amount'] = (float) $item['monthly_employer_amount'];
            $item['employee_amount']         = (float) $item['employee_amount'];
            $item['employer_amount']         = (float) $item['employer_amount'];
            $item['extra_amount']            = (float) $item['extra_amount'];
        }
        unset($item);

        return ['items' => $items, 'total' => $total];
    }

    /** Cast the numeric columns the way the pages expect them. */
    public static function present(array $row): array
    {
        $row['employee_count'] = (int) $row['employee_count'];
        foreach (['total_employee', 'total_employer', 'total_extra', 'total_amount'] as $column) {
            $row[$column] = (float) $row[$column];
        }

        return $row;
    }

    /**
     * The contribution rows a remittance would be built from: locked periods
     * whose window sits fully inside the requested range.
     *
     * @param list<string> $codes payroll_statutory codes of the agency
     * @return list<array<string, mixed>>
     */
    private function sourceRows(array $codes, string $start, string $end): array
    {
        $codePlaceholders = [];
        $params           = ['period_start' => $start, 'period_end' => $end];

        foreach (array_values($codes) as $index => $code) {
            $key                = 'code_' . $index;
            $codePlaceholders[] = ':' . $key;
            $params[$key]       = $code;
        }

        $lockedIn = implode(', ', array_map(
            static fn (string $status): string => "'" . $status . "'",
            self::LOCKED_STATUSES
        ));

        $rows = Database::select(
            "SELECT ps.id AS statutory_id, ps.code, ps.name AS line_name,
                    ps.schedule_source, ps.salary_base, ps.credited_base,
                    ps.employee_rate, ps.employer_rate,
                    ps.monthly_employee_amount, ps.monthly_employer_amount,
                    ps.employee_amount, ps.employer_amount, ps.extra_amount,
                    p.id AS payroll_id, p.employee_id,
                    pp.id AS period_id, pp.start_date AS period_start, pp.end_date AS period_end,
                    e.employee_number, e.first_name, e.middle_name, e.last_name, e.suffix
               FROM payroll_statutory ps
               JOIN payroll p ON p.id = ps.payroll_id
               JOIN payroll_periods pp ON pp.id = p.payroll_period_id
               LEFT JOIN employees e ON e.id = p.employee_id
              WHERE pp.deleted_at IS NULL
                AND pp.status IN ({$lockedIn})
                AND pp.start_date >= :period_start
                AND pp.end_date <= :period_end
                AND ps.code IN (" . implode(', ', $codePlaceholders) . ')
              ORDER BY pp.start_date ASC, pp.end_date ASC, e.employee_number ASC, ps.code ASC',
            $params
        );

        foreach ($rows as &$row) {
            // The snapshot stores one display name (the payslip convention).
            $row['employee_name'] = trim(implode(' ', array_filter([
                $row['first_name'],
                $row['middle_name'],
                $row['last_name'],
                $row['suffix'],
            ], static fn (mixed $part): bool => $part !== null && trim((string) $part) !== '')));

            unset($row['first_name'], $row['middle_name'], $row['last_name'], $row['suffix']);
        }
        unset($row);

        return $rows;
    }

    /** Raw header row or a RuntimeException the controller turns into a 404. */
    private function findOrFail(int $id): array
    {
        $row = Database::selectOne('SELECT * FROM statutory_remittances WHERE id = :id', ['id' => $id]);

        if ($row === null) {
            throw new RuntimeException('Statutory remittance not found.');
        }

        return $row;
    }

    private function requireItems(int $id): void
    {
        $count = (int) (Database::scalar(
            'SELECT COUNT(*) FROM statutory_remittance_items WHERE remittance_id = :remittance_id',
            ['remittance_id' => $id]
        ) ?? 0);

        if ($count === 0) {
            throw new ValidationException([
                'items' => 'This remittance has no contribution records — regenerate it before filing or confirming payment.',
            ]);
        }
    }

    private function referenceFor(int $id): string
    {
        return (string) (Database::scalar(
            'SELECT reference_no FROM statutory_remittances WHERE id = :id',
            ['id' => $id]
        ) ?? '#');
    }

    /** RMT-YYYYMMDD-XXXXXX, retried on the (astronomically unlikely) clash. */
    private function newReference(): string
    {
        for ($attempt = 0; $attempt < 10; $attempt++) {
            $reference = 'RMT-' . date('Ymd') . '-' . strtoupper(bin2hex(random_bytes(3)));

            $taken = Database::scalar(
                'SELECT COUNT(*) FROM statutory_remittances WHERE reference_no = :reference_no',
                ['reference_no' => $reference]
            );

            if ((int) $taken === 0) {
                return $reference;
            }
        }

        throw new RuntimeException('Unable to allocate a remittance reference number.');
    }

    /** Strict calendar date: rejects 2026-02-31 style near-misses too. */
    private static function strictDate(string $value, string $field): DateTimeImmutable
    {
        $date = DateTimeImmutable::createFromFormat('!Y-m-d', $value);
        if (!$date || $date->format('Y-m-d') !== $value) {
            throw new ValidationException([
                $field => 'The ' . str_replace('_', ' ', $field) . ' must be a valid date (YYYY-MM-DD).',
            ]);
        }

        return $date;
    }
}