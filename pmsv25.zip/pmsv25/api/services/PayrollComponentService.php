<?php
/**
 * Allowance & deduction master data and employee assignments (Phase 4).
 *
 * Allowances and deductions are the same shape of thing: a *master* template
 * (code, name, amount, how the amount is read, when it applies) and an
 * *assignment* of that template to an employee (with an optional amount
 * override, an optional effective window, a reason and notes). The payroll
 * engine reads the assignments, never the masters.
 *
 * Everything the two modules share lives here; AllowanceService and
 * DeductionService only state their table names, their category vocabulary and
 * the couple of rules that differ (allowances carry is_taxable, deductions
 * reserve the statutory codes the contribution engine computes for itself).
 *
 * Backward compatibility is the constraint every default here satisfies: a row
 * written before this module existed reads as a FIXED, RECURRING component,
 * charged in full in every pay period, with no date bound - exactly how the
 * engine treated it before.
 */

declare(strict_types=1);

namespace App\Services;

use App\Core\AuditLogger;
use App\Core\Database;
use App\Core\Settings;
use App\Core\ValidationException;
use RuntimeException;

abstract class PayrollComponentService
{
    /** Component masters (allowances / deductions). */
    protected const TABLE = '';

    /** Employee assignments of those masters. */
    protected const ASSIGNMENT_TABLE = '';

    /** The master id column on the assignment table. */
    protected const FOREIGN_KEY = '';

    /** Audit entity name, e.g. 'allowance'. */
    protected const ENTITY = '';

    /** Singular human label used in messages, e.g. 'Allowance'. */
    protected const LABEL = '';

    /** Allowed category vocabulary (value => label). */
    protected const CATEGORIES = [];

    /**
     * How a master's amount is read.
     *
     * PERIOD  the amount is charged in full on every pay period (the historic
     *         behaviour, and the default so nothing changes silently);
     * MONTHLY the amount is a monthly figure split across the pay periods of
     *         the month, exactly like a loan instalment.
     */
    public const FREQUENCIES = [
        'PERIOD'  => 'Every pay period',
        'MONTHLY' => 'Monthly (split across pay periods)',
    ];

    /** Whether the amount is a peso value or a percentage of monthly basic. */
    public const CALC_TYPES = [
        'FIXED'      => 'Fixed amount',
        'PERCENTAGE' => 'Percentage of monthly basic salary',
    ];

    /** Status filter values accepted by list(). */
    public const STATUSES = [
        ''      => 'All',
        '1'     => 'Active only',
        '0'     => 'Inactive only',
        'only'  => 'Archived only',
    ];

    // -----------------------------------------------------------------------
    // Options
    // -----------------------------------------------------------------------

    /** Vocabulary the pages build their pickers from, so nothing is hard-coded. */
    public function options(): array
    {
        return [
            'categories'      => $this->optionList(static::CATEGORIES),
            'frequencies'     => $this->optionList(self::FREQUENCIES),
            'calc_types'      => $this->optionList(self::CALC_TYPES),
            'statuses'        => $this->optionList(self::STATUSES),
            'reserved_codes'  => $this->reservedCodes(),
        ];
    }

    /**
     * @param array<string, string> $map
     * @return list<array{value: string, label: string}>
     */
    private function optionList(array $map): array
    {
        $out = [];
        foreach ($map as $value => $label) {
            $out[] = ['value' => (string) $value, 'label' => (string) $label];
        }

        return $out;
    }

    /**
     * Codes the statutory engine computes on its own. An assignment carrying
     * one is ignored by payroll while that engine is on, so the pages badge it
     * instead of pretending the amount here is charged.
     *
     * @return list<string>
     */
    protected function reservedCodes(): array
    {
        return [];
    }

    // -----------------------------------------------------------------------
    // Masters
    // -----------------------------------------------------------------------

    /**
     * @param array<string, mixed> $filters search, category, status, frequency
     * @return array{items: list<array<string, mixed>>, total: int}
     */
    public function list(array $filters, int $page = 1, int $perPage = 25): array
    {
        $table = static::TABLE;
        $map   = static::ASSIGNMENT_TABLE;
        $key   = static::FOREIGN_KEY;

        $where  = [];
        $params = [];

        $status = trim((string) ($filters['status'] ?? ''));

        if ($status === 'only') {
            $where[] = 'c.deleted_at IS NOT NULL';
        } else {
            $where[] = 'c.deleted_at IS NULL';
            if ($status === '1') {
                $where[] = 'c.is_active = 1';
            } elseif ($status === '0') {
                $where[] = 'c.is_active = 0';
            }
        }

        $category = strtoupper(trim((string) ($filters['category'] ?? '')));
        if ($category !== '' && isset(static::CATEGORIES[$category])) {
            $where[] = 'c.category = :category';
            $params['category'] = $category;
        }

        $frequency = strtoupper(trim((string) ($filters['frequency'] ?? '')));
        if ($frequency !== '' && isset(self::FREQUENCIES[$frequency])) {
            $where[] = 'c.frequency = :frequency';
            $params['frequency'] = $frequency;
        }

        $recurrence = trim((string) ($filters['recurring'] ?? ''));
        if ($recurrence === '1' || $recurrence === '0') {
            $where[] = 'c.is_recurring = :recurring';
            $params['recurring'] = (int) $recurrence;
        }

        $search = trim((string) ($filters['search'] ?? ''));
        if ($search !== '') {
            // One placeholder per column: PDO refuses to reuse a named token
            // inside a single statement.
            $where[] = '(c.code LIKE :search_code OR c.name LIKE :search_name)';
            $params['search_code'] = '%' . $search . '%';
            $params['search_name'] = '%' . $search . '%';
        }

        $whereSql = implode(' AND ', $where);

        $total = (int) (Database::scalar(
            "SELECT COUNT(*) FROM `{$table}` c WHERE {$whereSql}",
            $params
        ) ?? 0);

        $perPage = max(1, $perPage);
        $offset  = max(0, ($page - 1) * $perPage);

        $rows = Database::select(
            "SELECT c.*, cu.username AS created_by_username, uu.username AS updated_by_username,
                    COALESCE(assigned.total, 0) AS assigned_count,
                    COALESCE(assigned.active_total, 0) AS active_assigned_count
               FROM `{$table}` c
               LEFT JOIN users cu ON cu.id = c.created_by
               LEFT JOIN users uu ON uu.id = c.updated_by
               LEFT JOIN (SELECT `{$key}` AS component_id,
                                 COUNT(*) AS total,
                                 SUM(CASE WHEN is_active = 1 AND deleted_at IS NULL THEN 1 ELSE 0 END) AS active_total
                            FROM `{$map}`
                           GROUP BY `{$key}`) assigned ON assigned.component_id = c.id
              WHERE {$whereSql}
              ORDER BY c.is_active DESC, c.name
              LIMIT {$perPage} OFFSET {$offset}",
            $params
        );

        return [
            'items' => array_map(fn (array $row): array => $this->present($row), $rows),
            'total' => $total,
        ];
    }

    /** One master, with its assignment counters, or null. */
    public function find(int $id): ?array
    {
        $table = static::TABLE;
        $map   = static::ASSIGNMENT_TABLE;
        $key   = static::FOREIGN_KEY;

        $row = Database::selectOne(
            "SELECT c.*, cu.username AS created_by_username, uu.username AS updated_by_username,
                    COALESCE(assigned.total, 0) AS assigned_count,
                    COALESCE(assigned.active_total, 0) AS active_assigned_count
               FROM `{$table}` c
               LEFT JOIN users cu ON cu.id = c.created_by
               LEFT JOIN users uu ON uu.id = c.updated_by
               LEFT JOIN (SELECT `{$key}` AS component_id,
                                 COUNT(*) AS total,
                                 SUM(CASE WHEN is_active = 1 AND deleted_at IS NULL THEN 1 ELSE 0 END) AS active_total
                            FROM `{$map}`
                           GROUP BY `{$key}`) assigned ON assigned.component_id = c.id
              WHERE c.id = :id",
            ['id' => $id]
        );

        return $row === null ? null : $this->present($row);
    }

    /** @param array<string, mixed> $data */
    public function create(array $data, ?int $userId = null): array
    {
        $payload              = $this->masterPayload($data, null);
        $payload['created_by'] = $userId;
        $payload['updated_by'] = $userId;

        if (!array_key_exists('is_active', $payload)) {
            $payload['is_active'] = 1;
        }

        $id = Database::insert(static::TABLE, $payload);

        AuditLogger::record(
            $this->auditAction(),
            static::ENTITY,
            $id,
            sprintf('Created %s "%s"', strtolower(static::LABEL), (string) $payload['name'])
        );

        return $this->find($id) ?? [];
    }

    /** @param array<string, mixed> $data */
    public function update(int $id, array $data, ?int $userId = null): array
    {
        $existing = $this->find($id);

        if ($existing === null) {
            throw new RuntimeException(static::LABEL . ' not found.');
        }

        $payload = $this->masterPayload($data, $existing);

        if ($payload !== []) {
            $payload['updated_by'] = $userId;
            Database::update(static::TABLE, $payload, ['id' => $id]);
            AuditLogger::recordChanges(
                $this->auditAction(),
                static::ENTITY,
                $id,
                $existing,
                array_merge($existing, $payload)
            );
        }

        return $this->find($id) ?? [];
    }

    /** Soft-delete a master. Assignments survive as history and stop charging. */
    public function archive(int $id, ?int $userId = null): array
    {
        $existing = $this->find($id);

        if ($existing === null) {
            throw new RuntimeException(static::LABEL . ' not found.');
        }

        Database::update(static::TABLE, [
            'deleted_at' => date('Y-m-d H:i:s'),
            'updated_by' => $userId,
        ], ['id' => $id]);

        AuditLogger::record(
            $this->auditAction(),
            static::ENTITY,
            $id,
            sprintf(
                'Archived %s "%s" (%d assignment(s) kept as history)',
                strtolower(static::LABEL),
                (string) $existing['name'],
                (int) ($existing['assigned_count'] ?? 0)
            ),
            ['deleted_at' => null],
            ['deleted_at' => date('Y-m-d H:i:s')]
        );

        return $this->find($id) ?? [];
    }

    /** Return an archived master to the active list. */
    public function restore(int $id, ?int $userId = null): array
    {
        $existing = $this->find($id);

        if ($existing === null || ($existing['deleted_at'] ?? null) === null) {
            throw new RuntimeException(static::LABEL . ' not found or is not archived.');
        }

        Database::update(static::TABLE, [
            'deleted_at' => null,
            'updated_by' => $userId,
        ], ['id' => $id]);

        AuditLogger::record(
            $this->auditAction(),
            static::ENTITY,
            $id,
            sprintf('Restored %s "%s"', strtolower(static::LABEL), (string) $existing['name']),
            ['deleted_at' => $existing['deleted_at']],
            ['deleted_at' => null]
        );

        return $this->find($id) ?? [];
    }

    /** Page-header counters for the components page. */
    public function summary(): array
    {
        $table = static::TABLE;
        $map   = static::ASSIGNMENT_TABLE;
        $key   = static::FOREIGN_KEY;

        return [
            'active_masters'    => (int) (Database::scalar(
                "SELECT COUNT(*) FROM `{$table}` WHERE deleted_at IS NULL AND is_active = 1"
            ) ?? 0),
            'archived_masters'  => (int) (Database::scalar(
                "SELECT COUNT(*) FROM `{$table}` WHERE deleted_at IS NOT NULL"
            ) ?? 0),
            'active_assignments' => (int) (Database::scalar(
                "SELECT COUNT(*) FROM `{$map}` a
                   JOIN `{$table}` c ON c.id = a.`{$key}`
                  WHERE a.is_active = 1 AND a.deleted_at IS NULL
                    AND c.is_active = 1 AND c.deleted_at IS NULL"
            ) ?? 0),
            'monthly_templates' => (int) (Database::scalar(
                "SELECT COUNT(*) FROM `{$table}`
                  WHERE deleted_at IS NULL AND is_active = 1 AND frequency = 'MONTHLY'"
            ) ?? 0),
        ];
    }

    // -----------------------------------------------------------------------
    // Employee assignments
    // -----------------------------------------------------------------------

    /** Every assignment of this component, employee details included. */
    public function assignedEmployees(int $componentId): array
    {
        $map = static::ASSIGNMENT_TABLE;
        $key = static::FOREIGN_KEY;

        $rows = Database::select(
            "SELECT a.*, e.employee_number, e.first_name, e.middle_name, e.last_name, e.suffix,
                    e.department_id, d.name AS department_name
               FROM `{$map}` a
               JOIN employees e ON e.id = a.employee_id
               LEFT JOIN departments d ON d.id = e.department_id
              WHERE a.`{$key}` = :cid
              ORDER BY a.deleted_at IS NOT NULL, e.last_name, e.first_name",
            ['cid' => $componentId]
        );

        return array_map(fn (array $row): array => $this->presentAssignment($row), $rows);
    }

    /** Every component of this kind assigned to one employee (history included). */
    public function employeeAssignments(int $employeeId): array
    {
        $table = static::TABLE;
        $map   = static::ASSIGNMENT_TABLE;
        $key   = static::FOREIGN_KEY;

        $rows = Database::select(
            "SELECT a.*, c.code AS component_code, c.name AS component_name,
                    c.is_active AS component_is_active, c.deleted_at AS component_deleted_at,
                    c.frequency AS component_frequency, c.is_percentage AS component_is_percentage,
                    c.is_recurring AS component_is_recurring, c.amount AS component_amount,
                    c.effective_from AS component_effective_from, c.effective_to AS component_effective_to
               FROM `{$map}` a
               JOIN `{$table}` c ON c.id = a.`{$key}`
              WHERE a.employee_id = :emp
              ORDER BY a.deleted_at IS NOT NULL, c.name",
            ['emp' => $employeeId]
        );

        return array_map(fn (array $row): array => $this->presentAssignment($row), $rows);
    }

    /**
     * Assign a component to an employee.
     *
     * The (employee, component) pair is unique, so an assignment that was
     * un-assigned earlier is revived rather than duplicated: the amount, the
     * window, the reason and the notes are overwritten and the history of that
     * one row is kept.
     *
     * @param array<string, mixed> $data
     */
    public function assign(int $employeeId, array $data, ?int $userId = null): array
    {
        $this->assertEmployee($employeeId);

        $key         = static::FOREIGN_KEY;
        $componentId = (int) ($data[$key] ?? $data['component_id'] ?? 0);
        $master      = $this->find($componentId);

        if ($master === null) {
            throw new ValidationException([$key => 'The selected ' . strtolower(static::LABEL) . ' does not exist.']);
        }

        if (($master['deleted_at'] ?? null) !== null) {
            throw new ValidationException([$key => 'That ' . strtolower(static::LABEL) . ' is archived. Restore it before assigning it.']);
        }

        $existing = Database::selectOne(
            "SELECT * FROM `" . static::ASSIGNMENT_TABLE . "` WHERE employee_id = :emp AND `{$key}` = :cid",
            ['emp' => $employeeId, 'cid' => $componentId]
        );

        if ($existing !== null && ($existing['deleted_at'] ?? null) === null) {
            throw new ValidationException([
                $key => 'That ' . strtolower(static::LABEL) . ' is already assigned to this employee. Edit the assignment instead.',
            ]);
        }

        $payload = $this->assignmentPayload($data, $master, null, $employeeId);

        if ($existing !== null) {
            $payload['deleted_at'] = null;
            $payload['updated_by'] = $userId;

            if (!array_key_exists('is_active', $payload)) {
                $payload['is_active'] = 1;
            }

            Database::update(static::ASSIGNMENT_TABLE, $payload, ['id' => (int) $existing['id']]);

            AuditLogger::record(
                $this->auditAction(),
                static::ENTITY . '_assignment',
                (int) $existing['id'],
                sprintf('Re-assigned %s "%s" to employee #%d', strtolower(static::LABEL), (string) $master['name'], $employeeId),
                ['deleted_at' => $existing['deleted_at']],
                ['deleted_at' => null]
            );

            return $this->findAssignment($employeeId, (int) $existing['id']) ?? [];
        }

        $payload['employee_id'] = $employeeId;
        $payload[$key]          = $componentId;
        $payload['created_by']  = $userId;
        $payload['updated_by']  = $userId;

        if (!array_key_exists('is_active', $payload)) {
            $payload['is_active'] = 1;
        }

        $id = Database::insert(static::ASSIGNMENT_TABLE, $payload);

        AuditLogger::record(
            $this->auditAction(),
            static::ENTITY . '_assignment',
            $id,
            sprintf('Assigned %s "%s" to employee #%d', strtolower(static::LABEL), (string) $master['name'], $employeeId)
        );

        return $this->findAssignment($employeeId, $id) ?? [];
    }

    /** @param array<string, mixed> $data */
    public function updateAssignment(int $employeeId, int $assignmentId, array $data, ?int $userId = null): array
    {
        $existing = $this->findAssignment($employeeId, $assignmentId, true);

        if ($existing === null) {
            throw new RuntimeException('Assignment not found.');
        }

        if (($existing['deleted_at'] ?? null) !== null) {
            throw new RuntimeException('That assignment has been removed. Assign the ' . strtolower(static::LABEL) . ' again to change it.');
        }

        $key = static::FOREIGN_KEY;

        // Moving an assignment to a different master would rewrite history;
        // un-assign it and assign the other one instead.
        if (array_key_exists($key, $data) && (int) $data[$key] !== (int) $existing[$key]) {
            throw new ValidationException([$key => 'Un-assign this ' . strtolower(static::LABEL) . ' and assign the other one to change it.']);
        }

        $master  = $this->find((int) $existing[$key]);
        $payload = $this->assignmentPayload($data, $master ?? [], $existing, $employeeId);

        if ($payload !== []) {
            $payload['updated_by'] = $userId;
            Database::update(static::ASSIGNMENT_TABLE, $payload, ['id' => $assignmentId]);
            AuditLogger::recordChanges(
                $this->auditAction(),
                static::ENTITY . '_assignment',
                $assignmentId,
                $existing,
                array_merge($existing, $payload)
            );
        }

        return $this->findAssignment($employeeId, $assignmentId) ?? [];
    }

    /** Un-assign: soft delete, so the history of the assignment survives. */
    public function unassign(int $employeeId, int $assignmentId, ?int $userId = null): array
    {
        $existing = $this->findAssignment($employeeId, $assignmentId, true);

        if ($existing === null) {
            throw new RuntimeException('Assignment not found.');
        }

        if (($existing['deleted_at'] ?? null) !== null) {
            throw new RuntimeException('That assignment has already been removed.');
        }

        Database::update(static::ASSIGNMENT_TABLE, [
            'deleted_at' => date('Y-m-d H:i:s'),
            'updated_by' => $userId,
        ], ['id' => $assignmentId]);

        AuditLogger::record(
            $this->auditAction(),
            static::ENTITY . '_assignment',
            $assignmentId,
            sprintf(
                'Removed %s "%s" from employee #%d',
                strtolower(static::LABEL),
                (string) ($existing['component_name'] ?? $existing['name'] ?? ''),
                $employeeId
            ),
            ['deleted_at' => null],
            ['deleted_at' => date('Y-m-d H:i:s')]
        );

        return $this->findAssignment($employeeId, $assignmentId, true) ?? [];
    }

    /** One assignment, scoped to its employee so a crafted id cannot leak. */
    public function findAssignment(int $employeeId, int $assignmentId, bool $withHistory = false): ?array
    {
        $table = static::TABLE;
        $map   = static::ASSIGNMENT_TABLE;
        $key   = static::FOREIGN_KEY;

        $row = Database::selectOne(
            "SELECT a.*, c.code AS component_code, c.name AS component_name,
                    c.is_active AS component_is_active, c.deleted_at AS component_deleted_at,
                    c.frequency AS component_frequency, c.is_percentage AS component_is_percentage,
                    c.is_recurring AS component_is_recurring, c.amount AS component_amount,
                    c.effective_from AS component_effective_from, c.effective_to AS component_effective_to
               FROM `{$map}` a
               JOIN `{$table}` c ON c.id = a.`{$key}`
              WHERE a.id = :id AND a.employee_id = :emp",
            ['id' => $assignmentId, 'emp' => $employeeId]
        );

        if ($row === null) {
            return null;
        }

        if (!$withHistory && ($row['deleted_at'] ?? null) !== null) {
            return null;
        }

        return $this->presentAssignment($row);
    }

    // -----------------------------------------------------------------------
    // Validation
    // -----------------------------------------------------------------------

    /**
     * Build the column set for a master insert/update, rejecting anything the
     * columns cannot hold. Values not supplied on an update are left alone.
     *
     * @param array<string, mixed> $data
     * @param array<string, mixed>|null $existing
     * @return array<string, mixed>
     */
    private function masterPayload(array $data, ?array $existing): array
    {
        $isUpdate = $existing !== null;
        $payload  = [];

        if (!$isUpdate || array_key_exists('code', $data)) {
            $code = strtoupper(trim((string) ($data['code'] ?? '')));

            if ($code === '' && !$isUpdate) {
                $code = $this->deriveCode((string) ($data['name'] ?? ''));
            }

            if ($code === '') {
                throw new ValidationException(['code' => 'A code is required.']);
            }

            if (preg_match('/^[A-Z0-9][A-Z0-9_.-]{0,49}$/', $code) !== 1) {
                throw new ValidationException([
                    'code' => 'Use up to 50 letters, digits, dots, dashes or underscores, starting with a letter or digit.',
                ]);
            }

            $sql    = 'SELECT id FROM `' . static::TABLE . '` WHERE code = :code AND deleted_at IS NULL';
            $params = ['code' => $code];

            if ($isUpdate) {
                $sql .= ' AND id != :id';
                $params['id'] = (int) $existing['id'];
            }

            if (Database::scalar($sql, $params) !== null) {
                throw new ValidationException(['code' => 'That code is already in use.']);
            }

            $payload['code'] = $code;
        }

        if (!$isUpdate || array_key_exists('name', $data)) {
            $name = trim((string) ($data['name'] ?? ''));

            if ($name === '') {
                throw new ValidationException(['name' => 'A name is required.']);
            }

            if (mb_strlen($name) > 150) {
                throw new ValidationException(['name' => 'The name may not be longer than 150 characters.']);
            }

            $payload['name'] = $name;
        }

        if (!$isUpdate || array_key_exists('amount', $data)) {
            $raw = $data['amount'] ?? 0;

            if (!is_numeric($raw)) {
                throw new ValidationException(['amount' => 'The amount must be a number.']);
            }

            $amount = round((float) $raw, 2);

            if ($amount < 0) {
                throw new ValidationException(['amount' => 'The amount cannot be negative.']);
            }

            $payload['amount'] = $amount;
        }

        foreach (['is_taxable'] as $flag) {
            if (array_key_exists($flag, $data)) {
                $payload[$flag] = $this->asBool($data[$flag]) ? 1 : 0;
            }
        }

        if (array_key_exists('is_percentage', $data)) {
            $payload['is_percentage'] = $this->asBool($data['is_percentage']) ? 1 : 0;
        } elseif (!$isUpdate) {
            $payload['is_percentage'] = 0;
        }

        if (array_key_exists('is_recurring', $data)) {
            $payload['is_recurring'] = $this->asBool($data['is_recurring']) ? 1 : 0;
        } elseif (!$isUpdate) {
            $payload['is_recurring'] = 1;
        }

        if (array_key_exists('frequency', $data)) {
            $payload['frequency'] = $this->normaliseFrequency($data['frequency']);
        } elseif (!$isUpdate) {
            $payload['frequency'] = 'PERIOD';
        }

        if (array_key_exists('category', $data)) {
            $payload['category'] = $this->normaliseCategory($data['category']);
        }

        if (array_key_exists('effective_from', $data)) {
            $payload['effective_from'] = $this->normaliseDate($data['effective_from'], 'effective_from');
        }

        if (array_key_exists('effective_to', $data)) {
            $payload['effective_to'] = $this->normaliseDate($data['effective_to'], 'effective_to');
        }

        if (array_key_exists('description', $data)) {
            $description = trim((string) $data['description']);

            if (mb_strlen($description) > 255) {
                throw new ValidationException(['description' => 'The description may not be longer than 255 characters.']);
            }

            $payload['description'] = $description !== '' ? $description : null;
        }

        if (array_key_exists('is_active', $data)) {
            $payload['is_active'] = $this->asBool($data['is_active']) ? 1 : 0;
        }

        // ----- cross-field rules ------------------------------------------
        $effective    = array_merge($existing ?? [], $payload);
        $isPercentage = (int) ($effective['is_percentage'] ?? 0) === 1;
        $isRecurring  = (int) ($effective['is_recurring'] ?? 1) === 1;
        $frequency    = (string) ($effective['frequency'] ?? 'PERIOD');
        $from         = $effective['effective_from'] ?? null;
        $to           = $effective['effective_to'] ?? null;
        $amount       = (float) ($effective['amount'] ?? 0.0);

        if ($isPercentage) {
            if ($amount > 100.0) {
                throw new ValidationException(['amount' => 'A percentage cannot be higher than 100.']);
            }

            // A percentage is naturally a monthly figure: charging it in full
            // on both halves of a month would double it. The rule is applied
            // rather than merely reported so an install that already carries a
            // percentage master (the seeded TAX row) cannot drift out of it.
            if ($frequency !== 'MONTHLY') {
                $payload['frequency'] = 'MONTHLY';
                $frequency            = 'MONTHLY';
            }

            if (!$isRecurring) {
                $payload['is_recurring'] = 1;
                $isRecurring             = true;
            }
        }

        if (!$isRecurring && $from === null) {
            throw new ValidationException([
                'effective_from' => 'A one-time component needs the date it applies on.',
            ]);
        }

        if ($from !== null && $to !== null && $to < $from) {
            throw new ValidationException([
                'effective_to' => 'The end date cannot be earlier than the start date.',
            ]);
        }

        return $payload;
    }

    /**
     * Build the column set for an assignment insert/update.
     *
     * @param array<string, mixed> $data
     * @param array<string, mixed> $master
     * @param array<string, mixed>|null $existing
     * @return array<string, mixed>
     */
    private function assignmentPayload(array $data, array $master, ?array $existing, int $employeeId): array
    {
        $isUpdate = $existing !== null;
        $payload  = [];

        if (!$isUpdate || array_key_exists('amount', $data)) {
            $raw = $data['amount'] ?? 0;

            if (!is_numeric($raw)) {
                throw new ValidationException(['amount' => 'The amount must be a number.']);
            }

            $amount = round((float) $raw, 2);

            if ($amount < 0) {
                throw new ValidationException(['amount' => 'The amount cannot be negative.']);
            }

            if ((int) ($master['is_percentage'] ?? 0) === 1 && $amount > 100.0) {
                throw new ValidationException([
                    'amount' => 'This ' . strtolower(static::LABEL) . ' is a percentage, so the amount cannot be higher than 100.',
                ]);
            }

            $payload['amount'] = $amount;
        } elseif (!$isUpdate) {
            $payload['amount'] = 0.0;
        }

        if (array_key_exists('effective_from', $data)) {
            $payload['effective_from'] = $this->normaliseDate($data['effective_from'], 'effective_from');
        } elseif (!$isUpdate) {
            $payload['effective_from'] = null;
        }

        if (array_key_exists('effective_to', $data)) {
            $payload['effective_to'] = $this->normaliseDate($data['effective_to'], 'effective_to');
        } elseif (!$isUpdate) {
            $payload['effective_to'] = null;
        }

        if (array_key_exists('reason', $data)) {
            $payload['reason'] = $this->normaliseText($data['reason'], 'reason', 255);
        }

        if (array_key_exists('notes', $data)) {
            $payload['notes'] = $this->normaliseText($data['notes'], 'notes', 500);
        }

        if (array_key_exists('is_active', $data)) {
            $payload['is_active'] = $this->asBool($data['is_active']) ? 1 : 0;
        }

        // ----- cross-field rules ------------------------------------------
        $effective = array_merge($existing ?? [], $payload);
        $from      = $effective['effective_from'] ?? null;
        $to        = $effective['effective_to'] ?? null;

        if ($from !== null && $to !== null && $to < $from) {
            throw new ValidationException([
                'effective_to' => 'The end date cannot be earlier than the start date.',
            ]);
        }

        // A one-time component must be dated somewhere: either on the
        // assignment or on the master it comes from.
        $oneTime = (int) ($master['is_recurring'] ?? 1) === 0;

        if ($oneTime && $from === null && ($master['effective_from'] ?? null) === null) {
            throw new ValidationException([
                'effective_from' => 'This is a one-time ' . strtolower(static::LABEL) . ', so the assignment needs the date it applies on.',
            ]);
        }

        if ($isUpdate) {
            // Nothing links the change back to the employee otherwise; the
            // column is already set and must not be rewritten by an update.
            unset($payload['employee_id']);
        } elseif ($employeeId <= 0) {
            throw new ValidationException(['employee_id' => 'A valid employee is required.']);
        }

        return $payload;
    }

    // -----------------------------------------------------------------------
    // Presentation helpers
    // -----------------------------------------------------------------------

    /** Cast one master row for the API (money to float, flags to int, etc.). */
    protected function present(array $row): array
    {
        $row['id']             = (int) $row['id'];
        $row['amount']         = round((float) $row['amount'], 2);
        $row['is_active']      = (int) $row['is_active'];
        $row['assigned_count'] = (int) ($row['assigned_count'] ?? 0);
        $row['active_assigned_count'] = (int) ($row['active_assigned_count'] ?? 0);

        if (array_key_exists('is_percentage', $row)) {
            $row['is_percentage'] = (int) $row['is_percentage'];
        }

        if (array_key_exists('is_taxable', $row)) {
            $row['is_taxable'] = (int) $row['is_taxable'];
        }

        if (array_key_exists('is_recurring', $row)) {
            $row['is_recurring'] = (int) $row['is_recurring'];
        }

        $row['is_archived']        = ($row['deleted_at'] ?? null) !== null;
        $row['statutory_reserved'] = $this->isReserved((string) ($row['code'] ?? ''));

        return $row;
    }

    /** Cast one assignment row for the API. */
    protected function presentAssignment(array $row): array
    {
        $row['id']          = (int) $row['id'];
        $row['employee_id'] = (int) $row['employee_id'];
        $row['amount']      = round((float) $row['amount'], 2);
        $row['is_active']   = (int) $row['is_active'];
        $row['is_removed']  = ($row['deleted_at'] ?? null) !== null;
        $row['is_effective'] = $this->isEffective($row);

        foreach (['component_is_active', 'component_is_percentage', 'component_is_recurring'] as $flag) {
            if (array_key_exists($flag, $row)) {
                $row[$flag] = (int) $row[$flag];
            }
        }

        if (array_key_exists('component_amount', $row)) {
            $row['component_amount'] = round((float) $row['component_amount'], 2);
        }

        if (array_key_exists('employee_number', $row)) {
            $row['employee_name'] = trim(sprintf(
                '%s %s %s %s',
                (string) ($row['first_name'] ?? ''),
                (string) ($row['middle_name'] ?? ''),
                (string) ($row['last_name'] ?? ''),
                (string) ($row['suffix'] ?? '')
            ));
        }

        return $row;
    }

    /** Whether the statutory engine, not this assignment, computes the money. */
    protected function isReserved(string $code): bool
    {
        return in_array(strtoupper($code), $this->reservedCodes(), true);
    }

    /** A component is effective today when every switch and window allows it. */
    private function isEffective(array $assignment): bool
    {
        if ((int) $assignment['is_active'] !== 1 || ($assignment['deleted_at'] ?? null) !== null) {
            return false;
        }

        if ((int) ($assignment['component_is_active'] ?? 1) !== 1
            || ($assignment['component_deleted_at'] ?? null) !== null) {
            return false;
        }

        $today = date('Y-m-d');
        $from  = $assignment['effective_from'] ?? null;
        $to    = $assignment['effective_to'] ?? null;

        if ($from !== null && $from > $today) {
            return false;
        }

        if ($to !== null && $to < $today) {
            return false;
        }

        // A one-time component with no start of its own needs the master's.
        if ((int) ($assignment['component_is_recurring'] ?? 1) === 0) {
            $anchor = $from ?? ($assignment['component_effective_from'] ?? null);

            if ($anchor === null || $anchor !== $today) {
                return false;
            }
        }

        return true;
    }

    // -----------------------------------------------------------------------
    // Small value helpers
    // -----------------------------------------------------------------------

    /** @param mixed $value */
    private function asBool(mixed $value): bool
    {
        if (is_bool($value)) {
            return $value;
        }

        if (is_string($value)) {
            return !in_array(strtolower(trim($value)), ['', '0', 'false', 'no', 'off'], true);
        }

        return (int) $value === 1;
    }

    /** @param mixed $value */
    private function normaliseFrequency(mixed $value): string
    {
        $frequency = strtoupper(trim((string) $value));

        if ($frequency === '') {
            return 'PERIOD';
        }

        if (!isset(self::FREQUENCIES[$frequency])) {
            throw new ValidationException([
                'frequency' => 'Choose ' . implode(' or ', array_keys(self::FREQUENCIES)) . '.',
            ]);
        }

        return $frequency;
    }

    /** @param mixed $value */
    private function normaliseCategory(mixed $value): ?string
    {
        $category = strtoupper(trim((string) $value));

        if ($category === '') {
            return null;
        }

        if (static::CATEGORIES !== [] && !isset(static::CATEGORIES[$category])) {
            throw new ValidationException([
                'category' => 'Choose a listed category.',
            ]);
        }

        return $category;
    }

    /** @param mixed $value */
    private function normaliseDate(mixed $value, string $field): ?string
    {
        if ($value === null) {
            return null;
        }

        $text = trim((string) $value);

        if ($text === '') {
            return null;
        }

        // Accept a full datetime as well, keeping the date part only.
        $date = substr($text, 0, 10);

        $parsed = \DateTimeImmutable::createFromFormat('!Y-m-d', $date);

        if ($parsed === false || $parsed->format('Y-m-d') !== $date) {
            throw new ValidationException([$field => 'Use the YYYY-MM-DD date format.']);
        }

        return $date;
    }

    /** @param mixed $value */
    private function normaliseText(mixed $value, string $field, int $max): ?string
    {
        $text = trim((string) $value);

        if (mb_strlen($text) > $max) {
            throw new ValidationException([$field => sprintf('Use at most %d characters.', $max)]);
        }

        return $text !== '' ? $text : null;
    }

    /** Invent a code from a name, the way the settings screens do. */
    private function deriveCode(string $name): string
    {
        $code = strtoupper((string) preg_replace('/[^A-Z0-9]+/i', '', $name));

        return substr($code, 0, 20);
    }

    /** The employee must exist and not be archived away. */
    private function assertEmployee(int $employeeId): void
    {
        if ($employeeId <= 0) {
            throw new ValidationException(['employee_id' => 'A valid employee is required.']);
        }

        $exists = Database::scalar(
            'SELECT id FROM employees WHERE id = :id AND deleted_at IS NULL',
            ['id' => $employeeId]
        );

        if ($exists === null) {
            throw new RuntimeException('Employee not found.');
        }
    }

    /**
     * The audit action this module records.
     *
     * Declared abstract rather than stored in a constant so each subclass names
     * its own AuditLogger constant and a typo fails immediately.
     */
    abstract protected function auditAction(): string;

    /** Whether the statutory engine is currently replacing these assignments. */
    protected function statutoryEnabled(): bool
    {
        return Settings::bool('statutory.enabled', true);
    }
}