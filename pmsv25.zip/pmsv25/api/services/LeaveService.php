<?php
/**
 * Leave management (Phase 10).
 *
 * Flow from the brief:
 *   Employee submits -> HR approves/rejects -> Balance updates
 *   -> Attendance recognises leave -> Payroll calculates the effect.
 *
 * Approving a request updates leave_balances and creates LEAVE attendance rows
 * in one transaction (development rule 7).
 */

declare(strict_types=1);

namespace App\Services;

use App\Core\AuditLogger;
use App\Core\Auth;
use App\Core\Database;
use App\Core\DemoStaffScope;
use App\Core\ValidationException;
use App\Core\Validator;
use DateTimeImmutable;
use RuntimeException;

final class LeaveService
{
    public function __construct(private AttendanceEngine $engine = new AttendanceEngine())
    {
    }

    /** @return array<string, string> */
    public static function rules(): array
    {
        return [
            'employee_id'   => 'required|integer',
            'leave_type_id' => 'required|integer',
            'start_date'    => 'required|date',
            'end_date'      => 'required|date|after_or_equal:start_date',
            'reason'        => 'required|string|min:3|max:500',
        ];
    }

    /**
     * Working days covered by a request, excluding rest days and holidays so
     * credits are never consumed for them.
     */
    public function countWorkingDays(int $employeeId, string $startDate, string $endDate): int
    {
        $days  = 0;
        $start = new DateTimeImmutable($startDate);
        $end   = new DateTimeImmutable($endDate);

        for ($date = $start; $date <= $end; $date = $date->modify('+1 day')) {
            $context = $this->engine->contextFor($employeeId, $date->format('Y-m-d'));

            if ($context['is_rest_day'] || $context['holiday'] !== null) {
                continue;
            }

            $days++;
        }

        return $days;
    }
    /**
     * Submit a leave request (Phase 10).
     *
     * @param array<string, mixed> $data
     * @return array<string, mixed>
     */
    public function create(array $data, ?int $userId = null): array
    {
        $validator = Validator::make($data, self::rules());
        if ($validator->fails()) {
            throw new ValidationException($validator->errors());
        }

        $validated   = $validator->validated();
        $employeeId  = (int) $validated['employee_id'];
        DemoStaffScope::assertDemoParticipant($employeeId);
        $leaveTypeId = (int) $validated['leave_type_id'];
        $startDate   = (string) $validated['start_date'];
        $endDate     = (string) $validated['end_date'];

        // An employee may only submit for themselves (rule 14).
        if (Auth::user() !== null
            && !Auth::hasAnyPermission(['leave.view', 'employees.update'])
            && Auth::employeeId() !== $employeeId) {
            throw new ValidationException(['employee_id' => 'You may only submit leave for yourself.']);
        }

        $employee = Database::selectOne(
            'SELECT id, status, archived_at FROM employees WHERE id = :id AND deleted_at IS NULL',
            ['id' => $employeeId]
        );

        if ($employee === null) {
            throw new ValidationException(['employee_id' => 'The selected employee does not exist.']);
        }

        if ($employee['status'] !== 'ACTIVE' || $employee['archived_at'] !== null) {
            throw new ValidationException(['employee_id' => 'Leave can only be requested by active employees.']);
        }

        $leaveType = Database::selectOne(
            'SELECT * FROM leave_types WHERE id = :id AND is_active = 1 AND deleted_at IS NULL',
            ['id' => $leaveTypeId]
        );

        if ($leaveType === null) {
            throw new ValidationException(['leave_type_id' => 'The selected leave type does not exist.']);
        }

        $days = $this->countWorkingDays($employeeId, $startDate, $endDate);

        if ($days <= 0) {
            throw new ValidationException(['start_date' => 'The selected range contains no working days.']);
        }

        // Configurable maximum consecutive days.
        if ($leaveType['max_consecutive_days'] !== null && $days > (int) $leaveType['max_consecutive_days']) {
            throw new ValidationException([
                'end_date' => sprintf(
                    '%s allows a maximum of %d consecutive working days.',
                    $leaveType['name'],
                    (int) $leaveType['max_consecutive_days']
                ),
            ]);
        }

        $attachmentPath = $data['attachment_path'] ?? null;
        if ($attachmentPath !== null && $attachmentPath !== '') {
            $path = (string) $attachmentPath;
            if (!preg_match('#^uploads/leave/[a-f0-9]{48}\.(?:pdf|jpg|png)$#', $path)
                || !is_file(dirname(__DIR__, 2) . '/storage/' . $path)) {
                throw new ValidationException(['attachment_path' => 'Upload a valid supporting document through the leave form.']);
            }
        }
        if ((int) $leaveType['requires_attachment'] === 1 && ($attachmentPath === null || $attachmentPath === '')) {
            throw new ValidationException([
                'attachment_path' => sprintf('%s requires an attachment.', $leaveType['name']),
            ]);
        }

        // Balance check (Phase 10).
        $year = (int) date('Y', strtotime($startDate));

        if ((float) $leaveType['default_days'] > 0
            && (int) $leaveType['allow_negative_balance'] !== 1) {
            $remaining = $this->remainingBalance($employeeId, $leaveTypeId, $year);

            if ($days > $remaining) {
                throw new ValidationException([
                    'start_date' => sprintf(
                        'Insufficient %s balance: %.2f day(s) available, %.2f requested.',
                        $leaveType['name'],
                        $remaining,
                        (float) $days
                    ),
                ]);
            }
        }

        // Overlapping pending or approved requests are rejected.
        $overlap = Database::scalar(
            "SELECT id FROM leave_requests
              WHERE employee_id = :emp
                AND status IN (:pending, :approved)
                AND deleted_at IS NULL
                AND NOT (end_date < :start OR start_date > :end)
              LIMIT 1",
            [
                'emp'      => $employeeId,
                'pending'  => 'PENDING',
                'approved' => 'APPROVED',
                'start'    => $startDate,
                'end'      => $endDate,
            ]
        );

        if ($overlap !== null) {
            throw new ValidationException([
                'start_date' => 'A leave request already exists that overlaps these dates.',
            ]);
        }

        $userId = $userId ?? Auth::id();

        return Database::transaction(
            fn (): array => $this->insertRequest($employeeId, $leaveTypeId, $startDate, $endDate, $days, $validated, $attachmentPath, $userId)
        );
    }
/** Insert the request and reserve the pending balance. */
    private function insertRequest(
        int $employeeId,
        int $leaveTypeId,
        string $startDate,
        string $endDate,
        int $days,
        array $validated,
        ?string $attachmentPath,
        int $userId
    ): array {
        $requestId = Database::insert('leave_requests', [
            'employee_id'     => $employeeId,
            'leave_type_id'   => $leaveTypeId,
            'start_date'      => $startDate,
            'end_date'        => $endDate,
            'days'            => $days,
            'reason'          => $validated['reason'],
            'attachment_path' => $attachmentPath,
            'status'          => 'PENDING',
        ]);

        // Pending days are reserved immediately so balances stay accurate.
        $this->adjustPendingBalance($employeeId, $leaveTypeId, (int) date('Y', strtotime($startDate)), (float) $days);

        AuditLogger::record(
            AuditLogger::LEAVE_CREATED,
            'leave_request',
            $requestId,
            sprintf(
                'Leave request submitted: %s from %s to %s (%.2f days)',
                $this->leaveTypeName($leaveTypeId),
                $startDate,
                $endDate,
                $days
            ),
            null,
            [
                'employee_id'   => $employeeId,
                'leave_type_id' => $leaveTypeId,
                'start_date'    => $startDate,
                'end_date'      => $endDate,
                'days'          => $days,
            ]
        );

        return $this->find($requestId);
    }
/**
     * Approve a leave request (Phase 10).
     *
     * Approves the request, moves pending days into used days, and creates
     * LEAVE attendance rows for every affected working day so attendance
     * automatically recognises the leave (rule 7).
     *
     * @return array<string, mixed>
     */
    public function approve(int $requestId, string $remarks = '', ?int $approverId = null): array
    {
        if (DemoStaffScope::enabled()) {
            $targetEmployee = Database::scalar('SELECT employee_id FROM leave_requests WHERE id=:id', ['id'=>$requestId]);
            if ($targetEmployee !== null) { DemoStaffScope::assertIncluded((int) $targetEmployee); }
        }
        $request = $this->find($requestId);

        if ($request === null) {
            throw new RuntimeException('Leave request not found.');
        }

        if (Auth::employeeId() !== null && (int)$request['employee_id'] === (int)Auth::employeeId()) {
            throw new ValidationException(['permission'=>'No employee may approve or reject their own leave request.']);
        }

        if ($request['status'] !== 'PENDING') {
            throw new RuntimeException(sprintf('Only pending requests can be approved (current status: %s).', $request['status']));
        }

        $employeeId  = (int) $request['employee_id'];
        $leaveTypeId = (int) $request['leave_type_id'];
        $year        = (int) date('Y', strtotime((string) $request['start_date']));
        $days        = (float) $request['days'];
        $approverId  = $approverId ?? Auth::id();

        return Database::transaction(function () use ($requestId, $employeeId, $leaveTypeId, $year, $days, $remarks, $approverId, $request): array {
            // Pending -> used.
            Database::execute(
                'UPDATE leave_balances
                    SET pending_days = GREATEST(pending_days - :pending_days, 0),
                        used_days = used_days + :used_days
                  WHERE employee_id = :emp AND leave_type_id = :type AND year = :year',
                [
                    'pending_days' => $days,
                    'used_days'    => $days,
                    'emp'          => $employeeId,
                    'type'         => $leaveTypeId,
                    'year'         => $year,
                ]
            );

            Database::update('leave_requests', [
                'status'           => 'APPROVED',
                'approver_id'      => $approverId,
                'approved_at'      => date('Y-m-d H:i:s'),
                'approver_remarks' => $remarks !== '' ? $remarks : null,
            ], ['id' => $requestId]);

            $this->markLeaveAttendance($requestId, $employeeId, (string) $request['start_date'], (string) $request['end_date']);

            AuditLogger::record(
                AuditLogger::LEAVE_APPROVED,
                'leave_request',
                $requestId,
                sprintf(
                    'Leave approved for employee %s: %s (%.2f days)',
                    $employeeId,
                    $this->leaveTypeName($leaveTypeId),
                    $days
                ),
                ['status' => 'PENDING'],
                ['status' => 'APPROVED', 'approver_id' => $approverId, 'remarks' => $remarks]
            );

            return $this->find($requestId);
        });
    }

    /**
     * Reject a pending leave request; reserved pending days are released.
     *
     * @return array<string, mixed>
     */
    public function reject(int $requestId, string $remarks = '', ?int $approverId = null): array
    {
        if (DemoStaffScope::enabled()) {
            $employeeId = Database::scalar('SELECT employee_id FROM leave_requests WHERE id=:id', ['id'=>$requestId]);
            if ($employeeId !== null) { DemoStaffScope::assertIncluded((int) $employeeId); }
        }
        $request = $this->find($requestId);

        if ($request === null) {
            throw new RuntimeException('Leave request not found.');
        }

        if (Auth::employeeId() !== null && (int)$request['employee_id'] === (int)Auth::employeeId()) {
            throw new ValidationException(['permission'=>'No employee may approve or reject their own leave request.']);
        }

        if ($request['status'] !== 'PENDING') {
            throw new RuntimeException(sprintf('Only pending requests can be rejected (current status: %s).', $request['status']));
        }

        $approverId = $approverId ?? Auth::id();

        return Database::transaction(function () use ($requestId, $request, $remarks, $approverId): array {
            Database::update('leave_requests', [
                'status'           => 'REJECTED',
                'approver_id'      => $approverId,
                'approved_at'      => date('Y-m-d H:i:s'),
                'approver_remarks' => $remarks !== '' ? $remarks : null,
            ], ['id' => $requestId]);

            // Release the reserved pending days.
            $this->adjustPendingBalance(
                (int) $request['employee_id'],
                (int) $request['leave_type_id'],
                (int) date('Y', strtotime((string) $request['start_date'])),
                -1 * (float) $request['days']
            );

            AuditLogger::record(
                AuditLogger::LEAVE_REJECTED,
                'leave_request',
                $requestId,
                sprintf(
                    'Leave rejected for employee %s: %s (%.2f days)',
                    $request['employee_id'],
                    $this->leaveTypeName((int) $request['leave_type_id']),
                    (float) $request['days']
                ),
                ['status' => 'PENDING'],
                ['status' => 'REJECTED', 'approver_id' => $approverId, 'remarks' => $remarks]
            );

            return $this->find($requestId);
        });
    }
/**
     * Cancel a request. Approved leave releases the used days back; a pending
     * request releases the reserved pending days (Phase 10).
     *
     * @return array<string, mixed>
     */
    public function cancel(int $requestId, string $remarks = '', ?int $userId = null): array
    {
        if (DemoStaffScope::enabled()) {
            $employeeId = Database::scalar('SELECT employee_id FROM leave_requests WHERE id=:id', ['id'=>$requestId]);
            if ($employeeId !== null) { DemoStaffScope::assertIncluded((int) $employeeId); }
        }
        $request = $this->find($requestId);

        if ($request === null) {
            throw new RuntimeException('Leave request not found.');
        }

        if (in_array($request['status'], ['REJECTED', 'CANCELLED'], true)) {
            throw new RuntimeException(sprintf('This request is already %s.', strtolower((string) $request['status'])));
        }

        // An employee may only cancel their own request.
        if (Auth::user() !== null
            && !Auth::hasAnyPermission(['leave.view', 'employees.update'])
            && Auth::employeeId() !== (int) $request['employee_id']) {
            throw new RuntimeException('You may only cancel your own leave requests.');
        }

        $userId = $userId ?? Auth::id();

        return Database::transaction(function () use ($requestId, $request, $remarks, $userId): array {
            $employeeId  = (int) $request['employee_id'];
            $leaveTypeId = (int) $request['leave_type_id'];
            $year        = (int) date('Y', strtotime((string) $request['start_date']));
            $days        = (float) $request['days'];

            if ($request['status'] === 'APPROVED') {
                // Give the credits back.
                Database::execute(
                    'UPDATE leave_balances SET used_days = GREATEST(used_days - :days, 0)
                      WHERE employee_id = :emp AND leave_type_id = :type AND year = :year',
                    ['days' => $days, 'emp' => $employeeId, 'type' => $leaveTypeId, 'year' => $year]
                );

                $this->removeLeaveAttendance($requestId, $employeeId, (string) $request['start_date'], (string) $request['end_date']);
            } else {
                $this->adjustPendingBalance($employeeId, $leaveTypeId, $year, -$days);
            }

            Database::update('leave_requests', [
                'status'           => 'CANCELLED',
                'cancelled_at'     => date('Y-m-d H:i:s'),
                'approver_remarks' => $remarks !== '' ? $remarks : null,
            ], ['id' => $requestId]);

            AuditLogger::record(
                AuditLogger::LEAVE_CANCELLED,
                'leave_request',
                $requestId,
                sprintf('Leave request cancelled (%.2f days)', $days),
                ['status' => $request['status']],
                ['status' => 'CANCELLED', 'cancelled_by' => $userId]
            );

            return $this->find($requestId);
        });
    }
/** @return array<string, mixed>|null */
    public function find(int $requestId): ?array
    {
        return Database::selectOne(
            'SELECT lr.*, lt.code AS leave_type_code, lt.name AS leave_type_name,
                    lt.is_paid AS leave_is_paid,
                    e.employee_number, e.first_name, e.middle_name, e.last_name, e.suffix,
                    e.department_id, d.name AS department_name,
                    u.username AS approver_username
               FROM leave_requests lr
               JOIN leave_types lt ON lt.id = lr.leave_type_id
               JOIN employees e ON e.id = lr.employee_id
               LEFT JOIN departments d ON d.id = e.department_id
               LEFT JOIN users u ON u.id = lr.approver_id
              WHERE lr.id = :id AND lr.deleted_at IS NULL
              LIMIT 1',
            ['id' => $requestId]
        );
    }
/**
     * Leave requests with filters (Phase 10 / Phase 17).
     *
     * @param array<string, mixed> $filters
     * @return array{items: list<array<string, mixed>>, total: int}
     */
    public function list(array $filters, int $page = 1, int $perPage = 25): array
    {
        $where  = ['1 = 1'];
        $params = [];

        $archiveMode = strtolower(trim((string) ($filters['archived'] ?? 'false')));
        if ($archiveMode === 'only') {
            $where[] = 'lr.deleted_at IS NOT NULL';
        } elseif (!filter_var($archiveMode, FILTER_VALIDATE_BOOLEAN)) {
            $where[] = 'lr.deleted_at IS NULL';
        }

        if (!empty($filters['manager_employee_id'])) {
            $where[] = '(e.assigned_supervisor_id = :team_manager_id OR (e.assigned_supervisor_id IS NULL AND e.department_id = :team_department_id))';
            $params['team_manager_id'] = (int)$filters['manager_employee_id'];
            $params['team_department_id'] = (int)$filters['manager_department_id'];
        }

        if (!empty($filters['employee_id'])) {
            $where[] = 'lr.employee_id = :employee_id';
            $params['employee_id'] = (int) $filters['employee_id'];
        }

        foreach (['status' => 'lr.status', 'leave_type_id' => 'lr.leave_type_id', 'department_id' => 'e.department_id'] as $key => $column) {
            if (!empty($filters[$key])) {
                $where[] = sprintf('%s = :%s', $column, $key);
                $params[$key] = in_array($key, ['leave_type_id', 'department_id'], true)
                    ? (int) $filters[$key]
                    : (string) $filters[$key];
            }
        }

        foreach (['date_from' => 'lr.start_date >= :date_from', 'date_to' => 'lr.end_date <= :date_to'] as $key => $clause) {
            if (!empty($filters[$key])) {
                $where[] = $clause;
                $params[$key] = (string) $filters[$key];
            }
        }

        $whereSql = implode(' AND ', $where);

        $total = (int) (Database::scalar(
            "SELECT COUNT(*) FROM leave_requests lr JOIN employees e ON e.id = lr.employee_id WHERE {$whereSql}",
            $params
        ) ?? 0);

        $perPage = max(1, $perPage);
        $offset  = max(0, ($page - 1) * $perPage);

        $items = Database::select(
            "SELECT lr.*, lt.code AS leave_type_code, lt.name AS leave_type_name, lt.is_paid AS leave_is_paid,
                    e.employee_number, e.first_name, e.middle_name, e.last_name, e.suffix,
                    d.name AS department_name, u.username AS approver_username
               FROM leave_requests lr
               JOIN leave_types lt ON lt.id = lr.leave_type_id
               JOIN employees e ON e.id = lr.employee_id
               LEFT JOIN departments d ON d.id = e.department_id
               LEFT JOIN users u ON u.id = lr.approver_id
              WHERE {$whereSql}
              ORDER BY lr.created_at DESC, lr.id DESC
              LIMIT {$perPage} OFFSET {$offset}",
            $params
        );

        foreach ($items as &$item) {
            $item['full_name'] = trim(implode(' ', array_filter([
                $item['first_name'], $item['middle_name'], $item['last_name'], $item['suffix'],
            ], static fn (mixed $v): bool => (string) $v !== '')));
        }
        unset($item);

        return ['items' => $items, 'total' => $total];
    }

    /** Pending count, used by the dashboard (Phase 16). */
    public function pendingCount(?int $employeeId = null): int
    {
        $params = [];
        $sql    = "SELECT COUNT(*) FROM leave_requests WHERE status = 'PENDING' AND deleted_at IS NULL";

        if ($employeeId !== null) {
            $sql .= ' AND employee_id = :emp';
            $params['emp'] = $employeeId;
        }

        return (int) (Database::scalar($sql, $params) ?? 0);
    }

    /** Organisation-wide balance summary for a year (Phase 17). */
    public function balanceSummary(?int $year = null): array
    {
        $year = $year ?? (int) date('Y');

        return Database::select(
            'SELECT lt.id, lt.code, lt.name, lt.is_paid,
                    COALESCE(SUM(lb.entitled_days), 0) AS entitled_days,
                    COALESCE(SUM(lb.used_days), 0) AS used_days,
                    COALESCE(SUM(lb.pending_days), 0) AS pending_days,
                    COALESCE(SUM(lb.entitled_days - lb.used_days - lb.pending_days), 0) AS remaining_days
               FROM leave_types lt
               LEFT JOIN leave_balances lb ON lb.leave_type_id = lt.id AND lb.year = :year
              WHERE lt.is_active = 1 AND lt.deleted_at IS NULL
              GROUP BY lt.id, lt.code, lt.name, lt.is_paid
              ORDER BY lt.name',
            ['year' => $year]
        );
    }

    /** Leave-category balances grouped by employee for the management popover. */
    public function employeeBalanceSummary(?int $employeeId = null, ?int $year = null): array
    {
        $year = $year ?? (int) date('Y');
        $params = ['year' => $year];
        $employeeWhere = '';

        if ($employeeId !== null) {
            $employeeWhere = ' AND e.id = :employee_id';
            $params['employee_id'] = $employeeId;
        }

        return Database::select(
            'SELECT e.id AS employee_id,
                    CONCAT_WS(\' \', e.first_name, e.middle_name, e.last_name, e.suffix) AS full_name,
                    d.name AS department_name,
                    lt.id AS leave_type_id, lt.name AS leave_type_name, lt.is_paid,
                    COALESCE(lb.entitled_days, lt.default_days) AS entitled_days,
                    COALESCE(lb.used_days, 0) AS used_days,
                    COALESCE(lb.pending_days, 0) AS pending_days,
                    COALESCE(lb.entitled_days - lb.used_days - lb.pending_days, lt.default_days) AS remaining_days
               FROM employees e
               CROSS JOIN leave_types lt
               LEFT JOIN departments d ON d.id = e.department_id
               LEFT JOIN leave_balances lb
                 ON lb.employee_id = e.id AND lb.leave_type_id = lt.id AND lb.year = :year
              WHERE e.deleted_at IS NULL AND e.archived_at IS NULL
                AND lt.is_active = 1 AND lt.deleted_at IS NULL' . $employeeWhere . '
              ORDER BY e.last_name, e.first_name, lt.name',
            $params
        );
    }

    /**
     * Edit a pending leave request (dates / type / reason).
     *
     * @param array<string, mixed> $data
     * @return array<string, mixed>
     */
    public function update(int $requestId, array $data, ?int $userId = null): array
    {
        $existing = $this->find($requestId);
        if ($existing === null) {
            throw new RuntimeException('Leave request not found.');
        }
        DemoStaffScope::assertDemoParticipant((int) $existing['employee_id']);
        if ($existing['status'] !== 'PENDING') {
            throw new RuntimeException('Only pending leave requests can be edited.');
        }
        if (Auth::roleCode() === 'MANAGER' && Auth::employeeId() !== (int)$existing['employee_id']) {
            throw new ValidationException(['permission'=>'A Manager can approve/reject assigned leave but cannot edit someone else’s request.']);
        }
        if (Auth::user() !== null
            && !Auth::hasAnyPermission(['leave.view', 'employees.update'])
            && Auth::employeeId() !== (int) $existing['employee_id']) {
            throw new RuntimeException('You may only edit your own leave requests.');
        }

        $validator = Validator::make($data, [
            'leave_type_id' => 'nullable|integer',
            'start_date' => 'nullable|date',
            'end_date' => 'nullable|date',
            'reason' => 'nullable|string|min:3|max:500',
        ]);
        if ($validator->fails()) {
            throw new ValidationException($validator->errors());
        }
        $fields = $validator->validated();

        $leaveTypeId = isset($fields['leave_type_id']) && $fields['leave_type_id'] !== '' && $fields['leave_type_id'] !== null
            ? (int) $fields['leave_type_id'] : (int) $existing['leave_type_id'];
        $startDate = isset($fields['start_date']) && $fields['start_date'] !== '' && $fields['start_date'] !== null
            ? (string) $fields['start_date'] : (string) $existing['start_date'];
        $endDate = isset($fields['end_date']) && $fields['end_date'] !== '' && $fields['end_date'] !== null
            ? (string) $fields['end_date'] : (string) $existing['end_date'];
        $reason = $fields['reason'] ?? $existing['reason'];

        if ($endDate < $startDate) {
            throw new ValidationException(['end_date' => 'End date must be on or after start date.']);
        }

        $employeeId = (int) $existing['employee_id'];
        $oldYear = (int) date('Y', strtotime((string) $existing['start_date']));
        $oldDays = (float) $existing['days'];
        $oldType = (int) $existing['leave_type_id'];
        $days = $this->countWorkingDays($employeeId, $startDate, $endDate);
        if ($days <= 0) {
            throw new ValidationException(['start_date' => 'The selected range contains no working days.']);
        }

        return Database::transaction(function () use ($requestId, $employeeId, $leaveTypeId, $startDate, $endDate, $days, $reason, $oldYear, $oldDays, $oldType, $existing): array {
            $newYear = (int) date('Y', strtotime($startDate));
            // Release old reservation, reserve new.
            $this->adjustPendingBalance($employeeId, $oldType, $oldYear, -$oldDays);
            $this->adjustPendingBalance($employeeId, $leaveTypeId, $newYear, (float) $days);

            Database::update('leave_requests', [
                'leave_type_id' => $leaveTypeId,
                'start_date' => $startDate,
                'end_date' => $endDate,
                'days' => $days,
                'reason' => $reason,
            ], ['id' => $requestId]);

            AuditLogger::recordChanges(
                AuditLogger::LEAVE_CREATED,
                'leave_request',
                $requestId,
                $existing,
                array_merge($existing, ['leave_type_id' => $leaveTypeId, 'start_date' => $startDate, 'end_date' => $endDate, 'days' => $days, 'reason' => $reason])
            );

            return $this->find($requestId);
        });
    }

    /** Archive any request (soft delete), approved ones included; purged only via Data deletion.
     *
     * Archiving is a list operation only: an approved request keeps its used
     * credits and is still honoured by payroll while archived. To undo the
     * approval (and refund the credits), cancel it first.
     */
    public function delete(int $requestId): array
    {
        if (DemoStaffScope::enabled()) {
            $employeeId = Database::scalar('SELECT employee_id FROM leave_requests WHERE id=:id', ['id'=>$requestId]);
            if ($employeeId !== null) { DemoStaffScope::assertIncluded((int) $employeeId); }
        }
        $existing = $this->find($requestId);
        if ($existing === null) {
            throw new RuntimeException('Leave request not found.');
        }
        if (Auth::user() !== null
            && !Auth::hasAnyPermission(['leave.view', 'employees.update'])
            && Auth::employeeId() !== (int) $existing['employee_id']) {
            throw new RuntimeException('You may only delete your own leave requests.');
        }
        if ((string) $existing['status'] === 'PENDING') {
            $this->adjustPendingBalance(
                (int) $existing['employee_id'],
                (int) $existing['leave_type_id'],
                (int) date('Y', strtotime((string) $existing['start_date'])),
                -1 * (float) $existing['days']
            );
        }
        Database::update('leave_requests', ['deleted_at' => date('Y-m-d H:i:s')], ['id' => $requestId]);
        AuditLogger::record(
            AuditLogger::LEAVE_CANCELLED,
            'leave_request',
            $requestId,
            sprintf('Removed leave request #%d (archived)', $requestId),
            $existing,
            null
        );
        return ['id' => $requestId];
    }

    /** Restore a removed leave request to its list. */
    public function restore(int $requestId): array
    {
        if (DemoStaffScope::enabled()) {
            $employeeId = Database::scalar('SELECT employee_id FROM leave_requests WHERE id=:id', ['id'=>$requestId]);
            if ($employeeId !== null) { DemoStaffScope::assertIncluded((int) $employeeId); }
        }
        $existing = Database::selectOne(
            'SELECT * FROM leave_requests WHERE id = :id AND deleted_at IS NOT NULL',
            ['id' => $requestId]
        );

        if ($existing === null) {
            throw new RuntimeException('Leave request not found or is not archived.');
        }

        Database::update('leave_requests', ['deleted_at' => null], ['id' => $requestId]);

        AuditLogger::record(
            AuditLogger::LEAVE_CREATED,
            'leave_request',
            $requestId,
            sprintf('Restored leave request #%d', $requestId),
            ['deleted_at' => $existing['deleted_at']],
            null
        );

        return $this->find($requestId);
    }

    /**
     * Adjust an employee's entitled days for a leave type and year.
     *
     * Lets approvers correct credits (e.g. carry-over, manual grants). The
     * change is audited; used/pending days are never rewritten.
     *
     * @return list<array<string, mixed>> the employee's refreshed balances
     */
    public function adjustBalance(
        int $employeeId,
        int $leaveTypeId,
        int $year,
        float $entitledDays,
        string $reason = '',
        ?int $userId = null
    ): array {
        $employee = Database::selectOne(
            'SELECT id, first_name, middle_name, last_name FROM employees
              WHERE id = :id AND deleted_at IS NULL AND archived_at IS NULL',
            ['id' => $employeeId]
        );

        if ($employee === null) {
            throw new ValidationException(['employee_id' => 'The selected employee does not exist or is not active.']);
        }

        $type = Database::selectOne(
            'SELECT id, name FROM leave_types WHERE id = :id AND is_active = 1 AND deleted_at IS NULL',
            ['id' => $leaveTypeId]
        );

        if ($type === null) {
            throw new ValidationException(['leave_type_id' => 'The selected leave type does not exist.']);
        }

        if ($year < 2000 || $year > 2100) {
            throw new ValidationException(['year' => 'Year is out of range.']);
        }

        if (!is_finite($entitledDays) || $entitledDays < 0 || $entitledDays > 365) {
            throw new ValidationException(['entitled_days' => 'Entitled days must be between 0 and 365.']);
        }

        $userId = $userId ?? Auth::id();
        $this->ensureBalanceRow($employeeId, $leaveTypeId, $year);

        $before = Database::selectOne(
            'SELECT entitled_days, used_days, pending_days FROM leave_balances
              WHERE employee_id = :emp AND leave_type_id = :type AND year = :year',
            ['emp' => $employeeId, 'type' => $leaveTypeId, 'year' => $year]
        );

        Database::update(
            'leave_balances',
            ['entitled_days' => round($entitledDays, 2)],
            ['employee_id' => $employeeId, 'leave_type_id' => $leaveTypeId, 'year' => $year]
        );

        AuditLogger::record(
            AuditLogger::LEAVE_CREATED,
            'leave_balance',
            $employeeId,
            sprintf(
                'Leave balance adjusted: %s set to %.2f days for %d%s',
                $type['name'],
                $entitledDays,
                $year,
                $reason !== '' ? ' (' . mb_substr($reason, 0, 120) . ')' : ''
            ),
            $before,
            array_merge((array) $before, ['entitled_days' => round($entitledDays, 2)])
        );

        return $this->employeeBalanceSummary($employeeId, $year);
    }

    /** @return list<array<string, mixed>> */
    public function leaveTypes(): array
    {
        return Database::select(
            'SELECT * FROM leave_types WHERE deleted_at IS NULL ORDER BY is_active DESC, name'
        );
    }
/** Release or reserve pending days by a signed amount. */
    private function adjustPendingBalance(int $employeeId, int $leaveTypeId, int $year, float $delta): void
    {
        // Ensure the row exists before adjusting it.
        $this->ensureBalanceRow($employeeId, $leaveTypeId, $year);

        if ($delta >= 0) {
            Database::execute(
                'UPDATE leave_balances SET pending_days = pending_days + :delta
                  WHERE employee_id = :emp AND leave_type_id = :type AND year = :year',
                ['delta' => $delta, 'emp' => $employeeId, 'type' => $leaveTypeId, 'year' => $year]
            );

            return;
        }

        Database::execute(
            'UPDATE leave_balances SET pending_days = GREATEST(pending_days + :delta, 0)
              WHERE employee_id = :emp AND leave_type_id = :type AND year = :year',
            ['delta' => $delta, 'emp' => $employeeId, 'type' => $leaveTypeId, 'year' => $year]
        );
    }

    private function ensureBalanceRow(int $employeeId, int $leaveTypeId, int $year): void
    {
        $entitled = (float) (Database::scalar(
            'SELECT COALESCE(default_days, 0) FROM leave_types WHERE id = :type',
            ['type' => $leaveTypeId]
        ) ?? 0);

        $existing = Database::scalar(
            'SELECT id FROM leave_balances
              WHERE employee_id = :emp AND leave_type_id = :type AND year = :year',
            ['emp' => $employeeId, 'type' => $leaveTypeId, 'year' => $year]
        );

        if ($existing === null) {
            Database::insert('leave_balances', [
                'employee_id'   => $employeeId,
                'leave_type_id' => $leaveTypeId,
                'year'          => $year,
                'entitled_days' => $entitled,
                'used_days'     => 0.00,
                'pending_days'  => 0.00,
            ]);
        }
    }

    private function remainingBalance(int $employeeId, int $leaveTypeId, int $year): float
    {
        $this->ensureBalanceRow($employeeId, $leaveTypeId, $year);

        $row = Database::selectOne(
            'SELECT entitled_days, used_days, pending_days FROM leave_balances
              WHERE employee_id = :emp AND leave_type_id = :type AND year = :year',
            ['emp' => $employeeId, 'type' => $leaveTypeId, 'year' => $year]
        );

        if ($row === null) {
            return 0.0;
        }

        return (float) $row['entitled_days'] - (float) $row['used_days'] - (float) $row['pending_days'];
    }

    private function leaveTypeName(int $leaveTypeId): string
    {
        return (string) (Database::scalar(
            'SELECT name FROM leave_types WHERE id = :type',
            ['type' => $leaveTypeId]
        ) ?? 'Leave');
    }

    /**
     * Create LEAVE attendance rows for a range so attendance recognises the
     * leave automatically (rule 7).
     */
    private function markLeaveAttendance(int $requestId, int $employeeId, string $startDate, string $endDate): void
    {
        $start = new DateTimeImmutable($startDate);
        $end   = new DateTimeImmutable($endDate);

        for ($date = $start; $date <= $end; $date = $date->modify('+1 day')) {
            $dateString = $date->format('Y-m-d');
            $context    = $this->engine->contextFor($employeeId, $dateString);

            // Rest days and holidays are already covered by their own status.
            if ($context['is_rest_day'] || $context['holiday'] !== null) {
                continue;
            }

            $existing = $this->engine->findAttendance($employeeId, $dateString);

            if ($existing === null) {
                $archived = Database::selectOne(
                    'SELECT id FROM attendance WHERE employee_id = :emp AND attendance_date = :date AND deleted_at IS NOT NULL LIMIT 1',
                    ['emp' => $employeeId, 'date' => $dateString]
                );
                if ($archived !== null) {
                    throw new RuntimeException(sprintf(
                        'The attendance record for %s is in archive. Restore it before approving this leave.',
                        $dateString
                    ));
                }

                Database::insert('attendance', [
                    'employee_id'      => $employeeId,
                    'attendance_date'  => $dateString,
                    'shift_id'         => $context['shift']['id'] ?? null,
                    'work_schedule_id' => $context['schedule_id'],
                    'scheduled_start'  => $context['shift'] !== null ? substr((string) $context['shift']['start_time'], 0, 8) : null,
                    'scheduled_end'    => $context['shift'] !== null ? substr((string) $context['shift']['end_time'], 0, 8) : null,
                    'status'           => 'LEAVE',
                    'is_rest_day'      => 0,
                    'is_holiday'       => 0,
                    'leave_request_id' => $requestId,
                    'source'           => 'AUTO',
                ]);
            } elseif ($existing['time_in'] === null && $existing['time_out'] === null) {
                Database::update('attendance', [
                    'status'           => 'LEAVE',
                    'leave_request_id' => $requestId,
                ], ['id' => (int) $existing['id']]);
            }
        }
    }

    /** Remove the LEAVE attendance rows created for a request. */
    private function removeLeaveAttendance(int $requestId, int $employeeId, string $startDate, string $endDate): void
    {
        $start = new DateTimeImmutable($startDate);
        $end   = new DateTimeImmutable($endDate);

        for ($date = $start; $date <= $end; $date = $date->modify('+1 day')) {
            $row = $this->engine->findAttendance($employeeId, $date->format('Y-m-d'));

            if ($row !== null
                && (int) $row['leave_request_id'] === $requestId
                && $row['time_in'] === null
                && $row['time_out'] === null) {
                Database::delete('attendance', ['id' => (int) $row['id']]);
            }
        }
    }
}
