<?php
/**
 * Overtime assignments (Manager assigned, HR authorized, verified QR work).
 *
 * Flow: Manager assigns -> HR authorizes before work -> QR OT scans
 * -> Manager confirms -> HR verifies actual payable minutes.
 * There is NO employee Accept/Decline gate. Assignment itself does not
 * override statutory limits on compulsory overtime (Labor Code Art. 89).
 * Historical ACCEPTED/DECLINED records are preserved for audit.
 */

declare(strict_types=1);

namespace App\Services;

use App\Core\AuditLogger;
use App\Core\Auth;
use App\Core\Database;
use App\Core\DemoStaffScope;
use App\Core\Settings;
use App\Core\ValidationException;
use App\Core\Validator;
use RuntimeException;

final class OvertimeService
{
    public function __construct(private AttendanceEngine $engine = new AttendanceEngine())
    {
    }

    /** @return array<string, string> */
    public static function rules(): array
    {
        return [
            'employee_id'   => 'nullable|integer',
            'employee_ids'  => 'nullable|array',
            'overtime_date' => 'required|date',
            'start_time'    => 'required|time',
            'end_time'      => 'required|time',
            'reason'        => 'required|string|min:3|max:500',
            'ot_type'       => 'nullable|in:REGULAR,REST_DAY,HOLIDAY,NIGHT',
        ];
    }

    /**
     * Backend guard: only Admin may announce/assign/edit/cancel OT.
     * Route-level `overtime.create` already rejects non-admins, but this
     * defence-in-depth check also blocks direct service use and any future
     * route that forgets the permission. Never rely on hidden buttons alone.
     */
    private function requireAdmin(string $message = 'Only managers may manage overtime assignments.'): void
    {
        $user = Auth::user();

        if ($user === null) {
            throw new ValidationException(['permission' => 'Authentication is required.']);
        }

        $permissions = $user['permissions'] ?? [];

        if (($user['role_code'] ?? '') === 'MANAGER' && Auth::hasPermission('overtime.create')) {
            return;
        }

        throw new ValidationException(['permission' => $message]);
    }

    /** True when the response-tracking columns exist (post-migration). */
    private function hasResponseColumns(): bool
    {
        static $cached = null;

        if ($cached !== null) {
            return $cached;
        }

        try {
            $cached = Database::selectOne("SHOW COLUMNS FROM overtime_requests LIKE 'responded_at'") !== null;
        } catch (\Throwable $e) {
            $cached = false;
        }

        return $cached;
    }

    /** True when the creator column exists (post-migration). */
    private function hasCreatedByColumn(): bool
    {
        static $cached = null;

        if ($cached !== null) {
            return $cached;
        }

        try {
            $cached = Database::selectOne("SHOW COLUMNS FROM overtime_requests LIKE 'created_by'") !== null;
        } catch (\Throwable $e) {
            $cached = false;
        }

        return $cached;
    }

    /** @return list<string> selectable columns that exist on this database. */
    private function responseSelects(): array
    {
        $selects = [];

        if ($this->hasCreatedByColumn()) {
            $selects[] = 'o.created_by';
        }

        if ($this->hasResponseColumns()) {
            $selects[] = 'o.decline_reason';
            $selects[] = 'o.responded_at';
            $selects[] = 'o.responded_by';
            $selects[] = 'ru.username AS responded_by_username';
        }

        return $selects;
    }

    /** Extra LEFT JOINs needed by responseSelects(). */
    private function responseJoins(): string
    {
        if (!$this->hasResponseColumns()) {
            return '';
        }

        return 'LEFT JOIN users ru ON ru.id = o.responded_by';
    }

    /** Normalise status for old databases whose enum lacks ACCEPTED/DECLINED. */
    private function displayStatus(array $row): string
    {
        $status = strtoupper((string) ($row['status'] ?? ''));

        if ($this->hasResponseColumns()) {
            return $status;
        }

        // Pre-migration fallback: derive the assignment response from remarks.
        if ($status === 'REJECTED' && str_contains((string) ($row['approver_remarks'] ?? ''), 'Declined by assignee:')) {
            return 'DECLINED';
        }

        if ($status === 'APPROVED' && str_contains((string) ($row['approver_remarks'] ?? ''), 'Accepted by assignee')) {
            return 'ACCEPTED';
        }

        return $status;
    }

    /** Attach display response fields so API + UI work pre/post migration. */
    private function withResponse(array $row): array
    {
        $row['display_status'] = $this->displayStatus($row);

        if (!$this->hasResponseColumns()) {
            $remarks = (string) ($row['approver_remarks'] ?? '');

            if ($row['display_status'] === 'DECLINED') {
                $row['decline_reason'] = trim(str_replace('Declined by assignee:', '', $remarks));
            } elseif (!array_key_exists('decline_reason', $row)) {
                $row['decline_reason'] = null;
            }

            if (!array_key_exists('responded_at', $row)) {
                $row['responded_at'] = $row['display_status'] === 'ACCEPTED' || $row['display_status'] === 'DECLINED'
                    ? ($row['approved_at'] ?? null)
                    : null;
            }
        }

        return $row;
    }

    /** Hours between two times, handling an overnight window. */
    public function calculateHours(string $startTime, string $endTime): float
    {
        $start = strtotime($startTime);
        $end   = strtotime($endTime);

        if ($end === false || $start === false) {
            return 0.0;
        }

        // Overnight: the window crosses midnight.
        if ($end <= $start) {
            $end += 86400;
        }

        return round(max(0, $end - $start) / 3600, 2);
    }

    /**
     * Business rule: on the normal 8:00 AM–5:00 PM schedule, overtime may run
     * from 5:00 PM only until 12:00 AM MIDNIGHT — never past it.
     *
     * Times are zero-padded HH:MM:SS, so a plain string compare is safe: an
     * end time earlier than the start time means the window ran past midnight,
     * except for exactly 00:00:00 — midnight at the end of the same day,
     * which is a valid end (e.g. 5:00 PM → 12:00 AM = 7 hours).
     */
    private function assertEndsByMidnight(string $startTime, string $endTime): void
    {
        if ($endTime < $startTime && $endTime !== '00:00:00') {
            throw new ValidationException([
                'end_time' => 'Overtime cannot run past 12:00 AM midnight. The end time must be between the start time and 12:00 AM.',
            ]);
        }
    }

    /**
     * Reject an OT schedule whose end datetime has already passed.
     *
     * When end_time is '00:00:00', the window runs to midnight at the END
     * of overtime_date, i.e. 00:00:00 of the next calendar day.
     * Otherwise the deadline is TIMESTAMP(overtime_date, end_time).
     *
     * Comparison uses the application's configured timezone. A deterministic
     * $now (Y-m-d H:i:s) may be supplied for time-independent tests.
     */
    private function assertNotExpired(string $date, string $startTime, string $endTime, ?string $now = null): void
    {
        // Build the end datetime in the app's timezone.
        if ($endTime === '00:00:00') {
            // Midnight at end of overtime_date = 00:00:00 of the next calendar day.
            $endDateTime = new \DateTime($date . ' 00:00:00');
            $endDateTime->modify('+1 day');
        } else {
            $endDateTime = new \DateTime($date . ' ' . $endTime);
        }

        if ($now === null) {
            $now = (new \DateTime('now'))->format('Y-m-d H:i:s');
        }
        $nowDateTime = new \DateTime($now);

        if ($endDateTime <= $nowDateTime) {
            throw new ValidationException([
                'end_time' => 'This overtime schedule has already expired. The end date and time must be in the future.',
            ]);
        }
    }

    /**
     * Validate the overtime window against the employee's regular shift.
     *
     * For non-overnight shifts, overtime must start at or after the shift end.
     * Overnight shifts are excluded so their own schedule logic remains
     * authoritative.
     */
    private function assertOvertimeWindow(string $employeeId, string $date, string $startTime, string $endTime): void
    {
        $context = $this->engine->contextFor((int) $employeeId, $date);
        $shift   = $context['shift'] ?? null;

        if ($shift === null || (int) ($shift['is_overnight'] ?? 0) === 1) {
            return;
        }

        $shiftEnd = substr((string) $shift['end_time'], 0, 8);

        // Fixed standard pre-OT duty-free break 17:00–17:30.
        // Other shift/rest-day cases retain their actual schedule validation.
        $earliest = $shiftEnd === '17:00:00' && !$context['is_rest_day'] && $context['holiday'] === null
            ? '17:30:00' : $shiftEnd;
        if ($startTime < $earliest) {
            throw new ValidationException([
                'start_time' => sprintf('Assigned overtime must start at or after %s.', date('g:i A', strtotime($earliest))),
            ]);
        }
    }

    /** Configurable multiplier for a request's type (Phase 11 / Phase 12). */
    public function multiplierFor(string $otType): float
    {
        return match (strtoupper($otType)) {
            'REST_DAY', 'NIGHT' => Settings::float('payroll.overtime_rest_day_multiplier', 1.30),
            'HOLIDAY'           => Settings::float('payroll.overtime_holiday_multiplier', 2.00),
            default             => Settings::float('payroll.overtime_multiplier', 1.25),
        };
    }
/**
     * Admin announces an overtime assignment (one or many employees).
     *
     * Only Admin may call this: the route requires `overtime.create` (which
     * non-admin roles no longer hold) AND requireAdmin() below rejects any
     * Employee/Manager that calls the endpoint directly.
     *
     * @param array<string, mixed> $data
     * @return array<string, mixed> single record, or ['items'=>...] for bulk
     */
    public function create(array $data, ?int $userId = null, ?string $now = null): array
    {
        $this->requireAdmin();
        $userId = $userId ?? Auth::id();

        // Total hours is always derived from the start/end pair — a
        // client-supplied value is never read.
        unset($data['total_hours']);

        $employeeIds = $this->assignedEmployeeIds($data);

        $validator = Validator::make($data, self::rules());
        if ($validator->fails()) {
            throw new ValidationException($validator->errors());
        }

        $validated  = $validator->validated();
        $otDate     = (string) $validated['overtime_date'];
        $startTime  = $this->normaliseTime((string) $validated['start_time']);
        $endTime    = $this->normaliseTime((string) $validated['end_time']);

        $hours = $this->calculateHours($startTime, $endTime);

        if ($hours <= 0) {
            throw new ValidationException(['end_time' => 'End time must be after start time.']);
        }

        $this->assertEndsByMidnight($startTime, $endTime);
        $this->assertNotExpired($otDate, $startTime, $endTime, $now);

        // Configurable minimum OT duration.
        $minimumHours = Settings::float('payroll.overtime_min_hours', 0.0);
        if ($minimumHours > 0 && $hours < $minimumHours) {
            throw new ValidationException([
                'end_time' => sprintf('Overtime must be at least %.2f hour(s).', $minimumHours),
            ]);
        }

        // Configurable maximum so a mistyped time (20:00 -> 19:00) is a 23 hour
        // "overnight" shift rather than a silent error.
        $maximumHours = Settings::float('payroll.overtime_max_hours', 12.0);
        if ($maximumHours > 0 && $hours > $maximumHours) {
            throw new ValidationException([
                'end_time' => sprintf(
                    'Overtime cannot exceed %.2f hour(s). Check the start and end times.',
                    $maximumHours
                ),
            ]);
        }

        // Overlapping active assignments are rejected per employee.
        foreach ($employeeIds as $employeeId) {
            DemoStaffScope::assertDemoParticipant((int) $employeeId);
            $employee = Database::selectOne(
                'SELECT id, status, archived_at FROM employees WHERE id = :id AND deleted_at IS NULL',
                ['id' => $employeeId]
            );

            if ($employee === null) {
                throw new ValidationException(['employee_id' => 'One of the selected employees does not exist.']);
            }

            if ($employee['status'] !== 'ACTIVE' || $employee['archived_at'] !== null) {
                throw new ValidationException(['employee_id' => 'Overtime can only be assigned to active employees.']);
            }

            $this->assertOvertimeWindow((string) $employeeId, $otDate, $startTime, $endTime);

            $overlap = Database::scalar(
                "SELECT id FROM overtime_requests
                  WHERE employee_id = :emp
                    AND overtime_date = :date
                    AND status IN ('PENDING','ACCEPTED','COMPLETED','APPROVED')
                    AND deleted_at IS NULL
                    AND NOT (end_time <= :start OR start_time >= :end)
                  LIMIT 1",
                [
                    'emp'   => $employeeId,
                    'date'  => $otDate,
                    'start' => $startTime,
                    'end'   => $endTime,
                ]
            );

            if ($overlap !== null) {
                throw new ValidationException([
                    'overtime_date' => 'An overtime assignment already exists that overlaps this time range.',
                ]);
            }
        }

        $reason = (string) $validated['reason'];
        $typeHint = isset($validated['ot_type']) && $validated['ot_type'] !== ''
            ? (string) $validated['ot_type'] : null;

        return Database::transaction(function () use ($employeeIds, $otDate, $startTime, $endTime, $hours, $reason, $typeHint, $userId): array {
            $items = [];

            foreach ($employeeIds as $employeeId) {
                // Detect the OT type per employee when it was not supplied.
                $otType = $typeHint ?? $this->detectType($employeeId, $otDate);

                $row = [
                    'employee_id'   => $employeeId,
                    'overtime_date' => $otDate,
                    'start_time'    => $startTime,
                    'end_time'      => $endTime,
                    'hours'         => $hours,
                    'ot_type'       => $otType,
                    'reason'        => $reason,
                    'status'        => 'PENDING',
                ];

                if ($this->hasCreatedByColumn() && $userId !== null) {
                    $row['created_by'] = $userId;
                }

                $requestId = Database::insert('overtime_requests', $row);

                AuditLogger::record(
                    AuditLogger::OVERTIME_ASSIGNED,
                    'overtime_request',
                    $requestId,
                    sprintf('Overtime assigned: %.2f hours on %s', $hours, $otDate),
                    null,
                    [
                        'employee_id'   => $employeeId,
                        'overtime_date' => $otDate,
                        'start_time'    => $startTime,
                        'end_time'      => $endTime,
                        'hours'         => $hours,
                        'ot_type'       => $otType,
                        'created_by'    => $userId,
                    ]
                );

                $items[] = $this->find($requestId);
            }

            if (count($items) === 1) {
                return $items[0];
            }

            return ['items' => $items, 'count' => count($items)];
        });
    }

    /**
     * Normalise the assignee list.
     * Accepts `employee_ids[]` (preferred) or legacy single `employee_id`.
     *
     * @param array<string, mixed> $data
     * @return list<int>
     */
    private function assignedEmployeeIds(array $data): array
    {
        $raw = $data['employee_ids'] ?? ($data['employee_id'] ?? null);

        if (!is_array($raw)) {
            $raw = [$raw];
        }

        $ids = [];

        foreach ($raw as $value) {
            if ($value === null || $value === '') {
                continue;
            }

            if (filter_var($value, FILTER_VALIDATE_INT) === false || (int) $value <= 0) {
                throw new ValidationException(['employee_id' => 'Select at least one valid employee for this overtime.']);
            }

            $ids[] = (int) $value;
        }

        $ids = array_values(array_unique($ids));

        if ($ids === []) {
            throw new ValidationException(['employee_id' => 'Select at least one employee for this overtime.']);
        }

        return $ids;
    }
    /**
     * Admin edits a pending/accepted assignment.
     *
     * @param array<string, mixed> $data
     * @return array<string, mixed>
     */
    public function update(int $requestId, array $data, ?int $userId = null, ?string $now = null): array
    {
        $this->requireAdmin();

        // Total hours is always derived from the start/end pair — a
        // client-supplied value is never read.
        unset($data['total_hours']);

        $existing = $this->find($requestId);

        if ($existing === null) {
            throw new RuntimeException('Overtime assignment not found.');
        }
        DemoStaffScope::assertDemoParticipant((int) $existing['employee_id']);

        if (!in_array($existing['status'], ['PENDING', 'ACCEPTED', 'COMPLETED'], true)) {
            throw new RuntimeException('Only pending or accepted overtime assignments can be edited.');
        }

        $validated = Validator::make(
            $data,
            [
                'overtime_date' => 'nullable|date',
                'start_time'    => 'nullable|time',
                'end_time'      => 'nullable|time',
                'reason'        => 'nullable|string|min:3|max:500',
                'ot_type'       => 'nullable|in:REGULAR,REST_DAY,HOLIDAY,NIGHT',
            ]
        );

        if ($validated->fails()) {
            throw new ValidationException($validated->errors());
        }

        $fields = $validated->validated();

        $otDate    = isset($fields['overtime_date']) ? (string) $fields['overtime_date'] : (string) $existing['overtime_date'];
        $startTime = isset($fields['start_time']) ? $this->normaliseTime((string) $fields['start_time']) : (string) $existing['start_time'];
        $endTime   = isset($fields['end_time']) ? $this->normaliseTime((string) $fields['end_time']) : (string) $existing['end_time'];
        $hours     = $this->calculateHours($startTime, $endTime);

        if ($hours <= 0) {
            throw new ValidationException(['end_time' => 'End time must be after start time.']);
        }

        $this->assertEndsByMidnight($startTime, $endTime);
        $this->assertNotExpired($otDate, $startTime, $endTime, $now);

        $this->assertOvertimeWindow((string) $existing['employee_id'], $otDate, $startTime, $endTime);

        $payload = [
            'overtime_date' => $otDate,
            'start_time'    => $startTime,
            'end_time'      => $endTime,
            'hours'         => $hours,
            'ot_type'       => $fields['ot_type'] ?? $existing['ot_type'],
            'reason'        => $fields['reason'] ?? $existing['reason'],
        ];

        Database::update('overtime_requests', $payload, ['id' => $requestId]);

        AuditLogger::recordChanges(
            AuditLogger::OVERTIME_CREATED,
            'overtime_request',
            $requestId,
            $existing,
            array_merge($existing, $payload)
        );

        return $this->find($requestId);
    }

    /**
     * Assignee accepts their overtime assignment.
     * Only the linked employee (or an admin acting for them) may respond.
     */
    public function accept(int $requestId, ?int $userId = null): array
    {
        if (DemoStaffScope::enabled()) {
            $employeeId = Database::scalar('SELECT employee_id FROM overtime_requests WHERE id=:id', ['id'=>$requestId]);
            if ($employeeId !== null) { DemoStaffScope::assertIncluded((int) $employeeId); }
        }
        $existing = $this->find($requestId);

        if ($existing === null) {
            throw new RuntimeException('Overtime assignment not found.');
        }

        $this->requireAssignee($existing, 'accept');

        if ((string)$existing['status'] !== 'PENDING') {
            throw new RuntimeException('Only pending assignments can be accepted.');
        }

        $userId = $userId ?? Auth::id();
        $now = date('Y-m-d H:i:s');
        if (strtotime($existing['overtime_date'] . ' ' . $existing['start_time']) <= time()) {
            throw new ValidationException(['overtime' => 'An ordinary OT assignment must be accepted before work starts.']);
        }

        $payload = ['status' => 'ACCEPTED'];

        if ($this->hasResponseColumns()) {
            $payload['responded_at'] = $now;
            $payload['responded_by'] = $userId;
            $payload['decline_reason'] = null;
        } else {
            $payload['approver_remarks'] = 'Accepted by assignee';
        }

        Database::update('overtime_requests', $payload, ['id' => $requestId]);

        AuditLogger::record(
            AuditLogger::OVERTIME_ACCEPTED,
            'overtime_request',
            $requestId,
            sprintf('Overtime accepted by %s for %s', $this->assigneeName($existing), (string) $existing['overtime_date']),
            ['status' => $existing['status']],
            ['status' => 'ACCEPTED', 'responded_at' => $now, 'responded_by' => $userId]
        );

        return $this->find($requestId);
    }

    /**
     * Assignee declines their overtime assignment with a required reason.
     * Declined OT is never payable and reverses any applied attendance hours.
     */
    public function decline(int $requestId, string $reason, ?int $userId = null): array
    {
        if (DemoStaffScope::enabled()) {
            $employeeId = Database::scalar('SELECT employee_id FROM overtime_requests WHERE id=:id', ['id'=>$requestId]);
            if ($employeeId !== null) { DemoStaffScope::assertIncluded((int) $employeeId); }
        }
        $existing = $this->find($requestId);

        if ($existing === null) {
            throw new RuntimeException('Overtime assignment not found.');
        }

        $this->requireAssignee($existing, 'decline');

        $reason = trim($reason);

        if ($reason === '') {
            throw new ValidationException(['decline_reason' => 'Please tell your admin why you cannot work this overtime.']);
        }

        if (mb_strlen($reason) > 500) {
            throw new ValidationException(['decline_reason' => 'The decline reason must not exceed 500 characters.']);
        }

        if (!in_array((string)$existing['status'], ['PENDING', 'ACCEPTED'], true)) {
            throw new RuntimeException('This assignment can no longer be declined.');
        }
        if (strtotime($existing['overtime_date'] . ' ' . $existing['start_time']) <= time()) {
            throw new ValidationException(['overtime' => 'Please contact HR if work has already started. Completed OT cannot be declined retroactively.']);
        }

        $userId = $userId ?? Auth::id();
        $now = date('Y-m-d H:i:s');

        Database::transaction(function () use ($requestId, $existing, $reason, $userId, $now): void {
            $payload = ['status' => 'DECLINED'];

            if ($this->hasResponseColumns()) {
                $payload['decline_reason'] = $reason;
                $payload['responded_at'] = $now;
                $payload['responded_by'] = $userId;
            } else {
                // Pre-migration fallback keeps the reason visible via remarks.
                $payload['approver_remarks'] = 'Declined by assignee: ' . $reason;
                $payload['approved_at'] = $now;
            }

            Database::update('overtime_requests', $payload, ['id' => $requestId]);

            $this->reverseAttendance((int) $existing['employee_id'], $requestId, $existing);
        });

        AuditLogger::record(
            AuditLogger::OVERTIME_DECLINED,
            'overtime_request',
            $requestId,
            sprintf('Overtime declined by %s for %s: %s', $this->assigneeName($existing), (string) $existing['overtime_date'], $reason),
            ['status' => $existing['status']],
            ['status' => 'DECLINED', 'decline_reason' => $reason, 'responded_at' => $now, 'responded_by' => $userId]
        );

        return $this->find($requestId);
    }

    /**
     * Only the assigned employee (or an admin) may accept/decline.
     * Managers must never respond to another employee's assignment.
     */
    private function requireAssignee(array $record, string $action): void
    {
        $user = Auth::user();

        if ($user === null) {
            throw new ValidationException(['permission' => 'Authentication is required.']);
        }

        $permissions = (array) ($user['permissions'] ?? []);

        // A technical Admin is not a payroll employee and cannot accept/decline OT.

        $employeeId = Auth::employeeId();

        if ($employeeId !== null && $employeeId === (int) $record['employee_id']) {
            return;
        }

        throw new ValidationException(['permission' => sprintf('You may only %s your own overtime assignments.', $action)]);
    }

    private function assigneeName(array $record): string
    {
        $name = trim(implode(' ', array_filter([
            $record['first_name'] ?? null,
            $record['middle_name'] ?? null,
            $record['last_name'] ?? null,
        ], static fn ($value): bool => (string) $value !== '')));

        return $name !== '' ? $name : ('employee #' . (string) ($record['employee_id'] ?? ''));
    }
    /**
     * Flip PENDING/ACCEPTED overtime to COMPLETED once its end time passes.
     * Declined assignments never complete and never enter payroll.
     *
     * @param string|null $now Deterministic "now" (Y-m-d H:i:s) for tests.
     *                         Null uses the server's NOW().
     * @return int number of requests completed
     */
    public function completeEndedRequests(?string $now = null): int
    {
        $nowClause = $now === null ? 'NOW()' : ':now';
        $params    = $now === null ? [] : ['now' => $now];

        $due = Database::select(
            "SELECT o.id, o.employee_id, o.overtime_date, o.start_time, o.end_time, o.hours
               FROM overtime_requests o
              WHERE o.status IN ('PENDING','ACCEPTED')
                AND o.deleted_at IS NULL
                AND (
                    CASE
                        -- An end time of 00:00:00 (midnight) that follows a later
                        -- start time means the window runs to midnight at the END
                        -- of overtime_date, i.e. 00:00:00 of the next calendar day.
                        WHEN o.end_time = '00:00:00' AND o.start_time > '00:00:00'
                        THEN TIMESTAMP(DATE_ADD(o.overtime_date, INTERVAL 1 DAY), '00:00:00')
                        ELSE TIMESTAMP(o.overtime_date, o.end_time)
                    END
                ) <= {$nowClause}
              ORDER BY o.id ASC
              LIMIT 200",
            $params
        );

        if ($due === []) {
            return 0;
        }

        $completed = 0;

        foreach ($due as $row) {
            $total = $this->totalHoursFor($row);

            Database::update('overtime_requests', [
                'status'      => 'COMPLETED',
                'total_hours' => $total,
            ], ['id' => (int) $row['id']]);

            $completed++;

            AuditLogger::record(
                AuditLogger::OVERTIME_COMPLETED,
                'overtime_request',
                (int) $row['id'],
                sprintf(
                    'Overtime completed: %.2f hours total (%.2f requested) on %s',
                    $total,
                    (float) $row['hours'],
                    (string) $row['overtime_date']
                ),
                ['status' => 'PENDING', 'hours' => (float) $row['hours']],
                ['status' => 'COMPLETED', 'total_hours' => $total]
            );
        }

        return $completed;
    }

    /**
     * Actual overtime hours once the window has ended.
     *
     * Prefers the attendance record for that day (the time_in/time_out span is
     * the worked window) and falls back to the requested start-end hours when
     * the employee never logged attendance.
     *
     * @param array<string, mixed> $row
     */
    private function totalHoursFor(array $row): float
    {
        $scan = Database::selectOne(
            'SELECT payable_minutes, ot_time_in, ot_time_out FROM overtime_scans WHERE overtime_request_id = :id',
            ['id' => (int) $row['id']]
        );
        // Never pay unworked scheduled OT. Actual Time In AND Out are required.
        return ($scan === null || $scan['ot_time_out'] === null)
            ? 0.0 : round((int) $scan['payable_minutes'] / 60, 2);
    }

    /** Hours between two punches, handling an overnight shift. */
    private function hoursBetween(string $from, string $to): float
    {
        // MySQL hands back zero-dates for never-punched columns and PHP parses
        // those happily, so reject them before the arithmetic.
        if (str_starts_with(trim($from), '0000-00-00') || str_starts_with(trim($to), '0000-00-00')) {
            return 0.0;
        }

        $start = strtotime($from);
        $end   = strtotime($to);

        if ($start === false || $end === false) {
            return 0.0;
        }

        if ($end <= $start) {
            $end += 86400;
        }

        $hours = round(max(0, $end - $start) / 3600, 2);

        // Nothing sane runs past a full day.
        return $hours <= 24.0 ? $hours : 0.0;
    }

    /**
     * HR AUTHORISATION of a Manager assignment, before OT is worked.
     * Authorisation DOES NOT mark time payable and never writes to attendance.
     * Payroll hours remain zero until actual QR scans, independent Manager
     * confirmation and HR payroll verification all succeed.
     */
    public function approve(int $requestId, string $remarks = '', ?int $approverId = null): array
    {
        if (DemoStaffScope::enabled()) {
            $employeeId = Database::scalar('SELECT employee_id FROM overtime_requests WHERE id=:id', ['id'=>$requestId]);
            if ($employeeId !== null) { DemoStaffScope::assertIncluded((int) $employeeId); }
        }
        if (!Auth::hasPermission('overtime.approve') || Auth::roleCode() !== 'HR_PAYROLL') {
            throw new ValidationException(['permission' => 'Only HR/Payroll may authorize overtime.']);
        }
        $request = $this->find($requestId);
        if ($request === null) { throw new RuntimeException('Overtime assignment not found.'); }
        if (!in_array((string)$request['status'], ['PENDING', 'ACCEPTED'], true)) {
            throw new ValidationException(['status' => 'Only pending Manager assignments can be authorized before the start of OT.']);
        }
        if (strtotime($request['overtime_date'] . ' ' . $request['start_time']) <= time()) {
            throw new ValidationException(['overtime' => 'HR must authorize ordinary overtime before the scheduled start.']);
        }
        if (Auth::employeeId() !== null && (int) $request['employee_id'] === Auth::employeeId()) {
            throw new ValidationException(['employee' => 'You cannot authorize your own overtime.']);
        }
        $approverId = $approverId ?? Auth::id();
        return Database::transaction(function () use ($requestId, $request, $remarks, $approverId): array {
            Database::update('overtime_requests', [
                'status' => 'APPROVED',
                'approver_id' => $approverId,
                'approved_at' => date('Y-m-d H:i:s'),
                'approver_remarks' => $remarks !== '' ? $remarks : null,
                // No applied_hours here: authorization is NOT payroll verification.
            ], ['id' => $requestId]);
            AuditLogger::record(
                AuditLogger::OVERTIME_APPROVED,
                'overtime_request', $requestId,
                'OT assignment authorized before actual work; not yet payable.',
                ['status' => $request['status']],
                ['status' => 'APPROVED', 'authorized_by' => $approverId]
            );
            return $this->find($requestId);
        });
    }

    /** Manager confirms completed actual OT QR scans for employees in own team. */
    public function confirmActual(int $requestId): array
    {
        if (DemoStaffScope::enabled()) {
            $employeeId = Database::scalar('SELECT employee_id FROM overtime_requests WHERE id=:id', ['id'=>$requestId]);
            if ($employeeId !== null) { DemoStaffScope::assertIncluded((int) $employeeId); }
        }
        if (Auth::roleCode() !== 'MANAGER' || !Auth::hasPermission('overtime.create')) {
            throw new ValidationException(['permission' => 'Only an assigned Manager may confirm actual overtime.']);
        }
        $request = $this->find($requestId);
        if ($request === null) { throw new RuntimeException('Overtime assignment not found.'); }
        Auth::requireTeamEmployee((int)$request['employee_id']);
        if (Auth::employeeId() !== null && (int)$request['employee_id'] === Auth::employeeId()) {
            throw new ValidationException(['employee' => 'You cannot confirm your own overtime.']);
        }
        if ((string)$request['status'] !== 'APPROVED') {
            throw new ValidationException(['status' => 'OT must be authorized by HR before confirmation.']);
        }
        if (!empty($request['manager_confirmed_at'])) {
            throw new ValidationException(['status' => 'Actual OT has already been confirmed.']);
        }
        $scan = Database::selectOne(
            'SELECT ot_time_in, ot_time_out, payable_minutes FROM overtime_scans WHERE overtime_request_id = :id',
            ['id' => $requestId]
        );
        if ($scan === null || empty($scan['ot_time_in']) || empty($scan['ot_time_out'])) {
            throw new ValidationException(['overtime' => 'OT Time In and OT Time Out scans are required before Manager confirmation.']);
        }
        if ((int)$scan['payable_minutes'] <= 0) {
            throw new ValidationException(['overtime' => 'No payable OT minutes found. Submit for attendance verification instead.']);
        }
        Database::update('overtime_requests', [
            'manager_confirmed_by' => Auth::id(),
            'manager_confirmed_at' => date('Y-m-d H:i:s'),
        ], ['id' => $requestId]);
        AuditLogger::record(
            AuditLogger::OVERTIME_APPROVED, 'overtime_request', $requestId,
            'Manager confirmed actual QR overtime hours.',
            ['manager_confirmed_at' => null],
            ['manager_confirmed_by' => Auth::id(), 'payable_minutes' => (int)$scan['payable_minutes']]
        );
        return $this->find($requestId);
    }

    /** HR payroll verification after manager confirmation, then apply ACTUAL QR time. */
    public function verifyPayroll(int $requestId): array
    {
        if (DemoStaffScope::enabled()) {
            $employeeId = Database::scalar('SELECT employee_id FROM overtime_requests WHERE id=:id', ['id'=>$requestId]);
            if ($employeeId !== null) { DemoStaffScope::assertIncluded((int) $employeeId); }
        }
        if (Auth::roleCode() !== 'HR_PAYROLL' || !Auth::hasPermission('overtime.approve')) {
            throw new ValidationException(['permission' => 'Only HR/Payroll may verify overtime for payroll.']);
        }
        $request = $this->find($requestId);
        if ($request === null) { throw new RuntimeException('Overtime assignment not found.'); }
        if (Auth::employeeId() !== null && (int)$request['employee_id'] === Auth::employeeId()) {
            throw new ValidationException(['employee' => 'You cannot verify your own overtime for payroll.']);
        }
        if ((string)$request['status'] !== 'APPROVED') {
            throw new ValidationException(['status' => 'OT must first be authorized.']);
        }
        if (empty($request['manager_confirmed_at'])) {
            throw new ValidationException(['manager' => 'The assigned Manager must confirm the completed OT scans first.']);
        }
        if (!empty($request['payroll_verified_at']) || (float)$request['applied_hours'] > 0) {
            throw new ValidationException(['status' => 'This overtime has already been applied to payroll.']);
        }
        return Database::transaction(function () use ($requestId, $request): array {
            // Checks both QR punches and actual payable minutes. Transaction
            // rolls back if scans are missing or invalid; no unworked OT is paid.
            $this->applyToAttendance($requestId, (int)$request['employee_id'], $request);
            Database::update('overtime_requests', [
                'payroll_verified_by' => Auth::id(),
                'payroll_verified_at' => date('Y-m-d H:i:s'),
            ], ['id' => $requestId]);
            AuditLogger::record(
                AuditLogger::OVERTIME_APPROVED, 'overtime_request', $requestId,
                'HR verified Manager-confirmed actual OT for payroll.', null,
                ['payroll_verified_by' => Auth::id()]
            );
            return $this->find($requestId);
        });
    }

    /** Admin rejects an assignment (declines on behalf of management). */
    public function reject(int $requestId, string $remarks = '', ?int $approverId = null): array
    {
        if (DemoStaffScope::enabled()) {
            $employeeId = Database::scalar('SELECT employee_id FROM overtime_requests WHERE id=:id', ['id'=>$requestId]);
            if ($employeeId !== null) { DemoStaffScope::assertIncluded((int) $employeeId); }
        }
        if (!Auth::hasPermission('overtime.approve') || Auth::roleCode() !== 'HR_PAYROLL') { throw new ValidationException(['permission' => 'Only HR/Payroll authorizes overtime.']); }

        $request = $this->find($requestId);

        if ($request === null) {
            throw new RuntimeException('Overtime assignment not found.');
        }

        if (!in_array($request['status'], ['PENDING', 'ACCEPTED', 'COMPLETED'], true)) {
            throw new RuntimeException(sprintf(
                'Only pending or accepted assignments can be rejected (current status: %s).',
                $request['status']
            ));
        }

        $approverId = $approverId ?? Auth::id();

        Database::transaction(function () use ($requestId, $request, $remarks, $approverId): void {
            Database::update('overtime_requests', [
                'status'           => 'REJECTED',
                'approver_id'      => $approverId,
                'approved_at'      => date('Y-m-d H:i:s'),
                'approver_remarks' => $remarks !== '' ? $remarks : null,
            ], ['id' => $requestId]);

            // Rejected assignments must not linger as payable hours.
            $this->reverseAttendance((int) $request['employee_id'], $requestId, $request);
        });

        AuditLogger::record(
            AuditLogger::OVERTIME_REJECTED,
            'overtime_request',
            $requestId,
            sprintf('Overtime rejected: %.2f hours on %s', (float) $request['hours'], $request['overtime_date']),
            ['status' => 'PENDING'],
            ['status' => 'REJECTED', 'approver_id' => $approverId, 'remarks' => $remarks]
        );

        return $this->find($requestId);
    }
    /** Admin cancels an assignment, or revokes an approval. */
    public function cancel(int $requestId, ?int $userId = null): array
    {
        if (DemoStaffScope::enabled()) {
            $employeeId = Database::scalar('SELECT employee_id FROM overtime_requests WHERE id=:id', ['id'=>$requestId]);
            if ($employeeId !== null) { DemoStaffScope::assertIncluded((int) $employeeId); }
        }
        $this->requireAdmin();

        $request = $this->find($requestId);

        if ($request === null) {
            throw new RuntimeException('Overtime assignment not found.');
        }

        $status = (string) $request['status'];

        if (!empty($request['payroll_verified_at'])) {
            throw new ValidationException(['overtime' => 'Verified overtime is locked. Use a separately approved audited payroll correction instead.']);
        }
        if (in_array($status, ['REJECTED', 'CANCELLED'], true)) {
            throw new RuntimeException(sprintf('This assignment is already %s.', strtolower($status)));
        }

        // Cancelling removes any hours payroll would otherwise pay.
        Database::transaction(function () use ($requestId, $request, $status): void {
            $this->removeFromAttendance($requestId, (int) $request['employee_id'], $request);

            Database::update('overtime_requests', [
                'status'           => 'CANCELLED',
                'approver_remarks' => $status === 'APPROVED'
                    ? 'Approval revoked (assignment cancelled)'
                    : 'Cancelled by admin',
            ], ['id' => $requestId]);

            AuditLogger::record(
                AuditLogger::OVERTIME_CANCELLED,
                'overtime_request',
                $requestId,
                sprintf('Overtime assignment cancelled: %.2f hours on %s', (float) $request['hours'], $request['overtime_date']),
                ['status' => $status],
                ['status' => 'CANCELLED']
            );
        });

        return $this->find($requestId);
    }

    /** Reverse of applyToAttendance(): take back hours a decline/reject must not pay. */
    private function reverseAttendance(int $employeeId, int $requestId, array $request): void
    {
        // Nothing was ever applied: only clear the marker, never touch the row.
        if ((float) ($request['applied_hours'] ?? 0) <= 0) {
            Database::execute(
                'UPDATE overtime_requests SET applied_hours = 0 WHERE id = :id',
                ['id' => $requestId]
            );

            return;
        }

        $this->removeFromAttendance($requestId, $employeeId, $request);
    }

    /** Reverse of applyToAttendance(): undo the hours an approval wrote. */
    private function removeFromAttendance(int $requestId, int $employeeId, array $request): void
    {
        $otDate = (string) $request['overtime_date'];
        $hours  = (float) ($request['applied_hours'] > 0 ? $request['applied_hours'] : $request['hours']);

        $attendance = $this->engine->findAttendance($employeeId, $otDate);

        if ($attendance === null) {
            return;
        }

        $fabricated = $attendance['time_in'] === null
            && $attendance['time_out'] === null
            && (string) $attendance['source'] === 'AUTO'
            && (string) $attendance['remarks'] === 'Overtime applied';

        if ($fabricated) {
            // The approval created this row purely for the OT; remove it
            // entirely (same policy as approved-leave cancellation).
            Database::delete('attendance', ['id' => (int) $attendance['id']]);
        } else {
            // A real attendance row exists: only take the applied hours back.
            $remaining = max((float) $attendance['overtime_hours'] - $hours, 0.0);

            Database::execute(
                'UPDATE attendance SET overtime_hours = :hours WHERE id = :id',
                ['hours' => $remaining, 'id' => (int) $attendance['id']]
            );
        }

        Database::execute(
            'UPDATE overtime_requests SET applied_hours = 0 WHERE id = :id',
            ['id' => $requestId]
        );
    }

    /** Archive any assignment (soft delete). Only Admin may archive/restore. */
    public function delete(int $requestId): array
    {
        if (DemoStaffScope::enabled()) {
            $employeeId = Database::scalar('SELECT employee_id FROM overtime_requests WHERE id=:id', ['id'=>$requestId]);
            if ($employeeId !== null) { DemoStaffScope::assertIncluded((int) $employeeId); }
        }
        $this->requireAdmin();

        $request = $this->find($requestId);
        if ($request === null) {
            throw new RuntimeException('Overtime assignment not found.');
        }
        Database::update('overtime_requests', ['deleted_at' => date('Y-m-d H:i:s')], ['id' => $requestId]);
        AuditLogger::record(
            AuditLogger::OVERTIME_CREATED,
            'overtime_request',
            $requestId,
            sprintf('Removed overtime assignment #%d (archived)', $requestId),
            $request,
            null
        );
        return ['id' => $requestId];
    }

    /** Restore a removed overtime assignment to its list. Only Admin. */
    public function restore(int $requestId): array
    {
        if (DemoStaffScope::enabled()) {
            $employeeId = Database::scalar('SELECT employee_id FROM overtime_requests WHERE id=:id', ['id'=>$requestId]);
            if ($employeeId !== null) { DemoStaffScope::assertIncluded((int) $employeeId); }
        }
        $this->requireAdmin();

        $existing = Database::selectOne(
            'SELECT * FROM overtime_requests WHERE id = :id AND deleted_at IS NOT NULL',
            ['id' => $requestId]
        );

        if ($existing === null) {
            throw new RuntimeException('Overtime assignment not found or is not archived.');
        }

        Database::update('overtime_requests', ['deleted_at' => null], ['id' => $requestId]);

        AuditLogger::record(
            AuditLogger::OVERTIME_CREATED,
            'overtime_request',
            $requestId,
            sprintf('Restored overtime assignment #%d', $requestId),
            ['deleted_at' => $existing['deleted_at']],
            null
        );

        return $this->find($requestId);
    }

    /** @return array<string, mixed>|null */
    public function find(int $requestId): ?array
    {
        $this->completeEndedRequests();

        $selects = array_merge(
            [
                'o.*', 'e.employee_number', 'e.first_name', 'e.middle_name', 'e.last_name', 'e.suffix',
                'e.department_id', 'e.basic_salary', 'e.salary_type',
                'd.name AS department_name', 'u.username AS approver_username',
            ],
            $this->responseSelects()
        );

        $record = Database::selectOne(
            'SELECT ' . implode(', ', $selects) . '
               FROM overtime_requests o
               JOIN employees e ON e.id = o.employee_id
               LEFT JOIN departments d ON d.id = e.department_id
               LEFT JOIN users u ON u.id = o.approver_id
               ' . $this->responseJoins() . "
               WHERE o.id = :id AND o.deleted_at IS NULL
               LIMIT 1",
            ['id' => $requestId]
        );

        if ($record === null) { return null; }
        $record = $this->withResponse($record);
        $scan = Database::selectOne(
            'SELECT ot_time_in, ot_time_out, payable_minutes FROM overtime_scans WHERE overtime_request_id = :id',
            ['id' => $requestId]
        );
        $record['actual_scan'] = $scan;
        // Specific OT audit events only. The endpoint's owner/team guard is in the controller.
        $record['approval_history'] = Database::select(
            "SELECT action, description, created_at FROM audit_logs WHERE entity_type = 'overtime_request' AND entity_id = :id ORDER BY created_at ASC, id ASC LIMIT 100",
            ['id' => (string) $requestId]
        );
        return $record;
    }

    /**
     * Overtime assignments with filters (supports tomorrow=1 shortcut).
     *
     * @param array<string, mixed> $filters
     * @return array{items: list<array<string, mixed>>, total: int}
     */
    public function list(array $filters, int $page = 1, int $perPage = 25): array
    {
        // Finished windows leave the pending queue before the list is read.
        $this->completeEndedRequests();

        $where  = ['1 = 1'];
        $params = [];

        $archiveMode = strtolower(trim((string) ($filters['archived'] ?? 'false')));
        if ($archiveMode === 'only') {
            $where[] = 'o.deleted_at IS NOT NULL';
        } elseif (!filter_var($archiveMode, FILTER_VALIDATE_BOOLEAN)) {
            $where[] = 'o.deleted_at IS NULL';
        }

        if (!empty($filters['manager_employee_id'])) {
            $where[] = '(e.assigned_supervisor_id = :team_manager_id OR (e.assigned_supervisor_id IS NULL AND e.department_id = :team_department_id))';
            $params['team_manager_id'] = (int)$filters['manager_employee_id'];
            $params['team_department_id'] = (int)$filters['manager_department_id'];
        }

        if (!empty($filters['employee_id'])) {
            $where[] = 'o.employee_id = :employee_id';
            $params['employee_id'] = (int) $filters['employee_id'];
        }

        if (!empty($filters['tomorrow'])) {
            $where[] = 'o.overtime_date = DATE_ADD(CURDATE(), INTERVAL 1 DAY)';
        }

        foreach (['status' => 'o.status', 'department_id' => 'e.department_id', 'ot_type' => 'o.ot_type'] as $key => $column) {
            if (!empty($filters[$key])) {
                $where[] = sprintf('%s = :%s', $column, $key);
                $params[$key] = $key === 'department_id' ? (int) $filters[$key] : (string) $filters[$key];
            }
        }

        foreach (['date_from' => 'o.overtime_date >= :date_from', 'date_to' => 'o.overtime_date <= :date_to'] as $key => $clause) {
            if (!empty($filters[$key])) {
                $where[] = $clause;
                $params[$key] = (string) $filters[$key];
            }
        }

        $whereSql = implode(' AND ', $where);

        $total = (int) (Database::scalar(
            "SELECT COUNT(*) FROM overtime_requests o JOIN employees e ON e.id = o.employee_id WHERE {$whereSql}",
            $params
        ) ?? 0);

        $perPage = max(1, $perPage);
        $offset  = max(0, ($page - 1) * $perPage);

        $selects = array_merge(
            [
                'o.*', 'e.employee_number', 'e.first_name', 'e.middle_name', 'e.last_name', 'e.suffix',
                'e.basic_salary', 'e.salary_type', 'd.name AS department_name',
                'u.username AS approver_username',
            ],
            $this->responseSelects()
        );

        $items = Database::select(
            'SELECT ' . implode(', ', $selects) . "
               FROM overtime_requests o
               JOIN employees e ON e.id = o.employee_id
               LEFT JOIN departments d ON d.id = e.department_id
               LEFT JOIN users u ON u.id = o.approver_id
               " . $this->responseJoins() . "
              WHERE {$whereSql}
              ORDER BY o.overtime_date DESC, o.id DESC
              LIMIT {$perPage} OFFSET {$offset}",
            $params
        );

        foreach ($items as &$item) {
            $item['full_name'] = trim(implode(' ', array_filter([
                $item['first_name'], $item['middle_name'], $item['last_name'], $item['suffix'],
            ], static fn (mixed $v): bool => (string) $v !== '')));
            $item = $this->withResponse($item);
        }
        unset($item);

        return ['items' => $items, 'total' => $total];
    }

    /** Count assigned OT not yet HR-authorized (not employee-response pending).
     * Legacy ACCEPTED/COMPLETED records remain visible for follow-up.
     */
    public function pendingCount(?int $employeeId = null): int
    {
        $params = [];
        $sql    = "SELECT COUNT(*) FROM overtime_requests
                   WHERE status IN ('PENDING', 'ACCEPTED', 'COMPLETED') AND deleted_at IS NULL";

        if ($employeeId !== null) {
            $sql .= ' AND employee_id = :emp';
            $params['emp'] = $employeeId;
        }

        return (int) (Database::scalar($sql, $params) ?? 0);
    }

    /**
     * Tomorrow's assignments for the admin monitoring section.
     *
     * @return array{items: list<array<string, mixed>>, total: int}
     */
    public function tomorrow(int $page = 1, int $perPage = 50): array
    {
        return $this->list(['tomorrow' => '1'], $page, $perPage);
    }
/**
     * Apply approved overtime hours to the attendance row so the payroll
     * engine picks it up automatically (rule 8).
     *
     * @param array<string, mixed> $request
     */
    private function applyToAttendance(int $requestId, int $employeeId, array $request): void
    {
        $otDate = (string) $request['overtime_date'];
        // Only the verified separate OT Time In/Out pair determines payable OT.
        $hours = $this->totalHoursFor($request);
        if ($hours <= 0) {
            throw new ValidationException(['overtime' =>
                'OT cannot be approved for payroll without completed OT QR Time In and Time Out scans.']);
        }

        $attendance = $this->engine->findAttendance($employeeId, $otDate);

        if ($attendance === null) {
            // The day's record may be sitting in archive (it still holds the
            // unique key): refuse instead of crashing on a duplicate insert.
            $archived = Database::selectOne(
                'SELECT id FROM attendance WHERE employee_id = :emp AND attendance_date = :date AND deleted_at IS NOT NULL LIMIT 1',
                ['emp' => $employeeId, 'date' => $otDate]
            );
            if ($archived !== null) {
                throw new RuntimeException('The attendance record for this date is in archive. Restore it before approving overtime.');
            }

            // No attendance row yet: create one so the OT is not lost.
            $context = $this->engine->contextFor($employeeId, $otDate);

            $attendanceId = Database::insert('attendance', [
                'employee_id'      => $employeeId,
                'attendance_date'  => $otDate,
                'shift_id'         => $context['shift']['id'] ?? null,
                'work_schedule_id' => $context['schedule_id'],
                'scheduled_start'  => $context['shift'] !== null ? substr((string) $context['shift']['start_time'], 0, 8) : null,
                'scheduled_end'    => $context['shift'] !== null ? substr((string) $context['shift']['end_time'], 0, 8) : null,
                'overtime_hours'   => $hours,
                'status'           => 'PRESENT',
                'source'           => 'AUTO',
                'remarks'          => 'Overtime applied',
            ]);

            Database::execute(
                'UPDATE overtime_requests SET applied_hours = :hours WHERE id = :id',
                ['hours' => $hours, 'id' => $requestId]
            );

            return;
        }

        // Never trust old attendance.overtime_hours: historical MANUAL rows
        // sometimes contain 9 hours without ANY OT assignment. Sum only
        // earlier payroll-verified OT requests for this employee/date.
        $previousVerifiedHours = (float)(Database::scalar(
            "SELECT COALESCE(SUM(applied_hours),0) FROM overtime_requests
              WHERE employee_id = :emp AND overtime_date = :date AND id <> :request
                AND status = 'APPROVED' AND payroll_verified_at IS NOT NULL",
            ['emp'=>$employeeId,'date'=>$otDate,'request'=>$requestId]
        ) ?? 0);
        Database::execute(
            'UPDATE attendance SET overtime_hours = :hours WHERE id = :id',
            ['hours' => round($previousVerifiedHours + $hours, 2), 'id' => (int) $attendance['id']]
        );
        Database::execute(
            'UPDATE overtime_requests SET applied_hours = :hours WHERE id = :id',
            ['hours' => $hours, 'id' => $requestId]
        );
    }

    /** Detect the OT type from the employee's schedule and the holiday calendar. */
    private function detectType(int $employeeId, string $date): string
    {
        $context = $this->engine->contextFor($employeeId, $date);

        if ($context['holiday'] !== null) {
            return 'HOLIDAY';
        }

        if ($context['is_rest_day']) {
            return 'REST_DAY';
        }

        if (($context['shift']['is_overnight'] ?? 0) === 1) {
            return 'NIGHT';
        }

        return 'REGULAR';
    }

    private function normaliseTime(string $time): string
    {
        return strlen($time) === 5 ? $time . ':00' : $time;
    }
}