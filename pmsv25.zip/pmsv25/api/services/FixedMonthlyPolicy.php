<?php
declare(strict_types=1);
namespace App\Services;

/** Transparent, database-independent retail fixed-monthly salary arithmetic. */
final class FixedMonthlyPolicy
{
    public static function dailyRate(float $monthlySalary, float $annualDivisor = 365): float
    {
        if ($monthlySalary < 0 || $annualDivisor <= 0) {
            throw new \InvalidArgumentException('Salary and divisor must be valid.');
        }
        return ($monthlySalary * 12.0) / $annualDivisor;
    }

    public static function cutoffBasic(float $monthlySalary, string $from, string $to, ?string $hireDate = null): float
    {
        $start = new \DateTimeImmutable($from);
        $end = new \DateTimeImmutable($to);
        if ($end < $start) { throw new \InvalidArgumentException('Cutoff end before start.'); }
        $days = $start->diff($end)->days + 1;
        $actualStart = $hireDate !== null && $hireDate !== ''
            ? max($from, $hireDate) : $from;
        if ($actualStart > $to) { return 0.0; }
        $covered = (new \DateTimeImmutable($actualStart))->diff($end)->days + 1;
        return round($monthlySalary / 2.0 * $covered / $days, 2);
    }

    public static function earnedBasic(float $nominalBasic, float $absence, float $unpaidLeave, float $late, float $undertime): float
    {
        return round(max(0.0, $nominalBasic - $absence - $unpaidLeave - $late - $undertime), 2);
    }
}
