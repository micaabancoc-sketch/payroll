<?php
/**
 * Individual payroll payments & disbursement ledger (Phase 5).
 *
 * A payroll period moves Draft -> ... -> FINALIZED -> PAID, but before this
 * module the FINALIZED -> PAID step was a single flag flip: no record of who
 * was paid, how much, how, or when. This service is the per-employee ledger
 * behind that flag.
 *
 * Each row of `payroll` (one employee in one period) is disbursed through one
 * or more rows of `payroll_payments`:
 *
 *   COMPLETED  money moved (or confirmed moved for cash/manual). Only these
 *              rows add to `payroll.amount_paid`.
 *   PENDING    a confirmed intent recorded first (e.g. transfer instructed but
 *              not yet confirmed). Holds no money; complete() or fail() it.
 *   FAILED     an attempt that moved nothing. Kept for history, never reduces
 *              the balance.
 *   CANCELLED  a COMPLETED or PENDING row reversed by an authorised user.
 *              Excluded from paid totals; history is preserved, never deleted.
 *
 * `payroll.amount_paid` / `payroll.payment_status` (UNPAID / PARTIAL / PAID)
 * are cached on the payroll row inside the same transaction that writes the
 * ledger, so the FINALIZED -> PAID gate is a cheap indexed read.
 *
 * Eligibility: only rows in FINALIZED periods may be paid. DRAFT /
 * CALCULATING / FOR_REVIEW / APPROVED rows are still recalculable, CANCELLED
 * does not exist in this workflow, and PAID-period rows are already settled.
 * Zero-net rows (net_pay <= 0) need no disbursement and read as PAID.
 *
 * Idempotency: callers may pass `idempotency_key`. A retried request with the
 * same key returns the original ledger row instead of writing a second one.
 * `reference_no` (PAY-YYYYMMDD-XXXXXX) is unique per row.
 *
 * This ledger is for regular salary only. Loan repayments live in
 * `loan_payments` and 13th-month payments in `thirteenth_payments`; this
 * service never writes to either table.
 */

declare(strict_types=1);

namespace App\Services;

use App\Core\AuditLogger;
use App\Core\Auth;
use App\Core\Database;
use App\Core\ValidationException;
use RuntimeException;
use Throwable;

final class PayrollPaymentService
{
    /** Ledger row states, matching the `payroll_payments.payment_status` enum. */
    public const STATUSES = [
        'PENDING'   => 'Pending',
        'COMPLETED' => 'Completed',
        'FAILED'    => 'Failed attempt',
        'CANCELLED' => 'Cancelled / reversed',
    ];

    /** Payment methods, matching the `payroll_payments.payment_method` enum. */
    public const METHODS = [
        'CASH'          => 'Cash',
        'BANK_TRANSFER' => 'Bank Transfer',
        'GCASH'         => 'GCash',
        'OTHER'         => 'Other',
    ];

    /** Cached aggregate states on `payroll.payment_status`. */
    public const ROW_STATUSES = ['UNPAID', 'PARTIAL', 'PAID'];

    /** Only FINALIZED periods may be disbursed (PAID periods are settled). */
    public const ELIGIBLE_PERIOD_STATUS = 'FINALIZED';

    /**
     * Ledger rows for one payroll row, newest first, with the cached totals.
     *
     * @return array{payroll: array<string, mixed>, payments: list<array<string, mixed>>}
     */
    public function forPayroll(int $payrollId): array
    {
        $payroll = $this->row($payrollId);

        return [
            'payroll'  => $this->presentRow($payroll),
            'payments' => $this->ledgerFor((int) $payroll['id']),
        ];
    }

    /** Ledger rows + per-row balances for a whole period. */
    public function forPeriod(int $periodId): array
    {
        $period = Database::selectOne(
            'SELECT * FROM payroll_periods WHERE id = :id LIMIT 1',
            ['id' => $periodId]
        );

        if ($period === null) {
            throw new RuntimeException('Payroll period not found.');
        }

        $rows = Database::select(
            'SELECT p.*, e.employee_number, e.first_name, e.middle_name, e.last_name, e.suffix
               FROM payroll p
               JOIN employees e ON e.id = p.employee_id
              WHERE p.payroll_period_id = :pid
              ORDER BY e.employee_number',
            ['pid' => $periodId]
        );

        $items = [];
        foreach ($rows as $row) {
            $presented = $this->presentRow($row);
            $presented['payments'] = $this->ledgerFor((int) $row['id']);
            $items[] = $presented;
        }

        return ['period' => $period, 'items' => $items];
    }

    /** Dropdown vocabularies for the Payments page. */
    public function options(): array
    {
        return [
            'payment_statuses' => self::STATUSES,
            'payment_methods'  => self::METHODS,
            'row_statuses'     => self::ROW_STATUSES,
        ];
    }

    /** Marker A: record() part 1 (idempotency + validation). */
    public function record(int $payrollId, array $data, ?int $userId = null): array
    {
        $userId = $userId ?? Auth::id();
        $key    = trim((string) ($data['idempotency_key'] ?? ''));

        if ($key !== '') {
            $existing = Database::selectOne(
                'SELECT * FROM payroll_payments WHERE idempotency_key = :key LIMIT 1',
                ['key' => $key]
            );
            if ($existing !== null) {
                if ((int) $existing['payroll_id'] !== $payrollId) {
                    throw new ValidationException([
                        'idempotency_key' => 'This idempotency key was used for a different payroll record.',
                    ]);
                }
                return [
                    'payment' => $this->presentPayment($existing),
                    'payroll' => $this->presentRow($this->row($payrollId)),
                    'replayed' => true,
                ];
            }
        }

        return Database::transaction(function () use ($payrollId, $data, $key, $userId): array {
            $locked = $this->lockRow($payrollId);
            $period = $this->periodOf($locked);
            $this->assertPayable($locked, $period);
            if (\App\Core\DemoStaffScope::limitedDemoScope()) {
                \App\Core\DemoStaffScope::assertIncluded((int)$locked['employee_id']);
            }

            $amount = $this->parseAmount($data['amount'] ?? null);
            $method = strtoupper(trim((string) ($data['payment_method'] ?? 'CASH')));
            if (!isset(self::METHODS[$method])) {
                throw new ValidationException(['payment_method' => 'Choose Cash, Bank Transfer, GCash or Other.']);
            }

            $intent = strtoupper(trim((string) ($data['payment_status'] ?? 'COMPLETED')));
            if (!in_array($intent, ['COMPLETED', 'PENDING'], true)) {
                throw new ValidationException(['payment_status' => 'New payments use Completed or Pending.']);
            }

            $balance = $this->balanceDue($locked);
            if ($balance <= 0) {
                throw new RuntimeException('This payroll record is already fully paid.');
            }
            if ($amount > $balance) {
                throw new ValidationException([
                    'amount' => sprintf(
                        'That exceeds the outstanding balance of %s. Record %s or less.',
                        number_format($balance, 2),
                        number_format($balance, 2)
                    ),
                ]);
            }

            $confirmed = $data['confirmed'] ?? null;
            $isConfirm = $confirmed === true || $confirmed === 1 || $confirmed === '1'
                || (is_string($confirmed) && strtolower($confirmed) === 'true');
            if ($intent === 'COMPLETED' && !$isConfirm) {
                throw new ValidationException([
                    'confirmed' => 'Confirm the disbursement actually occurred. A method alone is not proof money moved.',
                ]);
            }

            $now = date('Y-m-d H:i:s');
            $paymentDate = trim((string) ($data['payment_date'] ?? ''));
            if ($paymentDate === '') {
                $paymentDate = substr($now, 0, 10);
            } elseif (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $paymentDate)) {
                throw new ValidationException(['payment_date' => 'Payment date must use YYYY-MM-DD format.']);
            }

            // An explicitly enabled one-staff TEST is never evidence of a real bank transfer.
            $notes = $this->nullIfEmpty($data['notes'] ?? $data['reason'] ?? null, 500);
            if (\App\Core\DemoStaffScope::limitedDemoScope()) {
                $notes = mb_substr('[LOCAL DEMO SIMULATION] ' . (string) $notes, 0, 500);
            }
            $paymentId = Database::insert('payroll_payments', [
                'payroll_id'        => (int) $locked['id'],
                'payroll_period_id' => (int) $locked['payroll_period_id'],
                'employee_id'       => (int) $locked['employee_id'],
                'reference_no'      => $this->newReference(),
                'idempotency_key'   => $key !== '' ? $key : null,
                'amount'            => $amount,
                'payment_method'    => $method,
                'method_reference'  => $this->nullIfEmpty($data['method_reference'] ?? null, 150),
                'payment_status'    => $intent,
                'payment_date'      => $paymentDate,
                'paid_at'           => $intent === 'COMPLETED' ? $now : null,
                'recorded_by'       => $userId,
                'notes'             => $notes,
            ]);

            $this->refreshAggregates((int) $locked['id']);

            $payment = Database::selectOne('SELECT * FROM payroll_payments WHERE id = :id LIMIT 1', ['id' => $paymentId]);
            $row     = $this->row($payrollId);

            AuditLogger::record(
                AuditLogger::PAYROLL_PAYMENT_RECORDED,
                'payroll_payment',
                $paymentId,
                sprintf(
                    'Recorded %s payroll payment %s of %s via %s for %s (period %s)',
                    strtolower($intent),
                    $payment['reference_no'] ?? $paymentId,
                    number_format($amount, 2),
                    self::METHODS[$method],
                    $this->employeeLabel($locked),
                    $period['code'] ?? $period['id']
                ),
                null,
                $payment ?: null
            );

            return [
                'payment' => $this->presentPayment($payment ?? []),
                'payroll' => $this->presentRow($row),
                'replayed' => false,
            ];
        });
    }

    /** Marker B1: complete() a PENDING intent. */
    public function complete(int $paymentId, array $data = [], ?int $userId = null): array
    {
        $userId = $userId ?? Auth::id();

        return Database::transaction(function () use ($paymentId, $data, $userId): array {
            $payment = $this->lockPayment($paymentId);
            if ((string) $payment['payment_status'] !== 'PENDING') {
                throw new RuntimeException('Only pending payments can be completed.');
            }

            $locked = $this->lockRow((int) $payment['payroll_id']);
            if (\App\Core\DemoStaffScope::limitedDemoScope()) {
                \App\Core\DemoStaffScope::assertIncluded((int)$locked['employee_id']);
            }
            $period = $this->periodOf($locked);
            $this->assertPayable($locked, $period, true);

            $balance = $this->balanceDue($locked);
            $amount  = round((float) $payment['amount'], 2);
            if ($amount > $balance) {
                throw new ValidationException([
                    'amount' => sprintf(
                        'Completing this would exceed the outstanding balance of %s.',
                        number_format($balance, 2)
                    ),
                ]);
            }

            $confirmed = $data['confirmed'] ?? null;
            $isConfirm = $confirmed === true || $confirmed === 1 || $confirmed === '1'
                || (is_string($confirmed) && strtolower($confirmed) === 'true');
            if (!$isConfirm) {
                throw new ValidationException([
                    'confirmed' => 'Confirm the disbursement actually occurred before completing it.',
                ]);
            }

            $now = date('Y-m-d H:i:s');
            Database::update('payroll_payments', [
                'payment_status' => 'COMPLETED',
                'paid_at'        => $now,
            ], ['id' => $paymentId]);

            $this->refreshAggregates((int) $locked['id']);
            $row = $this->row((int) $locked['id']);
            $fresh = Database::selectOne('SELECT * FROM payroll_payments WHERE id = :id LIMIT 1', ['id' => $paymentId]);

            AuditLogger::record(
                AuditLogger::PAYROLL_PAYMENT_COMPLETED,
                'payroll_payment',
                $paymentId,
                sprintf('Completed pending payroll payment %s of %s', $fresh['reference_no'] ?? $paymentId, number_format($amount, 2)),
                ['payment_status' => 'PENDING'],
                $fresh ?: null
            );

            return ['payment' => $this->presentPayment($fresh ?? []), 'payroll' => $this->presentRow($row)];
        });
    }

    /** Marker B2a: fail() a PENDING or COMPLETED attempt record. */
    public function markFailed(int $paymentId, array $data = [], ?int $userId = null): array
    {
        $userId = $userId ?? Auth::id();
        $reason = trim((string) ($data['reason'] ?? $data['notes'] ?? ''));
        if ($reason === '') {
            throw new ValidationException(['reason' => 'A reason is required for a failed attempt.']);
        }

        return Database::transaction(function () use ($paymentId, $reason, $userId): array {
            $payment = $this->lockPayment($paymentId);
            $status  = (string) $payment['payment_status'];
            if (!in_array($status, ['PENDING', 'COMPLETED'], true)) {
                throw new RuntimeException('Only pending or completed payments can be marked failed.');
            }

            $locked = $this->lockRow((int) $payment['payroll_id']);
            if (\App\Core\DemoStaffScope::limitedDemoScope()) {
                \App\Core\DemoStaffScope::assertIncluded((int)$locked['employee_id']);
            }
            $now    = date('Y-m-d H:i:s');
            Database::update('payroll_payments', [
                'payment_status' => 'FAILED',
                'notes'          => $this->appendNote($payment['notes'] ?? null, 'Failed: ' . $reason),
            ], ['id' => $paymentId]);

            $this->refreshAggregates((int) $locked['id']);
            $row   = $this->row((int) $locked['id']);
            $fresh = Database::selectOne('SELECT * FROM payroll_payments WHERE id = :id LIMIT 1', ['id' => $paymentId]);

            AuditLogger::record(
                AuditLogger::PAYROLL_PAYMENT_FAILED,
                'payroll_payment',
                $paymentId,
                sprintf('Marked payroll payment %s as failed: %s', $fresh['reference_no'] ?? $paymentId, $reason),
                ['payment_status' => $status],
                $fresh ?: null
            );

            return ['payment' => $this->presentPayment($fresh ?? []), 'payroll' => $this->presentRow($row)];
        });
    }

    /** Marker B2b1: cancel() a COMPLETED or PENDING row. */
    public function cancel(int $paymentId, array $data = [], ?int $userId = null): array
    {
        $userId = $userId ?? Auth::id();
        $reason = trim((string) ($data['reason'] ?? $data['cancel_reason'] ?? ''));
        if ($reason === '') {
            throw new ValidationException(['reason' => 'A cancellation reason is required.']);
        }

        return Database::transaction(function () use ($paymentId, $reason, $userId): array {
            $payment = $this->lockPayment($paymentId);
            $status  = (string) $payment['payment_status'];
            if (!in_array($status, ['COMPLETED', 'PENDING'], true)) {
                throw new RuntimeException('Only completed or pending payments can be cancelled.');
            }

            $locked = $this->lockRow((int) $payment['payroll_id']);
            if (\App\Core\DemoStaffScope::limitedDemoScope()) {
                \App\Core\DemoStaffScope::assertIncluded((int)$locked['employee_id']);
            }
            $now    = date('Y-m-d H:i:s');
            Database::update('payroll_payments', [
                'payment_status' => 'CANCELLED',
                'cancelled_by'   => $userId,
                'cancelled_at'   => $now,
                'cancel_reason'  => mb_substr($reason, 0, 255),
                'notes'          => $this->appendNote($payment['notes'] ?? null, 'Cancelled: ' . $reason),
            ], ['id' => $paymentId]);

            $this->refreshAggregates((int) $locked['id']);
            $row   = $this->row((int) $locked['id']);
            $fresh = Database::selectOne('SELECT * FROM payroll_payments WHERE id = :id LIMIT 1', ['id' => $paymentId]);

            AuditLogger::record(
                AuditLogger::PAYROLL_PAYMENT_CANCELLED,
                'payroll_payment',
                $paymentId,
                sprintf('Cancelled payroll payment %s of %s: %s', $fresh['reference_no'] ?? $paymentId, number_format((float) $payment['amount'], 2), $reason),
                ['payment_status' => $status],
                $fresh ?: null
            );

            return ['payment' => $this->presentPayment($fresh ?? []), 'payroll' => $this->presentRow($row)];
        });
    }

    /** Marker C1: eligibility + locking. */
    private function row(int $payrollId): array
    {
        $row = Database::selectOne(
            'SELECT p.*, pp.code AS period_code, pp.status AS period_status,
                    e.employee_number, e.first_name, e.middle_name, e.last_name, e.suffix
               FROM payroll p
               JOIN payroll_periods pp ON pp.id = p.payroll_period_id
               JOIN employees e ON e.id = p.employee_id
              WHERE p.id = :id LIMIT 1',
            ['id' => $payrollId]
        );
        if ($row === null) {
            throw new RuntimeException('Payroll record not found.');
        }
        return $row;
    }

    /** Marker C2a: lock helpers. */
    private function lockRow(int $payrollId): array
    {
        $row = Database::selectOne(
            'SELECT p.*, e.first_name, e.middle_name, e.last_name, e.suffix, e.employee_number
               FROM payroll p JOIN employees e ON e.id = p.employee_id
              WHERE p.id = :id LIMIT 1 FOR UPDATE',
            ['id' => $payrollId]
        );
        if ($row === null) {
            throw new RuntimeException('Payroll record not found.');
        }
        return $row;
    }

    private function lockPayment(int $paymentId): array
    {
        $row = Database::selectOne(
            'SELECT * FROM payroll_payments WHERE id = :id LIMIT 1 FOR UPDATE',
            ['id' => $paymentId]
        );
        if ($row === null) {
            throw new RuntimeException('Payroll payment not found.');
        }
        return $row;
    }

    private function periodOf(array $payrollRow): array
    {
        $period = Database::selectOne(
            'SELECT * FROM payroll_periods WHERE id = :id LIMIT 1',
            ['id' => (int) $payrollRow['payroll_period_id']]
        );
        if ($period === null) {
            throw new RuntimeException('Payroll period not found.');
        }
        return $period;
    }

    /** Marker C2b1: only FINALIZED rows may be paid. */
    private function assertPayable(array $payrollRow, array $period, bool $isFollowUp = false): void
    {
        $status = (string) ($period['status'] ?? '');
        if ($status === 'PAID') {
            throw new RuntimeException('This payroll period is already marked paid.');
        }
        if ($status !== self::ELIGIBLE_PERIOD_STATUS) {
            throw new RuntimeException(sprintf(
                'Payments require a FINALIZED payroll period (current status: %s).',
                $status === '' ? 'unknown' : $status
            ));
        }
        if (!$isFollowUp && (string) ($payrollRow['payment_status'] ?? '') === 'PAID') {
            throw new RuntimeException('This payroll record is already fully paid.');
        }
    }

    /** Marker C2c1: cached totals. */
    private function balanceDue(array $payrollRow): float
    {
        $net  = round((float) ($payrollRow['net_pay'] ?? 0), 2);
        if ($net <= 0) {
            return 0.0;
        }
        $paid = $this->completedTotal((int) $payrollRow['id']);
        return round(max(0.0, $net - $paid), 2);
    }

    private function completedTotal(int $payrollId): float
    {
        return round((float) (Database::scalar(
            "SELECT COALESCE(SUM(amount), 0) FROM payroll_payments
              WHERE payroll_id = :id AND payment_status = 'COMPLETED'",
            ['id' => $payrollId]
        ) ?? 0), 2);
    }

    private function refreshAggregates(int $payrollId): void
    {
        $row  = $this->row($payrollId);
        $net  = round((float) ($row['net_pay'] ?? 0), 2);
        $paid = $this->completedTotal($payrollId);
        $paid = min($paid, max(0.0, $net));
        $status = 'UNPAID';
        if ($net <= 0 || $paid >= $net) {
            $status = 'PAID';
            $paid   = max(0.0, $net);
        } elseif ($paid > 0) {
            $status = 'PARTIAL';
        }
        Database::update('payroll', ['amount_paid' => $paid, 'payment_status' => $status], ['id' => $payrollId]);
    }

    /** Marker C2d1: presenters. */
    private function presentRow(array $row): array
    {
        $net   = round((float) ($row['net_pay'] ?? 0), 2);
        $paid  = round((float) ($row['amount_paid'] ?? $this->completedTotal((int) ($row['id'] ?? 0))), 2);
        $due   = $net <= 0 ? 0.0 : round(max(0.0, $net - $paid), 2);
        $state = (string) ($row['payment_status'] ?? '');
        if ($state === '') {
            $state = $net <= 0 || $paid >= $net ? 'PAID' : ($paid > 0 ? 'PARTIAL' : 'UNPAID');
        }
        $row['net_pay']        = $net;
        $row['amount_paid']    = $paid;
        $row['balance_due']    = $due;
        $row['payment_status'] = $state;
        $row['full_name']      = $this->employeeLabel($row);
        return $row;
    }

    private function ledgerFor(int $payrollId): array
    {
        $rows = Database::select(
            'SELECT pp.*, u.username AS recorded_by_username
               FROM payroll_payments pp
               LEFT JOIN users u ON u.id = pp.recorded_by
              WHERE pp.payroll_id = :id
              ORDER BY pp.id DESC',
            ['id' => $payrollId]
        );
        return array_map([$this, 'presentPayment'], $rows);
    }

    private function presentPayment(array $payment): array
    {
        if (isset($payment['amount'])) {
            $payment['amount'] = round((float) $payment['amount'], 2);
        }
        $payment['payment_method_label'] = self::METHODS[(string) ($payment['payment_method'] ?? '')] ?? (string) ($payment['payment_method'] ?? '');
        $payment['payment_status_label'] = self::STATUSES[(string) ($payment['payment_status'] ?? '')] ?? (string) ($payment['payment_status'] ?? '');
        return $payment;
    }

    /** Tiny helpers + the FINALIZED -> PAID readiness summary. */
    private function parseAmount(mixed $value): float
    {
        if (!is_numeric($value)) {
            throw new ValidationException(['amount' => 'Enter a payment amount greater than zero.']);
        }
        $amount = round((float) $value, 2);
        if ($amount <= 0) {
            throw new ValidationException(['amount' => 'Enter a payment amount greater than zero.']);
        }
        return $amount;
    }

    private function nullIfEmpty(mixed $value, int $max): ?string
    {
        $text = trim((string) ($value ?? ''));
        if ($text === '') {
            return null;
        }
        return mb_substr($text, 0, $max);
    }

    private function appendNote(mixed $current, string $addition): string
    {
        $base = trim((string) ($current ?? ''));
        $glue = $base === '' ? '' : ' | ';
        return mb_substr($base . $glue . $addition, 0, 500);
    }

    private function employeeLabel(array $row): string
    {
        $name = trim(implode(' ', array_filter([
            $row['first_name'] ?? '', $row['middle_name'] ?? '',
            $row['last_name'] ?? '', $row['suffix'] ?? '',
        ], static fn (mixed $v): bool => (string) $v !== '')));
        $num = trim((string) ($row['employee_number'] ?? ''));
        if ($name === '') {
            return $num === '' ? ('Employee #' . ($row['employee_id'] ?? '?')) : $num;
        }
        return $num === '' ? $name : sprintf('%s (%s)', $name, $num);
    }

    private function newReference(): string
    {
        for ($attempt = 0; $attempt < 5; $attempt++) {
            $ref = sprintf('PAY-%s-%s', date('Ymd'), strtoupper(substr(bin2hex(random_bytes(3)), 0, 6)));
            $hit = Database::scalar('SELECT id FROM payroll_payments WHERE reference_no = :ref LIMIT 1', ['ref' => $ref]);
            if ($hit === null) {
                return $ref;
            }
        }
        return sprintf('PAY-%s-%s', date('YmdHis'), strtoupper(substr(bin2hex(random_bytes(3)), 0, 6)));
    }

    /** Period-level readiness for the FINALIZED -> PAID gate. */
    public function periodReadiness(int $periodId): array
    {
        try {
            $counts = Database::selectOne(
                "SELECT COUNT(*) AS total,
                        SUM(payment_status = 'PAID') AS paid,
                        SUM(payment_status = 'PARTIAL') AS partial,
                        SUM(payment_status = 'UNPAID') AS unpaid
                   FROM payroll WHERE payroll_period_id = :pid",
                ['pid' => $periodId]
            );
        } catch (Throwable $e) {
            // Refuse to mark a period PAID when ledger readiness cannot be verified.
            throw new RuntimeException('Could not verify salary payment status; do not mark this payroll paid.', 0, $e);
        }

        if (!is_array($counts) || $counts['total'] === null) {
            throw new RuntimeException('Could not verify salary payment totals.');
        }

        $total   = (int) $counts['total'];
        $paid    = (int) $counts['paid'];
        $unpaid  = (int) $counts['unpaid'];
        $partial = (int) $counts['partial'];

        return [
            'total'   => $total,
            'paid'    => $paid,
            'unpaid'  => $unpaid,
            'partial' => $partial,
            'ready'   => $total === 0 || ($unpaid === 0 && $partial === 0),
        ];
    }
}

