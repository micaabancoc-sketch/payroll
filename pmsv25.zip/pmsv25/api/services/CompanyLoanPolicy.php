<?php
declare(strict_types=1);
namespace App\Services;

/** Fixed company policy, separate from SSS and Pag-IBIG agency amortizations. */
final class CompanyLoanPolicy
{
    public static function terms(string $type, float $principal, int $months): array
    {
        $type = strtoupper($type);
        if (!in_array($type, ['SALARY_LOAN', 'CASH_ADVANCE'], true)) {
            throw new \InvalidArgumentException('Only company loans or salary advances use company terms.');
        }
        $max = $type === 'CASH_ADVANCE' ? 2 : 12;
        if ($months < 1 || $months > $max || $principal <= 0) {
            throw new \InvalidArgumentException('Invalid loan amount or repayment term.');
        }
        $rate = 0.0; // No interest without a separately documented and lawfully approved company policy.
        $interest = round($principal * $rate / 100, 2);
        $total = round($principal + $interest, 2);
        $periods = $months * 2;
        return [
            'interest_rate' => $rate, 'interest_amount' => $interest,
            'total_repayment' => $total, 'months' => $months,
            'cutoffs' => $periods, 'monthly_deduction' => round($total / $months, 2),
            'per_cutoff' => round($total / $periods, 2),
        ];
    }
    public static function maxPrincipal(string $type, float $salary): float
    {
        return round(max(0.0, $salary) * (strtoupper($type) === 'CASH_ADVANCE' ? 0.5 : 1.0), 2);
    }
}
