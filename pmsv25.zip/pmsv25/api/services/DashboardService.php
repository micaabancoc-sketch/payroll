<?php
/**
 * Dashboard aggregates (Phase 16).
 *
 * Cards: Employees, Present, Late, Absent, On Leave, Overtime, Pending Leave,
 * Pending OT. Sections: today's attendance, pending approvals, payroll status,
 * charts and recent activities.
 */

declare(strict_types=1);

namespace App\Services;

use App\Core\AuditLogger;
use App\Core\Database;

final class DashboardService
{
    public function __construct(
        private AttendanceService $attendance = new AttendanceService(),
        private LeaveService $leave = new LeaveService(),
        private OvertimeService $overtime = new OvertimeService(),
        private HolidayService $holidays = new HolidayService()
    ) {
    }

    /** @return array<string, mixed> */
    public function overview(int $employeeId): array
    {
        if ($employeeId > 0) {
            return $this->employeeOverview($employeeId);
        }

        $today = $this->attendance->todayOverview();

        return [
            'date'              => date('Y-m-d'),
            'cards'             => $this->cards($today['summary']),
            'today_attendance'  => $today,
            'pending_leave'     => $this->pendingLeave(),
            'pending_overtime'  => $this->pendingOvertime(),
            'payroll'           => $this->payrollStatus(),
            'charts'            => $this->charts(),
            'holidays'          => $this->holidays->upcoming(5),
            'recent_activities' => $this->recentActivities(),
            'my_counts'         => [
                'pending_leave'    => $this->leave->pendingCount($employeeId),
                'pending_overtime' => $this->overtime->pendingCount($employeeId),
            ],
        ];
    }

    /** Staff dashboard: deliberately scoped to the linked employee only. */
    private function employeeOverview(int $employeeId): array
    {
        $attendance = Database::selectOne(
            'SELECT * FROM attendance WHERE employee_id = :employee AND attendance_date = CURDATE() AND deleted_at IS NULL LIMIT 1',
            ['employee' => $employeeId]
        );
        $recent = Database::select(
            'SELECT al.event_type, al.scanned_at, al.result,
                    e.employee_number, e.first_name, e.middle_name, e.last_name, e.suffix,
                    d.name AS department_name, a.status AS attendance_status
               FROM attendance_logs al
               JOIN employees e ON e.id = al.employee_id
               LEFT JOIN departments d ON d.id = e.department_id
               LEFT JOIN attendance a ON a.id = al.attendance_id
              WHERE al.employee_id = :employee AND DATE(al.scanned_at) = CURDATE()
                AND (a.id IS NULL OR a.deleted_at IS NULL)
              ORDER BY al.scanned_at DESC LIMIT 10',
            ['employee' => $employeeId]
        );

        foreach ($recent as &$row) {
            $row['full_name'] = trim(implode(' ', array_filter([
                $row['first_name'], $row['middle_name'], $row['last_name'], $row['suffix'],
            ], static fn (mixed $value): bool => (string) $value !== '')));
        }
        unset($row);

        $status = (string) ($attendance['status'] ?? '');
        $summary = [
            'present' => in_array($status, ['PRESENT', 'LATE', 'UNDERTIME'], true) ? 1 : 0,
            'late' => $status === 'LATE' ? 1 : 0,
            'absent' => $status === 'ABSENT' ? 1 : 0,
            'on_leave' => $status === 'LEAVE' ? 1 : 0,
            'overtime_hours' => (float) ($attendance['overtime_hours'] ?? 0),
        ];

        $pendingLeave = Database::select(
            'SELECT lr.id, lr.start_date, lr.end_date, lr.days, lr.reason, lr.created_at,
                    lt.name AS leave_type_name, e.employee_number,
                    CONCAT_WS(" ", e.first_name, e.middle_name, e.last_name, e.suffix) AS full_name
               FROM leave_requests lr
               JOIN leave_types lt ON lt.id = lr.leave_type_id
               JOIN employees e ON e.id = lr.employee_id
               WHERE lr.employee_id = :employee AND lr.status = :status AND lr.deleted_at IS NULL
               ORDER BY lr.created_at ASC LIMIT 8',
            ['employee' => $employeeId, 'status' => 'PENDING']
        );
        $otStatuses = chr(39) . 'PENDING' . chr(39) . ',' . chr(39) . 'ACCEPTED' . chr(39) . ',' . chr(39) . 'COMPLETED' . chr(39);
        $pendingOvertime = Database::select(
            'SELECT o.id, o.overtime_date, o.start_time, o.end_time, o.hours, o.total_hours, o.status, o.reason,
                    e.employee_number,
                    CONCAT_WS(" ", e.first_name, e.middle_name, e.last_name, e.suffix) AS full_name
               FROM overtime_requests o
               JOIN employees e ON e.id = o.employee_id
               WHERE o.employee_id = :employee AND o.status IN (' . $otStatuses . ') AND o.deleted_at IS NULL
               ORDER BY o.overtime_date ASC LIMIT 8',
            ['employee' => $employeeId]
        );

        $payroll = Database::selectOne(
            'SELECT pp.id, pp.code, pp.name, pp.start_date, pp.end_date, pp.pay_date, pp.status,
                    p.gross_pay AS total_gross, p.total_deductions, p.net_pay AS total_net,
                    1 AS employee_count
               FROM payroll p
               JOIN payroll_periods pp ON pp.id = p.payroll_period_id
              WHERE p.employee_id = :employee AND pp.deleted_at IS NULL
                AND pp.end_date <= CURDATE() AND pp.status IN (:finalized, :paid)
              ORDER BY pp.end_date DESC, pp.id DESC LIMIT 1',
            ['employee' => $employeeId, 'finalized' => 'FINALIZED', 'paid' => 'PAID']
        );

        return [
            'date' => date('Y-m-d'),
            'cards' => [
                'employees' => 1,
                'present' => $summary['present'],
                'late' => $summary['late'],
                'absent' => $summary['absent'],
                'on_leave' => $summary['on_leave'],
                'overtime_hours' => $summary['overtime_hours'],
                'pending_leave' => $this->leave->pendingCount($employeeId),
                'pending_ot' => $this->overtime->pendingCount($employeeId),
            ],
            'today_attendance' => ['summary' => $summary, 'recent' => $recent],
            'pending_leave' => $pendingLeave,
            'pending_overtime' => $pendingOvertime,
            'payroll' => $payroll,
            'charts' => [
                'attendance_trend' => $this->employeeAttendanceTrend($employeeId),
                'status_breakdown' => $this->employeeStatusBreakdown($employeeId),
                'payroll_trend' => [],
                'department_stats' => [],
            ],
            'holidays' => $this->holidays->upcoming(5),
            'recent_activities' => [],
            'my_counts' => [
                'pending_leave' => $this->leave->pendingCount($employeeId),
                'pending_overtime' => $this->overtime->pendingCount($employeeId),
            ],
        ];
    }

    /** @return list<array<string, mixed>> */
    private function employeeAttendanceTrend(int $employeeId): array
    {
        return Database::select(
            'SELECT attendance_date AS date,
                    SUM(status IN (:present, :late, :undertime)) AS present,
                    SUM(status = :late_only) AS late,
                    SUM(status = :absent) AS absent,
                    SUM(status = :leave) AS on_leave
               FROM attendance
               WHERE employee_id = :employee
                 AND deleted_at IS NULL
                 AND attendance_date >= DATE_SUB(CURDATE(), INTERVAL 14 DAY)
               GROUP BY attendance_date ORDER BY attendance_date',
            [
                'employee' => $employeeId, 'present' => 'PRESENT', 'late' => 'LATE',
                'undertime' => 'UNDERTIME', 'late_only' => 'LATE', 'absent' => 'ABSENT', 'leave' => 'LEAVE',
            ]
        );
    }

    /** @return list<array<string, mixed>> */
    private function employeeStatusBreakdown(int $employeeId): array
    {
        return Database::select(
            'SELECT status, COUNT(*) AS count FROM attendance
               WHERE employee_id = :employee
                 AND deleted_at IS NULL
                 AND attendance_date >= DATE_SUB(CURDATE(), INTERVAL 30 DAY)
               GROUP BY status ORDER BY count DESC',
            ['employee' => $employeeId]
        );
    }

    /**
     * Dashboard cards (Phase 16).
     *
     * @param array<string, int|float> $summary
     * @return array<string, int|float>
     */
    public function cards(array $summary = []): array
    {
        $employees = (int) (Database::scalar(
            'SELECT COUNT(*) FROM employees
              WHERE status = :active AND archived_at IS NULL AND deleted_at IS NULL'
                . \App\Core\DemoStaffScope::excludingRoles('employees.id')
                . \App\Core\DemoStaffScope::excludingDemoUsernames('employees.id'),
            ['active' => 'ACTIVE']
        ) ?? 0);

        return [
            'employees'      => $employees,
            'present'        => (int) ($summary['present'] ?? 0),
            'late'           => (int) ($summary['late'] ?? 0),
            'absent'         => (int) ($summary['absent'] ?? 0),
            'on_leave'       => (int) ($summary['on_leave'] ?? 0),
            'overtime_hours' => (float) ($summary['overtime_hours'] ?? 0),
            'pending_leave'  => $this->leave->pendingCount(),
            'pending_ot'     => $this->overtime->pendingCount(),
        ];
    }

    /** @return list<array<string, mixed>> */
    public function pendingLeave(int $limit = 8): array
    {
        return Database::select(
            'SELECT lr.id, lr.start_date, lr.end_date, lr.days, lr.reason, lr.created_at,
                    lr.leave_type_id, lt.name AS leave_type_name, lt.code AS leave_type_code,
                    e.employee_number, e.first_name, e.middle_name, e.last_name, e.suffix,
                    d.name AS department_name
               FROM leave_requests lr
               JOIN leave_types lt ON lt.id = lr.leave_type_id
               JOIN employees e ON e.id = lr.employee_id
               LEFT JOIN departments d ON d.id = e.department_id
               WHERE lr.status = :pending AND lr.deleted_at IS NULL
               ORDER BY lr.created_at ASC
               LIMIT ' . max(1, $limit),
            ['pending' => 'PENDING']
        );
    }

    /** @return list<array<string, mixed>> */
    public function pendingOvertime(int $limit = 8): array
    {
        $statuses = chr(39) . 'PENDING' . chr(39) . ',' . chr(39) . 'ACCEPTED' . chr(39) . ',' . chr(39) . 'COMPLETED' . chr(39);
        return Database::select(
            'SELECT o.id, o.overtime_date, o.start_time, o.end_time, o.hours, o.total_hours, o.status,
                    o.reason, o.created_at,
                    o.ot_type, e.employee_number, e.first_name, e.middle_name, e.last_name, e.suffix,
                    d.name AS department_name
               FROM overtime_requests o
               JOIN employees e ON e.id = o.employee_id
               LEFT JOIN departments d ON d.id = e.department_id
               WHERE o.status IN (' . $statuses . ') AND o.deleted_at IS NULL
               ORDER BY o.overtime_date ASC
               LIMIT ' . max(1, $limit)
        );
    }

    /**
     * Current payroll status and summary (Phase 16).
     *
     * @return array<string, mixed>|null
     */
    public function payrollStatus(): ?array
    {
        $period = Database::selectOne(
            'SELECT pp.*, u.username AS created_by_username,
                    (SELECT COUNT(*) FROM payroll p WHERE p.payroll_period_id = pp.id) AS employee_count
               FROM payroll_periods pp
               LEFT JOIN users u ON u.id = pp.created_by
              WHERE pp.deleted_at IS NULL AND pp.end_date <= CURDATE()
              ORDER BY pp.end_date DESC, pp.id DESC
              LIMIT 1'
        );

        if ($period === null) {
            return null;
        }

        return [
            'id'               => (int) $period['id'],
            'code'             => $period['code'],
            'name'             => $period['name'],
            'start_date'       => $period['start_date'],
            'end_date'         => $period['end_date'],
            'pay_date'         => $period['pay_date'],
            'status'           => $period['status'],
            'total_gross'      => (float) $period['total_gross'],
            'total_deductions' => (float) $period['total_deductions'],
            'total_net'        => (float) $period['total_net'],
            'employee_count'   => (int) $period['employee_count'],
        ];
    }
/**
     * Attendance and payroll chart data (Phase 16).
     *
     * @return array<string, mixed>
     */
    public function charts(): array
    {
        return [
            'attendance_trend' => $this->attendanceTrend(14),
            'status_breakdown' => $this->statusBreakdown(30),
            'payroll_trend'    => $this->payrollTrend(6),
            'department_stats' => $this->departmentStats(),
        ];
    }

    /** Holidays normalized to the requested calendar year for dashboard viewing. */
    public function holidaysForYear(int $year): array
    {
        $year = max(2000, min(2100, $year));
        $rows = $this->holidays->all($year);

        foreach ($rows as &$row) {
            if ((int) ($row['is_recurring'] ?? 0) === 1) {
                $source = new \DateTimeImmutable((string) $row['holiday_date']);
                $row['holiday_date'] = sprintf('%04d-%02d-%02d', $year, (int) $source->format('n'), (int) $source->format('j'));
            }
        }
        unset($row);

        usort($rows, static fn (array $a, array $b): int => strcmp((string) $a['holiday_date'], (string) $b['holiday_date']));

        return $rows;
    }

    /**
     * Daily present/late/absent counts for the last N days (Phase 16).
     *
     * @return list<array<string, mixed>>
     */
    public function attendanceTrend(int $days = 14): array
    {
        return Database::select(
            'SELECT attendance_date AS date,
                    COALESCE(SUM(CASE WHEN status IN (:present, :late, :undertime) THEN 1 ELSE 0 END), 0) AS present,
                    COALESCE(SUM(CASE WHEN status = :late_only THEN 1 ELSE 0 END), 0) AS late,
                    COALESCE(SUM(CASE WHEN status = :absent THEN 1 ELSE 0 END), 0) AS absent,
                    COALESCE(SUM(CASE WHEN status = :leave THEN 1 ELSE 0 END), 0) AS on_leave
               FROM attendance
               WHERE attendance_date >= DATE_SUB(CURDATE(), INTERVAL :days DAY)
                 AND deleted_at IS NULL'
                 . \App\Core\DemoStaffScope::excludingRoles('attendance.employee_id')
                 . \App\Core\DemoStaffScope::excludingDemoUsernames('attendance.employee_id') . '
               GROUP BY attendance_date
               ORDER BY attendance_date',
            [
                'days'      => max(1, $days),
                'present'   => 'PRESENT',
                'late'      => 'LATE',
                'late_only' => 'LATE',
                'undertime' => 'UNDERTIME',
                'absent'    => 'ABSENT',
                'leave'     => 'LEAVE',
            ]
        );
    }

    /**
     * Status distribution over a period (Phase 16).
     *
     * @return list<array<string, mixed>>
     */
    public function statusBreakdown(int $days = 30): array
    {
        return Database::select(
            'SELECT status, COUNT(*) AS count
                FROM attendance
               WHERE attendance_date >= DATE_SUB(CURDATE(), INTERVAL :days DAY)
                 AND deleted_at IS NULL'
                 . \App\Core\DemoStaffScope::excludingRoles('attendance.employee_id')
                 . \App\Core\DemoStaffScope::excludingDemoUsernames('attendance.employee_id') . '
               GROUP BY status
               ORDER BY count DESC',
            ['days' => max(1, $days)]
        );
    }

    /**
     * Payroll totals for the last N periods (Phase 16).
     *
     * @return list<array<string, mixed>>
     */
    public function payrollTrend(int $periods = 6): array
    {
        return Database::select(
            'SELECT code, name, status, total_gross, total_deductions, total_net, start_date, end_date
               FROM payroll_periods
              WHERE deleted_at IS NULL AND end_date <= CURDATE()
              ORDER BY start_date DESC
              LIMIT ' . max(1, $periods)
        );
    }

    /**
     * Department statistics (Phase 16).
     *
     * @return list<array<string, mixed>>
     */
    public function departmentStats(): array
    {
        return Database::select(
            'SELECT d.id, d.name, d.code,
                    (SELECT COUNT(*) FROM employees e
                      WHERE e.department_id = d.id AND e.status = :active
                        AND e.archived_at IS NULL AND e.deleted_at IS NULL'
                        . \App\Core\DemoStaffScope::excludingRoles('e.id')
                        . \App\Core\DemoStaffScope::excludingDemoUsernames('e.id') . ') AS employee_count,
                    (SELECT COUNT(*) FROM attendance a
                       JOIN employees e2 ON e2.id = a.employee_id
                       WHERE e2.department_id = d.id AND a.attendance_date = CURDATE()
                         AND a.deleted_at IS NULL'
                         . \App\Core\DemoStaffScope::excludingRoles('a.employee_id')
                         . \App\Core\DemoStaffScope::excludingDemoUsernames('a.employee_id') . '
                         AND a.status IN (:present, :late, :undertime)) AS present_today
               FROM departments d
              WHERE d.deleted_at IS NULL AND d.is_active = 1
              ORDER BY d.name',
            ['active' => 'ACTIVE', 'present' => 'PRESENT', 'late' => 'LATE', 'undertime' => 'UNDERTIME']
        );
    }

    /**
     * Recent activities from the audit trail (Phase 16 / Phase 18).
     *
     * @return list<array<string, mixed>>
     */
    public function recentActivities(int $limit = 10): array
    {
        return AuditLogger::flagSampleRows(Database::select(
            'SELECT id, username, action, entity_type, entity_id, description, user_agent, created_at
               FROM audit_logs
              ORDER BY id DESC
              LIMIT ' . max(1, $limit)
        ));
    }

    /** @return array{items:list<array<string,mixed>>,total:int} */
    public function activityPage(array $filters, int $page, int $perPage): array
    {
        $where = ['1 = 1'];
        $params = [];

        if (($filters['q'] ?? '') !== '') {
            $where[] = '(description LIKE :q1 OR entity_type LIKE :q2)';
            $params['q1'] = '%' . $filters['q'] . '%';
            $params['q2'] = '%' . $filters['q'] . '%';
        }
        if (($filters['action'] ?? '') !== '') {
            $where[] = 'action LIKE :action';
            $params['action'] = '%' . $filters['action'] . '%';
        }
        if (($filters['username'] ?? '') !== '') {
            $where[] = 'username LIKE :username';
            $params['username'] = '%' . $filters['username'] . '%';
        }
        if (($filters['date_from'] ?? '') !== '') {
            $where[] = 'created_at >= :date_from';
            $params['date_from'] = $filters['date_from'] . ' 00:00:00';
        }
        if (($filters['date_to'] ?? '') !== '') {
            $where[] = 'created_at <= :date_to';
            $params['date_to'] = $filters['date_to'] . ' 23:59:59';
        }

        $whereSql = implode(' AND ', $where);
        $total = (int) (Database::scalar("SELECT COUNT(*) FROM audit_logs WHERE {$whereSql}", $params) ?? 0);
        $offset = max(0, ($page - 1) * $perPage);
        $items = Database::select(
            "SELECT id, username, action, entity_type, description, ip_address, user_agent, created_at
               FROM audit_logs WHERE {$whereSql}
              ORDER BY id DESC LIMIT {$perPage} OFFSET {$offset}",
            $params
        );

        // Same sample-data flag as /api/audit: rows written by the seeder are
        // badged in the dashboard feed instead of masquerading as real work.
        return ['items' => AuditLogger::flagSampleRows($items), 'total' => $total];
    }
}
