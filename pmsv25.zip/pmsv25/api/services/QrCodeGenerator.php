<?php
/**
 * Pure-PHP QR Code encoder (ISO/IEC 18004) — byte mode.
 *
 * Implemented from scratch so the system needs no Composer packages or
 * PHP extensions. Emits an SVG matrix, which every modern browser can
 * print, and the frontend can convert to PNG via canvas.
 *
 * Supports versions 1-10, error-correction levels L/M/Q/H, all 8 masks.
 */

declare(strict_types=1);

namespace App\Services;

final class QrCodeGenerator
{
    private const ECC_LEVELS = [
        'L' => 1,
        'M' => 0,
        'Q' => 3,
        'H' => 2,
    ];

    /**
     * Per version and ECC level:
     * [total codewords, ecc codewords per block, group1 blocks, group1 data codewords,
     *  group2 blocks, group2 data codewords]
     *
     * @var array<string, array<string, array{0:int,1:int,2:int,3:int,4:int,5:int}>>
     */
    private const VERSION_SPEC = [
        '1'  => ['L' => [26, 7, 1, 19, 0, 0],   'M' => [26, 10, 1, 16, 0, 0],  'Q' => [26, 13, 1, 13, 0, 0],  'H' => [26, 17, 1, 9, 0, 0]],
        '2'  => ['L' => [44, 10, 1, 34, 0, 0],  'M' => [44, 16, 1, 28, 0, 0],  'Q' => [44, 22, 1, 22, 0, 0],  'H' => [44, 28, 1, 16, 0, 0]],
        '3'  => ['L' => [70, 15, 1, 55, 0, 0],  'M' => [70, 26, 1, 44, 0, 0],  'Q' => [70, 18, 2, 17, 0, 0],  'H' => [70, 22, 2, 13, 0, 0]],
        '4'  => ['L' => [100, 20, 1, 80, 0, 0], 'M' => [100, 18, 2, 32, 0, 0], 'Q' => [100, 26, 2, 24, 0, 0], 'H' => [100, 16, 4, 9, 0, 0]],
        '5'  => ['L' => [134, 26, 1, 108, 0, 0],'M' => [134, 24, 2, 43, 0, 0], 'Q' => [134, 18, 2, 15, 2, 16],'H' => [134, 22, 2, 11, 2, 12]],
        '6'  => ['L' => [172, 18, 2, 68, 0, 0], 'M' => [172, 16, 4, 27, 0, 0], 'Q' => [172, 24, 4, 19, 0, 0], 'H' => [172, 28, 4, 15, 0, 0]],
        '7'  => ['L' => [196, 20, 2, 78, 0, 0], 'M' => [196, 18, 4, 31, 0, 0], 'Q' => [196, 18, 2, 14, 4, 15],'H' => [196, 26, 4, 13, 1, 14]],
        '8'  => ['L' => [242, 24, 2, 97, 0, 0], 'M' => [242, 22, 2, 38, 2, 39], 'Q' => [242, 22, 4, 18, 2, 19],'H' => [242, 26, 4, 14, 2, 15]],
        '9'  => ['L' => [292, 30, 2, 116, 0, 0],'M' => [292, 22, 3, 36, 2, 37], 'Q' => [292, 20, 4, 16, 4, 17],'H' => [292, 24, 4, 12, 4, 13]],
        '10' => ['L' => [346, 18, 2, 68, 2, 69], 'M' => [346, 26, 4, 43, 1, 44], 'Q' => [346, 24, 6, 19, 2, 20], 'H' => [346, 28, 6, 15, 2, 16]],
    ];

    /** Alignment pattern centre coordinates per version. */
    private const ALIGNMENT = [
        1 => [], 2 => [6, 18], 3 => [6, 22], 4 => [6, 26], 5 => [6, 30],
        6 => [6, 34], 7 => [6, 22, 38], 8 => [6, 24, 42], 9 => [6, 26, 46], 10 => [6, 28, 50],
    ];

    /** @var array<int, int> */
    private array $exp = [];
    /** @var array<int, int> */
    private array $log = [];
    private string $eccLevel = 'M';
    private int $selectedMask = 0;

    public function __construct()
    {
        // GF(256) log/antilog tables for the primitive polynomial 0x11D.
        $x = 1;
        for ($i = 0; $i < 255; $i++) {
            $this->exp[$i] = $x;
            $this->log[$x] = $i;
            $x <<= 1;
            if ($x & 0x100) {
                $x ^= 0x11D;
            }
        }
        for ($i = 255; $i < 512; $i++) {
            $this->exp[$i] = $this->exp[$i - 255];
        }
    }
/**
     * Encode text and return the module matrix (true = dark).
     *
     * $forcedMask is only used by the test-suite to compare against a
     * reference implementation; normal use always auto-selects the mask.
     *
     * @return array{matrix: list<list<bool>>, size: int, version: int, mask: int, codewords: list<int>}
     */
    public function encode(string $text, string $eccLevel = 'M', ?int $forcedMask = null): array
    {
        $this->eccLevel = isset(self::ECC_LEVELS[strtoupper($eccLevel)])
            ? strtoupper($eccLevel)
            : 'M';

        $bytes  = array_values(unpack('C*', $text) ?: []);
        $length = count($bytes);

        $version = 0;
        for ($v = 1; $v <= 10; $v++) {
            if ($this->dataCapacityBits($v) >= $this->totalDataBits($v, $length)) {
                $version = $v;
                break;
            }
        }

        if ($version === 0) {
            throw new \RuntimeException('Data too long for a QR code (maximum supported version is 10).');
        }

        $codewords   = $this->buildCodewords($bytes, $version);
        $interleaved = $this->interleaveWithEcc($codewords, $version);

        $matrix = $this->buildMatrix($interleaved, $version, $forcedMask);

        return [
            'matrix'    => $matrix,
            'size'      => 17 + (4 * $version),
            'version'   => $version,
            'mask'      => $this->selectedMask,
            'codewords' => $interleaved,
        ];
    }

    /**
     * Render an SVG string for the given matrix.
     *
     * @param list<list<bool>> $matrix
     */
    public function toSvg(
        array $matrix,
        int $scale = 8,
        int $quietZone = 4,
        string $dark = '#000000',
        string $light = '#ffffff'
    ): string {
        $size  = count($matrix);
        $total = $size + ($quietZone * 2);

        // One path element per dark run keeps the output compact.
        $paths = [];
        for ($y = 0; $y < $size; $y++) {
            $x = 0;
            while ($x < $size) {
                if ($matrix[$y][$x] !== true) {
                    $x++;
                    continue;
                }
                $runStart = $x;
                while ($x < $size && $matrix[$y][$x] === true) {
                    $x++;
                }
                $length = $x - $runStart;
                $paths[] = sprintf(
                    // The closing horizontal move is already negative, so the
                    // format must not add another sign: "h--8z" is invalid path
                    // data and makes a browser stop drawing mid-path.
                    'M%d %dh%dv%dh%dz',
                    ($runStart + $quietZone) * $scale,
                    ($y + $quietZone) * $scale,
                    $length * $scale,
                    $scale,
                    -$length * $scale
                );
            }
        }

        $dimension = $total * $scale;

        return sprintf(
            '<svg xmlns="http://www.w3.org/2000/svg" width="%1$d" height="%1$d" viewBox="0 0 %1$d %1$d"'
            . ' shape-rendering="crispEdges" role="img" aria-label="QR code">'
            . '<rect width="%1$d" height="%1$d" fill="%2$s"/>'
            . '<path d="%3$s" fill="%4$s"/></svg>',
            $dimension,
            $light,
            implode(' ', $paths),
            $dark
        );
    }

    // -----------------------------------------------------------------------
    // Capacity helpers
    // -----------------------------------------------------------------------

    private function dataCodewordCount(int $version): int
    {
        $spec = self::VERSION_SPEC[(string) $version][$this->eccLevel];
        return ($spec[2] * $spec[3]) + ($spec[4] * $spec[5]);
    }

    private function dataCapacityBits(int $version): int
    {
        return $this->dataCodewordCount($version) * 8;
    }

    private function totalDataBits(int $version, int $length): int
    {
        return 4 + $this->characterCountBits($version) + ($length * 8);
    }

    private function characterCountBits(int $version): int
    {
        return $version <= 9 ? 8 : 16;
    }
/**
     * Build the final data codewords: mode + length + payload + terminator + padding.
     *
     * @param list<int> $bytes
     * @return list<int>
     */
    private function buildCodewords(array $bytes, int $version): array
    {
        $dataCodewords = $this->dataCodewordCount($version);
        $bits = [];

        $this->appendBits($bits, 0b0100, 4);                                  // byte mode
        $this->appendBits($bits, count($bytes), $this->characterCountBits($version));

        foreach ($bytes as $byte) {
            $this->appendBits($bits, $byte, 8);
        }

        $capacityBits = $dataCodewords * 8;

        // Terminator: up to four zero bits, truncated if the capacity is nearly full.
        $terminator = min(4, $capacityBits - count($bits));
        if ($terminator > 0) {
            $this->appendBits($bits, 0, $terminator);
        }

        while (count($bits) % 8 !== 0) {
            $bits[] = 0;
        }

        $codewords = [];
        for ($i = 0; $i < count($bits); $i += 8) {
            $byte = 0;
            for ($j = 0; $j < 8; $j++) {
                $byte = ($byte << 1) | $bits[$i + $j];
            }
            $codewords[] = $byte;
        }

        // Pad codewords alternate 0xEC / 0x11.
        $padBytes = [0xEC, 0x11];
        $index = 0;
        while (count($codewords) < $dataCodewords) {
            $codewords[] = $padBytes[$index % 2];
            $index++;
        }

        return $codewords;
    }

    /**
     * Split into blocks, compute Reed-Solomon ECC and interleave.
     *
     * @param list<int> $data
     * @return list<int>
     */
    private function interleaveWithEcc(array $data, int $version): array
    {
        $spec = self::VERSION_SPEC[(string) $version][$this->eccLevel];
        $totalCodewords = $spec[0];
        $eccPerBlock    = $spec[1];

        $blocks = [];
        $offset = 0;

        for ($i = 0; $i < $spec[2]; $i++) {
            $blocks[] = array_slice($data, $offset, $spec[3]);
            $offset += $spec[3];
        }
        for ($i = 0; $i < $spec[4]; $i++) {
            $blocks[] = array_slice($data, $offset, $spec[5]);
            $offset += $spec[5];
        }

        $eccBlocks = [];
        foreach ($blocks as $block) {
            $eccBlocks[] = $this->reedSolomon($block, $eccPerBlock);
        }

        $result = [];

        // Interleave the data codewords column-wise.
        $maxDataLength = max(array_map('count', $blocks));
        for ($i = 0; $i < $maxDataLength; $i++) {
            foreach ($blocks as $block) {
                if (isset($block[$i])) {
                    $result[] = $block[$i];
                }
            }
        }

        // Interleave the ECC codewords.
        for ($i = 0; $i < $eccPerBlock; $i++) {
            foreach ($eccBlocks as $ecc) {
                $result[] = $ecc[$i];
            }
        }

        return array_slice($result, 0, $totalCodewords);
    }

    /**
     * Reed-Solomon error correction codewords over GF(256).
     *
     * @param list<int> $data
     * @return list<int>
     */
    private function reedSolomon(array $data, int $eccLength): array
    {
        // Generator polynomial of the requested degree.
        $generator = [1];
        for ($i = 0; $i < $eccLength; $i++) {
            $generator = $this->polynomialMultiply($generator, [1, $this->exp[$i]]);
        }

        // Remainder of data(x) divided by generator(x).
        $remainder = array_merge($data, array_fill(0, $eccLength, 0));

        for ($i = 0; $i < count($data); $i++) {
            $coefficient = $remainder[$i];
            if ($coefficient === 0) {
                continue;
            }
            for ($j = 0; $j < count($generator); $j++) {
                $remainder[$i + $j] ^= $this->gfMultiply($coefficient, $generator[$j]);
            }
        }

        return array_slice($remainder, count($data), $eccLength);
    }

    /**
     * @param list<int> $a
     * @param list<int> $b
     * @return list<int>
     */
    private function polynomialMultiply(array $a, array $b): array
    {
        $result = array_fill(0, count($a) + count($b) - 1, 0);
        foreach ($a as $i => $ai) {
            if ($ai === 0) {
                continue;
            }
            foreach ($b as $j => $bj) {
                $result[$i + $j] ^= $this->gfMultiply($ai, $bj);
            }
        }
        return $result;
    }

    private function gfMultiply(int $a, int $b): int
    {
        if ($a === 0 || $b === 0) {
            return 0;
        }
        return $this->exp[($this->log[$a] + $this->log[$b]) % 255];
    }

    /** @param list<int> $bits */
    private function appendBits(array &$bits, int $value, int $length): void
    {
        for ($i = $length - 1; $i >= 0; $i--) {
            $bits[] = ($value >> $i) & 1;
        }
    }
// -----------------------------------------------------------------------
    // Matrix construction
    // -----------------------------------------------------------------------

    /**
     * @param list<int> $codewords
     * @return list<list<bool>>
     */
    private function buildMatrix(array $codewords, int $version, ?int $forcedMask = null): array
    {
        $size = 17 + (4 * $version);

        $matrix   = [];
        $reserved = [];
        for ($y = 0; $y < $size; $y++) {
            $matrix[$y]   = array_fill(0, $size, false);
            $reserved[$y] = array_fill(0, $size, false);
        }

        $this->placeFunctionPatterns($matrix, $reserved, $version, $size);

        // Write codeword bits into the data area in the standard zig-zag order.
        $bitIndex     = 0;
        $codewordBits = count($codewords) * 8;
        $upward       = true;

        for ($right = $size - 1; $right > 0; $right -= 2) {
            if ($right === 6) {
                $right--;   // column 6 is the vertical timing pattern
            }

            for ($step = 0; $step < $size; $step++) {
                $y = $upward ? ($size - 1 - $step) : $step;

                for ($c = 0; $c < 2; $c++) {
                    $x = $right - $c;
                    if ($reserved[$y][$x] === true) {
                        continue;
                    }

                    $dark = false;
                    if ($bitIndex < $codewordBits) {
                        $byteIndex = intdiv($bitIndex, 8);
                        $bitInByte = 7 - ($bitIndex % 8);
                        $dark = ((($codewords[$byteIndex] >> $bitInByte) & 1) === 1);
                    }
                    // Bits past the codewords are remainder bits and stay light.

                    $matrix[$y][$x] = $dark;
                    $bitIndex++;
                }
            }

            $upward = !$upward;
        }

        // Try all 8 masks and keep the one with the lowest penalty score.
        if ($forcedMask !== null) {
            $this->selectedMask = $forcedMask;
            $result = $this->applyMask($matrix, $reserved, $size, $forcedMask);
            $this->placeFormatBits($result, $size, $forcedMask);
            return $result;
        }

        $best      = $matrix;
        $bestScore = PHP_INT_MAX;
        $bestMask  = 0;

        for ($mask = 0; $mask < 8; $mask++) {
            $candidate = $this->applyMask($matrix, $reserved, $size, $mask);
            $this->placeFormatBits($candidate, $size, $mask);

            $score = $this->penaltyScore($candidate, $size);
            if ($score < $bestScore) {
                $bestScore = $score;
                $best      = $candidate;
                $bestMask  = $mask;
            }
        }

        $this->selectedMask = $bestMask;

        return $best;
    }

    /**
     * Reserve the format information areas.
     *
     * The existing module value is deliberately preserved so that the two
     * modules shared with the timing pattern (8,6) and (6,8) are not cleared.
     *
     * @param list<list<bool>> $matrix
     * @param list<list<bool>> $reserved
     */
    private function reserveFormatAreas(array &$matrix, array &$reserved, int $size): void
    {
        $mark = static function (int $y, int $x) use (&$matrix, &$reserved): void {
            $reserved[$y][$x] = true;
        };

        for ($i = 0; $i < 9; $i++) {
            $mark(8, $i);
            $mark($i, 8);
        }
        for ($i = 0; $i < 8; $i++) {
            $mark(8, $size - 1 - $i);
            $mark($size - 1 - $i, 8);
        }
    }

    /**
     * @param list<list<bool>> $matrix
     * @param list<list<bool>> $reserved
     */
    private function placeFunctionPatterns(array &$matrix, array &$reserved, int $version, int $size): void
    {
        // Finder patterns with their separators.
        $this->placeFinder($matrix, $reserved, 0, 0, $size);
        $this->placeFinder($matrix, $reserved, 0, $size - 7, $size);
        $this->placeFinder($matrix, $reserved, $size - 7, 0, $size);

        // Timing patterns.
        for ($i = 8; $i < $size - 8; $i++) {
            $dark = ($i % 2 === 0);
            $this->setFunction($matrix, $reserved, $i, 6, $dark);
            $this->setFunction($matrix, $reserved, 6, $i, $dark);
        }

        // Alignment patterns (never overlapping the three finder patterns).
        $centres = self::ALIGNMENT[$version] ?? [];
        foreach ($centres as $cy) {
            foreach ($centres as $cx) {
                $overlapsFinder = ($cy <= 8 && $cx <= 8)
                    || ($cy <= 8 && $cx >= $size - 9)
                    || ($cy >= $size - 9 && $cx <= 8);
                if ($overlapsFinder) {
                    continue;
                }
                $this->placeAlignment($matrix, $reserved, $cx, $cy);
            }
        }

        // The dark module is always set.
        $this->setFunction($matrix, $reserved, $size - 8, 8, true);

        // Reserve version information for version 7 and above.
        if ($version >= 7) {
            for ($i = 0; $i < 6; $i++) {
                for ($j = 0; $j < 3; $j++) {
                    $this->setFunction($matrix, $reserved, $i, $size - 11 + $j, false);
                    $this->setFunction($matrix, $reserved, $size - 11 + $j, $i, false);
                }
            }
        }

        $this->reserveFormatAreas($matrix, $reserved, $size);
    }
/**
     * @param list<list<bool>> $matrix
     * @param list<list<bool>> $reserved
     */
    private function placeFinder(array &$matrix, array &$reserved, int $top, int $left, int $size): void
    {
        for ($dy = -1; $dy <= 7; $dy++) {
            for ($dx = -1; $dx <= 7; $dx++) {
                $y = $top + $dy;
                $x = $left + $dx;
                if ($y < 0 || $y >= $size || $x < 0 || $x >= $size) {
                    continue;
                }

                $inRing = ($dy >= 0 && $dy <= 6 && ($dx === 0 || $dx === 6))
                    || ($dx >= 0 && $dx <= 6 && ($dy === 0 || $dy === 6));
                $inCore = ($dy >= 2 && $dy <= 4 && $dx >= 2 && $dx <= 4);

                $this->setFunction($matrix, $reserved, $y, $x, $inRing || $inCore);
            }
        }
    }

    /**
     * @param list<list<bool>> $matrix
     * @param list<list<bool>> $reserved
     */
    private function placeAlignment(array &$matrix, array &$reserved, int $cx, int $cy): void
    {
        for ($dy = -2; $dy <= 2; $dy++) {
            for ($dx = -2; $dx <= 2; $dx++) {
                $dark = (max(abs($dx), abs($dy)) !== 1);
                $this->setFunction($matrix, $reserved, $cy + $dy, $cx + $dx, $dark);
            }
        }
    }

    /**
     * @param list<list<bool>> $matrix
     * @param list<list<bool>> $reserved
     */
    private function setFunction(array &$matrix, array &$reserved, int $y, int $x, bool $dark): void
    {
        $matrix[$y][$x]   = $dark;
        $reserved[$y][$x] = true;
    }

    /**
     * @param list<list<bool>> $matrix
     * @param list<list<bool>> $reserved
     * @return list<list<bool>>
     */
    private function applyMask(array $matrix, array $reserved, int $size, int $mask): array
    {
        for ($y = 0; $y < $size; $y++) {
            for ($x = 0; $x < $size; $x++) {
                if ($reserved[$y][$x]) {
                    continue;
                }

                $invert = match ($mask) {
                    0 => ($y + $x) % 2 === 0,
                    1 => $y % 2 === 0,
                    2 => $x % 3 === 0,
                    3 => ($y + $x) % 3 === 0,
                    4 => (intdiv($y, 2) + intdiv($x, 3)) % 2 === 0,
                    5 => (($y * $x) % 2) + (($y * $x) % 3) === 0,
                    6 => ((($y * $x) % 2) + (($y * $x) % 3)) % 2 === 0,
                    7 => ((($y + $x) % 2) + (($y * $x) % 3)) % 2 === 0,
                    default => false,
                };

                if ($invert) {
                    $matrix[$y][$x] = !$matrix[$y][$x];
                }
            }
        }

        return $matrix;
    }

    /**
     * Draw the 15 format-information bits in their two redundant copies.
     *
     * The bit order follows the specification: bit 0 sits next to the
     * top-left finder along column 8, and the second copy is split between
     * row 8 and column 8 beside the other two finders.
     *
     * @param list<list<bool>> $matrix
     */
    private function placeFormatBits(array &$matrix, int $size, int $mask): void
    {
        $formatBits = $this->formatBits($mask);

        // Copy 1 — runs down column 8, then turns left along row 8.
        for ($i = 0; $i <= 5; $i++) {
            $matrix[$i][8] = (bool) (($formatBits >> $i) & 1);
        }
        $matrix[7][8] = (bool) (($formatBits >> 6) & 1);
        $matrix[8][8] = (bool) (($formatBits >> 7) & 1);
        $matrix[8][7] = (bool) (($formatBits >> 8) & 1);
        for ($i = 9; $i <= 14; $i++) {
            $matrix[8][14 - $i] = (bool) (($formatBits >> $i) & 1);
        }

        // Copy 2 — along row 8 on the right, then down column 8 at the bottom.
        for ($i = 0; $i <= 7; $i++) {
            $matrix[8][$size - 1 - $i] = (bool) (($formatBits >> $i) & 1);
        }
        for ($i = 8; $i <= 14; $i++) {
            $matrix[$size - 15 + $i][8] = (bool) (($formatBits >> $i) & 1);
        }

        // The dark module is always set.
        $matrix[$size - 8][8] = true;
    }

    /** BCH(15,5) format information with the 0x5412 XOR mask. */
    private function formatBits(int $mask): int
    {
        $data = (self::ECC_LEVELS[$this->eccLevel] << 3) | $mask;

        $rem = $data;
        for ($i = 0; $i < 10; $i++) {
            $rem = ($rem << 1) ^ ((($rem >> 9) & 1) * 0x537);
        }

        return (($data << 10) | $rem) ^ 0x5412;
    }
/**
     * Mask penalty score, rules 1-3 combined per row/column plus rule 4.
     *
     * Implements the exact scoring algorithm from the specification using a
     * sliding window of run lengths (the standard reference approach), so the
     * mask we select is identical to other conformant encoders.
     *
     * @param list<list<bool>> $matrix
     */
    private function penaltyScore(array $matrix, int $size): int
    {
        $N1 = 3;   // penalty for a run of 5 same-coloured modules
        $N2 = 3;   // penalty per 2x2 block of one colour
        $N3 = 40;  // penalty for finder-like patterns
        $N4 = 10;  // penalty factor for dark-ratio deviation

        $result = 0;

        // Rules 1 and 3, applied to every row.
        for ($y = 0; $y < $size; $y++) {
            $runHistory = array_fill(0, 7, 0);
            $colour     = false;
            $runX       = 0;

            for ($x = 0; $x < $size; $x++) {
                if ($matrix[$y][$x] === $colour) {
                    $runX++;
                    if ($runX === 5) {
                        $result += $N1;
                    } elseif ($runX > 5) {
                        $result++;
                    }
                } else {
                    $this->addRunToHistory($runX, $runHistory, $size);
                    if (!$colour) {
                        $result += $this->countFinderPatterns($runHistory) * $N3;
                    }
                    $colour = $matrix[$y][$x];
                    $runX   = 1;
                }
            }

            $result += $this->terminateAndCount($colour, $runX, $runHistory, $size) * $N3;
        }

        // Rules 1 and 3, applied to every column.
        for ($x = 0; $x < $size; $x++) {
            $runHistory = array_fill(0, 7, 0);
            $colour     = false;
            $runY       = 0;

            for ($y = 0; $y < $size; $y++) {
                if ($matrix[$y][$x] === $colour) {
                    $runY++;
                    if ($runY === 5) {
                        $result += $N1;
                    } elseif ($runY > 5) {
                        $result++;
                    }
                } else {
                    $this->addRunToHistory($runY, $runHistory, $size);
                    if (!$colour) {
                        $result += $this->countFinderPatterns($runHistory) * $N3;
                    }
                    $colour = $matrix[$y][$x];
                    $runY   = 1;
                }
            }

            $result += $this->terminateAndCount($colour, $runY, $runHistory, $size) * $N3;
        }

        // Rule 2: 2x2 blocks of the same colour.
        for ($y = 0; $y < $size - 1; $y++) {
            for ($x = 0; $x < $size - 1; $x++) {
                $v = $matrix[$y][$x];
                if ($v === $matrix[$y][$x + 1] && $v === $matrix[$y + 1][$x] && $v === $matrix[$y + 1][$x + 1]) {
                    $result += $N2;
                }
            }
        }

        // Rule 4: deviation of the dark-module ratio from 50%.
        $dark = 0;
        foreach ($matrix as $row) {
            foreach ($row as $cell) {
                if ($cell === true) {
                    $dark++;
                }
            }
        }

        $totalCells = $size * $size;
        $k          = (int) (abs($dark * 20 - $totalCells * 10) / $totalCells);

        return $result + $k * $N4;
    }

    /** @param list<int> $runHistory */
    private function addRunToHistory(int $runLength, array &$runHistory, int $size): void
    {
        if ($runHistory[0] === 0) {
            $currentRunLength = $runLength + $size;   // implicit light border before the first run
        } else {
            $currentRunLength = $runLength;
        }

        array_shift($runHistory);
        $runHistory[] = $currentRunLength;
    }

    /** @param list<int> $runHistory */
    private function countFinderPatterns(array $runHistory): int
    {
        $n = $runHistory[1];

        // A 1:1:3:1:1 dark/light ratio next to a light area at least 4x the unit.
        $core = $n > 0
            && $runHistory[2] === $n
            && $runHistory[3] === $n * 3
            && $runHistory[4] === $n
            && $runHistory[5] === $n;

        $finderCount = 0;
        if ($core && $runHistory[0] >= $n * 4 && $runHistory[6] >= $n) {
            $finderCount++;
        }
        if ($core && $runHistory[6] >= $n * 4 && $runHistory[0] >= $n) {
            $finderCount++;
        }

        return $finderCount;
    }

    /** @param list<int> $runHistory */
    private function terminateAndCount(bool $currentRunColour, int $currentRunLength, array &$runHistory, int $size): int
    {
        if ($currentRunColour) {
            // Finish a dark run before appending the trailing light border.
            $this->addRunToHistory($currentRunLength, $runHistory, $size);
            $currentRunLength = 0;
        }

        $currentRunLength += $size;   // implicit light border after the last run
        $this->addRunToHistory($currentRunLength, $runHistory, $size);

        return $this->countFinderPatterns($runHistory);
    }
}