<?php
/**
 * Government contributions (SSS, PhilHealth, Pag-IBIG) and BIR withholding tax.
 *
 * Nothing here is hard-coded: every rate, floor, ceiling, salary-credit step
 * and tax bracket is read from the effective-dated schedule tables
 * (`statutory_schedules`, `bir_withholding_schedules`,
 * `bir_withholding_brackets`) that the Settings page maintains. Each schedule
 * carries the issuing agency, the document it came from and the URL, so a
 * payroll row can always be traced to the rule that produced it.
 *
 * Money rules enforced here:
 *   - Contributions are monthly amounts, allocated to the payroll period with
 *     the configured basis (calendar days covered or equal split per month).
 *   - Withholding tax uses the BIR table that matches the payroll frequency;
 *     a period that covers a whole month always uses the monthly table.
 *   - Only the employee share is a payroll deduction. Employer shares (and the
 *     SSS EC premium) are reported separately and never affect net pay.
 */

declare(strict_types=1);

namespace App\Services;

use App\Core\AuditLogger;
use App\Core\Database;
use App\Core\Settings;
use DateTimeImmutable;
use InvalidArgumentException;
use RuntimeException;

final class StatutoryDeductionService
{
    /** Contribution codes, in the order they appear on a payslip. */
    public const CODES = ['SSS', 'PHILHEALTH', 'PAGIBIG'];

    /** The withholding tax is stored as a fourth statutory line. */
    public const TAX_CODE = 'WITHHOLDING_TAX';

    public const FREQUENCIES = ['DAILY', 'WEEKLY', 'SEMI_MONTHLY', 'MONTHLY'];

    /**
     * Deduction codes owned by this service. Employee deductions carrying one
     * of these codes are ignored by the payroll engine so the legacy seeded
     * SSS / PhilHealth / Pag-IBIG / TAX placeholders can never double-deduct.
     */
    public const RESERVED_DEDUCTION_CODES = [
        'SSS', 'PHILHEALTH', 'PAGIBIG', 'TAX',
        'SSS_EE', 'PHILHEALTH_EE', 'PAGIBIG_EE', 'WITHHOLDING_TAX',
    ];

    private const SCHEDULE_COLUMNS = [
        'name', 'salary_base', 'salary_floor', 'salary_ceiling', 'employee_rate', 'employer_rate',
        'low_salary_threshold', 'low_employee_rate', 'low_employer_rate',
        'credit_step', 'credit_min', 'credit_max', 'ec_amount', 'ec_amount_high', 'ec_threshold',
        'rounding', 'deduction_code', 'deduction_name', 'effective_from', 'effective_to',
        'source_name', 'source_url', 'notes', 'status',
    ];

    private const NUMERIC_FIELDS = [
        'salary_floor', 'salary_ceiling', 'employee_rate', 'employer_rate',
        'low_salary_threshold', 'low_employee_rate', 'low_employer_rate',
        'credit_step', 'credit_min', 'credit_max', 'ec_amount', 'ec_amount_high', 'ec_threshold',
    ];

    /** @var array<string, array<string, mixed>|null> */
    private array $scheduleCache = [];

    /** @var array<string, array<string, mixed>|null> */
    private array $birScheduleCache = [];

    /** @var array<int, list<array<string, mixed>>> */
    private array $bracketCache = [];

    /** Master switch (Settings -> Payroll). */
    public function enabled(array $settings = []): bool
    {
        return (bool) ($settings['statutory_enabled'] ?? Settings::bool('statutory.enabled', true));
    }

    /** Per-agency switch. */
    public function agencyEnabled(string $code, array $settings = []): bool
    {
        return (bool) ($settings['statutory_' . strtolower($code) . '_enabled']
            ?? Settings::bool('statutory.' . strtolower($code) . '_enabled', true));
    }

    // -----------------------------------------------------------------------
    // Period calculation
    // -----------------------------------------------------------------------

    /**
     * Compute every statutory amount for one employee and one payroll period.
     *
     * Expected context keys:
     *   employee, start_date, end_date, monthly_basic, monthly_allowances,
     *   gross_pay, non_taxable_allowances, settings
     *
     * @param array<string, mixed> $context
     * @return array<string, mixed>
     */
    public function calculate(array $context): array
    {
        $settings = (array) ($context['settings'] ?? []);
        $startDate = (string) ($context['start_date'] ?? '');
        $endDate   = (string) ($context['end_date'] ?? '');

        if ($startDate === '' || $endDate === '') {
            throw new InvalidArgumentException('A payroll period start and end date are required.');
        }

        $monthlyBasic      = (float) ($context['monthly_basic'] ?? 0.0);
        $monthlyAllowances = (float) ($context['monthly_allowances'] ?? 0.0);
        $grossPay          = (float) ($context['gross_pay'] ?? 0.0);
        $nonTaxable        = (float) ($context['non_taxable_allowances'] ?? 0.0);

        $result = [
            'enabled'              => false,
            'monthly_basic'        => round($monthlyBasic, 2),
            'allocation_basis'     => $this->allocationBasis($settings),
            'allocation_factor'    => 1.0,
            'contributions'        => [],
            'withholding_tax'      => null,
            'employee_total'       => 0.0,
            'employer_total'       => 0.0,
            'deductions'           => [],
            'rows'                 => [],
            'warnings'             => [],
        ];

        if (!$this->enabled($settings)) {
            return $result;
        }

        $result['enabled']           = true;
        $factor                      = $this->allocationFactor($startDate, $endDate, $settings);
        $result['allocation_factor'] = $factor;

        $warnings = [];

        foreach (self::CODES as $code) {
            if (!$this->agencyEnabled($code, $settings)) {
                continue;
            }

            $rawBase  = $this->salaryBaseFor($code, $monthlyBasic, $monthlyAllowances, $settings, $endDate);
            $computed = $this->contribution($code, $rawBase, $factor, $endDate, $this->allocationBasis($settings) === 'EQUAL_SPLIT');

            $result['contributions'][$code] = $computed;

            if ($computed['missing']) {
                throw new \RuntimeException('Cannot calculate payroll: missing effective statutory contribution table for '
                    . $code . ' on ' . $endDate . '. Update Settings > Contributions before generating payroll.');
            }

            $result['rows'][] = $computed['row'];

            if ($computed['employee_amount'] > 0) {
                $result['deductions'][] = [
                    'code'    => $computed['deduction_code'],
                    'name'    => $computed['name'],
                    'amount'  => $computed['employee_amount'],
                    'remarks' => $computed['remarks'],
                ];
            }
        }

        $employeeContributions = round(array_sum(array_map(
            static fn (array $item): float => (float) $item['employee_amount'],
            $result['contributions']
        )), 2);

        if ($this->taxEnabled($settings)) {
            $tax = $this->withholdingTax($context, $employeeContributions, $factor, $endDate);
            $result['withholding_tax'] = $tax;
            $result['rows'][]          = $tax['row'];

            if ($tax['missing']) {
                throw new \RuntimeException('Cannot calculate payroll: missing BIR withholding table on '
                    . $endDate . '. Update the official BIR table before generating payroll.');
            }

            if ($tax['amount'] > 0) {
                $result['deductions'][] = [
                    'code'    => self::TAX_CODE,
                    'name'    => 'Withholding Tax',
                    'amount'  => $tax['amount'],
                    'remarks' => $tax['remarks'],
                ];
            }
        }

        $employerTotal = round(array_sum(array_map(
            static fn (array $item): float => (float) $item['employer_amount'] + (float) $item['extra_amount'],
            $result['contributions']
        )), 2);

        $taxAmount = (float) ($result['withholding_tax']['amount'] ?? 0.0);

        $result['employee_total'] = round($employeeContributions + $taxAmount, 2);
        $result['employer_total'] = $employerTotal;
        $result['warnings']       = $warnings;
        $result['taxable_compensation'] = (float) ($result['withholding_tax']['taxable'] ?? 0.0);
        $result['tax_frequency']        = $result['withholding_tax']['frequency'] ?? null;

        $result['snapshot'] = [
            'enabled'              => true,
            'allocation_basis'     => $result['allocation_basis'],
            'allocation_factor'    => $factor,
            'period'               => ['start' => $startDate, 'end' => $endDate],
            'monthly_basic'        => round($monthlyBasic, 2),
            'tax_frequency'        => $result['tax_frequency'],
            'taxable_compensation' => $result['taxable_compensation'],
            'employee_total'       => $result['employee_total'],
            'employer_total'       => $result['employer_total'],
            'schedules'            => array_map(
                static fn (array $item): array => [
                    'code'           => $item['code'],
                    'schedule_id'    => $item['schedule_id'],
                    'effective_from' => $item['schedule_effective_from'],
                    'source'         => $item['schedule_source'],
                ],
                array_merge($result['rows'], [])
            ),
            'warnings'             => $warnings,
        ];

        return $result;
    }

    /**
     * Share of the monthly statutory amount charged to this payroll period.
     *
     * CALENDAR_DAYS (default) prorates by the days of the period inside the
     * month it ends in, so the two halves of a month always add up to exactly
     * one monthly amount. EQUAL_SPLIT divides by the configured number of pay
     * periods per month.
     *
     * @param array<string, mixed> $settings
     */
    public function allocationFactor(string $startDate, string $endDate, array $settings = []): float
    {
        if ($this->allocationBasis($settings) === 'EQUAL_SPLIT') {
            $periods = (int) ($settings['statutory_periods_per_month']
                ?? Settings::int('statutory.periods_per_month', 2));

            return round(1 / max(1, $periods), 6);
        }

        $end   = new DateTimeImmutable($endDate);
        $start = new DateTimeImmutable($startDate);

        $monthFirst = $end->modify('first day of this month');
        $monthLast  = $end->modify('last day of this month');
        $daysInMonth = (int) $end->format('t');

        $from = $start > $monthFirst ? $start : $monthFirst;
        $to   = $end < $monthLast ? $end : $monthLast;

        if ($to < $from) {
            return 0.0;
        }

        $covered = (int) $from->diff($to)->days + 1;

        return round(min(1.0, $covered / $daysInMonth), 6);
    }

    /** The salary base a contribution is computed from. */
    public function salaryBaseFor(
        string $code,
        float $monthlyBasic,
        float $monthlyAllowances,
        array $settings = [],
        ?string $asOf = null
    ): float {
        $base = 'MONTHLY_BASIC';

        if ($code === 'PAGIBIG') {
            $base = (string) ($settings['statutory_pagibig_salary_base']
                ?? Settings::string('statutory.pagibig_salary_base', 'MONTHLY_BASIC_PLUS_ALLOWANCES'));
        } else {
            $schedule = $this->scheduleFor($code, $asOf ?? date('Y-m-d'));
            if ($schedule !== null) {
                $base = (string) $schedule['salary_base'];
            }
        }

        return round($monthlyBasic + (strtoupper($base) === 'MONTHLY_BASIC_PLUS_ALLOWANCES' ? $monthlyAllowances : 0.0), 2);
    }

    // -----------------------------------------------------------------------
    // Contribution + tax maths
    // -----------------------------------------------------------------------

    /** The second cutoff absorbs a one-cent rounding remainder, never double deducting it. */
    public static function equalSplitAmount(float $monthlyAmount, string $endDate): float
    {
        $first = round($monthlyAmount / 2.0, 2);
        return (int) substr($endDate, 8, 2) >= 16
            ? round($monthlyAmount - $first, 2)
            : $first;
    }

    /**
     * One contribution (monthly amount, allocated to the period).
     *
     * @return array<string, mixed>
     */
    private function contribution(string $code, float $rawBase, float $factor, string $anchorDate, bool $equalSplit = false): array
    {
        $schedule = $this->scheduleFor($code, $anchorDate);

        if ($schedule === null) {
            return $this->missingContribution($code, $rawBase, $factor, $anchorDate);
        }

        $rounding  = (string) $schedule['rounding'];
        $scheme    = (string) $schedule['scheme'];
        $base      = $rawBase;
        $msc       = null;
        $rates     = ['employee' => 0.0, 'employer' => 0.0];

        if ($scheme === 'CREDIT_RATE') {
            $step = (float) ($schedule['credit_step'] ?? 0);
            $msc  = $step > 0 ? round($base / $step) * $step : $base;
            $msc  = max((float) ($schedule['credit_min'] ?? 0), min((float) ($schedule['credit_max'] ?? $msc), $msc));
            $paid = $msc;
            $rates['employee'] = (float) $schedule['employee_rate'];
            $rates['employer'] = (float) $schedule['employer_rate'];
        } else {
            $paid = $this->clamp($base, $schedule);

            $usesLowRates = $schedule['low_salary_threshold'] !== null
                && $paid <= (float) $schedule['low_salary_threshold'];

            $rates['employee'] = $usesLowRates && $schedule['low_employee_rate'] !== null
                ? (float) $schedule['low_employee_rate']
                : (float) ($schedule['employee_rate'] ?? 0.0);
            $rates['employer'] = $usesLowRates && $schedule['low_employer_rate'] !== null
                ? (float) $schedule['low_employer_rate']
                : (float) ($schedule['employer_rate'] ?? 0.0);
        }

        $monthlyEmployee = $this->money($paid * $rates['employee'] / 100, $rounding);
        $monthlyEmployer = $this->money($paid * $rates['employer'] / 100, $rounding);

        $monthlyExtra = 0.0;
        if ($schedule['ec_amount'] !== null) {
            $threshold    = $schedule['ec_threshold'] !== null ? (float) $schedule['ec_threshold'] : null;
            $monthlyExtra = ($threshold !== null && $paid > $threshold)
                ? (float) ($schedule['ec_amount_high'] ?? 0.0)
                : (float) $schedule['ec_amount'];
        }

        $employeeAmount = $equalSplit && abs($factor - 0.5) < 0.0001
            ? self::equalSplitAmount($monthlyEmployee, $anchorDate)
            : $this->money($monthlyEmployee * $factor, 'CENTAVO');
        $employerAmount = $equalSplit && abs($factor - 0.5) < 0.0001
            ? self::equalSplitAmount($monthlyEmployer, $anchorDate)
            : $this->money($monthlyEmployer * $factor, 'CENTAVO');
        $extraAmount = $equalSplit && abs($factor - 0.5) < 0.0001
            ? self::equalSplitAmount($monthlyExtra, $anchorDate)
            : $this->money($monthlyExtra * $factor, 'CENTAVO');

        $remarks = $msc !== null
            ? sprintf('MSC %s @ %s', $this->money($msc, 'CENTAVO'), $this->rateLabel($rates['employee']))
            : sprintf('%s of %s @ %s', $code === 'PHILHEALTH' ? 'Basic' : 'Fund salary', number_format($paid, 2), $this->rateLabel($rates['employee']));

        $row = [
            'code'                    => $code,
            'name'                    => (string) $schedule['deduction_name'],
            'scheme'                  => $scheme,
            'schedule_id'             => (int) $schedule['id'],
            'schedule_effective_from' => (string) $schedule['effective_from'],
            'schedule_source'         => (string) ($schedule['source_name'] ?? ''),
            'salary_base'             => (string) $schedule['salary_base'],
            'monthly_base'            => round($rawBase, 2),
            'credited_base'           => round($paid, 2),
            'employee_rate'           => $rates['employee'],
            'employer_rate'           => $rates['employer'],
            'monthly_employee_amount' => $monthlyEmployee,
            'monthly_employer_amount' => $monthlyEmployer,
            'monthly_extra_amount'    => $monthlyExtra,
            'allocation_factor'       => $factor,
            'employee_amount'         => $employeeAmount,
            'employer_amount'         => $employerAmount,
            'extra_amount'            => $extraAmount,
            'withholding_period'      => null,
            'bracket_order'           => null,
            'remarks'                 => $remarks,
        ];

        return [
            'code'                    => $code,
            'name'                    => (string) $schedule['deduction_name'],
            'deduction_code'          => (string) $schedule['deduction_code'],
            'scheme'                  => $scheme,
            'schedule_id'             => (int) $schedule['id'],
            'schedule_effective_from' => (string) $schedule['effective_from'],
            'schedule_source'         => (string) ($schedule['source_name'] ?? ''),
            'monthly_base'            => round($rawBase, 2),
            'credited_base'           => round($paid, 2),
            'msc'                     => $msc,
            'employee_rate'           => $rates['employee'],
            'employer_rate'           => $rates['employer'],
            'monthly_employee_amount' => $monthlyEmployee,
            'monthly_employer_amount' => $monthlyEmployer,
            'monthly_extra_amount'    => $monthlyExtra,
            'employee_amount'         => $employeeAmount,
            'employer_amount'         => $employerAmount,
            'extra_amount'            => $extraAmount,
            'missing'                 => false,
            'remarks'                 => $remarks,
            'row'                     => $row,
        ];
    }

    /**
     * A contribution whose effective schedule does not cover the period. It is
     * reported (so the gap is visible in the payroll audit trail) but charges
     * nothing until an administrator adds the missing version.
     *
     * @return array<string, mixed>
     */
    private function missingContribution(string $code, float $rawBase, float $factor, string $anchorDate): array
    {
        $name    = match ($code) {
            'SSS'        => 'SSS Contribution (Employee Share)',
            'PHILHEALTH' => 'PhilHealth Premium (Employee Share)',
            default      => 'Pag-IBIG Fund (Employee Share)',
        };
        $remarks = sprintf('%s: no effective schedule published for %s', $code, $anchorDate);

        return [
            'code'                    => $code,
            'name'                    => $name,
            'deduction_code'          => match ($code) {
                'SSS'        => 'SSS_EE',
                'PHILHEALTH' => 'PHILHEALTH_EE',
                default      => 'PAGIBIG_EE',
            },
            'scheme'                  => null,
            'schedule_id'             => null,
            'schedule_effective_from' => null,
            'schedule_source'         => null,
            'monthly_base'            => round($rawBase, 2),
            'credited_base'           => 0.0,
            'msc'                     => null,
            'employee_rate'           => null,
            'employer_rate'           => null,
            'monthly_employee_amount' => 0.0,
            'monthly_employer_amount' => 0.0,
            'monthly_extra_amount'    => 0.0,
            'employee_amount'         => 0.0,
            'employer_amount'         => 0.0,
            'extra_amount'            => 0.0,
            'missing'                 => true,
            'remarks'                 => $remarks,
            'row'                     => [
                'code'                    => $code,
                'name'                    => $name,
                'scheme'                  => null,
                'schedule_id'             => null,
                'schedule_effective_from' => null,
                'schedule_source'         => null,
                'salary_base'             => null,
                'monthly_base'            => round($rawBase, 2),
                'credited_base'           => 0.0,
                'employee_rate'           => null,
                'employer_rate'           => null,
                'monthly_employee_amount' => 0.0,
                'monthly_employer_amount' => 0.0,
                'monthly_extra_amount'    => 0.0,
                'allocation_factor'       => $factor,
                'employee_amount'         => 0.0,
                'employer_amount'         => 0.0,
                'extra_amount'            => 0.0,
                'withholding_period'      => null,
                'bracket_order'           => null,
                'remarks'                 => $remarks,
            ],
        ];
    }

    public function taxEnabled(array $settings = []): bool
    {
        return (bool) ($settings['statutory_tax_enabled'] ?? Settings::bool('statutory.tax_enabled', true));
    }

    /**
     * Withholding tax for the period, using the BIR table that matches the
     * payroll frequency (monthly for a period that covers a whole month).
     *
     * @param array<string, mixed> $context
     * @return array<string, mixed>
     */
    private function withholdingTax(array $context, float $employeeContributions, float $factor, string $anchorDate): array
    {
        $settings = (array) ($context['settings'] ?? []);

        $excludeNonTaxable = (bool) ($settings['statutory_tax_exclude_non_taxable_allowances']
            ?? Settings::bool('statutory.tax_exclude_non_taxable_allowances', true));
        $subtractContributions = (bool) ($settings['statutory_tax_subtract_contributions']
            ?? Settings::bool('statutory.tax_subtract_contributions', true));

        $taxable = (float) ($context['gross_pay'] ?? 0.0);
        if ($excludeNonTaxable) {
            $taxable -= (float) ($context['non_taxable_allowances'] ?? 0.0);
        }
        if ($subtractContributions) {
            $taxable -= $employeeContributions;
        }
        $taxable = round(max(0.0, $taxable), 2);

        $frequency = $this->taxFrequency($factor, $settings);
        $schedule  = $this->birScheduleFor($frequency, $anchorDate);

        if ($schedule === null) {
            $remarks = sprintf('Withholding tax: no %s BIR table published for %s', $frequency, $anchorDate);

            return [
                'name'      => 'Withholding Tax',
                'amount'    => 0.0,
                'taxable'   => $taxable,
                'frequency' => $frequency,
                'missing'   => true,
                'remarks'   => $remarks,
                'row'       => $this->taxRow(0.0, $taxable, $frequency, null, null, $factor, $remarks),
            ];
        }

        // A monthly table is applied to the monthly equivalent of the period
        // compensation, then allocated back to the period.
        $forTable = $frequency === 'MONTHLY' && $factor > 0
            ? round($taxable / $factor, 2)
            : $taxable;

        $bracket = $this->birBracket((int) $schedule['id'], $forTable);

        $taxOnTable = 0.0;
        if ($bracket !== null) {
            $taxOnTable = round(
                (float) $bracket['base_tax']
                + ((float) $bracket['excess_rate'] / 100) * max(0.0, $forTable - (float) $bracket['excess_over']),
                2
            );
        }

        $amount = $frequency === 'MONTHLY' ? round($taxOnTable * $factor, 2) : $taxOnTable;

        $remarks = sprintf(
            '%s table - taxable %s%s',
            $frequency,
            number_format($taxable, 2),
            $bracket !== null ? ' at ' . $this->rateLabel((float) $bracket['excess_rate']) : ''
        );

        return [
            'name'      => 'Withholding Tax',
            'amount'    => $amount,
            'taxable'   => $taxable,
            'frequency' => $frequency,
            'missing'   => false,
            'remarks'   => $remarks,
            'row'       => $this->taxRow(
                $amount,
                $taxable,
                $frequency,
                (int) $schedule['id'],
                (string) $schedule['effective_from'],
                $factor,
                $remarks,
                (string) ($schedule['source_name'] ?? ''),
                $bracket !== null ? (int) $bracket['bracket_order'] : null
            ),
        ];
    }

    /** @return array<string, mixed> */
    private function taxRow(
        float $amount,
        float $taxable,
        string $frequency,
        ?int $scheduleId,
        ?string $effectiveFrom,
        float $factor,
        string $remarks,
        string $source = '',
        ?int $bracketOrder = null
    ): array {
        return [
            'code'                    => self::TAX_CODE,
            'name'                    => 'Withholding Tax',
            'scheme'                  => 'BIR_TABLE',
            'schedule_id'             => $scheduleId,
            'schedule_effective_from' => $effectiveFrom,
            'schedule_source'         => $source,
            'salary_base'             => 'TAXABLE_COMPENSATION',
            'monthly_base'            => $taxable,
            'credited_base'           => $taxable,
            'employee_rate'           => null,
            'employer_rate'           => null,
            'monthly_employee_amount' => $amount,
            'monthly_employer_amount' => 0.0,
            'monthly_extra_amount'    => 0.0,
            'allocation_factor'       => $factor,
            'employee_amount'         => $amount,
            'employer_amount'         => 0.0,
            'extra_amount'            => 0.0,
            'withholding_period'      => $frequency,
            'bracket_order'           => $bracketOrder,
            'remarks'                 => $remarks,
        ];
    }

    /** BIR table for a period that does not span a whole month. */
    private function taxFrequency(float $factor, array $settings): string
    {
        if ($factor >= 0.99) {
            return 'MONTHLY';
        }

        $configured = strtoupper((string) ($settings['pay_frequency']
            ?? Settings::string('payroll.pay_frequency', 'SEMI_MONTHLY')));

        return match ($configured) {
            'WEEKLY'    => 'WEEKLY',
            'DAILY'     => 'DAILY',
            // BIR publishes no bi-weekly table - the monthly table is applied
            // to the monthly equivalent, which is the standard treatment.
            'BI_WEEKLY' => 'MONTHLY',
            'MONTHLY'   => 'MONTHLY',
            default     => 'SEMI_MONTHLY',
        };
    }

    // -----------------------------------------------------------------------
    // Schedule lookups
    // -----------------------------------------------------------------------

    /** @return array<string, mixed>|null */
    public function scheduleFor(string $code, string $asOf): ?array
    {
        $key = strtoupper($code) . '|' . $asOf;

        if (!array_key_exists($key, $this->scheduleCache)) {
            $this->scheduleCache[$key] = Database::selectOne(
                "SELECT * FROM statutory_schedules
                  WHERE code = :code AND status = 'ACTIVE'
                    AND effective_from <= :as_of_start
                    AND (effective_to IS NULL OR effective_to >= :as_of_end)
                  ORDER BY effective_from DESC
                  LIMIT 1",
                ['code' => strtoupper($code), 'as_of_start' => $asOf, 'as_of_end' => $asOf]
            );
        }

        return $this->scheduleCache[$key];
    }

    /** @return array<string, mixed>|null */
    public function birScheduleFor(string $frequency, string $asOf): ?array
    {
        $key = strtoupper($frequency) . '|' . $asOf;

        if (!array_key_exists($key, $this->birScheduleCache)) {
            $this->birScheduleCache[$key] = Database::selectOne(
                "SELECT * FROM bir_withholding_schedules
                  WHERE frequency = :frequency AND status = 'ACTIVE'
                    AND effective_from <= :as_of_start
                    AND (effective_to IS NULL OR effective_to >= :as_of_end)
                  ORDER BY effective_from DESC
                  LIMIT 1",
                ['frequency' => strtoupper($frequency), 'as_of_start' => $asOf, 'as_of_end' => $asOf]
            );
        }

        return $this->birScheduleCache[$key];
    }

    /** @return array<string, mixed>|null */
    public function birBracket(int $scheduleId, float $compensation): ?array
    {
        if (!isset($this->bracketCache[$scheduleId])) {
            $this->bracketCache[$scheduleId] = Database::select(
                'SELECT * FROM bir_withholding_brackets WHERE schedule_id = :id ORDER BY bracket_order',
                ['id' => $scheduleId]
            );
        }

        $amount = round($compensation, 2);

        foreach ($this->bracketCache[$scheduleId] as $bracket) {
            if ($bracket['compensation_to'] === null || $amount <= (float) $bracket['compensation_to']) {
                return $bracket;
            }
        }

        return $this->bracketCache[$scheduleId] === [] ? null : end($this->bracketCache[$scheduleId]);
    }

    public function clearCache(): void
    {
        $this->scheduleCache   = [];
        $this->birScheduleCache = [];
        $this->bracketCache    = [];
    }

    // -----------------------------------------------------------------------
    // Settings UI support
    // -----------------------------------------------------------------------

    /**
     * Everything the Settings page shows: every schedule version (active or
     * not) plus the BIR tables with their brackets.
     *
     * @return array<string, mixed>
     */
    public function adminOverview(): array
    {
        $schedules = Database::select('SELECT * FROM statutory_schedules ORDER BY code, effective_from DESC');
        $bir       = Database::select('SELECT * FROM bir_withholding_schedules ORDER BY frequency, effective_from DESC');

        $brackets = [];
        foreach (Database::select('SELECT * FROM bir_withholding_brackets ORDER BY schedule_id, bracket_order') as $row) {
            $brackets[(int) $row['schedule_id']][] = $row;
        }

        foreach ($bir as $index => $schedule) {
            $bir[$index]['brackets'] = $brackets[(int) $schedule['id']] ?? [];
        }

        return [
            'schedules'                => $schedules,
            'bir'                      => $bir,
            'codes'                    => self::CODES,
            'frequencies'              => self::FREQUENCIES,
            'reserved_deduction_codes' => self::RESERVED_DEDUCTION_CODES,
            'settings'                 => array_filter(
                Settings::all(),
                static fn (mixed $value, string $key): bool => str_starts_with($key, 'statutory.'),
                ARRAY_FILTER_USE_BOTH
            ),
        ];
    }

    /**
     * Update one schedule version (Settings -> Contributions -> Edit).
     *
     * @param array<string, mixed> $data
     * @return array<string, mixed>
     */
    public function updateSchedule(int $id, array $data, ?int $userId = null): array
    {
        $existing = Database::selectOne('SELECT * FROM statutory_schedules WHERE id = :id', ['id' => $id]);

        if ($existing === null) {
            throw new RuntimeException('Statutory schedule not found.');
        }

        $payload = [];

        foreach (self::SCHEDULE_COLUMNS as $field) {
            if (!array_key_exists($field, $data)) {
                continue;
            }

            $value = $data[$field];

            if (in_array($field, self::NUMERIC_FIELDS, true)) {
                $payload[$field] = ($value === '' || $value === null) ? null : $this->assertNumber($field, $value);
                continue;
            }

            if ($field === 'effective_from' || $field === 'effective_to') {
                $payload[$field] = ($value === '' || $value === null) ? null : $this->assertDate($field, (string) $value);
                continue;
            }

            if ($field === 'rounding') {
                $payload[$field] = strtoupper((string) $value) === 'PESO' ? 'PESO' : 'CENTAVO';
                continue;
            }

            if ($field === 'salary_base') {
                $base = strtoupper((string) $value);
                if (!in_array($base, ['MONTHLY_BASIC', 'MONTHLY_BASIC_PLUS_ALLOWANCES'], true)) {
                    throw new InvalidArgumentException('Salary base must be MONTHLY_BASIC or MONTHLY_BASIC_PLUS_ALLOWANCES.');
                }
                $payload[$field] = $base;
                continue;
            }

            if ($field === 'status') {
                $status = strtoupper((string) $value);
                if (!in_array($status, ['ACTIVE', 'INACTIVE'], true)) {
                    throw new InvalidArgumentException('Status must be ACTIVE or INACTIVE.');
                }
                $payload[$field] = $status;
                continue;
            }

            $payload[$field] = trim((string) $value) === '' ? null : trim((string) $value);
        }

        if ($payload === []) {
            throw new InvalidArgumentException('Nothing to update.');
        }

        if (array_key_exists('effective_from', $payload) && $payload['effective_from'] !== null) {
            $taken = Database::scalar(
                'SELECT id FROM statutory_schedules
                  WHERE code = :code AND effective_from = :from AND id != :id',
                ['code' => $existing['code'], 'from' => $payload['effective_from'], 'id' => $id]
            );
            if ($taken !== null) {
                throw new InvalidArgumentException('Another version of this schedule already starts on that date.');
            }
        }

        Database::update('statutory_schedules', $payload, ['id' => $id]);
        $this->clearCache();

        $updated = Database::selectOne('SELECT * FROM statutory_schedules WHERE id = :id', ['id' => $id]) ?? $existing;
        AuditLogger::recordChanges(
            AuditLogger::STATUTORY_SCHEDULE_CHANGED,
            'statutory_schedule',
            $id,
            $existing,
            $updated
        );

        return $updated;
    }

    /** Update one BIR bracket row (Settings -> Contributions). */
    public function updateBirBracket(int $id, array $data, ?int $userId = null): array
    {
        $existing = Database::selectOne('SELECT * FROM bir_withholding_brackets WHERE id = :id', ['id' => $id]);

        if ($existing === null) {
            throw new RuntimeException('BIR withholding bracket not found.');
        }

        $payload = [];
        foreach (['compensation_from', 'compensation_to', 'base_tax', 'excess_rate', 'excess_over'] as $field) {
            if (!array_key_exists($field, $data)) {
                continue;
            }
            $value = $data[$field];
            $payload[$field] = ($value === '' || $value === null) ? null : $this->assertNumber($field, $value);
        }

        if (array_key_exists('notes', $data)) {
            $payload['notes'] = trim((string) $data['notes']) === '' ? null : trim((string) $data['notes']);
        }

        if ($payload === []) {
            throw new InvalidArgumentException('Nothing to update.');
        }
        if (array_key_exists('compensation_from', $payload) && $payload['compensation_from'] === null) {
            throw new InvalidArgumentException('The bracket start is required.');
        }

        Database::update('bir_withholding_brackets', $payload, ['id' => $id]);
        $this->clearCache();

        $updated = Database::selectOne('SELECT * FROM bir_withholding_brackets WHERE id = :id', ['id' => $id]) ?? $existing;
        AuditLogger::recordChanges(
            AuditLogger::STATUTORY_SCHEDULE_CHANGED,
            'bir_withholding_bracket',
            $id,
            $existing,
            $updated
        );

        return $updated;
    }

    /**
     * Publish a new version by copying the latest one and starting it on the
     * given date. The previous version is closed the day before.
     *
     * @return array<string, mixed>
     */
    public function createVersion(string $type, string $effectiveFrom, ?int $userId = null): array
    {
        $type    = strtoupper(trim($type));
        $effectiveFrom = $this->assertDate('effective_from', $effectiveFrom);

        // A contribution schedule (one of the agencies above, or any other
        // code already present - useful for a company-specific levy).
        if (in_array($type, self::CODES, true) || $this->scheduleCodeExists($type)) {
            return Database::transaction(fn (): array => $this->cloneContribution($type, $effectiveFrom, $userId));
        }

        if ($type === 'BIR') {
            return Database::transaction(function () use ($effectiveFrom, $userId): array {
                $created = [];
                foreach (self::FREQUENCIES as $frequency) {
                    $created[] = $this->cloneBir($frequency, $effectiveFrom, $userId);
                }

                return ['type' => 'BIR', 'effective_from' => $effectiveFrom, 'versions' => $created];
            });
        }

        if (in_array($type, self::FREQUENCIES, true)) {
            return Database::transaction(fn (): array => $this->cloneBir($type, $effectiveFrom, $userId));
        }

        throw new InvalidArgumentException('Unknown statutory schedule type.');
    }

    private function scheduleCodeExists(string $code): bool
    {
        return Database::scalar('SELECT id FROM statutory_schedules WHERE code = :code LIMIT 1', ['code' => $code]) !== null;
    }

    /** @return array<string, mixed> */
    private function cloneContribution(string $code, string $effectiveFrom, ?int $userId): array
    {
        $latest = Database::selectOne(
            'SELECT * FROM statutory_schedules WHERE code = :code ORDER BY effective_from DESC LIMIT 1',
            ['code' => $code]
        );

        if ($latest === null) {
            throw new RuntimeException(sprintf('There is no %s schedule to copy. Create the first version first.', $code));
        }

        // A version is always the same contribution computed with new numbers,
        // so every descriptive column (code, name, agency, scheme, source...)
        // travels with the copy. Only the version markers change.
        $payload = array_diff_key($latest, array_flip([
            'id', 'effective_from', 'effective_to', 'status', 'created_at', 'updated_at', 'created_by',
        ]));

        $payload['effective_from'] = $effectiveFrom;
        $payload['effective_to']   = null;
        $payload['status']         = 'ACTIVE';
        $payload['created_by']     = $userId;

        $id = Database::insert('statutory_schedules', $payload);

        $this->closePreviousVersion(
            'statutory_schedules',
            'code',
            $code,
            (int) $latest['id'],
            $effectiveFrom,
            $userId
        );

        $this->clearCache();

        AuditLogger::record(
            AuditLogger::STATUTORY_SCHEDULE_CHANGED,
            'statutory_schedule',
            $id,
            sprintf('Published a new %s schedule effective %s (copied from version %s)', $code, $effectiveFrom, $latest['effective_from']),
            null,
            ['effective_from' => $effectiveFrom, 'copied_from' => $latest['effective_from']]
        );

        return Database::selectOne('SELECT * FROM statutory_schedules WHERE id = :id', ['id' => $id]) ?? [];
    }

    /** @return array<string, mixed> */
    private function cloneBir(string $frequency, string $effectiveFrom, ?int $userId): array
    {
        $latest = Database::selectOne(
            'SELECT * FROM bir_withholding_schedules WHERE frequency = :frequency ORDER BY effective_from DESC LIMIT 1',
            ['frequency' => $frequency]
        );

        if ($latest === null) {
            throw new RuntimeException(sprintf('There is no %s BIR table to copy.', $frequency));
        }

        $scheduleId = Database::insert('bir_withholding_schedules', [
            'frequency'      => $frequency,
            'effective_from' => $effectiveFrom,
            'effective_to'   => null,
            'source_name'    => $latest['source_name'],
            'source_url'     => $latest['source_url'],
            'notes'          => $latest['notes'],
            'status'         => 'ACTIVE',
            'created_by'     => $userId,
        ]);

        $brackets = Database::select(
            'SELECT * FROM bir_withholding_brackets WHERE schedule_id = :id ORDER BY bracket_order',
            ['id' => (int) $latest['id']]
        );

        foreach ($brackets as $bracket) {
            Database::insert('bir_withholding_brackets', [
                'schedule_id'       => $scheduleId,
                'bracket_order'     => (int) $bracket['bracket_order'],
                'compensation_from' => $bracket['compensation_from'],
                'compensation_to'   => $bracket['compensation_to'],
                'base_tax'          => $bracket['base_tax'],
                'excess_rate'       => $bracket['excess_rate'],
                'excess_over'       => $bracket['excess_over'],
                'notes'             => $bracket['notes'],
            ]);
        }

        $this->closePreviousVersion(
            'bir_withholding_schedules',
            'frequency',
            $frequency,
            (int) $latest['id'],
            $effectiveFrom,
            $userId
        );

        $this->clearCache();

        AuditLogger::record(
            AuditLogger::STATUTORY_SCHEDULE_CHANGED,
            'bir_withholding_schedule',
            $scheduleId,
            sprintf('Published a new %s BIR withholding table effective %s (copied from %s)', $frequency, $effectiveFrom, $latest['effective_from']),
            null,
            ['effective_from' => $effectiveFrom, 'brackets' => count($brackets)]
        );

        $created = Database::selectOne('SELECT * FROM bir_withholding_schedules WHERE id = :id', ['id' => $scheduleId]) ?? [];
        $created['brackets'] = Database::select(
            'SELECT * FROM bir_withholding_brackets WHERE schedule_id = :id ORDER BY bracket_order',
            ['id' => $scheduleId]
        );

        return $created;
    }

    /** Close the previous version the day before the new one starts. */
    private function closePreviousVersion(
        string $table,
        string $keyColumn,
        string $keyValue,
        int $previousId,
        string $newFrom,
        ?int $userId
    ): void {
        $dayBefore = (new DateTimeImmutable($newFrom))->modify('-1 day')->format('Y-m-d');

        Database::execute(
            sprintf(
                'UPDATE `%s` SET effective_to = :day_before
                  WHERE `%s` = :key_value AND id = :id
                    AND (effective_to IS NULL OR effective_to >= :new_from)',
                $table,
                $keyColumn
            ),
            [
                'day_before' => $dayBefore,
                'key_value'  => $keyValue,
                'id'         => $previousId,
                'new_from'   => $newFrom,
            ]
        );
    }

    // -----------------------------------------------------------------------
    // Small helpers
    // -----------------------------------------------------------------------

    /** @param array<string, mixed> $schedule */
    private function clamp(float $value, array $schedule): float
    {
        if ($schedule['salary_floor'] !== null) {
            $value = max($value, (float) $schedule['salary_floor']);
        }
        if ($schedule['salary_ceiling'] !== null) {
            $value = min($value, (float) $schedule['salary_ceiling']);
        }

        return $value;
    }

    private function money(float $value, string $rounding): float
    {
        return $rounding === 'PESO'
            ? (float) round($value, 0)
            : (float) round($value, 2);
    }

    private function rateLabel(float $rate): string
    {
        $formatted = rtrim(rtrim(number_format($rate, 2, '.', ''), '0'), '.');

        return $formatted . '%';
    }

    /** @param array<string, mixed> $settings */
    private function allocationBasis(array $settings): string
    {
        $basis = strtoupper((string) ($settings['statutory_allocation_basis']
            ?? Settings::string('statutory.allocation_basis', 'CALENDAR_DAYS')));

        return $basis === 'EQUAL_SPLIT' ? 'EQUAL_SPLIT' : 'CALENDAR_DAYS';
    }

    private function assertNumber(string $field, mixed $value): float
    {
        if (!is_numeric($value)) {
            throw new InvalidArgumentException(sprintf('%s must be a number.', $field));
        }

        $number = (float) $value;

        if ($number < 0) {
            throw new InvalidArgumentException(sprintf('%s cannot be negative.', $field));
        }
        if (in_array($field, ['employee_rate', 'employer_rate', 'low_employee_rate', 'low_employer_rate'], true) && $number > 100) {
            throw new InvalidArgumentException(sprintf('%s must be a percentage between 0 and 100.', $field));
        }
        if ($field === 'excess_rate' && $number > 100) {
            throw new InvalidArgumentException('excess_rate must be a percentage between 0 and 100.');
        }

        return $number;
    }

    private function assertDate(string $field, string $value): string
    {
        if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $value)) {
            throw new InvalidArgumentException(sprintf('%s must be a date in YYYY-MM-DD form.', $field));
        }

        return (new DateTimeImmutable($value))->format('Y-m-d');
    }
}