<?php
/**
 * Employee management (Phase 4) with automatic QR issuing (Phase 5).
 *
 * Registration flow from the brief:
 *   Register Employee -> Generate Employee ID -> Generate secure random QR
 *   token -> Save token -> Generate QR image -> Save QR image.
 *
 * Multi-step writes run inside a transaction so a half-created employee can
 * never exist (development rule 4).
 */

declare(strict_types=1);

namespace App\Services;

use App\Core\AuditLogger;
use App\Core\Auth;
use App\Core\Database;
use App\Core\Logger;
use App\Core\ValidationException;
use App\Core\Validator;
use RuntimeException;

final class EmployeeService
{
    // Business rule: ALL employees (Manager, Staff, others) are FULL_TIME.
    // The form no longer offers a choice; the backend forces FULL_TIME too.
    public const EMPLOYMENT_TYPES = ['FULL_TIME'];
    public const GENDERS          = ['MALE', 'FEMALE', 'OTHER'];
    public const SALARY_TYPES     = ['MONTHLY', 'SEMI_MONTHLY']; // Legacy MONTHLY is valid for reading, never daily/hourly new hires.
    public const STATUSES         = ['ACTIVE', 'INACTIVE', 'SUSPENDED', 'RESIGNED', 'TERMINATED'];

    public function __construct(private QrCodeService $qrService = new QrCodeService())
    {
    }

    /** The QR service, exposed so controllers can issue or read codes. */
    public function qrService(): QrCodeService
    {
        return $this->qrService;
    }

    /** Reject duplicate normalized full names (including inactive employees).
     *  Application validation; create/edit is also protected by a database advisory name lock
     *  in the transaction below, to prevent simultaneous duplicate submissions. */
    private function assertNameNotUsed(array $name, ?int $exceptId = null): void
    {
        $first = trim((string) ($name['first_name'] ?? ''));
        $last = trim((string) ($name['last_name'] ?? ''));
        $middle = trim((string) ($name['middle_name'] ?? ''));
        if ($first === '' || $last === '') { return; }
        $row = Database::scalar(
            "SELECT id FROM employees WHERE LOWER(TRIM(first_name)) = LOWER(:first)
                 AND LOWER(TRIM(COALESCE(last_name, ''))) = LOWER(:last)
                 AND LOWER(TRIM(COALESCE(middle_name, ''))) = LOWER(:middle)
                 AND (:skip IS NULL OR id <> :exclude) LIMIT 1",
            ['first'=>$first, 'last'=>$last, 'middle'=>$middle, 'skip'=>$exceptId, 'exclude'=>$exceptId ?? 0]
        );
        if ($row !== null) {
            throw new ValidationException(['first_name' => 'An employee with the same full name already exists. Verify the existing record instead of creating a duplicate.']);
        }
    }

    /** Sequential employee number: EMP-000001. */
    public function nextEmployeeNumber(): string
    {
        $max = (int) (Database::scalar(
            "SELECT COALESCE(MAX(CAST(SUBSTRING(employee_number, 5) AS UNSIGNED)), 0)
               FROM employees
              WHERE employee_number LIKE 'EMP-%'"
        ) ?? 0);

        $next = $max + 1;

        // Skip a number that somehow already exists (defensive).
        while (Database::scalar(
            'SELECT id FROM employees WHERE employee_number = :n',
            ['n' => 'EMP-' . sprintf('%06d', $next)]
        ) !== null) {
            $next++;
        }

        return 'EMP-' . sprintf('%06d', $next);
    }

    /**
     * Validation rules shared by create and update.
     *
     * Middle name is optional; suffix is legacy (ignored on write).
     *
     * @return array<string, string>
     */
    public static function rules(bool $forUpdate = false): array
    {
        $required = $forUpdate ? '' : 'required|';

        return [
            'first_name'       => $required . 'string|min:1|max:100',
            'middle_name'      => 'nullable|string|max:100',
            // Nullable in the schema (`last_name VARCHAR(100) NULL`) and already
            // optional on update; requiring it on create only blocked legitimate
            // payloads and contradicted every consumer that tolerates its absence.
            'last_name'        => ($forUpdate ? 'nullable' : 'required') . '|string|min:1|max:100',
            'gender'           => $required . 'in:' . implode(',', self::GENDERS),
            'birth_date'       => 'nullable|date',
            'address'          => 'nullable|string|max:255',
            'contact_number'   => 'nullable|string|regex:/^09[0-9]{9}$/',
            'email'            => 'nullable|email|max:150',
            'department_id'    => 'nullable|integer',
            'assigned_supervisor_id' => 'nullable|integer',
            // Deliberately not type-constrained: resolvePosition() accepts either
            // a numeric positions.id or the role strings "STAFF"/"MANAGER", so a
            // `string` rule here rejected the numeric id the API allows.
            'position_id'      => 'nullable|max:50',
            'position_role'    => 'nullable|in:STAFF,MANAGER', // backwards compatibility only
            'account_role'     => 'nullable|in:STAFF,MANAGER,HR_PAYROLL,ADMIN',
            'employment_type'  => $required . 'in:' . implode(',', self::EMPLOYMENT_TYPES),
            'date_hired'       => $required . 'date',
            'salary_type'      => $required . 'in:' . implode(',', self::SALARY_TYPES),
            'basic_salary'     => $required . 'numeric|min:0',
            'work_schedule_id' => 'nullable|integer',
            'payroll_eligible'  => 'nullable|in:0,1',
            'status'           => 'nullable|in:' . implode(',', self::STATUSES),
            'notes'            => 'nullable|string|max:2000',
            'sss_number'       => 'nullable|string|max:30',
            'philhealth_number'=> 'nullable|string|max:30',
            'pagibig_number'   => 'nullable|string|max:30',
            'tin'              => 'nullable|string|max:30',
            // Account credentials are required when creating an employee. The
            // `required` prefix is applied on create only (update keeps them
            // nullable); the `same:` rule enforces the password match.
            'account_username'       => ($forUpdate ? 'nullable' : 'required') . '|string|min:1|max:100',
            'account_password'       => ($forUpdate ? 'nullable' : 'required') . '|string|min:1|max:255',
            'account_password_confirm' => ($forUpdate ? 'nullable' : 'required') . '|string|min:1|max:255|same:account_password',
        ];
    }

    /**
     * Normalise frontend payloads: empty strings become null so nullable
     * integer / date columns never receive "" (which broke add/edit when a
     * select was left on its placeholder).
     *
     * @param array<string, mixed> $data
     * @return array<string, mixed>
     */
    private static function normalizeInput(array $data): array
    {
        $nullable = [
            'middle_name', 'last_name', 'birth_date', 'address',
            'contact_number', 'email', 'department_id', 'assigned_supervisor_id', 'position_id',
            'work_schedule_id', 'status', 'notes',
            'sss_number', 'philhealth_number', 'pagibig_number', 'tin',
        ];

        foreach ($nullable as $field) {
            if (array_key_exists($field, $data) && ($data[$field] === '' || $data[$field] === 'null')) {
                $data[$field] = null;
            }
        }

        foreach (['first_name', 'last_name', 'middle_name', 'email', 'contact_number'] as $field) {
            if (isset($data[$field]) && is_string($data[$field])) {
                $trimmed = trim($data[$field]);
                $data[$field] = $trimmed === '' && in_array($field, $nullable, true) ? null : $trimmed;
            }
        }

        // Legacy suffix field is dropped: the column stays for old rows but new
        // writes always store NULL so names are "First [Middle] Last".
        $data['suffix'] = null;
        unset($data['suffix']);

        // Business rule: ALL employees are FULL_TIME. Force it server-side so
        // manually submitted PART_TIME/CONTRACT/PROBATIONARY/INTERN can never
        // be saved. The column itself is kept unchanged.
        $data['employment_type'] = 'FULL_TIME';

        return $data;
    }
/**
     * Create an employee, the initial salary history row, the leave balances
     * and the QR code — all atomically.
     *
     * @param array<string, mixed> $data
     * @return array<string, mixed>
     */
    public function create(array $data, ?int $userId = null): array
    {
        $data = self::normalizeInput($data);
        $data['salary_type'] = 'SEMI_MONTHLY'; // Fixed monthly salary, paid in two cutoffs.
        // Trim the account username before validation so '  mich  ' is checked
        // as 'mich' (consistent with the uniqueness lookup below).
        if (isset($data['account_username']) && is_string($data['account_username'])) {
            $data['account_username'] = trim($data['account_username']);
        }
        $validator = Validator::make($data, self::rules());
        if ($validator->fails()) {
            throw new ValidationException($validator->errors());
        }

        $validated = $validator->validated();
        if (\App\Core\DemoStaffScope::enabled()) {
            // Any new account stays outside the one-person defense payroll.
            $validated['payroll_eligible'] = 0;
        }
        $this->assertNameNotUsed($validated);
        $validated = $this->resolvePosition($validated);
        $this->assertAccountRoleAllowed((string) ($validated['account_role'] ?? 'STAFF'));
        if (!\App\Core\DemoStaffScope::enabled()
            && in_array((string)($validated['account_role'] ?? 'STAFF'), ['HR_PAYROLL','MANAGER'], true)
            && (int)($validated['payroll_eligible'] ?? 1) === 0) {
            throw new ValidationException(['payroll_eligible'=>'HR and Manager employees must remain payroll eligible.']);
        }

        $this->assertReferencesExist($validated);
        $this->assertEmailAvailable($validated['email'] ?? null);
        if (!empty($validated['email']) && Database::scalar(
            'SELECT id FROM users WHERE email = :email',
            ['email' => $validated['email']]
        ) !== null) {
            throw new ValidationException(['email' => 'This email already belongs to a system account.']);
        }

        // Pre-check the username BEFORE any insert. The unique index applies to
        // every row, including archived/soft-deleted ones, so no
        // `deleted_at IS NULL` filter is used here.
        $accountUsername = trim((string) ($validated['account_username'] ?? ''));
        if ($accountUsername === '') {
            throw new ValidationException(['account_username' => 'The Account Username is required.']);
        }
        if (Database::scalar(
            'SELECT id FROM users WHERE username = :username',
            ['username' => $accountUsername]
        ) !== null) {
            throw new ValidationException(['account_username' => 'This username is already taken. Please choose another.']);
        }

        // Both password fields are required on create (see rules()) and the
        // `same:` rule already rejects mismatches; double-check here so a
        // missing confirm can never slip through to the insert below.
        $accountPassword = (string) ($validated['account_password'] ?? '');
        $accountConfirm  = (string) ($validated['account_password_confirm'] ?? '');
        if ($accountPassword === '' || $accountConfirm === '') {
            throw new ValidationException(['account_password' => 'The account password and confirmation are required.']);
        }
        if ($accountPassword !== $accountConfirm) {
            throw new ValidationException(['account_password_confirm' => 'The password confirmation does not match.']);
        }

        $userId = $userId ?? Auth::id();

        $nameLock = 'pms_new_employee_' . substr(hash('sha256', mb_strtolower(trim((string)$validated['first_name']) . '|' . trim((string)($validated['middle_name'] ?? '')) . '|' . trim((string)($validated['last_name'] ?? '')))), 0, 40);
        if ((int) Database::scalar('SELECT GET_LOCK(:lock_name,5)', ['lock_name'=>$nameLock]) !== 1) {
            throw new ValidationException(['first_name'=>'Another employee registration is in progress. Please retry.']);
        }
        try {
            $this->assertNameNotUsed($validated);
            return Database::transaction(function () use ($validated, $userId, $accountUsername, $accountPassword): array {
            $employeeNumber = $this->nextEmployeeNumber();

            $employeeId = Database::insert('employees', [
                'employee_number'  => $employeeNumber,
                'first_name'       => $validated['first_name'],
                'middle_name'      => $validated['middle_name'] ?? null,
                'last_name'        => $validated['last_name'] ?? null,
                'suffix'           => null,
                'gender'           => $validated['gender'],
                'birth_date'       => $validated['birth_date'] ?? null,
                'address'          => $validated['address'] ?? null,
                'contact_number'   => $validated['contact_number'] ?? null,
                'email'            => $validated['email'] ?? null,
                'department_id'    => $validated['department_id'] ?? null,
                'assigned_supervisor_id' => $validated['assigned_supervisor_id'] ?? null,
                'position_id'      => $validated['position_id'] ?? null,
                'employment_type'  => $validated['employment_type'],
                'date_hired'       => $validated['date_hired'],
                'salary_type'      => $validated['salary_type'],
                'basic_salary'     => (float) $validated['basic_salary'],
                // Respect the assigned 5-day/6-day work schedule. If none was
                // selected, use the configured default (usually Mon-Sat).
                'work_schedule_id' => $this->monSatScheduleId() ?? $this->defaultScheduleId(),
                'status'           => $validated['status'] ?? 'ACTIVE',
                'payroll_eligible' => (int)($validated['payroll_eligible'] ?? 1),
                'notes'            => $validated['notes'] ?? null,
                'sss_number'       => $validated['sss_number'] ?? null,
                'philhealth_number'=> $validated['philhealth_number'] ?? null,
                'pagibig_number'   => $validated['pagibig_number'] ?? null,
                'tin'              => $validated['tin'] ?? null,
                'created_by'       => $userId,
            ]);

            // The employee record is the source of truth for access. Every
            // employee receives one linked account; only Admin is system-only.
            // Username/password were validated above and are required — never
            // fall back to a generated name or a default password here.
            $accountRole = $this->accountRoleByCode((string) ($validated['account_role'] ?? 'STAFF'));

            try {
                Database::insert('users', [
                    'username'      => $accountUsername,
                    'email'         => $validated['email'] ?? null,
                    'password_hash' => password_hash($accountPassword, PASSWORD_DEFAULT),
                    'full_name'     => trim($validated['first_name'] . ' ' . ($validated['last_name'] ?? '')),
                    'role_id'       => $accountRole['id'],
                    'employee_id'   => $employeeId,
                    'status'        => 'ACTIVE',
                ]);
            } catch (\PDOException $e) {
                // Log the real DB message for developers (transaction rolls
                // back the employee insert automatically); users only see a
                // field-level validation error, never SQL or password data.
                Logger::error('Employee account creation failed', [
                    'error'    => $e->getMessage(),
                    'username' => $accountUsername,
                    'email'    => $validated['email'] ?? null,
                ]);
                $message = (string) $e->getMessage();
                if (str_contains($message, 'uq_users_username') || (str_contains($message, 'Duplicate entry') && str_contains($message, 'users.username'))) {
                    throw new ValidationException(['account_username' => 'This username is already taken. Please choose another.']);
                }
                if (str_contains($message, 'uq_users_email') || (str_contains($message, 'Duplicate entry') && str_contains($message, 'users.email'))) {
                    throw new ValidationException(['email' => 'This email already belongs to a system account.']);
                }
                throw new ValidationException(['account_username' => 'Could not create the login account. Please try again.']);
            }

            // Initial salary history (Phase 4).
            Database::insert('salary_history', [
                'employee_id'    => $employeeId,
                'salary_type'    => $validated['salary_type'],
                'basic_salary'   => (float) $validated['basic_salary'],
                'effective_from' => $validated['date_hired'],
                'reason'         => 'Initial salary on hire',
                'changed_by'     => $userId,
            ]);

            // Leave credits for the current year (Phase 10).
            $this->initialiseLeaveBalances($employeeId, (int) date('Y'));

            // HR can still register operators or excluded staff; only a demo
            // participant receives an attendance QR. No employee data is removed.
            $qr = \App\Core\DemoStaffScope::participates($employeeId)
                ? $this->qrService->issue($employeeId, $userId)
                : null;

            $employee = $this->find($employeeId);

            AuditLogger::record(
                AuditLogger::EMPLOYEE_CREATED,
                'employee',
                $employeeId,
                sprintf('Created employee %s', $this->fullName($employee)),
                null,
                $employee
            );

            return [
                'employee' => $employee,
                'qr' => $qr === null ? null : [
                    'qr_id'     => $qr['qr_id'],
                    'token'     => $qr['token'],
                    'image'     => $qr['image'],
                    'serial_no' => $qr['serial_no'],
                ],
                'account'  => [
                    'username' => $accountUsername,
                    'role'     => $accountRole['code'],
                ],
            ];
        });
        } finally {
            Database::scalar('SELECT RELEASE_LOCK(:lock_name)', ['lock_name'=>$nameLock]);
        }
    }

    /**
     * Resolve the Staff/Manager-only position model.
     *
     * The UI offers exactly two choices (Staff, Manager). Callers may send
     * position_role, or position_id as a numeric id, "STAFF"/"MANAGER", or a
     * legacy position id. Legacy ids are honoured; the two generic positions
     * are created on demand so fresh and existing installs behave the same.
     *
     * @param array<string, mixed> $validated
     * @return array<string, mixed>
     */
    private function resolvePosition(array $validated): array
    {
        $role = null;
        if (!empty($validated['position_role'])) {
            $role = strtoupper((string) $validated['position_role']);
        } elseif (isset($validated['position_id']) && is_string($validated['position_id'])) {
            $upper = strtoupper(trim($validated['position_id']));
            if ($upper === 'STAFF' || $upper === 'MANAGER') {
                $role = $upper;
            }
        }

        if ($role !== null) {
            $validated['position_id'] = $this->ensureGenericPosition($role);
        } elseif (isset($validated['position_id']) && $validated['position_id'] !== null && $validated['position_id'] !== '') {
            // Legacy numeric id: keep it, but if it points at a deleted row fall
            // back to the generic Staff position so the save never fails.
            $exists = Database::scalar(
                'SELECT id FROM positions WHERE id = :id AND deleted_at IS NULL',
                ['id' => (int) $validated['position_id']]
            );
            if ($exists === null) {
                $validated['position_id'] = $this->ensureGenericPosition('STAFF');
            } else {
                $validated['position_id'] = (int) $validated['position_id'];
            }
        } else {
            $validated['position_id'] = null;
            if ($role !== null) {
                $validated['position_id'] = $this->ensureGenericPosition($role);
            }
        }

        unset($validated['position_role']);

        return $validated;
    }

    /** Ensure the generic Staff/Manager position exists; return its id. */
    private function ensureGenericPosition(string $role): int
    {
        $role = strtoupper($role) === 'MANAGER' ? 'MANAGER' : 'STAFF';
        $code = $role === 'MANAGER' ? 'MANAGER' : 'STAFF';
        $name = $role === 'MANAGER' ? 'Manager' : 'Staff';

        $id = Database::scalar(
            'SELECT id FROM positions WHERE code = :code AND deleted_at IS NULL',
            ['code' => $code]
        );

        if ($id !== null) {
            return (int) $id;
        }

        return (int) Database::insert('positions', [
            'code' => $code,
            'name' => $name,
            'department_id' => null,
            'job_level' => $role === 'MANAGER' ? 'Manager' : 'Staff',
            'description' => $role === 'MANAGER' ? 'Managerial role' : 'Staff role',
            'is_active' => 1,
        ]);
    }

    /** A position (Cashier, etc.) must never silently confer a privileged login role. */
    private function assertAccountRoleAllowed(string $code): void
    {
        if (!in_array($code, ['STAFF', 'MANAGER', 'HR_PAYROLL', 'ADMIN'], true)) {
            throw new ValidationException(['account_role' => 'Choose a valid system account role.']);
        }
        // HR can onboard staff, but cannot grant Manager or HR permissions.
        if ($code !== 'STAFF' && Auth::roleCode() !== 'ADMIN') {
            throw new ValidationException(['account_role' => 'Only Admin can assign Admin, Manager, or HR/Payroll roles.']);
        }
    }

    /** @return array{id:int,code:string} */
    private function accountRoleByCode(string $code): array
    {
        $this->assertAccountRoleAllowed($code);
        $id = Database::scalar('SELECT id FROM roles WHERE code = :code', ['code' => $code]);
        if ($id === null) {
            throw new ValidationException(['account_role' => 'The selected role has not been installed. Run the four-role migration.']);
        }
        return ['id' => (int) $id, 'code' => $code];
    }

    /** @return array{id:int,code:string} */
    private function accountRole(mixed $positionId): array
    {
        // Direct role strings (from the Staff/Manager-only form) win.
        if (is_string($positionId) && in_array(strtoupper(trim($positionId)), ['STAFF', 'MANAGER'], true)) {
            $code = strtoupper(trim($positionId));
            $id = Database::scalar('SELECT id FROM roles WHERE code = :code', ['code' => $code]);
            if ($id === null) {
                throw new RuntimeException("The {$code} role is not configured.");
            }
            return ['id' => (int) $id, 'code' => $code];
        }

        $manager = false;
        if ($positionId !== null && $positionId !== '') {
            $position = Database::selectOne(
                'SELECT name, job_level, code FROM positions WHERE id = :id AND deleted_at IS NULL',
                ['id' => (int) $positionId]
            );
            if ($position !== null && in_array(strtoupper((string) ($position['code'] ?? '')), ['STAFF', 'MANAGER'], true)) {
                $manager = strtoupper((string) $position['code']) === 'MANAGER';
            } else {
                $descriptor = strtolower(trim(($position['job_level'] ?? '') . ' ' . ($position['name'] ?? '')));
                $manager = preg_match('/\b(manager|supervisor)\b/', $descriptor) === 1;
            }
        }

        $code = $manager ? 'MANAGER' : 'STAFF';
        $id = Database::scalar('SELECT id FROM roles WHERE code = :code', ['code' => $code]);
        if ($id === null) {
            throw new RuntimeException("The {$code} role is not configured.");
        }

        return ['id' => (int) $id, 'code' => $code];
    }

    private function nextAccountUsername(string $firstName, string $lastName, string $email): string
    {
        $source = $email !== '' ? explode('@', $email, 2)[0] : $firstName . $lastName;
        $base = strtolower((string) preg_replace('/[^a-z0-9_-]+/i', '', $source));
        if (strlen($base) < 3) {
            $base = strtolower((string) preg_replace('/[^a-z0-9]+/i', '', $firstName . $lastName . 'staff'));
        }
        $base = substr($base, 0, 90);
        $username = $base;
        $suffix = 2;
        while (Database::scalar('SELECT id FROM users WHERE username = :username', ['username' => $username]) !== null) {
            $username = substr($base, 0, 90) . $suffix;
            $suffix++;
        }
        return $username;
    }

    /**
     * Issue a temporary password for the employee's linked account.
     *
     * The employee is the user, so this lives on the employee rather than
     * the retired user-management screen: the account is reconciled first,
     * which means an admin can recover access for an employee whose login
     * was archived or never issued.
     *
     * A new cryptographically random temporary password is created on reset:
     * it is only a way back in, because must_change_password forces the
     * employee to pick a real one before the account does anything else.
     *
     * @return array{id:int, username:string, temporary_password:string, created:bool}
     */
    public function resetAccountPassword(int $id): array
    {
        $employee = Database::selectOne(
            'SELECT * FROM employees WHERE id = :id AND deleted_at IS NULL',
            ['id' => $id]
        );

        if ($employee === null) {
            throw new RuntimeException('Employee not found.');
        }

        // A soft-deleted or archived account would silently swallow the reset,
        // so bring the login back before writing the new password.
        $account = $this->ensureAccount($employee);
        $accountId = (int) $account['id'];
        $temporary = bin2hex(random_bytes(12));

        Database::update('users', [
            'password_hash'        => password_hash($temporary, PASSWORD_DEFAULT),
            'must_change_password' => 1,
        ], ['id' => $accountId]);

        Auth::revokeAllTokens($accountId);

        AuditLogger::record(
            AuditLogger::PASSWORD_CHANGED,
            'user',
            $accountId,
            sprintf(
                'Password reset for employee %s (username "%s", temporary password issued)',
                $this->fullName($employee),
                (string) $account['username']
            )
        );

        return [
            'id'                 => $accountId,
            'username'           => (string) $account['username'],
            'temporary_password' => $temporary,
            'created'            => (bool) ($account['is_new'] ?? false),
            'is_new'             => (bool) ($account['is_new'] ?? false),
        ];
    }

    /**
     * Guarantee the employee's login exists and is usable.
     *
     * The employee record is the source of truth for access, so this is the
     * single place that reconciles the two: an account that exists is
     * reactivated (and revived if it was soft-deleted), and one that is
     * genuinely absent is created with the role derived from the employee's
     * position.
     *
     * Reviving matters because a soft-deleted row still owns its username and
     * email — inserting a replacement would violate the unique indexes.
     *
     * @return array<string, mixed> the account row
     */
    private function ensureAccount(array $employee): array
    {
        $employeeId = (int) $employee['id'];

        // Prefer a live account, otherwise fall back to the retired one.
        $existing = Database::selectOne(
            'SELECT u.* FROM users u
              WHERE u.employee_id = :emp
              ORDER BY (u.deleted_at IS NULL) DESC, u.id
              LIMIT 1',
            ['emp' => $employeeId]
        );

        if ($existing !== null) {
            $changes = [];

            if ($existing['status'] !== 'ACTIVE')    { $changes['status'] = 'ACTIVE'; }
            if ($existing['deleted_at'] !== null)    { $changes['deleted_at'] = null; }

            if ($changes !== []) {
                Database::update('users', $changes, ['id' => (int) $existing['id']]);
            }

            return $changes === []
                ? $existing
                : array_merge($existing, $changes);
        }

        $role = $this->accountRoleByCode('STAFF');

        $username = $this->nextAccountUsername(
            (string) ($employee['first_name'] ?? ''),
            (string) ($employee['last_name'] ?? ''),
            (string) ($employee['email'] ?? '')
        );

        // Only claim the email when no other row (including retired ones) owns it.
        $email = $employee['email'] ?? null;
        if ($email !== null && Database::scalar(
            'SELECT id FROM users WHERE email = :email',
            ['email' => $email]
        ) !== null) {
            $email = null;
        }

        $accountId = Database::insert('users', [
            'username'      => $username,
            'email'         => $email,
            'password_hash' => password_hash(bin2hex(random_bytes(24)), PASSWORD_DEFAULT),
            'must_change_password' => 1,
            'full_name'     => $this->fullName($employee),
            'role_id'       => $role['id'],
            'employee_id'   => $employeeId,
            'status'        => 'ACTIVE',
        ]);

        return [
            'id'          => $accountId,
            'username'    => $username,
            'role_id'     => $role['id'],
            'employee_id' => $employeeId,
            'status'      => 'ACTIVE',
            'is_new'      => true,
        ];
    }
/**
     * Update an employee. Salary changes are recorded in salary_history and
     * in the audit trail (Phase 4 / Phase 18).
     *
     * @param array<string, mixed> $data
     * @return array<string, mixed>
     */
    public function update(int $id, array $data, ?int $userId = null): array
    {
        // Account credentials are create-only: strip any stale account_* keys
        // a caller may still send so an Edit can never touch the login.
        unset($data['account_username'], $data['account_password'], $data['account_password_confirm']);
        $data = self::normalizeInput($data);
        $validator = Validator::make($data, self::rules(true));
        if ($validator->fails()) {
            throw new ValidationException($validator->errors());
        }

        $validated = $this->resolvePosition($validator->validated());
        if (\App\Core\DemoStaffScope::enabled() && array_key_exists('payroll_eligible', $data)) {
            $shouldBeEligible = $id === 1 && (string) Database::scalar(
                'SELECT employee_number FROM employees WHERE id=:id', ['id'=>$id]
            ) === 'EMP-000001';
            if ((int)($data['payroll_eligible']) !== ($shouldBeEligible ? 1 : 0)) {
                throw new ValidationException(['payroll_eligible' =>
                    'For this defense demo only EMP-000001 is payroll eligible. The existing employee history is preserved.']);
            }
        }
        if (isset($data['account_role']) && $data['account_role'] !== '') {
            $this->assertAccountRoleAllowed((string) $data['account_role']);
        }

        $existing = Database::selectOne(
            'SELECT * FROM employees WHERE id = :id AND deleted_at IS NULL',
            ['id' => $id]
        );

        if ($existing === null) {
            throw new RuntimeException('Employee not found.');
        }
        $this->assertNameNotUsed(array_merge($existing, array_filter([
            'first_name' => $validated['first_name'] ?? null,
            'middle_name' => $validated['middle_name'] ?? null,
            'last_name' => $validated['last_name'] ?? null,
        ], static fn($v) => $v !== null)), $id);

        // Validate the effective department-position combination on a partial edit.
        $effectiveDepartment = array_key_exists('department_id', $data)
            ? ($validated['department_id'] ?? null) : ($existing['department_id'] ?? null);
        $effectivePosition = array_key_exists('position_id', $data)
            ? ($validated['position_id'] ?? null) : ($existing['position_id'] ?? null);
        if ($effectivePosition !== null && $effectiveDepartment !== null) {
            $positionRow = Database::selectOne(
                'SELECT department_id FROM positions WHERE id = :id AND deleted_at IS NULL',
                ['id' => (int) $effectivePosition]
            );
            if ($positionRow !== null && (int) ($positionRow['department_id'] ?? 0) !== (int) $effectiveDepartment) {
                throw new ValidationException(['position_id' => 'The position must belong to the selected department.']);
            }
        }

        // Setting your own status to anything but ACTIVE would deactivate your
        // own account mid-session (same lockout as self-archiving).
        $resultStatus = $validated['status'] ?? $existing['status'] ?? 'ACTIVE';
        if ($resultStatus !== 'ACTIVE') {
            self::assertNotSelf($id, 'deactivate');
        }

        // HR/Manager are ordinary paid employees: never hide them through the test-account switch.
        if (!\App\Core\DemoStaffScope::enabled()
            && array_key_exists('payroll_eligible', $data) && (int)$data['payroll_eligible'] === 0) {
            $privileged = Database::scalar(
                "SELECT u.id FROM users u JOIN roles r ON r.id=u.role_id"
                ." WHERE u.employee_id=:eid AND u.deleted_at IS NULL"
                ." AND r.code IN ('HR_PAYROLL','MANAGER') LIMIT 1",
                ['eid'=>$id]
            );
            if ($privileged !== null) {
                throw new ValidationException(['payroll_eligible'=>'HR and Manager employees must remain payroll eligible.']);
            }
        }
        $this->assertReferencesExist($validated);
        if ((int)($validated['assigned_supervisor_id'] ?? 0) === $id && !empty($validated['assigned_supervisor_id'])) {
            throw new ValidationException(['assigned_supervisor_id'=>'An employee cannot supervise themselves.']);
        }
        $this->assertEmailAvailable($validated['email'] ?? null, $id);
        if (!empty($validated['email']) && Database::scalar(
            'SELECT id FROM users WHERE email = :email AND (employee_id IS NULL OR employee_id <> :employee)',
            ['email' => $validated['email'], 'employee' => $id]
        ) !== null) {
            throw new ValidationException(['email' => 'This email already belongs to another system account.']);
        }

        $userId = $userId ?? Auth::id();

        return Database::transaction(function () use ($id, $validated, $existing, $userId, $data): array {
            // Partial update: the Validator fills EVERY rule field with null when
            // it is absent, so presence must be judged against the REQUEST, not
            // $validated. Otherwise omitting a NOT NULL column (e.g. gender)
            // writes null and fails with "Column 'gender' cannot be null" — the
            // "unexpected error" seen when saving an edit. Only fields the caller
            // actually sent are written; everything else keeps its current value.
            $updatable = [];
            foreach (['first_name', 'middle_name', 'last_name', 'gender', 'birth_date', 'address',
                      'contact_number', 'email', 'department_id', 'assigned_supervisor_id', 'position_id', 'employment_type',
                      'sss_number', 'philhealth_number', 'pagibig_number', 'tin',
                      'date_hired', 'salary_type', 'basic_salary', 'work_schedule_id', 'status', 'payroll_eligible', 'notes'] as $field) {
                // position_id is derived from position_role (the Staff/Manager
                // dropdown), so treat either key as the caller having supplied it.
                // Presence is judged against the REQUEST only: the Validator does
                // not add absent/empty fields to $validated, so keying off it would
                // both skip fields the caller sent AND let an empty "" through as
                // null into NOT NULL columns (e.g. gender). Write what the caller
                // sent; treat "" as null only for genuinely nullable columns.
                $provided = array_key_exists($field, $data)
                    || ($field === 'position_id' && array_key_exists('position_role', $data));
                if ($provided) {
                    // Value source is the VALIDATED data, not the raw request.
                    // resolvePosition() maps the Staff/Manager role string
                    // (position_role) to a numeric positions.id — the only form
                    // position_id may take in the BIGINT FK column. The raw
                    // request never carries a numeric position_id for this form
                    // (it is deleted client-side), so reading it here put
                    // "STAFF"/"MANAGER" straight into the integer column and
                    // MySQL strict mode raised SQLSTATE 1366. An earlier
                    // `?? ($data['position_role'] ?? null)` fallback did the
                    // same to every other explicitly-null column (department_id,
                    // work_schedule_id, ...). $validated always holds the
                    // resolved value for every field in this list, so never fall
                    // back to the raw role string: valid NULLs keep writing NULL.
                    $value = $validated[$field] ?? $data[$field];
                    $notNull = in_array($field, ['first_name', 'gender', 'employment_type', 'date_hired', 'salary_type', 'basic_salary'], true);
                    if ($value === '' || $value === null) {
                        if (!$notNull) {
                            $updatable[$field] = null;
                        }
                        // Never write null/"" into a NOT NULL column on update.
                    } else {
                        $updatable[$field] = $value;
                    }
                }
            }
            // Company-wide uniform work schedule; ignore a forged POST value.
            $updatable['work_schedule_id'] = $this->monSatScheduleId() ?? $this->defaultScheduleId();
            // Suffix was removed from the product: never write it.
            $updatable['suffix'] = null;

            if ($updatable !== []) {
                Database::update('employees', $updatable, ['id' => $id]);
            }

            $current  = array_merge($existing, $updatable);
            $isActive = ($current['status'] ?? 'ACTIVE') === 'ACTIVE';

            if ($isActive) {
                  // An active employee must always be able to sign in, so make
                  // sure the linked account exists and is live.
                  $account = $this->ensureAccount($current);
                  $accountUpdate = [
                      'full_name' => trim(($current['first_name'] ?? '') . ' ' . ($current['last_name'] ?? '')),
                      'email'     => $current['email'] ?? null,
                      'status'    => 'ACTIVE',
                  ];
                  // Employee's job position does not change system privileges.
                  // Only an explicit Admin edit can grant a different user role.
                  if (isset($data['account_role']) && $data['account_role'] !== '') {
                      $role = $this->accountRoleByCode((string) $data['account_role']);
                      $accountUpdate['role_id'] = $role['id'];
                  }
                  Database::update('users', $accountUpdate, ['id' => (int) $account['id']]);
              } else {
                  $account = Database::selectOne(
                      'SELECT id FROM users WHERE employee_id = :employee AND deleted_at IS NULL LIMIT 1',
                      ['employee' => $id]
                  );

                  if ($account !== null) {
                      Database::update('users', ['status' => 'INACTIVE'], ['id' => (int) $account['id']]);
                  }
              }

            // A salary change closes the previous history row and opens a new one.
            $oldSalary = (float) $existing['basic_salary'];
            $newSalary = (float) ($validated['basic_salary'] ?? $oldSalary);

            if (abs($newSalary - $oldSalary) > 0.0001) {
                $effectiveFrom = $validated['date_hired'] ?? date('Y-m-d');

                Database::execute(
                    'UPDATE salary_history
                        SET effective_to = :to
                      WHERE employee_id = :emp AND effective_to IS NULL',
                    [
                        'to'  => date('Y-m-d', strtotime('-1 day', strtotime($effectiveFrom))),
                        'emp' => $id,
                    ]
                );

                Database::insert('salary_history', [
                    'employee_id'    => $id,
                    'salary_type'    => $validated['salary_type'] ?? $existing['salary_type'],
                    'basic_salary'   => $newSalary,
                    'effective_from' => $effectiveFrom,
                    'reason'         => $validated['notes'] ?? 'Salary updated',
                    'changed_by'     => $userId,
                ]);

                AuditLogger::recordSalaryChange(
                    $id,
                    $this->fullName($existing),
                    $oldSalary,
                    $newSalary,
                    $userId
                );
            }

            $employee = $this->find($id);

            AuditLogger::recordChanges(
                AuditLogger::EMPLOYEE_UPDATED,
                'employee',
                $id,
                $existing,
                $employee
            );

            return ['employee' => $employee];
        });
    }

    /**
     * Full employee record with department, position, schedule and QR code.
     *
     * @return array<string, mixed>|null
     */
    public function find(int $id): ?array
    {
        $employee = Database::selectOne(
            'SELECT e.*, d.name AS department_name, p.name AS position_name,
                    ws.name AS work_schedule_name, ws.schedule_type AS work_schedule_type,
                    u.id AS account_id, u.username AS account_username,
                    u.status AS account_status, r.code AS account_role
               FROM employees e
               LEFT JOIN departments d ON d.id = e.department_id
               LEFT JOIN positions p   ON p.id = e.position_id
               LEFT JOIN work_schedules ws ON ws.id = e.work_schedule_id
               LEFT JOIN users u ON u.id = (
                    SELECT MIN(u2.id) FROM users u2
                     WHERE u2.employee_id = e.id AND u2.deleted_at IS NULL
               )
               LEFT JOIN roles r ON r.id = u.role_id
              WHERE e.id = :id AND e.deleted_at IS NULL',
            ['id' => $id]
        );

        if ($employee === null) {
            return null;
        }

        $employee['qr_code'] = $this->qrService->activeCode($id);
        $employee['full_name'] = $this->fullName($employee);

        return $employee;
    }
/**
     * Search and filter employees (Phase 4) with pagination.
     *
     * Supported filters: q (free text), department_id, position_id, status,
     * employment_type, salary_type, archived (false, true, or only),
     * attendance_date, attendance_status, sort.
     *
     * @param array<string, mixed> $filters
     * @return array{items: list<array<string, mixed>>, total: int}
     */
    public function search(array $filters, int $page = 1, int $perPage = 25): array
    {
        $where  = ['1 = 1', 'e.deleted_at IS NULL'];
        $params = [];
        if (!empty($filters['demo_staff_only'])) {
            $where[] = '1=1' . \App\Core\DemoStaffScope::excludingRoles('e.id')
                . \App\Core\DemoStaffScope::excludingDemoUsernames('e.id');
        }

        // Soft-deleted records are never returned. "only" powers the dedicated
        // archive storage page; true remains available for combined exports.
        $archiveMode = strtolower(trim((string) ($filters['archived'] ?? 'false')));
        if ($archiveMode === 'only') {
            $where[] = 'e.archived_at IS NOT NULL';
        } elseif (!filter_var($archiveMode, FILTER_VALIDATE_BOOLEAN)) {
            $where[] = 'e.archived_at IS NULL';
        }

        $query = trim((string) ($filters['q'] ?? ''));
        if ($query !== '') {
            // Each placeholder is bound separately because PDO cannot reuse a
            // named parameter when emulated prepares are disabled.
            // The final clause matches a typed full name such as "Juan Dela Cruz".
            $where[] = "(e.employee_number LIKE :q1 OR e.first_name LIKE :q2 OR e.middle_name LIKE :q3
                         OR e.last_name LIKE :q4 OR e.email LIKE :q5 OR e.contact_number LIKE :q6
                         OR CONCAT_WS(' ', e.first_name, e.last_name) LIKE :q7
                         OR CONCAT_WS(' ', e.last_name, e.first_name) LIKE :q8)";

            $like = '%' . $query . '%';
            $params['q1'] = $like;
            $params['q2'] = $like;
            $params['q3'] = $like;
            $params['q4'] = $like;
            $params['q5'] = $like;
            $params['q6'] = $like;
            $params['q7'] = $like;
            $params['q8'] = $like;
        }

        if (!empty($filters['manager_employee_id'])) {
            $where[] = '(e.assigned_supervisor_id = :team_manager_id OR (e.assigned_supervisor_id IS NULL AND e.department_id = :team_department_id))';
            $params['team_manager_id'] = (int)$filters['manager_employee_id'];
            $params['team_department_id'] = (int)$filters['manager_department_id'];
        }
        foreach (['department_id', 'position_id', 'status', 'employment_type', 'salary_type', 'payroll_eligible'] as $field) {
            $value = $filters[$field] ?? null;
            if ($value !== null && $value !== '') {
                $where[]  = sprintf('e.%s = :%s', $field, $field);
                $params[$field] = $value;
            }
        }

        // Attendance filter (employee list "Attendance" button): only staff
        // with an attendance record on the given date (and optional status).
        $attendanceJoin = '';
        $attendanceDate = trim((string) ($filters['attendance_date'] ?? ''));
        if ($attendanceDate !== '') {
            $attendanceJoin = 'JOIN attendance att ON att.employee_id = e.id'
                . ' AND att.attendance_date = :att_date AND att.deleted_at IS NULL';
            $params['att_date'] = $attendanceDate;

            $attendanceStatus = trim((string) ($filters['attendance_status'] ?? ''));
            if ($attendanceStatus !== '') {
                $where[] = 'att.status = :att_status';
                $params['att_status'] = $attendanceStatus;
            }
        }

        $whereSql = implode(' AND ', $where);

        $total = (int) (Database::scalar(
            "SELECT COUNT(*) FROM employees e {$attendanceJoin} WHERE {$whereSql}",
            $params
        ) ?? 0);

        $perPage = max(1, $perPage);
        $offset  = max(0, ($page - 1) * $perPage);

        $orderBy = match (strtolower((string) ($filters['sort'] ?? 'name'))) {
            'hired'  => 'e.date_hired DESC, e.employee_number DESC',
            'number' => 'e.employee_number ASC',
            default  => 'e.last_name ASC, e.first_name ASC, e.employee_number ASC',
        };

        $items = Database::select("SELECT e.id, e.employee_number, e.first_name, e.middle_name, e.last_name, e.suffix,
                      e.gender, e.employment_type, e.date_hired, e.salary_type, e.basic_salary, e.assigned_supervisor_id,
                      e.status, e.payroll_eligible, e.archived_at, e.email, e.contact_number,
                      d.name AS department_name, p.name AS position_name,
                      ws.name AS work_schedule_name,
                      u.username AS account_username, u.status AS account_status,
                      r.code AS account_role,
                      qr.status AS qr_status, qr.token_hint AS qr_token_hint
                 FROM employees e
                 {$attendanceJoin}
                 LEFT JOIN departments d ON d.id = e.department_id
                 LEFT JOIN positions p   ON p.id = e.position_id
                 LEFT JOIN work_schedules ws ON ws.id = e.work_schedule_id
                 LEFT JOIN users u ON u.id = (
                      SELECT MIN(u2.id) FROM users u2
                       WHERE u2.employee_id = e.id AND u2.deleted_at IS NULL
                 )
                 LEFT JOIN roles r ON r.id = u.role_id
                 LEFT JOIN employee_qr_codes qr ON qr.employee_id = e.id AND qr.status = 'ACTIVE'
                WHERE {$whereSql}
              ORDER BY {$orderBy}
              LIMIT {$perPage} OFFSET {$offset}",
            $params
        );

        foreach ($items as &$item) {
            $item['full_name'] = $this->fullName($item);
        }
        unset($item);

        return ['items' => $items, 'total' => $total];
    }

    /**
     * Archive an employee: the record is kept, the QR code is invalidated and
     * the linked user account is deactivated (Phase 4).
     *
     * @return array<string, mixed>
     */
    public function archive(int $id, ?int $userId = null): array
    {
        $employee = Database::selectOne(
            'SELECT * FROM employees WHERE id = :id AND deleted_at IS NULL AND archived_at IS NULL',
            ['id' => $id]
        );

        if ($employee === null) {
            throw new RuntimeException('Employee not found or already archived.');
        }

        // Archiving deactivates the linked account, which would instantly lock
        // out whoever is signed in as this employee.
        self::assertNotSelf($id, 'archive');

        $userId = $userId ?? Auth::id();
        $now    = date('Y-m-d H:i:s');
        $employeeName = $this->fullName($employee);

        return Database::transaction(static function () use ($id, $employee, $employeeName, $userId, $now): array {
            Database::update('employees', [
                'status'      => 'INACTIVE',
                'archived_at' => $now,
                'archived_by' => $userId,
            ], ['id' => $id]);

            // Invalidate the active QR code so an archived badge can never scan.
            Database::execute(
                "UPDATE employee_qr_codes
                    SET status = 'DISABLED', disabled_at = NOW(), disabled_reason = :reason
                  WHERE employee_id = :emp AND status = 'ACTIVE'",
                ['reason' => 'Employee archived', 'emp' => $id]
            );

            // Deactivate the linked self-service account.
            Database::execute(
                'UPDATE users SET status = :status WHERE employee_id = :emp',
                ['status' => 'INACTIVE', 'emp' => $id]
            );

            AuditLogger::record(
                AuditLogger::EMPLOYEE_ARCHIVED,
                'employee',
                $id,
                sprintf('Archived employee %s', $employeeName),
                ['status' => $employee['status']],
                ['status' => 'INACTIVE', 'archived_at' => $now]
            );

            return ['id' => $id, 'status' => 'INACTIVE', 'archived_at' => $now];
        });
    }
/** Restore an archived employee (Phase 4). */
    public function restore(int $id, ?int $userId = null): array
    {
        $employee = Database::selectOne(
            'SELECT * FROM employees WHERE id = :id AND deleted_at IS NULL AND archived_at IS NOT NULL',
            ['id' => $id]
        );

        if ($employee === null) {
            throw new RuntimeException('Employee not found or is not archived.');
        }

        $userId = $userId ?? Auth::id();
        $employeeName = $this->fullName($employee);
        $qrService = $this->qrService;

        return Database::transaction(function () use ($id, $employee, $employeeName, $userId, $qrService): array {
            Database::update('employees', [
                'status'      => 'ACTIVE',
                'archived_at' => null,
                'archived_by' => null,
            ], ['id' => $id]);

            // The employee is the user: make sure the login is usable again,
            // recreating it if the account went missing while archived.
            $account = $this->ensureAccount($employee);
            $role    = $account['role_code'] ?? null;
            if ($role === null) {
                $roleRow = Database::selectOne('SELECT code FROM roles WHERE id = :id', ['id' => (int) ($account['role_id'] ?? 0)]);
                $role = $roleRow['code'] ?? null;
            }

            // archive() disabled the badge, so undo that here: without a fresh
            // ACTIVE code a restored employee could never clock in again.
            if (\App\Core\DemoStaffScope::participates($id) && $qrService->activeCode($id) === null) {
                $qrService->issue($id, $userId, true);
            }

            AuditLogger::record(
                AuditLogger::EMPLOYEE_RESTORED,
                'employee',
                $id,
                sprintf('Restored employee %s', $employeeName),
                ['status' => $employee['status']],
                ['status' => 'ACTIVE']
            );

            return [
                'id'      => $id,
                'status'  => 'ACTIVE',
                'account' => [
                    'username' => $account['username'],
                    'role'     => $role,
                    'created'  => (bool) ($account['is_new'] ?? false),
                ],
            ];
        });
    }
/** Soft delete: the record is hidden, not destroyed (Phase 4). */
    public function delete(int $id, ?int $userId = null): array
    {
        $employee = Database::selectOne(
            'SELECT * FROM employees WHERE id = :id AND deleted_at IS NULL',
            ['id' => $id]
        );

        if ($employee === null) {
            throw new RuntimeException('Employee not found.');
        }

        // Deleting also kills the linked account and its sessions.
        self::assertNotSelf($id, 'delete');

        $userId = $userId ?? Auth::id();
        $now    = date('Y-m-d H:i:s');

        Database::transaction(static function () use ($id, $userId, $now): void {
            Database::update('employees', ['deleted_at' => $now], ['id' => $id]);

            // Hide the linked self-service account and kill its sessions.
            Database::execute(
                'UPDATE users SET status = :status, deleted_at = :deleted WHERE employee_id = :emp',
                ['status' => 'INACTIVE', 'deleted' => $now, 'emp' => $id]
            );
            Database::execute(
                'UPDATE api_tokens t
                    JOIN users u ON u.id = t.user_id
                    SET t.is_revoked = 1
                  WHERE u.employee_id = :emp',
                ['emp' => $id]
            );
        });

        AuditLogger::record(
            AuditLogger::EMPLOYEE_DELETED,
            'employee',
            $id,
            sprintf('Deleted employee %s', $this->fullName($employee)),
            $employee,
            null
        );

        return ['id' => $id, 'deleted_at' => $now];
    }

    /**
     * Salary history for an employee (Phase 4).
     *
     * @return list<array<string, mixed>>
     */
    public function salaryHistory(int $employeeId): array
    {
        return Database::select(
            'SELECT sh.*, u.username AS changed_by_username
               FROM salary_history sh
               LEFT JOIN users u ON u.id = sh.changed_by
              WHERE sh.employee_id = :id
              ORDER BY sh.effective_from DESC, sh.id DESC',
            ['id' => $employeeId]
        );
    }
/**
     * Leave balances for an employee (Phase 10), creating the year's rows on demand.
     *
     * @return list<array<string, mixed>>
     */
    public function leaveBalances(int $employeeId, ?int $year = null): array
    {
        $year = $year ?? (int) date('Y');

        $this->initialiseLeaveBalances($employeeId, $year);

        return Database::select(
            'SELECT lb.leave_type_id, lb.year, lb.entitled_days, lb.used_days, lb.pending_days,
                    (lb.entitled_days - lb.used_days - lb.pending_days) AS remaining_days,
                    lt.code, lt.name, lt.is_paid, lt.description
               FROM leave_balances lb
               JOIN leave_types lt ON lt.id = lb.leave_type_id
              WHERE lb.employee_id = :emp AND lb.year = :year
              ORDER BY lt.name',
            ['emp' => $employeeId, 'year' => $year]
        );
    }

    /** Seed one balance row per active leave type for the year. */
    public function initialiseLeaveBalances(int $employeeId, int $year): void
    {
        $types = Database::select(
            'SELECT id, default_days FROM leave_types WHERE is_active = 1 AND deleted_at IS NULL'
        );

        foreach ($types as $type) {
            $existing = Database::scalar(
                'SELECT id FROM leave_balances
                  WHERE employee_id = :emp AND leave_type_id = :type AND year = :year',
                ['emp' => $employeeId, 'type' => (int) $type['id'], 'year' => $year]
            );

            if ($existing === null) {
                Database::insert('leave_balances', [
                    'employee_id'   => $employeeId,
                    'leave_type_id' => (int) $type['id'],
                    'year'          => $year,
                    'entitled_days' => (float) $type['default_days'],
                    'used_days'     => 0.00,
                    'pending_days'  => 0.00,
                ]);
            }
        }
    }

    /**
     * Employee profile summary: personal details plus attendance and
     * request statistics (Phase 4 / Phase 16).
     *
     * @return array<string, mixed>
     */
    public function profile(int $employeeId, ?int $year = null): array
    {
        $employee = $this->find($employeeId);
        if ($employee === null) {
            throw new RuntimeException('Employee not found.');
        }

        $year = $year ?? (int) date('Y');

        $attendanceStats = Database::selectOne(
            'SELECT COUNT(*) AS total_days,
                    COALESCE(SUM(CASE WHEN status IN (:present, :late) THEN 1 ELSE 0 END), 0) AS present_count,
                    COALESCE(SUM(CASE WHEN status = :late_only THEN 1 ELSE 0 END), 0) AS late_count,
                    COALESCE(SUM(CASE WHEN status = :absent THEN 1 ELSE 0 END), 0) AS absent_count,
                    COALESCE(SUM(CASE WHEN status IN (:leave, :holiday) THEN 1 ELSE 0 END), 0) AS on_leave_count,
                    COALESCE(SUM(late_minutes), 0) AS late_minutes,
                    COALESCE(SUM(undertime_minutes), 0) AS undertime_minutes,
                    COALESCE(SUM(overtime_hours), 0) AS overtime_hours,
                    COALESCE(SUM(worked_hours), 0) AS worked_hours
                FROM attendance
               WHERE employee_id = :emp AND deleted_at IS NULL AND YEAR(attendance_date) = :year',
            [
                'emp'     => $employeeId,
                'year'    => $year,
                'present' => 'PRESENT',
                'late'    => 'LATE',
                'late_only' => 'LATE',
                'absent'  => 'ABSENT',
                'leave'   => 'LEAVE',
                'holiday' => 'HOLIDAY',
            ]
        ) ?? [];

        $attendanceStats['overtime_hours'] = (float) (Database::scalar(
            "SELECT COALESCE(SUM(applied_hours), 0) FROM overtime_requests
               WHERE employee_id = :emp AND status = 'APPROVED' AND YEAR(overtime_date) = :year",
            ['emp' => $employeeId, 'year' => $year]
        ) ?? 0);

        $pendingRequests = Database::selectOne(
            'SELECT
                (SELECT COUNT(*) FROM leave_requests
                  WHERE employee_id = :leave_emp AND status = :leave_status AND deleted_at IS NULL) AS pending_leave,
                (SELECT COUNT(*) FROM overtime_requests
                  WHERE employee_id = :ot_emp AND status = :ot_status AND deleted_at IS NULL) AS pending_overtime',
            [
                'leave_emp'    => $employeeId,
                'leave_status' => 'PENDING',
                'ot_emp'       => $employeeId,
                'ot_status'    => 'PENDING',
            ]
        ) ?? [];

        return [
            'employee'         => $employee,
            'salary_history'   => $this->salaryHistory($employeeId),
            'leave_balances'   => $this->leaveBalances($employeeId, $year),
            'attendance_stats' => $attendanceStats,
            'pending_requests' => $pendingRequests,
            'year'             => $year,
        ];
    }

    /** @return list<array<string, mixed>> */
    public function departments(bool $archivedOnly = false): array
    {
        return Database::select(
            $archivedOnly
                ? 'SELECT d.*,
                    (SELECT COUNT(*) FROM employees e
                      WHERE e.department_id = d.id AND e.deleted_at IS NULL
                        AND e.archived_at IS NULL) AS employee_count
                FROM departments d
               WHERE d.deleted_at IS NOT NULL
               ORDER BY d.name'
                : 'SELECT d.*,
                    (SELECT COUNT(*) FROM employees e
                      WHERE e.department_id = d.id AND e.deleted_at IS NULL
                        AND e.archived_at IS NULL) AS employee_count
                FROM departments d
               WHERE d.deleted_at IS NULL AND d.is_active = 1
               ORDER BY d.name'
        );
    }

    /** @return list<array<string, mixed>> */
    public function positions(?int $departmentId = null, bool $archivedOnly = false): array
    {
        $params = [];
        $where  = $archivedOnly ? 'p.deleted_at IS NOT NULL' : 'p.deleted_at IS NULL AND p.is_active = 1';

        if ($departmentId !== null) {
            $where .= ' AND p.department_id = :dept';
            $params['dept'] = $departmentId;
        }

        return Database::select(
            "SELECT p.*, d.name AS department_name
               FROM positions p
               LEFT JOIN departments d ON d.id = p.department_id
              WHERE {$where}
              ORDER BY d.name, p.name",
            $params
        );
    }

    /** First active schedule, used when an employee has none assigned. */
    public function defaultScheduleId(): ?int
    {
        // Business rule: ALL employees work Monday–Saturday. New hires must
        // always receive the existing Standard Mon-Sat schedule (STD-MFS).
        $monSat = $this->monSatScheduleId();
        if ($monSat !== null) {
            return $monSat;
        }

        $id = Database::scalar(
            'SELECT id FROM work_schedules
              WHERE is_default = 1 AND is_active = 1 AND deleted_at IS NULL
              ORDER BY id LIMIT 1'
        );

        if ($id !== null) {
            return (int) $id;
        }

        $id = Database::scalar(
            'SELECT id FROM work_schedules WHERE is_active = 1 AND deleted_at IS NULL ORDER BY id LIMIT 1'
        );

        return $id === null ? null : (int) $id;
    }

    /**
     * Existing Standard Mon-Sat schedule (code STD-MFS, Monday–Saturday).
     * Reuses the seeded row — never creates a new schedule.
     */
    public function monSatScheduleId(): ?int
    {
        $id = Database::scalar(
            "SELECT id FROM work_schedules
              WHERE code = 'STD-MFS' AND is_active = 1 AND deleted_at IS NULL
              ORDER BY id LIMIT 1"
        );

        if ($id !== null) {
            return (int) $id;
        }

        $id = Database::scalar(
            "SELECT id FROM work_schedules
              WHERE name = 'Standard Mon-Sat' AND is_active = 1 AND deleted_at IS NULL
              ORDER BY id LIMIT 1"
        );

        return $id === null ? null : (int) $id;
    }

    /** Human-readable "First [Middle] Last" (suffix removed). */
    public function fullName(array $employee): string
    {
        $parts = array_filter([
            $employee['first_name'] ?? '',
            $employee['middle_name'] ?? '',
            $employee['last_name'] ?? '',
        ], static fn (mixed $v): bool => trim((string) $v) !== '');

        return trim(implode(' ', array_map(static fn ($v): string => trim((string) $v), $parts)));
    }

    /**
     * Guard: department, position and schedule must exist when supplied.
     * Empty strings are treated as "not supplied".
     *
     * @param array<string, mixed> $data
     */
    private function assertReferencesExist(array $data): void
    {
        if (!empty($data['assigned_supervisor_id'])) {
            $supervisor = Database::selectOne("SELECT e.id FROM employees e JOIN users u ON u.employee_id=e.id JOIN roles r ON r.id=u.role_id WHERE e.id=:id AND e.status='ACTIVE' AND e.deleted_at IS NULL AND u.status='ACTIVE' AND u.deleted_at IS NULL AND r.code='MANAGER' LIMIT 1",
                ['id'=>(int)$data['assigned_supervisor_id']]);
            if (!$supervisor) { throw new ValidationException(['assigned_supervisor_id'=>'Select an active Manager employee as supervisor.']); }
        }
        if (!empty($data['position_id']) && !empty($data['department_id'])) {
            $row = Database::selectOne(
                'SELECT department_id FROM positions WHERE id = :id AND deleted_at IS NULL',
                ['id' => (int) $data['position_id']]
            );
            if ($row !== null && (int) ($row['department_id'] ?? 0) !== (int) $data['department_id']) {
                throw new ValidationException(['position_id' => 'The selected position does not belong to the selected department.']);
            }
        }
        foreach (['department_id', 'position_id', 'work_schedule_id'] as $field) {
            $id = $data[$field] ?? null;
            if ($id === null || $id === '') {
                continue;
            }

            $table = $field === 'department_id' ? 'departments' : ($field === 'position_id' ? 'positions' : 'work_schedules');
            $label = $field === 'department_id' ? 'Department' : ($field === 'position_id' ? 'Position' : 'Work schedule');

            $exists = Database::scalar(
                "SELECT id FROM {$table} WHERE id = :id AND deleted_at IS NULL",
                ['id' => (int) $id]
            );

            if ($exists === null) {
                throw new ValidationException([$field => "The selected {$label} does not exist."]);
            }
        }
    }

    /**
     * Block acting on your own employee record when the action would lock you
     * out (archive / deactivate / delete all disable the linked account).
     */
    private static function assertNotSelf(int $employeeId, string $action): void
    {
        $ownId = Auth::employeeId();

        if ($ownId !== null && $ownId === $employeeId) {
            throw new ValidationException(['employee' => sprintf(
                'You cannot %s your own employee record while signed in as them. Ask another administrator to do it.',
                $action
            )]);
        }
    }

    private function assertEmailAvailable(?string $email, ?int $ignoreId = null): void
    {
        if ($email === null || $email === '') {
            return;
        }

        $params = ['email' => $email];
        $sql    = 'SELECT id FROM employees WHERE email = :email AND deleted_at IS NULL';

        if ($ignoreId !== null) {
            $sql .= ' AND id != :ignore';
            $params['ignore'] = $ignoreId;
        }

        if (Database::scalar($sql, $params) !== null) {
            throw new ValidationException(['email' => 'That email address is already in use.']);
        }
    }
}
