<?php
declare(strict_types=1);

namespace App\Services;

use App\Core\AuditLogger;
use App\Core\Auth;
use App\Core\Database;
use App\Core\DemoStaffScope;
use App\Core\ValidationException;
use RuntimeException;

/**
 * 13th-Month Pay service.
 *
 * Formula (computed server-side only):
 *   13th-month pay = total BASIC SALARY earned in the calendar year / 12.
 *
 * Earnings source: the per-period basic_pay rows of FINALIZED and PAID payroll
 * runs that fall wholly inside the calendar year. Never the current
 * employees.basic_salary (that would ignore mid-year salary changes), and never
 * gross/net, overtime, night differential, premium or holiday pay.
 *
 * Two corrections are applied while reading history:
 *   1. Legacy rows written before the payroll engine separated holiday pay
 *      stored holiday amounts inside basic_pay; the matching payroll_items
 *      'HOLIDAY' earning is subtracted (clamped at zero). History itself is
 *      never rewritten.
 *   2. A period that crosses 31 Dec / 1 Jan cannot be allocated reliably, so
 *      generation is refused rather than guessed.
 */
final class ThirteenthPayService
{
    public const STATUSES = ['DRAFT', 'FOR_APPROVAL', 'APPROVED', 'PAID'];

    // This is the COMBINED annual exemption for 13th month and other benefits,
    // not a guaranteed 90k tax-free allowance for each benefit separately.
    public const BIR_BENEFITS_EXEMPTION = 90000.00;

    /**
     * Payroll-period statuses whose per-period figures are stable and final.
     *
     * FINALIZED locks every payroll row (is_locked = 1) and the workflow has no
     * transition back to CALCULATING; PAID is terminal. APPROVED is excluded on
     * purpose: APPROVED -> CALCULATING is a legal transition and recalculation
     * replaces the unlocked rows, so reading APPROVED could let a final annual
     * figure change after it was generated.
     */
    public const ELIGIBLE_PAYROLL_STATUSES = ['FINALIZED', 'PAID'];

    public const TRANSITIONS = [
        'DRAFT'        => ['FOR_APPROVAL'],
        'FOR_APPROVAL' => ['APPROVED'],
        'APPROVED'     => ['PAID'],
        'PAID'         => [],
    ];

    /**
     * Generate (or safely refresh DRAFT) records for one calendar year.
     *
     * Only FINALIZED and PAID payroll periods contribute (see
     * ELIGIBLE_PAYROLL_STATUSES). Re-running Generate refreshes DRAFT rows in
     * place; submitted, approved, released and paid rows are never overwritten.
     */
    public function generate(int $year, ?int $userId = null): array
    {
        $userId = $userId ?? Auth::id();
        $this->assertYear($year);

        $audit = $this->collectYearEarnings($year);

        // A period that straddles 31 Dec / 1 Jan cannot be split by period and
        // no per-day earning breakdown is stored, so allocating its amount
        // would be a guess. Refuse rather than produce a misleading figure.
        if ($audit['crossing_periods'] !== []) {
            $codes = implode(', ', array_map(
                static fn (array $period): string => (string) $period['code'],
                $audit['crossing_periods']
            ));
            throw new ValidationException([
                'calendar_year' => sprintf(
                    'Payroll period(s) %s cross the calendar-year boundary, so their basic-salary earnings cannot be allocated to %d without guessing. Split the affected period into year-contained periods and finalize them before generating 13th-month pay.',
                    $codes,
                    $year
                ),
            ]);
        }

        $totals = $audit['totals'];
        if ($totals === []) {
            throw new ValidationException(['calendar_year' => 'No finalized payroll earnings found for that year, so nothing can be generated.']);
        }
        return Database::transaction(function () use ($year, $userId, $totals, $audit): array {
            foreach ($totals as $empId => $gross) {
                $amount = round(max(0.0, (float) $gross) / 12.0, 2);
                // Repeated Generate refreshes DRAFT rows in place (unique key
                // employee_id + calendar_year); any later status is preserved.
                Database::execute(
                    'INSERT INTO thirteenth_pays (employee_id, calendar_year, gross_total, thirteenth_pay, status, generated_by, generated_at)
                     VALUES (:emp, :yr, :gross, :amt, \'DRAFT\', :uid, NOW())
                     ON DUPLICATE KEY UPDATE
                       gross_total = IF(status = \'DRAFT\', VALUES(gross_total), gross_total),
                       thirteenth_pay = IF(status = \'DRAFT\', VALUES(thirteenth_pay), thirteenth_pay),
                       generated_by = IF(status = \'DRAFT\', VALUES(generated_by), generated_by)',
                    ['emp' => $empId, 'yr' => $year, 'gross' => round((float) $gross, 2), 'amt' => $amount, 'uid' => $userId]
                );
            }
            AuditLogger::record(
                AuditLogger::PAYROLL_CALCULATED, 'thirteenth_pay', $year,
                sprintf('Generated 13th-month pay for %d employee(s), year %d', count($totals), $year),
                null, [
                    'calendar_year'                 => $year,
                    'employees'                     => count($totals),
                    'eligible_payroll_statuses'     => self::ELIGIBLE_PAYROLL_STATUSES,
                    'payroll_rows_included'         => $audit['records_included'],
                    'legacy_holiday_rows_corrected' => $audit['legacy_rows'],
                    'legacy_holiday_adjustment'     => round($audit['legacy_holiday_adjustment'], 2),
                    'crossing_periods_flagged'      => count($audit['crossing_periods']),
                ]
            );

            $result = $this->listByYear($year);
            // Machine-readable provenance for anyone auditing the generated
            // figures against the source payroll rows.
            $result['reconciliation'] = [
                'eligible_payroll_statuses'     => self::ELIGIBLE_PAYROLL_STATUSES,
                'payroll_rows_included'         => $audit['records_included'],
                'employees_with_earnings'       => count($totals),
                'legacy_holiday_rows_corrected' => $audit['legacy_rows'],
                'legacy_holiday_adjustment'     => round($audit['legacy_holiday_adjustment'], 2),
                'crossing_periods_flagged'      => count($audit['crossing_periods']),
            ];

            return $result;
        });
    }

    /** Saved records for one year (main table). */
    public function listByYear(int $year): array
    {
        // Same 1900..2100 contract as every other entry point, so a missing or
        // nonsensical calendar_year answers with a validation error instead of
        // an empty list labelled with that year. Internal callers have already
        // validated the year, so this is a no-op for them.
        $this->assertYear($year);
        $rows = Database::select(
            'SELECT tp.id, tp.employee_id, e.employee_number, e.first_name, e.last_name,
                    tp.gross_total, tp.thirteenth_pay, tp.status,
                    tp.submitted_at, tp.approved_at, tp.released_at, tp.paid_at
               FROM thirteenth_pays tp
               JOIN employees e ON e.id = tp.employee_id
              WHERE tp.calendar_year = :yr
              ORDER BY e.last_name, e.first_name, e.employee_number',
            ['yr' => $year]
        );
        $out = [];
        foreach ($rows as $r) {
            $out[] = [
                'id' => (int) $r['id'],
                'employee_id' => (int) $r['employee_id'],
                'employee_number' => (string) $r['employee_number'],
                'full_name' => trim((string) $r['first_name'] . ' ' . (string) ($r['last_name'] ?? '')) ?: '(no name)',
                'gross_total' => (float) $r['gross_total'],
                'thirteenth_pay' => (float) $r['thirteenth_pay'],
                'ordinary_deductions' => 0.0,
                'net_thirteenth_pay' => (float) $r['thirteenth_pay'],
                'tax_review_required' => (float) $r['thirteenth_pay'] > self::BIR_BENEFITS_EXEMPTION,
                'status' => (string) $r['status'],
                'submitted_at' => $r['submitted_at'], 'approved_at' => $r['approved_at'],
                'released_at' => $r['released_at'], 'paid_at' => $r['paid_at'],
            ];
        }
        return ['success' => true, 'records' => $out, 'calendar_year' => $year];
    }


    /** DRAFT -> FOR_APPROVAL for every DRAFT record of the year. */
    public function submitForApproval(int $year, ?int $userId = null): array
    {
        if (DemoStaffScope::limitedDemoScope()) {
            throw new RuntimeException('One-staff defense demo is DRAFT-only; 13th-month approval and payment are disabled.');
        }
        $userId = $userId ?? Auth::id();
        $this->assertYear($year);
        return Database::transaction(function () use ($year, $userId): array {
            $moved = Database::execute(
                "UPDATE thirteenth_pays SET status='FOR_APPROVAL', submitted_by=:uid, submitted_at=NOW()
                  WHERE calendar_year=:yr AND status='DRAFT'",
                ['uid' => $userId, 'yr' => $year]
            );
            if ($moved === 0) {
                throw new ValidationException(['calendar_year' => 'There are no DRAFT records to submit for that year.']);
            }
            AuditLogger::record(
                AuditLogger::PAYROLL_APPROVED, 'thirteenth_pay', $year,
                sprintf('Submitted %d 13th-month record(s) for approval, year %d', $moved, $year),
                null, ['calendar_year' => $year, 'moved' => $moved]
            );
            return ['success' => true, 'moved' => $moved] + $this->listByYear($year);
        });
    }

    /** FOR_APPROVAL -> APPROVED for every submitted record of the year. */
    public function approve(int $year, ?int $userId = null): array
    {
        if (DemoStaffScope::limitedDemoScope()) {
            throw new RuntimeException('One-staff defense demo is DRAFT-only; 13th-month approval and payment are disabled.');
        }
        $userId = $userId ?? Auth::id();
        $this->assertYear($year);
        return Database::transaction(function () use ($year, $userId): array {
            $moved = Database::execute(
                "UPDATE thirteenth_pays SET status='APPROVED', approved_by=:uid, approved_at=NOW()
                  WHERE calendar_year=:yr AND status='FOR_APPROVAL'",
                ['uid' => $userId, 'yr' => $year]
            );
            if ($moved === 0) {
                throw new ValidationException(['calendar_year' => 'There are no submitted records waiting for approval.']);
            }
            AuditLogger::record(
                AuditLogger::PAYROLL_APPROVED, 'thirteenth_pay', $year,
                sprintf('Approved %d 13th-month record(s), year %d', $moved, $year),
                null, ['calendar_year' => $year, 'moved' => $moved]
            );
            return ['success' => true, 'moved' => $moved] + $this->listByYear($year);
        });
    }

    /** APPROVED -> PAID for every approved record of the year. */
    public function releaseApproved(int $year, ?int $userId = null): array
    {
        if (DemoStaffScope::limitedDemoScope()) {
            throw new RuntimeException('One-staff defense demo is DRAFT-only; 13th-month approval and payment are disabled.');
        }
        $userId = $userId ?? Auth::id();
        $this->assertYear($year);
        return Database::transaction(function () use ($year, $userId): array {
            $rows = Database::select(
                "SELECT id, thirteenth_pay FROM thirteenth_pays
                  WHERE calendar_year=:yr AND status='APPROVED'",
                ['yr' => $year]
            );
            if ($rows === []) {
                throw new ValidationException(['calendar_year' => 'There are no APPROVED records to release for that year.']);
            }
            // The module does not store annual "other benefits" or any 13th-month
            // withholding ledger. Never release an amount which, by itself,
            // exceeds the statutory combined exemption as automatically tax-free.
            foreach ($rows as $r) {
                if ((float) $r['thirteenth_pay'] > self::BIR_BENEFITS_EXEMPTION) {
                    throw new ValidationException([
                        'calendar_year' => '13th-month amount exceeds the combined PHP 90,000 annual benefits exemption. BIR tax review/withholding must be handled before release; this no-routine-deduction workflow cannot automatically clear that payment.',
                    ]);
                }
            }
            foreach ($rows as $r) {
                Database::update(
                    'thirteenth_pays',
                    ['status' => 'PAID', 'released_at' => date('Y-m-d H:i:s')],
                    ['id' => (int) $r['id']]
                );
                // Exactly one payment ledger row per 13th-month record:
                // uq_ltpay_payment is UNIQUE on thirteenth_pay_id. Release opens
                // it as PENDING with 0.00 disbursed; recordPayment() then
                // completes/accumulates that same row. Release and payment must
                // never each INSERT a row for one record (SQLSTATE 23000).
                Database::insert('thirteenth_payments', [
                    'thirteenth_pay_id' => (int) $r['id'],
                    'amount' => 0.00,
                    'payment_status' => 'PENDING',
                    'paid_by' => $userId,
                ]);
            }
            AuditLogger::record(
                AuditLogger::PAYROLL_PAID, 'thirteenth_pay', $year,
                sprintf('Released %d approved 13th-month record(s), year %d', count($rows), $year),
                null, ['calendar_year' => $year, 'released' => count($rows)]
            );
            return ['success' => true, 'released' => count($rows)] + $this->listByYear($year);
        });
    }


    /**
     * Released-but-unpaid rows: PAID records that still have a balance.
     *
     * A row stays in this list for as long as the disbursed total (every
     * PARTIAL or COMPLETED payment on the ledger) is below the 13th-month
     * amount. payment_status is the ledger state the UI shows:
     *   PENDING   — released, nothing paid yet (0.00 disbursed);
     *   PARTIAL   — an instalment was received but a balance is outstanding;
     *   COMPLETED — fully settled, which also drops the row out of this list
     *               because paid_total then equals thirteenth_pay.
     */
    public function unpaidReleased(int $year): array
    {
        $this->assertYear($year);
        $rows = Database::select(
            "SELECT tp.id, tp.employee_id, e.employee_number, e.first_name, e.last_name,
                    tp.gross_total, tp.thirteenth_pay, tp.status, tp.released_at,
                    COALESCE(MAX(py.payment_status), 'PENDING') AS payment_status,
                    COALESCE(SUM(CASE WHEN py.payment_status IN ('PARTIAL','COMPLETED') THEN py.amount ELSE 0 END), 0) AS paid_total
               FROM thirteenth_pays tp
               JOIN employees e ON e.id = tp.employee_id
          LEFT JOIN thirteenth_payments py ON py.thirteenth_pay_id = tp.id
              WHERE tp.calendar_year = :yr AND tp.status = 'PAID'
              GROUP BY tp.id
             HAVING paid_total < tp.thirteenth_pay
              ORDER BY e.last_name, e.first_name, e.employee_number",
            ['yr' => $year]
        );
        $out = [];
        foreach ($rows as $r) {
            $due = round((float) $r['thirteenth_pay'] - (float) $r['paid_total'], 2);
            $out[] = [
                'id' => (int) $r['id'],
                'employee_id' => (int) $r['employee_id'],
                'employee_number' => (string) $r['employee_number'],
                'full_name' => trim((string) $r['first_name'] . ' ' . (string) ($r['last_name'] ?? '')) ?: '(no name)',
                'gross_total' => (float) $r['gross_total'],
                'thirteenth_pay' => (float) $r['thirteenth_pay'],
                'ordinary_deductions' => 0.0,
                'net_thirteenth_pay' => (float) $r['thirteenth_pay'],
                'paid_total' => (float) $r['paid_total'],
                'balance_due' => $due,
                'payment_status' => (string) $r['payment_status'],
                'status' => (string) $r['status'],
                'released_at' => $r['released_at'],
            ];
        }
        return ['success' => true, 'records' => $out, 'calendar_year' => $year];
    }

    /**
     * Record a payment against a released record.
     *
     * Status transitions on the single UNIQUE ledger row per thirteenth_pay_id:
     *   PENDING -> PARTIAL    a part-payment arrived, a balance is outstanding;
     *   PARTIAL -> PARTIAL    further instalments accumulate;
     *   PARTIAL -> COMPLETED  the cumulative amount settles the record;
     *   PENDING -> COMPLETED  a single payment settles it in one go.
     * COMPLETED is therefore reserved for a payment that actually clears the
     * record: an instalment can never be mislabelled as fully paid. The
     * overpayment guard means the cumulative total can never exceed the amount
     * due, and only a successful save removes the row from unpaidReleased().
     */
    public function recordPayment(int $payId, float $amount, ?int $userId = null): array
    {
        if (DemoStaffScope::limitedDemoScope()) {
            throw new RuntimeException('One-staff defense demo is DRAFT-only; 13th-month approval and payment are disabled.');
        }
        $userId = $userId ?? Auth::id();
        if ($payId <= 0 || $amount <= 0) {
            throw new ValidationException(['amount' => 'Enter a valid payment amount.']);
        }
        return Database::transaction(function () use ($payId, $amount, $userId): array {
            $pay = Database::selectOne('SELECT * FROM thirteenth_pays WHERE id = :id', ['id' => $payId]);
            if ($pay === null) {
                throw new ValidationException(['pay_id' => 'No such 13th-month pay record.']);
            }
            if ((string) $pay['status'] !== 'PAID') {
                throw new ValidationException(['pay_id' => 'Only released (PAID) records can receive payments.']);
            }
            // The ledger row is UNIQUE per thirteenth_pay_id, so a payment must
            // UPDATE the row opened by release (PENDING, 0.00 paid) instead of
            // INSERT-ing a duplicate — the INSERT here raised SQLSTATE 23000 the
            // moment a released record was paid. Partial payments accumulate into
            // `amount`; the released-but-unpaid list keeps showing the row until
            // the balance reaches zero, and an overpayment is rejected so the
            // same money can never be recorded twice.
            $ledger = Database::selectOne(
                'SELECT id, amount FROM thirteenth_payments WHERE thirteenth_pay_id = :id',
                ['id' => $payId]
            );
            $alreadyPaid = $ledger === null ? 0.0 : round((float) $ledger['amount'], 2);
            $balanceDue  = round((float) $pay['thirteenth_pay'] - $alreadyPaid, 2);
            if ($amount > $balanceDue + 0.005) {
                throw new ValidationException([
                    'amount' => sprintf('Payment exceeds the remaining balance of %.2f.', $balanceDue),
                ]);
            }

            // Cumulative amount and the status it implies. COMPLETED is only
            // reached when the running total covers the 13th-month amount
            // (0.005 tolerance = half a centavo of rounding); anything short of
            // that is PARTIAL, so the record still shows as outstanding.
            $payDue    = round((float) $pay['thirteenth_pay'], 2);
            $newTotal  = round($alreadyPaid + round($amount, 2), 2);
            $newStatus = $newTotal >= $payDue - 0.005 ? 'COMPLETED' : 'PARTIAL';

            if ($ledger === null) {
                $insId = Database::insert('thirteenth_payments', [
                    'thirteenth_pay_id' => $payId,
                    'amount' => $newTotal,
                    'payment_status' => $newStatus,
                    'paid_at' => date('Y-m-d H:i:s'),
                    'paid_by' => $userId,
                ]);
            } else {
                $insId = (int) $ledger['id'];
                Database::update(
                    'thirteenth_payments',
                    [
                        'amount' => $newTotal,
                        'payment_status' => $newStatus,
                        'paid_at' => date('Y-m-d H:i:s'),
                        'paid_by' => $userId,
                    ],
                    ['id' => $insId]
                );
            }
            Database::update(
                'thirteenth_pays',
                ['paid_at' => date('Y-m-d H:i:s')],
                ['id' => $payId]
            );
            AuditLogger::record(
                AuditLogger::PAYROLL_PAID, 'thirteenth_pay', $payId,
                sprintf('Recorded 13th-month payment of %.2f', round($amount, 2)),
                null, ['payment_id' => $insId, 'amount' => round($amount, 2)]
            );
            return ['success' => true, 'payment_id' => $insId] + $this->unpaidReleased((int) $pay['calendar_year']);
        });
    }

    /**
     * Gather eligible basic-salary earnings per employee for one calendar year.
     *
     * Rules applied here (each one deliberate):
     *   - Only FINALIZED / PAID periods are read (see
     *     ELIGIBLE_PAYROLL_STATUSES) so a later recalculation cannot change a
     *     generated figure.
     *   - Only periods wholly inside the year are summed. A period that merely
     *     overlaps the boundary is reported in 'crossing_periods' instead of
     *     having its whole amount guessed into the year.
     *   - basic_pay is used, never gross/net, overtime or night differential.
     *   - Legacy rows (written before the engine separated holiday pay) have
     *     the payroll_items 'HOLIDAY' earning subtracted because that amount
     *     was embedded in basic_pay; the subtraction is clamped at zero so it
     *     can never produce a negative basic amount.
     *
     * @return array{
     *   totals: array<int, float>,
     *   crossing_periods: list<array<string, mixed>>,
     *   records_included: int,
     *   legacy_rows: int,
     *   legacy_holiday_adjustment: float
     * }
     */
    private function collectYearEarnings(int $year): array
    {
        $start = sprintf('%04d-01-01', $year);
        $end   = sprintf('%04d-12-31', $year);

        // Finalized/paid periods that overlap the year but are not wholly
        // contained: these (and only these) cannot be allocated reliably.
        $crossing = Database::select(
            'SELECT pp.id, pp.code, pp.start_date, pp.end_date
               FROM payroll_periods pp
              WHERE pp.deleted_at IS NULL
                AND pp.status IN (\'FINALIZED\', \'PAID\')
                AND pp.start_date <= :yend
                AND pp.end_date >= :ystart
                AND (pp.start_date < :ystart_b OR pp.end_date > :yend_b)
              ORDER BY pp.start_date, pp.id',
            ['ystart' => $start, 'yend' => $end, 'ystart_b' => $start, 'yend_b' => $end]
        );

        if ($crossing !== []) {
            return [
                'totals'                    => [],
                'crossing_periods'          => $crossing,
                'records_included'          => 0,
                'legacy_rows'               => 0,
                'legacy_holiday_adjustment' => 0.0,
            ];
        }

        $rows = Database::select(
            'SELECT p.employee_id, p.basic_pay, p.absence_deduction, p.leave_deduction, p.late_deduction, p.undertime_deduction, p.calculation_snapshot,
                    COALESCE(h.holiday_amount, 0) AS holiday_embedded
               FROM payroll p
               JOIN employees e ON e.id=p.employee_id
               JOIN payroll_periods pp ON pp.id = p.payroll_period_id
               LEFT JOIN (
                    SELECT payroll_id, SUM(amount) AS holiday_amount
                      FROM payroll_items
                     WHERE item_type = \'EARNING\' AND code = \'HOLIDAY\'
                     GROUP BY payroll_id
               ) h ON h.payroll_id = p.id
              WHERE pp.deleted_at IS NULL
                AND pp.status IN (\'FINALIZED\', \'PAID\')
                AND pp.start_date >= :start
                AND pp.end_date <= :end' . (DemoStaffScope::enabled()
                    ? DemoStaffScope::excludingRoles('e.id') . DemoStaffScope::excludingDemoUsernames('e.id')
                    : '') . '
              ORDER BY p.employee_id, pp.start_date, p.id',
            ['start' => $start, 'end' => $end]
        );

        $totals     = [];
        $records    = 0;
        $legacyRows = 0;
        $legacyAdj  = 0.0;

        foreach ($rows as $row) {
            $employeeId = (int) $row['employee_id'];
            $basic      = (float) $row['basic_pay'];

            if (!$this->basicPayExcludesHoliday($row['calculation_snapshot'] ?? null)) {
                // Legacy row: holiday pay was embedded in basic_pay. Remove the
                // separately itemised earning so only basic salary remains.
                // The old engine always added the same amount to both, so the
                // payroll_items figure is authoritative.
                $holiday = (float) $row['holiday_embedded'];
                if ($holiday > 0) {
                    $legacyRows++;
                    $legacyAdj += $holiday;
                }
                $basic = max(0.0, $basic - $holiday);
            }

            // Basic salary actually earned excludes unpaid time. Statutory
            // 13th-month pay must not be based on nominal pre-deduction basic.
            $unearned = (float) ($row['absence_deduction'] ?? 0)
                + (float) ($row['leave_deduction'] ?? 0)
                + (float) ($row['late_deduction'] ?? 0)
                + (float) ($row['undertime_deduction'] ?? 0);
            $basic = FixedMonthlyPolicy::earnedBasic($basic, (float) ($row['absence_deduction'] ?? 0), (float) ($row['leave_deduction'] ?? 0), (float) ($row['late_deduction'] ?? 0), (float) ($row['undertime_deduction'] ?? 0));
            $records++;
            $totals[$employeeId] = ($totals[$employeeId] ?? 0.0) + $basic;
        }

        // No valid earnings => no record at all (never a fabricated zero row).
        $totals = array_filter($totals, static fn (float $amount): bool => $amount > 0.0);

        return [
            'totals'                    => $totals,
            'crossing_periods'          => [],
            'records_included'          => $records,
            'legacy_rows'               => $legacyRows,
            'legacy_holiday_adjustment' => $legacyAdj,
        ];
    }

    /**
     * True when a payroll row was produced by an engine that kept holiday pay
     * out of basic_pay (snapshot accounting marker present and false). Legacy
     * rows return false and are then corrected with their 'HOLIDAY' earning.
     */
    private function basicPayExcludesHoliday(mixed $snapshotJson): bool
    {
        if (!is_string($snapshotJson) || $snapshotJson === '') {
            return false;
        }

        $snapshot = json_decode($snapshotJson, true);
        if (!is_array($snapshot)) {
            return false;
        }

        return ($snapshot['accounting']['holiday_pay_included_in_basic'] ?? null) === false;
    }

    private function assertYear(int $year): void
    {
        if ($year < 1900 || $year > 2100) {
            throw new ValidationException(['calendar_year' => 'Enter a valid calendar year.']);
        }
    }
}
