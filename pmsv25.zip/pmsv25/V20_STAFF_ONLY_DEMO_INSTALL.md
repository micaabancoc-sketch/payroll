# PMS V20 — Staff-only Attendance & Payroll Test Mode

This complete test build is based on V19 and implements the user's temporary request to **leave HR and Manager out of the employee attendance/payroll test, like the non-employee Admin account**. This is a *scoped demo*, **not** a permanent change in their employment status.

## What changes

- **Employees & Salaries** staff roster and employee dropdown: HR/Manager account-linked rows are hidden.
- **HR/Manager shared Attendance view**: HR/Manager rows are hidden, but their personal attendance history is preserved.
- **Payroll → Check Employee, Calculate Employee, Calculate All, View Batch Exceptions**: exclude employees whose linked user role is `HR_PAYROLL`, `MANAGER`, `ADMIN`, or `KIOSK` in staff-only mode. Role is read from `users` and `roles`, not inferred from department or name.
- **Draft payroll**: Calculate All regenerates unlocked DRAFT rows for active Staff only. Staff with unresolved attendance remain provisional/for verification, not auto-ABSENT.
- **Hard safety lock**: attempts to submit for review, approve, finalize, mark paid, or record salary payment are blocked by the backend during staff-only demo mode.
- No records or linked user accounts are deleted, deactivated, unlinked, or archived. HR and Manager can still log in and manage their teams/payroll administration. Their own profile data and historical records remain.

## Installation: do NOT overwrite V19

1. Back up your V19 folder and complete `attendance_payroll_v19_test` database using phpMyAdmin **Export → SQL (structure and data)**.
2. Extract `PMS_V20_STAFF_ONLY_DEMO_TEST_BUILD.zip` to `C:\xampp\htdocs\` so the folder is `C:\xampp\htdocs\pmsv20`.
3. Default DB connection uses **`attendance_payroll_v19_test`**, the same *test database* used for V19, to avoid the missing-database error you previously experienced. If you want isolation, create a clone under another name **and edit `api/config/config.php` or set `DB_NAME`** before testing.
4. Run on XAMPP Apache/MariaDB; open `http://localhost/pmsv20/` and log in as HR.
5. Open **Employees & Salaries**; HR and Operations Manager should be absent from the staff list. They still exist in **Admin → User Accounts**.
6. Open **Payroll Processing**, choose Oct 16–31 2026, and click **Calculate All (Save Draft)** again. Existing unlocked V19 DRAFT rows for the same cutoff (which may include HR/Manager) are recalculated using Staff-only eligibility. *Do not recalculate already finalized or paid periods.*
7. **View Batch Exceptions**: only Staff attendance exceptions should be shown. If `Principal student1` is an active Staff account, that employee will still be included (and may have unresolved attendance).
8. **DRAFT ONLY**: do not perform approval, disbursements, or actual salary payment in this mode.

## Turn the exclusion off later

Set environment variable `DEMO_STAFF_ONLY=false` and restart Apache, or change the default in `api/config/config.php` to false. This test build's hardcoded UI banners may still say staff-only; prepare a production build with normal company-wide payroll for real use. **Recalculate the entire eligible payroll batch before any real approval or salary disbursement.**

## SQL migration

No schema migration is required from the V19 test database. Do not import the old full database dump again: it would overwrite current demo changes. No employee records have been changed in this test build.

## Validation performed

- PHP syntax: 71 PHP files passed `php -l`.
- JavaScript syntax: 8 non-vendor JS files passed `node --check`.
- Static safety checks confirm employee scope applies to staff list, attendance list, single and batch payroll, exception queue and salary payment endpoints.
- A small SQL fixture confirmed Staff remains eligible while HR/Manager are excluded.
- Actual XAMPP/MariaDB end-to-end login, salary calculation, and permissions have **not** been executed in this environment. This is a TEST BUILD, not production certified.
