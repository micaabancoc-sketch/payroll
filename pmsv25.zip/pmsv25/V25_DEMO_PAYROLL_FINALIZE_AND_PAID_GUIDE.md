# PMS V25 — local one-staff payroll demo (Finalize and Paid)

**Test database only.** The project still connects to `attendance_payroll_v25_clean` by default. This update changes the PHP / frontend, not the contents of your database. Keep a backup of your existing project and database. Do not import a fresh SQL dump over a database containing your test work.

## Eligible employee

The `demo.staff_only` flag remains ON. Only employee `EMP-000001` (Demo Staff Member) may participate in new attendance, loans, leave/OT and payroll runs. HR, Manager and Admin keep their login and operational roles; old records are untouched.

## Payroll workflow

1. Log in as **HR Payroll**. Open **Payroll Processing**.
2. Open an existing **DRAFT** period whose cutoff has finished. Click **Calculate All (Check & Calculate)** again. Successful complete batches become **FOR_REVIEW**, not permanently DRAFT. If there are unresolved attendance/financial exceptions, fix them and recalculate; release stays blocked.
3. Click **Approve** (HR only). The period becomes **APPROVED**.
4. Click **Finalize** (HR only). The period becomes **FINALIZED** and rows lock.
5. Click **Salary Payment Records**. On the staff row, click **Record Payment**, enter the amount and choose **Completed**, confirm the **simulated** payment. Record any remainder to reach fully PAID for that staff row. This writes only the test ledger; no bank transfer happens.
6. Return to Payroll Processing. Click **Mark Period Paid** (HR only). This is allowed only after all employee salary rows are fully paid. It also posts the approved payroll loan instalment to the loan payment ledger **once**, inside a DB transaction.
7. Open **Payroll > Payslips** / **Loan Management** to verify the result. Do not manually record the same payroll loan instalment using **Record Repayment**.

**Important:** After FINALIZED, payroll calculations are locked. The specific cutoff must have ended. `APP_ENV=production` disables the simulated demo release path, even when `enable_payroll_workflow` is `true`. The independent 13th-month release restriction is unchanged.

## Installation

- Back up `C:\xampp\htdocs\pmsv25` and export the current `attendance_payroll_v25_clean` database.
- Replace your local project with the contents of this ZIP; keep your local DB credentials if you changed them.
- Do **not** reimport the SQL demo seed. This fix requires no SQL migration.
- Hard-refresh `http://localhost/pmsv25/frontend/payroll/index.html` (Ctrl+F5); sign in to HR Payroll.

## Verification limitations

Offline syntax/static checks can verify PHP/JS code and the roster/payment guards, but the actual database-dependent payroll transitions must still be tested locally in XAMPP/MySQL. Do not use any resulting demo ledger as a real salary receipt.
