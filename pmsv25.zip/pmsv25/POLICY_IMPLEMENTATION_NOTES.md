# Policy integration notes (October 2026)

This is a **partial policy-alignment pass** on the uploaded project, not a fully verified production payroll implementation. **The existing HTML/CSS design is unchanged.**

## Included in this pass
- Role seed updated to limit Manager to review, attendance/leave and OT assignment; Administrator retains system/finance functions. Employee role displays as Employee and has loan-request permissions. Backend OT guard requires Manager role.
- Seed settings: 60-minute QR late cutoff, no grace minutes, 4-hour maximum assigned OT, equal monthly statutory-contribution split, auto overtime disabled, auto time-out disabled.
- Cashier-only selectable initial department/position; legacy department/position reference rows remain inactive rather than being deleted.
- Five fictional full-time Cashier sample employees + employee login accounts (cashier1 through cashier5) and salary histories. Sample accounts require password changes.

## Still needs engineering before policy-complete
- Dedicated OT Time In and OT Time Out attendance states, 5:00–5:30 PM break, and corresponding QR confirmation UI, backed by verified work logging. The legacy AttendanceEngine's auto-OT logic must be tested for disabled-setting behavior.
- Automatic payroll period generation and holiday/banking-day pay-date advance; payroll/leave/loan company-specific formulas and workflow.
- Effective salary divisor validation (365 only when truly fully monthly-paid), statutory tax/rate reviews, loan 5% flat interest and amortization, 13th-month/final-pay edge cases.
- Employee loan application permissions may require service-side checks and page navigation adjustments; seed permission alone does not establish full self-service.
- Real deployment: change demo passwords, change seeded placeholder organization information, secure scanner endpoints, and import fresh database.

## Setup
- For a clean development database, import `database/main.sql` into MySQL with phpMyAdmin or the MySQL client. **This file drops existing tables and will erase old data. Do not import over a live database.**
- No database migrations have been run against a live XAMPP instance in this environment.
- Do not treat unverified existing payroll calculations as compliant until tested with Philippine official effective-dated rules.
