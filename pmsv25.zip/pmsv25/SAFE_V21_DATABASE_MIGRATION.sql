-- PMS V21 — NO SCHEMA MIGRATION REQUIRED (from V20 schema)
-- The default V21 role/roster scope and period validation are implemented in PHP.
-- This file intentionally does not mutate any employee, account or payroll records.
-- Do not reimport a full database dump over your current test data.
SELECT 'PMS V21: No schema changes required. Back up the test database before testing.' AS migration_status;
