-- PMS V17 CONSOLIDATED TEST BUILD - SAFE, NON-DESTRUCTIVE DATABASE MIGRATION
-- TARGET: MariaDB 10.4 / MySQL-compatible. Existing database: attendance_payroll.
-- BACKUP FIRST in phpMyAdmin, restore a CLONED database for testing.
-- Select your CLONED attendance_payroll database in phpMyAdmin before running.
-- Run after the original PMS V16 safe migration. Does not drop tables,
-- DELETE records, reset IDs/passwords, or rewrite historical salary/attendance.
-- Safe to rerun for columns/table that have already been added.

ALTER TABLE `employees`
  ADD COLUMN IF NOT EXISTS `assigned_supervisor_id` BIGINT(20) UNSIGNED NULL;

-- One finite, documented total balance per employee/deduction assignment.
-- Legacy assignments retain NULL total_amount and will NOT be charged by the
-- upgraded payroll engine unless reauthorized under the new procedure.
ALTER TABLE `employee_deductions`
  ADD COLUMN IF NOT EXISTS `total_amount` DECIMAL(12,2) NULL,
  ADD COLUMN IF NOT EXISTS `deducted_amount` DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  ADD COLUMN IF NOT EXISTS `authorization_reference` VARCHAR(255) NULL,
  ADD COLUMN IF NOT EXISTS `completed_at` DATETIME NULL;

-- Entries are written ONLY when a fully disbursed payroll period is marked PAID.
-- One entry per assignment per paid period; the UNIQUE key is idempotency guard.
CREATE TABLE IF NOT EXISTS `employee_deduction_payments` (
  `id` BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `assignment_id` BIGINT(20) UNSIGNED NOT NULL,
  `payroll_period_id` BIGINT(20) UNSIGNED NOT NULL,
  `amount` DECIMAL(12,2) NOT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_ed_payment_period` (`assignment_id`,`payroll_period_id`),
  KEY `idx_ed_payment_period` (`payroll_period_id`),
  CONSTRAINT `fk_ed_payment_assignment` FOREIGN KEY (`assignment_id`)
    REFERENCES `employee_deductions` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `fk_ed_payment_payroll_period` FOREIGN KEY (`payroll_period_id`)
    REFERENCES `payroll_periods` (`id`) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Government-loan registration requires verified official evidence and signed
-- deduction authorization before the salary-payroll engine considers it.
-- Existing ACTIVE loans are NOT silently rewritten or treated as verified.
ALTER TABLE `loans`
  ADD COLUMN IF NOT EXISTS `agency_evidence_reference` VARCHAR(255) NULL,
  ADD COLUMN IF NOT EXISTS `deduction_authorization_reference` VARCHAR(255) NULL,
  ADD COLUMN IF NOT EXISTS `agency_verified_at` DATETIME NULL,
  ADD COLUMN IF NOT EXISTS `release_reference` VARCHAR(255) NULL;

-- Informational verification; safe read-only queries.
SHOW COLUMNS FROM `employees` LIKE 'assigned_supervisor_id';
SHOW COLUMNS FROM `employee_deductions` WHERE Field IN
  ('total_amount','deducted_amount','authorization_reference','completed_at');
SHOW COLUMNS FROM `loans` WHERE Field IN
  ('agency_evidence_reference','deduction_authorization_reference','agency_verified_at','release_reference');
SHOW TABLES LIKE 'employee_deduction_payments';
