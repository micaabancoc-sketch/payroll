PMS V23.1 – USER ACCOUNT ACTIVATION HOTFIX (complete V23 project)
===============================================================
Problem: Activating an inactive employee account showed:
  employee_id: Employee accounts require a linked employee.
Even though the User Accounts table showed a valid Employee ID.

Root cause: api/core/Validator.php includes all nullable fields (even absent
ones) as null in validated(). The UserController::update() method copied these
nulls into every partial PUT update, replacing the existing employee_id with
null when the UI sent only {status: 'ACTIVE'}.

Fix: api/controllers/UserController.php now copies only request-supplied fields
into an update payload. This keeps employee_id, role_id, full_name and email
unchanged when using Activate/Deactivate, and preserves normal linkage checks.

Installation:
1. Back up your existing pmsv23 folder and V23 test database.
2. Extract this complete project into C:\xampp\htdocs\pmsv23_1
   (rename the included pmsv23 folder, or overwrite only after a backup).
3. Keep the SAME V23 test database and config. NO new SQL is required.
4. Log in as Admin > User Accounts, activate one INACTIVE cashier account.
5. Verify it changes to ACTIVE and still has its original Employee ID.
6. Check Employees & Salaries independently; activating a LOGIN account does
   not necessarily change the linked employee's employment status.

Safety: Test on cloned DB first. This is a focused fix. Full payroll logic
is NOT revalidated by this package. PHP syntax checked. No actual local XAMPP
transactions were available for this build.
