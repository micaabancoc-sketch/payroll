(function (global) {
  'use strict';

  var COLORS = {
    blue:   '#2563eb',
    green:  '#16a34a',
    amber:  '#d97706',
    red:    '#dc2626',
    indigo: '#4f46e5',
    slate:  '#94a3b8',
    violet: '#7c3aed',
  };

  /** Grouped bar chart. series: [{label, color, values: []}] */
  function barChart(canvas, labels, series) {
    var ctx = canvas.getContext('2d');
    if (!ctx) { return; }

    var width  = canvas.clientWidth || 400;
    var height = canvas.clientHeight || 220;
    var ratio  = window.devicePixelRatio || 1;

    canvas.width  = width * ratio;
    canvas.height = height * ratio;
    ctx.setTransform(ratio, 0, 0, ratio, 0, 0);
    ctx.clearRect(0, 0, width, height);

    var padLeft = 44, padBottom = 26, padTop = 12, padRight = 8;
    var plotWidth  = width - padLeft - padRight;
    var plotHeight = height - padTop - padBottom;

    var rawMax = 0;
    series.forEach(function (s) {
      s.values.forEach(function (v) { if (Number(v) > rawMax) { rawMax = Number(v); } });
    });

    var scale = yTicks(rawMax, 4);
    var max = scale.max;

    ctx.strokeStyle = '#e2e8f0';
    ctx.fillStyle   = '#64748b';
    ctx.lineWidth   = 1;
    ctx.font        = '10px "Segoe UI", sans-serif';
    ctx.textAlign   = 'right';

    scale.ticks.forEach(function (tick) {
      var y = padTop + plotHeight - ((tick / max) * plotHeight);
      ctx.beginPath();
      ctx.moveTo(padLeft, y);
      ctx.lineTo(width - padRight, y);
      ctx.stroke();

      ctx.fillText(String(tick), padLeft - 6, y + 3);
    });

    var groupCount = Math.max(1, labels.length);
    var groupWidth = plotWidth / groupCount;
    var barWidth   = Math.max(2, (groupWidth * 0.7) / Math.max(1, series.length));

    ctx.textAlign = 'center';

    labels.forEach(function (labelText, index) {
      var groupX = padLeft + (groupWidth * index);

      series.forEach(function (s, sIndex) {
        var value     = Number(s.values[index] || 0);
        var barHeight = (value / max) * plotHeight;
        var x         = groupX + (groupWidth * 0.15) + (barWidth * sIndex);
        var y         = padTop + plotHeight - barHeight;

        if (barHeight > 0) {
          var gradient = ctx.createLinearGradient(0, y, 0, y + barHeight);
          gradient.addColorStop(0, s.color);
          gradient.addColorStop(1, hexToRgba(s.color, 0.72));
          ctx.fillStyle = gradient;
          roundedRect(ctx, x, y, barWidth, barHeight, Math.min(4, barWidth / 2));
          ctx.fill();
        }
      });

      ctx.fillStyle = '#64748b';
    });

    ctx.fillStyle = '#64748b';
    ctx.font      = '10px "Segoe UI", sans-serif';
    drawXLabels(ctx, labels, function (index) {
      return padLeft + (groupWidth * index) + (groupWidth / 2);
    }, padLeft, width - padRight, height - 8);
  }

  /** Doughnut chart. data: [{label, value, color}] */
  function doughnutChart(canvas, data) {
    var ctx = canvas.getContext('2d');
    if (!ctx) { return; }

    var width  = canvas.clientWidth || 300;
    var height = canvas.clientHeight || 220;
    var ratio  = window.devicePixelRatio || 1;

    canvas.width  = width * ratio;
    canvas.height = height * ratio;
    ctx.setTransform(ratio, 0, 0, ratio, 0, 0);
    ctx.clearRect(0, 0, width, height);

    var total = 0;
    data.forEach(function (d) { total += Number(d.value || 0); });

    var centerX = width / 2;
    var centerY = height / 2;
    var radius  = Math.min(width, height) / 2 - 14;
    var inner   = radius * 0.58;

    if (total <= 0) {
      ctx.strokeStyle = '#dbeafe';
      ctx.lineWidth   = radius - inner;
      ctx.beginPath();
      ctx.arc(centerX, centerY, (radius + inner) / 2, 0, Math.PI * 2);
      ctx.stroke();

      ctx.fillStyle = '#5f7fa8';
      ctx.font      = '11px "Segoe UI", sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText('No data', centerX, centerY + 4);

      return;
    }

    var startAngle = -Math.PI / 2;

    data.forEach(function (slice) {
      var value = Number(slice.value || 0);
      if (value <= 0) { return; }

      var sliceAngle = (value / total) * Math.PI * 2;

      ctx.beginPath();
      ctx.fillStyle = slice.color;
      ctx.moveTo(centerX, centerY);
      ctx.arc(centerX, centerY, radius, startAngle, startAngle + sliceAngle);
      ctx.closePath();
      ctx.fill();
      ctx.strokeStyle = '#ffffff';
      ctx.lineWidth = 2;
      ctx.stroke();

      startAngle += sliceAngle;
    });

    ctx.globalCompositeOperation = 'destination-out';
    ctx.beginPath();
    ctx.arc(centerX, centerY, inner, 0, Math.PI * 2);
    ctx.fill();
    ctx.globalCompositeOperation = 'source-over';

    ctx.fillStyle = '#173a68';
    ctx.font      = '700 15px "Segoe UI", sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText(String(total), centerX, centerY + 1);
    ctx.fillStyle = '#64748b';
    ctx.font      = '9px "Segoe UI", sans-serif';
    ctx.fillText('records', centerX, centerY + 14);
  }
  /** Line chart. series: [{label, color, values: []}] */
  function lineChart(canvas, labels, series) {
    var ctx = canvas.getContext('2d');
    if (!ctx) { return; }

    var width  = canvas.clientWidth || 400;
    var height = canvas.clientHeight || 220;
    var ratio  = window.devicePixelRatio || 1;

    canvas.width  = width * ratio;
    canvas.height = height * ratio;
    ctx.setTransform(ratio, 0, 0, ratio, 0, 0);
    ctx.clearRect(0, 0, width, height);

    var padLeft = 44, padBottom = 26, padTop = 12, padRight = 8;
    var plotWidth  = width - padLeft - padRight;
    var plotHeight = height - padTop - padBottom;

    var rawMax = 0;
    series.forEach(function (s) {
      s.values.forEach(function (v) { if (Number(v) > rawMax) { rawMax = Number(v); } });
    });

    var scale = yTicks(rawMax, 4);
    var max = scale.max;

    ctx.strokeStyle = '#e2e8f0';
    ctx.fillStyle   = '#64748b';
    ctx.font        = '10px "Segoe UI", sans-serif';
    ctx.textAlign   = 'right';

    scale.ticks.forEach(function (tick) {
      var y = padTop + plotHeight - ((tick / max) * plotHeight);
      ctx.beginPath();
      ctx.moveTo(padLeft, y);
      ctx.lineTo(width - padRight, y);
      ctx.stroke();
      ctx.fillText(String(tick), padLeft - 6, y + 3);
    });

    var count = Math.max(1, labels.length);
    var stepX = count > 1 ? (plotWidth / (count - 1)) : 0;

    series.forEach(function (s) {
      ctx.strokeStyle = s.color;
      ctx.lineWidth   = 2;
      ctx.beginPath();

      s.values.forEach(function (value, index) {
        var x = count > 1 ? (padLeft + stepX * index) : (padLeft + plotWidth / 2);
        var y = padTop + plotHeight - ((Number(value || 0) / max) * plotHeight);

        if (index === 0) {
          ctx.moveTo(x, y);
        } else {
          ctx.lineTo(x, y);
        }
      });

      ctx.stroke();
    });

    ctx.fillStyle = '#64748b';
    ctx.font      = '10px "Segoe UI", sans-serif';

    drawXLabels(ctx, labels, function (index) {
      return count > 1 ? (padLeft + stepX * index) : (padLeft + plotWidth / 2);
    }, padLeft, width - padRight, height - 8);
  }

  function niceMax(value) {
    var magnitude = Math.pow(10, Math.floor(Math.log10(value)));
    var scaled    = value / magnitude;

    var nice = scaled <= 1 ? 1 : scaled <= 2 ? 2 : scaled <= 5 ? 5 : 10;

    return nice * magnitude;
  }

  /**
   * Y-axis ticks with no duplicate labels.
   *
   * Small counts (the common attendance case: 0s and 1s) previously rounded
   * to "1, 1, 1, 0, 0" — a merged, unreadable axis. Small maxima now get one
   * tick per integer; larger ones get 1/2/2.5/5/10 steps.
   *
   * @returns {{max: number, ticks: number[]}}
   */
  function yTicks(maxValue, steps) {
    steps = steps || 4;
    var max = Number(maxValue) || 0;

    if (max <= 0) {
      return { max: steps, ticks: [0, 1, 2, 3, 4].slice(0, steps + 1) };
    }

    if (max <= steps) {
      var ints = [];
      var top = Math.ceil(max);
      for (var v = 0; v <= top; v++) { ints.push(v); }
      return { max: top, ticks: ints };
    }

    var rawStep   = max / steps;
    var magnitude = Math.pow(10, Math.floor(Math.log10(rawStep)));
    var norm      = rawStep / magnitude;
    var nice      = norm <= 1 ? 1 : norm <= 2 ? 2 : norm <= 2.5 ? 2.5 : norm <= 5 ? 5 : 10;
    var step      = nice * magnitude;
    var topMax    = Math.ceil(max / step) * step;

    var ticks = [];
    for (var t = 0; t <= topMax + (step / 1000); t += step) {
      ticks.push(Math.round(t * 100) / 100);
    }

    return { max: topMax, ticks: ticks };
  }

  /**
   * X-axis labels that never merge: empty labels are skipped, colliding
   * labels are dropped, and the first/last labels are pulled inside the
   * plot so they are never clipped by the canvas edge.
   */
  function drawXLabels(ctx, labels, xFor, left, right, y) {
    var prevRight = -Infinity;

    labels.forEach(function (labelText, index) {
      var text = shorten(labelText);
      if (!text) { return; }

      var x     = xFor(index);
      var half  = ctx.measureText(text).width / 2;
      var align = 'center';

      if (x - half < left) {
        align = 'left';
        x = left;
      } else if (x + half > right) {
        align = 'right';
        x = right;
      }

      var itemLeft  = align === 'left' ? x : align === 'right' ? x - half * 2 : x - half;
      var itemRight = align === 'right' ? x : align === 'left' ? x + half * 2 : x + half;

      if (itemLeft < prevRight + 2) { return; }

      ctx.textAlign = align;
      ctx.fillText(text, x, y);
      prevRight = itemRight;
    });

    ctx.textAlign = 'center';
  }

  function roundedRect(ctx, x, y, width, height, radius) {
    var r = Math.max(0, Math.min(radius, width / 2, height / 2));
    ctx.beginPath();
    ctx.moveTo(x + r, y);
    ctx.lineTo(x + width - r, y);
    ctx.quadraticCurveTo(x + width, y, x + width, y + r);
    ctx.lineTo(x + width, y + height);
    ctx.lineTo(x, y + height);
    ctx.lineTo(x, y + r);
    ctx.quadraticCurveTo(x, y, x + r, y);
    ctx.closePath();
  }

  function hexToRgba(hex, alpha) {
    var value = String(hex || '').replace('#', '');
    if (!/^[0-9a-f]{6}$/i.test(value)) { return hex; }
    return 'rgba(' + parseInt(value.slice(0, 2), 16) + ','
      + parseInt(value.slice(2, 4), 16) + ','
      + parseInt(value.slice(4, 6), 16) + ',' + alpha + ')';
  }

  function shorten(text, maxChars) {
    var limit = maxChars || 8;
    text = String(text === null || text === undefined ? '' : text);

    return text.length > limit ? text.slice(0, limit - 1) + '…' : text;
  }

  global.Charts = {
    colors: COLORS,
    bar: barChart,
    doughnut: doughnutChart,
    line: lineChart,
  };
})(window);
