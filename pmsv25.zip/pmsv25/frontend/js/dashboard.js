(function () {
  'use strict';

  if (!App.guard()) { return; }

  App.renderNav('dashboard');
  App.renderHeader();

  var activityPage = 1;
  var expandedActivityPage = 1;
  var activityModal = document.getElementById('activity-modal');
  var calendarDate = new Date();
  calendarDate.setDate(1);
  var calendarYears = {};
  var calendarFloat = document.getElementById('calendar-float');
  var holidayFloat = document.getElementById('holiday-float');

  var STATUS_COLORS = {
    PRESENT:   Charts.colors.green,
    LATE:      Charts.colors.amber,
    ABSENT:    Charts.colors.red,
    UNDERTIME: '#ea580c',
    LEAVE:     Charts.colors.indigo,
    HOLIDAY:   '#818cf8',
    REST_DAY:  Charts.colors.slate,
  };

  async function load() {
    var data;

    try {
      data = (await Api.get('/dashboard')).data;
    } catch (error) {
      App.notify(error.message, 'error');
      return;
    }

    renderCards(data.cards);
    renderToday(data.today_attendance);
    renderPending(data.pending_leave, data.pending_overtime);
    renderPayroll(data.payroll);
    renderCharts(data.charts);
    renderDepartments((data.charts && data.charts.department_stats) || []);
    connectDashboardCards();
    if (App.can('audit.view')) {
      loadActivities(false);
    } else {
      document.getElementById('expand-activities').hidden = true;
      renderActivities(data.recent_activities || [], false);
    }
  }
  function renderCards(cards) {
    var icons = {
      late: '<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></svg>',
      absent: '<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="9"/><path d="M8 8l8 8M16 8l-8 8"/></svg>',
      pending_leave: '<svg viewBox="0 0 24 24"><rect x="4" y="5" width="16" height="16" rx="2"/><path d="M8 3v4M16 3v4M4 10h16M12 13v4M10 15h4"/></svg>',
      pending_ot: '<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l4 2M18 4l2-2"/></svg>'
    };
    var definitions = [
      { key: 'late',          label: 'Late today',       accent: 'accent-warning', href: 'attendance/index.html', permission: 'attendance.view_own' },
      { key: 'absent',        label: 'Absent today',     accent: 'accent-danger', href: 'attendance/index.html', permission: 'attendance.view_own' },
      { key: 'pending_leave', label: 'Pending leave',    accent: 'accent-violet', href: 'leave/index.html', permission: 'leave.view_own' },
      { key: 'pending_ot',    label: 'Pending overtime', accent: 'accent-cyan', href: 'overtime/index.html', permission: 'overtime.view_own' }
    ];

    var employees = Number(cards.employees || 0);
    var present = Number(cards.present || 0);
    var attendanceRate = employees > 0 ? Math.round((present / employees) * 100) : 0;
    document.getElementById('present-total').textContent = App.formatNumber(present, 0);
    document.getElementById('present-context').textContent = App.formatNumber(employees, 0) + ' active employee' + (employees === 1 ? '' : 's') + ' in the system';
    document.getElementById('attendance-details').innerHTML =
        '<div><strong>' + App.escapeHtml(attendanceRate) + '%</strong><span>Attendance rate</span></div>'
      + '<div><strong>' + App.escapeHtml(cards.on_leave || 0) + '</strong><span>On leave</span></div>'
      + '<div><strong>' + App.escapeHtml(App.formatNumber(cards.overtime_hours || 0)) + '</strong><span>OT hours</span></div>';

    var html = '';

    definitions.forEach(function (definition) {
      var clickable = App.can(definition.permission)
        ? ' data-card-href="' + App.escapeHtml(definition.href) + '" tabindex="0" role="link"'
        : '';
      html += '<article class="stat-card dashboard-kpi-card ' + definition.accent + '"' + clickable + '>'
           +  '<div class="stat-card-top"><div class="stat-label">' + App.escapeHtml(definition.label) + '</div>'
           +  '<span class="stat-icon" aria-hidden="true">' + icons[definition.key] + '</span></div>'
           +  '<div class="stat-value">' + App.escapeHtml(cards[definition.key] || 0) + '</div>'
           +  '</article>';
    });

    document.getElementById('cards').innerHTML = html;
  }

  function renderToday(attendance) {
    var container = document.getElementById('today-table');
    var summary   = attendance.summary || {};
    var recent    = attendance.recent || [];

    document.getElementById('att-sub').textContent =
      App.formatNumber(summary.overtime_hours) + ' OT hours recorded today';

    if (!recent.length) {
      App.emptyState(container, 'No scans recorded today yet.');
      return;
    }

    var html = '<table><thead><tr>'
      + '<th>Employee</th><th>Event</th><th>Time</th>'
      + '<th>Status</th><th>Department</th>'
      + '</tr></thead><tbody>';

    recent.forEach(function (row) {
      html += '<tr>'
        + '<td>' + App.escapeHtml(row.full_name || '') + '</td>'
        + '<td>' + App.escapeHtml(App.label(row.event_type)) + '</td>'
        + '<td class="nowrap">' + App.escapeHtml(App.formatTime(row.scanned_at)) + '</td>'
        + '<td>' + (row.attendance_status
            ? '<span class="' + App.statusClass(row.attendance_status) + '">' + App.escapeHtml(App.label(row.attendance_status)) + '</span>'
            : '<span class="muted">&mdash;</span>') + '</td>'
        + '<td>' + App.escapeHtml(row.department_name || '') + '</td>'
        + '</tr>';
    });

    container.innerHTML = html + '</tbody></table>';
  }
  function renderPending(leaves, overtime) {
    renderLeaveTable(document.getElementById('leave-table'), leaves || []);
    renderOtTable(document.getElementById('ot-table'), overtime || []);
  }

  function renderLeaveTable(container, rows) {
    if (!rows.length) {
      App.emptyState(container, 'No pending leave requests.');
      return;
    }

    var html = '<table><thead><tr>'
      + '<th>Employee</th><th>Type</th><th>Dates</th><th>Days</th>'
      + '</tr></thead><tbody>';

    rows.forEach(function (row) {
      html += '<tr>'
        + '<td>' + App.escapeHtml(row.full_name || '') + '</td>'
        + '<td>' + App.escapeHtml(row.leave_type_name || '') + '</td>'
        + '<td class="nowrap">' + App.escapeHtml(App.formatDate(row.start_date))
        + ' &ndash; ' + App.escapeHtml(App.formatDate(row.end_date)) + '</td>'
        + '<td>' + App.escapeHtml(App.formatNumber(row.days)) + '</td>'
        + '</tr>';
    });

    container.innerHTML = html + '</tbody></table>';
  }

  function renderOtTable(container, rows) {
    if (!rows.length) {
      App.emptyState(container, 'No pending overtime assignments.');
      return;
    }

    var html = '<table><thead><tr>'
      + '<th>Employee</th><th>Date</th><th>Time</th><th>Hours</th>'
      + '</tr></thead><tbody>';

    rows.forEach(function (row) {
      html += '<tr>'
        + '<td>' + App.escapeHtml(row.full_name || '') + '</td>'
        + '<td class="nowrap">' + App.escapeHtml(App.formatDate(row.overtime_date)) + '</td>'
        + '<td class="nowrap">' + App.escapeHtml(App.formatTime(row.start_time))
        + ' &ndash; ' + App.escapeHtml(App.formatTime(row.end_time)) + '</td>'
        + '<td>' + App.escapeHtml(App.formatNumber(row.hours)) + '</td>'
        + '</tr>';
    });

    container.innerHTML = html + '</tbody></table>';
  }

  function renderPayroll(payroll) {
    var container = document.getElementById('payroll-status');

    if (!payroll) {
      App.emptyState(container, 'No completed payroll period yet. Upcoming cutoffs are available in Payroll Runs.');
      return;
    }

    container.innerHTML =
        '<div class="dashboard-payroll-summary">'
      +   '<div class="dashboard-payroll-period"><span class="dashboard-card-label">Payroll period</span><strong>' + App.escapeHtml(payroll.name || payroll.code) + '</strong><small>Pay date ' + App.escapeHtml(App.formatDate(payroll.pay_date)) + '</small></div>'
      +   '<div class="dashboard-payroll-metric"><span>Gross pay</span><strong>' + App.escapeHtml(App.formatMoney(payroll.total_gross)) + '</strong></div>'
      +   '<div class="dashboard-payroll-metric"><span>Deductions</span><strong>' + App.escapeHtml(App.formatMoney(payroll.total_deductions)) + '</strong></div>'
      +   '<div class="dashboard-payroll-metric net"><span>Net pay</span><strong>' + App.escapeHtml(App.formatMoney(payroll.total_net)) + '</strong></div>'
      +   '<div class="dashboard-payroll-state"><span class="' + App.statusClass(payroll.status) + '">' + App.escapeHtml(App.label(payroll.status)) + '</span><small>' + App.escapeHtml(payroll.employee_count || 0) + ' employees</small></div>'
      + '</div>';
  }

  function renderCharts(charts) {
    var trend = (charts && charts.attendance_trend) || [];
    var labels = trend.map(function (row, index) {
      return index === 0 || index === trend.length - 1 || index % 3 === 0 ? String(row.date).slice(5) : '';
    });

    Charts.line(document.getElementById('chart-attendance'), labels, [
      { label: 'Present', color: Charts.colors.green, values: trend.map(function (r) { return r.present; }) },
      { label: 'Late',    color: Charts.colors.amber, values: trend.map(function (r) { return r.late; }) },
      { label: 'Absent',  color: Charts.colors.red,   values: trend.map(function (r) { return r.absent; }) },
    ]);

    document.getElementById('legend-attendance').innerHTML =
        '<span><i class="legend-dot" style="background:' + Charts.colors.green + '"></i>Present</span>'
      + '<span><i class="legend-dot" style="background:' + Charts.colors.amber + '"></i>Late</span>'
      + '<span><i class="legend-dot" style="background:' + Charts.colors.red + '"></i>Absent</span>';

    var breakdown = (charts && charts.status_breakdown) || [];

    Charts.doughnut(document.getElementById('chart-status'), breakdown.map(function (row) {
      return {
        label: App.label(row.status),
        value: row.count,
        color: STATUS_COLORS[row.status] || Charts.colors.slate,
      };
    }));

    document.getElementById('legend-status').innerHTML = breakdown.map(function (row) {
      return '<span><i class="legend-dot" style="background:' + (STATUS_COLORS[row.status] || Charts.colors.slate) + '"></i>'
           + App.escapeHtml(App.label(row.status)) + ' (' + row.count + ')</span>';
    }).join('');
  }
  function renderDepartments(rows) {
    var container = document.getElementById('dept-table');

    if (!rows.length) {
      App.emptyState(container, 'No departments configured.');
      return;
    }

    var html = '';

    rows.forEach(function (row) {
      var employees = Number(row.employee_count || 0);
      var present = Number(row.present_today || 0);
      var percentage = employees > 0 ? Math.min(100, Math.round((present / employees) * 100)) : 0;
      html += '<div class="department-progress">'
        + '<div class="department-progress-head"><strong title="' + App.escapeHtml(row.name) + '">' + App.escapeHtml(row.name) + '</strong><span>'
        + App.escapeHtml(present) + ' / ' + App.escapeHtml(employees) + '</span></div>'
        + '<div class="department-progress-track" role="progressbar" aria-label="' + App.escapeHtml(row.name) + ' attendance" aria-valuenow="' + App.escapeHtml(percentage) + '" aria-valuemin="0" aria-valuemax="100">'
        + '<i style="width:' + App.escapeHtml(percentage) + '%"></i></div></div>';
    });

    container.innerHTML = html;
  }

  function connectDashboardCards() {
    var destinations = [
      ['.dashboard-total-card', 'attendance/index.html', 'attendance.view_own'],
      ['.dashboard-chart-card', 'attendance/index.html', 'attendance.view_own'],
      ['.dashboard-status-card', 'attendance/index.html', 'attendance.view_own'],
      ['.dashboard-department-card', 'employees/index.html', 'employees.view'],
      ['.dashboard-payroll-card', App.can('payroll.period.view') ? 'payroll/index.html' : 'payroll/payslips.html', App.can('payroll.period.view') ? 'payroll.period.view' : 'payroll.payslip.view_own']
    ];
    destinations.forEach(function (item) {
      var card = document.querySelector(item[0]);
      if (!card || !App.can(item[2])) { return; }
      card.setAttribute('data-card-href', item[1]);
      card.setAttribute('tabindex', '0');
      card.setAttribute('role', 'link');
    });
  }

  function openCard(card) {
    if (card && card.getAttribute('data-card-href')) { window.location.href = card.getAttribute('data-card-href'); }
  }

  document.querySelector('.dashboard-content').addEventListener('click', function (event) {
    if (event.target.closest('button, a, input, select, textarea, summary')) { return; }
    openCard(event.target.closest('[data-card-href]'));
  });
  document.querySelector('.dashboard-content').addEventListener('keydown', function (event) {
    if ((event.key === 'Enter' || event.key === ' ') && event.target.hasAttribute('data-card-href')) {
      event.preventDefault();
      openCard(event.target);
    }
  });

  /* ---------- personalized welcome, clock, and holiday calendar ---------- */

  function updateClock() {
    var now = new Date();
    var seconds = now.getSeconds();
    var minutes = now.getMinutes() + seconds / 60;
    var hours = (now.getHours() % 12) + minutes / 60;
    document.getElementById('clock-second').style.transform = 'translateX(-50%) rotate(' + (seconds * 6) + 'deg)';
    document.getElementById('clock-minute').style.transform = 'translateX(-50%) rotate(' + (minutes * 6) + 'deg)';
    document.getElementById('clock-hour').style.transform = 'translateX(-50%) rotate(' + (hours * 30) + 'deg)';
    document.getElementById('digital-time').textContent = now.toLocaleTimeString('en-PH', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
    document.getElementById('digital-date').textContent = now.toLocaleDateString('en-PH', { weekday: 'short', month: 'short', day: 'numeric', year: 'numeric' });
  }

  function initializeWelcomeClock() {
    var user = Api.user() || {};
    var firstName = String(user.full_name || user.username || 'User').trim().split(/\s+/)[0];
    document.getElementById('dashboard-welcome').textContent = 'Welcome, ' + firstName;
    updateClock();
    window.setInterval(updateClock, 1000);
  }

  function localIso(year, month, day) {
    return String(year) + '-' + String(month + 1).padStart(2, '0') + '-' + String(day).padStart(2, '0');
  }

  async function holidaysForYear(year) {
    if (!calendarYears[year]) {
      calendarYears[year] = (await Api.get('/dashboard/holidays', { year: year })).data || [];
    }
    return calendarYears[year];
  }

  async function renderCalendar() {
    var year = calendarDate.getFullYear();
    var month = calendarDate.getMonth();
    var grid = document.getElementById('calendar-grid');
    document.getElementById('calendar-month').textContent = calendarDate.toLocaleDateString('en-PH', { month: 'long', year: 'numeric' });
    grid.innerHTML = '<div class="calendar-loading">Loading holidays...</div>';

    try {
      var holidays = await holidaysForYear(year);
      var holidayMap = {};
      holidays.forEach(function (holiday) {
        holidayMap[holiday.holiday_date] = holidayMap[holiday.holiday_date] || [];
        holidayMap[holiday.holiday_date].push(holiday);
      });
      var firstDay = new Date(year, month, 1).getDay();
      var lastDate = new Date(year, month + 1, 0).getDate();
      var today = new Date();
      var todayIso = localIso(today.getFullYear(), today.getMonth(), today.getDate());
      var html = '';
      for (var blank = 0; blank < firstDay; blank++) { html += '<span class="calendar-blank"></span>'; }
      for (var day = 1; day <= lastDate; day++) {
        var iso = localIso(year, month, day);
        var isHoliday = !!holidayMap[iso];
        html += '<button type="button" class="calendar-day' + (isHoliday ? ' holiday' : '') + (iso === todayIso ? ' today' : '')
          + '" data-calendar-date="' + iso + '"' + (isHoliday ? ' title="' + App.escapeHtml(holidayMap[iso].map(function (h) { return h.name; }).join(', ')) + '"' : '') + '>'
          + '<span>' + day + '</span>' + (isHoliday ? '<i></i>' : '') + '</button>';
      }
      grid.innerHTML = html;
    } catch (error) {
      grid.innerHTML = '<div class="calendar-loading">' + App.escapeHtml(error.message) + '</div>';
    }
  }

  async function showDateDetails(iso) {
    var parts = iso.split('-').map(Number);
    var date = new Date(parts[0], parts[1] - 1, parts[2]);
    var holidays = await holidaysForYear(parts[0]);
    var matches = holidays.filter(function (holiday) { return holiday.holiday_date === iso; });
    document.getElementById('holiday-float-date').textContent = date.toLocaleDateString('en-PH', { month: 'long', day: 'numeric', year: 'numeric' });
    document.getElementById('holiday-float-weekday').textContent = date.toLocaleDateString('en-PH', { weekday: 'long' });
    document.getElementById('holiday-float-body').innerHTML = matches.length
      ? matches.map(function (holiday) {
          return '<article class="holiday-detail"><span class="status status-active">' + App.escapeHtml(App.label(holiday.holiday_type)) + '</span><h3>'
            + App.escapeHtml(holiday.name) + '</h3><p>' + (Number(holiday.is_paid) === 1 ? 'Paid holiday' : 'Unpaid holiday')
            + (Number(holiday.is_recurring) === 1 ? ' &middot; Repeats yearly' : '') + '</p></article>';
        }).join('')
      : '<div class="holiday-empty"><strong>Regular workday</strong><span>No holiday is recorded for this date.</span></div>';
    holidayFloat.hidden = false;
  }

  document.getElementById('live-clock').addEventListener('click', function () {
    calendarFloat.hidden = !calendarFloat.hidden;
    this.setAttribute('aria-expanded', calendarFloat.hidden ? 'false' : 'true');
    if (!calendarFloat.hidden) { renderCalendar(); }
  });
  document.getElementById('calendar-prev').addEventListener('click', function () { calendarDate.setMonth(calendarDate.getMonth() - 1); renderCalendar(); });
  document.getElementById('calendar-next').addEventListener('click', function () { calendarDate.setMonth(calendarDate.getMonth() + 1); renderCalendar(); });
  document.getElementById('calendar-grid').addEventListener('click', function (event) {
    var day = event.target.closest('[data-calendar-date]');
    if (day) { showDateDetails(day.getAttribute('data-calendar-date')); }
  });
  document.querySelector('[data-close-calendar]').addEventListener('click', function () { calendarFloat.hidden = true; document.getElementById('live-clock').setAttribute('aria-expanded', 'false'); });
  document.querySelector('[data-close-holiday]').addEventListener('click', function () { holidayFloat.hidden = true; });
  document.addEventListener('click', function (event) {
    if (event.target.closest('.floating-card, #live-clock')) { return; }
    calendarFloat.hidden = true;
    holidayFloat.hidden = true;
    document.getElementById('live-clock').setAttribute('aria-expanded', 'false');
  });

  function activityFilters(expanded) {
    if (!expanded) { return { page: activityPage }; }
    return {
      page: expandedActivityPage,
      per_page: 25,
      q: document.getElementById('activity-q').value.trim(),
      username: document.getElementById('activity-user').value.trim(),
      action: document.getElementById('activity-action').value.trim(),
      date_from: document.getElementById('activity-from').value,
      date_to: document.getElementById('activity-to').value,
    };
  }

  async function loadActivities(expanded) {
    var container = document.getElementById(expanded ? 'activity-expanded-table' : 'activity-table');
    App.loading(container);
    try {
      var response = await Api.get('/dashboard/activities', activityFilters(expanded));
      renderActivities(response.data || [], expanded, response.meta && response.meta.pagination);
    } catch (error) {
      App.emptyState(container, error.message);
    }
  }

  function renderActivities(rows, expanded, meta) {
    var container = document.getElementById(expanded ? 'activity-expanded-table' : 'activity-table');
    var paging = document.getElementById(expanded ? 'activity-expanded-paging' : 'activity-paging');

    if (!rows.length) {
      App.emptyState(container, 'No activity recorded yet.');
      paging.innerHTML = '';
      return;
    }

    var html = '<table><thead><tr>'
      + '<th>User</th><th>Action</th>' + (expanded ? '<th>Entity</th>' : '') + '<th>Description</th><th>When</th>'
      + '</tr></thead><tbody>';

    rows.forEach(function (row) {
      html += '<tr' + (App.isSampleData(row) ? ' class="row-sample"' : '') + '>'
        + '<td>' + App.escapeHtml(row.username || '\u2014') + '</td>'
        + '<td>' + App.escapeHtml(App.label(row.action)) + '</td>'
        + (expanded ? '<td>' + App.escapeHtml(App.label(row.entity_type || '') || '\u2014') + '</td>' : '')
        + '<td>' + App.sampleBadge(row) + App.escapeHtml(row.description || '\u2014') + '</td>'
        + '<td class="nowrap">' + App.escapeHtml(expanded ? (App.formatDate(row.created_at) + ' ' + App.formatTime(row.created_at)) : App.formatTime(row.created_at)) + '</td>'
        + '</tr>';
    });

    container.innerHTML = html + '</tbody></table>';
    renderActivityPaging(paging, meta, expanded);
  }

  function renderActivityPaging(container, meta, expanded) {
    if (!meta) { container.innerHTML = ''; return; }
    container.innerHTML = '<span class="pagination-info">Page ' + App.escapeHtml(meta.current_page) + ' of ' + App.escapeHtml(Math.max(1, meta.total_pages)) + ' &middot; ' + App.escapeHtml(meta.total_records) + ' activities</span>'
      + '<button type="button" class="btn btn-ghost btn-sm" data-activity-prev' + (meta.has_prev ? '' : ' disabled') + '>&laquo; Previous</button>'
      + '<button type="button" class="btn btn-ghost btn-sm" data-activity-next' + (meta.has_next ? '' : ' disabled') + '>Next &raquo;</button>';
    var prev = container.querySelector('[data-activity-prev]');
    var next = container.querySelector('[data-activity-next]');
    if (prev) { prev.addEventListener('click', function () { if (expanded) { expandedActivityPage--; } else { activityPage--; } loadActivities(expanded); }); }
    if (next) { next.addEventListener('click', function () { if (expanded) { expandedActivityPage++; } else { activityPage++; } loadActivities(expanded); }); }
  }

  document.getElementById('expand-activities').addEventListener('click', function () {
    activityModal.hidden = false;
    expandedActivityPage = 1;
    loadActivities(true);
  });
  document.querySelector('[data-close-activities]').addEventListener('click', function () { activityModal.hidden = true; });
  activityModal.addEventListener('click', function (event) { if (event.target === activityModal) { activityModal.hidden = true; } });
  document.getElementById('filter-activities').addEventListener('click', function () { expandedActivityPage = 1; loadActivities(true); });
  document.getElementById('clear-activities').addEventListener('click', function () {
    ['activity-q', 'activity-user', 'activity-action', 'activity-from', 'activity-to'].forEach(function (id) { document.getElementById(id).value = ''; });
    expandedActivityPage = 1;
    loadActivities(true);
  });

  initializeWelcomeClock();
  load();
})();
