(function (global) {
  'use strict';

  function escapeHtml(value) {
    // The ampersand must be replaced first, otherwise the entities produced by
    // the later calls would themselves be re-escaped.
    return String(value === null || value === undefined ? '' : value)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;');
  }

  function formatMoney(value, symbol) {
    var amount = Number(value || 0);
    var prefix = symbol === undefined ? 'PHP ' : symbol;

    return prefix + amount.toLocaleString('en-PH', {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    });
  }

  function formatNumber(value, decimals) {
    var places = decimals === undefined ? 2 : decimals;

    return Number(value || 0).toLocaleString('en-PH', {
      minimumFractionDigits: places,
      maximumFractionDigits: places,
    });
  }

  function formatDate(value) {
    if (!value) { return ''; }

    var date = new Date(value);
    if (isNaN(date.getTime())) { return String(value); }

    return date.toLocaleDateString('en-PH', { year: 'numeric', month: 'short', day: 'numeric' });
  }

  function formatTime(value) {
    if (!value) { return ''; }

    var date = new Date(value);

    if (isNaN(date.getTime())) {
      // A bare time such as "08:00:00".
      var match = /^(\d{2}):(\d{2})/.exec(String(value));
      if (!match) { return String(value); }

      var hour   = parseInt(match[1], 10);
      var suffix = hour >= 12 ? 'PM' : 'AM';
      var display = hour % 12 === 0 ? 12 : hour % 12;

      return display + ':' + match[2] + ' ' + suffix;
    }

    return date.toLocaleTimeString('en-PH', { hour: 'numeric', minute: '2-digit' });
  }

  function formatLateMinutes(minutes) {
    var total = Math.max(0, Math.floor(Number(minutes || 0)));
    var hours   = Math.floor(total / 60);
    var minutes = total % 60;

    var parts = [];
    if (hours > 0) {
      parts.push(hours + ' hour' + (hours === 1 ? '' : 's'));
    }
    if (minutes > 0) {
      parts.push(minutes + ' minute' + (minutes === 1 ? '' : 's'));
    }
    if (parts.length === 0) {
      parts.push('0 minutes');
    }

    return 'Late: ' + parts.join(' and ');
  }

  function label(value) {
    if (value === null || value === undefined) { return ''; }

    return String(value)
      .replace(/_/g, ' ')
      .toLowerCase()
      .replace(/\b\w/g, function (c) { return c.toUpperCase(); });
  }

  function statusClass(value) {
    return 'status status-' + String(value || '').toLowerCase().replace(/_/g, '-');
  }

  /**
   * Was this audit row written by the sample-data seeder?
   *
   * The API marks the rows database/seed_audit_logs.php writes with
   * `is_sample`; everything a real user does comes back unmarked. Only an
   * explicit truthy flag counts, so a missing field — an older payload, or a
   * feed that does not carry it — never marks genuine activity.
   */
  function isSampleData(row) {
    return !!(row && (row.is_sample === true || row.is_sample === 1 || row.is_sample === '1'));
  }

  function sampleBadge(row) {
    if (!isSampleData(row)) { return ''; }

    return '<span class="badge-sample" title="Sample data written by database/seed_audit_logs.php, not real activity">Test data</span>';
  }

  function applyBranding(branding) {
    var logo = branding && branding.logo;
    if (!/^assets\/(?:uploads\/)?[a-zA-Z0-9._-]+$/.test(String(logo || ''))) { return; }

    document.querySelectorAll('.brand-logo, .login-logo').forEach(function (image) {
      image.src = logo;
    });
    document.querySelectorAll('link[rel~="icon"]').forEach(function (icon) {
      icon.href = logo;
      icon.removeAttribute('type');
    });
  }

  function loadBranding() {
    if (typeof Api === 'undefined' || typeof Api.get !== 'function') { return Promise.resolve(null); }
    return Api.get('/settings/branding').then(function (response) {
      applyBranding(response.data || {});
      return response.data || {};
    }).catch(function () {
      return null;
    });
  }

  var ACTION_ICONS = {
    view: '<svg viewBox="0 0 24 24"><path d="M2 12s3.5-6 10-6 10 6 10 6-3.5 6-10 6S2 12 2 12z"/><circle cx="12" cy="12" r="2.5"/></svg>',
    edit: '<svg viewBox="0 0 24 24"><path d="M4 20h4L19 9l-4-4L4 16v4zM13.5 6.5l4 4"/></svg>',
    archive: '<svg viewBox="0 0 24 24"><path d="M4 7h16v13H4zM3 3h18v4H3zM9 11h6"/></svg>',
    restore: '<svg viewBox="0 0 24 24"><path d="M4 10a8 8 0 1 1 2 8M4 10V4m0 6h6"/></svg>',
    approve: '<svg viewBox="0 0 24 24"><path d="M5 12l4 4L19 6"/></svg>',
    reject: '<svg viewBox="0 0 24 24"><path d="M6 6l12 12M18 6L6 18"/></svg>',
    cancel: '<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="9"/><path d="M8 8l8 8M16 8l-8 8"/></svg>',
    delete: '<svg viewBox="0 0 24 24"><path d="M4 7h16M9 7V4h6v3M7 7l1 13h8l1-13M10 11v5M14 11v5"/></svg>',
    key: '<svg viewBox="0 0 24 24"><circle cx="8" cy="15" r="4"/><path d="M11 12l8-8M16 7l2 2M14 9l2 2"/></svg>',
    status: '<svg viewBox="0 0 24 24"><path d="M4 12h16M15 7l5 5-5 5"/></svg>'
  };

  function actionMenu(items, labelText) {
    var available = (items || []).filter(function (item) {
      if (!item || item.show === false) { return false; }
      return !/archive|restore|permanent.?delete|move to archive|remove|purge/i.test(String(item.label || '') + ' ' + String(item.icon || '') + ' ' + String(item.attribute || ''));
    });

    if (!available.length) { return ''; }

    var html = '<details class="action-menu"><summary class="action-menu-trigger" aria-label="'
      + escapeHtml(labelText || 'Actions') + '" title="' + escapeHtml(labelText || 'Actions') + '">'
      + '<span aria-hidden="true">&#8942;</span></summary><div class="action-menu-panel">';

    available.forEach(function (item) {
      var attribute = /^data-[a-z0-9-]+$/.test(item.attribute || '') ? item.attribute : 'data-action-item';
      var icon = ACTION_ICONS[item.icon] || ACTION_ICONS.view;
      var danger = item.danger ? ' danger' : '';
      // Colour by action so the menu reads at a glance (approve green, edit
      // blue, view light blue, ...). Do not combine with `danger`: its hover
      // rule is more specific and would win.
      var tone = item.tone && /^[a-z0-9-]+$/.test(item.tone) ? ' action-menu-item--' + item.tone : '';

      html += '<button type="button" class="action-menu-item' + danger + tone + '" '
        + attribute + '="' + escapeHtml(item.value === undefined ? '' : item.value) + '">'
        + '<span class="action-menu-icon" aria-hidden="true">' + icon + '</span>'
        + '<span>' + escapeHtml(item.label || 'Action') + '</span></button>';
    });

    return html + '</div></details>';
  }

  function enhanceTables(root) {
    var scope = root && typeof root.querySelectorAll === 'function' ? root : document;
    var tables = [];
    if (scope.matches && scope.matches('table')) { tables.push(scope); }
    Array.prototype.push.apply(tables, scope.querySelectorAll('table'));

    tables.forEach(function (table) {
      table.classList.add('data-table');
      var bodyRows = table.querySelectorAll('tbody tr');
      Array.prototype.forEach.call(bodyRows, function (row) {
        var cells = row.querySelectorAll('td');
        Array.prototype.forEach.call(cells, function (cell) {
          var text = (cell.textContent || '').trim();
          if (!text && !cell.children.length) {
            var placeholder = document.createElement('span');
            placeholder.className = 'cell-empty';
            placeholder.textContent = '\u2014';
            cell.appendChild(placeholder);
            text = '\u2014';
          }
          var numeric = cell.classList.contains('number') || cell.classList.contains('money') || /^(?:PHP\s*)?-?[\d,]+(?:\.\d+)?(?:\s*%)?$/.test(text);
          if (numeric) {
            cell.classList.add('cell-number');
          } else if (text.length > 42) {
            cell.classList.add('cell-truncate');
            if (!cell.title) { cell.title = text; }
          }
          if (cell.querySelector('.action-menu')) { cell.classList.add('cell-actions'); }
        });
      });

      var headers = table.querySelectorAll('thead th');
      Array.prototype.forEach.call(headers, function (header, index) {
        var columnCells = table.querySelectorAll('tbody tr td:nth-child(' + (index + 1) + ')');
        var values = Array.prototype.filter.call(columnCells, function (cell) { return !cell.classList.contains('cell-actions') && (cell.textContent || '').trim() !== '\u2014'; });
        var numericCount = values.filter(function (cell) { return cell.classList.contains('cell-number'); }).length;
        if (values.length && numericCount === values.length) { header.classList.add('cell-number'); }
      });
    });
  }

  function savedSidebarCollapsed() {
    try { return localStorage.getItem('pms_sidebar_collapsed') === '1'; } catch (error) { return false; }
  }

  function isDesktopViewport() {
    if (typeof window.matchMedia === 'function') { return window.matchMedia('(min-width: 901px)').matches; }
    return Number(window.innerWidth || 1024) >= 901;
  }

  function applySidebarPreference() {
    if (!document.body || !document.body.classList) { return; }
    var desktop = isDesktopViewport();
    document.body.classList.toggle('sidebar-collapsed', desktop && savedSidebarCollapsed());
    if (desktop) { document.body.classList.remove('nav-open'); }
  }

  applySidebarPreference();

  var ICON_EYE =
    '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"'
    + ' stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">'
    + '<path d="M1 12s4-7 11-7 11 7 11 7-4 7-11 7-11-7-11-7z"/><circle cx="12" cy="12" r="3"/>'
    + '</svg>';

  var ICON_EYE_OFF =
    '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"'
    + ' stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">'
    + '<path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94"/>'
    + '<path d="M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19"/>'
    + '<path d="M14.12 14.12a3 3 0 1 1-4.24-4.24"/><line x1="1" y1="1" x2="23" y2="23"/>'
    + '</svg>';

  var NAV_ICONS = {
    users: '<svg viewBox="0 0 24 24"><circle cx="9" cy="8" r="3"/><path d="M3 20v-2c0-3 3-5 6-5s6 2 6 5v2M17 9h5M19.5 6.5v5"/></svg>',
    dashboard: '<svg viewBox="0 0 24 24"><rect x="3" y="3" width="7" height="7" rx="2"/><rect x="14" y="3" width="7" height="7" rx="2"/><rect x="3" y="14" width="7" height="7" rx="2"/><rect x="14" y="14" width="7" height="7" rx="2"/></svg>',
    employees: '<svg viewBox="0 0 24 24"><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75"/></svg>',
    attendance: '<svg viewBox="0 0 24 24"><rect x="3" y="4" width="18" height="18" rx="2"/><path d="M16 2v4M8 2v4M3 10h18M8 15l2 2 5-5"/></svg>',
    scanner: '<svg viewBox="0 0 24 24"><path d="M3 7V4a1 1 0 0 1 1-1h3M17 3h3a1 1 0 0 1 1 1v3M21 17v3a1 1 0 0 1-1 1h-3M7 21H4a1 1 0 0 1-1-1v-3M7 8h3v3H7zM14 8h3v3h-3zM7 14h3v3H7zM14 14h3v3h-3z"/></svg>',
    leave: '<svg viewBox="0 0 24 24"><path d="M20.8 4.6c-5.5-.8-10.5 1-13.2 4.7-2.1 2.9-2.3 6.5-2.3 9.7M4 21c2.4-5.1 6.5-9 12-11.5"/><path d="M20.8 4.6c.4 5.3-1.5 9.4-5.3 11.2-2.8 1.3-6 .7-8.1-.4"/></svg>',
    overtime: '<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2M19 5l2-2"/></svg>',
    payroll: '<svg viewBox="0 0 24 24"><rect x="3" y="5" width="18" height="14" rx="2"/><path d="M3 10h18M7 15h2M13 15h4"/></svg>',
    thirteenth: '<svg viewBox="0 0 24 24"><rect x="3" y="5" width="18" height="14" rx="2"/><path d="M3 10h18M7 15h2M13 15h4"/></svg>',
    payslips: '<svg viewBox="0 0 24 24"><path d="M6 2h9l4 4v16H6zM14 2v5h5M9 12h7M9 16h7"/></svg>',
    payments: '<svg viewBox="0 0 24 24"><rect x="2" y="6" width="20" height="12" rx="2"/><circle cx="12" cy="12" r="2.5"/><path d="M6 12h.01M18 12h.01"/></svg>',
    loans: '<svg viewBox="0 0 24 24"><path d="M12 2v20M17 6H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/></svg>',
    'my-qr': '<svg viewBox="0 0 24 24"><path d="M3 3h7v7H3zM14 3h7v7h-7zM3 14h7v7H3zM14 14h3v3h-3zM19 14h2v7h-7v-2"/></svg>',
    adjustments: '<svg viewBox="0 0 24 24"><path d="M4 6h16M4 12h10M4 18h8M16 14l4 4M20 14l-4 4"/></svg>',
    deductions: '<svg viewBox="0 0 24 24"><path d="M4 4h16v16H4zM8 9h8M8 13h8M8 17h5"/></svg>',
    reports: '<svg viewBox="0 0 24 24"><path d="M4 20V10M10 20V4M16 20v-7M22 20H2"/></svg>',
    settings: '<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="3"/><path d="M19 15l2 2-4 4-2-2M9 4L7 2 3 6l2 2M4 15l-2 2 4 4 2-2M15 4l2-2 4 4-2 2M12 2v3M12 19v3M2 12h3M19 12h3"/></svg>'
  };

  // --- SweetAlert2 bridge (Phase 21) ----------------------------------------
  //
  // Every notice, confirmation and prompt in the application goes through
  // these helpers, so the look is identical on all pages and for every role.
  // They degrade to the previous behaviour when the library is not loaded.

  function sweetAlertAvailable() {
    return typeof global.Swal !== 'undefined' && typeof global.Swal.fire === 'function';
  }

  function sweetIcon(type) {
    switch (type) {
      case 'success': return 'success';
      case 'error':   return 'error';
      case 'warning': return 'warning';
      default:        return 'info';
    }
  }

  function sweetTitle(type) {
    switch (type) {
      case 'success': return 'Success';
      case 'error':   return 'Something went wrong';
      case 'warning': return 'Please note';
      default:        return 'Notice';
    }
  }

  function sweetTimer(type) {
    switch (type) {
      case 'error':   return 6000;
      case 'warning': return 4500;
      default:        return 2600;
    }
  }

  function legacyNotice(message, type) {
    var container = document.querySelector('[data-notices]');

    // Pages without the notice strip (the sign-in page) would otherwise lose
    // the message entirely, so degrade to a real alert rather than silence.
    if (!container) {
      global.alert(message);
      return;
    }

    var el = document.createElement('div');
    el.className = 'notice notice-' + (type || 'info');
    el.textContent = message;

    var close = document.createElement('button');
    close.type = 'button';
    close.className = 'notice-close';
    close.textContent = '\u00d7';
    close.addEventListener('click', function () { el.remove(); });

    el.appendChild(close);
    container.appendChild(el);

    setTimeout(function () { el.remove(); }, 8000);
  }

  /**
   * Refresh the sidebar notification badges.
   *
   * The personal pending-overtime badge is informational: how many assigned
   * OT sessions are awaiting HR authorization (no employee response gate).
   * The count comes from the existing OT API (GET /overtime?status=PENDING),
   * which scopes callers without overtime.view to their own employee record on
   * the server, so the browser only ever sees the signed-in user's own number —
   * never another employee's. Admin announces OT (overtime.create) and renders
   * no badge element, so no request is made for that role.
   *
   * The badge drops when HR authorizes or rejects the assignment; employee
   * acknowledgement is not required and does not change this count.
   *
   * Informational by design — a failed count must never break the page.
   *
   * @return {Promise<number>} the count shown (0 when hidden or unreachable)
   */
  function refreshNavBadges() {
    // No badge element (Admin, or a role without the Overtime link) → no call.
    var badge = document.querySelector('[data-nav-badge]');
    if (!badge) { return Promise.resolve(0); }

    if (typeof Api === 'undefined' || typeof Api.get !== 'function') {
      return Promise.resolve(0);
    }

    // Defence in depth: an announcer must never see a personal pending count.
    if (App.can('overtime.create')) {
      badge.hidden = true;
      badge.textContent = '';
      return Promise.resolve(0);
    }

    // per_page=1 keeps the rows small; the count itself is meta.pagination.total.
    return Api.get('/overtime', { status: 'PENDING', per_page: 1 }).then(function (response) {
      var meta = response && response.meta && response.meta.pagination;
      var count = Math.max(0, parseInt(meta && meta.total_records, 10) || 0);

      badge.textContent = count > 0 ? String(count) : '';
      badge.hidden = count === 0;
      return count;
    }).catch(function () {
      badge.hidden = true;
      badge.textContent = '';
      return 0;
    });
  }

  /**
   * Where an account holding an administrator-issued temporary password must
   * go before it can do anything else.
   *
   * Kept relative, the way every other page link in the frontend is: each page
   * declares a <base> pointing at the frontend folder, so this resolves both
   * from dashboard.html and from a page inside a subfolder.
   */
  var FORCED_PASSWORD_CHANGE_URL = 'change-password/index.html';

  /** True while the account still has to replace an administrator reset password. */
  function isForcedPasswordChange() {
    var user = Api.user();
    return !!(user && user.must_change_password === true);
  }

  var App = {
    escapeHtml: escapeHtml,
    formatMoney: formatMoney,
    formatNumber: formatNumber,
    formatDate: formatDate,
    formatTime: formatTime,
    formatLateMinutes: formatLateMinutes,
    label: label,
    statusClass: statusClass,
    isSampleData: isSampleData,
    sampleBadge: sampleBadge,
    actionMenu: actionMenu,
    enhanceTables: enhanceTables,
    applyBranding: applyBranding,
    loadBranding: loadBranding,
    refreshNavBadges: refreshNavBadges,

    /** The signed-in user, or null when the session has expired. */
    user: function () {
      return Api.user();
    },

    /** Can the current user act? Hides unauthorised actions (Phase 20). */
    can: function (permission) {
      var user = Api.user();
      if (!user) { return false; }

      var permissions = user.permissions || [];

      return permissions.indexOf('*') !== -1 || permissions.indexOf(permission) !== -1;
    },

    canAny: function (permissions) {
      for (var i = 0; i < permissions.length; i++) {
        if (App.can(permissions[i])) { return true; }
      }

      return false;
    },

    /**
     * Redirect to the sign-in page when there is no valid session, or to the
     * Change Password page while an administrator reset is outstanding.
     *
     * The redirect is a convenience, not the guard itself: while
     * must_change_password is set the API refuses every endpoint but the change
     * flow, so opening a page directly cannot get around the forced step.
     */
    guard: function () {
      if (!Api.token() || !Api.user()) {
        window.location.replace(Api.loginUrl());
        return false;
      }

      if (isForcedPasswordChange()) {
        window.location.replace(FORCED_PASSWORD_CHANGE_URL);
        return false;
      }

      // A manually typed page URL must not expose another role's workspace.
      var path = (window.location.pathname.split('/frontend/')[1] || '').replace(/^\//, '');
      var role = (Api.user() || {}).role;
      var access = {
        'employees/index.html': ['HR_PAYROLL'],
        'team/index.html': ['MANAGER'],
        'users/index.html': ['ADMIN'],
        'attendance/index.html': ['HR_PAYROLL','MANAGER','STAFF'],
        'attendance/scanner.html': ['KIOSK'],
        'profile/my-qr.html': ['STAFF'],
        'leave/index.html': ['HR_PAYROLL','MANAGER','STAFF'],
        'overtime/index.html': ['HR_PAYROLL','MANAGER','STAFF'],
        'payroll/index.html': ['HR_PAYROLL'],
        'payroll/adjustments.html': ['HR_PAYROLL'],
        'payroll/reviewer.html': ['MANAGER'],
        'loans/remittances.html': ['HR_PAYROLL'],
        'payroll/deductions.html': ['HR_PAYROLL'],
        'payroll/thirteenth.html': ['HR_PAYROLL'],
        'payroll/payments.html': ['HR_PAYROLL'],
        'payroll/payslips.html': ['STAFF'],
        'loans/index.html': ['HR_PAYROLL','STAFF'],
        'reports/index.html': ['HR_PAYROLL'],
        'settings/index.html': ['ADMIN']
      };
      if (role !== 'STAFF' && new URLSearchParams(location.search).get('mine') === '1') {
        window.location.replace(new URL('dashboard.html', document.baseURI).href);
        return false;
      }
      if (role === 'MANAGER' && path === 'loans/index.html') {
        window.location.replace(new URL('dashboard.html', document.baseURI).href);
        return false;
      }
      if (role === 'KIOSK' && path !== 'attendance/scanner.html' && path !== 'change-password/index.html') {
        window.location.replace(new URL('attendance/scanner.html', document.baseURI).href);
        return false;
      }
      if (/\/archive\.html$/.test(path) || (access[path] && access[path].indexOf(role) === -1)) {
        window.location.replace(new URL('dashboard.html', document.baseURI).href);
        return false;
      }
      return true;
    },

    /** Render the sidebar navigation, hiding links the role cannot use. */
    renderNav: function (activePage) {
      var nav = document.querySelector('[data-nav]');
      if (!nav) { return; }

      var role = (App.user() || {}).role;
      var items = [
        { section: 'Workspace', page: 'dashboard', href: 'dashboard.html', label: 'Dashboard', roles: ['ADMIN','HR_PAYROLL','MANAGER','STAFF'] },
        { section: 'Administration', page: 'users', href: 'users/index.html', label: 'User Accounts', roles: ['ADMIN'] },
                { section: 'HR & Payroll', page: 'employees', href: 'employees/index.html', label: 'Employees & Salaries', roles: ['HR_PAYROLL'] },
        { section: 'My Team', page: 'team', href: 'team/index.html', label: 'My Team', roles: ['MANAGER'] },
        { section: 'Time & Leave', page: 'attendance', href: 'attendance/index.html', label: 'Attendance', roles: ['HR_PAYROLL','MANAGER','STAFF'] },





        { section: 'Time & Leave', page: 'leave', href: 'leave/index.html', label: 'Leave', roles: ['HR_PAYROLL','MANAGER','STAFF'] },
        { section: 'Time & Leave', page: 'overtime', href: 'overtime/index.html', label: 'Overtime', roles: ['HR_PAYROLL','MANAGER','STAFF'] },
        { section: 'Time & Leave', page: 'my-qr', href: 'profile/my-qr.html', label: 'My QR', roles: ['STAFF'] },
        { section: 'Payroll', page: 'payroll', href: 'payroll/index.html', label: 'Payroll Processing', roles: ['HR_PAYROLL'] },
        { section: 'Payroll', page: 'adjustments', href: 'payroll/adjustments.html', label: 'Payroll Adjustments', roles: ['HR_PAYROLL'] },
        { section: 'My Team', page: 'reviewer', href: 'payroll/reviewer.html', label: 'HR Personal Reviewer', roles: ['MANAGER'] },
        { section: 'Payroll', page: 'deductions', href: 'payroll/deductions.html', label: 'Authorized Deductions', roles: ['HR_PAYROLL'] },
        { section: 'Payroll', page: 'thirteenth', href: 'payroll/thirteenth.html', label: '13th Month', roles: ['HR_PAYROLL'] },
        // Salary payment ledger is opened from Payroll Processing after finalization.

        { section: 'Payroll', page: 'loans', href: 'loans/index.html', label: 'Loan Management', roles: ['HR_PAYROLL'] },

        // Agency loan remittance ledger retained in the DB; separate module retired.
        { section: 'Payroll', page: 'payslips', href: 'payroll/payslips.html', label: 'My Payslips', roles: ['STAFF'] },
        { section: 'Payroll', page: 'my-loans', href: 'loans/index.html', label: 'My Loans', roles: ['STAFF'] },
        { section: 'Insights', page: 'reports', href: 'reports/index.html', label: 'Payroll Reports', roles: ['HR_PAYROLL'] }
      ];
      // Stable sidebar grouping: personal employee self-service is separate from management.
      var sectionOrder=['Workspace','Administration','HR & Payroll','My Team','Time & Leave','Payroll','Insights','My Personal'];
      items.sort(function(a,b){return sectionOrder.indexOf(a.section)-sectionOrder.indexOf(b.section);});
      if (role === 'STAFF' && activePage === 'loans') { activePage = 'my-loans'; }
      if (role !== 'STAFF' && new URLSearchParams(location.search).get('mine') === '1') {
        activePage = '__personal'; // no management item is highlighted in self-service mode
      }
      var html = '';
      var lastSection = '';

      items.forEach(function (item) {
        if (item.roles.indexOf(role) === -1) { return; }
        if (item.page === 'reviewer' && role === 'MANAGER' && !(Api.user() || {}).is_hr_reviewer) { return; }

        if (item.section !== lastSection) {
          html += '<div class="nav-section">' + escapeHtml(item.section) + '</div>';
          lastSection = item.section;
        }

        var linkLabel = item.label;
        var classes = 'nav-link' + (item.page === activePage ? ' active' : '');

        var newTab = item.page === 'scanner' ? ' target="_blank" rel="noopener"' : '';

        // Personal pending badge (the unanswered-OT queue): only for users who
        // cannot announce OT themselves — Admin never renders one. It sits inside
        // the label span so the collapsed sidebar still hides label and badge
        // together as one last child.
        var badge = item.badge && !App.can('overtime.create')
          ? '<span class="nav-badge" data-nav-badge="' + item.badge + '" hidden></span>'
          : '';

        html += '<a class="' + classes + '" href="' + item.href + '" title="' + escapeHtml(linkLabel) + '"' + newTab + '>'
             +  '<span class="nav-icon">' + (NAV_ICONS[item.page] || NAV_ICONS.settings) + '</span>'
             +  '<span>' + escapeHtml(linkLabel) + badge + '</span>'
             +  '</a>';
      });

      nav.innerHTML = html || '<div class="nav-empty">No modules are assigned to this account. Ask an administrator to review the role.</div>';

      // Fire and forget: a slow or failed count must never delay the sidebar.
      refreshNavBadges();
    },

    renderHeader: function () {
      var header = document.querySelector('[data-header]');
      if (!header) { return; }

      var user = Api.user();
      if (!user) { return; }

      var title = document.title.split(/[—-]/)[0].trim();
      var initials = String(user.full_name || user.username || 'U').split(/\s+/).map(function (part) {
        return part.charAt(0);
      }).join('').slice(0, 2).toUpperCase();
      var settingsLink = App.can('settings.manage')
        ? '<a class="account-menu-item" href="settings/index.html"><span aria-hidden="true">&#9881;</span><span>Settings</span></a>'
        : '';

      // Operator accounts have management tools only, not personal time/payroll links.
      var personalLinks = '';

      header.innerHTML =
          '<div class="header-leading">'
        +   '<button type="button" class="mobile-menu" data-menu aria-label="Toggle navigation" aria-expanded="true"><span></span><span></span><span></span></button>'
        +   '<div><div class="header-eyebrow">Attendance &amp; Payroll</div><div class="header-title">' + escapeHtml(title) + '</div></div>'
        + '</div>'
        + '<div class="header-user">'
        +   '<div class="account-menu">'
        +     '<button type="button" class="account-menu-toggle" data-account-toggle aria-haspopup="menu" aria-expanded="false">'
        +       '<span class="user-avatar">' + escapeHtml(initials) + '</span>'
        +       '<span class="header-meta"><span class="header-name">' + escapeHtml(user.full_name) + '</span><span class="header-role">' + escapeHtml(user.role_name || App.label(user.role)) + '</span></span>'
        +       '<span class="account-chevron" aria-hidden="true">&#8964;</span>'
        +     '</button>'
        +     '<div class="account-menu-panel" data-account-panel role="menu" hidden>'
        +       '<div class="account-menu-identity"><strong>' + escapeHtml(user.full_name) + '</strong><span>' + escapeHtml(user.email || user.username) + '</span></div>'
        +       '<a class="account-menu-item" href="profile/index.html"><span aria-hidden="true">&#9786;</span><span>My Profile</span></a>'
        +       personalLinks
        +       settingsLink
        +       '<button type="button" class="account-menu-item danger" data-signout><span aria-hidden="true">&#10162;</span><span>Sign out</span></button>'
        +     '</div>'
        +   '</div>'
        + '</div>';

      var menu = header.querySelector('[data-menu]');
      var sidebar = document.querySelector('.sidebar');
      if (menu && sidebar) {
        function updateMenuState() {
          var desktop = isDesktopViewport();
          menu.setAttribute('aria-expanded', desktop
            ? (document.body.classList.contains('sidebar-collapsed') ? 'false' : 'true')
            : (document.body.classList.contains('nav-open') ? 'true' : 'false'));
          menu.setAttribute('aria-label', desktop
            ? (document.body.classList.contains('sidebar-collapsed') ? 'Expand navigation' : 'Collapse navigation')
            : (document.body.classList.contains('nav-open') ? 'Close navigation' : 'Open navigation'));
        }

        menu.addEventListener('click', function () {
          if (!isDesktopViewport()) {
            document.body.classList.toggle('nav-open');
          } else {
            var collapsed = document.body.classList.toggle('sidebar-collapsed');
            try { localStorage.setItem('pms_sidebar_collapsed', collapsed ? '1' : '0'); } catch (error) { /* storage may be disabled */ }
          }
          updateMenuState();
        });

        sidebar.addEventListener('click', function (event) {
          if (event.target.closest('.nav-link') && !isDesktopViewport()) {
            document.body.classList.remove('nav-open');
            updateMenuState();
          }
        });
        window.addEventListener('resize', function () { applySidebarPreference(); updateMenuState(); });
        updateMenuState();
      }

      var accountToggle = header.querySelector('[data-account-toggle]');
      var accountPanel = header.querySelector('[data-account-panel]');
      var accountMenu = header.querySelector('.account-menu');
      var signOut = header.querySelector('[data-signout]');

      function closeAccountMenu() {
        accountPanel.hidden = true;
        accountToggle.setAttribute('aria-expanded', 'false');
      }

      accountToggle.addEventListener('click', function () {
        var opening = accountPanel.hidden;
        accountPanel.hidden = !opening;
        accountToggle.setAttribute('aria-expanded', opening ? 'true' : 'false');
      });
      document.addEventListener('click', function (event) {
        if (!accountMenu.contains(event.target)) { closeAccountMenu(); }
      });
      document.addEventListener('keydown', function (event) {
        if (event.key === 'Escape') { closeAccountMenu(); }
      });

      if (signOut) {
        signOut.addEventListener('click', async function () {
          try {
            await Api.post('/auth/logout');
          } catch (error) {
            // The session may already be gone; clear it regardless.
          }

          Api.clearSession();
          window.location.replace(Api.loginUrl());
        });
      }
    },

    /**
     * Show a dismissible notice — a SweetAlert2 toast (Phase 21).
     *
     * The signature is unchanged, so every existing App.notify() call across
     * the pages now renders through SweetAlert2 without being touched. When
     * the library is unavailable the original in-page notice is used instead,
     * so a missing asset can never break a page (the same "never break"
     * rule the axios -> fetch fallback follows).
     */
    notify: function (message, type) {
      if (!sweetAlertAvailable()) {
        return legacyNotice(message, type);
      }

      global.Swal.fire({
        toast: true,
        position: 'top-end',
        icon: sweetIcon(type),
        title: escapeHtml(message),
        showConfirmButton: false,
        timer: sweetTimer(type),
        timerProgressBar: true,
        // Toasts have no backdrop, so allowOutsideClick is not a valid option
        // here (SweetAlert warns if it is set) — a toast never blocks anyway.
        didOpen: function (el) {
          el.addEventListener('mouseenter', global.Swal.stopTimer);
          el.addEventListener('mouseleave', global.Swal.resumeTimer);
        },
      });
    },

    /**
     * Ask a yes/no question. Resolves true when confirmed.
     *
     * Replaces window.confirm(), which cannot be styled and blocks the page.
     * Callers must be async: `if (!await App.confirm('...')) { return; }`
     */
    confirm: function (message, options) {
      options = options || {};

      if (!sweetAlertAvailable()) {
        return Promise.resolve(global.confirm(message));
      }

      var config = {
        title: options.title || 'Please confirm',
        text: escapeHtml(message),
        icon: options.icon || 'warning',
        showCancelButton: true,
        confirmButtonText: options.confirmText || 'Yes, continue',
        cancelButtonText: options.cancelText || 'Cancel',
        reverseButtons: true,
        focusCancel: true,
        returnFocus: true,
        backdrop: true,
        allowOutsideClick: false,
        allowEnterKey: true,
      };

      if (options.danger) {
        config.confirmButtonColor = '#dc2626';
        config.denyButtonColor = '#dc2626';
      } else {
        config.confirmButtonColor = '#2563eb';
      }

      return global.Swal.fire(config).then(function (result) {
        return result.isConfirmed === true;
      });
    },

    /**
     * Ask for a single line of text. Resolves the string, or null if cancelled.
     *
     * Replaces window.prompt().
     */
    prompt: function (message, options) {
      options = options || {};

      if (!sweetAlertAvailable()) {
        return Promise.resolve(global.prompt(message));
      }

      return global.Swal.fire({
        title: options.title || 'Your input',
        input: 'text',
        inputLabel: escapeHtml(message),
        inputValue: options.value || '',
        inputPlaceholder: options.placeholder || '',
        showCancelButton: true,
        confirmButtonText: options.confirmText || 'OK',
        cancelButtonText: options.cancelText || 'Cancel',
        confirmButtonColor: '#2563eb',
        reverseButtons: true,
        returnFocus: true,
        inputValidator: function (value) {
          if (options.required && !String(value === undefined || value === null ? '' : value).trim()) {
            return options.requiredMessage || 'This field is required.';
          }
          return undefined;
        },
      }).then(function (result) {
        if (result.isConfirmed !== true) { return null; }
        return result.value === undefined || result.value === null ? '' : String(result.value);
      });
    },

    /**
     * Show a blocking message the user has to acknowledge.
     *
     * Used where a toast would be too easy to miss (fatal errors, results the
     * user must read in full, such as an issued QR token or a password).
     */
    alert: function (message, title, type) {
      if (!sweetAlertAvailable()) {
        global.alert(message);
        return Promise.resolve();
      }

      return global.Swal.fire({
        title: title || sweetTitle(type),
        html: escapeHtml(message),
        icon: sweetIcon(type),
        confirmButtonText: 'OK',
        confirmButtonColor: '#2563eb',
        returnFocus: true,
      });
    },
    formValues: function (form) {
      var data = {};
      var elements = form.elements;

      for (var i = 0; i < elements.length; i++) {
        var field = elements[i];
        if (!field.name || field.disabled) { continue; }

        if (field.type === 'checkbox') {
          data[field.name] = field.checked;
        } else if (field.type === 'radio') {
          if (field.checked) { data[field.name] = field.value; }
        } else {
          data[field.name] = field.value;
        }
      }

      return data;
    },

    fillSelect: function (select, items, valueKey, labelKey, placeholder) {
      if (!select) { return; }

      // Build <option> nodes with DOM methods instead of an HTML string, so no
      // value ever reaches the page through innerHTML. The rendered markup and
      // selected values are unchanged.
      while (select.firstChild) {
        select.removeChild(select.firstChild);
      }

      if (placeholder !== undefined) {
        var placeholderOption = document.createElement('option');
        placeholderOption.value = '';
        placeholderOption.textContent = escapeHtml(placeholder);
        select.add(placeholderOption);
      }

      Array.prototype.forEach.call(items || [], function (item) {
        if (!item) { return; }

        var option = document.createElement('option');
        option.value = escapeHtml(item[valueKey]);
        option.textContent = escapeHtml(item[labelKey]);
        select.add(option);
      });
    },

    loading: function (container) {
      if (!container) { return; }

      while (container.firstChild) {
        container.removeChild(container.firstChild);
      }

      var spinner = document.createElement('div');
      spinner.className = 'table-loading';
      spinner.textContent = 'Loading\u2026';
      container.appendChild(spinner);
    },

    emptyState: function (container, message) {
      if (!container) { return; }

      while (container.firstChild) {
        container.removeChild(container.firstChild);
      }

      var empty = document.createElement('div');
      empty.className = 'table-empty';
      empty.textContent = escapeHtml(message);
      container.appendChild(empty);
    },

    applyPermissions: function () {
      var nodes = document.querySelectorAll('[data-permission]');

      for (var i = 0; i < nodes.length; i++) {
        var node    = nodes[i];
        var needed  = node.getAttribute('data-permission').split(',');
        var allowed = App.canAny(needed);

        node.style.display = allowed ? '' : 'none';
      }
    },

    /**
     * Add a show/hide eye to every password field inside `root`.
     *
     * Runs automatically once the page is ready, so a plain
     * <input type="password"> needs no extra markup — the sign-in page gets its
     * toggle for free. Dialogs that build their form after load can call this
     * again with the container they just filled.
     *
     * Safe to call twice on the same container: already-wrapped fields are
     * skipped.
     */
    enhancePasswordFields: function (root) {
      var scope = root || document;

      if (!scope || typeof scope.querySelectorAll !== 'function') { return; }

      var inputs = scope.querySelectorAll('input[type="password"]');

      Array.prototype.forEach.call(inputs, function (input) {
        if (input.getAttribute('data-password-toggle') === 'done') { return; }
        if (!input.parentNode) { return; }

        // Wrap the input so the button can sit on top of its right-hand edge.
        var wrapper = document.createElement('span');
        wrapper.className = 'password-field';

        input.parentNode.insertBefore(wrapper, input);
        wrapper.appendChild(input);

        var button = document.createElement('button');
        button.type = 'button';
        button.className = 'password-toggle';
        button.innerHTML = ICON_EYE;

        function describe(visible) {
          var text = visible ? 'Hide password' : 'Show password';

          button.setAttribute('aria-label', text);
          button.setAttribute('aria-pressed', visible ? 'true' : 'false');
          button.title = text;
        }

        describe(false);

        button.addEventListener('click', function () {
          var reveal = input.type === 'password';

          input.type        = reveal ? 'text' : 'password';
          button.innerHTML  = reveal ? ICON_EYE_OFF : ICON_EYE;

          describe(reveal);

          // Put the caret back where the user left it so they can keep typing.
          try {
            var end = input.value.length;

            input.focus();

            if (typeof input.setSelectionRange === 'function') {
              input.setSelectionRange(end, end);
            }
          } catch (error) {
            // Some input types do not support selection; focus alone is enough.
          }
        });

        wrapper.appendChild(button);

        input.setAttribute('data-password-toggle', 'done');
      });
    },
  };

  global.App = App;

  if (document.querySelector('.brand-logo, .login-logo')) {
    App.loadBranding();
  }

  function positionActionMenu(menu) {
    if (!menu || !menu.open) { return; }

    var trigger = menu.querySelector('.action-menu-trigger');
    var panel = menu.querySelector('.action-menu-panel');
    if (!trigger || !panel) { return; }

    panel.classList.add('action-menu-floating');
    panel.style.visibility = 'hidden';
    panel.style.top = '0px';
    panel.style.left = '0px';

    var triggerRect = trigger.getBoundingClientRect();
    var panelWidth = panel.offsetWidth;
    var panelHeight = panel.offsetHeight;
    var edge = 8;
    var left = Math.max(edge, Math.min(triggerRect.right - panelWidth, window.innerWidth - panelWidth - edge));
    var top = triggerRect.bottom + 6;

    if (top + panelHeight > window.innerHeight - edge) {
      top = Math.max(edge, triggerRect.top - panelHeight - 6);
    }

    panel.style.left = Math.round(left) + 'px';
    panel.style.top = Math.round(top) + 'px';
    panel.style.visibility = 'visible';
  }

  function repositionOpenActionMenus() {
    var menus = document.querySelectorAll('.action-menu[open]');
    Array.prototype.forEach.call(menus, positionActionMenu);
  }

  document.addEventListener('toggle', function (event) {
    var menu = event.target;
    if (!menu.classList || !menu.classList.contains('action-menu')) { return; }

    if (menu.open) {
      window.requestAnimationFrame(function () { positionActionMenu(menu); });
    } else {
      var panel = menu.querySelector('.action-menu-panel');
      if (panel) {
        panel.classList.remove('action-menu-floating');
        panel.removeAttribute('style');
      }
    }
  }, true);

  if (typeof window.addEventListener === 'function') {
    window.addEventListener('resize', repositionOpenActionMenus);
  }
  document.addEventListener('scroll', repositionOpenActionMenus, true);

  document.addEventListener('click', function (event) {
    var activeMenu = event.target.closest && event.target.closest('.action-menu');
    var menus = document.querySelectorAll('.action-menu[open]');

    Array.prototype.forEach.call(menus, function (menu) {
      if (menu !== activeMenu || (event.target.closest && event.target.closest('.action-menu-item'))) {
        menu.removeAttribute('open');
      }
    });
  });

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', function () {
      App.enhancePasswordFields();
      enhanceTables(document);
    });
  } else {
    App.enhancePasswordFields();
    enhanceTables(document);
  }

  if (typeof MutationObserver !== 'undefined' && document.documentElement) {
    var tableEnhancePending = false;
    new MutationObserver(function (mutations) {
      var needsEnhancement = mutations.some(function (mutation) {
        return Array.prototype.some.call(mutation.addedNodes || [], function (node) {
          return node.nodeType === 1 && ((node.matches && node.matches('table, tbody, tr, td')) || (node.querySelector && node.querySelector('table')));
        });
      });
      if (!needsEnhancement || tableEnhancePending) { return; }
      tableEnhancePending = true;
      window.requestAnimationFrame(function () { tableEnhancePending = false; enhanceTables(document); });
    }).observe(document.documentElement, { childList: true, subtree: true });
  }
})(window);
