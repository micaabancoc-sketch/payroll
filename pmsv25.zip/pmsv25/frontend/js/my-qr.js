(function () {
  'use strict';
  if (!App.guard()) { return; }
  App.renderNav('my-qr');
  App.renderHeader();
  var nameEl = document.getElementById('my-qr-employee');
  var statusEl = document.getElementById('my-qr-status');
  var imageEl = document.getElementById('my-qr-image');
  var actions = document.getElementById('my-qr-actions');
  var qrMarkup = '';
  var employeeName = 'My Attendance QR';

  async function load() {
    try {
      var profile = (await Api.get('/auth/me')).data || {};
      var employeeId = Number(profile.employee_id || 0);
      employeeName = profile.full_name || profile.username || employeeName;
      nameEl.textContent = employeeName + (profile.employee_number ? ' · ' + profile.employee_number : '');
      if (!employeeId || !App.can('profile.view_own')) {
        statusEl.textContent = 'This account has no authorized employee QR code.';
        return;
      }
      // The QR endpoint enforces employee ownership on the PHP server.
      qrMarkup = await Api.qrSvg(employeeId);
      imageEl.innerHTML = qrMarkup;
      actions.hidden = false;
      try {
        var qr = (await Api.get('/qr/active/' + employeeId)).data || {};
        statusEl.textContent = 'Issued ' + App.formatDate(qr.issued_at) + ' · ' + Number(qr.scan_count || 0) + ' scan(s)';
      } catch (error) {
        statusEl.textContent = 'Your QR code is active. Show it at the attendance station.';
      }
    } catch (error) {
      actions.hidden = true;
      imageEl.textContent = '';
      statusEl.textContent = 'Your QR code could not be loaded. Ask an administrator to check your issued code.';
    }
  }

  document.getElementById('my-qr-download').addEventListener('click', function () {
    if (!qrMarkup) { return; }
    var url = URL.createObjectURL(new Blob([qrMarkup], {type: 'image/svg+xml;charset=utf-8'}));
    var link = document.createElement('a');
    link.href = url;
    link.download = employeeName.replace(/[^\w.-]+/g, '-') + '-qr.svg';
    document.body.appendChild(link);
    link.click();
    link.remove();
    URL.revokeObjectURL(url);
  });
  document.getElementById('my-qr-print').addEventListener('click', function () {
    if (!qrMarkup) { return; }
    var win = window.open('', '_blank', 'width=420,height=560');
    if (!win) { App.notify('Allow pop-ups to print your QR code.', 'warning'); return; }
    win.document.write('<!DOCTYPE html><html><head><meta charset="UTF-8"><title>My attendance QR</title>'
      + '<style>body{font-family:Segoe UI,sans-serif;text-align:center;padding:24px}svg{width:280px;height:280px}</style>'
      + '</head><body><h3>' + App.escapeHtml(employeeName) + '</h3>' + qrMarkup
      + '<p>Personal attendance QR code</p></body></html>');
    win.document.close(); win.focus(); win.print();
  });
  load();
})();
