export const TYPE_COLORS = [
  '#7c3aed', '#2563eb', '#0891b2', '#16a34a',
  '#d97706', '#dc2626', '#db2777', '#4f46e5',
];

export const HOLIDAY_COLOR = '#b45309';

export function colorFor(name) {
  const text = String(name || '?');
  let hash = 0;
  for (let i = 0; i < text.length; i++) {
    hash = ((hash * 31) + text.charCodeAt(i)) >>> 0;
  }
  return TYPE_COLORS[hash % TYPE_COLORS.length];
}

export function hexA(hex, alpha) {
  const v = String(hex || '').replace('#', '');
  if (!/^[0-9a-f]{6}$/i.test(v)) {
    return hex;
  }
  return 'rgba(' + parseInt(v.slice(0, 2), 16) + ',' + parseInt(v.slice(2, 4), 16) + ','
    + parseInt(v.slice(4, 6), 16) + ',' + alpha + ')';
}

export function isoOfDate(date) {
  return date.getFullYear() + '-'
    + String(date.getMonth() + 1).padStart(2, '0') + '-'
    + String(date.getDate()).padStart(2, '0');
}

export function addDays(date, n) {
  return new Date(date.getFullYear(), date.getMonth(), date.getDate() + n);
}

export function expandRange(startIso, endIso, maxDays = 62) {
  const [sy, sm, sd] = String(startIso).slice(0, 10).split('-').map(Number);
  const [ey, em, ed] = String(endIso).slice(0, 10).split('-').map(Number);
  const end = new Date(ey, em - 1, ed);
  const days = [];
  for (let cur = new Date(sy, sm - 1, sd), guard = 0; cur <= end && guard < maxDays; cur = addDays(cur, 1), guard++) {
    days.push(isoOfDate(cur));
  }
  return days;
}

export class LeaveCalendarStore {
  constructor(api) {
    this.api = api;
    this.events = [];
    this.holidays = [];
  }

  async fetchRequests(fromIso, toIso, maxPages = 5) {
    const rows = [];
    let page = 1;
    let hasNext = true;
    while (hasNext && page <= maxPages) {
      const resp = await this.api.get('/leave', {
        date_from: fromIso, date_to: toIso, per_page: 100, page,
      });
      rows.push(...(resp.data || []));
      hasNext = Boolean(resp.meta?.pagination?.has_next);
      page++;
    }
    return rows;
  }

  async fetchHolidays() {
    try {
      return (await this.api.get('/holidays')).data || [];
    } catch (error) {
      return [];
    }
  }

  async loadRange(fetchFrom, fetchTo, visStart, visEnd) {
    const [rows, holidays] = await Promise.all([
      this.fetchRequests(fetchFrom, fetchTo),
      this.fetchHolidays(),
    ]);

    this.events = rows
      .map((row) => ({
        request: row,
        dates: expandRange(row.start_date, row.end_date)
          .filter((d) => d >= visStart && d <= visEnd),
      }))
      .filter((entry) => entry.dates.length > 0);

    const years = [...new Set(
      expandRange(visStart, visEnd).map((d) => d.slice(0, 4)),
    )];

    this.holidays = holidays.flatMap((h) => {
      const base = String(h.holiday_date || '').slice(0, 10);
      if (!base) {
        return [];
      }
      if (Number(h.is_recurring) === 1) {
        return years
          .map((yy) => yy + base.slice(4))
          .filter((projected) => projected >= visStart && projected <= visEnd)
          .map((projected) => ({ date: projected, name: h.name }));
      }
      return base >= visStart && base <= visEnd ? [{ date: base, name: h.name }] : [];
    });

    return { events: this.events, holidays: this.holidays };
  }

  eventsOn(dateIso, off = {}) {
    return this.events.filter(
      (e) => e.dates.includes(dateIso) && !off[e.request.leave_type_name || 'Leave'],
    );
  }

  holidaysOn(dateIso, showHolidays = true) {
    if (!showHolidays) {
      return [];
    }
    return this.holidays.filter((h) => h.date === dateIso);
  }

  groupByType(dateIso, off = {}) {
    const groups = this.eventsOn(dateIso, off).reduce((acc, e) => {
      const key = e.request.leave_type_name || 'Leave';
      acc[key] = acc[key] || { name: key, count: 0, color: colorFor(key) };
      acc[key].count += 1;
      return acc;
    }, {});
    return Object.values(groups).sort((a, b) => b.count - a.count);
  }

  countByType() {
    return this.events.reduce((acc, e) => {
      const key = e.request.leave_type_name || 'Leave';
      acc[key] = (acc[key] || 0) + e.dates.length;
      return acc;
    }, {});
  }
}
