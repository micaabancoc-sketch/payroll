(function (global) {
  'use strict';

  function defaultBase() {
    var path = window.location.pathname;
    var marker = '/frontend/';
    var idx = path.indexOf(marker);

    if (idx !== -1) {
      return path.slice(0, idx + marker.length - 1).replace(/\/$/, '') + '/../api';
    }

    return path.replace(/[^/]*$/, '') + 'api';
  }

  var API_BASE = (window.PMS_API_BASE || defaultBase()).replace(/\/+$/, '');

  var TOKEN_KEY = 'pms_token';
  var USER_KEY  = 'pms_user';

  /**
   * The sign-in page.
   *
   * It is the index.html sitting at the application root, one level above the
   * frontend folder. Every frontend page declares <base> pointing at that
   * folder, so '../' always resolves to the root — whichever page is asking and
   * whichever path the project is deployed under.
   */
  var LOGIN_URL = '../';

  function token() {
    return localStorage.getItem(TOKEN_KEY);
  }

  function currentUser() {
    try {
      return JSON.parse(localStorage.getItem(USER_KEY) || 'null');
    } catch (error) {
      return null;
    }
  }

  function setSession(tokenValue, user) {
    localStorage.setItem(TOKEN_KEY, tokenValue);
    localStorage.setItem(USER_KEY, JSON.stringify(user));
  }

  function clearSession() {
    localStorage.removeItem(TOKEN_KEY);
    localStorage.removeItem(USER_KEY);
  }

  function redirectToLogin() {
    window.location.replace(LOGIN_URL);
  }

  /**
   * React to a 401 from the API.
   *
   * A 401 only means "your session expired" when a token was actually sent.
   * Rejected credentials on the sign-in page also return 401, and bouncing
   * those to the login page just reloads the form and swallows the reason the
   * sign-in failed — so only an existing session is cleared and redirected.
   */
  function handleUnauthorized() {
    if (!token()) { return; }

    clearSession();
    redirectToLogin();
  }

  async function toError(response) {
    var payload = null;

    try {
      payload = await response.json();
    } catch (error) {
      payload = null;
    }

    if (response.status === 401) {
      handleUnauthorized();
      return new Error('Your session has expired. Please sign in again.');
    }

    var message = (payload && payload.message) || ('Request failed with status ' + response.status);
    var error   = new Error(message);

    error.status  = response.status;
    error.errors  = (payload && payload.errors) || null;
    if (error.errors) {
      var detail = Object.keys(error.errors).map(function (key) { return key + ': ' + error.errors[key]; }).join('; ');
      if (detail) { error.message = detail; }
    }
    error.payload = payload;

    return error;
  }

  function buildUrl(path, query) {
    var url = API_BASE + (path.charAt(0) === '/' ? path : '/' + path);

    if (query) {
      var params = new URLSearchParams();

      Object.keys(query).forEach(function (key) {
        var value = query[key];
        if (value !== undefined && value !== null && value !== '') {
          params.append(key, value);
        }
      });

      var qs = params.toString();
      if (qs) {
        url += (url.indexOf('?') === -1 ? '?' : '&') + qs;
      }
    }

    return url;
  }

  function buildPayload(body, headers) {
    if (body !== undefined && body !== null && !(body instanceof FormData)) {
      headers['Content-Type'] = 'application/json';
      return JSON.stringify(body);
    }

    if (body instanceof FormData) {
      return body;
    }

    return undefined;
  }

  function buildHeaders(body, options) {
    var headers = { 'Accept': 'application/json' };
    var payload = buildPayload(body, headers);

    var auth = token();
    if (auth) {
      headers['Authorization'] = 'Bearer ' + auth;
    }

    if (options.deviceId) {
      headers['X-Device-Id'] = options.deviceId;
    }

    return { headers: headers, payload: payload };
  }

  /** Normalise a failure into a readable Error (sync twin of toError). */
  function httpError(status, text) {
    var payload = null;

    try {
      payload = text ? JSON.parse(text) : null;
    } catch (parseError) {
      payload = null;
    }

    if (status === 401) {
      handleUnauthorized();
      return new Error('Your session has expired. Please sign in again.');
    }

    var message = (payload && payload.message) || ('Request failed with status ' + status);
    var error   = new Error(message);

    error.status  = status;
    error.errors  = (payload && payload.errors) || null;
    if (error.errors) { var msg = Object.keys(error.errors).map(function (field) { return field + ': ' + error.errors[field]; }).join('; '); if (msg) { error.message = msg; } }
    error.payload = payload;

    return error;
  }

  /**
   * Axios transport (primary): `await`ed HTTP with identical semantics to
   * the fetch transport below. `validateStatus: () => true` keeps every
   * status on the resolved path so branching matches fetch line-for-line;
   * only true network failures reject (mapped to the same message).
   */
  async function requestViaAxios(method, url, parts, options) {
    var response;

    try {
      response = await axios({
        method:           method,
        url:              url,
        headers:          parts.headers,
        data:             parts.payload,
        responseType:     'text',
        transformRequest: [function (data) { return data; }],
        validateStatus:   function () { return true; },
      });
    } catch (networkError) {
      throw new Error('Cannot reach the API server. Is it running?');
    }

    var status = response.status;
    var text = response.data === undefined || response.data === null ? '' : String(response.data);
    var responseHeaders = response.headers || {};
    var contentType = responseHeaders['content-type'] || responseHeaders['Content-Type'] || '';

    // A 204 has no body to parse.
    if (status === 204) {
      return { success: true, message: '', data: null };
    }

    // Raw responses (e.g. a QR image) are returned as text.
    if (options.raw) {
      if (status < 200 || status >= 300) {
        throw httpError(status, text);
      }

      return text;
    }

    if (contentType.indexOf('application/json') === -1) {
      if (status < 200 || status >= 300) {
        throw httpError(status, text);
      }

      return { success: true, message: '', data: null };
    }

    var json = text ? JSON.parse(text) : null;

    if (status < 200 || status >= 300) {
      var error = new Error((json && json.message) || 'Request failed');
      error.status  = status;
      error.errors  = (json && json.errors) || null;
      if (error.errors) { var msg = Object.keys(error.errors).map(function (field) { return field + ': ' + error.errors[field]; }).join('; '); if (msg) { error.message = msg; } }
      error.payload = json;

      if (status === 401) {
        handleUnauthorized();
      }

      throw error;
    }

    return json;
  }

  /** Fetch transport (fallback): the original implementation, untouched. */
  async function requestViaFetch(method, url, parts, options) {
    var response;

    try {
      response = await fetch(url, {
        method:  method,
        headers: parts.headers,
        body:    parts.payload,
      });
    } catch (networkError) {
      throw new Error('Cannot reach the API server. Is it running?');
    }

    // A 204 has no body to parse.
    if (response.status === 204) {
      return { success: true, message: '', data: null };
    }

    var contentType = response.headers.get('content-type') || '';

    // Raw responses (e.g. a QR image) are returned as text.
    if (options.raw) {
      if (!response.ok) {
        throw await toError(response);
      }

      return response.text();
    }

    if (contentType.indexOf('application/json') === -1) {
      if (!response.ok) {
        throw await toError(response);
      }

      return { success: true, message: '', data: null };
    }

    var json = await response.json();

    if (!response.ok) {
      var error = new Error(json.message || 'Request failed');
      error.status  = response.status;
      error.errors  = json.errors || null;
      if (error.errors) { var msg = Object.keys(error.errors).map(function (field) { return field + ': ' + error.errors[field]; }).join('; '); if (msg) { error.message = msg; } }
      error.payload = json;

      if (response.status === 401) {
        handleUnauthorized();
      }

      throw error;
    }

    return json;
  }

  async function request(method, path, body, options) {
    options = options || {};

    var url   = buildUrl(path, options.query);
    var parts = buildHeaders(body, options);

    // Axios does the HTTP when its script loaded; otherwise the fetch
    // fallback answers identically, so the app never breaks.
    if (typeof axios !== 'undefined') {
      return requestViaAxios(method, url, parts, options);
    }

    return requestViaFetch(method, url, parts, options);
  }

  var Api = {
    base:        function () { return API_BASE; },
    token:       token,
    user:        currentUser,
    setSession:  setSession,
    clearSession: clearSession,

    loginUrl:    function () { return LOGIN_URL; },

    get:    function (path, query, options)   { return request('GET', path, undefined, Object.assign({ query: query }, options || {})); },
    post:   function (path, body, options)    { return request('POST', path, body, options); },
    put:    function (path, body, options)    { return request('PUT', path, body, options); },
    patch:  function (path, body, options)    { return request('PATCH', path, body, options); },
    delete: function (path, options)          { return request('DELETE', path, undefined, options); },

    csvUrl: function (path, query) {
      var params = new URLSearchParams();

      Object.keys(query || {}).forEach(function (key) {
        var value = query[key];
        if (value !== undefined && value !== null && value !== '') {
          params.append(key, value);
        }
      });

      params.append('format', 'csv');

      var qs = params.toString();

      return API_BASE + (path.charAt(0) === '/' ? path : '/' + path) + (qs ? '?' + qs : '');
    },

    /** Download an authenticated CSV without putting the bearer token in a URL. */
    downloadCsv: async function (path, query, filename) {
      var params = Object.assign({}, query || {}, { format: 'csv' });
      var text = await request('GET', path, undefined, { query: params, raw: true });
      var blob = new Blob([text], { type: 'text/csv;charset=utf-8' });
      var url = URL.createObjectURL(blob);
      var link = document.createElement('a');
      link.href = url;
      link.download = filename || 'report.csv';
      document.body.appendChild(link);
      link.click();
      link.remove();
      URL.revokeObjectURL(url);
    },

    /**
     * Fetch a QR image as SVG markup.
     *
     * An <img src> cannot carry the bearer token, so the SVG is downloaded
     * with the normal authenticated request and inlined into the page.
     */
    qrSvg: async function (employeeId) {
      return request('GET', '/qr/svg/' + employeeId, null, { raw: true });
    },
  };

  global.Api = Api;
})(window);
