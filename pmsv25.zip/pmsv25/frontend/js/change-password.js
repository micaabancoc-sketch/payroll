/**
 * Forced password change.
 *
 * An administrator password reset signs the account in with the shared
 * temporary password and flags it (must_change_password). Until that password
 * is replaced the API refuses every other endpoint, so this page is the only
 * place a reset account can go: App.guard() sends it here from every other
 * page, and the sign-in page forwards to it after a reset login.
 */
(function () {
  'use strict';

  // App.guard() is deliberately not used here: this is exactly the page that
  // guard sends a flagged account to, so calling it would bounce in a loop.
  // The session is validated directly instead.
  if (!Api.token() || !Api.user()) {
    window.location.replace(Api.loginUrl());
    return;
  }

  if (!Api.user().must_change_password) {
    window.location.replace((Api.user() || {}).role === 'KIOSK' ? 'attendance/scanner.html' : 'dashboard.html');
    return;
  }

  App.enhancePasswordFields(document);

  var form = document.getElementById('change-password-form');
  var button = document.getElementById('change-password-btn');
  var errorEl = document.getElementById('change-password-error');
  var signOut = document.getElementById('change-password-signout');
  var accountLabel = document.getElementById('change-password-user');
  var user = Api.user();

  accountLabel.textContent = 'Signed in as '
    + (user.full_name || user.username || user.email || 'you');

  function showError(message) {
    errorEl.textContent = message;
    errorEl.hidden = false;
  }

  form.addEventListener('submit', async function (event) {
    event.preventDefault();
    errorEl.hidden = true;

    if (!form.reportValidity()) {
      return;
    }

    var newPassword = document.getElementById('new-password').value;
    var confirmPassword = document.getElementById('confirm-password').value;

    if (newPassword !== confirmPassword) {
      showError('The new password and its confirmation do not match.');
      return;
    }

    button.disabled = true;
    button.textContent = 'Updating...';

    try {
      var response = await Api.post('/auth/change-password', {
        current_password: document.getElementById('current-password').value,
        new_password: newPassword,
        confirm_password: confirmPassword
      });

      // The endpoint revokes every other session and issues a fresh token, and
      // clears must_change_password. Storing the new token with an updated flag
      // means App.guard() will not bounce the user straight back here.
      var updated = Object.assign({}, Api.user(), { must_change_password: false });
      Api.setSession(response.data.token, updated);

      await App.alert(
        'Your password has been changed. You can now use the system.',
        'Password updated',
        'success'
      );
      window.location.replace((Api.user() || {}).role === 'KIOSK' ? 'attendance/scanner.html' : 'dashboard.html');
    } catch (error) {
      showError(error.message || 'Unable to change your password. Please try again.');
      button.disabled = false;
      button.textContent = 'Update password';
    }
  });

  signOut.addEventListener('click', async function () {
    try {
      await Api.post('/auth/logout');
    } catch (error) {
      // The session may already be gone; clear it regardless.
    }

    Api.clearSession();
    window.location.replace(Api.loginUrl());
  });
})();