(function () {
  'use strict';

  if (!App.guard()) { return; }
  App.renderNav('profile');
  App.renderHeader();
  App.enhancePasswordFields(document);

  var currentProfile = null;
  var profileForm = document.getElementById('profile-form');
  var editButton = document.getElementById('edit-profile');
  var closeButton = document.getElementById('close-profile-edit');
  var saveButton = document.getElementById('save-profile');
  var editActions = document.getElementById('profile-edit-actions');
  var editCard = document.querySelector('.profile-edit-card');
  var editError = document.getElementById('profile-edit-error');

  var fields = {
    username: document.getElementById('profile-field-username'),
    email: document.getElementById('profile-field-email'),
    full_name: document.getElementById('profile-field-full-name'),
    first_name: document.getElementById('profile-field-first-name'),
    middle_name: document.getElementById('profile-field-middle-name'),
    last_name: document.getElementById('profile-field-last-name'),
    suffix: document.getElementById('profile-field-suffix'),
    contact_number: document.getElementById('profile-field-contact'),
    birth_date: document.getElementById('profile-field-birth-date'),
    gender: document.getElementById('profile-field-gender'),
    address: document.getElementById('profile-field-address')
  };

  function initials(name) {
    return String(name || 'U').split(/\s+/).filter(Boolean).map(function (part) {
      return part.charAt(0);
    }).join('').slice(0, 2).toUpperCase();
  }

  function valueOrEmpty(value) {
    return value === null || value === undefined ? '' : String(value);
  }

  function showRelevantFields(profile) {
    var hasEmployee = profile.employee_id !== null && profile.employee_id !== undefined;
    document.querySelectorAll('[data-employee-field]').forEach(function (element) {
      element.hidden = !hasEmployee;
    });
    document.querySelectorAll('[data-account-name]').forEach(function (element) {
      element.hidden = hasEmployee;
    });
    fields.first_name.required = hasEmployee;
    fields.gender.required = hasEmployee;
    fields.full_name.required = !hasEmployee;
  }

  function fillProfile(profile) {
    currentProfile = profile;
    showRelevantFields(profile);
    Object.keys(fields).forEach(function (key) {
      fields[key].value = valueOrEmpty(profile[key]);
    });
    if (!fields.gender.value) { fields.gender.value = 'OTHER'; }

    document.getElementById('profile-avatar').textContent = initials(profile.full_name || profile.username);
    document.getElementById('profile-name').textContent = profile.full_name || profile.username;
    document.getElementById('profile-role').textContent = profile.role_name || App.label(profile.role);
    document.getElementById('profile-username').textContent = profile.username || '\u2014';

    document.getElementById('profile-employee-number').textContent = profile.employee_number || '\u2014';
    document.getElementById('profile-email').textContent = profile.email || '\u2014';
    document.getElementById('profile-role-detail').textContent = profile.role_name || App.label(profile.role);
    document.getElementById('profile-last-login').textContent = profile.last_login_at
      ? App.formatDate(profile.last_login_at) + ' ' + App.formatTime(profile.last_login_at)
      : '\u2014';
  }

  function setEditing(editing) {
    Object.keys(fields).forEach(function (key) {
      var wrapper = fields[key].closest('.profile-field');
      fields[key].disabled = !editing || Boolean(wrapper && wrapper.hidden);
    });
    editButton.hidden = editing;
    editActions.hidden = !editing;
    editCard.classList.toggle('is-editing', editing);
    editError.hidden = true;
    editError.textContent = '';
    if (editing) { fields.username.focus(); }
  }

  /* ------------------------------------------------------------ QR code */
  // View, download and print your own attendance code. Issuing a code is an
  // administrator action and is deliberately not offered here.
  var qrCard    = document.getElementById('profile-qr-card');
  var qrImage   = document.getElementById('profile-qr-image');
  var qrStatus  = document.getElementById('profile-qr-status');
  var qrActions = document.getElementById('profile-qr-actions');
  var qrSvgText = '';

  async function loadQr() {
    if (!qrCard) { return; }

    var employeeId = currentProfile && currentProfile.employee_id;

    if (!employeeId || (App.user() || {}).role !== 'STAFF') {
      // Operator accounts retain their employee data, but cannot show a usable attendance badge.
      qrCard.hidden = true;
      return;
    }

    qrCard.hidden = false;
    qrStatus.textContent = 'Loading your QR code…';

    try {
      qrSvgText = await Api.qrSvg(employeeId);
      qrImage.innerHTML = qrSvgText;
      qrActions.hidden = false;

      try {
        var code = (await Api.get('/qr/active/' + employeeId)).data;
        qrStatus.textContent = 'Issued ' + App.formatDate(code.issued_at) + ' · ' + (code.scan_count || 0) + ' scan(s)';
      } catch (error) {
        qrStatus.textContent = 'Your QR code is active. Show it at the scanner.';
      }
    } catch (error) {
      qrImage.innerHTML = '';
      qrActions.hidden = true;
      qrStatus.textContent = 'No QR code has been issued for you yet. Ask an administrator to generate one.';
    }
  }

  document.getElementById('profile-qr-download').addEventListener('click', function () {
    if (!qrSvgText) { return; }

    var blob = new Blob([qrSvgText], { type: 'image/svg+xml;charset=utf-8' });
    var url = URL.createObjectURL(blob);
    var link = document.createElement('a');
    var name = (currentProfile && currentProfile.full_name) || 'attendance-qr';

    link.href = url;
    link.download = String(name).replace(/[^\w.-]+/g, '-') + '-qr.svg';
    document.body.appendChild(link);
    link.click();
    link.remove();
    URL.revokeObjectURL(url);
  });

  document.getElementById('profile-qr-print').addEventListener('click', function () {
    if (!qrSvgText) { return; }

    var name = (currentProfile && currentProfile.full_name) || 'My attendance QR';
    var win = window.open('', '_blank', 'width=420,height=560');

    if (!win) {
      App.notify('Allow pop-ups to print your QR code.', 'warning');
      return;
    }

    win.document.write(
      '<html><head><title>' + App.escapeHtml(name) + ' — attendance QR</title>'
      + '<style>body{font-family:Segoe UI,sans-serif;text-align:center;padding:24px}'
      + '#qr{width:280px;height:280px;margin:16px auto}h3{margin:0 0 4px}</style></head><body>'
      + '<h3>' + App.escapeHtml(name) + '</h3>'
      + '<div id="qr">' + qrSvgText + '</div>'
      + '<p>Scan this code to record attendance.</p>'
      + '</body></html>'
    );

    win.document.close();
    win.focus();
    win.print();
  });

  async function loadProfile() {
    try {
      var data = (await Api.get('/auth/me')).data;
      Api.setSession(Api.token(), data);
      currentProfile = data;
      fillProfile(data);
      setEditing(false);
      loadQr();
    } catch (error) {
      App.notify(error.message, 'error');
    }
  }

  editButton.addEventListener('click', function () {
    setEditing(true);
  });

  closeButton.addEventListener('click', function () {
    if (currentProfile) { fillProfile(currentProfile); }
    setEditing(false);
  });

  profileForm.addEventListener('submit', async function (event) {
    event.preventDefault();
    if (!currentProfile || !profileForm.reportValidity()) { return; }

    var payload = {
      username: fields.username.value.trim(),
      email: fields.email.value.trim() || null
    };
    var hasEmployee = currentProfile.employee_id !== null && currentProfile.employee_id !== undefined;
    if (hasEmployee) {
      payload.first_name = fields.first_name.value.trim();
      payload.middle_name = fields.middle_name.value.trim() || null;
      payload.last_name = fields.last_name.value.trim() || null;
      payload.suffix = fields.suffix.value.trim() || null;
      payload.contact_number = fields.contact_number.value.trim() || null;
      payload.birth_date = fields.birth_date.value || null;
      payload.gender = fields.gender.value;
      payload.address = fields.address.value.trim() || null;
    } else {
      payload.full_name = fields.full_name.value.trim();
    }

    editError.hidden = true;
    saveButton.disabled = true;
    saveButton.textContent = 'Saving...';
    try {
      var updated = (await Api.put('/auth/profile', payload)).data;
      Api.setSession(Api.token(), updated);
      fillProfile(updated);
      setEditing(false);
      App.renderHeader();
      App.notify('Profile updated successfully.', 'success');
    } catch (error) {
      editError.textContent = error.message;
      editError.hidden = false;
    } finally {
      saveButton.disabled = false;
      saveButton.textContent = 'Save changes';
    }
  });

  document.getElementById('password-form').addEventListener('submit', async function (event) {
    event.preventDefault();
    var button = document.getElementById('change-password');
    var errorEl = document.getElementById('profile-error');
    errorEl.hidden = true;
    button.disabled = true;
    button.textContent = 'Updating...';

    try {
      var response = await Api.post('/auth/change-password', {
        current_password: document.getElementById('current-password').value,
        new_password: document.getElementById('new-password').value,
        confirm_password: document.getElementById('confirm-password').value
      });
      Api.setSession(response.data.token, Api.user());
      event.target.reset();
      App.notify('Password updated successfully.', 'success');
    } catch (error) {
      errorEl.textContent = error.message;
      errorEl.hidden = false;
    } finally {
      button.disabled = false;
      button.textContent = 'Update password';
    }
  });

  loadProfile();
})();
