# Code Patterns Map — Async, Class, Functional Array Ops, Module System

Where each pattern lives in this codebase (`file:line`, verified 2026-10-02).
Line numbers may drift as the code evolves; search the symbol name if a
number looks stale.

## 0. Axios, Await & Shared PDO Connection (added 2026-10-02)

| What | File | Line(s) |
|---|---|---|
| Vendored Axios UMD build (v1.12.2, loaded before `api.js` on every page) | `frontend/js/vendor/axios.min.js` | 1–2 (bundle) |
| Axios transport: `await`ed HTTP, same semantics as fetch | `frontend/js/api.js` | 178 (`async function requestViaAxios`) |
| Fetch fallback transport (original, untouched) | `frontend/js/api.js` | 242 (`async function requestViaFetch`) |
| Transport picker: axios when loaded, fetch otherwise | `frontend/js/api.js` | 298–312 (`async function request`) |
| Shared URL / headers / payload builders used by both transports | `frontend/js/api.js` | 95 (`buildUrl`), 117 (`buildPayload`), 130 (`buildHeaders`) |
| Sync error normalizer (twin of `toError`) | `frontend/js/api.js` | 147 (`httpError`) |
| `await` at every call site (unchanged public `Api` interface) | `frontend/*/index.html`, `frontend/*/*.html` | e.g. `await Api.get(…)` throughout |
| Shared PDO factory (`pdo_connection()` singleton) | `api/config/connection-pdo.php` | 22 (`function pdo_connection`) |
| `Database` delegating to the shared factory | `api/core/Database.php` | 31 (`connection()`), 43 (`require_once …/connection-pdo.php`) |

## 1. Module system (ES Modules + PHP autoloader)

| What | File | Line(s) |
|---|---|---|
| ES module: calendar data layer (`import` / `export`) | `frontend/js/modules/leave-calendar-store.js` | 1–14 (docblock), 15, 20, 23, 33, 43, 50, 55, 72 |
| ES module consumed via dynamic `import()` | `frontend/leave/index.html` | 920–921 |
| `LeaveCalendarStore` instantiated from the module namespace | `frontend/leave/index.html` | 921 (`new ns.LeaveCalendarStore(Api)`) |
| PHP module system: PSR-4 style autoloader (`App\Core\X` → `api/core/X.php`) | `api/bootstrap.php` | 23 |
| Classic-script namespacing (pre-module pattern): `App`, `Api`, `Charts` globals | `frontend/js/app.js`, `frontend/js/api.js`, `frontend/js/charts.js` | app.js:576 (`global.App = App`), api.js:249 (`global.Api = Api`), charts.js:271–276 |

## 2. Class

| What | File | Line(s) |
|---|---|---|
| `LeaveCalendarStore` (frontend ES class: constructor + methods) | `frontend/js/modules/leave-calendar-store.js` | 72–179 (class), 75–79 (constructor) |
| Service classes (backend) | `api/services/LeaveService.php` | 25 (`final class LeaveService`) |
| Service classes (backend) | `api/services/EmployeeService.php` | 24 (`final class EmployeeService`) |
| Controller classes (backend) | `api/controllers/LeaveController.php` | 16 (`final class LeaveController`) |
| Auth/token session class (backend) | `api/core/Auth.php` | 13 (`final class Auth`) |

## 3. Async (`async` / `await`)

| What | File | Line(s) |
|---|---|---|
| `LeaveCalendarStore.fetchRequests` — paged `await` loop | `frontend/js/modules/leave-calendar-store.js` | 81–95 |
| `LeaveCalendarStore.fetchHolidays` — `await` with fallback | `frontend/js/modules/leave-calendar-store.js` | 97–104 |
| `LeaveCalendarStore.loadRange` — parallel `await Promise.all` | `frontend/js/modules/leave-calendar-store.js` | 109–112 |
| Module bootstrap promise + `ensureCal()` gate | `frontend/leave/index.html` | 920–929 |
| Calendar loader awaiting the store | `frontend/leave/index.html` | 992 (`await ensureCal()`), 1017 (`await calStore.loadRange(…)`) |
| Central API client (`async request`, fetch + normalize) | `frontend/js/api.js` | 94 |
| Existing page-level `async` loaders (example) | `frontend/attendance/index.html` | 119 (`async function load()`), 227 (`async function saveAttendance()`) |

## 4. Functional array operations (`map` / `filter` / `reduce` / `flatMap`)

| What | File | Line(s) |
|---|---|---|
| `expandRange` input parsing (`.map(Number)`) | `frontend/js/modules/leave-calendar-store.js` | 56–57 |
| `loadRange` event pipeline (`.map` + `.filter`) | `frontend/js/modules/leave-calendar-store.js` | 117–122 |
| Visible-year set (`.map`) | `frontend/js/modules/leave-calendar-store.js` | 125 |
| Holiday projection (`.flatMap` + `.map` + `.filter` + `.map`) | `frontend/js/modules/leave-calendar-store.js` | 129–138 |
| `eventsOn` / `holidaysOn` (`.filter`) | `frontend/js/modules/leave-calendar-store.js` | 148, 158 |
| `groupByType` / `countByType` (`.reduce`) | `frontend/js/modules/leave-calendar-store.js` | 163, 174 |
| Existing dashboard transforms (`.map`) | `frontend/js/dashboard.js` | 198, 203–204 |
| Existing PHP functional style (`array_map`, `array_filter`) | `api/services/EmployeeService.php` | 946 (`array_filter`), 988 (`array_map` in `fullName`) |

## 5. This turn's attendance features (bonus map)

| What | File | Line(s) |
|---|---|---|
| Seed defaults: 8AM / 5PM / 20-min auto-OT | `database/main.sql` | 761–763 |
| Live-DB seed of the same keys | (script, temp) `migrate_attendance_defaults.php` | — |
| Public API exposure (`/settings/public`) | `api/controllers/SettingsController.php` | `publicKeys()` allow-list |
| Time-picker rendering + ordering in Settings UI | `frontend/settings/index.html` | `TIME_SETTINGS` list, `SETTING_ORDER` entries |
| Manual-entry form prefilled 8AM / 5PM | `frontend/attendance/index.html` | 260–267 (fetch), 302–303 (defaults) |
| New-shift form prefilled 8AM / 5PM | `frontend/settings/index.html` | `publicDefaults()`, `openShiftForm()` |
| Auto-OT threshold read + regular-day rule | `api/services/AttendanceEngine.php` | 166, 207–208 |
| Auto-OT threshold for rest-day / holiday work | `api/services/AttendanceEngine.php` | 222 |
