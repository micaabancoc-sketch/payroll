# PMS V16 Integrated candidate status

Code changes integrated into the user's original V14 source. Static PHP syntax and embedded JS syntax verified. Existing role-route smoke test passed. MariaDB end-to-end runs were **not available** in this environment.

See V16_INSTALL_AND_TEST_GUIDE.txt for tested coverage, explicit limitations, and non-destructive installation instructions.

Important: The uploaded real database dump was used **only** to compare the schema; it is NOT included in this ZIP. Historic employee and payroll data remain only in the user's MySQL database and backups.
