# PMS V21 — Full Payroll Roster + No-Backdated Payroll Periods (TEST BUILD)

## Changes from V20

1. HR/Payroll and Manager **are again normal eligible employees** for Attendance, employee directory, batch exceptions, employee preview, and Calculate All DRAFT. The V20 staff-only role flag now defaults to FALSE. Their login, salary, and historical records are unchanged.
2. Extra sample demo username(s) `demo2` and `test` (in the supplied roster screenshot, `Principal student1` had username `test`) are excluded from the **shared employee list, shared attendance lists, new payroll previews and newly calculated DRAFT batches**. This is an **exact account username match** and does NOT delete or disable an account or erase historical records. If "demo2" is a different username in your actual DB, change `demo.excluded_usernames` accordingly in `api/config/config.php`. To stop ALL demo exclusions, set `DEMO_EXCLUDE_USERNAMES` to an empty string.
3. Since some accounts are temporarily excluded from this TEST batch, API approval, finalization and salary payments remain **blocked until the exclusion is removed and the full eligible roster is recalculated and verified**. This keeps demo estimates from being mistaken for a complete real company payroll.
4. Create Payroll Period is now chronological: new cutoffs whose `end_date` is before today's Manila date are rejected, as are periods whose `start_date` falls on or before the **latest end date of an existing unarchived payroll period**. Existing overlapping cutoff rejection remains. Same rule is enforced in the PHP API, with an early warning/disabled Create button in the UI. Direct API updates that attempt to backdate a DRAFT period are similarly rejected. Existing historical periods and records remain untouched.
5. The Add Period form defaults to the next applicable cutoff and retains the fixed 1–15 / 16–month-end semi-monthly calendar. Viewing the Payroll list no longer silently auto-creates earlier periods.

## Example

If payroll cutoffs are already recorded through **November 30, 2026**, March 1–15, 2026 is rejected even if there is no period in March. December 1–15, 2026 may be added if its end has not already passed and no later cutoff is recorded. If a December cutoff already exists, a new cutoff must come after that December period.

## Safe installation

1. Back up your working V20 folder and database first. Prefer making a clone of `attendance_payroll_v19_test` for testing.
2. Extract the complete ZIP to `C:\xampp\htdocs\pmsv21` (ensure that `api`, `frontend`, and `index.html` are directly inside that directory).
3. The default connection still targets `attendance_payroll_v19_test` (change DB_NAME / `api/config/config.php` if your clone has another name). **Do not connect to a real payroll production database.**
4. **No new SQL tables/columns.** `SAFE_V21_DATABASE_MIGRATION.sql` is a no-op reference; no import necessary.
5. Open `http://localhost/pmsv21/`, log in as HR, and verify HR/Manager are back in Employees & Salaries.
6. In Payroll Processing, select the October 16–31 demo cutoff, click **Calculate All (Save Draft)** *once* to replace old unlocked V20 DRAFT rows with the new scope. Old DRAFT rows may remain visible until recalculated; this is intentional to preserve the existing DB.
7. In **New period**, try selecting March 2026. The form should reject it. Try the next cutoff after the latest existing one; it should be allowed. The API also rejects backdated POST requests.

## Limitations / safeguards

- The extra demo account is **hidden from demo operational lists, not physically deleted**. An old saved DRAFT can still contain that account until you recalculate. Existing finalized/paid histories must not be silently erased.
- If you meant an account other than `demo2` or `test`, change the exact login username in `DEMO_EXCLUDE_USERNAMES`. Do **not** delete employees or payroll rows to hide them.
- To test complete company approval or payment, use a separate restored full-roster test environment, clear the demo exclusion, resolve all attendance/financial exceptions, and recalculate; do not rely on limited-scope DRAFT amounts.
- No live MariaDB or browser integration was available for this build. PHP lint, frontend JavaScript parsing and the seven date-policy tests passed, but live CRUD and approval safeguards must be checked on your XAMPP test instance.
