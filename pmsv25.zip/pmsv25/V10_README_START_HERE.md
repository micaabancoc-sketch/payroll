# Payroll System — V10 RBAC/UI Policy Revision

This ZIP is a revision of the uploaded PMS V9 frontend and API, preserving its existing visual design. It is **not** a production-certified payroll system. Do not reuse seeded accounts/data in a live business.

## Scope applied
- Fixed 4 roles: Admin, HR/Payroll, Manager, Staff. Effective roles are enforced in `api/core/RolePolicy.php` and supplied to the frontend at login, regardless of old DB role JSON.
- Admin: user accounts, organization, schedules, holidays, settings, audit; **not** payroll approval, payout, or other employees' payslips.
- HR: employee/salary, attendance verification, OT authorization, payroll processing, payslips, loans, deductions, remittance/reports.
- Manager: read-only team roster scoped to the manager department, attendance, leave approvals, OT assignment; own payslip only. Managers **cannot** compute or finalize payroll.
- Staff: own records, leave requests, own payslips/loan requests; **no OT request/create/approve button**.
- Archive UI, archived deep-link files, restore, delete and archive APIs removed or disabled. Historical data in old DB is not purged (important for audit).
- Allowance computation disabled in PayrollEngine. Old DB fields remain for backward compatibility; new payroll has no allowance earnings.
- Account management page added at `frontend/users/index.html`.
- HR now owns payroll approval, finalization and disbursement status transitions.
- Only HR/Payroll can manage authorized/custom payroll deductions.
- Admin password resets issue unique random temporary passwords, not the prior shared V9 reset password.

## Important implementation and policy limitations
1. Existing database schema/seed data were **not rebuilt**. Confirm against your installed database before use. Do not import this over real employee data without backing up and performing a controlled migration.
2. Manager team scoping currently means **same department as the manager's linked employee record**, not a custom team roster. Assign one account-linked employee and department per manager.
3. Old V9 reports, leave-type editor, contribution schedule calculation, QR/scanner workflows, payroll engine and loan flows have **not been verified against a live MySQL server**. This archive passed PHP lint and front-end script syntax checks only. Test authorization and payroll outputs before use.
4. The 365-day divisor requires confirmed fully monthly-paid coverage including rest days/holiday rules. Verify the special non-working holiday policy before live payroll; do not hard-code one divisor blindly.
5. Allowances are not emitted by the new payroll engine, but old allowance data/schema can still exist in the legacy database. Treat it as historical, not an available module.
6. Do not make archive records editable or restore their endpoints. Use deactivation/status and auditable adjustments instead of destructive deletion.
7. Overtime is manager-assigned and HR-authorized, but the legacy scan/excess-hours review and pay calculations require end-to-end policy validation before production.
8. Company salary advances and agency loans must be validated against applicable authorization and remittance rules before production.

## Local setup (XAMPP)
1. Extract `pms` under `C:/xampp/htdocs/` (keep a backup of your original V9 project).
2. Start Apache and MySQL in XAMPP, configure `api/config/config.php` and PDO credentials.
3. Visit `http://localhost/pms/` to sign in, using credentials from your **own** local development setup.
4. Test each role's direct URLs, endpoint responses (401/403), and same-department restrictions.
5. Check the backend audit logs and payroll computation with **dummy** employee records before any actual payroll.

## Security checklist
- Verify that admin cannot `POST /api/payroll/periods/{id}/calculate`, finalize or pay.
- Verify manager cannot `GET /api/payroll/periods` or another employee's payslip.
- Verify manager cannot view another department's employees, leave requests, OT or attendance; manager cannot access salary history.
- Verify staff cannot `POST /api/overtime` or accept/decline OT; staff only sees their own payslip and loans.
- Verify archive URLs/REST endpoints are unavailable; restoring old records is intentionally unsupported in UI/API.
- Verify default or test passwords are changed before deployment.

## V10 specific notes for the reviewer
- The original V9 UI theme (HTML/CSS/Bootstrap-like layout) is retained; sidebar navigation is restricted by role, and direct URL access is redirected through `App.guard()`.
- The Manager's `frontend/team/index.html` is a separate, read-only roster; it intentionally does not reuse the HR employee-edit page.
- Admin's User Accounts page supports creating accounts, activating/deactivating them and one-time display of a unique, randomly generated reset password; passwords are not stored in plaintext.
- Old V9 Archive UI is **hidden/disabled** and Archive/API operations removed from route registration. Some legacy inert HTML/JS and database fields remain for compatibility, and should be removed with a reviewed migration rather than blind deletion; no archive screens appear in navigation.
- Staff cannot request OT, accept/decline OT or change OT amounts. HR verification and the Manager->HR assignment flow are now the permitted controller route path. Historic V9 assignment status strings can remain in existing data.
- The original V9 backend has **not** been fully retested against a live database. UI guard by itself is not security: check network requests for each role and audit every remaining API handler before real staff data is entered.
- The older `ensureAccount` fallback no longer creates accounts with a shared known password. If one of these automatically reconciled accounts is needed, Admin must reset its password and communicate the random temporary password securely.
- This release does NOT promise that all salary/OT/holiday/SSS/BIR/PhilHealth/Pag-IBIG rates are correct or current. Confirm policies and effective-dated rules before running real payroll; never use the draft as the company's sole payroll system.
- Smoke test: `php tests/v10_rbac_policy_smoke.php` (no DB needed). Additional XAMPP integration tests are required.
