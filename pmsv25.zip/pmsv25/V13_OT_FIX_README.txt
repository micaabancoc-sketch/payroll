PMS V13 – OVERTIME AUTHORIZATION / PAYROLL VERIFICATION FIX

CAUSE OF ERROR
The old Approve action immediately tried to pay overtime. It required OT QR Time In/Out,
so before OT was performed it returned 422: The given data was invalid.

CORRECT FLOW
1. Manager assigns OT to an employee on the assigned team.
2. HR clicks AUTHORIZE OT ASSIGNMENT (before OT is performed). No money is paid yet.
3. Employee scans Regular Time In and Regular Time Out; on the authorized OT day,
   employee scans OT Time In and OT Time Out on the Kiosk.
4. Manager confirms the actual QR time, except for own OT.
5. HR clicks VERIFY FOR PAYROLL. ONLY now are verified payable hours applied to payroll.
6. Employee sees approved OT in the payroll/payslip after HR processes the cutoff.

EARLY OT SCAN
An authorized assignment starting 5:30 PM accepts OT Time In from 5:00 PM,
but payable work starts no earlier than 5:30 PM. Actual scanned timestamps remain stored.

INSTALL
1. Export/backup MySQL database and backup the existing pmsv3 directory.
2. Extract this ZIP; put its pmsv3 directory under C:\xampp\htdocs\; merge/replace application files.
3. In phpMyAdmin select the EXISTING database and import ONLY:
   pmsv3/database/migrations/20261030_v13_ot_authorization_verification.sql
   Run it ONCE. Do not re-import main.sql.
4. Refresh the overtime page Ctrl+F5 (or log out and back in).
5. Test with Manager and HR accounts and camera in XAMPP. No live DB test was possible here.

SECURITY
Both new actions enforce server-side roles: Manager only assigned-team QR confirmation,
HR only payroll verification, self-confirmation and self-HR-verification disallowed.
This fixes the approval error and OT processing flow; other historical modules and
all statutory computations still require full integration testing before live payroll.

NOTE
Existing previously approved OT rows are not deleted or altered by the migration.

V13 CODE-LEVEL CHECKS
- PHP syntax checked and inline JavaScript syntax checked.
- NO real MySQL / XAMPP integration test performed here.
- The scheduled OT hours remain nonpayable until HR verification applies completed QR time.
- Excess/unusual OT handling and all payroll statutory rules still require complete policy QA.
