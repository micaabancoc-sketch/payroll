# PMS V9 — combined policy fixes and final-defense setup

**Use a copied XAMPP PROJECT AND A BACKED-UP TEST DATABASE.** The fixes change PHP, JavaScript, CSS and MySQL. Editing SQL alone will not update the UI or recalculate old payroll.

## 1. Safe install on a copy of your V8 database

1. Export/backup the current MySQL database in phpMyAdmin; also back up your `htdocs/pms` folder. Do not overwrite the only copy.
2. Create a separate **test database** from your current V8 database backup, and a separate V9 project folder. Verify the PHP configuration (`api/config/config.php`, environment variable `DB_NAME` if set) points to that chosen test database.
3. In phpMyAdmin **select the same test database that V9 is configured to use**, open SQL / Import, and run `database/migrations/20261023_v9_roles_position_salary.sql` **once**. This adds the nullable `positions.base_salary` column; do not rerun the `ALTER TABLE` statement after it succeeds. If the V7 migration was never imported, apply the documented V7 migrations first. **NEVER re-import `database/main.sql` onto an existing/populated database**: it drops/resets tables.
4. Log out and log in to refresh granted permissions. Hard-refresh your browser (Ctrl+Shift+R).
5. Admin: Settings > Organization > Departments/Positions — assign default monthly salaries to departments/positions. Admin > Employees > Add — choose department then position and confirm salary is suggested and editable, Account Role is Staff by default and semi-monthly is fixed. A selected 5-/6-day schedule is saved.
6. Use HR to test Staff creation and loan approval; Manager to approve leave/OT/payroll; Admin to confirm actual loan disbursement and payroll payment.

### September 2026 ONE-EMPLOYEE defense data, in the SAME test DB

1. In phpMyAdmin select your **same test database**. Import `database/SEED_EXISTING_TEST_DB_MAX_DEFENSE.sql` **ONCE**. It deliberately contains NO `CREATE DATABASE`, `USE`, `DROP`, `DELETE`, or `TRUNCATE`. It is additive (skips records with matching Max employee number and dates); it will not reset old attendance. Its required data: seeded `CASH` Department, `CASHIER` Position, `STD-MFS` Mon–Sat schedule, `DAY` Shift, `SL` leave type, `STAFF` role, and `admin` + `manager` account usernames. If any prerequisites don't exist, **do not assume the seed worked**.
2. Immediately run `database/MAX_DEFENSE_VERIFY_READ_ONLY.sql` in the same database. **Expected:** Max (`TEST-SEP26-08`), 13 weekday/Saturday attendance entries, 0 Sunday attendance entries, 1 absence (Sept 5), 20 late minutes (Sept 8), 30 undertime minutes (Sept 10), 1 paid SL (Sept 14), approved 2h OT (Sept 12), and a Sep 1–15 draft period. If the employee already exists under a different code/name, the duplicate-name guard means this seed does not recreate Max; use the existing code or a new clean TEST DB.
3. In V9, Admin > Employees search `Max Test` / `TEST-SEP26-08`; HR/Manager > Attendance filter Sep 1–15, 2026; Manager > Leave Requests/Overtime; HR > Payroll Runs > Sep 1–15 and **calculate a DRAFT** period. **Do not finalize or mark Paid before comparing all pay lines with the manual-defense guide.**
4. Optional demo login `max_sep26` (temporary password `Password123@`), first-login password change required. This is a **fictional demo password**, never for real users.
5. User-visible QR scan count may be zero: the Max ledger was historically **IMPORTED test attendance**, not scanned at a real terminal. Approved leave/OT flags are also mock historical approvals; perform a separate live-role workflow to demonstrate clicking Approve.

### Example reference calculation (NOT a certified result)

- Max basic: PHP 20,000 monthly, PHP 10,000 per complete cutoff.
- Using an *illustrative, arrangement-dependent* annual factor 313 for this six-day unpaid-rest-day example: daily rate `20000*12/313 = 766.773...`, hourly rate `/8`.
- One unpaid absence **−766.77**, late 20 min **−31.95**, undertime 30 min **−47.92**, 2 approved regular-day OT hours (1.25x) **+239.62**, approved paid SL **no deduction**.
- Gross including OT **10,239.62**; after attendance deductions **9,392.98**, **before** official government/loan deductions. Verify all rounding, divisor and historical statutory schedules in your actual database before showing any final net-pay answer. It may change with a different legitimate wage and holiday arrangement. This is a reference check, not proof of production/legal accuracy.
- Government employee contributions use configured, effective-dated SSS, PhilHealth, Pag-IBIG schedules with an equal employee-share split across the two cutoffs; BIR is computed using the applicable tax table, not a blanket 50/50 allocation. Verify the right official schedule is loaded for the pay period.
- 13th-month payout requires *annual eligible earned basic salary history*; September alone is insufficient. Do not seed a fictional complete annual payout based on a single cutoff.

## 2. Automatic absence at 9:01 AM — set up a local scheduled task

The app blocks QR/manual ordinary Time In outside 7:00:00–9:00:59 for an 8 AM shift. To actually create the daily `ABSENT` row **without someone opening the app**, run the local scheduled process at least once a minute on the test server:

`C:\xampp\php\php.exe C:\xampp\htdocs\YOUR_V9_FOLDER\api\cli\attendance_absence_reconciler.php`

In **Windows Task Scheduler**, create a task executing PHP with that PHP-script path as argument, trigger daily with 1-minute repeat interval throughout the attendance window, e.g. 8:55–9:10 AM (prefer continuous once-per-minute within scheduled active hours for other shifts). Set the *Start in* directory if required. Test it manually with `php.exe` and check that the run reports an absence count and does not create duplicate rows on a second run. It must be a scheduled local CLI task, **not an unauthenticated web URL**. Scheduled REST DAY and approved leave are excluded. Managers retain a verified correction route for confirmed actual work.

## 3. What has been updated in V9

- Admin can assign account roles; HR creates STAFF only (also enforced by PHP). Job Position is separate from Account Role. Basic salary suggestions from **Position** override **Department** defaults, but individual salary is editable; employment is full-time and new employee salary is fixed monthly / paid semi-monthly.
- Duplicate employee full-name/username validations, including create serialization, plus existing database-level unique constraints for many other keys. **This is not a proof of universal duplicate-proofing for every table.**
- Fixed 9:01 cutoff on regular QR/manual Time In with scheduled absence reconciliation and manager correction; rest-day ordinary scans disabled; permanent active QR with Admin revocation/regeneration. A valid QR does not override the time cutoff.
- HR offers/approves Company Loan/Salary Advance terms; the employee accepts; **Admin only** can confirm release; repayments cannot start before release. No self-approval/release. Agency SSS/Pag-IBIG loans use agency instructions.
- Required leave attachment uploader (PDF/JPG/PNG up to 2 MB, stored outside frontend; Maternity leave still requires evidence). Correct leave type selection is essential, e.g. VL vs Maternity. Leave duration continues to exclude scheduled rest days/nonchargeable holidays.
- Password-change layout height issue fixed. Employee OT hours summary now reflects **approved** OT rather than old raw recorded OT; it should be `0.00` with no approved OT. Existing historical rows are never blindly deleted.
- Fixed kinsenas basic and automatic period/payday safeguards from V7/V8 remain included; no new arbitrary payroll periods.
- Payroll Adjustments and Deduction Types/Payroll Deductions pages from V7/V8 remain present. Already finalized/paid payroll stays immutable and is not secretly recalculated by installing code.

## 4. Verification status / important limitations

- PHP syntax and JavaScript static regressions tested; database-specific behavior was **not tested in a real XAMPP/MySQL server** here (the test environment has no PHP pdo_mysql driver). Run the included smoke tests and inspect the generated payroll, including holiday/rest-day premiums and the statutory contribution schedules.
- The correct daily/hourly divisor depends on your actual contract, workweek and holiday pay coverage, and must be reviewed before relying on net pay. `313` and `261` are configured illustrative paid-day factors, **not a universal legal guarantee**.
- A passed SQL import doesn't mean data is visible if your browser PHP project is connected to a different database. Check PHP `DB_NAME` and select the same database in phpMyAdmin.
- V9 is a **development/test deliverable**. Do not use for live employee payroll without a verified end-to-end XAMPP run and statutory/holiday/legal review.
