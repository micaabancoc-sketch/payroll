-- OPTIONAL: Fix the specific legacy MANUAL 08:00–17:00 demo rows that display 9h / 9h OT.
-- BACKUP FIRST. ONLY for a cloned TEST database after review. Not part of default migration.
-- Preserve original values in a permanent snapshot before making any changes.
CREATE TABLE IF NOT EXISTS pms_v23_manual_attendance_backup LIKE attendance;
INSERT IGNORE INTO pms_v23_manual_attendance_backup
SELECT a.* FROM attendance a WHERE a.deleted_at IS NULL AND a.source='MANUAL'
 AND TIME(a.time_in)='08:00:00' AND TIME(a.time_out)='17:00:00'
 AND (a.worked_hours>8 OR a.overtime_hours>0)
 AND NOT EXISTS (
   SELECT 1 FROM overtime_requests ot
   WHERE ot.employee_id=a.employee_id AND ot.overtime_date=a.attendance_date
     AND ot.status='APPROVED' AND ot.payroll_verified_at IS NOT NULL
 );
-- Record audit trail (one row per updated record) BEFORE changes.
INSERT INTO audit_logs (user_id,username,action,entity_type,entity_id,description,old_value,new_value)
SELECT NULL,'system','V23_ATTENDANCE_REPAIR','attendance',CAST(a.id AS CHAR),
 'Demo correction: 08:00-17:00 is 8 working hours after unpaid meal break; unverified manual OT excluded',
 JSON_OBJECT('worked_hours',a.worked_hours,'overtime_hours',a.overtime_hours,'status',a.status),
 JSON_OBJECT('worked_hours',8.00,'overtime_hours',0.00,'status',IF(DAYOFWEEK(a.attendance_date)=1,'REST_DAY',a.status))
FROM attendance a
JOIN pms_v23_manual_attendance_backup b ON b.id=a.id
WHERE a.deleted_at IS NULL AND (a.worked_hours>8 OR a.overtime_hours>0)
AND NOT EXISTS (SELECT 1 FROM audit_logs z WHERE z.action='V23_ATTENDANCE_REPAIR'
 AND z.entity_type='attendance' AND z.entity_id=CAST(a.id AS CHAR));
UPDATE attendance a
JOIN pms_v23_manual_attendance_backup b ON b.id=a.id
SET a.worked_hours=8.00, a.overtime_hours=0.00,
    a.is_rest_day=IF(DAYOFWEEK(a.attendance_date)=1,1,a.is_rest_day),
    a.status=IF(DAYOFWEEK(a.attendance_date)=1,'REST_DAY',a.status)
WHERE a.deleted_at IS NULL AND a.source='MANUAL'
 AND TIME(a.time_in)='08:00:00' AND TIME(a.time_out)='17:00:00'
 AND (a.worked_hours>8 OR a.overtime_hours>0)
 AND NOT EXISTS (
   SELECT 1 FROM overtime_requests ot WHERE ot.employee_id=a.employee_id
     AND ot.overtime_date=a.attendance_date AND ot.status='APPROVED'
     AND ot.payroll_verified_at IS NOT NULL
 );
-- See actual data reviewed before approval. Sunday duty is NOT payroll approved by this script.
SELECT attendance_date,employee_id,source,status,worked_hours,overtime_hours FROM attendance
WHERE source='MANUAL' AND attendance_date BETWEEN '2026-10-16' AND '2026-10-31' ORDER BY employee_id,attendance_date;
