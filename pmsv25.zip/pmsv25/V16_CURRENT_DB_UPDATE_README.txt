PMS V16 - CURRENT DATABASE UPDATE (2026-10-31)

IMPORTANT: Do NOT import database/main.sql or your exported attendance_payroll.sql into an existing database.
BACKUP current database + C:\xampp\htdocs\pmsv3 before updating.
The provided current database dump contains usernames, password hashes and tokens; it is NOT packaged here.

Install: extract project folder over your testing copy of C:\xampp\htdocs\pmsv3; run database/migrations/20261031_v16_safe_upgrade.sql ONCE in phpMyAdmin against attendance_payroll.
Verify using the SQL SHOW COLUMNS at the bottom, and perform end-to-end tests.
Do NOT use with live payroll until employer policies, government contribution schedules, and approval controls have been validated.
