# Superseded setup guide
For this clean-database package, follow PMS_V25_CLEAN_DB_INSTALL.md, not the old migration steps.
