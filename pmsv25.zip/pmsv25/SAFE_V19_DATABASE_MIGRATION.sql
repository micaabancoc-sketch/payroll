-- PMS V19 PROVISIONAL PAYROLL TEST BUILD — SCHEMA NO-OP
-- Applies ONLY when cloning an existing V18 test database. No DROP, DELETE, UPDATE or INSERT.
-- This version stores provisional flags in the existing payroll.calculation_snapshot column.
-- Select your separate CLONED TEST database in phpMyAdmin; backup before import.
SELECT 'PMS V19: no schema changes required; current data preserved.' AS migration_status;
