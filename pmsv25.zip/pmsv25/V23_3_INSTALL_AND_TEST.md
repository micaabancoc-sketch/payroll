# PMS V23.3 — Staff Payment Status + 13th-Month No Routine Deductions

This is a **test build**, based on V23.2, for XAMPP/PHP/MariaDB.

## Installation

1. **Back up** your current `pmsv23_2` project and the entire `attendance_payroll_v23_test` database. Test on a cloned database if you can.
2. Extract the ZIP so the application folder is `C:\xampp\htdocs\pmsv23_3`.
3. No schema changes are needed **if V23.2 migrations are already applied**. Do **not** import a full SQL dump over an existing test database or rerun old migrations unnecessarily.
4. The default DB connection remains `attendance_payroll_v23_test`. Update `api/config/config.php` or set `DB_NAME` if you are using your own clone name. Do **not** direct this test build at a live payroll database.
5. Open `http://localhost/pmsv23_3/`, login, and force refresh (`Ctrl+Shift+R`).

## Fix A — Staff Payslips

- Staff **My Payslips** shows **Payroll status** separately from **Payment status**.
- Detailed payslip shows **Payment status**, **Amount paid**, **Remaining balance**, and **Last payment date** (when a completed payment exists).
- These values come from the `payroll_payments` ledger: only `COMPLETED` payment rows count. `PENDING`, `FAILED`, and `CANCELLED` rows do not reduce the balance.
- No payment or payroll record is written by reading a payslip.
- Finalization and payment remain separate; an official payslip can exist while still unpaid.
- Existing staff-only payslip authorization rules remain unchanged.

**Staff test:** Login as Demo Staff. Open Oct 16–31, 2026 payslip. If a **completed** payment for PHP 9,265.02 was recorded, expect `FINALIZED` + `PAID`, PHP 9,265.02 paid, and PHP 0.00 remaining. If it was reversed or cancelled, expect an unpaid or partial balance, matching the ledger. Repeat with an unpaid employee and verify `UNPAID`.

## Fix B — 13th-Month Pay

- `13th-Month Pay = total basic salary earned during the calendar year / 12` (existing rule).
- **No second deduction** for SSS, PhilHealth, Pag-IBIG, late/absence, or ordinary loan installment. Backend responses and HR table now show ordinary deductions as PHP 0.00 and net 13th equal to calculated 13th pay.
- The **PHP 90,000 tax exemption applies to the combined annual 13th-month plus other benefits**, not just 13th-month alone. There may be a **BIR withholding obligation on taxable excess**. The app does not presently track all 'other benefits' for this threshold, and must not be treated as automatically tax-compliant.
- For an individual calculated 13th-month amount **above PHP 90,000**, backend **blocks the release** until BIR handling is reviewed. It does **not** silently release a potentially taxable amount without withholding.
- Corrected an existing mismatch: the 13th-month approval button is shown for HR/Payroll, matching the backend HR-only permission. Independent review of HR's own benefit requires separate implementation/review.
- **Do not treat a partial-year 13th-month figure as a full-year legal entitlement**: the generator uses only finalized basic salary earned in the specified year.

**13th-month test:** HR → 13th Month → Generate for a year with finalized payroll periods. Confirm Deductions = PHP 0.00 and Net 13th = calculated 13th amount. Test submit/approval/release on the **test database only**, not as an actual cash payment. For taxable cases, first obtain tax-compliance review outside this demo module.

## Checks performed offline

- PHP syntax validation on PHP sources, frontend JS syntax check and inline script parsing.
- `php tests/v23_3_payment_13th_policy_test.php`: pure payment states and 13th-month source-level rules.
- `php tests/v23_2_sunday_rest_day_test.php`: unchanged Sunday classification behavior.

**Not verified here:** Real MariaDB transactions and browser user permissions in your local XAMPP, annual BIR other-benefit totals, and any real money transfer. Do not use this test build to pay employees until those have been reviewed.
