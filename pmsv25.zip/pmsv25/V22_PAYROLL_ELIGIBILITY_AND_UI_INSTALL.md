# PMS V22 — Payroll Eligibility, Approval and Employee Filters (TEST BUILD)

This is a **complete V21-based project**, not a patch. **Use a cloned test database.** No production payroll approval is warranted until the app is tested on the intended XAMPP/MariaDB environment.

## What changed

- Removes the V21 username-based demo exclusion lock that blocked `FOR_REVIEW → APPROVED` even with a valid complete batch.
- Adds `employees.payroll_eligible` (1 = included in company payroll; 0 = genuine non-payroll/test employee). Defaults to 1, so normal HR and Manager employees participate.
- The **one-time migration** marks only the linked accounts with exact usernames `test` or `demo2` not payroll eligible. Their login, attendance, loan and historical payroll records are **not deleted**, deactivated or erased. Review the employee list after migration to confirm this classification.
- Payroll preview, Calculate Employee, Calculate All, batch exceptions and server-side approval validation now use the explicit eligible roster instead of a hidden username list.
- Approval, finalization and payment **remain blocked** for unresolved attendance/financial exceptions, a missing eligible employee row, duplicate payroll rows, or provisional drafts. Recalculate the saved (unlocked) DRAFT/For Review batch before attempting approval.
- Employee directory defaults to **Active + Payroll eligible**; click **Show filters** to view inactive or excluded employees. Edit Employee allows HR to change the payroll eligibility field; HR/Manager are safeguarded from being designated non-payroll.
- The **Manual Attendance** employee list now shows only active payroll-eligible employees. Historic attendance records for inactive/excluded employees remain accessible via records/history.
- The inaccurate V21 demo-mode banners were removed.
- Existing Add Payroll Period retroactive/overlap validation is preserved.

## Installation (safe sequence)

1. In phpMyAdmin **export a full backup** of your current TEST DB. Keep your V21 source folder as a rollback.
2. **Clone** that database to an isolated test database (for example `attendance_payroll_v22_test`); do not use production records. Verify table contents.
3. Select the cloned database in phpMyAdmin and **import `SAFE_V22_DATABASE_MIGRATION.sql`**. This must happen **before first V22 login**. The SQL adds one column, with no DROP/DELETE of tables or records.
4. Extract this ZIP to `C:\xampp\htdocs\pmsv22`. Update `pmsv22/api/config/config.php` **or DB_NAME environment variable** to the exact test DB name. Never point V22 to your original database by mistake. Default configuration is `attendance_payroll_v22_test`. If you choose a different clone name, update `DB_NAME` or `config.php` to match it.
5. Open `http://localhost/pmsv22/`; browser hard refresh (`Ctrl+Shift+R`). Log in as HR.
6. HR → **Employees & Salaries**. Confirm Demo Staff, HR and Manager are all **Payroll Eligible = Yes**. To inspect the `test` / `demo2` account, click **Show filters**, set Status=All statuses, Payroll eligibility=All.
7. HR → **Payroll Processing** → October 16–31, 2026 → **Calculate All (Save Draft)** to replace old unlocked V21 rows with the current eligible roster. If the period is already `FOR_REVIEW`, use the existing **Recalculate** action if available; only unlocked records may be changed. Do not tamper with finalized/paid history.
8. Verify the employee count and each calculation; click **View Batch Exceptions**. Resolve all real issues with evidence and **recalculate**. Only then attempt **Approve**.

### Expected result for the provided test account setup

- Eligible: Demo Staff, Demo HR Payroll, Operations Manager (if all remain ACTIVE).
- Excluded: the extra `test`/`demo2` account (if found by the migration).
- Inactive cashiers: not included while inactive; still viewable with filters.
- `FOR_REVIEW → APPROVED` no longer fails merely because a real test account is excluded. **Other valid controls can still block approval** (missing employees, unresolved exceptions, invalid pay date, failed validations).

### Known limitations

- Source syntax and structural checks can be run here, but a live MariaDB transaction test against your local XAMPP is not available. This is a **test build**.
- The older checkbox selections genuinely connect to legacy bulk archive/restore actions; they were **not silently deleted** in this update. Removing the legacy Archive workflow and related checkboxes belongs to a separately reviewed UI/data-retention change.
- Remaining previously identified review/OT/13th-month issues have **not** been certified as fully fixed here.

## Rollback

Restore the prior V21 folder and the **backed-up test database**. Do not reverse the added field manually after records have used it. If you don't want V22, simply return to the previous source + backup.
