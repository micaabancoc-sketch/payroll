BASE="${1:-http://127.0.0.1:8099/api}"
PASS=0
FAIL=0

ok()  { echo "  PASS  $1"; PASS=$((PASS + 1)); }
bad() { echo "  FAIL  $1"; echo "        $2"; FAIL=$((FAIL + 1)); }

# check <label> <path> <expected_substring> [token]
check() {
  local label="$1" path="$2" needle="$3" token="$4"
  local response

  if [ -n "$token" ]; then
    response=$(curl -s "$BASE$path" -H "Authorization: Bearer $token")
  else
    response=$(curl -s "$BASE$path")
  fi

  if echo "$response" | grep -q "$needle"; then
    ok "$label"
  else
    bad "$label" "$(echo "$response" | head -c 200)"
  fi
}

echo "=============================================="
echo " FRONTEND CONTRACT SMOKE TEST"
echo "=============================================="
echo

# A previous suite (e.g. the end-to-end run) may have tripped the rate limiter,
# which would block this suite's own sign-in. Clear the buckets first so this
# script is independently runnable whichever order the suites run in.
if command -v php > /dev/null 2>&1; then
  php tests/reset_test_data.php > /dev/null 2>&1 || true
elif [ -x /c/xampp/php/php.exe ]; then
  /c/xampp/php/php.exe tests/reset_test_data.php > /dev/null 2>&1 || true
fi

TOKEN=$(curl -s -X POST "$BASE/auth/login" -H 'Content-Type: application/json' \
  -d '{"username":"admin","password":"Password123@"}' \
  | grep -o '"token":"[a-f0-9]*"' | head -1 | cut -d'"' -f4)

if [ -z "$TOKEN" ]; then
  echo "Cannot obtain a token. Is the API running at $BASE ?"
  echo "If the API is up, the rate limiter may be blocking this client."
  exit 1
fi

# A real employee and payroll period to exercise the detail views.
EMP_ID=$(curl -s "$BASE/employees?per_page=1" -H "Authorization: Bearer $TOKEN" \
  | grep -o '"id":[0-9]*' | head -1 | cut -d: -f2)

# The QR panel needs an employee whose code is currently ACTIVE. The end-to-end
# suite regenerates codes, so the active one is usually on the employee it
# created most recently — search a wide window rather than the first few.
QR_EMP_ID=$(curl -s "$BASE/employees?per_page=50" -H "Authorization: Bearer $TOKEN" \
  | grep -o '"id":[0-9]*' | cut -d: -f2 | while read candidate; do
      if curl -s "$BASE/qr/active/$candidate" -H "Authorization: Bearer $TOKEN" | grep -q '"status":"ACTIVE"'; then
        echo "$candidate"
        break
      fi
    done)

echo "Token acquired."
echo "Employee under test: ${EMP_ID:-none}; with an active QR code: ${QR_EMP_ID:-none}"
echo

echo "--- Shell and common --------------------------------------"
check "GET /dashboard            (dashboard.html)"  /dashboard       '"cards"'        "$TOKEN"
check "GET /auth/me              (session restore)" /auth/me         '"success":true' "$TOKEN"
check "GET /settings/company     (header company)" /settings/company '"success":true' "$TOKEN"
check "GET /settings/public      (public values)"  /settings/public  '"success":true' "$TOKEN"

echo
echo "--- Attendance ---------------------------------------------"
check "GET /attendance           (attendance page)" "/attendance?date_from=2026-10-01&date_to=2026-10-31" '"success":true' "$TOKEN"
check "GET /attendance/today     (today panel)"     /attendance/today '"success":true' "$TOKEN"
check "GET /employees/options    (manual entry)"    /employees/options '"success":true' "$TOKEN"

# post_check <label> <path> <expected_substring> <token>
post_check() {
  local label="$1" path="$2" needle="$3" token="$4"
  local response
  response=$(curl -s -X POST "$BASE$path" -H "Authorization: Bearer $token" \
    -H 'Content-Type: application/json' -d '{}')
  if echo "$response" | grep -q "$needle"; then
    ok "$label"
  else
    bad "$label" "$(echo "$response" | head -c 200)"
  fi
}

echo
echo "--- Employees ----------------------------------------------"
check "GET /employees            (directory)"       "/employees?page=1"        '"success":true' "$TOKEN"
# The employee IS the user, so the directory carries the linked account and
# the row action can reset it. Both are load-bearing for the employee page.
check "GET /employees            (linked account)"  "/employees?page=1"        '"account_username"' "$TOKEN"
check "GET /settings/departments (filter select)"   /settings/departments      '"success":true' "$TOKEN"
check "GET /settings/positions   (form select)"     /settings/positions        '"success":true' "$TOKEN"
check "GET /schedules            (form select)"     /schedules                 '"success":true' "$TOKEN"

if [ -n "$EMP_ID" ]; then
  check "GET /employees/{id}/profile        (profile modal)" "/employees/$EMP_ID/profile"        '"success":true' "$TOKEN"
  check "GET /employees/{id}/leave-balances (profile modal)" "/employees/$EMP_ID/leave-balances" '"success":true' "$TOKEN"
  check "GET /employees/{id}/salary-history (profile modal)" "/employees/$EMP_ID/salary-history" '"success":true' "$TOKEN"
  check "GET /qr/history/{id}              (QR panel)"      "/qr/history/$EMP_ID"               '"success":true' "$TOKEN"
  # The reset action is admin-only, so the manager session must be refused.
  MANAGER_TOKEN=$(curl -s -X POST "$BASE/auth/login" -H 'Content-Type: application/json' \
    -d '{"username":"manager","password":"Password123@"}' \
    | grep -o '"token":"[a-f0-9]*"' | head -1 | cut -d'"' -f4)
  if [ -n "$MANAGER_TOKEN" ]; then
    post_check "POST /employees/{id}/reset-password (manager denied)" \
      "/employees/$EMP_ID/reset-password" 'settings.manage' "$MANAGER_TOKEN"
  else
    echo "  SKIP  reset-password permission assertion - manager could not sign in"
  fi
fi

# The QR panel and badge only exist for an employee with a live code.
if [ -n "$QR_EMP_ID" ]; then
  check "GET /qr/active/{id}               (QR panel)"      "/qr/active/$QR_EMP_ID"             '"status":"ACTIVE"' "$TOKEN"
  check "GET /qr/svg/{id}                  (inline QR badge)" "/qr/svg/$QR_EMP_ID"                '<svg'              "$TOKEN"
else
  echo "  SKIP  QR panel assertions - no employee currently has an active code"
  echo "        (the end-to-end suite replaces codes as part of its own tests)"
fi

echo
echo "--- Leave ---------------------------------------------------"
check "GET /leave                (queue)"      "/leave?page=1"  '"success":true' "$TOKEN"
check "GET /leave/types          (form select)" /leave/types     '"success":true' "$TOKEN"

echo
echo "--- Overtime ------------------------------------------------"
check "GET /overtime             (queue)"      "/overtime?page=1" '"success":true' "$TOKEN"
check "GET /overtime/tomorrow    (tomorrow)"  "/overtime/tomorrow" '"success":true' "$TOKEN"

echo
echo "--- Payroll -------------------------------------------------"
check "GET /payroll/periods      (index)"      "/payroll/periods?page=1" '"success":true' "$TOKEN"
check "GET /payroll/settings     (rate preview)" /payroll/settings      '"success":true' "$TOKEN"

PERIOD_ID=$(curl -s "$BASE/payroll/periods?page=1" -H "Authorization: Bearer $TOKEN" \
  | grep -o '"id":[0-9]*' | head -1 | cut -d: -f2)

if [ -n "$PERIOD_ID" ]; then
  check "GET /payroll/periods/{id}          (period detail)" "/payroll/periods/$PERIOD_ID"          '"success":true' "$TOKEN"
  check "GET /payroll/periods/{id}/payroll  (register)"      "/payroll/periods/$PERIOD_ID/payroll"  '"success":true' "$TOKEN"
  check "GET /payroll/payslips/period/{id}  (payslip list)"   "/payroll/payslips/period/$PERIOD_ID"  '"success":true' "$TOKEN"
fi

if [ -n "$EMP_ID" ]; then
  check "GET /payroll/payslips/employee/{id} (payslip history)" "/payroll/payslips/employee/$EMP_ID" '"success":true' "$TOKEN"
fi

echo
echo "--- Reports -------------------------------------------------"
check "GET /settings/departments                  (filter)"   /settings/departments '"success":true' "$TOKEN"
DATES="date_from=2026-10-01&date_to=2026-10-31"
check "GET /reports/attendance/daily             (daily)"     "/reports/attendance/daily?$DATES"     '"success":true' "$TOKEN"
check "GET /reports/attendance/monthly           (monthly)"   "/reports/attendance/monthly?$DATES"   '"success":true' "$TOKEN"
check "GET /reports/attendance/late              (late)"      "/reports/attendance/late?$DATES"      '"success":true' "$TOKEN"
check "GET /reports/attendance/absent            (absent)"    "/reports/attendance/absent?$DATES"    '"success":true' "$TOKEN"
check "GET /reports/attendance/undertime         (undertime)" "/reports/attendance/undertime?$DATES" '"success":true' "$TOKEN"
check "GET /reports/overtime                     (overtime)"  "/reports/overtime?$DATES"             '"success":true' "$TOKEN"
check "GET /reports/leave/history                (leave)"     "/reports/leave/history?$DATES"        '"success":true' "$TOKEN"
check "GET /reports/leave/balance                (balance)"   /reports/leave/balance                 '"success":true' "$TOKEN"
check "GET /reports/payroll/summary              (payroll)"   /reports/payroll/summary               '"success":true' "$TOKEN"
check "GET /reports/payroll/employee             (per emp)"   "/reports/payroll/employee?$DATES"     '"success":true' "$TOKEN"
check "GET /reports/payroll/department           (per dept)"  "/reports/payroll/department?$DATES"   '"success":true' "$TOKEN"
check "GET /reports/payroll/deductions           (deduct)"    "/reports/payroll/deductions?$DATES"   '"success":true' "$TOKEN"

echo
echo "--- Settings ------------------------------------------------"
check "GET /settings             (settings grid)" /settings        '"success":true' "$TOKEN"
check "GET /users                (user list)"     "/users?page=1"  '"success":true' "$TOKEN"
check "GET /users/roles          (role select)"   /users/roles     '"success":true' "$TOKEN"
check "GET /schedules            (schedule list)" /schedules       '"success":true' "$TOKEN"
check "GET /schedules/shifts     (shift list)"    /schedules/shifts '"success":true' "$TOKEN"
check "GET /holidays             (holiday list)"  /holidays        '"success":true' "$TOKEN"
check "GET /audit                (audit trail)"   "/audit?page=1"  '"success":true' "$TOKEN"

echo
echo "=============================================="
echo " RESULT: $PASS passed, $FAIL failed"
echo "=============================================="

[ "$FAIL" -eq 0 ] || exit 1
