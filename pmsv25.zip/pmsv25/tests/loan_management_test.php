<?php
/**
 * Loan management test (Phase 3A / 3B).
 *
 * Proves, with independent manual arithmetic, that:
 *
 *   1. the engine splits a monthly loan deduction across the pay periods of
 *      the month (SEMI_MONTHLY = half per period), rounds to centavos and
 *      never proposes an instalment below the smallest unit;
 *   2. calculating (and recalculating) payroll only PROPOSES the instalments:
 *      no loan_payments rows are written and no balance moves while the
 *      period is a draft, however many times it is calculated;
 *   3. marking a period PAID commits the instalments to the ledger and moves
 *      the balances atomically with the status change, exactly once - a
 *      replay adds nothing (idempotency guard) and the database-level unique
 *      key rejects a duplicated (period, loan) PAYROLL row outright;
 *   4. recordPayment() is transaction-safe: sequential (or racing) payments
 *      cannot overpay a loan, the overpayment error is precise, the final
 *      payment flips the loan to PAID, and a cancelled or settled loan
 *      refuses new payments;
 *   5. the legacy repair path (reversePayrollDeductions) restores a balance
 *      and removes its ledger rows, then a re-commit records once;
 *   6. create() requires an explicit instalment and rejects one that exceeds
 *      the principal or a balance above the principal;
 *   7. filing a loan leaves it PENDING: the engine proposes nothing and a
 *      repayment is refused until an approver - never the user who filed it -
 *      approves it, and approving it is what makes the next payroll run
 *      propose the instalment (Phase 3B);
 *   8. a rejection requires a reason and is terminal (no approval, no
 *      repayment, no edit, no cancel afterwards), while a withdrawn filing
 *      restores to PENDING rather than ACTIVE.
 *
 * Everything is created inside ONE outer transaction and rolled back when the
 * script ends, so no fixture ever survives - the genuine attendance_payroll
 * database is never touched (tests/db_guard.php refuses it).
 *
 * Usage:
 *   DB_NAME=attendance_payroll_test php tests/loan_management_test.php
 *
 * Exit code 0 = every check passed, 1 = at least one check failed.
 */

declare(strict_types=1);

use App\Core\Database;
use App\Core\Settings;
use App\Core\ValidationException;
use App\Services\LoanService;
use App\Services\PayrollEngine;
use App\Services\PayrollPaymentService;
use App\Services\PayrollService;

require dirname(__DIR__) . '/api/autoload.php';

$config = require dirname(__DIR__) . '/api/config/config.php';
date_default_timezone_set((string) $config['app']['timezone']);

// Refuse to write anything when the configured database looks like production.
require __DIR__ . '/db_guard.php';
pmsAssertSafeTestDatabase();

const SALARY   = 22000.00;
const PER_A_START = '2025-12-01';
const PER_A_END   = '2025-12-15';
const PER_B_START = '2025-12-16';
const PER_B_END   = '2025-12-31';

$passed   = 0;
$failed   = 0;
$failures = [];

function check(string $label, bool $ok, string $detail = ''): void
{
    global $passed, $failed, $failures;

    if ($ok) {
        $passed++;
        echo "  PASS  $label\n";
        return;
    }

    $failed++;
    $failures[] = $label;
    echo "  FAIL  $label\n";
    if ($detail !== '') {
        echo "        $detail\n";
    }
}

function checkMoney(string $label, float $expected, float $actual): void
{
    check(
        $label,
        abs($expected - $actual) < 0.005,
        sprintf('expected %s, got %s', number_format($expected, 2), number_format($actual, 2))
    );
}

function checkSame(string $label, mixed $expected, mixed $actual): void
{
    check($label, $expected === $actual, sprintf('expected %s, got %s', var_export($expected, true), var_export($actual, true)));
}

function heading(string $title): void
{
    echo "\n", $title, "\n", str_repeat('-', strlen($title)), "\n";
}

// ---------------------------------------------------------------------------
// Fixture helpers
// ---------------------------------------------------------------------------

$sequence = 0;

function nextCode(string $prefix): string
{
    global $sequence;
    $sequence++;

    return sprintf('%s%02d_%s', $prefix, $sequence, strtoupper(bin2hex(random_bytes(3))));
}

function makeEmployee(float $salary, array $over = []): int
{
    return Database::insert('employees', array_merge([
        'employee_number' => nextCode('LOAN-'),
        'first_name'      => 'Loan',
        'last_name'       => 'Mgmt',
        'gender'          => 'OTHER',
        'date_hired'      => '2024-01-01',
        'employment_type' => 'FULL_TIME',
        'salary_type'     => 'MONTHLY',
        'basic_salary'    => $salary,
        'status'          => 'ACTIVE',
    ], $over));
}

/** The engine reads the real loans table, so insert loans exactly like the service does. */
function makeLoan(int $employeeId, float $principal, float $monthly, float $balance): int
{
    return Database::insert('loans', [
        'employee_id'       => $employeeId,
        'loan_type'         => 'SALARY_LOAN',
        'reference_no'      => null,
        'principal_amount'  => $principal,
        'monthly_deduction' => $monthly,
        'balance'           => $balance,
        'start_date'        => '2025-01-01',
        'end_date'          => null,
        'status'            => $balance > 0 ? 'ACTIVE' : 'PAID',
        'notes'             => null,
        'created_by'        => null,
        'approved_by'       => null,
        'approved_at'       => null,
    ]);
}

function employeeRow(int $employeeId): array
{
    $row = Database::selectOne('SELECT * FROM employees WHERE id = :id', ['id' => $employeeId]);

    if ($row === null) {
        throw new RuntimeException('Fixture employee ' . $employeeId . ' disappeared.');
    }

    return $row;
}

function addAttendance(int $employeeId, string $date, string $status = 'PRESENT'): void
{
    Database::insert('attendance', [
        'employee_id'     => $employeeId,
        'attendance_date' => $date,
        'status'          => $status,
        'source'          => 'MANUAL',
    ]);
}

function addPresentDays(int $employeeId, array $dates): void
{
    foreach ($dates as $date) {
        addAttendance($employeeId, $date, 'PRESENT');
    }
}

/** @return list<string> consecutive dates starting at $from */
function consecutiveDates(string $from, int $count): array
{
    $cursor = new DateTimeImmutable($from);
    $dates  = [];

    for ($i = 0; $i < $count; $i++) {
        $dates[] = $cursor->format('Y-m-d');
        $cursor  = $cursor->modify('+1 day');
    }

    return $dates;
}

/**
 * Phase 5: the FINALIZED -> PAID gate refuses while any payable payroll row
 * is outstanding, so a test that wants to mark a period paid must disburse
 * the salary first. Settle every payable row through the production
 * PayrollPaymentService - the same path the Payments page uses - never by
 * touching the cached payment columns directly. Rows with a non-positive
 * net pay need no disbursement (the gate reads them as settled) and
 * already-settled rows are skipped.
 *
 * @return int how many payroll rows this settled
 */
function disbursePeriodFully(PayrollPaymentService $payments, int $periodId, int $userId): int
{
    $rows = Database::select(
        'SELECT id, net_pay, amount_paid, payment_status
           FROM payroll
          WHERE payroll_period_id = :pid
          ORDER BY id',
        ['pid' => $periodId]
    );

    $settled = 0;
    foreach ($rows as $row) {
        if ((string) ($row['payment_status'] ?? '') === 'PAID') {
            continue;
        }
        $net = round((float) ($row['net_pay'] ?? 0), 2);
        if ($net <= 0) {
            continue;
        }
        $due = round($net - (float) ($row['amount_paid'] ?? 0), 2);
        if ($due <= 0) {
            continue;
        }
        $payments->record((int) $row['id'], [
            'amount'         => $due,
            'payment_method' => 'CASH',
            'payment_status' => 'COMPLETED',
            'confirmed'      => true,
            'notes'          => 'Automated test: full salary disbursement before PAID.',
        ], $userId);
        $settled++;
    }

    return $settled;
}

/** Amount of one earning/deduction line, 0.0 when the line is absent. */
function itemAmount(array $lines, string $code): float
{
    foreach ($lines as $line) {
        if (strtoupper((string) $line['code']) === strtoupper($code)) {
            return (float) $line['amount'];
        }
    }

    return 0.0;
}

/** Number of ledger rows one loan has accumulated. */
function ledgerCount(int $loanId): int
{
    return (int) (Database::scalar(
        'SELECT COUNT(*) FROM loan_payments WHERE loan_id = :loan_id',
        ['loan_id' => $loanId]
    ) ?? 0);
}

function loanBalance(int $loanId): float
{
    return round((float) (Database::scalar(
        'SELECT balance FROM loans WHERE id = :id',
        ['id' => $loanId]
    ) ?? 0.0), 2);
}

function loanStatus(int $loanId): string
{
    return (string) (Database::scalar(
        'SELECT status FROM loans WHERE id = :id',
        ['id' => $loanId]
    ) ?? '');
}

// ---------------------------------------------------------------------------
// Scenario
// ---------------------------------------------------------------------------

Database::beginTransaction();

try {
    $userId = (int) (Database::scalar(
        "SELECT id FROM users WHERE username = 'admin' AND deleted_at IS NULL LIMIT 1"
    ) ?? 0);

    if ($userId === 0) {
        throw new RuntimeException('admin account not found - seed the database first.');
    }

    $engine         = new PayrollEngine();
    $payrollService = new PayrollService($engine);
    $loans          = new LoanService();
    $payments       = new PayrollPaymentService();

    // -----------------------------------------------------------------------
    heading('0. Preflight: loans module present in the target database');
    // -----------------------------------------------------------------------
    $loanCols = (int) (Database::scalar(
        "SELECT COUNT(*) FROM information_schema.columns
          WHERE table_schema = DATABASE() AND table_name = 'loans'
            AND column_name IN ('reference_no','notes','approved_by','approved_at','rejection_reason')"
    ) ?? 0);
    $paymentCols = (int) (Database::scalar(
        "SELECT COUNT(*) FROM information_schema.columns
          WHERE table_schema = DATABASE() AND table_name = 'loan_payments'
            AND column_name IN ('period_id','payment_type','remarks','created_by')"
    ) ?? 0);
    $repayKey = (int) (Database::scalar(
        "SELECT COUNT(DISTINCT index_name) FROM information_schema.statistics
          WHERE table_schema = DATABASE() AND table_name = 'loan_payments'
            AND index_name = 'uq_loanpay_period_loan'"
    ) ?? 0);

    check('the loans migration is applied (loans columns)', $loanCols === 5,
        'run: php database/migrate_employee_loans.php');
    // Phase 3B: MySQL would silently truncate a filing to '' if the ENUM did
    // not carry the two approval states.
    $approvalStates = (int) (Database::scalar(
        "SELECT COUNT(*) FROM information_schema.columns
          WHERE table_schema = DATABASE() AND table_name = 'loans' AND column_name = 'status'
            AND COLUMN_TYPE LIKE '%PENDING%' AND COLUMN_TYPE LIKE '%REJECTED%'"
    ) ?? 0);
    check('the status ENUM carries PENDING and REJECTED', $approvalStates === 1,
        'run: php database/migrate_employee_loans.php');
    check('the repayment ledger carries the Phase 3 columns', $paymentCols === 4,
        'run: php database/migrate_employee_loans.php');
    check('the (period, loan) idempotency key exists', $repayKey === 1,
        'run: php database/migrate_employee_loans.php');
    check('loan deductions are enabled', (bool) Settings::bool('payroll.loan_deduction_enabled', false));

    $settings = $engine->settings();
    echo '   pay_frequency = ', (string) $settings['pay_frequency'],
        ', periods/month = ', $engine->periodsPerMonth($settings), "\n";

    // -----------------------------------------------------------------------
    heading('1. Monthly deduction split across the pay periods of a month');
    // -----------------------------------------------------------------------
    checkSame('SEMI_MONTHLY has 2 periods a month', 2, $engine->periodsPerMonth(['pay_frequency' => 'SEMI_MONTHLY']));
    checkSame('MONTHLY has 1 period a month', 1, $engine->periodsPerMonth(['pay_frequency' => 'MONTHLY']));
    checkSame('WEEKLY has 4 periods a month', 4, $engine->periodsPerMonth(['pay_frequency' => 'WEEKLY']));
    checkSame('BI_WEEKLY has 2 periods a month', 2, $engine->periodsPerMonth(['pay_frequency' => 'BI_WEEKLY']));

    checkMoney('a 1000.00 monthly deduction is 500.00 per semi-monthly period',
        500.00, $engine->loanInstalmentForPeriod(1000.00, ['pay_frequency' => 'SEMI_MONTHLY']));
    checkMoney('two halves of 1000.01 round to 500.01 + 500.00 (not 500.02)',
        500.01, $engine->loanInstalmentForPeriod(1000.01, ['pay_frequency' => 'SEMI_MONTHLY']));
    checkMoney('a half centavo still leaves an instalment (0.01)', 0.01,
        $engine->loanInstalmentForPeriod(0.01, ['pay_frequency' => 'SEMI_MONTHLY']));
    checkMoney('MONTHLY payroll withdraws the whole monthly deduction',
        1000.00, $engine->loanInstalmentForPeriod(1000.00, ['pay_frequency' => 'MONTHLY']));
    checkMoney('WEEKLY payroll quarters the monthly deduction',
        250.00, $engine->loanInstalmentForPeriod(1000.00, ['pay_frequency' => 'WEEKLY']));

    // -----------------------------------------------------------------------
    heading('2. The engine proposes half a month, capped by the balance');
    // -----------------------------------------------------------------------
    $empA = makeEmployee(SALARY);
    addPresentDays($empA, consecutiveDates(PER_A_START, 15));

    $loanA = makeLoan($empA, 1000.00, 1000.00, 1000.00);
    $expectedA = $engine->loanInstalmentForPeriod(1000.00, $settings);

    $calc = $engine->calculateEmployee(employeeRow($empA), PER_A_START, PER_B_END);
    $allocation = (array) ($calc['loan_allocations'] ?? []);

    checkSame('exactly one loan allocation is proposed', 1, count($allocation));
    checkMoney('the proposed instalment is the per-period split', $expectedA, (float) ($allocation[0]['amount'] ?? 0));
    checkMoney('the LOAN line on the payslip matches the proposal', $expectedA,
        itemAmount((array) $calc['deductions'], 'LOAN'));
    checkMoney('the engine does not move the balance', 1000.00, loanBalance($loanA));
    checkSame('the engine writes no ledger rows', 0, ledgerCount($loanA));

    // -----------------------------------------------------------------------
    heading('3. Calculating payroll proposes but never commits repayments');
    // -----------------------------------------------------------------------
    $periodA = $payrollService->createPeriod([
        'start_date' => PER_A_START,
        'end_date'   => PER_A_END,
        'pay_date'   => PER_A_END,
        'name'       => 'Automated loan test 2025-12 first half',
    ], $userId);
    $periodAId = (int) $periodA['id'];

    $resultA = $payrollService->calculate($periodAId, $userId);

    checkSame('a calculation reports the instalments it proposed', 1,
        (int) ($resultA['loan_instalments_proposed'] ?? 0));
    checkMoney('the proposed total is the split instalment', $expectedA,
        (float) ($resultA['loan_repayment_total'] ?? 0.0));
    checkMoney('the loan balance is untouched by the calculation', 1000.00, loanBalance($loanA));
    checkSame('no ledger rows exist after the calculation', 0, ledgerCount($loanA));

    $item = Database::selectOne(
        "SELECT pi.amount FROM payroll_items pi
           JOIN payroll p ON p.id = pi.payroll_id
          WHERE p.payroll_period_id = :pid AND p.employee_id = :e AND pi.code = 'LOAN'",
        ['pid' => $periodAId, 'e' => $empA]
    );
    checkMoney('the saved payslip itemises the half-month instalment', $expectedA, (float) ($item['amount'] ?? 0.0));

    // A recalculation stays presentational: same rows replaced, still no ledger.
    $resultB = $payrollService->calculate($periodAId, $userId);
    checkSame('recalculating still proposes exactly one instalment', 1,
        (int) ($resultB['loan_instalments_proposed'] ?? 0));
    checkMoney('the loan balance still has not moved', 1000.00, loanBalance($loanA));
    checkSame('recalculating still writes no ledger rows', 0, ledgerCount($loanA));

    // -----------------------------------------------------------------------
    heading('4. Marking the period PAID commits the repayments exactly once');
    // -----------------------------------------------------------------------
    $payrollService->transition($periodAId, 'APPROVED', $userId);
    $payrollService->transition($periodAId, 'FINALIZED', $userId);

    checkMoney('approve + finalize still leave the balance alone', 1000.00, loanBalance($loanA));
    checkSame('approve + finalize still write no ledger rows', 0, ledgerCount($loanA));

    // Phase 5: the PAID gate needs the salary actually disbursed first, so
    // settle every payable row through the production payment service.
    $settled = disbursePeriodFully($payments, $periodAId, $userId);
    check('the period salary is disbursed before PAID', $settled >= 1, 'payments recorded=' . $settled);
    check('every payroll row reports fully paid', (bool) $payments->periodReadiness($periodAId)['ready']);

    $paid = $payrollService->transition($periodAId, 'PAID', $userId);
    $repayments = (array) ($paid['loan_repayments'] ?? []);

    checkSame('the PAID response reports the committed instalments', 1, (int) ($repayments['recorded'] ?? 0));
    checkMoney('the PAID response reports the committed total', $expectedA, (float) ($repayments['total'] ?? 0.0));
    checkMoney('the loan balance drops by the instalment', round(1000.00 - $expectedA, 2), loanBalance($loanA));

    $ledgerRow = Database::selectOne(
        "SELECT * FROM loan_payments WHERE loan_id = :lid AND period_id = :pid AND payment_type = 'PAYROLL'",
        ['lid' => $loanA, 'pid' => $periodAId]
    );
    check('the PAYROLL ledger row exists with the period link', $ledgerRow !== null);
    checkMoney('the ledger amount matches the payslip', $expectedA,
        $ledgerRow === null ? -1.0 : (float) $ledgerRow['amount']);
    check('the ledger row records the payroll row that produced it',
        $ledgerRow !== null && (int) ($ledgerRow['payroll_id'] ?? 0) > 0);

    // The service-level replay: same period, same loan -> nothing new.
    $replay = $loans->recordPayrollDeductions(
        $periodAId,
        [['loan_id' => $loanA, 'amount' => $expectedA]],
        $userId
    );
    checkSame('replaying the commit records nothing', 0, (int) ($replay['recorded'] ?? -1));
    checkSame('replaying the commit skips the charged instalment', 1, (int) ($replay['skipped'] ?? 0));
    checkMoney('the balance is untouched by the replay', round(1000.00 - $expectedA, 2), loanBalance($loanA));
    checkSame('still exactly one ledger row for the period and loan', 1, ledgerCount($loanA));

    // The database-level guard: the unique key rejects a duplicated pair.
    $duplicateRejected = false;
    try {
        Database::insert('loan_payments', [
            'loan_id'      => $loanA,
            'payroll_id'   => null,
            'period_id'    => $periodAId,
            'amount'       => 1.00,
            'payment_type' => 'PAYROLL',
        ]);
    } catch (PDOException $e) {
        $duplicateRejected = stripos($e->getMessage(), 'Duplicate entry') !== false;
    }
    check('a duplicate (period, loan) PAYROLL row is rejected by the unique key', $duplicateRejected);
    checkSame('the rejected insert left one row', 1, ledgerCount($loanA));

    // A manual payment on the same period carries a NULL period_id and is free
    // to coexist with the payroll row - MySQL counts NULLs as distinct.
    $loans->recordPayment($loanA, ['amount' => round($expectedA / 2, 2)], $userId);
    checkSame('manual payments coexist with the payroll row', 2, ledgerCount($loanA));

    // -----------------------------------------------------------------------
    heading('5. Legacy repair: reverse restores, then a re-commit records once');
    // -----------------------------------------------------------------------
    $empB = makeEmployee(SALARY);
    addPresentDays($empB, consecutiveDates(PER_B_START, 10));
    $periodB = $payrollService->createPeriod([
        'start_date' => PER_B_START,
        'end_date'   => PER_B_END,
        'pay_date'   => PER_B_END,
        'name'       => 'Automated loan test 2025-12 second half',
    ], $userId);
    $periodBId = (int) $periodB['id'];

    // Simulate a PRE-fix draft commit: the old flow wrote the ledger row and
    // moved the balance while the period was still being calculated.
    $loanB = makeLoan($empB, 600.00, 300.00, 600.00);
    $preFix = $loans->recordPayrollDeductions(
        $periodBId,
        [['loan_id' => $loanB, 'amount' => 300.00]],
        $userId
    );
    checkSame('the legacy-style commit records the instalment', 1, (int) ($preFix['recorded'] ?? 0));
    checkMoney('the legacy-style commit moved the balance', 300.00, loanBalance($loanB));

    $reversed = $loans->reversePayrollDeductions($periodBId);
    checkSame('the repair path reverses the period rows', 1, (int) ($reversed['reversed'] ?? 0));
    checkMoney('the repair path restores the balance', 600.00, loanBalance($loanB));
    checkSame('the repair path deletes the ledger rows', 0, ledgerCount($loanB));

    $recommit = $loans->recordPayrollDeductions(
        $periodBId,
        [['loan_id' => $loanB, 'amount' => 300.00]],
        $userId
    );
    checkSame('the repaired period re-commits exactly once', 1, (int) ($recommit['recorded'] ?? 0));
    checkMoney('the re-committed balance matches', 300.00, loanBalance($loanB));

    // -----------------------------------------------------------------------
    heading('6. recordPayment() is transaction-safe and settles precisely');
    // -----------------------------------------------------------------------
    $empC = makeEmployee(SALARY);
    $loanC = makeLoan($empC, 1000.00, 500.00, 1000.00);

    $pay1 = $loans->recordPayment($loanC, ['amount' => 600.00], $userId);
    checkMoney('the first payment leaves 400.00', 400.00, (float) ($pay1['balance'] ?? 0));
    checkSame('the loan stays ACTIVE', 'ACTIVE', (string) ($pay1['status'] ?? ''));

    $overpaid = false;
    try {
        // 600.00 over a 400.00 balance must be refused, never clamped silently.
        $loans->recordPayment($loanC, ['amount' => 600.00], $userId);
    } catch (ValidationException $e) {
        $overpaid = isset($e->errors()['amount'])
            && stripos((string) $e->errors()['amount'], 'cannot exceed') !== false;
    }
    check('an overpayment is refused with the outstanding amount', $overpaid);
    checkMoney('the refusal did not move the balance', 400.00, loanBalance($loanC));

    $pay2 = $loans->recordPayment($loanC, ['amount' => 400.00], $userId);
    checkMoney('the final payment settles the loan', 0.00, (float) ($pay2['balance'] ?? -1));
    checkSame('a settled loan flips to PAID', 'PAID', (string) ($pay2['status'] ?? ''));

    $refusedOnPaid = false;
    try {
        $loans->recordPayment($loanC, ['amount' => 1.00], $userId);
    } catch (RuntimeException $e) {
        $refusedOnPaid = stripos($e->getMessage(), 'already fully paid') !== false;
    }
    check('a settled loan refuses further payments', $refusedOnPaid);

    $badAmount = false;
    try {
        $loans->recordPayment($loanA, ['amount' => 0], $userId);
    } catch (ValidationException $e) {
        $badAmount = isset($e->errors()['amount']);
    }
    check('a zero or negative payment is rejected by validation', $badAmount);

    $loanD = makeLoan($empC, 500.00, 100.00, 500.00);
    $loans->cancel($loanD, $userId, 'loan management test');
    $refusedOnCancelled = false;
    try {
        $loans->recordPayment($loanD, ['amount' => 100.00], $userId);
    } catch (RuntimeException $e) {
        $refusedOnCancelled = stripos($e->getMessage(), 'cancelled') !== false;
    }
    check('a cancelled loan refuses payments', $refusedOnCancelled);

    // -----------------------------------------------------------------------
    heading('7. create() requires an explicit, valid instalment');
    // -----------------------------------------------------------------------
    $base = [
        'employee_id'      => $empC,
        'loan_type'        => 'SALARY_LOAN',
        'principal_amount' => 2400.00,
        'start_date'       => '2026-01-01',
    ];

    $missingInstalment = false;
    try {
        $loans->create($base, $userId);
    } catch (ValidationException $e) {
        $missingInstalment = isset($e->errors()['monthly_deduction']);
    }
    check('a loan without a monthly deduction is refused', $missingInstalment);

    $tooLarge = false;
    try {
        $loans->create(array_merge($base, ['monthly_deduction' => 2600.00]), $userId);
    } catch (ValidationException $e) {
        $tooLarge = isset($e->errors()['monthly_deduction'])
            && stripos((string) $e->errors()['monthly_deduction'], 'cannot exceed') !== false;
    }
    check('an instalment above the principal is refused', $tooLarge);

    $badBalance = false;
    try {
        $loans->create(array_merge($base, ['monthly_deduction' => 400.00, 'balance' => 2500.00]), $userId);
    } catch (ValidationException $e) {
        $badBalance = isset($e->errors()['balance']);
    }
    check('a balance above the principal is refused', $badBalance);

    $created = $loans->create(array_merge($base, ['monthly_deduction' => 400.00]), $userId);
    checkMoney('a valid loan keeps its explicit instalment', 400.00, (float) ($created['monthly_deduction'] ?? 0));
    checkMoney('a valid loan starts fully outstanding', 2400.00, (float) ($created['balance'] ?? 0));
    checkSame('a valid loan is filed as PENDING', 'PENDING', (string) ($created['status'] ?? ''));
    checkSame('the filing carries no approver', null, $created['approved_by'] ?? null);

    // -----------------------------------------------------------------------
    heading('8. Approval workflow: PENDING -> ACTIVE / REJECTED (Phase 3B)');
    // -----------------------------------------------------------------------
    // A second real account has to decide what the first one files, otherwise
    // self-approval prevention would make the module unusable.
    $approverId = (int) (Database::scalar(
        "SELECT id FROM users
          WHERE id <> :id AND status = 'ACTIVE' AND deleted_at IS NULL
          ORDER BY id LIMIT 1",
        ['id' => $userId]
    ) ?? 0);

    check('a second active account exists to act as the approver', $approverId > 0,
        'the approval workflow needs two users');

    $empD = makeEmployee(SALARY);
    addPresentDays($empD, consecutiveDates(PER_A_START, 15));

    $filed = $loans->create([
        'employee_id'       => $empD,
        'loan_type'         => 'CASH_ADVANCE',
        'principal_amount'  => 1200.00,
        'monthly_deduction' => 600.00,
        'start_date'        => PER_A_START,
    ], $userId);
    $filedId = (int) $filed['id'];

    checkSame('the filed loan is PENDING in the database', 'PENDING', loanStatus($filedId));
    checkSame('PENDING is labelled for the pages', 'Awaiting approval', (string) ($filed['status_label'] ?? ''));
    checkSame('a filed loan is not deducting', false, (bool) ($filed['is_deducting'] ?? true));
    checkSame('the filing is flagged as pending', true, (bool) ($filed['is_pending'] ?? false));
    checkSame('the filing carries no approval timestamp', null, $filed['approved_at'] ?? null);

    // Payroll must ignore it: a filing is not a deduction.
    $calcPending = $engine->calculateEmployee(employeeRow($empD), PER_A_START, PER_B_END);
    checkSame('the engine proposes no instalment for a pending loan', 0,
        count((array) ($calcPending['loan_allocations'] ?? [])));
    checkMoney('no LOAN deduction line is produced for a pending loan', 0.0,
        itemAmount((array) $calcPending['deductions'], 'LOAN'));

    $blockedPayment = false;
    try {
        $loans->recordPayment($filedId, ['amount' => 100.00], $approverId);
    } catch (RuntimeException $e) {
        $blockedPayment = stripos($e->getMessage(), 'awaiting approval') !== false;
    }
    check('a pending loan refuses a repayment', $blockedPayment);
    checkSame('the refusal wrote no ledger row', 0, ledgerCount($filedId));

    // Self-approval prevention: the filer cannot decide their own loan.
    $selfApproved = false;
    try {
        $loans->approve($filedId, $userId);
    } catch (RuntimeException $e) {
        $selfApproved = stripos($e->getMessage(), 'filed yourself') !== false;
    }
    check('the user who filed the loan cannot approve it', $selfApproved);
    checkSame('the refused self-approval left it PENDING', 'PENDING', loanStatus($filedId));

    $selfRejected = false;
    try {
        $loans->reject($filedId, 'changed my mind', $userId);
    } catch (RuntimeException $e) {
        $selfRejected = stripos($e->getMessage(), 'filed yourself') !== false;
    }
    check('the user who filed the loan cannot reject it either', $selfRejected);
    checkSame('the refused self-rejection left it PENDING', 'PENDING', loanStatus($filedId));

    // Withdrawing a filing and restoring it must not skip the approval.
    $loans->cancel($filedId, $approverId, 'withdrawn while pending');
    checkSame('a filing can be withdrawn', 'CANCELLED', loanStatus($filedId));

    $restored = $loans->restore($filedId, $approverId);
    checkSame('restoring a withdrawn filing returns it to PENDING', 'PENDING', (string) ($restored['status'] ?? ''));
    checkSame('the restored filing is still undecided', null, $restored['approved_at'] ?? null);

    // Another approver - and only another approver - moves it into the rotation.
    $approved = $loans->approve($filedId, $approverId);
    checkSame('a different approver moves the loan to ACTIVE', 'ACTIVE', (string) ($approved['status'] ?? ''));
    checkSame('the approver is stamped on the loan', $approverId, (int) ($approved['approved_by'] ?? 0));
    check('the approval is timestamped', !empty($approved['approved_at']));
    checkSame('an approved loan deducts', true, (bool) ($approved['is_deducting'] ?? false));

    $approvedTwice = false;
    try {
        $loans->approve($filedId, $approverId);
    } catch (RuntimeException $e) {
        $approvedTwice = stripos($e->getMessage(), 'awaiting approval') !== false;
    }
    check('a loan can only be approved once', $approvedTwice);

    $calcApproved = $engine->calculateEmployee(employeeRow($empD), PER_A_START, PER_B_END);
    checkSame('the engine now proposes exactly one instalment', 1,
        count((array) ($calcApproved['loan_allocations'] ?? [])));
    checkMoney('the approved instalment is the per-period split',
        $engine->loanInstalmentForPeriod(600.00, $settings),
        itemAmount((array) $calcApproved['deductions'], 'LOAN'));

    // Rejection needs a reason, and it is terminal.
    $empE = makeEmployee(SALARY);
    $toReject = $loans->create([
        'employee_id'       => $empE,
        'loan_type'         => 'EMERGENCY_LOAN',
        'principal_amount'  => 800.00,
        'monthly_deduction' => 200.00,
        'start_date'        => PER_A_START,
    ], $approverId);
    $toRejectId = (int) $toReject['id'];

    $blankReason = false;
    try {
        $loans->reject($toRejectId, '   ', $userId);
    } catch (ValidationException $e) {
        $blankReason = isset($e->errors()['rejection_reason']);
    }
    check('rejecting without a reason is refused', $blankReason);
    checkSame('the refused rejection left it PENDING', 'PENDING', loanStatus($toRejectId));

    $rejected = $loans->reject($toRejectId, 'Principal is above the loan ceiling', $userId);
    checkSame('a rejection moves the loan to REJECTED', 'REJECTED', (string) ($rejected['status'] ?? ''));
    checkSame('the reason is kept on the record', 'Principal is above the loan ceiling',
        (string) ($rejected['rejection_reason'] ?? ''));
    checkSame('the deciding user is recorded', $userId, (int) ($rejected['approved_by'] ?? 0));
    checkSame('REJECTED is labelled for the pages', 'Rejected', (string) ($rejected['status_label'] ?? ''));
    checkSame('a rejected loan is flagged as rejected', true, (bool) ($rejected['is_rejected'] ?? false));

    $rejectedThenApproved = false;
    try {
        $loans->approve($toRejectId, $approverId);
    } catch (RuntimeException $e) {
        $rejectedThenApproved = stripos($e->getMessage(), 'awaiting approval') !== false;
    }
    check('a rejected loan cannot be approved afterwards', $rejectedThenApproved);

    $rejectedThenPaid = false;
    try {
        $loans->recordPayment($toRejectId, ['amount' => 50.00], $userId);
    } catch (RuntimeException $e) {
        $rejectedThenPaid = stripos($e->getMessage(), 'rejected') !== false;
    }
    check('a rejected loan refuses repayments', $rejectedThenPaid);
    checkSame('the refusal wrote no ledger row', 0, ledgerCount($toRejectId));

    $rejectedThenEdited = false;
    try {
        $loans->update($toRejectId, ['notes' => 'revive me'], $userId);
    } catch (RuntimeException $e) {
        $rejectedThenEdited = stripos($e->getMessage(), 'rejected') !== false;
    }
    check('a rejected loan cannot be edited back into the queue', $rejectedThenEdited);

    $rejectedThenCancelled = false;
    try {
        $loans->cancel($toRejectId, $userId, 'no');
    } catch (RuntimeException $e) {
        $rejectedThenCancelled = stripos($e->getMessage(), 'rejected') !== false;
    }
    check('a rejected loan cannot be cancelled', $rejectedThenCancelled);
    checkSame('it is still REJECTED after every refusal', 'REJECTED', loanStatus($toRejectId));

    // Portfolio figures separate the decisions that are still open.
    $summary = $loans->summary();
    $expectedPending  = (int) Database::scalar("SELECT COUNT(*) FROM loans WHERE status = 'PENDING'");
    $expectedRejected = (int) Database::scalar("SELECT COUNT(*) FROM loans WHERE status = 'REJECTED'");

    checkSame('the summary counts exactly the loans awaiting approval', $expectedPending,
        (int) ($summary['pending'] ?? -1));
    checkSame('the summary counts exactly the rejected loans', $expectedRejected,
        (int) ($summary['rejected'] ?? -1));
    checkMoney('a rejected loan is not part of the outstanding balance',
        (float) Database::scalar("SELECT COALESCE(SUM(balance), 0) FROM loans WHERE status = 'ACTIVE'"),
        (float) ($summary['outstanding'] ?? -1));

    // End to end through the payroll service: approving is what turns a filing
    // into a payslip deduction.
    $empF = makeEmployee(SALARY);
    addPresentDays($empF, consecutiveDates('2026-01-01', 10));

    $pendingLoan = $loans->create([
        'employee_id'       => $empF,
        'loan_type'         => 'SALARY_LOAN',
        'principal_amount'  => 1500.00,
        'monthly_deduction' => 500.00,
        'start_date'        => '2026-01-01',
    ], $userId);
    $pendingLoanId = (int) $pendingLoan['id'];

    $periodC = $payrollService->createPeriod([
        'start_date' => '2026-01-01',
        'end_date'   => '2026-01-15',
        'pay_date'   => '2026-01-15',
        'name'       => 'Automated loan approval test 2026-01 first half',
    ], $userId);
    $periodCId = (int) $periodC['id'];

    $draftPending = $payrollService->calculate($periodCId, $userId);
    $pendingItem  = Database::selectOne(
        "SELECT pi.amount FROM payroll_items pi
           JOIN payroll p ON p.id = pi.payroll_id
          WHERE p.payroll_period_id = :pid AND p.employee_id = :e AND pi.code = 'LOAN'",
        ['pid' => $periodCId, 'e' => $empF]
    );
    check('no payslip line is saved for a loan awaiting approval', $pendingItem === null);

    $beforeTotal = (float) ($draftPending['loan_repayment_total'] ?? -1);
    $beforeCount = (int) ($draftPending['loan_instalments_proposed'] ?? -1);

    // Independently re-derive what the period SHOULD propose: only ACTIVE
    // loans, each capped at its outstanding balance. The loan waiting for
    // approval is in neither figure, which is the point of the workflow.
    $expectedPeriodTotal = 0.0;
    $expectedPeriodCount = 0;

    foreach (Database::select("SELECT monthly_deduction, balance FROM loans
                                WHERE status = 'ACTIVE' AND balance > 0") as $row) {
        $instalment = round(min(
            $engine->loanInstalmentForPeriod((float) $row['monthly_deduction'], $settings),
            round((float) $row['balance'], 2)
        ), 2);

        if ($instalment <= 0) {
            continue;
        }

        $expectedPeriodTotal = round($expectedPeriodTotal + $instalment, 2);
        $expectedPeriodCount++;
    }

    checkSame('the draft proposes exactly the ACTIVE loans', $expectedPeriodCount, $beforeCount);
    checkMoney('the draft totals exactly the ACTIVE loans - the pending one contributes nothing',
        $expectedPeriodTotal, $beforeTotal);

    $loans->approve($pendingLoanId, $approverId);

    $draftApproved = $payrollService->calculate($periodCId, $userId);
    checkSame('approving the loan adds exactly one proposal to the period', $beforeCount + 1,
        (int) ($draftApproved['loan_instalments_proposed'] ?? -1));
    checkMoney('approving the loan adds exactly its instalment to the period total',
        round($beforeTotal + $engine->loanInstalmentForPeriod(500.00, $settings), 2),
        (float) ($draftApproved['loan_repayment_total'] ?? -1));
    checkSame('the approved loan is ACTIVE', 'ACTIVE', loanStatus($pendingLoanId));

    $approvedItem = Database::selectOne(
        "SELECT pi.amount FROM payroll_items pi
           JOIN payroll p ON p.id = pi.payroll_id
          WHERE p.payroll_period_id = :pid AND p.employee_id = :e AND pi.code = 'LOAN'",
        ['pid' => $periodCId, 'e' => $empF]
    );
    checkMoney('the approved loan itemises the instalment on the payslip',
        $engine->loanInstalmentForPeriod(500.00, $settings),
        $approvedItem === null ? -1.0 : (float) $approvedItem['amount']);
} catch (Throwable $e) {
    check('no unexpected exception', false, get_class($e) . ': ' . $e->getMessage() . ' @ ' . $e->getFile() . ':' . $e->getLine());
} finally {
    // Every fixture created above (employees, attendance, loans, periods,
    // payroll rows, payroll items and the repayment ledger) is rolled back
    // here: nothing is ever committed.
    Database::rollBack();
}

echo "\n", $passed, ' passed, ', $failed, " failed\n";

if ($failures !== []) {
    echo "\nFailures:\n";
    foreach ($failures as $failure) {
        echo '  - ', $failure, "\n";
    }
    echo "\nLOAN MANAGEMENT: FAILED\n";
    exit(1);
}

echo "\nLOAN MANAGEMENT: every check passed\n";
exit(0);