<?php
/**
 * Rest day swap / exchange workflow test.
 * Proves the RestDaySwapService mutual-consent lifecycle.
 *
 * Usage:
 *   DB_NAME=attendance_payroll_test php tests/rest_day_swap_test.php
 *
 * Exit code 0 = every check passed, 1 = at least one check failed.
 */

declare(strict_types=1);

use App\Core\Auth;
use App\Core\Database;
use App\Core\ValidationException;
use App\Services\RestDaySwapService;

require dirname(__DIR__) . '/api/autoload.php';

$config = require dirname(__DIR__) . '/api/config/config.php';
date_default_timezone_set((string) ($config['app']['timezone'] ?? 'Asia/Manila'));

require __DIR__ . '/db_guard.php';
pmsAssertSafeTestDatabase();

function mockAuth(array $user): void
{
    $ref = new ReflectionClass(Auth::class);
    $userProp = $ref->getProperty('user');
    $userProp->setAccessible(true);
    $userProp->setValue(null, $user);
    $resolvedProp = $ref->getProperty('resolved');
    $resolvedProp->setAccessible(true);
    $resolvedProp->setValue(null, true);
}

function clearAuth(): void
{
    $ref = new ReflectionClass(Auth::class);
    $userProp = $ref->getProperty('user');
    $userProp->setAccessible(true);
    $userProp->setValue(null, null);
    $resolvedProp = $ref->getProperty('resolved');
    $resolvedProp->setAccessible(true);
    $resolvedProp->setValue(null, false);
}

function roleIdByCode(string $code): int
{
    $row = Database::selectOne('SELECT id FROM roles WHERE code = :code LIMIT 1', ['code' => $code]);
    if ($row === null) {
        throw new RuntimeException("Role '$code' not found.");
    }
    return (int) $row['id'];
}

function makeUser(
    int $employeeId,
    string $username,
    string $roleCode,
    array $permissions,
    string $status = 'ACTIVE'
): int {
    return Database::insert('users', [
        'username'             => $username,
        'email'                => $username . '@example.test',
        'password_hash'        => 'x',
        'full_name'            => ucfirst($username),
        'role_id'              => roleIdByCode($roleCode),
        'employee_id'          => $employeeId,
        'status'               => $status,
        'must_change_password' => 0,
        'created_at'           => date('Y-m-d H:i:s'),
    ]);
}

function ensureManagerPerms(): void
{
    $mgr = Database::selectOne(
        "SELECT id, permissions FROM roles WHERE code = 'MANAGER' LIMIT 1"
    );
    if ($mgr === null) {
        return;
    }
    $perms = json_decode((string) ($mgr['permissions'] ?? '[]'), true);
    if (!is_array($perms)) {
        $perms = [];
    }
    $added = false;
    foreach (['rest_day_swap.approve', 'rest_day_swap.view'] as $p) {
        if (!in_array($p, $perms, true)) {
            $perms[] = $p;
            $added = true;
        }
    }
    if ($added) {
        Database::update(
            'roles',
            ['permissions' => json_encode($perms)],
            ['id' => (int) $mgr['id']]
        );
    }
}

$passed   = 0;
$failed   = 0;
$failures = [];

function check(string $label, $ok, string $detail = ''): void
{
    global $passed, $failed, $failures;
    if ($ok instanceof \Closure) {
        $ok = $ok();
    }
    if ($ok) {
        $passed++;
        echo "  PASS  $label\n";
        return;
    }
    $failed++;
    $failures[] = $label;
    echo "  FAIL  $label\n";
    if ($detail !== '') {
        echo "        $detail\n";
    }
}

function heading(string $title): void
{
    echo "\n", $title, "\n", str_repeat('-', strlen($title)), "\n";
}

$service = new RestDaySwapService();

$EMP_REQUESTER = 1;
$EMP_OTHER     = 2;
const EFFECTIVE_DATE = '2026-10-19';
ensureManagerPerms();

// Ensure employee records exist for manager/admin users.
function ensureEmployee(int $id, string $number, string $first, string $last): void
{
    $exists = Database::selectOne('SELECT id FROM employees WHERE id = :id', ['id' => $id]);
    if ($exists === null) {
        Database::insert('employees', [
            'id'                 => $id,
            'employee_number'    => $number,
            'first_name'         => $first,
            'last_name'          => $last,
            'gender'             => 'OTHER',
            'date_hired'         => '2024-01-01',
            'employment_type'    => 'FULL_TIME',
            'salary_type'        => 'MONTHLY',
            'basic_salary'       => 20000.00,
            'status'             => 'ACTIVE',
            'work_schedule_id'   => 1,
        ]);
    }
}
ensureEmployee(998, 'EMP-ADMIN-' . uniqid(), 'Admin', 'User');
ensureEmployee(999, 'EMP-MGR-' . uniqid(), 'Manager', 'User');

// Clean up any leftover swaps from previous runs for the test employees.
Database::run(
    'DELETE FROM rest_day_swaps WHERE requester_id IN (:r1, :r2) OR other_employee_id IN (:o1, :o2)',
    ['r1' => $EMP_REQUESTER, 'r2' => $EMP_OTHER, 'o1' => $EMP_REQUESTER, 'o2' => $EMP_OTHER]
);

// Create users for the employees so we can attach them to Auth.
$USER_REQUESTER = makeUser($EMP_REQUESTER, 'req_staff_' . uniqid(), 'STAFF', [
    'rest_day_swap.create',
    'rest_day_swap.view_own',
]);
$USER_OTHER     = makeUser($EMP_OTHER, 'oth_staff_' . uniqid(), 'STAFF', [
    'rest_day_swap.create',
    'rest_day_swap.view_own',
]);
$USER_MANAGER   = makeUser(999, 'mgr_approve_' . uniqid(), 'MANAGER', [
    'rest_day_swap.approve',
    'rest_day_swap.view',
]);
$USER_ADMIN     = makeUser(998, 'admin_all_' . uniqid(), 'ADMIN', ['*']);

function baseRequest(): array
{
    return [
        'requester_id'           => $GLOBALS['EMP_REQUESTER'],
        'other_employee_id'      => $GLOBALS['EMP_OTHER'],
        'requester_original_dow' => 0,
        'other_original_dow'     => 6,
        'effective_date'         => EFFECTIVE_DATE,
        'reason'                 => 'Need to attend a family event on Sunday.',
    ];
}
// 1. CREATE
heading('1.  Create swap request');

check('create: valid request returns PENDING swap', function () use ($service): bool {
    mockAuth([
        'id'         => $GLOBALS['USER_REQUESTER'],
        'username'   => 'req_staff',
        'employee_id' => $GLOBALS['EMP_REQUESTER'],
        'role_code'  => 'STAFF',
        'permissions'=> ['rest_day_swap.create', 'rest_day_swap.view_own'],
    ]);
    $swap = $service->create(baseRequest());
    clearAuth();
    return $swap !== null
        && $swap['status'] === RestDaySwapService::STATUS_PENDING
        && $swap['other_consent'] === RestDaySwapService::CONSENT_PENDING
        && $swap['manager_decision'] === RestDaySwapService::DECISION_PENDING
        && $swap['requester_id'] === $GLOBALS['EMP_REQUESTER']
        && $swap['other_employee_id'] === $GLOBALS['EMP_OTHER']
        && (int) $swap['requester_original_dow'] === 0
        && (int) $swap['other_original_dow'] === 6
        && $swap['effective_date'] === EFFECTIVE_DATE;
}, '');

check('create: self-swap rejected', function () use ($service): bool {
    mockAuth([
        'id'         => $GLOBALS['USER_REQUESTER'],
        'employee_id' => $GLOBALS['EMP_REQUESTER'],
        'role_code'  => 'STAFF',
        'permissions'=> ['rest_day_swap.create'],
    ]);
    $req = baseRequest();
    $req['other_employee_id'] = $GLOBALS['EMP_REQUESTER'];
    try {
        $service->create($req);
        clearAuth();
        return false;
    } catch (\Throwable $e) {
        clearAuth();
        return $e instanceof ValidationException;
    }
}, '');

check('create: inactive employee rejected', function () use ($service): bool {
    mockAuth([
        'id'         => $GLOBALS['USER_REQUESTER'],
        'employee_id' => $GLOBALS['EMP_REQUESTER'],
        'role_code'  => 'STAFF',
        'permissions'=> ['rest_day_swap.create'],
    ]);
    $req = baseRequest();
    $req['other_employee_id'] = 4;
    try {
        $service->create($req);
        clearAuth();
        return false;
    } catch (\Throwable $e) {
        clearAuth();
        return $e instanceof ValidationException;
    }
}, '');

check('create: wrong requester rest day rejected', function () use ($service): bool {
    mockAuth([
        'id'         => $GLOBALS['USER_REQUESTER'],
        'employee_id' => $GLOBALS['EMP_REQUESTER'],
        'role_code'  => 'STAFF',
        'permissions'=> ['rest_day_swap.create'],
    ]);
    $req = baseRequest();
    $req['requester_original_dow'] = 1;
    try {
        $service->create($req);
        clearAuth();
        return false;
    } catch (\Throwable $e) {
        clearAuth();
        return $e instanceof ValidationException;
    }
}, '');

check('create: duplicate same-date request rejected', function () use ($service): bool {
    $req2 = baseRequest();
    $req2['other_employee_id'] = 3;
    try {
        $service->create($req2);
        return false;
    } catch (\Throwable $e) {
        return $e instanceof ValidationException;
    }
}, '');

check('create: duplicate same-date for same other rejected', function () use ($service): bool {
    $req3 = baseRequest();
    $req3['requester_id'] = 3;
    try {
        $service->create($req3);
        return false;
    } catch (\Throwable $e) {
        return $e instanceof ValidationException;
    }
}, '');
// 2. RESPOND
heading('2.  Respond (accept / decline)');

function respondSwap(): int
{
    global $service;
    // Clean up any existing swaps for these employees so we can create fresh.
    Database::run(
        'DELETE FROM rest_day_swaps WHERE requester_id IN (:r1, :r2) OR other_employee_id IN (:o1, :o2)',
        ['r1' => $GLOBALS['EMP_REQUESTER'], 'r2' => $GLOBALS['EMP_OTHER'], 'o1' => $GLOBALS['EMP_REQUESTER'], 'o2' => $GLOBALS['EMP_OTHER']]
    );
    $s = $service->create(baseRequest());
    return (int) $s['id'];
}

$swapId = respondSwap();

check('respond: other employee accepts', function () use ($swapId, $service): bool {
    mockAuth([
        'id'         => $GLOBALS['USER_OTHER'],
        'employee_id' => $GLOBALS['EMP_OTHER'],
        'role_code'  => 'STAFF',
        'permissions'=> ['rest_day_swap.view_own'],
    ]);
    $result = $service->respond($swapId, ['action' => 'ACCEPT'], $GLOBALS['USER_OTHER']);
    clearAuth();
    return $result['other_consent'] === RestDaySwapService::CONSENT_ACCEPTED
        && $result['status'] === RestDaySwapService::STATUS_PENDING;
}, '');

check('respond: decline requires reason', function () use ($swapId, $service): bool {
    $freshId = respondSwap();
    mockAuth([
        'id'         => $GLOBALS['USER_OTHER'],
        'employee_id' => $GLOBALS['EMP_OTHER'],
        'role_code'  => 'STAFF',
        'permissions'=> ['rest_day_swap.view_own'],
    ]);
    try {
        $service->respond($freshId, ['action' => 'DECLINE'], $GLOBALS['USER_OTHER']);
        clearAuth();
        return false;
    } catch (\Throwable $e) {
        clearAuth();
        return $e instanceof ValidationException;
    }
}, '');

check('respond: decline with reason sets REJECTED', function () use ($service): bool {
    $freshId = respondSwap();
    mockAuth([
        'id'         => $GLOBALS['USER_OTHER'],
        'employee_id' => $GLOBALS['EMP_OTHER'],
        'role_code'  => 'STAFF',
        'permissions'=> ['rest_day_swap.view_own'],
    ]);
    $result = $service->respond(
        $freshId,
        ['action' => 'DECLINE', 'reason' => 'Not available that weekend.'],
        $GLOBALS['USER_OTHER']
    );
    clearAuth();
    return $result['other_consent'] === RestDaySwapService::CONSENT_DECLINED
        && $result['status'] === RestDaySwapService::STATUS_REJECTED
        && $result['manager_remarks'] === 'Declined by other employee: Not available that weekend.';
}, '');

check('respond: non-other employee rejected', function () use ($swapId, $service): bool {
    $freshId = respondSwap();
    mockAuth([
        'id'         => $GLOBALS['USER_REQUESTER'],
        'employee_id' => $GLOBALS['EMP_REQUESTER'],
        'role_code'  => 'STAFF',
        'permissions'=> ['rest_day_swap.view_own'],
    ]);
    try {
        $service->respond($freshId, ['action' => 'ACCEPT', 'reason' => 'x'], $GLOBALS['USER_REQUESTER']);
        clearAuth();
        return false;
    } catch (\Throwable $e) {
        clearAuth();
        return $e instanceof ValidationException;
    }
}, '');

check('respond: already responded cannot respond again', function () use ($service): bool {
    $freshId = respondSwap();
    mockAuth([
        'id'         => $GLOBALS['USER_OTHER'],
        'employee_id' => $GLOBALS['EMP_OTHER'],
        'role_code'  => 'STAFF',
        'permissions'=> ['rest_day_swap.view_own'],
    ]);
    $service->respond($freshId, ['action' => 'ACCEPT'], $GLOBALS['USER_OTHER']);
    clearAuth();
    try {
        $service->respond($freshId, ['action' => 'DECLINE', 'reason' => 'changed mind'], $GLOBALS['USER_OTHER']);
        return false;
    } catch (\Throwable $e) {
        return $e instanceof \RuntimeException;
    }
}, '');
// 3. APPROVE / REJECT
heading('3.  Approve / reject (manager)');

function approvedSwapId(): int
{
    global $service;
    $sid = respondSwap();
    mockAuth([
        'id'         => $GLOBALS['USER_OTHER'],
        'employee_id' => $GLOBALS['EMP_OTHER'],
        'role_code'  => 'STAFF',
        'permissions'=> ['rest_day_swap.view_own'],
    ]);
    $service->respond($sid, ['action' => 'ACCEPT'], $GLOBALS['USER_OTHER']);
    clearAuth();
    mockAuth([
        'id'         => $GLOBALS['USER_MANAGER'],
        'employee_id' => 999,
        'role_code'  => 'MANAGER',
        'permissions'=> ['rest_day_swap.approve', 'rest_day_swap.view'],
    ]);
    $result = $service->approve($sid, ['remarks' => 'Looks good.'], $GLOBALS['USER_MANAGER']);
    clearAuth();
    return (int) $result['id'];
}

check('approve: manager approves after both consent', function () use ($service): bool {
    $sid = approvedSwapId();
    $swap = $service->find($sid);
    return $swap['status'] === RestDaySwapService::STATUS_APPROVED
        && $swap['manager_decision'] === RestDaySwapService::DECISION_APPROVED
        && $swap['manager_id'] === $GLOBALS['USER_MANAGER'];
}, '');

check('approve: schedules updated after approval', function () use ($service): bool {
    $sid = approvedSwapId();
    $requester = Database::selectOne(
        'SELECT work_schedule_id FROM employees WHERE id = :id',
        ['id' => $GLOBALS['EMP_REQUESTER']]
    );
    $other = Database::selectOne(
        'SELECT work_schedule_id FROM employees WHERE id = :id',
        ['id' => $GLOBALS['EMP_OTHER']]
    );
    return $requester !== null && $other !== null
        && (int) $requester['work_schedule_id'] > 0
        && (int) $other['work_schedule_id'] > 0;
}, '');

check('approve: non-manager rejected', function () use ($service): bool {
    $sid = respondSwap();
    mockAuth([
        'id'         => $GLOBALS['USER_OTHER'],
        'employee_id' => $GLOBALS['EMP_OTHER'],
        'role_code'  => 'STAFF',
        'permissions'=> ['rest_day_swap.view_own'],
    ]);
    try {
        $service->approve($sid, ['remarks' => 'nope'], $GLOBALS['USER_OTHER']);
        clearAuth();
        return false;
    } catch (\Throwable $e) {
        clearAuth();
        return $e instanceof ValidationException;
    }
}, '');

check('approve: before other consent rejected', function () use ($service): bool {
    $sid = respondSwap();
    mockAuth([
        'id'         => $GLOBALS['USER_MANAGER'],
        'employee_id' => 999,
        'role_code'  => 'MANAGER',
        'permissions'=> ['rest_day_swap.approve', 'rest_day_swap.view'],
    ]);
    try {
        $service->approve($sid, ['remarks' => 'too early'], $GLOBALS['USER_MANAGER']);
        clearAuth();
        return false;
    } catch (\Throwable $e) {
        clearAuth();
        return $e instanceof \RuntimeException;
    }
}, '');

check('approve: already decided cannot approve', function () use ($service): bool {
    $sid = respondSwap();
    mockAuth([
        'id'         => $GLOBALS['USER_OTHER'],
        'employee_id' => $GLOBALS['EMP_OTHER'],
        'role_code'  => 'STAFF',
        'permissions'=> ['rest_day_swap.view_own'],
    ]);
    $service->respond($sid, ['action' => 'DECLINE', 'reason' => 'no'], $GLOBALS['USER_OTHER']);
    clearAuth();
    mockAuth([
        'id'         => $GLOBALS['USER_MANAGER'],
        'employee_id' => 999,
        'role_code'  => 'MANAGER',
        'permissions'=> ['rest_day_swap.approve', 'rest_day_swap.view'],
    ]);
    try {
        $service->approve($sid, ['remarks' => 'nope'], $GLOBALS['USER_MANAGER']);
        clearAuth();
        return false;
    } catch (\Throwable $e) {
        clearAuth();
        return $e instanceof \RuntimeException;
    }
}, '');

// 4. REJECT
heading('4.  Reject (manager)');

check('reject: manager rejects pending swap', function () use ($service): bool {
    $sid = respondSwap();
    mockAuth([
        'id'         => $GLOBALS['USER_OTHER'],
        'employee_id' => $GLOBALS['EMP_OTHER'],
        'role_code'  => 'STAFF',
        'permissions'=> ['rest_day_swap.view_own'],
    ]);
    $service->respond($sid, ['action' => 'ACCEPT'], $GLOBALS['USER_OTHER']);
    clearAuth();
    mockAuth([
        'id'         => $GLOBALS['USER_MANAGER'],
        'employee_id' => 999,
        'role_code'  => 'MANAGER',
        'permissions'=> ['rest_day_swap.approve', 'rest_day_swap.view'],
    ]);
    $result = $service->reject($sid, ['remarks' => 'Business needs.'], $GLOBALS['USER_MANAGER']);
    clearAuth();
    return $result['status'] === RestDaySwapService::STATUS_REJECTED
        && $result['manager_decision'] === RestDaySwapService::DECISION_REJECTED
        && $result['manager_id'] === $GLOBALS['USER_MANAGER']
        && $result['manager_remarks'] === 'Business needs.';
}, '');
// 5. CANCEL
heading('5.  Cancel (requester / admin)');

check('cancel: requester cancels own pending swap', function () use ($service): bool {
    $sid = respondSwap();
    mockAuth([
        'id'         => $GLOBALS['USER_REQUESTER'],
        'employee_id' => $GLOBALS['EMP_REQUESTER'],
        'role_code'  => 'STAFF',
        'permissions'=> ['rest_day_swap.view_own'],
    ]);
    $result = $service->cancel($sid, $GLOBALS['USER_REQUESTER']);
    clearAuth();
    return $result['status'] === RestDaySwapService::STATUS_CANCELLED;
}, '');

check('cancel: admin cancels any pending swap', function () use ($service): bool {
    $sid = respondSwap();
    mockAuth([
        'id'         => $GLOBALS['USER_ADMIN'],
        'employee_id' => 998,
        'role_code'  => 'ADMIN',
        'permissions'=> ['*'],
    ]);
    $result = $service->cancel($sid, $GLOBALS['USER_ADMIN']);
    clearAuth();
    return $result['status'] === RestDaySwapService::STATUS_CANCELLED;
}, '');

check('cancel: non-requester non-admin rejected', function () use ($service): bool {
    $sid = respondSwap();
    mockAuth([
        'id'         => $GLOBALS['USER_OTHER'],
        'employee_id' => $GLOBALS['EMP_OTHER'],
        'role_code'  => 'STAFF',
        'permissions'=> ['rest_day_swap.view_own'],
    ]);
    try {
        $service->cancel($sid, $GLOBALS['USER_OTHER']);
        clearAuth();
        return false;
    } catch (\Throwable $e) {
        clearAuth();
        return $e instanceof ValidationException;
    }
}, '');

// 6. CROSS-SCHEDULE
heading('6.  Schedule update after approval (cross-schedule)');

function crossScheduleSwap(): array
{
    global $service;
    $empA = Database::insert('employees', [
        'employee_number'     => 'RDSTEST-A-' . uniqid(),
        'first_name'          => 'Rds',
        'last_name'           => 'TestA',
        'gender'              => 'MALE',
        'date_hired'          => '2024-01-01',
        'employment_type'     => 'FULL_TIME',
        'salary_type'         => 'MONTHLY',
        'basic_salary'        => 20000.00,
        'status'              => 'ACTIVE',
        'work_schedule_id'    => 1,
    ]);
    $empB = Database::insert('employees', [
        'employee_number'     => 'RDSTEST-B-' . uniqid(),
        'first_name'          => 'Rds',
        'last_name'           => 'TestB',
        'gender'              => 'FEMALE',
        'date_hired'          => '2024-01-01',
        'employment_type'     => 'FULL_TIME',
        'salary_type'         => 'MONTHLY',
        'basic_salary'        => 20000.00,
        'status'              => 'ACTIVE',
        'work_schedule_id'    => 2,
    ]);
    $swap = $service->create([
        'requester_id'           => $empA,
        'other_employee_id'      => $empB,
        'requester_original_dow' => 0,
        'other_original_dow'     => 0,
        'effective_date'         => '2026-10-26',
        'reason'                 => 'Cross-schedule swap test.',
    ]);
    $sid = (int) $swap['id'];
    mockAuth([
        'id'         => 9001,
        'employee_id' => $empB,
        'role_code'  => 'STAFF',
        'permissions'=> ['rest_day_swap.view_own'],
    ]);
    $service->respond($sid, ['action' => 'ACCEPT'], 9001);
    clearAuth();
    mockAuth([
        'id'         => $GLOBALS['USER_MANAGER'],
        'employee_id' => 999,
        'role_code'  => 'MANAGER',
        'permissions'=> ['rest_day_swap.approve', 'rest_day_swap.view'],
    ]);
    $result = $service->approve($sid, ['remarks' => 'Cross schedule ok.'], $GLOBALS['USER_MANAGER']);
    clearAuth();
    return ['empA' => $empA, 'empB' => $empB, 'swap' => $result];
}

check('approve: cross-schedule assigns new work_schedule_id', function () use ($service): bool {
    $cs = crossScheduleSwap();
    $empA = Database::selectOne(
        'SELECT work_schedule_id FROM employees WHERE id = :id',
        ['id' => $cs['empA']]
    );
    $empB = Database::selectOne(
        'SELECT work_schedule_id FROM employees WHERE id = :id',
        ['id' => $cs['empB']]
    );
    $ok = $empA !== null && $empB !== null
        && (int) $empA['work_schedule_id'] > 0
        && (int) $empB['work_schedule_id'] > 0;
    echo "        empA schedule: " . (int) $empA['work_schedule_id']
        . ", empB schedule: " . (int) $empB['work_schedule_id'] . "\n";
    return $ok;
}, '');
// 7. LIST
heading('7.  List');

check('list: requester sees own swaps', function () use ($service): bool {
    mockAuth([
        'id'         => $GLOBALS['USER_REQUESTER'],
        'employee_id' => $GLOBALS['EMP_REQUESTER'],
        'role_code'  => 'STAFF',
        'permissions'=> ['rest_day_swap.view_own'],
    ]);
    $result = $service->list([], 1, 25);
    clearAuth();
    return isset($result['items']) && is_array($result['items'])
        && $result['total'] >= 1;
}, '');

check('list: manager sees all swaps', function () use ($service): bool {
    mockAuth([
        'id'         => $GLOBALS['USER_MANAGER'],
        'employee_id' => 999,
        'role_code'  => 'MANAGER',
        'permissions'=> ['rest_day_swap.approve', 'rest_day_swap.view'],
    ]);
    $result = $service->list([], 1, 25);
    clearAuth();
    return isset($result['items']) && is_array($result['items']);
}, '');

// Summary
echo "\n";
echo str_repeat('=', 50), "\n";
printf("  Results: %d passed, %d failed\n", $passed, $failed);
if ($failed > 0) {
    echo "  Failures:\n";
    foreach ($failures as $f) {
        echo "    - $f\n";
    }
}
echo str_repeat('=', 50), "\n";

exit($failed > 0 ? 1 : 0);
