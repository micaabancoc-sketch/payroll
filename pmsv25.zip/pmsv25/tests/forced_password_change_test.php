<?php
/**
 * Forced password change flow — end-to-end test over real HTTP.
 *
 * Walks the exact journey an administrator reset creates:
 *
 *   reset -> login with the temporary password -> every normal endpoint is
 *   refused -> only the change-password flow works -> a real password is
 *   chosen -> full access returns and the old temporary password dies.
 *
 * DB-backed assertions are used where HTTP alone cannot see the guarantee
 * (the password is stored hashed, the flag is cleared only on success, the
 * audit trail never records the temporary password). All rows created here
 * are removed again, so a pass leaves the database exactly as it was.
 *
 * Usage: php tests/forced_password_change_test.php [api_base]
 *   api_base defaults to http://localhost/pms/api (override via PMS_API_BASE).
 */

declare(strict_types=1);

// Refuse to touch a production or genuine-use database: this suite creates
// users, employees and audit rows (and removes them again), so it must run
// against a dedicated test database (DB_NAME=attendance_payroll_test).
require __DIR__ . '/db_guard.php';
pmsAssertSafeTestDatabase();

$base = getenv('PMS_API_BASE') ?: ($argv[1] ?? 'http://localhost/pms/api');

const ADMIN_USERNAME       = 'admin';
const ADMIN_PASSWORD       = 'Password123@';
const TEMPORARY_PASSWORD   = '123';
const ORIGINAL_PASSWORD    = 'TempStart@26';
const REPLACEMENT_PASSWORD = 'Workflow@2026';

$passed    = 0;
$failed    = 0;
$failures  = [];

/** @var array<string, mixed> */
$created = [
    'user_id'           => null,
    'user_username'     => null,
    'employee_id'       => null,
    'linked_user_id'    => null,
    'linked_username'   => null,
];

function check(string $label, bool $ok, string $detail = ''): void
{
    global $passed, $failed, $failures;

    if ($ok) {
        $passed++;
        echo "  PASS  $label\n";
        return;
    }

    $failed++;
    $failures[] = $label;
    echo "  FAIL  $label\n";
    echo "        $detail\n";
}

/**
 * One real HTTP call against the running API.
 *
 * @param  array<string, mixed> $body
 * @return array{status:int, json:array<string, mixed>}
 */
function api(string $method, string $path, array $body = [], ?string $token = null): array
{
    global $base;

    $headers = ['Content-Type: application/json', 'Accept: application/json'];
    if ($token !== null) {
        $headers[] = 'Authorization: Bearer ' . $token;
    }

    $options = [
        'http' => [
            'method'        => strtoupper($method),
            'header'        => implode("\r\n", $headers),
            'ignore_errors' => true,
            'timeout'       => 20,
        ],
    ];

    if ($body !== []) {
        $options['http']['content'] = json_encode($body, JSON_UNESCAPED_SLASHES);
    }

    $raw    = @file_get_contents($base . $path, false, stream_context_create($options));
    $status = 0;

    foreach ($http_response_header ?? [] as $line) {
        if (preg_match('#^HTTP/\S+\s+(\d+)#', $line, $m)) {
            $status = (int) $m[1];
        }
    }

    $decoded = json_decode((string) $raw, true);

    return [
        'status' => $status,
        'json'   => is_array($decoded) ? $decoded : [],
    ];
}

function db(): PDO
{
    $config = require dirname(__DIR__) . '/api/config/config.php';
    $db     = $config['database'];

    return new PDO(
        sprintf('mysql:host=%s;port=%d;dbname=%s;charset=utf8mb4', $db['host'], $db['port'], $db['name']),
        $db['user'],
        $db['password'],
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
    );
}

/** @return array<string, mixed>|null */
function dbRow(string $sql, array $params = []): ?array
{
    static $pdo = null;
    $pdo ??= db();

    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $row = $stmt->fetch(PDO::FETCH_ASSOC);

    return $row === false ? null : $row;
}

function dbValue(string $sql, array $params = []): mixed
{
    $row = dbRow($sql, $params);
    return $row === null ? null : reset($row);
}

/** How many live accounts are currently chained to the change flow. */
function flaggedAccounts(): int
{
    return (int) dbValue('SELECT COUNT(*) FROM users WHERE must_change_password = 1 AND deleted_at IS NULL');
}

echo '==============================================' . "\n";
echo ' FORCED PASSWORD CHANGE FLOW TEST' . "\n";
echo '==============================================' . "\n";
echo 'API base: ' . $base . "\n\n";

// ---------------------------------------------------------------------------
// Preflight
// ---------------------------------------------------------------------------
$health = api('GET', '/health');

if ($health['status'] !== 200) {
    fwrite(STDERR, "API is not reachable at {$base} (HTTP {$health['status']}). Start Apache first.\n");
    exit(2);
}

$adminLogin = api('POST', '/auth/login', [
    'username' => ADMIN_USERNAME,
    'password' => ADMIN_PASSWORD,
]);

if ($adminLogin['status'] !== 200) {
    fwrite(STDERR, "Admin sign-in failed (HTTP {$adminLogin['status']}) — is the database seeded?\n");
    exit(3);
}

$adminToken = (string) ($adminLogin['json']['data']['token'] ?? '');
$adminId    = (int) ($adminLogin['json']['data']['user']['id'] ?? 0);

check('Preflight: health check answers', $health['status'] === 200);
check('Preflight: admin can sign in', $adminToken !== '', 'no token in login response');

// The database may already hold accounts chained to the flow (seeded demo
// users, earlier manual runs), so every flag assertion below is expressed as a
// delta against this snapshot instead of an absolute number.
$flagsBefore = flaggedAccounts();

echo "\n--- The reset issues one shared temporary password ---------------\n";

// ---------------------------------------------------------------------------
// Scenario 1: an administrator reset issues exactly the shared temporary
// password, hashes it, flags the account and never returns the hash.
// ---------------------------------------------------------------------------
$suffix   = (string) time();
$username = 'fc' . $suffix;

$createUser = api('POST', '/users', [
    'username'  => $username,
    'full_name' => 'Forced Change Probe',
    'role_id'   => (int) dbValue('SELECT id FROM roles WHERE id != 1 ORDER BY id LIMIT 1'),
    'password'  => ORIGINAL_PASSWORD,
], $adminToken);

$created['user_username'] = $username;
$created['user_id']       = $createUser['json']['data']['id'] ?? null;

if ($createUser['status'] < 200 || $createUser['status'] >= 300 || $created['user_id'] === null) {
    check('1. A disposable user account can be created', false, 'create failed: ' . json_encode($createUser));
    // Without an account there is nothing left to test.
    goto FINISH;
}

$createdUserId = (int) $created['user_id'];

$userId = (int) dbValue('SELECT id FROM users WHERE id = :id', ['id' => $createdUserId]);
$before = dbRow(
    'SELECT password_hash, must_change_password FROM users WHERE id = :id',
    ['id' => $userId]
);

check('1. account starts unflagged and unusable-temp-free',
    (int) ($before['must_change_password'] ?? -1) === 0
        && password_verify(TEMPORARY_PASSWORD, (string) $before['password_hash']) === false,
    'new accounts must not ship with the temporary password or the forced flag');

$reset = api('POST', "/users/{$userId}/reset-password", [], $adminToken);
$data  = $reset['json']['data'] ?? [];

$stored = dbRow(
    'SELECT password_hash, must_change_password FROM users WHERE id = :id',
    ['id' => $userId]
);

$auditRows = (function () use ($userId): array {
    $pdo = db();
    $stmt = $pdo->prepare(
        'SELECT description, old_value, new_value FROM audit_logs WHERE entity_id = :eid'
    );
    $stmt->execute(['eid' => (string) $userId]);
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
})();

$leakFound = false;
foreach ($auditRows as $row) {
    $text = str_replace($username, '', implode('|', array_map(function ($v) {
        return (string) $v;
    }, $row)));

    if (strpos($text, TEMPORARY_PASSWORD) !== false) {
        $leakFound = true;
    }
}

check('1a. reset returns HTTP 200 and temporary_password = "123"',
    $reset['status'] === 200 && ($data['temporary_password'] ?? null) === TEMPORARY_PASSWORD,
    'response: ' . json_encode($reset));
check('1b. reset response never returns the stored hash',
    !isset($data['password_hash']) && !isset($data['hash']),
    'keys: ' . implode(',', array_keys($data)));
check('1c. reset stores the password hashed, not as plaintext',
    $stored !== null
        && $stored['password_hash'] !== TEMPORARY_PASSWORD
        && password_verify(TEMPORARY_PASSWORD, (string) $stored['password_hash']),
    'stored hash is not the plaintext value');
check('1d. reset flags the account (must_change_password = 1)',
    (int) ($stored['must_change_password'] ?? 0) === 1,
    'must_change_password = ' . ($stored['must_change_password'] ?? 'NULL'));
check('1e. reset is audit-logged and the log never contains the temporary password',
    count($auditRows) >= 1 && !$leakFound,
    count($auditRows) . ' audit row(s) for the reset/change');
check('1f. the reset flagged exactly one account and disturbed no other',
    flaggedAccounts() === $flagsBefore + 1,
    'flagged accounts: before=' . $flagsBefore . ', now=' . flaggedAccounts());

echo "\n--- Existing sessions are cut, the admin is untouched ------------\n";

// ---------------------------------------------------------------------------
// Scenario 2: the reset revoked every session the account already had.
// ---------------------------------------------------------------------------
$oldLogin = api('POST', '/auth/login', [
    'username' => $username,
    'password' => ORIGINAL_PASSWORD,
]);

if ($oldLogin['status'] === 200) {
    $oldToken = (string) ($oldLogin['json']['data']['token'] ?? '');

    check('2a. a pre-reset token no longer works anywhere',
        api('GET', '/auth/me', [], $oldToken)['status'] === 401,
        'expected 401, got ' . api('GET', '/auth/me', [], $oldToken)['status']);
} else {
    check('2a. a pre-reset token no longer works anywhere', true, 'skipped: pre-reset login failed');
}

$adminMe = api('GET', '/auth/me', [], $adminToken);

check('2b. the reset never disturbs the administrator session',
    $adminMe['status'] === 200
        && ($adminMe['json']['data']['must_change_password'] ?? null) === false,
    'admin /auth/me failed or is flagged: ' . json_encode($adminMe));

echo "\n--- Signing in with the temporary password ----------------------\n";

// ---------------------------------------------------------------------------
// Scenario 3: the temporary password opens the door, and the response says
// exactly what the frontend must hear.
// ---------------------------------------------------------------------------
$tempLogin = api('POST', '/auth/login', [
    'username' => $username,
    'password' => TEMPORARY_PASSWORD,
]);

$tempToken = (string) ($tempLogin['json']['data']['token'] ?? '');
$tempFlag  = $tempLogin['json']['data']['user']['must_change_password'] ?? null;

check('3a. signing in with "123" succeeds',
    $tempLogin['status'] === 200 && $tempToken !== '',
    'response: ' . json_encode($tempLogin));
check('3b. the session reports must_change_password = true',
    $tempFlag === true,
    'got must_change_password = ' . json_encode($tempFlag));

echo "\n--- A flagged account is chained to the change flow ----------------\n";

// ---------------------------------------------------------------------------
// Scenario 4: every normal endpoint refuses the session while the flag is set,
// and only the change-password flow stays reachable.
// ---------------------------------------------------------------------------
check('4a. dashboard is blocked while flagged',
    api('GET', '/dashboard', [], $tempToken)['status'] === 403,
    'expected 403, got ' . api('GET', '/dashboard', [], $tempToken)['status']);
check('4b. editing your own profile is blocked while flagged',
    api('PUT', '/auth/profile', ['full_name' => 'Renamed'], $tempToken)['status'] === 403,
    'expected 403 — the flag must chain self-service too');
check('4c. an admin-only list is blocked while flagged',
    api('GET', '/users', [], $tempToken)['status'] === 403,
    'expected 403, got ' . api('GET', '/users', [], $tempToken)['status']);
check('4d. /auth/me remains reachable (the change screen needs it)',
    ($me = api('GET', '/auth/me', [], $tempToken))['status'] === 200
        && ($me['json']['data']['must_change_password'] ?? null) === true,
    'expected 200 + flag true, got ' . api('GET', '/auth/me', [], $tempToken)['status']);

echo "\n--- Bad change attempts change nothing ---------------------------\n";

// ---------------------------------------------------------------------------
// Scenario 5: failed change attempts are rejected without clearing the flag.
// ---------------------------------------------------------------------------
$mismatch = api('POST', '/auth/change-password', [
    'current_password' => TEMPORARY_PASSWORD,
    'new_password'     => REPLACEMENT_PASSWORD,
    'confirm_password' => REPLACEMENT_PASSWORD . '.x',
], $tempToken);

check('5a. mismatched confirmation is rejected (422)',
    $mismatch['status'] === 422, 'got ' . $mismatch['status']);

$reuseTemp = api('POST', '/auth/change-password', [
    'current_password' => TEMPORARY_PASSWORD,
    'new_password'     => TEMPORARY_PASSWORD,
    'confirm_password' => TEMPORARY_PASSWORD,
], $tempToken);

$detail = $reuseTemp['json']['errors']['new_password'] ?? '';
check('5b. the temporary password is refused as the new password (422)',
    $reuseTemp['status'] === 422
        && stripos((string) $detail, 'temporary') !== false,
    'expected 422 + "temporary" error, got ' . json_encode($reuseTemp));

$stillFlagged = (int) dbValue(
    'SELECT must_change_password FROM users WHERE id = :id',
    ['id' => $userId]
);

check('5c. the flag survives every failed attempt',
    $stillFlagged === 1 && password_verify(TEMPORARY_PASSWORD, (string) dbValue(
        'SELECT password_hash FROM users WHERE id = :id',
        ['id' => $userId]
    )),
    'flag cleared or password changed without success');

echo "\n--- A real password is chosen -------------------------------------\n";

// ---------------------------------------------------------------------------
// Scenario 6: a valid change clears the flag, revokes old sessions, issues a
// fresh token, and only then opens the whole API again.
// ---------------------------------------------------------------------------
$change = api('POST', '/auth/change-password', [
    'current_password' => TEMPORARY_PASSWORD,
    'new_password'     => REPLACEMENT_PASSWORD,
    'confirm_password' => REPLACEMENT_PASSWORD,
], $tempToken);

$freshToken = (string) ($change['json']['data']['token'] ?? '');

check('6a. a valid change succeeds and issues a fresh session',
    $change['status'] === 200 && $freshToken !== '',
    'response: ' . json_encode($change));

$after = dbRow(
    'SELECT password_hash, must_change_password FROM users WHERE id = :id',
    ['id' => $userId]
);
$activeTokens = (int) dbValue(
    'SELECT COUNT(*) FROM api_tokens WHERE user_id = :id AND is_revoked = 0',
    ['id' => $userId]
);

check('6b. the flag is cleared only on success',
    (int) ($after['must_change_password'] ?? 1) === 0,
    'flag = ' . ($after['must_change_password'] ?? 'NULL'));
check('6b2. clearing the flag left every other account exactly as it was',
    flaggedAccounts() === $flagsBefore,
    'flagged accounts: before=' . $flagsBefore . ', now=' . flaggedAccounts());
check('6c. the new password is stored, the temporary one is not',
    password_verify(REPLACEMENT_PASSWORD, (string) $after['password_hash'])
        && password_verify(TEMPORARY_PASSWORD, (string) $after['password_hash']) === false,
    'stored hash does not match the expected password');
check('6d. exactly one active session survives the change',
    $activeTokens === 1,
    "$activeTokens active token(s) after change-password");

check('6e. the old flagged session is dead',
    api('GET', '/auth/me', [], $tempToken)['status'] === 401,
    'expected 401 for the pre-change token');
check('6f. the fresh session has full access again',
    ($dash = api('GET', '/dashboard', [], $freshToken))['status'] === 200,
    'expected 200, got ' . api('GET', '/dashboard', [], $freshToken)['status']);
$profileUpdate = api('PUT', '/auth/profile', [
    'username'  => $username,
    'full_name' => 'Forced Change Probe',
], $freshToken);

check('6g. self-service editing works again',
    $profileUpdate['status'] === 200,
    'expected 200, got ' . $profileUpdate['status'] . ': ' . json_encode($profileUpdate));

echo "\n--- The temporary password dies with the flow --------------------\n";

// ---------------------------------------------------------------------------
// Scenario 7: the new password is the way in, the temporary password is not.
// ---------------------------------------------------------------------------
$relogin = api('POST', '/auth/login', [
    'username' => $username,
    'password' => REPLACEMENT_PASSWORD,
]);

check('7a. signing in with the new password succeeds (flag false)',
    $relogin['status'] === 200
        && ($relogin['json']['data']['user']['must_change_password'] ?? null) === false,
    'response: ' . json_encode($relogin));
check('7b. the temporary password no longer works',
    api('POST', '/auth/login', [
        'username' => $username,
        'password' => TEMPORARY_PASSWORD,
    ])['status'] === 401,
    'expected 401 for a login with "123"');

echo "\n--- The employee-side reset uses the same temporary password -----\n";

// ---------------------------------------------------------------------------
// Scenario 8: the employee reset endpoint (EmployeeService) issues exactly the
// same shared temporary password and flag.
// ---------------------------------------------------------------------------
$empSuffix  = (string) time();
$empAccount = 'fcacct' . $empSuffix;
$createEmp  = api('POST', '/employees', [
    'first_name'        => 'Forced',
    'last_name'         => 'Probe' . $empSuffix,
    'gender'            => 'MALE',
    'date_hired'        => '2026-01-05',
    'employment_type'   => 'FULL_TIME',
    'salary_type'       => 'MONTHLY',
    'basic_salary'      => 25000,
    'department_id'     => 1,
    'position_id'       => 1,
    'work_schedule_id'  => 1,
    'email'             => "forced.probe.{$empSuffix}@company.test",
    'account_username'  => $empAccount,
    'account_password'  => ORIGINAL_PASSWORD,
    'account_password_confirm' => ORIGINAL_PASSWORD,
], $adminToken);

$empId = (int) ($createEmp['json']['data']['employee']['id'] ?? 0);
$created['employee_id'] = $empId === 0 ? null : $empId;

if ($createEmp['status'] < 200 || $createEmp['status'] >= 300 || $empId === 0) {
    check('8a. a disposable employee can be created', false, json_encode($createEmp));
} else {
    $created['linked_username'] = $empAccount;

    // Snapshot the account before the reset so the "starts clean" assertion is
    // actually about the pre-reset state.
    $linkedBefore = dbRow(
        'SELECT id, username, password_hash, must_change_password FROM users WHERE employee_id = :eid',
        ['eid' => $empId]
    );

    $empReset = api('POST', "/employees/{$empId}/reset-password", [], $adminToken);
    $empData  = $empReset['json']['data'] ?? [];

    $linked = dbRow(
        'SELECT id, username, password_hash, must_change_password FROM users WHERE employee_id = :eid',
        ['eid' => $empId]
    );

    $created['linked_user_id']  = isset($linked['id']) ? (int) $linked['id'] : null;
    $created['linked_username'] = $linked['username'] ?? $empAccount;

    check('8a. a disposable employee can be created', $empId !== 0, json_encode($createEmp));
    check('8b0. the new employee account starts unusable-temp-free',
        $linkedBefore !== null
            && (int) $linkedBefore['must_change_password'] === 0
            && password_verify(TEMPORARY_PASSWORD, (string) $linkedBefore['password_hash']) === false,
        json_encode($linkedBefore === null ? 'no linked account' : $linkedBefore));
    check('8b. the employee reset issues the shared temporary password',
        $empReset['status'] === 200 && ($empData['temporary_password'] ?? null) === TEMPORARY_PASSWORD,
        'response: ' . json_encode($empReset));
    check('8c. the linked account is flagged and stores the password hashed',
        $linked !== null
            && (int) $linked['must_change_password'] === 1
            && $linked['password_hash'] !== TEMPORARY_PASSWORD
            && password_verify(TEMPORARY_PASSWORD, (string) $linked['password_hash']),
        json_encode($linked === null ? 'no linked account' : $linked));
}

echo "\n--- Nothing else in the system was disturbed ---------------------\n";

// ---------------------------------------------------------------------------
// Scenario 9: the flag only ever travelled along our own probes. The database
// may already contain accounts chained to the flow, so this is a delta check.
// ---------------------------------------------------------------------------
$expectedFlags = $created['linked_user_id'] === null ? $flagsBefore : $flagsBefore + 1;

check('9. the flag moved only on our own probe accounts',
    flaggedAccounts() === $expectedFlags,
    'flagged accounts: before=' . $flagsBefore . ', expected=' . $expectedFlags
        . ', now=' . flaggedAccounts());

// ---------------------------------------------------------------------------
// Scenario 10: both reset paths stay wired to the shared temporary value and
// the change endpoint keeps refusing it — a regression tripwire.
// ---------------------------------------------------------------------------
$sources = [
    'api/controllers/UserController.php'    => 'Auth::TEMPORARY_PASSWORD',
    'api/services/EmployeeService.php'      => 'Auth::TEMPORARY_PASSWORD',
    'api/controllers/AuthController.php'    => '=== Auth::TEMPORARY_PASSWORD',
];

$wired = true;
foreach ($sources as $file => $needle) {
    $source = (string) @file_get_contents(dirname(__DIR__) . '/' . $file);
    if (strpos($source, $needle) === false) {
        $wired = false;
    }
}

check('10. the reset paths share Auth::TEMPORARY_PASSWORD in the code',
    $wired,
    'one of the reset/change files no longer references the shared constant');

FINISH:

echo "\n==============================================\n";
echo " RESULT: $passed passed, $failed failed\n";
echo "==============================================\n";

// ---------------------------------------------------------------------------
// Cleanup — always run, even when an early check fails above.
// ---------------------------------------------------------------------------
try {
    $pdo = db();

    if ($created['linked_user_id'] !== null) {
        $pdo->prepare('DELETE FROM users WHERE id = :id')
            ->execute(['id' => $created['linked_user_id']]);
    }

    if ($created['employee_id'] !== null) {
        // The QR images cascade out of the database with the employee, so the
        // generated SVG files have to be removed by hand.
        $qrFiles = [];
        try {
            $stmt = $pdo->prepare('SELECT qr_image_path FROM employee_qr_codes WHERE employee_id = :id');
            $stmt->execute(['id' => $created['employee_id']]);
            $qrFiles = array_filter(array_column($stmt->fetchAll(PDO::FETCH_ASSOC), 'qr_image_path'));
        } catch (PDOException $e) {
            // Table naming drift is not worth failing an otherwise clean run.
        }

        $pdo->prepare('DELETE FROM employees WHERE id = :id')
            ->execute(['id' => $created['employee_id']]);

        $config = require dirname(__DIR__) . '/api/config/config.php';
        foreach ($qrFiles as $relative) {
            @unlink($config['paths']['qrcodes'] . DIRECTORY_SEPARATOR . basename((string) $relative));
        }
    }

    if ($created['user_id'] !== null) {
        $pdo->prepare('DELETE FROM users WHERE id = :id')
            ->execute(['id' => $created['user_id']]);
    }

    foreach (array_filter([
        $created['user_username'],
        $created['linked_username'],
    ]) as $identifier) {
        try {
            $pdo->prepare('DELETE FROM login_attempts WHERE identifier = :id')
                ->execute(['id' => $identifier]);
        } catch (PDOException $e) {
            // Column name drift across versions is not worth failing a pass for.
        }
    }
} catch (PDOException $e) {
    echo '  NOTE  cleanup could not reach the database: ' . $e->getMessage() . "\n";
}

exit($failed === 0 ? 0 : 1);