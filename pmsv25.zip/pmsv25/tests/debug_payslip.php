<?php
/**
 * Payslip render diagnostic (bypasses HTTP).
 */

declare(strict_types=1);

spl_autoload_register(static function (string $class): void {
    $prefix = 'App\\';
    if (!str_starts_with($class, $prefix)) {
        return;
    }

    $relative = substr($class, strlen($prefix));
    $parts    = explode('\\', $relative);
    $file     = array_pop($parts);
    $subDir   = $parts === [] ? '' : strtolower(implode('/', $parts)) . '/';

    $path = __DIR__ . '/../api/' . $subDir . strtolower($file) . '.php';
    if (is_file($path)) {
        require_once $path;
    }
});

require __DIR__ . '/../api/config/config.php';

date_default_timezone_set('Asia/Manila');

$id = (int) ($argv[1] ?? 3);

try {
    $service = new App\Services\PayslipService();
    $result  = $service->render($id);

    echo json_encode($result, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES), "\n";
} catch (Throwable $e) {
    echo get_class($e), ': ', $e->getMessage(), "\n";
    echo $e->getTraceAsString(), "\n";
}
spl_autoload_register(static function (string $class): void {
    $prefix = 'App\\';
    if (!str_starts_with($class, $prefix)) {
        return;
    }

    $relative = substr($class, strlen($prefix));
    $parts    = explode('\\', $relative);
    $file     = array_pop($parts);
    $subDir   = $parts === [] ? '' : strtolower(implode('/', $parts)) . '/';

    $path = __DIR__ . '/../api/' . $subDir . strtolower($file) . '.php';
    if (is_file($path)) {
        require_once $path;
    }
});

require __DIR__ . '/../api/config/config.php';

date_default_timezone_set('Asia/Manila');

$token = $argv[1] ?? '';

echo "Token: {$token}\n\n";

$qr = new App\Services\QrCodeService();

try {
    $resolved = $qr->resolve($token);
    echo 'Resolve OK: employee_id=' . $resolved['employee_id'] . " qr_id={$resolved['qr_id']}\n";
} catch (Throwable $e) {
    echo 'Resolve FAILED: ' . $e->getMessage() . "\n";
    exit(1);
}

$engine     = new App\Services\AttendanceEngine();
$employeeId = $resolved['employee_id'];
$date       = date('Y-m-d');

echo "\nContext:\n";
$context = $engine->contextFor($employeeId, $date);
echo '  shift=' . json_encode($context['shift']) . "\n";
echo '  is_rest_day=' . var_export($context['is_rest_day'], true) . "\n";
echo '  holiday=' . json_encode($context['holiday']) . "\n";

echo "\nExisting attendance:\n";
var_dump($engine->findAttendance($employeeId, $date));

echo "\nScan:\n";
try {
    $service = new App\Services\AttendanceService($qr, $engine);
    $result  = $service->scan($token);
    echo json_encode($result, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES) . "\n";
} catch (Throwable $e) {
    echo get_class($e) . ': ' . $e->getMessage() . "\n";
    echo $e->getTraceAsString() . "\n";
}