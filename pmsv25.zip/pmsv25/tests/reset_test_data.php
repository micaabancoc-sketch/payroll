<?php
/**
 * Test-data reset and preflight helper (used by the test suites).
 *
 * Two jobs:
 *
 *   1. Preflight — make sure the database is actually seeded. A missing or
 *      emptied database otherwise shows up as "Invalid username or password",
 *      which sends you hunting through the auth code for a problem that is not
 *      there.
 *
 *   2. Reset — remove the artefacts the end-to-end suite leaves behind so it can
 *      be run again. The suite creates a brand new employee on every pass, so
 *      attendance, leave and overtime rows never clash. The one thing that
 *      cannot be duplicated is a payroll period, because the date ranges must
 *      not overlap, so those are cleared here. Payroll rows, payslips and
 *      adjustments cascade from payroll_periods.
 *
 * Usage: php tests/reset_test_data.php [period_name]
 */

declare(strict_types=1);

$periodName = $argv[1] ?? 'Automated test period';

$config = require __DIR__ . '/../api/config/config.php';
$db     = $config['database'];

try {
    $pdo = new PDO(
        sprintf('mysql:host=%s;port=%d;dbname=%s;charset=utf8mb4', $db['host'], $db['port'], $db['name']),
        $db['user'],
        $db['password'],
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
    );
} catch (PDOException $e) {
    fwrite(STDERR, "Cannot reach the database: {$e->getMessage()}\n");
    fwrite(STDERR, "Start MySQL, then import: mysql -u root -p < database/main.sql\n");
    exit(2);
}

// ---------------------------------------------------------------------------
// 1. Preflight: is the database seeded?
// ---------------------------------------------------------------------------

/** @var array<string, int> $required */
$required = [
    'roles'           => 3,
    'users'           => 3,
    'departments'     => 1,
    'system_settings' => 1,
];

$missing = [];

foreach ($required as $table => $minimum) {
    try {
        $count = (int) $pdo->query("SELECT COUNT(*) FROM `{$table}`")->fetchColumn();
    } catch (PDOException $e) {
        $missing[] = "{$table} (table missing)";
        continue;
    }

    if ($count < $minimum) {
        $missing[] = sprintf('%s (%d row(s), expected at least %d)', $table, $count, $minimum);
    }
}

// The demo accounts must exist and be able to sign in.
if (!isset($missing[0])) {
    $admin = $pdo->query(
    "SELECT password_hash FROM users WHERE username = 'admin' AND deleted_at IS NULL"
    )->fetchColumn();

    if ($admin === false) {
    $missing[] = 'admin account';
    } elseif (!password_verify('Password123@', (string) $admin)) {
        $missing[] = "admin's password is not Password123@";
    }
}

if ($missing !== []) {
    fwrite(STDERR, "The database is not seeded:\n");

    foreach ($missing as $problem) {
        fwrite(STDERR, "  - {$problem}\n");
    }

    fwrite(STDERR, "\nImport the main SQL file to fix it:\n  mysql -u root -p < database/main.sql\n");
    exit(3);
}

// ---------------------------------------------------------------------------
// 2. Reset test artefacts
// ---------------------------------------------------------------------------

$statement = $pdo->prepare('DELETE FROM payroll_periods WHERE name = :name');
$statement->execute(['name' => $periodName]);

echo sprintf("Removed %d test payroll period(s).\n", $statement->rowCount());

// The suite issues a few hundred requests per pass, which legitimately trips
// the sliding-window limiter. Clearing the buckets keeps back-to-back passes
// independent; the limiter itself is exercised by its own assertions.
$cleared = $pdo->exec('DELETE FROM rate_limits');

echo sprintf("Cleared %d rate-limit bucket(s).\n", (int) $cleared);

// A previous run may have locked an account through the deliberate bad-login
// tests. Unlock everything so the next pass can sign in.
$unlocked = $pdo->exec(
    'UPDATE users SET failed_attempts = 0, locked_until = NULL WHERE failed_attempts > 0 OR locked_until IS NOT NULL'
);

echo sprintf("Unlocked %d account(s).\n", (int) $unlocked);

// A test may deliberately reset someone's password (e.g. the permission
// assertion on POST /employees/{id}/reset-password). Put every account back
// on the documented demo password so a failed assertion cannot leave the
// fixtures unusable.
$demoHash = password_hash('Password123@', PASSWORD_DEFAULT);
$stale = $pdo->prepare(
    'UPDATE users SET password_hash = :hash, must_change_password = 0 WHERE id = :id'
);
$candidates = $pdo->query('SELECT id, password_hash, must_change_password FROM users')->fetchAll(PDO::FETCH_ASSOC);
$normalised = 0;

foreach ($candidates as $account) {
    // bcrypt hashes are salted, so the demo hash never matches by comparison;
    // verify the plaintext instead or every row would be rewritten each run.
    if (password_verify('Password123@', (string) $account['password_hash']) && (int) $account['must_change_password'] === 0) {
        continue;
    }

    $stale->execute(['hash' => $demoHash, 'id' => (int) $account['id']]);
    $normalised += $stale->rowCount();
}

echo sprintf("Normalised %d account password(s) to Password123@.\n", $normalised);
