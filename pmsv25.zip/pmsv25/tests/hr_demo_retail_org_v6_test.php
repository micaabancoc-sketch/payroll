<?php
/** Run: php tests/hr_demo_retail_org_v6_test.php (no DB connection needed). */
$root = dirname(__DIR__);
$sql = file_get_contents($root.'/database/migrations/20261022_retail_org_hr_demo.sql');
$schema = file_get_contents($root.'/database/main.sql');
$ui = file_get_contents($root.'/frontend/employees/index.html');
$cases = [
  'nondestructive migration' => !preg_match('/\b(?:DROP|TRUNCATE)\s+TABLE\b/i', $sql),
  'five retail departments' => count(array_filter(['CASH','HR','SALES','STOCK','OPS'], fn($c)=>strpos($sql, "('".$c."'") !== false)) === 5,
  'HR/Payroll account role' => strpos($sql, "r.code='HR_PAYROLL'") !== false,
  'unique HR demo account' => strpos($sql, "username='hr'") !== false,
  'HR employee linked to users' => strpos($sql, "JOIN roles r ON r.code='HR_PAYROLL'") !== false && strpos($sql, "'DEMO-HR-001'") !== false,
  'forced password change' => strpos($sql, "'Demo HR Payroll',r.id,e.id,'ACTIVE',1") !== false,
  'monthly salary basis' => strpos($sql, "'MONTHLY',30000.00") !== false,
  'initial history' => strpos($sql, 'INSERT INTO salary_history') !== false,
  'fresh schema updated' => strpos($schema, 'V6 RETAIL DEMO ORGANIZATION') !== false,
  'department validation' => strpos($ui, 'Please select a Department first.') !== false,
  'position validation' => strpos($ui, 'Please select a Position belonging') !== false,
  'salary validation' => strpos($ui, 'This Department has no Basic Salary.') !== false,
];
$failed = 0;
foreach ($cases as $case=>$ok) {
    echo ($ok ? 'PASS ' : 'FAIL ').$case."\n";
    if (!$ok) $failed++;
}
exit($failed?1:0);
