<?php

/**
 * Overtime midnight-completion regression tests.
 *
 * Covers the fix for completeEndedRequests(): an OT assignment ending at
 * 00:00:00 (midnight) that starts later than midnight must be treated as
 * ending at midnight on the *next* calendar day, not at the start of the
 * overtime date.
 *
 *   1. 5:00 PMâ€“12:00 AM is NOT completed before the midnight deadline.
 *   2. 5:00 PMâ€“12:00 AM IS completed once the midnight deadline has passed.
 *   3. 5:00 PMâ€“10:00 PM keeps its original completion behaviour.
 *   4. 5:00 PMâ€“12:00 AM remains a valid creation window.
 *   5. 5:00 PMâ€“12:01 AM remains rejected at creation.
 *   6. Creation and update both keep the midnight restriction.
 *
 * Usage: DB_NAME=attendance_payroll_test php tests/overtime_midnight_completion_test.php
 * Refuses production-looking databases via tests/db_guard.php.
 */

declare(strict_types=1);

use App\Core\Auth;
use App\Core\Validator;
use App\Core\ValidationException;
use App\Services\OvertimeService;

require dirname(__DIR__) . '/api/autoload.php';

// Refuse to touch a production or genuine-use database.
require __DIR__ . '/db_guard.php';
pmsAssertSafeTestDatabase();

$config = require dirname(__DIR__) . '/api/config/config.php';
date_default_timezone_set((string) $config['app']['timezone']);

const REF_DATE   = '2026-10-17'; // Saturday â€” no schedule interference expected
const REF_DATE_2 = '2026-10-18'; // Sunday â€” used for update test (no overlap)
const REF_DATE_3 = '2026-10-19'; // Monday â€” future date for creation tests
const REF_NOW    = '2026-10-18 01:00:00'; // 1:00 AM on Oct 18 â€” deterministic clock
const REF_START  = '17:00:00';   // 5:00 PM
const REF_END    = '00:00:00';   // 12:00 AM midnight
const REF_LATE   = '00:01:00';   // 12:01 AM â€” must be rejected
const REF_EVENING = '22:00:00';  // 10:00 PM â€” regular end time

$passed   = 0;
$failed   = 0;
$failures = [];

function check(string $label, bool $ok, string $detail = ''): void
{
    global $passed, $failed, $failures;

    if ($ok) {
        $passed++;
        echo "  PASS  $label\n";
        return;
    }

    $failed++;
    $failures[] = $label;
    echo "  FAIL  $label\n";
    if ($detail !== '') {
        echo "        $detail\n";
    }
}

// ---------------------------------------------------------------------------
// Database helpers (private connection, independent of the app's Database)
// ---------------------------------------------------------------------------

function testDb(): \PDO
{
    static $pdo = null;

    if ($pdo instanceof \PDO) {
        return $pdo;
    }

    $cfg = require dirname(__DIR__) . '/api/config/config.php';
    $db  = $cfg['database'];

    $pdo = new \PDO(
        sprintf('mysql:host=%s;port=%d;dbname=%s;charset=utf8mb4', $db['host'], $db['port'], $db['name']),
        $db['user'],
        $db['password'],
        [\PDO::ATTR_ERRMODE => \PDO::ERRMODE_EXCEPTION, \PDO::ATTR_DEFAULT_FETCH_MODE => \PDO::FETCH_ASSOC]
    );

    return $pdo;
}

/** @param array<string, mixed> $data */
function insertRow(string $table, array $data): int
{
    $columns      = array_keys($data);
    $placeholders = array_map(static fn (string $c): string => ':' . $c, $columns);
    $quoted       = array_map(static fn (string $c): string => '`' . $c . '`', $columns);

    $sql  = sprintf('INSERT INTO `%s` (%s) VALUES (%s)', $table, implode(', ', $quoted), implode(', ', $placeholders));
    $stmt = testDb()->prepare($sql);
    $stmt->execute($data);

    return (int) testDb()->lastInsertId();
}

function scalarValue(string $sql, array $params = []): mixed
{
    $stmt = testDb()->prepare($sql);
    $stmt->execute($params);
    $value = $stmt->fetchColumn();

    return $value === false ? null : $value;
}

/** @return array<string, mixed>|null */
function dbRow(string $sql, array $params = []): ?array
{
    $stmt = testDb()->prepare($sql);
    $stmt->execute($params);
    $row = $stmt->fetch();

    return $row === false ? null : $row;
}

// ---------------------------------------------------------------------------
// Fixture setup
// ---------------------------------------------------------------------------

$created = [
    'roles'     => [],
    'users'     => [],
    'employees' => [],
    'ot'        => [],
];

function dbExecute(string $sql, array $params = []): void
{
    $stmt = testDb()->prepare($sql);
    $stmt->execute($params);
}

function teardown(): void
{
    global $created;
    $db = testDb();

    foreach ($created['ot'] as $id) {
        dbExecute('DELETE FROM overtime_requests WHERE id = :id', [':id' => $id]);
    }
    foreach ($created['users'] as $id) {
        dbExecute('DELETE FROM api_tokens WHERE user_id = :id', [':id' => $id]);
        dbExecute('DELETE FROM users WHERE id = :id', [':id' => $id]);
    }
    foreach ($created['employees'] as $id) {
        dbExecute('DELETE FROM employees WHERE id = :id', [':id' => $id]);
    }
    foreach ($created['roles'] as $id) {
        dbExecute('DELETE FROM roles WHERE id = :id', [':id' => $id]);
    }
}

// Insert an ADMIN role with '*' permissions (matches main.sql seed).
function fixtureAdminRole(): int
{
    global $created;
    $suffix = substr(uniqid('', true), -6);
    $id = insertRow('roles', [
        'code'        => 'ADMIN_TEST_' . $suffix,
        'name'        => 'Test Administrator',
        'description' => 'Temporary admin role for OT midnight tests',
        'permissions' => json_encode(['*']),
        'is_system'   => 0,
    ]);
    $created['roles'][] = $id;
    return $id;
}

// Insert a user linked to the admin role.
function fixtureAdminUser(int $roleId): int
{
    global $created;
    $suffix = substr(uniqid('', true), -6);
    $id = insertRow('users', [
        'username'       => 'ot_test_admin_' . $suffix,
        'email'          => 'ot_test_admin_' . $suffix . '@example.com',
        'password_hash'  => password_hash('Password123@', PASSWORD_DEFAULT),
        'full_name'      => 'OT Test Admin',
        'role_id'        => $roleId,
        'employee_id'    => null,
        'status'         => 'ACTIVE',
    ]);
    $created['users'][] = $id;
    return $id;
}

// Insert an employee without a work schedule (so assertOvertimeWindow returns early).
function fixtureEmployee(): int
{
    global $created;
    $id = insertRow('employees', [
        'employee_number' => 'EMP-OT-TEST-' . uniqid('', true),
        'first_name'      => 'OT',
        'last_name'       => 'Test Employee',
        'gender'          => 'OTHER',
        'email'           => 'ot.test.' . uniqid('', true) . '@example.com',
        'department_id'   => null,
        'position_id'     => null,
        'employment_type' => 'FULL_TIME',
        'date_hired'      => '2026-01-05',
        'salary_type'     => 'MONTHLY',
        'basic_salary'    => 25000.00,
        'work_schedule_id'=> null,
        'status'          => 'ACTIVE',
        'created_by'      => null,
        'notes'           => 'Temporary employee for OT midnight tests',
    ]);
    $created['employees'][] = $id;
    return $id;
}

// Make Auth see the admin user so requireAdmin() passes in create()/update().
function authAsAdmin(int $userId): void
{
    $ref = new ReflectionClass(Auth::class);

    $userProp = $ref->getProperty('user');
    $userProp->setAccessible(true);
    $userProp->setValue(null, [
        'id'         => $userId,
        'username'   => 'ot_test_admin',
        'role_code'  => 'ADMIN',
        'permissions'=> ['*'],
    ]);

    $resolvedProp = $ref->getProperty('resolved');
    $resolvedProp->setAccessible(true);
    $resolvedProp->setValue(null, true);
}

function authClear(): void
{
    $ref = new ReflectionClass(Auth::class);

    $userProp = $ref->getProperty('user');
    $userProp->setAccessible(true);
    $userProp->setValue(null, null);

    $resolvedProp = $ref->getProperty('resolved');
    $resolvedProp->setAccessible(true);
    $resolvedProp->setValue(null, false);
}

// ---------------------------------------------------------------------------
// Tests
// ---------------------------------------------------------------------------

echo "Overtime midnight-completion regression tests\n";
echo str_repeat('-', 60), "\n";

// --- Fixtures ---------------------------------------------------------------

$adminRoleId = fixtureAdminRole();
$adminUserId = fixtureAdminUser($adminRoleId);
$employeeId  = fixtureEmployee();

authAsAdmin($adminUserId);

$service = new OvertimeService();

// ---------------------------------------------------------------------------
// 1. 5:00 PMâ€“12:00 AM NOT completed before the midnight deadline.
// ---------------------------------------------------------------------------

$otId1 = insertRow('overtime_requests', [
    'employee_id'   => $employeeId,
    'overtime_date' => REF_DATE,
    'start_time'    => REF_START,
    'end_time'      => REF_END,
    'hours'         => 7.00,
    'ot_type'       => 'REGULAR',
    'reason'        => 'Midnight completion test 1',
    'status'        => 'PENDING',
    'created_at'    => date('Y-m-d H:i:s'),
    'updated_at'    => date('Y-m-d H:i:s'),
]);
$created['ot'][] = $otId1;

// 23:00 on the OT date is 1 hour before the midnight deadline (next day 00:00:00).
$service->completeEndedRequests('2026-10-17 23:00:00');

$status1 = (string) scalarValue('SELECT status FROM overtime_requests WHERE id = :id', [':id' => $otId1]);
check('OT 17:00â€“00:00 stays PENDING at 23:00 on OT date (before midnight deadline)', $status1 === 'PENDING', "status=$status1");

// ---------------------------------------------------------------------------
// 2. 5:00 PMâ€“12:00 AM IS completed once the midnight deadline has passed.
// ---------------------------------------------------------------------------

// 00:30 on the next day is past the midnight deadline (2026-10-18 00:00:00).
$service->completeEndedRequests('2026-10-18 00:30:00');

$status2 = (string) scalarValue('SELECT status FROM overtime_requests WHERE id = :id', [':id' => $otId1]);
check('OT 17:00â€“00:00 becomes COMPLETED after midnight deadline', $status2 === 'COMPLETED', "status=$status2");

// ---------------------------------------------------------------------------
// 3. Regular 5:00 PMâ€“10:00 PM keeps its original completion behaviour.
// ---------------------------------------------------------------------------

$otId3a = insertRow('overtime_requests', [
    'employee_id'   => $employeeId,
    'overtime_date' => REF_DATE,
    'start_time'    => REF_START,
    'end_time'      => REF_EVENING,
    'hours'         => 5.00,
    'ot_type'       => 'REGULAR',
    'reason'        => 'Midnight completion test 3a',
    'status'        => 'PENDING',
    'created_at'    => date('Y-m-d H:i:s'),
    'updated_at'    => date('Y-m-d H:i:s'),
]);
$created['ot'][] = $otId3a;

$otId3b = insertRow('overtime_requests', [
    'employee_id'   => $employeeId,
    'overtime_date' => REF_DATE,
    'start_time'    => REF_START,
    'end_time'      => REF_EVENING,
    'hours'         => 5.00,
    'ot_type'       => 'REGULAR',
    'reason'        => 'Midnight completion test 3b',
    'status'        => 'PENDING',
    'created_at'    => date('Y-m-d H:i:s'),
    'updated_at'    => date('Y-m-d H:i:s'),
]);
$created['ot'][] = $otId3b;

// 21:00 is before the 22:00 deadline -> stays PENDING.
$service->completeEndedRequests('2026-10-17 21:00:00');

$status3a = (string) scalarValue('SELECT status FROM overtime_requests WHERE id = :id', [':id' => $otId3a]);
check('Regular OT 17:00â€“22:00 stays PENDING at 21:00 (before 22:00 deadline)', $status3a === 'PENDING', "status=$status3a");

// 23:00 is past the 22:00 deadline -> COMPLETED.
$service->completeEndedRequests('2026-10-17 23:00:00');

$status3b = (string) scalarValue('SELECT status FROM overtime_requests WHERE id = :id', [':id' => $otId3b]);
check('Regular OT 17:00â€“22:00 becomes COMPLETED at 23:00 (after 22:00 deadline)', $status3b === 'COMPLETED', "status=$status3b");

// ---------------------------------------------------------------------------
// 4. 5:00 PMâ€“12:00 AM remains valid at creation.
// ---------------------------------------------------------------------------

try {
    $record = $service->create([
        'employee_id'   => $employeeId,
        'overtime_date' => REF_DATE_3,
        'start_time'    => REF_START,
        'end_time'      => REF_END,
        'reason'        => 'Valid midnight window creation test',
        'ot_type'       => 'REGULAR',
    ], null, REF_NOW);
    $created['ot'][] = (int) ($record['id'] ?? 0);
    check('Creation 17:00â€“00:00 is accepted (no exception)', is_array($record) && isset($record['id']), 'record=' . json_encode($record ?? null));
} catch (\Throwable $e) {
    check('Creation 17:00â€“00:00 is accepted (no exception)', false, $e->getMessage());
}

// ---------------------------------------------------------------------------
// 5. 5:00 PMâ€“12:01 AM remains rejected at creation.
// ---------------------------------------------------------------------------

try {
    $service->create([
        'employee_id'   => $employeeId,
        'overtime_date' => REF_DATE,
        'start_time'    => REF_START,
        'end_time'      => REF_LATE,
        'reason'        => 'Invalid past-midnight creation test',
        'ot_type'       => 'REGULAR',
    ]);
    check('Creation 17:00â€“00:01 is rejected', false, 'no exception thrown');
} catch (ValidationException $e) {
    $errors = $e->errors();
    check('Creation 17:00â€“00:01 is rejected', isset($errors['end_time']) && str_contains($errors['end_time'], 'midnight'), 'errors=' . json_encode($errors));
} catch (\Throwable $e) {
    check('Creation 17:00â€“00:01 is rejected with ValidationException', false, get_class($e) . ': ' . $e->getMessage());
}

// ---------------------------------------------------------------------------
// 6. Update validation retains the midnight restriction.
// ---------------------------------------------------------------------------

// Create a valid OT first, then try to move its end time past midnight.
$validId = null;
try {
    $record = $service->create([
        'employee_id'   => $employeeId,
        'overtime_date' => REF_DATE_2,
        'start_time'    => REF_START,
        'end_time'      => REF_EVENING,
        'reason'        => 'Valid OT for update test',
        'ot_type'       => 'REGULAR',
    ]);
    $validId = (int) ($record['id'] ?? 0);
    $created['ot'][] = $validId;
} catch (\Throwable $e) {
    check('Setup: valid OT created for update test', false, $e->getMessage());
}

if ($validId !== null) {
    try {
        $service->update($validId, [
            'end_time' => REF_LATE,
        ]);
        check('Update end_time to 00:01 is rejected', false, 'no exception thrown');
    } catch (ValidationException $e) {
        $errors = $e->errors();
        check('Update end_time to 00:01 is rejected', isset($errors['end_time']) && str_contains($errors['end_time'], 'midnight'), 'errors=' . json_encode($errors));
    } catch (\Throwable $e) {
        check('Update end_time to 00:01 is rejected with ValidationException', false, get_class($e) . ': ' . $e->getMessage());
    }

    // Update to a valid midnight window should succeed.
    try {
        $record = $service->update($validId, [
            'end_time' => REF_END,
        ]);
        check('Update end_time to 00:00 is accepted', is_array($record) && isset($record['id']), 'record=' . json_encode($record ?? null));
    } catch (\Throwable $e) {
        check('Update end_time to 00:00 is accepted', false, $e->getMessage());
    }
} else {
    check('Setup: valid OT created for update test', false, 'could not create OT record');
}

// ---------------------------------------------------------------------------
// Teardown + summary
// ---------------------------------------------------------------------------

authClear();
teardown();

echo str_repeat('-', 60), "\n";
printf("  Results: %d passed, %d failed\n", $passed, $failed);

if ($failed > 0) {
    echo "\n  Failures:\n";
    foreach ($failures as $f) {
        echo "    - $f\n";
    }
    exit(1);
}

echo "  All overtime midnight-completion tests passed.\n";
exit(0);


