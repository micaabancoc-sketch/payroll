<?php
// Standalone check: EmployeeService::rules() must accept all 4 salary types
// and reject invalid ones. No DB needed.
declare(strict_types=1);
require __DIR__ . '/../api/core/Validator.php';
require __DIR__ . '/../api/services/EmployeeService.php';

use App\Services\EmployeeService;

$base = [
  'first_name' => 'Test', 'gender' => 'MALE', 'date_hired' => '2026-01-05',
  'employment_type' => 'FULL_TIME', 'basic_salary' => 1000,
];
$results = [];
foreach (['MONTHLY','SEMI_MONTHLY','DAILY','HOURLY'] as $t) {
  $v = App\Core\Validator::make($base + ['salary_type' => $t], EmployeeService::rules());
  $results[$t] = $v->passes() ? 'PASS' : 'FAIL: '.json_encode($v->errors());
}
$vBad = App\Core\Validator::make($base + ['salary_type' => 'WEEKLY'], EmployeeService::rules());
$results['WEEKLY_rejected'] = $vBad->fails() ? 'PASS (rejected)' : 'FAIL (accepted!)';
echo json_encode($results, JSON_PRETTY_PRINT), "\n";
echo 'SALARY_TYPES const: ', json_encode(EmployeeService::SALARY_TYPES), "\n";
