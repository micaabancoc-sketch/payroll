#!/usr/bin/env python3
"""Decode the plaintext token out of a stored QR SVG.

The token is never stored in the database (only a peppered SHA-256 hash and an
8-character hint), so the QR image is the only place it survives. This proves
that by reading it straight back out of a stored file with an independent
decoder (zxing-cpp), with no knowledge of our PHP encoder.

Usage:
    python tests/qr_decode_token.py storage/qrcodes/emp-2-qr7.svg
"""
import re
import sys

import numpy as np
import zxingcpp
from PIL import Image

# Every module is emitted as "M<x> <y>h<w>v<h>h-<w>z", one subpath per dark
# module. Recovering the matrix therefore needs no SVG renderer.
SUBPATH = re.compile(r"M(\d+) (\d+)h(\d+)v(\d+)h-\d+z")


def matrix_from_svg(path):
    with open(path, encoding="utf-8") as handle:
        svg = handle.read()
    d = re.search(r'\sd="([^"]+)"', svg).group(1)

    modules = [(int(x), int(y), int(w), int(h)) for x, y, w, h in SUBPATH.findall(d)]
    if not modules:
        raise SystemExit("no modules found in " + path)

    # The smallest run is one module; wider runs are merges.
    step = min(w for _, _, w, _ in modules)
    origin = min(x for x, _, _, _ in modules)

    # Span the dark modules only -- the quiet zone is padding, not data.
    size = (max(x + w for x, _, w, _ in modules) - origin) // step

    # A QR symbol is 21 modules plus 4 per version (17 + 4k). Any other size
    # means the module step was inferred wrongly, and decoding it would
    # produce a confident-looking but meaningless token.
    if (size - 17) % 4 or not 21 <= size <= 177:
        raise SystemExit(
            f"{path}: {size}x{size} is not a valid QR symbol size -- "
            "module step misdetected, refusing to decode"
        )

    grid = np.full((size, size), 255, dtype=np.uint8)
    for x, y, w, h in modules:
        # A rectangle may span several modules in either axis, so both the
        # horizontal run and the vertical drop have to be expanded.
        cols, rows = w // step, h // step
        col, row = (x - origin) // step, (y - origin) // step
        grid[row:row + rows, col:col + cols] = 0

    return grid


def render(grid, scale=8, quiet=4):
    """Upscale the module grid with a quiet zone, the way zxing expects."""
    size = grid.shape[0]
    dim = (size + quiet * 2) * scale
    img = Image.new("L", (dim, dim), 255)
    px = img.load()

    for y in range(size):
        for x in range(size):
            if grid[y, x] == 0:
                for dy in range(scale):
                    for dx in range(scale):
                        px[(x + quiet) * scale + dx, (y + quiet) * scale + dy] = 0

    return img


def main():
    if len(sys.argv) < 2:
        raise SystemExit(__doc__)

    for path in sys.argv[1:]:
        grid = matrix_from_svg(path)
        results = zxingcpp.read_barcodes(render(grid))
        print(f"{path}")
        print(f"  modules : {grid.shape[0]}x{grid.shape[1]}")
        print(f"  token   : {results[0].text if results else '<unreadable>'}")


if __name__ == "__main__":
    main()