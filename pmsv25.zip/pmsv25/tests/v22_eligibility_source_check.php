<?php
/** V22 source integration smoke test. Live DB integration is required on XAMPP separately. */
declare(strict_types=1);
$root = dirname(__DIR__);
$payroll = file_get_contents($root.'/api/services/PayrollService.php');
$scopes = file_get_contents($root.'/api/core/demostaffscope.php');
$employees = file_get_contents($root.'/api/services/EmployeeService.php');
$controller = file_get_contents($root.'/api/controllers/EmployeeController.php');
$ui = file_get_contents($root.'/frontend/employees/index.html');
$checks = [
    'Payroll full-batch eligibility scope' => str_contains($payroll, "excludingDemoUsernames('employees.id')"),
    'Approval checks explicit eligibility' => str_contains($payroll, 'AND payroll_eligible=1'),
    'No old demo approval lock' => !str_contains($payroll, 'DEMO ACCOUNT EXCLUSION'),
    'No username exclusion in eligibility helper' => !str_contains($scopes, 'LOWER(demo_ex_user.username)'),
    'Employee update persists eligibility' => str_contains($employees, "'basic_salary', 'work_schedule_id', 'status', 'payroll_eligible', 'notes'"),
    'Active-only dropdown for manual attendance' => str_contains($controller, "'status' => 'ACTIVE', 'payroll_eligible' => '1'"),
    'Editable eligibility in HR UI' => str_contains($ui, "formField('Payroll eligible'")
];
foreach ($checks as $name => $ok) { echo ($ok ? '[PASS] ' : '[FAIL] ').$name."\n"; }
exit(in_array(false, $checks, true) ? 1 : 0);
