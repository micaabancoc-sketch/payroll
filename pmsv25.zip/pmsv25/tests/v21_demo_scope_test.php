<?php
// V21's previous full-company assertions are superseded by the V25 defense scope.
// Keep this launcher so test suites that call the old file still exercise the current policy.
require __DIR__ . '/v25_staff_only_demo_scope_test.php';
