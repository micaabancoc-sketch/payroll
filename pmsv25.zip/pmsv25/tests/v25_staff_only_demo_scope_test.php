<?php
/** Staff-only demo scope: static SQL policy (no DB connection needed). */
declare(strict_types=1);
require dirname(__DIR__) . '/api/core/Database.php';
require dirname(__DIR__) . '/api/core/demostaffscope.php';
use App\Core\DemoStaffScope;
function check(bool $ok, string $why): void { if (!$ok) { fwrite(STDERR, "FAIL: {$why}\n"); exit(1); } }
check(DemoStaffScope::enabled(), 'staff_only config enabled');
foreach (['employees.id','e.id','a.employee_id','attendance.employee_id','al.employee_id'] as $alias) {
    $role = DemoStaffScope::excludingRoles($alias);
    $staff = DemoStaffScope::excludingDemoUsernames($alias);
    check(str_contains($role, "'HR_PAYROLL','MANAGER','ADMIN','KIOSK'"), 'exclude operators: '. $alias);
    check(str_contains($staff, "employee_number='EMP-000001'") || str_contains($staff, "employee_number = 'EMP-000001'"), 'only demo Staff: '. $alias);
    check(str_contains($staff, 'payroll_eligible'), 'respect eligibility: '. $alias);
}
check(DemoStaffScope::limitedDemoScope(), 'demo roster remains limited');
check(DemoStaffScope::payrollWorkflowEnabled(), 'local test enables verified payroll approval/payment');
try { DemoStaffScope::excludingRoles('users.id OR 1=1'); check(false,'injection guard'); }
catch (RuntimeException $e) { /* expected */ }
echo "PASS: V25 staff-only non-destructive demo scope\n";
