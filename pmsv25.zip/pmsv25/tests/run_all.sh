#!/usr/bin/env bash
#
# Run every check in one pass.
#
# Usage:
#   bash tests/run_all.sh [base_url]
#
# Requires a running API. Start one with:
#   PMS_TEST_CLOCK=1 php -S 127.0.0.1:8099 api/index.php
# (PMS_TEST_CLOCK lets the API end-to-end phase pin its scan timestamps so
#  the attendance flow tests hold at any hour — see tests/api_test.sh.)
#
# Database alignment: the test runner and the HTTP API process must read the
# same DB_NAME.  The API default (api/config/config.php) falls back to the
# production name attendance_payroll when DB_NAME is unset, while all test
# fixtures and helpers expect attendance_payroll_test.  Export it here so the
# whole runner (and any API child process it spawns) shares the isolated test
# database.  A fail-fast guard below verifies the value before any HTTP traffic
# is sent.

BASE="${1:-http://127.0.0.1:8099/api}"
ROOT="$(cd "$(dirname "$0")/.." && pwd)"

cd "$ROOT" || exit 1

# ------------------------------------------------------------------
# 0. Database alignment + fail-fast guard (before any HTTP traffic)
# ------------------------------------------------------------------

# Test suites and their fixtures use attendance_payroll_test.  Export it so
# the test process, the PDO helpers (testDb/reset_test_data), and any API
# child process created by this script all read the same database.
export DB_NAME="${DB_NAME:-attendance_payroll_test}"

# Fail-fast: if the variable is unset, empty, or points at a production-like
# name, abort immediately instead of sending HTTP requests against the wrong
# database and seeing "Invalid QR code" errors.
export TARGET_DB="${DB_NAME}"
if [ -z "$TARGET_DB" ]; then
  echo "ERROR: DB_NAME is not set; refusing to run against the default production database." >&2
  echo "Set DB_NAME=attendance_payroll_test (or an isolated test database) and retry." >&2
  exit 1
fi

lower_target=$(printf '%s' "$TARGET_DB" | tr '[:upper:]' '[:lower:]')
case "$lower_target" in
  attendance_payroll)
    echo "ERROR: DB_NAME is '$TARGET_DB' (the default production database)." >&2
    echo "Point DB_NAME at a test database (e.g. attendance_payroll_test) and retry." >&2
    exit 1
    ;;
  *)
    ;;
esac

PHP="${PHP_BIN:-php}"
NODE="${NODE_BIN:-node}"

STATUS=0

header() {
  echo
  echo "##########################################################"
  echo "#  $1"
  echo "##########################################################"
  echo
}

run() {
  local label="$1"
  shift

  if "$@"; then
    echo
    echo ">>> $label: OK"
  else
    echo
    echo ">>> $label: FAILED"
    STATUS=1
  fi
}

header "0/9  Database preflight"

# Refuse to touch anything that looks like production before the first
# destructive step: tests/reset_test_data.php deletes payroll periods, and the
# later phases insert attendance, payroll and setting rows. Getting DB_NAME
# wrong here would not be recoverable.
if ! "$PHP" tests/db_guard.php; then
  echo
  echo "The configured database is not a safe test target (see above)."
  exit 1
fi

# Fail here rather than at phase 5 with a puzzling "Invalid username or
# password". An unseeded database is the usual cause.
if ! "$PHP" tests/reset_test_data.php; then
  echo
  echo "The database is not ready. Fix it with:"
  echo "  mysql -u root -p < database/main.sql"
  exit 1
fi

echo "Database is seeded and test artefacts are cleared."

header "0b/9  13th-month module tables"

# The 13th-month tables may be missing on installs that imported main.sql before
# the module existed. The migration is idempotent, so always run it.
if ! "$PHP" database/migrate_13th_month.php > /dev/null 2>&1; then
  echo "The 13th-month module migration failed. Fix it before running the suite."
  exit 1
fi

echo "13th-month module tables are present."

header "0c/9  Late cut-off & automatic-absence settings"

# Same reasoning as the 13th-month migration: an install imported before this
# feature existed still needs the two settings. The migration is idempotent, so
# always run it.
if ! "$PHP" database/migrate_late_cutoff_absence.php > /dev/null 2>&1; then
  echo "The late-cutoff settings migration failed. Fix it before running the suite."
  exit 1
fi

echo "Late-cutoff and automatic-absence settings are present."

header "0d/9  Government contribution & withholding-tax tables"

# Same reasoning as the two migrations above: an install imported before the
# statutory module existed still needs the four tables, the BIR brackets and
# the six payroll columns. The migration is idempotent -- CREATE TABLE IF NOT
# EXISTS / INSERT IGNORE everywhere, and its single ALTER TABLE is reported as
# "already applied" -- so always run it. It never drops, truncates or resets a
# table. Its summary line is deliberately left visible so the schedule and
# bracket counts can be eyeballed on every pass.
if ! "$PHP" database/migrate_statutory_deductions.php; then
  echo "The statutory-deduction migration failed. Fix it before running the suite."
  exit 1
fi

echo "Government contribution and withholding-tax tables are present."

header "0e/9  Employee loans & repayment-ledger safeguard"

# Same reasoning as the migrations above: an install imported before the
# employee-loans module existed still needs the loans columns, the repayment
# ledger columns and keys - including the UNIQUE (period_id, loan_id) guard
# that keeps a PAID payroll transition from ever charging an instalment twice
# (Phase 3A) - plus the Phase 3B approval states (PENDING / REJECTED) on the
# status ENUM, the rejection_reason column and the loans.approve permission.
# The migration is idempotent; it never drops or rewrites data, and widening
# the ENUM leaves every existing loan on the status it already had.
if ! "$PHP" database/migrate_employee_loans.php; then
  echo "The employee-loans migration failed. Fix it before running the suite."
  exit 1
fi

echo "Employee-loans tables, columns and keys are present."

header "0f/9  Individual payroll payments (disbursement ledger)"

# Same reasoning as the migrations above: an install imported before the
# payments module existed still needs the payroll_payments ledger, the two
# cached aggregate columns on payroll, the status index, the two unique keys
# (reference_no + idempotency_key) and the three MANAGER permissions. The
# migration is idempotent; it never drops or rewrites a net-pay figure and only
# backfills already-disbursed rows (period PAID) or zero-net rows as PAID, so
# existing payroll rows, loan repayments and 13th-month records are preserved.
if ! "$PHP" database/migrate_payroll_payments.php > /dev/null 2>&1; then
  echo "The payroll-payments migration failed. Fix it before running the suite."
  exit 1
fi

echo "Payroll-payments ledger, aggregate columns and permissions are present."
header "0g/9  Statutory reports & remittance register"

# Same reasoning as the migrations above: an install imported before this
# module existed still needs the statutory_remittances register, its snapshot
# items and the three permissions (report.statutory, remittance.view,
# remittance.manage). The migration is idempotent -- CREATE TABLE IF NOT EXISTS
# plus INSERT-free JSON grants guarded with JSON_CONTAINS -- so a rerun leaves
# an existing register frozen. It never drops, truncates or rewrites a
# remittance. Its summary line is left visible so the remittance/item counts
# and the granted permissions can be eyeballed on every pass.
if ! "$PHP" database/migrate_statutory_remittances.php; then
  echo "The statutory-remittances migration failed. Fix it before running the suite."
  exit 1
fi

echo "Statutory-remittance register, snapshot items and permissions are present."

header "0h/9  Rest day swap table & role permissions"

# The rest_day_swaps table plus MANAGER/STAFF role permissions are created
# idempotently; rerunning is safe.
if ! "$PHP" database/migrate_rest_day_swaps.php; then
  echo "The rest-day-swap migration failed. Fix it before running the suite."
  exit 1
fi

echo "Rest-day-swap table and permissions are present."

header "1/9  PHP syntax (every .php file)"
FAILED=""

for file in $(find api database tests -name '*.php' | sort); do
  if ! "$PHP" -l "$file" > /dev/null 2>&1; then
    echo "SYNTAX ERROR: $file"
    "$PHP" -l "$file"
    FAILED="$FAILED $file"
  fi
done

if [ -z "$FAILED" ]; then
  echo "All PHP files parse cleanly."
else
  STATUS=1
fi

header "2/9  Frontend JavaScript syntax"
run "JavaScript syntax" "$NODE" tests/js_syntax_check.js || STATUS=1

header "3/9  Frontend JavaScript behaviour"
run "JavaScript behaviour" "$NODE" tests/frontend_js_test.js || STATUS=1

header "4/9  PDO placeholder reuse"
run "PDO placeholders" "$PHP" tests/placeholder_check.php || STATUS=1

header "5/9  QR encoder verification"
if command -v python > /dev/null 2>&1 && python -c "import segno" > /dev/null 2>&1; then
  run "QR matrices vs segno" python tests/verify_qr.py || STATUS=1
else
  echo "SKIP — python + segno not available (QR output was verified during development)."
fi

header "6/9  API end-to-end suite"
run "API end-to-end" bash tests/api_test.sh "$BASE" || STATUS=1

header "7/9  QR permission boundaries"

# The end-to-end suite deliberately floods the scan endpoint, which blocks this
# client for 300 seconds. Clear the limiter so the remaining phases start clean
# -- they assert on status codes, and a 429 would read as a permission failure.
"$PHP" tests/reset_test_data.php > /dev/null 2>&1 || true

# Generation is administrator-only; everyone may read only their own code.
run "QR permissions" bash tests/qr_perm_check.sh || STATUS=1

header "8/9  Frontend contract smoke test"
run "Frontend contract" bash tests/frontend_smoke.sh "$BASE" || STATUS=1

header "9/9  Entry point & navigation"

# Serves the static frontend, so it needs the web server rather than the API
# base. Override with SITE_ROOT when running from a different host.
run "Entry point" bash tests/routing_test.sh "${SITE_ROOT:-http://localhost/pms}" || STATUS=1

header "10/10  13th-month pay calculation (database-backed, rollback-safe)"
run "13th-month calculation" "$PHP" tests/thirteenth_pay_test.php || STATUS=1

header "11/11  Forced password change flow"

# A reset issues the shared temporary password, chains the account to the
# change-password screen, and only a real password releases it. Runs over HTTP
# like the end-to-end suite; its probe rows are removed again before it exits.
run "Forced password change" "$PHP" tests/forced_password_change_test.php "$BASE" || STATUS=1

header "12/12  Late cut-off (30 min) & automatic absence rule"

# Proves the rule end to end: 29 min allowed, exactly 30 and 31 denied + ABSENT,
# for STAFF and MANAGER, through every entry point and the reconciler that
# marks absence without a scan. Its fixtures (shifts, schedules, employees,
# users, leaves, holidays, QR images) are all removed before it exits.
run "Late cut-off & absence" "$PHP" tests/late_cutoff_absence_test.php "$BASE" || STATUS=1

header "13/13  Government contributions & withholding tax"

# Proves the seeded schedules really are the published ones (SSS Circular
# 2024-006, PhilHealth Advisory 2025-0002, Pag-IBIG Circular No. 460 and BIR
# RR 11-2018 Annex E), that every rate, floor, ceiling, MSC credit step and tax
# bracket is applied correctly, that a monthly contribution is allocated to a
# twice-monthly payroll so both halves add up to exactly one month, and that net
# pay is still gross pay minus employee deductions. It opens its own payroll
# period (2026-07-01 to 2026-07-31, which does not overlap the end-to-end
# suite's 2026-11-01 period) and removes every fixture before it exits.
run "Statutory deductions" "$PHP" tests/statutory_deductions_test.php || STATUS=1

header "14/14  Payroll calculation accuracy (engine, locks, 13th-month integration)"

# Proves with independent manual arithmetic that basic pay is present-days x the
# daily rate, that holiday pay reaches gross pay exactly once (including a paid
# holiday nobody recorded - the calendar, not the attendance ledger, is the
# source of truth), that overtime/night differential/allowances keep their own
# classification, that an absent or unpaid-leave day is charged once, that a
# draft recalculation duplicates no rows or items, that finalized/paid payroll
# cannot be recalculated, and that a year of 360,000.00 of basic salary produces
# 30,000.00 of 13th-month pay. Everything runs inside one transaction that is
# rolled back, and it refuses a production-looking database (tests/db_guard.php).
run "Payroll calculation" "$PHP" tests/payroll_calculation_test.php || STATUS=1

header "15/15  Employee loans (approval workflow, semi-monthly split, PAID commit)"

# Proves the Phase 3A fixes: the engine splits a monthly deduction across the
# pay periods of the month, a payroll calculation only proposes instalments,
# the repayment ledger (and the balances) move atomically and exactly once at
# the PAID transition, recordPayment() cannot overpay a loan, and the repair
# path still reverses pre-fix draft rows correctly. On top of that it proves the
# Phase 3B approval workflow end to end: a filed loan is PENDING and is neither
# deducted nor repaid, only an approver who is NOT the user who filed it can
# move it to ACTIVE (self-approval prevention, in the service and at the
# database), a rejection requires a reason and is terminal, restoring a
# withdrawn filing returns it to PENDING rather than ACTIVE, and approving is
# what makes the next payroll run propose the instalment. Everything runs inside
# one transaction that is rolled back, and it refuses a production-looking
# database (tests/db_guard.php).
run "Loan management" "$PHP" tests/loan_management_test.php || STATUS=1

header "16/16  Individual payroll payments (ledger, partial payments, PAID gate)"

# Proves the Phase 5 disbursement ledger end to end: a draft period is not
# payable, a FINALIZED row accumulates COMPLETED payments against net_pay
# exactly (₱5,000 then ₱10,000 on a ₱15,000 net), an overpayment is rejected,
# a FAILED attempt never reduces the balance, a CANCELLED row is excluded from
# the paid total but its history is preserved, a fully-paid row refuses further
# payments, a retried request with the same idempotency key returns the original
# row instead of writing a second one, and the period cannot move FINALIZED ->
# PAID while any required salary payment is outstanding — after every row is
# disbursed the gate opens and the loan repayments commit exactly once.
run "Payroll payments" "$PHP" tests/payroll_payments_test.php || STATUS=1
header "17/17  Statutory reports & remittance tracking"

# Proves the Phase 6 report layer end to end against the same locked-period
# evidence the remittance service files from: the contribution register only
# reports locked periods (a DRAFT is excluded), filters by agency/code/employee
# and date window, the remittance register lists what StatutoryRemittanceService
# committed without recomputing anything, and the per-agency/month summary
# reconciles to the filed register totals. It also asserts the report methods
# never disagree with the remittance service about which agency files a code.
run "Statutory reports & remittances" "$PHP" tests/statutory_remittances_report_test.php || STATUS=1

header "18/18  Rest day swap / exchange workflow"

# Proves the rest-day-swap lifecycle: create (PENDING), other employee
# respond (ACCEPT/DECLINE), manager approve/reject, schedule update on
# approval, cancel, and list. Runs inside the test database with its own
# setup/teardown; refuses production-looking databases via db_guard.
run "Rest day swap" "$PHP" tests/rest_day_swap_test.php || STATUS=1


echo
echo "##########################################################"
if [ "$STATUS" -eq 0 ]; then
  echo "#  ALL CHECKS PASSED"
else
  echo "#  SOME CHECKS FAILED"
fi
echo "##########################################################"

exit "$STATUS"
