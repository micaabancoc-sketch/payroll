#!/usr/bin/env node
/**
 * Syntax-check every piece of frontend JavaScript.
 *
 * Extracts each inline <script> block from the HTML pages and parses it with
 * `new Function`, then parses the standalone js/*.js files. This catches typos
 * such as an unbalanced parenthesis that PHP linting and HTML validity checks
 * both miss.
 *
 * Usage: node tests/js_syntax_check.js
 */

'use strict';

const fs = require('fs');
const os = require('os');
const path = require('path');
const { spawnSync } = require('child_process');

const ROOT = path.resolve(__dirname, '..');
const FRONTEND = path.join(ROOT, 'frontend');

let failures = 0;
let checked = 0;

function walk(dir, extension) {
  const results = [];

  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    const full = path.join(dir, entry.name);

    if (entry.isDirectory()) {
      results.push(...walk(full, extension));
    } else if (entry.name.endsWith(extension)) {
      results.push(full);
    }
  }

  return results;
}

function report(file, detail) {
  failures += 1;
  console.log(`FAIL  ${path.relative(ROOT, file).replace(/\\/g, '/')}`);
  console.log(`      ${detail}`);
}

// --- no-op character replacements ------------------------------------------
//
// `.replace(/&/g, '&')` looks like escaping and does nothing. That pattern sat
// inside escapeHtml, which meant every interpolated value reached innerHTML
// unescaped while the code read as if it were safe.
const NOOP_REPLACE = /\.replace\(\/(\\?.)\/g\s*,\s*(['"])(.*?)\2\)/g;

function checkNoopReplaces(file, source) {
  let match;

  NOOP_REPLACE.lastIndex = 0;

  while ((match = NOOP_REPLACE.exec(source)) !== null) {
    const needle = match[1];
    const replacement = match[3];

    // Only single-character needles: an escaped backslash needs care that is
    // not worth the complexity here.
    if (needle.length === 1 && needle === replacement) {
      const line = source.slice(0, match.index).split('\n').length;

      report(
        file,
        `line ${line}: .replace(/${needle}/g, ${replacement}) replaces a character with `
        + 'itself — it is a no-op'
      );
    }
  }
}

// --- ES module support ------------------------------------------------------
//
// `frontend/js/modules/*.js` are real ES modules (`import` / `export`). The
// classic-script parser used below cannot read them — `export` is a syntax
// error inside `new Function` — so the check used to report a problem in a
// file that is perfectly valid. Those files are parsed as modules instead,
// which is also the stricter test: it is exactly how the browser loads them.
const ES_MODULE = /^[ \t]*(?:import\s[^;]*?from\s*['"][^'"]+['"]|import\s*['"][^'"]+['"]|export\s+(?:default\b|const\b|let\b|var\b|function\b|class\b|async\s+function\b|\{|\*))/m;

/** Parse a module with Node itself. Returns null, or the error message. */
function moduleSyntaxError(source) {
  const directory = fs.mkdtempSync(path.join(os.tmpdir(), 'pms-jscheck-'));
  const file = path.join(directory, 'module.mjs');

  try {
    fs.writeFileSync(file, source);
    const result = spawnSync(process.execPath, ['--check', file], { encoding: 'utf8' });

    if (result.status === 0) {
      return null;
    }

    const stderr = String(result.stderr || '').trim();
    const line = stderr.split('\n').find(l => /error/i.test(l));
    return (line || stderr || 'module syntax error').trim();
  } finally {
    fs.rmSync(directory, { recursive: true, force: true });
  }
}

// --- standalone scripts ----------------------------------------------------
for (const file of walk(FRONTEND, '.js')) {
  const source = fs.readFileSync(file, 'utf8');

  checkNoopReplaces(file, source);

  if (ES_MODULE.test(source)) {
    const error = moduleSyntaxError(source);

    if (error === null) {
      checked += 1;
    } else {
      report(file, error);
    }

    continue;
  }

  try {
    new Function(source);
    checked += 1;
  } catch (error) {
    report(file, error.message);
  }
}

// --- every HTML page -------------------------------------------------------
// The sign-in page lives at the project root; the rest are under frontend/.
function htmlPages() {
  const pages = walk(FRONTEND, '.html');

  for (const entry of fs.readdirSync(ROOT, { withFileTypes: true })) {
    if (entry.isFile() && entry.name.endsWith('.html')) {
      pages.push(path.join(ROOT, entry.name));
    }
  }

  return pages;
}

const SCRIPT = /<script(?![^>]*\bsrc=)[^>]*>([\s\S]*?)<\/script>/g;

for (const file of htmlPages()) {
  const html = fs.readFileSync(file, 'utf8');

  let match;
  let index = 0;

  while ((match = SCRIPT.exec(html)) !== null) {
    index += 1;

    checkNoopReplaces(file, match[1]);

    try {
      new Function(match[1]);
      checked += 1;
    } catch (error) {
      const line = html.slice(0, match.index).split('\n').length;
      report(file, `inline script #${index} (starts near line ${line}): ${error.message}`);
    }
  }
}

// --- every getElementById target must exist --------------------------------
const ID_ATTRIBUTE = /\bid="([^"]+)"/g;
const GET_BY_ID = /getElementById\(\s*['"]([^'"]+)['"]\s*\)/g;

let missingIds = 0;

for (const file of htmlPages()) {
  const html = fs.readFileSync(file, 'utf8');

  const ids = new Set();
  let m;

  while ((m = ID_ATTRIBUTE.exec(html)) !== null) {
    ids.add(m[1]);
  }

  const referenced = new Set();

  while ((m = GET_BY_ID.exec(html)) !== null) {
    referenced.add(m[1]);
  }

  for (const id of referenced) {
    if (ids.has(id)) { continue; }

    // Elements rendered later by JavaScript (e.g. modal bodies) legitimately
    // have no markup, but the id must still appear as a string in the file.
    const asString = `'${id}'`;
    const asDouble = `"${id}"`;
    const occurrences = html.split(asString).length + html.split(asDouble).length - 2;

    if (occurrences > 1) { continue; }

    missingIds += 1;
    console.log(
      `FAIL  ${path.relative(ROOT, file).replace(/\\/g, '/')}  `
      + `getElementById('${id}') has no matching id in the markup`
    );
  }
}

failures += missingIds;

console.log('');
console.log(`${checked} script block(s) parsed, ${missingIds} missing DOM id(s).`);

if (failures === 0) {
  console.log('Frontend JavaScript is syntactically valid.');
  process.exit(0);
}

console.log(`${failures} problem(s) found.`);
process.exit(1);