<?php
/** Offline static regression for the explicitly-enabled one-staff payroll demo. */
declare(strict_types=1);
require dirname(__DIR__) . '/api/core/Database.php';
require dirname(__DIR__) . '/api/core/demostaffscope.php';
use App\Core\DemoStaffScope;
function ensure(bool $condition, string $why): void { if (!$condition) { fwrite(STDERR,"FAIL: $why\n"); exit(1); } }
$root = dirname(__DIR__);
ensure(DemoStaffScope::enabled(), 'demo staff-only roster remains enabled');
ensure(DemoStaffScope::payrollWorkflowEnabled(), 'local demo payroll workflow is enabled');
$payroll = file_get_contents($root.'/api/services/PayrollService.php');
$payments = file_get_contents($root.'/api/services/PayrollPaymentService.php');
$ui = file_get_contents($root.'/frontend/payroll/index.html');
ensure(str_contains($payroll, "? 'DRAFT' : 'FOR_REVIEW'"), 'clean batch moves to review');
ensure(str_contains($payroll, "DemoStaffScope::excludingDemoUsernames('employees.id')"), 'payroll eligibility staff-only');
ensure(str_contains($payroll, '!isset($expected[$id])'), 'exclude nonstaff payroll rows');
ensure(str_contains($payroll, 'commitLoanRepayments($periodId, $userId)'), 'loan repayment commits on PAID');
ensure(str_contains($payments, 'Could not verify salary payment status'), 'payment status failure fails closed');
ensure(str_contains($ui, 'data-action="PAID"'), 'Mark Period Paid action visible');
ensure(str_contains($ui, 'Salary Payment Records'), 'payment workspace retained');
ensure(str_contains(file_get_contents($root.'/api/config/config.php'), "'enable_payroll_workflow' => true"), 'test flag configured');
echo "PASS: local staff-only payroll release static test\n";
