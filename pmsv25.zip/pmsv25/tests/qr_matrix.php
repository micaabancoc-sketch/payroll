<?php
declare(strict_types=1);

require __DIR__ . '/../api/services/QrCodeGenerator.php';

use App\Services\QrCodeGenerator;

$mode     = $argv[1] ?? 'dump';
$offset   = in_array($mode, ['--svg', '--cw'], true) ? 2 : 1;

$text     = $argv[$offset]     ?? 'ATT-EMP-8F72A9C1-4D31';
$eccLevel = $argv[$offset + 1] ?? 'M';
$mask     = isset($argv[$offset + 2]) ? (int) $argv[$offset + 2] : null;

$generator = new QrCodeGenerator();
$result    = $generator->encode($text, $eccLevel, $mask);

if ($mode === '--svg') {
    echo $generator->toSvg($result['matrix'], 8, 4), PHP_EOL;
    exit;
}

if ($mode === '--cw') {
    echo "VERSION {$result['version']} MASK {$result['mask']}\n";
    echo implode(' ', $result['codewords']), "\n";
    exit;
}

echo "VERSION {$result['version']} MASK {$result['mask']}\n";
foreach ($result['matrix'] as $row) {
    $line = '';
    foreach ($row as $cell) {
        $line .= $cell ? '1' : '0';
    }
    echo $line . "\n";
}