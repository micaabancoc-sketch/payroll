<?php
/**
 * Run-scoped fixture cleanup for tests/api_test.sh (Phase 21).
 *
 * The end-to-end suite provisions a brand new employee plus its linked login
 * account on every pass (username test.user.<epoch>). reset_test_data.php
 * clears the payroll periods, the rate-limit buckets and any locked accounts,
 * but it cannot clear the employee: it has no way to tell a test row from a
 * genuine one. Left to itself, every pass therefore leaves another employee and
 * account behind, along with the attendance, leave, overtime, payroll and QR
 * rows that hang off it.
 *
 * So the suite cleans up after itself here, from an EXIT trap, on the success
 * path and the failure path alike.
 *
 * Ownership is proven, never guessed. api_test.sh captures the exact employee id
 * and linked user id from the Add-Employee response and passes them in; this
 * script deletes those ids and nothing else. It never selects rows by name or by
 * a 'test.user.%' prefix, so genuine data can never be touched. As a second lock
 * the linked account's username must match the one the pass created and the
 * account must actually belong to the employee id we were given.
 *
 * Deleting the employee cascades its attendance, leave, overtime, QR, payroll,
 * salary-history and 13th-month rows (see the ON DELETE CASCADE foreign keys in
 * database/main.sql). Two references do NOT cascade and are handled explicitly,
 * children first:
 *   - attendance_logs.employee_id is ON DELETE SET NULL, so the scan evidence
 *     trail for the fixture is deleted before the employee, otherwise those rows
 *     would be orphaned and pile up on every pass;
 *   - users.employee_id is ON DELETE SET NULL, so the linked login account is
 *     deleted by id (which in turn cascades its api_tokens).
 *
 * The database is guarded twice: db_guard.php refuses a production name and the
 * genuine 'attendance_payroll' database, and this script refuses the genuine
 * database even when the guard was deliberately overridden with
 * PMS_ALLOW_GENUINE_DB=1.
 *
 * Usage:
 *   php tests/cleanup_api_fixture.php <employee_id> [user_id] [account_username]
 *
 * Exit codes: 0 = removed or already gone, 2 = database unreachable,
 *             3 = refused (unsafe target or failed ownership check),
 *             4 = the delete itself failed.
 */

declare(strict_types=1);

require __DIR__ . '/db_guard.php';

// Refuse a production or genuine-use target before touching anything.
pmsAssertSafeTestDatabase();

$employeeId = (int) ($argv[1] ?? 0);
$userId     = (int) ($argv[2] ?? 0);
$username   = (string) ($argv[3] ?? '');

if ($employeeId <= 0) {
    // The suite aborted before it created anything (for example it never got a
    // token), so there is nothing to clean up. That is not an error.
    echo "No fixture id supplied; nothing to clean up.\n";
    exit(0);
}

$config = require __DIR__ . '/../api/config/config.php';
$db     = $config['database'];

// The guard already refuses 'attendance_payroll'; make it unconditional here so
// an operator who overrode the guard (PMS_ALLOW_GENUINE_DB=1) still cannot have
// this script delete from the genuine working database by accident.
if (strcasecmp((string) ($db['name'] ?? ''), 'attendance_payroll') === 0) {
    fwrite(STDERR, "Refusing to clean up: DB_NAME is the genuine 'attendance_payroll' database.\n");
    exit(3);
}

try {
    $pdo = new PDO(
        sprintf(
            'mysql:host=%s;port=%d;dbname=%s;charset=%s',
            $db['host'],
            $db['port'],
            $db['name'],
            $db['charset'] ?? 'utf8mb4'
        ),
        $db['user'],
        $db['password'],
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
    );
} catch (PDOException $e) {
    fwrite(STDERR, "Cannot reach the database: {$e->getMessage()}\n");
    exit(2);
}

// ---------------------------------------------------------------------------
// Ownership check: only proceed when the ids really name the fixture this pass
// created. When the account username was supplied it must match exactly, and the
// account must belong to the employee id we were given.
// ---------------------------------------------------------------------------

if ($userId > 0) {
    $stmt = $pdo->prepare('SELECT id, username, employee_id FROM users WHERE id = :id');
    $stmt->execute(['id' => $userId]);
    $account = $stmt->fetch(PDO::FETCH_ASSOC) ?: null;

    if ($account === null) {
        // Already gone; fall back to the employee link below.
        $userId = 0;
    } else {
        if ((int) $account['employee_id'] !== $employeeId) {
            fwrite(STDERR, sprintf(
                "Refusing to clean up: account %d is not linked to employee %d.\n",
                $userId,
                $employeeId
            ));
            exit(3);
        }

        if ($username !== '' && (string) $account['username'] !== $username) {
            fwrite(STDERR, sprintf(
                "Refusing to clean up: account %d is '%s', not the expected '%s'.\n",
                $userId,
                $account['username'],
                $username
            ));
            exit(3);
        }
    }
}

// ---------------------------------------------------------------------------
// Remove the fixture, children first. Everything else cascades from employees.
// ---------------------------------------------------------------------------

$pdo->beginTransaction();

try {
    // attendance_logs.employee_id is ON DELETE SET NULL, so delete the scan
    // trail first to avoid leaving orphaned evidence rows behind.
    $logs = $pdo->prepare('DELETE FROM attendance_logs WHERE employee_id = :id');
    $logs->execute(['id' => $employeeId]);
    $logRows = $logs->rowCount();

    // The linked login account. users.employee_id is ON DELETE SET NULL, so the
    // account must be removed explicitly; the employee link is used only when
    // the response did not expose an account id.
    if ($userId > 0) {
        $del = $pdo->prepare('DELETE FROM users WHERE id = :id');
        $del->execute(['id' => $userId]);
    } else {
        $del = $pdo->prepare('DELETE FROM users WHERE employee_id = :id');
        $del->execute(['id' => $employeeId]);
    }
    $accountRows = $del->rowCount();

    // The employee. Its attendance, leave, overtime, QR, payroll, salary-history
    // and 13th-month rows cascade away with it.
    $emp = $pdo->prepare('DELETE FROM employees WHERE id = :id');
    $emp->execute(['id' => $employeeId]);
    $employeeRows = $emp->rowCount();

    $pdo->commit();
} catch (\Throwable $e) {
    $pdo->rollBack();
    fwrite(STDERR, "Fixture cleanup failed: {$e->getMessage()}\n");
    exit(4);
}

// The auto-issued QR is written to storage/qrcodes as emp-<id>-qr*.svg. Remove
// the files too, so a re-used id cannot inherit a stale badge image.
$qrDir        = rtrim((string) ($config['paths']['qrcodes'] ?? ''), '/\\');
$removedFiles = 0;

foreach (glob($qrDir . '/emp-' . $employeeId . '-qr*.svg') ?: [] as $file) {
    if (@unlink($file)) {
        $removedFiles++;
    }
}

if ($employeeRows === 0 && $accountRows === 0 && $logRows === 0 && $removedFiles === 0) {
    printf("Fixture already gone (employee %d).\n", $employeeId);
    exit(0);
}

printf(
    "Removed employee %d, %d account row(s), %d attendance_logs row(s) and %d QR image(s).\n",
    $employeeId,
    $accountRows,
    $logRows,
    $removedFiles
);