<?php
/** Offline regression for the V23.2 Sunday classification policy (no MariaDB required). */
declare(strict_types=1);
namespace App\Core {
    final class Database {
        public static array $row = [];
        public static array $saved = [];
        public static function scalar(string $sql, array $params = []): mixed {
            if (str_contains($sql, 'work_schedules')) return 1;
            if (str_contains($sql, 'SUM(applied_hours)')) return 0;
            if (str_contains($sql, 'COUNT(*) FROM overtime_requests')) return 0;
            return null;
        }
        public static function selectOne(string $sql, array $params = []): ?array {
            if (str_contains($sql, 'FROM employees')) return ['work_schedule_id'=>1];
            if (str_contains($sql, 'FROM work_schedule_days')) {
                return ((int)$params['dow'] === 0)
                    ? ['is_rest_day'=>1,'shift_id'=>null]
                    : ['is_rest_day'=>0,'shift_id'=>2];
            }
            if (str_contains($sql, 'FROM shifts')) return [
                'id'=>2,'start_time'=>'08:00:00','end_time'=>'17:00:00',
                'break_start'=>'12:00:00','break_end'=>'13:00:00','grace_period_minutes'=>0,
                'is_overnight'=>0,
            ];
            if (str_contains($sql, 'FROM attendance')) return array_merge(self::$row,self::$saved);
            return null;
        }
        public static function select(string $sql, array $params = []): array {
            return str_contains($sql,'FROM attendance WHERE') ? [self::$row] : [];
        }
        public static function update(string $table, array $data, array $where): int {
            if ($table === 'attendance') { self::$saved = $data; }
            return 1;
        }
    }
    final class Settings {
        public static function int(string $key, int $fallback=0): int { return $fallback; }
        public static function float(string $key, float $fallback=0): float { return $fallback; }
        public static function string(string $key, string $fallback=''): string { return $fallback; }
        public static function bool(string $key, bool $fallback=false): bool { return $fallback; }
    }
}
namespace App\Services {
    require_once __DIR__ . '/../api/services/AttendanceEngine.php';
    require_once __DIR__ . '/../api/services/PayrollEngine.php';
    function must(bool $result,string $message): void {
        if (!$result) throw new \RuntimeException('FAIL: '.$message);
        echo 'PASS: '.$message."\n";
    }
    $engine = new AttendanceEngine();
    $record = [
        'id'=>500,'employee_id'=>3,'attendance_date'=>'2026-10-18',
        'time_in'=>'2026-10-18 08:00:00','time_out'=>'2026-10-18 17:00:00',
        'source'=>'MANUAL','status'=>'PRESENT','remarks'=>null,
    ];
    \App\Core\Database::$row=$record;
    \App\Core\Database::$saved=[];
    $result=$engine->recalculate($record);
    must($result['status']==='REST_DAY', 'Sunday manual Time In/Out stays REST_DAY');
    must((float)$result['worked_hours']===0.0,'Sunday manual time log has zero regular worked hours');
    must((float)$result['overtime_hours']===0.0,'Sunday manual time log never infers OT');
    must((int)$result['late_minutes']===0 && (int)$result['undertime_minutes']===0,'Sunday has no late or undertime deductions');
    must($result['time_in']===$record['time_in'] && $result['time_out']===$record['time_out'], 'Sunday raw timestamps are preserved');

    $record['time_out']=null;
    \App\Core\Database::$row=$record;
    \App\Core\Database::$saved=[];
    $result=$engine->recalculate($record);
    must($result['status']==='REST_DAY','Sunday time-in alone still displays REST_DAY');

    $record['attendance_date']='2026-10-19';
    $record['time_in']='2026-10-19 08:00:00';
    $record['time_out']='2026-10-19 17:00:00';
    \App\Core\Database::$row=$record;
    \App\Core\Database::$saved=[];
    $result=$engine->recalculate($record);
    must($result['status']==='PRESENT','Monday regular day is PRESENT');
    must((float)$result['worked_hours']===8.0,'Monday 08:00-17:00 minus lunch = 8h');
    must((float)$result['overtime_hours']===0.0,'Monday unassigned OT is zero');
    $payroll = new PayrollEngine($engine);
    $employee = ['id'=>3, 'date_hired'=>'2026-01-05'];
    $restManual = [
        'attendance_date'=>'2026-10-18','status'=>'PRESENT','time_in'=>'2026-10-18 08:00:00',
        'time_out'=>'2026-10-18 17:00:00','source'=>'MANUAL',
    ];
    \App\Core\Database::$row=$restManual;
    $issues=$payroll->attendanceExceptions($employee,'2026-10-18','2026-10-18');
    must(count($issues)===0,'Manual Sunday time log does not block payroll as unresolved work');
    \App\Core\Database::$row=array_merge($restManual,['source'=>'QR']);
    $issues=$payroll->attendanceExceptions($employee,'2026-10-18','2026-10-18');
    must(count($issues)===1 && $issues[0]['reason']==='REST_DAY_WORK_REQUIRES_VERIFIED_PREMIUM_REVIEW',
        'Unverified QR Sunday work evidence still requires payroll review');
    echo 'All offline Sunday policy regression tests passed.\n';
}
