<?php
declare(strict_types=1);
require dirname(__DIR__).'/api/services/PayrollCalendarService.php';
use App\Services\PayrollCalendarService as C;
function check($actual,$expected){if ($actual !== $expected) throw new RuntimeException('Expected '.json_encode($expected).' got '.json_encode($actual));}
check(C::periodsForMonth(2026,10),[['2026-10-01','2026-10-15','2026-10-20'],['2026-10-16','2026-10-31','2026-11-05']]);
check(C::periodsForMonth(2028,2)[1][1],'2028-02-29');
check(C::adjustedPayday('2026-12-20'),'2026-12-18');
check(C::adjustedPayday('2026-12-20',['2026-12-18']),'2026-12-17');
check(C::adjustedPayday('2026-11-05',['2026-11-05']),'2026-11-04');
echo "Payroll calendar policy tests passed\n";
