<?php
$path = 'c:\xampp\htdocs\pms\tests\overtime_midnight_completion_test.php';
$content = file_get_contents($path);

// Fix test 6 update calls to pass REF_NOW
$content = str_replace("'end_time' => REF_LATE,\n        ]);", "'end_time' => REF_LATE,\n        ], null, REF_NOW);", $content);
$content = str_replace("'end_time' => REF_END,\n        ]);", "'end_time' => REF_END,\n        ], null, REF_NOW);", $content);

file_put_contents($path, $content);
echo "Done\n";