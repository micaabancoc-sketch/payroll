<?php
// Contact-number validation check (read-only, no DB writes).
// Covers: 2 digits, 11-digit PH mobile, 12-digit, 30 chars, 31 chars, leading zero.
declare(strict_types=1);
require __DIR__ . '/../api/core/Validator.php';
require __DIR__ . '/../api/services/EmployeeService.php';

use App\Services\EmployeeService;

function checkContact(string $label, string $value): array {
  $data = [
    'first_name' => 'Test', 'gender' => 'MALE', 'date_hired' => '2026-01-05',
    'employment_type' => 'FULL_TIME', 'salary_type' => 'MONTHLY',
    'basic_salary' => 1000, 'contact_number' => $value,
  ];
  $v = App\Core\Validator::make($data, EmployeeService::rules());
  $out = $v->errors()['contact_number'] ?? null;
  $validated = $v->validated()['contact_number'] ?? '(missing)';
  return [
    'label' => $label, 'value' => $value, 'len' => mb_strlen($value),
    'passes' => $out === null,
    'error' => $out, 'stored_as' => $validated . ' (' . gettype($validated) . ')',
  ];
}

$cases = [
  checkContact('2 digits', '12'),
  checkContact('11-digit PH mobile', '09970923320'),
  checkContact('12-digit', '639970923320'),
  checkContact('30 chars', str_repeat('9', 30)),
  checkContact('31 chars (must fail)', str_repeat('9', 31)),
  checkContact('leading zero preserved', '09171234567'),
];

// Update rules must behave the same (Edit Employee path).
$upd = App\Core\Validator::make(
  ['contact_number' => '09970923320'],
  EmployeeService::rules(true)
);
echo json_encode(['cases' => $cases, 'update_11digit_passes' => !$upd->fails()], JSON_PRETTY_PRINT), "\n";
