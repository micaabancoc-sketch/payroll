<?php
$path = 'c:\xampp\htdocs\pms\tests\overtime_midnight_completion_test.php';
$content = file_get_contents($path);

// Add null, REF_NOW after the create call for test 4
$lines = explode("\n", $content);
$modified = false;
for ($i = 0; $i < count($lines); $i++) {
    if (strpos($lines[$i], "Valid midnight window creation test") !== false) {
        // Find the ']);' line after this reason line
        for ($j = $i; $j < min($i + 5, count($lines)); $j++) {
            if (trim($lines[$j]) === "]);") {
                $lines[$j] = str_replace("]);", "], null, REF_NOW);", $lines[$j]);
                $modified = true;
                echo "Line $j changed to: " . $lines[$j] . "\n";
                break;
            }
        }
        break;
    }
}

if ($modified) {
    file_put_contents($path, implode("\n", $lines));
    echo "Done\n";
} else {
    echo "No changes made\n";
    // Debug
    for ($i = 0; $i < count($lines); $i++) {
        if (strpos($lines[$i], "Valid midnight window creation test") !== false) {
            echo "Found reason at line $i\n";
            for ($j = $i; $j < min($i + 5, count($lines)); $j++) {
                echo "  Line $j: [" . $lines[$j] . "]\n";
            }
        }
    }
}