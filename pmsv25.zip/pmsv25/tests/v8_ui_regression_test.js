#!/usr/bin/env node
'use strict';
const fs = require('fs');
const path = require('path');
const vm = require('vm');
const assert = require('assert');
const root = path.resolve(__dirname, '..');
const html = (p) => fs.readFileSync(path.join(root, p), 'utf8');
const source = html('frontend/js/app.js');
const permissions = {
  ADMIN: ['*'],
  HR_PAYROLL: ['dashboard.view','employees.view','attendance.view_own','leave.view_own','overtime.view_own','payroll.period.view','payroll.payslip.view_own','loans.view','report.attendance'],
  MANAGER: ['dashboard.view','employees.view','attendance.view_own','leave.view_own','overtime.view_own','payroll.period.view','payroll.payslip.view_own','report.attendance'],
  STAFF: ['dashboard.view','attendance.view_own','leave.view_own','overtime.view_own','profile.view_own','payroll.payslip.view_own','loans.view_own'],
};
let user = null;
const nav = { innerHTML: '' };
const document = {readyState:'loading',body:{classList:{toggle(){},remove(){}}},
  querySelector(s){return s==='[data-nav]'?nav:null},querySelectorAll(){return []}, addEventListener(){}
};
const window = {addEventListener(){},matchMedia(){return {matches:false}},innerWidth:1024};window.window = window;
const Api = {user: () => user};
vm.runInNewContext(source, {window, Api, document, Promise, console});
let checked=0;
for (const [role, grants] of Object.entries(permissions)) {
  user={role,permissions:grants};
  window.App.renderNav(role==='STAFF'?'my-qr':'dashboard');
  const links = [...nav.innerHTML.matchAll(/<a\b[^>]*href="([^"]+)"[^>]*>([\s\S]*?)<\/a>/g)];
  assert.ok(links.length > 0, role+' has menu links');
  for (const link of links) {
    assert.ok(!link[2].includes('undefined'), `${role} must not render undefined icon`);
    const relative = link[1].split('#')[0];
    assert.ok(fs.existsSync(path.join(root,'frontend',relative)), `${role}: ${relative} resolves to a real page`);
    assert.ok(link[2].includes('<svg'), `${role}: nav item has defined SVG icon`);
    checked++;
  }
  assert.strictEqual(nav.innerHTML.includes('profile/my-qr.html'),role==='STAFF',role+' own QR page access');
  assert.strictEqual(nav.innerHTML.includes('payroll/deductions.html'),role==='ADMIN'||role==='HR_PAYROLL',role+' deductions menu scope');
}
assert.ok(html('frontend/profile/my-qr.html').includes('my-qr-image'),'dedicated QR visible at top');
assert.ok(html('frontend/js/my-qr.js').includes("Api.qrSvg(employeeId)"),'QR comes from own server-backed account');
assert.ok(html('api/controllers/QrController.php').includes('Auth::requireSelfOrQrPermission($employeeId)'),'QR API protects ownership');
assert.ok(html('frontend/payroll/deductions.html').includes('System-managed (reference only)'),'Legacy government rows explained');
assert.ok(html('frontend/payroll/adjustments.html').includes('No adjustments submitted yet'),'Manager adjustment empty state explained');
console.log(`PASS: ${checked} sidebar links (4 roles), no undefined, QR privacy, permission scope, readable empty states`);
