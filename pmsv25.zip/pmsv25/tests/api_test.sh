#!/usr/bin/env bash
#
# End-to-end API test suite (Phase 21).
#
# Exercises the full flow: auth -> employee -> QR -> scan -> leave ->
# overtime -> payroll -> payslip -> lock, plus the security checks.
#
# Usage: bash tests/api_test.sh [base_url]
#
# Phase 6/7 pins its scan timestamps via a `scanned_at` body field, honoured
# only when the API test server runs with PMS_TEST_CLOCK=1:
#   PMS_TEST_CLOCK=1 php -S 127.0.0.1:8099 api/index.php

# Database alignment + fail-fast guard.
#
# The test process and the HTTP API process must read the same DB_NAME.
# The API default (api/config/config.php) falls back to the production name
# attendance_payroll when DB_NAME is unset, while all test fixtures and
# helpers expect attendance_payroll_test.  Export it here so the test script
# and any API child process share the isolated test database.  A fail-fast
# guard below verifies the value before any HTTP requests are sent.

# Test fixtures and helpers use attendance_payroll_test.  Export it so the
# test process (PDO helpers, reset_test_data) and the API child process both
# read the same database.
export DB_NAME="${DB_NAME:-attendance_payroll_test}"

# Fail-fast: if DB_NAME is unset or points at the production default, abort
# immediately instead of sending HTTP requests against the wrong database.
export TARGET_DB="${DB_NAME}"
if [ -z "$TARGET_DB" ]; then
  echo "ERROR: DB_NAME is not set; refusing to run against the default production database." >&2
  echo "Set DB_NAME=attendance_payroll_test (or an isolated test database) and retry." >&2
  exit 1
fi

lower_target=$(printf '%s' "$TARGET_DB" | tr '[:upper:]' '[:lower:]')
case "$lower_target" in
  attendance_payroll)
    echo "ERROR: DB_NAME is '$TARGET_DB' (the default production database)." >&2
    echo "Point DB_NAME at a test database (e.g. attendance_payroll_test) and retry." >&2
    exit 1
    ;;
  *)
    ;;
esac

BASE="${1:-http://127.0.0.1:8099/api}"
PHP="/c/xampp/php/php.exe"

PASS=0
FAIL=0

pass() { echo "  PASS  $1"; PASS=$((PASS + 1)); }
fail() { echo "  FAIL  $1"; echo "        ${2:-}"; FAIL=$((FAIL + 1)); }

# ---------------------------------------------------------------------------
# Run-scoped fixture cleanup.
#
# Every pass provisions a fresh employee and a linked login account
# (username test.user.<epoch>). reset_test_data.php clears the payroll periods
# the suite created but cannot tell a test employee from a genuine one, so the
# suite disposes of its own fixture here. The Add-Employee response is captured
# into FIXTURE_* below; the EXIT trap hands those exact ids to
# tests/cleanup_api_fixture.php, which deletes those ids and nothing else after
# proving the account really belongs to the employee. No row is ever matched by
# a 'test.user.%' name pattern.
# ---------------------------------------------------------------------------
FIXTURE_EMP_ID=""
FIXTURE_USER_ID=""
FIXTURE_USER_NAME=""

fixture_cleanup() {
  # Capture the suite's own exit status first so cleanup can never change it.
  local status=$?

  if [ -n "$FIXTURE_EMP_ID" ]; then
    echo
    echo "[cleanup] Removing run-scoped fixture (employee $FIXTURE_EMP_ID)..."
    # A cleanup failure is reported loudly but deliberately does not become the
    # suite's exit code: the trap re-exits with the original status regardless.
    "$PHP" tests/cleanup_api_fixture.php \
      "$FIXTURE_EMP_ID" "$FIXTURE_USER_ID" "$FIXTURE_USER_NAME"
    local cleanup_status=$?
    if [ "$cleanup_status" -ne 0 ]; then
      echo "  [cleanup] WARNING: fixture cleanup exited $cleanup_status" >&2
    fi
  fi

  exit "$status"
}

# Cleanup runs on success and failure alike, but always preserves the exit code.
trap fixture_cleanup EXIT

# assert_contains <label> <haystack> <needle>
assert_contains() {
  if echo "$2" | grep -q "$3"; then
    pass "$1"
  else
    fail "$1" "expected '$3' in: $(echo "$2" | head -c 180)"
  fi
}

json() {
  $PHP -r '
    $d = json_decode(stream_get_contents(STDIN), true);
    $v = $d;
    foreach (explode(".", $argv[1]) as $p) { $v = $v[$p] ?? null; }
    echo is_bool($v) ? ($v ? "true" : "false") : (string) $v;
  ' "$1"
}

assert_status() {
  local label="$1" method="$2" path="$3" expected="$4" body="$5" token="$6"
  local args=(-s -o /dev/null -w '%{http_code}' -X "$method" "$BASE$path" -H 'Content-Type: application/json')

  [ -n "$token" ] && args+=(-H "Authorization: Bearer $token")
  [ -n "$body" ] && args+=(-d "$body")

  local code
  code=$(curl "${args[@]}")

  if [ "$code" = "$expected" ]; then pass "$label"; else fail "$label" "expected HTTP $expected, got $code"; fi
}

echo "=============================================="
echo " ATTENDANCE & PAYROLL - END-TO-END TEST SUITE"
echo "=============================================="
echo "Base URL: $BASE"
echo

# Refuse to write to a production or genuine-use database. This suite creates
# payroll periods and employees and clears them again, so it has to run against
# a dedicated test database (DB_NAME=attendance_payroll_test).
if ! "$PHP" tests/db_guard.php; then
  echo "Aborting: the configured database is not a safe test target (see above)." >&2
  exit 1
fi
echo

# Clear the payroll periods this suite created on a previous pass so the
# non-overlap rule can be exercised again. Safe: only rows named after the
# suite are touched and their children cascade.
$PHP tests/reset_test_data.php 'Automated test period'
echo

echo "[Phase 1] Health & bootstrap"
HEALTH=$(curl -s "$BASE/health")
assert_contains "API responds" "$HEALTH" '"success":true'
assert_contains "Service identifies itself" "$HEALTH" 'attendance-payroll-api'

echo
echo "[Phase 3] Authentication & authorization"
assert_status "Invalid credentials rejected" POST /auth/login 401 '{"username":"nosuchuser","password":"wrong"}'
assert_status "Protected route needs a token" GET /employees 401
assert_status "Invalid token rejected" GET /employees 401 '' 'not-a-real-token'

LOGIN=$(curl -s -X POST "$BASE/auth/login" -H 'Content-Type: application/json' \
  -d '{"username":"admin","password":"Password123@"}')
assert_contains "Super admin signs in" "$LOGIN" '"success":true'

TOKEN=$(echo "$LOGIN" | json data.token)

if [ -z "$TOKEN" ]; then
  echo "  ABORT: no token issued."
  exit 1
fi

pass "Bearer token issued"

ME=$(curl -s "$BASE/auth/me" -H "Authorization: Bearer $TOKEN")
assert_contains "Session resolves the user" "$ME" 'admin'
assert_contains "Super admin has wildcard permissions" "$ME" '"\*"'

EMP_LOGIN=$(curl -s -X POST "$BASE/auth/login" -H 'Content-Type: application/json' \
  -d '{"username":"staff","password":"Password123@"}')
EMP_TOKEN=$(echo "$EMP_LOGIN" | json data.token)

if [ -n "$EMP_TOKEN" ]; then
  assert_status "Employee cannot list employees" GET /employees 403 '' "$EMP_TOKEN"
  assert_status "Employee cannot read payroll periods" GET /payroll/periods 403 '' "$EMP_TOKEN"
else
  fail "Employee login" "$EMP_LOGIN"
fi

assert_status "Password change needs the current password" POST /auth/change-password 422 \
  '{"current_password":"wrong","new_password":"NewPass@123","confirm_password":"NewPass@123"}' "$TOKEN"

echo
echo "[Phase 4] Employees"
SUFFIX=$(date +%s)

# Creating an employee also provisions the linked login account, so the payload
# must carry the account credentials the API requires on create (see
# EmployeeService::rules(): account_username / account_password /
# account_password_confirm). Username and email are unique per pass via SUFFIX;
# the contact number uses the required PH mobile format (09XXXXXXXXX).
CREATE=$(curl -s -X POST "$BASE/employees" -H "Authorization: Bearer $TOKEN" -H 'Content-Type: application/json' \
  -d "{\"first_name\":\"Test\",\"last_name\":\"User$SUFFIX\",\"gender\":\"FEMALE\",\"date_hired\":\"2026-01-05\",\"employment_type\":\"FULL_TIME\",\"salary_type\":\"MONTHLY\",\"basic_salary\":25000,\"department_id\":1,\"position_id\":1,\"work_schedule_id\":1,\"contact_number\":\"09171234567\",\"email\":\"test.$SUFFIX@company.com\",\"account_username\":\"test.user.$SUFFIX\",\"account_password\":\"TestPass@123\",\"account_password_confirm\":\"TestPass@123\"}")

assert_contains "Employee created" "$CREATE" '"success":true'

EMP_ID=$(echo "$CREATE" | json data.employee.id)
QR_TOKEN=$(echo "$CREATE" | json data.qr.token)

# Remember exactly what this pass created so the EXIT trap can remove it again.
# data.employee.account_id is the linked login account and data.account.username
# is the unique test.user.<epoch> name; both are echoed back by EmployeeService.
FIXTURE_EMP_ID="$EMP_ID"
FIXTURE_USER_ID=$(echo "$CREATE" | json data.employee.account_id)
FIXTURE_USER_NAME=$(echo "$CREATE" | json data.account.username)

if [ -n "$EMP_ID" ] && [ -n "$QR_TOKEN" ]; then
  pass "Employee ID assigned and QR auto-issued"
else
  fail "Employee creation response incomplete" "$CREATE"
fi

# The duplicate probe has to be otherwise valid, including a *distinct* account
# username: an invalid payload would now be rejected by the credential rules
# before EmployeeService::assertEmailAvailable() reports the duplicate email.
assert_contains "Duplicate email rejected" \
  "$(curl -s -X POST "$BASE/employees" -H "Authorization: Bearer $TOKEN" -H 'Content-Type: application/json' \
     -d "{\"first_name\":\"Dup\",\"gender\":\"MALE\",\"date_hired\":\"2026-01-05\",\"employment_type\":\"FULL_TIME\",\"salary_type\":\"MONTHLY\",\"basic_salary\":1000,\"email\":\"test.$SUFFIX@company.com\",\"account_username\":\"dup.user.$SUFFIX\",\"account_password\":\"TestPass@123\",\"account_password_confirm\":\"TestPass@123\"}")" \
  'already in use'

assert_contains "Negative salary rejected" \
  "$(curl -s -X POST "$BASE/employees" -H "Authorization: Bearer $TOKEN" -H 'Content-Type: application/json' \
     -d '{"first_name":"Bad","gender":"MALE","date_hired":"2026-01-05","employment_type":"FULL_TIME","salary_type":"MONTHLY","basic_salary":-5}')" \
  '"success":false'

assert_contains "Search finds the employee" \
  "$(curl -s "$BASE/employees?q=Test%20User$SUFFIX" -H "Authorization: Bearer $TOKEN")" \
  "Test User$SUFFIX"
echo
echo "[Phase 5] QR codes"
QR=$(curl -s "$BASE/qr/active/$EMP_ID" -H "Authorization: Bearer $TOKEN")
assert_contains "Active QR metadata returned" "$QR" '"status":"ACTIVE"'
assert_contains "QR exposes only a hint, never the token" "$QR" 'token_hint'

SVG=$(curl -s "$BASE/qr/svg/$EMP_ID" -H "Authorization: Bearer $TOKEN")
assert_contains "QR renders as SVG" "$SVG" '<svg'
assert_contains "SVG contains the module matrix" "$SVG" '<path'

REGEN=$(curl -s -X POST "$BASE/qr/issue/$EMP_ID" -H "Authorization: Bearer $TOKEN" -H 'Content-Type: application/json' -d '{"replace":true}')
NEW_QR_TOKEN=$(echo "$REGEN" | json data.token)
assert_contains "QR regenerated" "$REGEN" '"success":true'

if [ -n "$NEW_QR_TOKEN" ]; then
  assert_contains "Replaced QR is rejected" \
    "$(curl -s -X POST "$BASE/attendance/scan" -H 'Content-Type: application/json' -d "{\"token\":\"$QR_TOKEN\"}")" \
    'replaced'
fi

echo
echo "[Phase 6/7] QR attendance and the calculation engine"
# Pin the scan clock so this flow does not depend on the wall-clock time the
# suite runs: the fixture employee is on the seeded DAY shift (08:00 start,
# 30-minute late cut-off), so a real-time scan after 08:30 would be denied.
# `scanned_at` is honoured only when the API test server runs with
# PMS_TEST_CLOCK=1 (ignored otherwise — see AttendanceController::testClock).
# Every attendance rule still evaluates against these pinned timestamps.
SCAN_DAY=$($PHP -r 'echo date("Y-m-d");')
scan_at() {
  curl -s -X POST "$BASE/attendance/scan" -H 'Content-Type: application/json' \
    -d "{\"token\":\"$NEW_QR_TOKEN\",\"scanned_at\":\"$SCAN_DAY $1\"}"
}

SCAN=$(scan_at '08:05:00')
assert_contains "Time-in recorded" "$SCAN" '"event_type":"TIME_IN"'
assert_contains "Status incomplete until time-out" "$SCAN" 'INCOMPLETE'

# A second scan of the same code on the same day advances to time-out.
assert_contains "Second scan becomes time-out" \
  "$(scan_at '17:05:00')" \
  '"event_type":"TIME_OUT"'

# A third scan finds the day already complete and is refused.
assert_contains "Third scan refused once the day is complete" \
  "$(scan_at '17:06:00')" \
  'already complete'

assert_contains "Unknown QR rejected" \
  "$(curl -s -X POST "$BASE/attendance/scan" -H 'Content-Type: application/json' -d '{"token":"ATT-FAKE-FAKE-FAKE"}')" \
  'Invalid QR code'

assert_contains "Missing token rejected" \
  "$(curl -s -X POST "$BASE/attendance/scan" -H 'Content-Type: application/json' -d '{}')" \
  'required'

echo
echo "[Phase 10] Leave management"
LEAVE=$(curl -s -X POST "$BASE/leave" -H "Authorization: Bearer $TOKEN" -H 'Content-Type: application/json' \
  -d "{\"employee_id\":$EMP_ID,\"leave_type_id\":1,\"start_date\":\"2026-11-02\",\"end_date\":\"2026-11-03\",\"reason\":\"Automated test leave\"}")

assert_contains "Leave request submitted" "$LEAVE" '"success":true'

LEAVE_ID=$(echo "$LEAVE" | json data.id)

if [ -n "$LEAVE_ID" ]; then
  assert_contains "Leave approved" \
    "$(curl -s -X POST "$BASE/leave/$LEAVE_ID/approve" -H "Authorization: Bearer $TOKEN" -H 'Content-Type: application/json' -d '{"remarks":"ok"}')" \
    'APPROVED'

  assert_contains "Leave balance updated" \
    "$(curl -s "$BASE/employees/$EMP_ID/leave-balances" -H "Authorization: Bearer $TOKEN")" \
    'used_days'

  assert_contains "Cannot approve a second time" \
    "$(curl -s -X POST "$BASE/leave/$LEAVE_ID/approve" -H "Authorization: Bearer $TOKEN" -H 'Content-Type: application/json' -d '{}')" \
    '"success":false'
fi

assert_contains "Overlapping leave rejected" \
  "$(curl -s -X POST "$BASE/leave" -H "Authorization: Bearer $TOKEN" -H 'Content-Type: application/json' \
     -d "{\"employee_id\":$EMP_ID,\"leave_type_id\":1,\"start_date\":\"2026-11-03\",\"end_date\":\"2026-11-04\",\"reason\":\"Overlap\"}")" \
  'overlaps'

assert_contains "End before start rejected" \
  "$(curl -s -X POST "$BASE/leave" -H "Authorization: Bearer $TOKEN" -H 'Content-Type: application/json' \
     -d "{\"employee_id\":$EMP_ID,\"leave_type_id\":1,\"start_date\":\"2026-12-10\",\"end_date\":\"2026-12-01\",\"reason\":\"Bad range\"}")" \
  '"success":false'

echo
echo "[Phase 11] Overtime assignments (Admin announces, assignee responds)"
OT=$(curl -s -X POST "$BASE/overtime" -H "Authorization: Bearer $TOKEN" -H 'Content-Type: application/json' \
  -d "{\"employee_id\":$EMP_ID,\"overtime_date\":\"2026-11-05\",\"start_time\":\"18:00\",\"end_time\":\"21:00\",\"reason\":\"Automated test OT\"}")

assert_contains "Overtime assigned" "$OT" '"success":true'

OT_ID=$(echo "$OT" | json data.id)

if [ -n "$OT_ID" ]; then
  assert_contains "Overtime approved" \
    "$(curl -s -X POST "$BASE/overtime/$OT_ID/approve" -H "Authorization: Bearer $TOKEN" -H 'Content-Type: application/json' -d '{}')" \
    'APPROVED'

  assert_contains "Tomorrow assignments" \
    "$(curl -s "$BASE/overtime/tomorrow" -H "Authorization: Bearer $TOKEN")" \
    '"success":true'
fi

assert_contains "End before start rejected" \
  "$(curl -s -X POST "$BASE/overtime" -H "Authorization: Bearer $TOKEN" -H 'Content-Type: application/json' \
     -d "{\"employee_id\":$EMP_ID,\"overtime_date\":\"2026-11-06\",\"start_time\":\"20:00\",\"end_time\":\"19:00\",\"reason\":\"Bad\"}")" \
  '"success":false'
echo
echo "[Phase 12/13/14] Payroll configuration, engine and workflow"
PERIOD=$(curl -s -X POST "$BASE/payroll/periods" -H "Authorization: Bearer $TOKEN" -H 'Content-Type: application/json' \
  -d '{"start_date":"2026-11-01","end_date":"2026-11-15","pay_date":"2026-11-20","name":"Automated test period"}')

assert_contains "Payroll period created" "$PERIOD" '"success":true'

PERIOD_ID=$(echo "$PERIOD" | json data.id)

assert_contains "Overlapping period rejected" \
  "$(curl -s -X POST "$BASE/payroll/periods" -H "Authorization: Bearer $TOKEN" -H 'Content-Type: application/json' \
     -d '{"start_date":"2026-11-10","end_date":"2026-11-25","pay_date":"2026-11-30"}')" \
  'overlaps'

if [ -n "$PERIOD_ID" ]; then
  CALC=$(curl -s -X POST "$BASE/payroll/periods/$PERIOD_ID/calculate" -H "Authorization: Bearer $TOKEN" -H 'Content-Type: application/json' -d '{}')

  assert_contains "Payroll calculated" "$CALC" '"employees_processed"'
  assert_contains "Period moved to review" "$CALC" 'FOR_REVIEW'

  assert_contains "Workflow cannot skip a step" \
    "$(curl -s -X POST "$BASE/payroll/periods/$PERIOD_ID/transition" -H "Authorization: Bearer $TOKEN" -H 'Content-Type: application/json' -d '{"status":"FINALIZED"}')" \
    'cannot move to'

  assert_contains "Period approved" \
    "$(curl -s -X POST "$BASE/payroll/periods/$PERIOD_ID/transition" -H "Authorization: Bearer $TOKEN" -H 'Content-Type: application/json' -d '{"status":"APPROVED"}')" \
    'APPROVED'

  assert_contains "Period finalized" \
    "$(curl -s -X POST "$BASE/payroll/periods/$PERIOD_ID/transition" -H "Authorization: Bearer $TOKEN" -H 'Content-Type: application/json' -d '{"status":"FINALIZED"}')" \
    'FINALIZED'

  assert_contains "Finalized payroll is locked" \
    "$(curl -s -X POST "$BASE/payroll/periods/$PERIOD_ID/calculate" -H "Authorization: Bearer $TOKEN" -H 'Content-Type: application/json' -d '{}')" \
    'cannot move to'

  ROWS=$(curl -s "$BASE/payroll/periods/$PERIOD_ID/payroll" -H "Authorization: Bearer $TOKEN")
  PAYROLL_ID=$(echo "$ROWS" | json data.0.id)

  assert_contains "Payroll rows carry the lock flag" "$ROWS" '"is_locked":1'

  if [ -n "$PAYROLL_ID" ]; then
    PS=$(curl -s "$BASE/payroll/payslips/$PAYROLL_ID" -H "Authorization: Bearer $TOKEN")
    assert_contains "Payslip renders" "$PS" '"payslip"'
    assert_contains "Payslip includes net pay" "$PS" 'net_pay'
    assert_contains "Payslip includes the earnings breakdown" "$PS" 'earnings'
  fi
fi

echo
echo "[Phase 16] Dashboard"
DASH=$(curl -s "$BASE/dashboard" -H "Authorization: Bearer $TOKEN")
assert_contains "Dashboard cards" "$DASH" '"cards"'
assert_contains "Dashboard charts" "$DASH" 'attendance_trend'
assert_contains "Dashboard recent activity" "$DASH" 'recent_activities'

echo
echo "[Phase 17] Reports"
assert_contains "Daily attendance report" \
  "$(curl -s "$BASE/reports/attendance/daily?date_from=2026-11-01&date_to=2026-11-30" -H "Authorization: Bearer $TOKEN")" \
  '"success":true'

assert_contains "Late report" \
  "$(curl -s "$BASE/reports/attendance/late?date_from=2026-11-01&date_to=2026-11-30" -H "Authorization: Bearer $TOKEN")" \
  '"success":true'

assert_contains "Payroll summary report" \
  "$(curl -s "$BASE/reports/payroll/summary" -H "Authorization: Bearer $TOKEN")" \
  '"success":true'

assert_contains "CSV export streams headers" \
  "$(curl -s "$BASE/reports/attendance/daily?format=csv&date_from=2026-11-01&date_to=2026-11-30" -H "Authorization: Bearer $TOKEN")" \
  'employee_number'
echo
echo "[Phase 18] Audit trail"
assert_contains "Session recorded" \
  "$(curl -s "$BASE/audit?per_page=50" -H "Authorization: Bearer $TOKEN")" \
  'LOGIN'

assert_contains "Employee creation recorded" \
  "$(curl -s "$BASE/audit?action=EMPLOYEE_CREATED" -H "Authorization: Bearer $TOKEN")" \
  'EMPLOYEE_CREATED'

echo
echo "[Phase 19] Configurable settings"
assert_contains "Settings readable" \
  "$(curl -s "$BASE/settings" -H "Authorization: Bearer $TOKEN")" \
  'payroll.overtime_multiplier'

curl -s -X PUT "$BASE/settings" -H "Authorization: Bearer $TOKEN" -H 'Content-Type: application/json' \
  -d '{"payroll.overtime_multiplier":"1.50"}' > /dev/null

AFTER=$(curl -s "$BASE/payroll/settings" -H "Authorization: Bearer $TOKEN" | json data.overtime_multiplier)

if [ "$AFTER" = "1.5" ] || [ "$AFTER" = "1.50" ]; then
  pass "Business rules configurable without code changes (OT multiplier -> $AFTER)"
else
  fail "Business rules configurable" "expected 1.50, got $AFTER"
fi

curl -s -X PUT "$BASE/settings" -H "Authorization: Bearer $TOKEN" -H 'Content-Type: application/json' \
  -d '{"payroll.overtime_multiplier":"1.25"}' > /dev/null

echo
echo "[Phase 8/9] Schedules and holidays"
assert_contains "Schedules listed" "$(curl -s "$BASE/schedules" -H "Authorization: Bearer $TOKEN")" 'STD-MF'
assert_contains "Shifts listed"    "$(curl -s "$BASE/schedules/shifts" -H "Authorization: Bearer $TOKEN")" 'DAY'
assert_contains "Holidays listed"  "$(curl -s "$BASE/holidays" -H "Authorization: Bearer $TOKEN")" 'Christmas'

echo
echo "[Phase 20] Security hardening"
assert_status "SQL injection attempt handled safely" POST /auth/login 401 \
  '{"username":"admin'"'"' OR 1=1 --","password":"x"}'

assert_contains "Invalid input returns field errors" \
  "$(curl -s -X POST "$BASE/employees" -H "Authorization: Bearer $TOKEN" -H 'Content-Type: application/json' \
     -d '{"first_name":"","gender":"NOPE","date_hired":"not-a-date","employment_type":"X","salary_type":"Y","basic_salary":"abc"}')" \
  '"errors"'

assert_status "Unknown endpoint returns 404" GET /nope 404 '' "$TOKEN"

assert_contains "Errors do not leak internals" \
  "$(curl -s "$BASE/nope" -H "Authorization: Bearer $TOKEN")" \
  'does not exist'

echo
echo "[Phase 4] Archive and restore"
assert_contains "Employee archived" \
  "$(curl -s -X POST "$BASE/employees/$EMP_ID/archive" -H "Authorization: Bearer $TOKEN" -H 'Content-Type: application/json' -d '{}')" \
  'INACTIVE'

assert_contains "Archived employee's QR is refused" \
  "$(curl -s -X POST "$BASE/attendance/scan" -H 'Content-Type: application/json' -d "{\"token\":\"$NEW_QR_TOKEN\"}")" \
  '"success":false'

assert_contains "Employee restored" \
  "$(curl -s -X POST "$BASE/employees/$EMP_ID/restore" -H "Authorization: Bearer $TOKEN" -H 'Content-Type: application/json' -d '{}')" \
  'ACTIVE'

echo
echo "[Phase 20b] Rate limiting"
# The scan endpoint allows 60 requests per minute. Deliberately exceed it.
# This runs last because the client is then blocked for 300 seconds.
RATE_HIT=""
for _ in $(seq 1 70); do
  RATE_HIT=$(curl -s -o /dev/null -w '%{http_code}' -X POST "$BASE/attendance/scan" \
    -H 'Content-Type: application/json' -d '{"token":"ATT-FAKE-FAKE-FAKE"}')
  [ "$RATE_HIT" = "429" ] && break
done

if [ "$RATE_HIT" = "429" ]; then
  pass "Flooding the scan endpoint is throttled (HTTP 429)"
else
  fail "Flooding the scan endpoint is throttled" "last status was $RATE_HIT"
fi

echo
echo "=============================================="
echo " RESULT: $PASS passed, $FAIL failed"
echo "=============================================="

[ "$FAIL" -eq 0 ] || exit 1
