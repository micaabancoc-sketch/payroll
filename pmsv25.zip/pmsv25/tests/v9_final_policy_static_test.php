<?php
declare(strict_types=1);
require dirname(__DIR__) . '/api/services/CompanyLoanPolicy.php';
require dirname(__DIR__) . '/api/services/FixedMonthlyPolicy.php';
use App\Services\CompanyLoanPolicy;
use App\Services\FixedMonthlyPolicy;
$root = dirname(__DIR__);
$checks = [
 'employee fixed semi-monthly create'=>str_contains(file_get_contents($root.'/api/services/EmployeeService.php'), 'SEMI_MONTHLY'),
 'employee duplicate name validation'=>str_contains(file_get_contents($root.'/api/services/EmployeeService.php'), 'assertNameNotUsed'),
 'editable employee salary'=>str_contains(file_get_contents($root.'/frontend/employees/index.html'), 'name="basic_salary" id="fm-basic_salary"'),
 'position salary field in position modal'=>str_contains(substr(file_get_contents($root.'/frontend/settings/index.html'), strpos(file_get_contents($root.'/frontend/settings/index.html'), 'async function openPositionForm')), 'gf-pos-salary'),
 'role restrictions on loan approval'=>str_contains(file_get_contents($root.'/api/services/LoanService.php'), "Auth::roleCode() !== 'HR_PAYROLL'"),
 'loan release restricted to admin'=>str_contains(file_get_contents($root.'/api/services/LoanService.php'), "Auth::roleCode() !== 'ADMIN'"),
 'leave attachment upload enabled'=>str_contains(file_get_contents($root.'/api/routes.php'), '/api/leave/attachment'),
 'no automated QR expiration'=>str_contains(file_get_contents($root.'/database/migrations/20261023_v9_roles_position_salary.sql'), "'qr.token_expiry_days','0'"),
 'attendance absence reconciler scheduled'=>file_exists($root.'/api/cli/attendance_absence_reconciler.php'),
 'defense seed exists'=>file_exists($root.'/database/SEED_EXISTING_TEST_DB_MAX_DEFENSE.sql'),
];
foreach($checks as $label=>$ok){if(!$ok){fwrite(STDERR,"FAIL: $label\n"); exit(1);}echo "PASS: $label\n";}
$loan=CompanyLoanPolicy::terms('SALARY_LOAN',10000.0,6);
if (abs($loan['per_cutoff']-875.0)>0.01) { throw new RuntimeException('Wrong loan installment'); }
echo "PASS: 10,000 company loan / 6 months / 5% = 875 per cutoff\n";
$advance=CompanyLoanPolicy::terms('CASH_ADVANCE',10000.0,2);
if (abs($advance['per_cutoff']-2500)>0.01) { throw new RuntimeException('Wrong advance installment'); }
echo "PASS: 10,000 salary advance / 2 months = 2,500 per cutoff\n";
$fixed=FixedMonthlyPolicy::cutoffBasic(20000.0,'2026-09-01','2026-09-15');
if (abs($fixed-10000.0)>0.01){fwrite(STDERR,"FAIL: fixed cutoff basic $fixed\n");exit(1);}
echo "PASS: monthly 20,000 -> cutoff 10,000\n";
