<?php
declare(strict_types=1);
require dirname(__DIR__) . '/api/autoload.php';
use App\Services\PayrollPeriodPolicy;

function assertTest(bool $predicate, string $message): void {
    if (!$predicate) { fwrite(STDERR, 'FAIL: ' . $message . PHP_EOL); exit(1); }
}
assertTest(PayrollPeriodPolicy::validateNewPeriod('2026-03-01','2026-03-15','2026-11-30','2026-11-02') !== [], 'March must be blocked when November exists');
assertTest(PayrollPeriodPolicy::validateNewPeriod('2026-10-16','2026-10-31',null,'2026-11-02') !== [], 'Ended cutoff before current date blocked');
assertTest(PayrollPeriodPolicy::validateNewPeriod('2026-11-01','2026-11-15','2026-11-15','2026-11-02') !== [], 'Existing cutoff overlap blocked');
assertTest(PayrollPeriodPolicy::validateNewPeriod('2026-11-16','2026-11-30','2026-11-15','2026-11-02') === [], 'Next cutoff in same month accepted');
assertTest(PayrollPeriodPolicy::validateNewPeriod('2026-12-01','2026-12-15','2026-11-30','2026-11-02') === [], 'Later month accepted');
assertTest(PayrollPeriodPolicy::validateNewPeriod('2027-01-01','2027-01-15','2026-12-31','2026-11-02') === [], 'Next year accepted');
assertTest(PayrollPeriodPolicy::validateNewPeriod('2026-12-16','2026-12-31','2026-12-31','2026-11-02') !== [], 'Duplicate cutoff blocked');
echo "PASS: 7 V21 payroll period policy cases" . PHP_EOL;
