<?php
/**
 * Individual payroll payments & disbursement ledger test (Phase 5).
 *
 * Proves, with independent manual arithmetic, that:
 *
 *   1. the migration is applied: the payroll_payments ledger, the cached
 *      payroll.amount_paid / payment_status columns, and the idempotency
 *      unique key all exist;
 *   2. only FINALIZED periods are payable: DRAFT / APPROVED rows refuse a
 *      payment;
 *   3. record() accumulates COMPLETED payments against net_pay and derives the
 *      remaining balance and UNPAID / PARTIAL / PAID status correctly, using
 *      the worked 15,000 -> 5,000 -> 10,000 example;
 *   4. overpayment is rejected precisely, a zero amount is rejected, and a
 *      COMPLETED row cannot be written on a bare method selection (an explicit
 *      confirmation is required);
 *   5. PENDING holds no money until complete() confirms it, complete() requires
 *      an explicit confirmation, and a failed attempt is kept for history but
 *      never reduces the balance;
 *   6. cancel() reverses a COMPLETED or PENDING row, restores the balance, is
 *      excluded from paid totals, preserves history, and requires a reason;
 *   7. a fully PAID row refuses further successful payments;
 *   8. idempotency_key replays the original row instead of writing a second
 *      one, and the same key against a different payroll row is rejected;
 *   9. the period FINALIZED -> PAID gate: periodReadiness() reports ready only
 *      when no row is UNPAID or PARTIAL, and the transition is refused while a
 *      row is partially paid;
 *  10. every ledger change writes an audit row.
 *
 * Everything is created inside ONE outer transaction and rolled back when the
 * script ends, so no fixture ever survives - the genuine attendance_payroll
 * database is never touched (tests/db_guard.php refuses it).
 *
 * Usage:
 *   DB_NAME=attendance_payroll_test php tests/payroll_payments_test.php
 *
 * Exit code 0 = every check passed, 1 = at least one check failed.
 */

declare(strict_types=1);

use App\Core\AuditLogger;
use App\Core\Database;
use App\Core\ValidationException;
use App\Services\PayrollEngine;
use App\Services\PayrollPaymentService;
use App\Services\PayrollService;

require dirname(__DIR__) . '/api/autoload.php';

function check(string $label, bool $ok, string $detail = ''): void
{
    global $passed, $failed, $failures;

    if ($ok) {
        $passed++;
        echo "  PASS  $label\n";
        return;
    }

    $failed++;
    $failures[] = $label;
    echo "  FAIL  $label\n";
    if ($detail !== '') {
        echo "        $detail\n";
    }
}

function checkMoney(string $label, float $expected, float $actual): void
{
    check(
        $label,
        abs($expected - $actual) < 0.005,
        sprintf('expected %s, got %s', number_format($expected, 2), number_format($actual, 2))
    );
}

function checkSame(string $label, mixed $expected, mixed $actual): void
{
    check($label, $expected === $actual, sprintf('expected %s, got %s', var_export($expected, true), var_export($actual, true)));
}

function heading(string $title): void
{
    echo "\n", $title, "\n", str_repeat('-', strlen($title)), "\n";
}

// ---------------------------------------------------------------------------
// Fixture helpers
// ---------------------------------------------------------------------------

$sequence = 0;

function nextCode(string $prefix): string
{
    global $sequence;
    $sequence++;

    return sprintf('%s%02d_%s', $prefix, $sequence, strtoupper(bin2hex(random_bytes(3))));
}

function makeEmployee(float $salary): int
{
    return Database::insert('employees', [
        'employee_number' => nextCode('PAY-'),
        'first_name'      => 'Payment',
        'last_name'       => 'Mgmt',
        'gender'          => 'OTHER',
        'date_hired'      => '2024-01-01',
        'employment_type' => 'FULL_TIME',
        'salary_type'     => 'MONTHLY',
        'basic_salary'    => $salary,
        'status'          => 'ACTIVE',
    ]);
}

function employeeRow(int $employeeId): array
{
    $row = Database::selectOne('SELECT * FROM employees WHERE id = :id', ['id' => $employeeId]);

    if ($row === null) {
        throw new RuntimeException('Fixture employee ' . $employeeId . ' disappeared.');
    }

    return $row;
}

/** Mark the employee present on the given dates so net_pay is the full salary. */
function addPresentDays(int $employeeId, array $dates): void
{
    foreach ($dates as $date) {
        Database::insert('attendance', [
            'employee_id'     => $employeeId,
            'attendance_date' => $date,
            'status'          => 'PRESENT',
            'source'          => 'MANUAL',
        ]);
    }
}

/** @return list<string> consecutive dates starting at $from */
function consecutiveDates(string $from, int $count): array
{
    $cursor = new DateTimeImmutable($from);
    $dates  = [];

    for ($i = 0; $i < $count; $i++) {
        $dates[] = $cursor->format('Y-m-d');
        $cursor  = $cursor->modify('+1 day');
    }

    return $dates;
}

/** Cached net_pay for one payroll row. */
function netPay(int $payrollId): float
{
    return round((float) (Database::scalar('SELECT net_pay FROM payroll WHERE id = :id', ['id' => $payrollId]) ?? 0), 2);
}

/** Cached amount_paid / payment_status for one payroll row. */
function rowAggregate(int $payrollId): array
{
    $row = Database::selectOne(
        'SELECT amount_paid, payment_status FROM payroll WHERE id = :id',
        ['id' => $payrollId]
    );

    return [
        'amount_paid'    => round((float) ($row['amount_paid'] ?? -1), 2),
        'payment_status' => (string) ($row['payment_status'] ?? ''),
    ];
}

/** The payroll row id for one employee in one period. */
function payrollRowId(int $periodId, int $employeeId): int
{
    return (int) (Database::scalar(
        'SELECT id FROM payroll WHERE payroll_period_id = :pid AND employee_id = :e',
        ['pid' => $periodId, 'e' => $employeeId]
    ) ?? 0);
}

/** Count of COMPLETED ledger rows for one payroll row. */
function completedCount(int $payrollId): int
{
    return (int) (Database::scalar(
        "SELECT COUNT(*) FROM payroll_payments WHERE payroll_id = :id AND payment_status = 'COMPLETED'",
        ['id' => $payrollId]
    ) ?? 0);
}

/** Count of every ledger row for one payroll row (history is never deleted). */
function ledgerCount(int $payrollId): int
{
    return (int) (Database::scalar(
        'SELECT COUNT(*) FROM payroll_payments WHERE payroll_id = :id',
        ['id' => $payrollId]
    ) ?? 0);
}

/** Period status string. */
function periodStatus(int $periodId): string
{
    return (string) (Database::scalar('SELECT status FROM payroll_periods WHERE id = :id', ['id' => $periodId]) ?? '');
}

/**
 * Create, calculate and finalize a one-employee period, returning both ids.
 * The employee must already be present on every day of [start, end] so the
 * net pay equals the full basic salary.
 *
 * @return array{period: int, payroll: int}
 */
function finalizedPeriod(PayrollService $payroll, int $employeeId, string $start, string $end, string $name, int $userId): array
{
    $period = $payroll->createPeriod([
        'start_date' => $start,
        'end_date'   => $end,
        'pay_date'   => $end,
        'name'       => $name,
    ], $userId);
    $periodId = (int) $period['id'];

    $payroll->calculate($periodId, $userId);
    $payroll->transition($periodId, 'APPROVED', $userId);
    $payroll->transition($periodId, 'FINALIZED', $userId);

    return ['period' => $periodId, 'payroll' => payrollRowId($periodId, $employeeId)];
}

/** Audit rows recorded for one payment id (entity_id is stored as VARCHAR). */
function auditCount(string $action, int $paymentId): int
{
    return (int) (Database::scalar(
        "SELECT COUNT(*) FROM audit_logs
           WHERE action = :a AND entity_type = 'payroll_payment' AND entity_id = :e",
        ['a' => $action, 'e' => (string) $paymentId]
    ) ?? 0);
}

$config = require dirname(__DIR__) . '/api/config/config.php';
date_default_timezone_set((string) $config['app']['timezone']);

// Refuse to write anything when the configured database looks like production.
require __DIR__ . '/db_guard.php';
pmsAssertSafeTestDatabase();

const PER_START = '2025-12-01';
const PER_END   = '2025-12-15';

// Later, non-overlapping periods for the pending / fail / cancel / gate flows.
const PER_B_START = '2025-10-01';
const PER_B_END   = '2025-10-15';
const PER_C_START = '2025-09-01';
const PER_C_END   = '2025-09-15';
const PER_D_START = '2025-08-01';
const PER_D_END   = '2025-08-15';

$passed   = 0;
$failed   = 0;
$failures = [];

// ---------------------------------------------------------------------------
// Scenario
// ---------------------------------------------------------------------------

Database::beginTransaction();

try {
    $userId = (int) (Database::scalar(
        "SELECT id FROM users WHERE username = 'admin' AND deleted_at IS NULL LIMIT 1"
    ) ?? 0);

    if ($userId === 0) {
        throw new RuntimeException('admin account not found - seed the database first.');
    }

    $engine   = new PayrollEngine();
    $payroll  = new PayrollService($engine);
    $payments = new PayrollPaymentService();

    // -----------------------------------------------------------------------
    heading('1. Preflight: the Phase 5 migration is applied');
    // -----------------------------------------------------------------------
    $ledgerTable = (int) (Database::scalar(
        "SELECT COUNT(*) FROM information_schema.tables
          WHERE table_schema = DATABASE() AND table_name = 'payroll_payments'"
    ) ?? 0);
    check('the payroll_payments ledger exists', $ledgerTable === 1,
        'run: php database/migrate_payroll_payments.php');

    $ledgerCols = (int) (Database::scalar(
        "SELECT COUNT(*) FROM information_schema.columns
          WHERE table_schema = DATABASE() AND table_name = 'payroll_payments'
            AND column_name IN ('reference_no','idempotency_key','amount','payment_method',
                                'method_reference','payment_status','payment_date','paid_at',
                                'recorded_by','cancelled_by','cancel_reason','notes')"
    ) ?? 0);
    check('the ledger carries every disbursement column', $ledgerCols === 12,
        'run: php database/migrate_payroll_payments.php');

    $payrollCols = (int) (Database::scalar(
        "SELECT COUNT(*) FROM information_schema.columns
          WHERE table_schema = DATABASE() AND table_name = 'payroll'
            AND column_name IN ('amount_paid','payment_status')"
    ) ?? 0);
    check('payroll caches amount_paid and payment_status', $payrollCols === 2,
        'run: php database/migrate_payroll_payments.php');

    $idemKey = (int) (Database::scalar(
        "SELECT COUNT(DISTINCT index_name) FROM information_schema.statistics
          WHERE table_schema = DATABASE() AND table_name = 'payroll_payments'
            AND index_name = 'uq_payrollpay_idem'"
    ) ?? 0);
    check('the idempotency unique key exists', $idemKey === 1,
        'run: php database/migrate_payroll_payments.php');

    if ($ledgerTable !== 1 || $payrollCols !== 2) {
        // Without the schema every later assertion would throw. Fail fast with a
        // clear hint instead of a wall of spurious errors.
        throw new RuntimeException('Phase 5 schema missing - run: php database/migrate_payroll_payments.php');
    }

    $options = $payments->options();
    check('the page exposes the four payment methods', count($options['payment_methods'] ?? []) === 4);
    check('the methods are cash, bank transfer, GCash and other',
        array_keys($options['payment_methods'] ?? []) === ['CASH', 'BANK_TRANSFER', 'GCASH', 'OTHER']);
    check('the ledger statuses are pending/completed/failed/cancelled',
        array_keys($options['payment_statuses'] ?? []) === ['PENDING', 'COMPLETED', 'FAILED', 'CANCELLED']);

    // -----------------------------------------------------------------------
    heading('2. A finalized period with a 15,000 net pay is the payable source');
    // -----------------------------------------------------------------------
    $empA = makeEmployee(15000.00);
    addPresentDays($empA, consecutiveDates(PER_START, 15));

    $periodA = $payroll->createPeriod([
        'start_date' => PER_START,
        'end_date'   => PER_END,
        'pay_date'   => PER_END,
        'name'       => 'Automated payments test 2025-12 first half',
    ], $userId);
    $periodAId = (int) $periodA['id'];

    $payroll->calculate($periodAId, $userId);
    $payrollA = payrollRowId($periodAId, $empA);

    // The engine prorates a MONTHLY salary across the present days of the
    // period and then applies statutory deductions, so the net pay is whatever
    // the engine derives - not a round 15,000. Every partial-payment figure
    // below is driven from this real net pay, which is exactly how the worked
    // example behaves in practice: pay part, the balance is the remainder, pay
    // the remainder, and the row settles to fully PAID.
    $netA = netPay($payrollA);
    check('the payroll row has a positive net pay to disburse', $netA > 0,
        sprintf('net pay computed as %s', number_format($netA, 2)));
    $halfA = round($netA / 2, 2);
    $restA = round($netA - $halfA, 2);

    $beforeFinalize = rowAggregate($payrollA);
    checkSame('a fresh payroll row starts UNPAID', 'UNPAID', $beforeFinalize['payment_status']);
    checkMoney('a fresh payroll row has paid nothing', 0.00, $beforeFinalize['amount_paid']);

    // -----------------------------------------------------------------------
    heading('3. Only FINALIZED periods are payable');
    // -----------------------------------------------------------------------
    $draftRejected = false;
    try {
        $payments->record($payrollA, ['amount' => 100.00, 'confirmed' => true], $userId);
    } catch (RuntimeException $e) {
        $draftRejected = stripos($e->getMessage(), 'finalized') !== false;
    }
    check('a calculated (FOR_REVIEW) period refuses a payment until FINALIZED', $draftRejected);
    checkSame('the refused payment leaves the FOR_REVIEW period status untouched', 'FOR_REVIEW', periodStatus($periodAId));

    $payroll->transition($periodAId, 'APPROVED', $userId);
    $approvedRejected = false;
    try {
        $payments->record($payrollA, ['amount' => 100.00, 'confirmed' => true], $userId);
    } catch (RuntimeException $e) {
        $approvedRejected = stripos($e->getMessage(), 'finalized') !== false;
    }
    check('an APPROVED (not yet FINALIZED) period still refuses a payment', $approvedRejected);

    $payroll->transition($periodAId, 'FINALIZED', $userId);
    checkSame('the period is now FINALIZED', 'FINALIZED', periodStatus($periodAId));

    // -----------------------------------------------------------------------
    heading('4. Partial payments accumulate against net pay');
    // -----------------------------------------------------------------------
    $p1 = $payments->record($payrollA, [
        'amount'          => $halfA,
        'payment_method'  => 'BANK_TRANSFER',
        'method_reference' => 'REF-123',
        'confirmed'       => true,
        'idempotency_key' => 'phase5-example-1',
    ], $userId);

    checkSame('the first payment is COMPLETED', 'COMPLETED', (string) $p1['payment']['payment_status']);
    check('the first payment is not a replay', empty($p1['replayed']));
    $ref1 = (string) $p1['payment']['reference_no'];
    check('the payment carries a PAY- reference', str_starts_with($ref1, 'PAY-'));
    $p1Id = (int) $p1['payment']['id'];

    $agg1 = rowAggregate($payrollA);
    checkMoney(sprintf('after paying %s, amount_paid matches it', number_format($halfA, 2)), $halfA, $agg1['amount_paid']);
    checkSame('after the first payment, status is PARTIAL', 'PARTIAL', $agg1['payment_status']);
    checkMoney(sprintf('the row reports %s still outstanding', number_format($restA, 2)), $restA, (float) $p1['payroll']['balance_due']);

    $overpay = false;
    try {
        $payments->record($payrollA, [
            'amount'         => round($restA + 0.01, 2),
            'payment_method' => 'CASH',
            'confirmed'      => true,
        ], $userId);
    } catch (ValidationException $e) {
        $overpay = array_key_exists('amount', $e->errors());
    }
    check('a payment over the outstanding balance is rejected', $overpay);
    $aggAfterOverpay = rowAggregate($payrollA);
    checkMoney('the rejected overpayment moved nothing', $halfA, $aggAfterOverpay['amount_paid']);
    checkSame('the row is still PARTIAL after the rejected overpayment', 'PARTIAL', $aggAfterOverpay['payment_status']);

    $zeroRejected = false;
    try {
        $payments->record($payrollA, ['amount' => 0, 'confirmed' => true], $userId);
    } catch (ValidationException $e) {
        $zeroRejected = array_key_exists('amount', $e->errors());
    }
    check('a zero payment amount is rejected', $zeroRejected);

    $unconfirmed = false;
    try {
        $payments->record($payrollA, [
            'amount'         => round($restA / 2, 2),
            'payment_method' => 'GCASH',
            'confirmed'      => false,
        ], $userId);
    } catch (ValidationException $e) {
        $unconfirmed = array_key_exists('confirmed', $e->errors());
    }
    check('a COMPLETED payment requires an explicit confirmation', $unconfirmed);
    checkSame('no COMPLETED row was written without confirmation', 1, completedCount($payrollA));

    // -----------------------------------------------------------------------
    heading('5. The second payment settles the row to fully PAID');
    // -----------------------------------------------------------------------
    $p2 = $payments->record($payrollA, [
        'amount'         => $restA,
        'payment_method' => 'CASH',
        'confirmed'      => true,
        'idempotency_key' => 'phase5-example-2',
    ], $userId);

    $agg2 = rowAggregate($payrollA);
    checkMoney(sprintf('after the second payment, amount_paid is %s', number_format($netA, 2)), $netA, $agg2['amount_paid']);
    checkSame('the row is now fully PAID', 'PAID', $agg2['payment_status']);
    checkMoney('the remaining balance is 0.00', 0.00, (float) $p2['payroll']['balance_due']);
    checkSame('exactly two COMPLETED payments settled the row', 2, completedCount($payrollA));

    $overFull = false;
    try {
        $payments->record($payrollA, ['amount' => 0.01, 'confirmed' => true], $userId);
    } catch (RuntimeException $e) {
        $overFull = stripos($e->getMessage(), 'fully paid') !== false;
    }
    check('a fully paid row refuses another payment', $overFull);

    // -----------------------------------------------------------------------
    heading('6. A PENDING payment holds no money until it is completed');
    // -----------------------------------------------------------------------
    // A fresh finalized period (employee B) drives the pending / fail / cancel
    // flows, because row A is already settled above.
    $empB = makeEmployee(15000.00);
    addPresentDays($empB, consecutiveDates(PER_B_START, 15));
    $finalB    = finalizedPeriod($payroll, $empB, PER_B_START, PER_B_END, 'Automated payments test 2025-10 first half', $userId);
    $periodBId = $finalB['period'];
    $payrollB  = $finalB['payroll'];
    $netB      = netPay($payrollB);
    $pendB     = round($netB * 0.4, 2);

    $pend = $payments->record($payrollB, [
        'amount'          => $pendB,
        'payment_method'  => 'BANK_TRANSFER',
        'method_reference' => 'TRF-7788',
        'payment_status'  => 'PENDING',
        'idempotency_key' => 'phase5-pending-1',
        'confirmed'       => true,
    ], $userId);

    checkSame('a PENDING intent is stored as PENDING', 'PENDING', (string) $pend['payment']['payment_status']);
    $pendId = (int) $pend['payment']['id'];
    $aggPend = rowAggregate($payrollB);
    checkMoney('a PENDING payment adds nothing to amount_paid', 0.00, $aggPend['amount_paid']);
    checkSame('a PENDING payment leaves the row UNPAID', 'UNPAID', $aggPend['payment_status']);
    checkMoney('a PENDING payment leaves the full balance outstanding', $netB, (float) $pend['payroll']['balance_due']);

    // A PENDING payment cannot be confirmed simply by completing it: the caller
    // must explicitly confirm the money actually moved.
    $completeUnconfirmed = false;
    try {
        $payments->complete($pendId, ['confirmed' => false], $userId);
    } catch (ValidationException $e) {
        $completeUnconfirmed = array_key_exists('confirmed', $e->errors());
    }
    check('completing a PENDING payment requires an explicit confirmation', $completeUnconfirmed);
    checkSame('the unconfirmed complete did not move the row', 'UNPAID', rowAggregate($payrollB)['payment_status']);

    // Completing it counts the money and marks the timestamp.
    $done = $payments->complete($pendId, ['confirmed' => true], $userId);
    checkSame('completing flips the payment to COMPLETED', 'COMPLETED', (string) $done['payment']['payment_status']);
    check('completing stamps a paid_at timestamp', !empty($done['payment']['paid_at']));
    $aggDone = rowAggregate($payrollB);
    checkMoney('completing now counts the amount as paid', $pendB, $aggDone['amount_paid']);
    checkSame('completing moves the row to PARTIAL', 'PARTIAL', $aggDone['payment_status']);

    // A failed attempt (from a second PENDING) never reduces the balance.
    $pend2 = $payments->record($payrollB, [
        'amount'         => round($netB * 0.3, 2),
        'payment_method' => 'GCASH',
        'payment_status' => 'PENDING',
        'confirmed'      => true,
    ], $userId);
    $pend2Id = (int) $pend2['payment']['id'];

    $failNoReason = false;
    try {
        $payments->markFailed($pend2Id, [], $userId);
    } catch (ValidationException $e) {
        $failNoReason = array_key_exists('reason', $e->errors());
    }
    check('a failed attempt requires a reason', $failNoReason);

    $failedRes = $payments->markFailed($pend2Id, ['reason' => 'Bank rejected the transfer.'], $userId);
    checkSame('the attempt is marked FAILED', 'FAILED', (string) $failedRes['payment']['payment_status']);
    $aggFail = rowAggregate($payrollB);
    checkMoney('a failed attempt leaves amount_paid unchanged', $pendB, $aggFail['amount_paid']);
    checkSame('a failed attempt keeps the row PARTIAL', 'PARTIAL', $aggFail['payment_status']);
    checkSame('the failed row is preserved in the ledger history', 2, ledgerCount($payrollB));

    // -----------------------------------------------------------------------
    heading('7. Cancelling a COMPLETED payment restores the balance, keeps history');
    // -----------------------------------------------------------------------
    $comp = $payments->record($payrollB, [
        'amount'          => round($netB * 0.3, 2),
        'payment_method'  => 'CASH',
        'payment_status'  => 'COMPLETED',
        'confirmed'       => true,
        'idempotency_key' => 'phase5-to-cancel',
    ], $userId);
    $compId   = (int) $comp['payment']['id'];
    $compAmt  = round((float) $comp['payment']['amount'], 2);
    $aggComp  = rowAggregate($payrollB);
    checkMoney('a second completed payment accumulates on top of the first', round($pendB + $compAmt, 2), $aggComp['amount_paid']);

    $cancelNoReason = false;
    try {
        $payments->cancel($compId, [], $userId);
    } catch (ValidationException $e) {
        $cancelNoReason = array_key_exists('reason', $e->errors());
    }
    check('cancelling a payment requires a reason', $cancelNoReason);

    $cancelled = $payments->cancel($compId, ['reason' => 'Wrong account used.'], $userId);
    checkSame('the payment is now CANCELLED', 'CANCELLED', (string) $cancelled['payment']['payment_status']);
    $aggCancel = rowAggregate($payrollB);
    checkMoney('a cancelled payment is excluded from amount_paid', $pendB, $aggCancel['amount_paid']);
    checkSame('the row falls back to PARTIAL after the cancel', 'PARTIAL', $aggCancel['payment_status']);
    checkSame('the cancelled row is still in the ledger (history preserved)', 3, ledgerCount($payrollB));

    $recancelled = false;
    try {
        $payments->cancel($compId, ['reason' => 'again'], $userId);
    } catch (RuntimeException $e) {
        $recancelled = stripos($e->getMessage(), 'cancelled') !== false;
    }
    check('a cancelled payment cannot be cancelled again', $recancelled);

    // -----------------------------------------------------------------------
    heading('8. Idempotency: a retried key replays the original, never doubles it');
    // -----------------------------------------------------------------------
    // Settle employee B fully with a keyed payment, then replay that exact key.
    $balanceB = round($netB - $pendB, 2);
    $settleB  = $payments->record($payrollB, [
        'amount'          => $balanceB,
        'payment_method'  => 'CASH',
        'payment_status'  => 'COMPLETED',
        'confirmed'       => true,
        'idempotency_key' => 'phase5-settle-B',
    ], $userId);
    checkSame('employee B is fully PAID after settling the remainder', 'PAID', rowAggregate($payrollB)['payment_status']);
    $settleId = (int) $settleB['payment']['id'];

    $replay = $payments->record($payrollB, [
        'amount'          => $balanceB,
        'payment_method'  => 'GCASH',
        'payment_status'  => 'COMPLETED',
        'confirmed'       => true,
        'idempotency_key' => 'phase5-settle-B',
    ], $userId);

    check('a retried idempotency key is flagged as a replay', !empty($replay['replayed']));
    checkSame('the replay returns the original payment id', $settleId, (int) $replay['payment']['id']);
    checkMoney('the replay does not increase amount_paid beyond net pay', $netB, rowAggregate($payrollB)['amount_paid']);
    checkSame('the replay wrote no extra ledger row', 4, ledgerCount($payrollB));

    // A key cannot be reused against a different payroll record.
    $crossKey = false;
    try {
        $payments->record($payrollA, [
            'amount'          => 1.00,
            'payment_status'  => 'COMPLETED',
            'confirmed'       => true,
            'idempotency_key' => 'phase5-settle-B',
        ], $userId);
    } catch (ValidationException $e) {
        $crossKey = array_key_exists('idempotency_key', $e->errors());
    }
    check('an idempotency key cannot be reused on a different record', $crossKey);

    // -----------------------------------------------------------------------
    heading('9. The FINALIZED -> PAID gate: no period is paid while a row is short');
    // -----------------------------------------------------------------------
    // A third employee/period that we leave unpaid on purpose.
    $empC = makeEmployee(15000.00);
    addPresentDays($empC, consecutiveDates(PER_C_START, 15));
    $finalC    = finalizedPeriod($payroll, $empC, PER_C_START, PER_C_END, 'Automated payments test 2025-09 first half', $userId);
    $periodCId = $finalC['period'];
    $payrollC  = $finalC['payroll'];
    $netC      = netPay($payrollC);

    $paidTooSoon = false;
    try {
        $payroll->transition($periodCId, 'PAID', $userId);
    } catch (RuntimeException $e) {
        $paidTooSoon = stripos($e->getMessage(), 'unpaid') !== false;
    }
    check('a period with an unpaid row cannot be marked PAID', $paidTooSoon);
    checkSame('the blocked period is still FINALIZED', 'FINALIZED', periodStatus($periodCId));

    // A partial payment still blocks the transition (it says "partially paid").
    $halfC = round($netC / 2, 2);
    $payments->record($payrollC, [
        'amount'         => $halfC,
        'payment_method' => 'CASH',
        'payment_status' => 'COMPLETED',
        'confirmed'      => true,
    ], $userId);
    checkSame('the row is PARTIAL after a half payment', 'PARTIAL', rowAggregate($payrollC)['payment_status']);
    $partialBlocks = false;
    try {
        $payroll->transition($periodCId, 'PAID', $userId);
    } catch (RuntimeException $e) {
        $partialBlocks = stripos($e->getMessage(), 'unpaid') !== false && stripos($e->getMessage(), 'partially paid') !== false;
    }
    check('a partially paid period also refuses PAID', $partialBlocks);

    // Settle the remainder; now the period transitions and commits cleanly.
    $payments->record($payrollC, [
        'amount'         => round($netC - $halfC, 2),
        'payment_method' => 'BANK_TRANSFER',
        'payment_status' => 'COMPLETED',
        'confirmed'      => true,
    ], $userId);
    checkSame('the row is fully PAID once the remainder is disbursed', 'PAID', rowAggregate($payrollC)['payment_status']);

    // Any other seeded employee whose payroll row is still UNPAID/PARTIAL must
    // also be settled: the FINALIZED→PAID gate requires every row in the
    // period to be paid, not just the one under test.
    $stillUnpaid = Database::select(
        "SELECT id, net_pay FROM payroll
           WHERE payroll_period_id = :pid
             AND payment_status IN ('UNPAID', 'PARTIAL')",
        ['pid' => $periodCId]
    );
    foreach ($stillUnpaid as $u) {
        $payments->record((int) $u['id'], [
            'amount'         => (float) $u['net_pay'],
            'payment_method' => 'BANK_TRANSFER',
            'payment_status' => 'COMPLETED',
            'confirmed'      => true,
        ], $userId);
    }

    $paidResult = $payroll->transition($periodCId, 'PAID', $userId);
    checkSame('the fully disbursed period transitions to PAID', 'PAID', periodStatus($periodCId));
    check('the PAID response reports the loan repayments', array_key_exists('loan_repayments', $paidResult));



    // -----------------------------------------------------------------------
    heading('10. Every disbursement action is audit-logged');
    // -----------------------------------------------------------------------
    checkSame('recording a payment logs PAYROLL_PAYMENT_RECORDED', 1,
        auditCount(AuditLogger::PAYROLL_PAYMENT_RECORDED, $p1Id));
    checkSame('completing a pending payment is logged as COMPLETED', 1,
        auditCount(AuditLogger::PAYROLL_PAYMENT_COMPLETED, $pendId));
    checkSame('a failed attempt logs PAYROLL_PAYMENT_FAILED', 1,
        auditCount(AuditLogger::PAYROLL_PAYMENT_FAILED, $pend2Id));
    checkSame('a cancellation logs PAYROLL_PAYMENT_CANCELLED', 1,
        auditCount(AuditLogger::PAYROLL_PAYMENT_CANCELLED, $compId));

    // -----------------------------------------------------------------------
    heading('11. Loan repayments stay separate from salary disbursement');
    // -----------------------------------------------------------------------
    // The salary ledger never writes to the loan ledger for these employees.
    $loanLedger = (int) (Database::scalar(
        "SELECT COUNT(*) FROM loan_payments lp
           JOIN loans l ON l.id = lp.loan_id
          WHERE l.employee_id IN (:a, :b, :c)",
        ['a' => $empA, 'b' => $empB, 'c' => $empC]
    ) ?? 0);
    checkSame('salary disbursement writes no loan repayment rows', 0, $loanLedger);

    $salaryLedger = (int) (Database::scalar(
        'SELECT COUNT(*) FROM payroll_payments WHERE employee_id IN (:a, :b, :c)',
        ['a' => $empA, 'b' => $empB, 'c' => $empC]
    ) ?? 0);
    check('the salary ledger holds the full disbursement history for all three employees',
        $salaryLedger >= 6, sprintf('ledger rows: %d', $salaryLedger));
} catch (Throwable $e) {
    check('no unexpected exception', false, get_class($e) . ': ' . $e->getMessage() . ' @ ' . $e->getFile() . ':' . $e->getLine());
} finally {
    // Every fixture created above (employees, attendance, periods, payroll
    // rows, payroll items and the disbursement ledger) is rolled back here:
    // nothing is ever committed.
    Database::rollBack();
}

echo "\n", $passed, ' passed, ', $failed, " failed\n";

if ($failures !== []) {
    echo "\nFailures:\n";
    foreach ($failures as $failure) {
        echo '  - ', $failure, "\n";
    }
    echo "\nPAYROLL PAYMENTS: FAILED\n";
    exit(1);
}

echo "\nPAYROLL PAYMENTS: every check passed\n";
exit(0);

