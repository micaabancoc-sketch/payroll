<?php
/**
 * Payroll calculation accuracy test (Phase 1 audit).
 *
 * Proves, with independent manual arithmetic, that:
 *
 *   1. normal basic pay is present-days x daily rate and carries no holiday
 *      earning when the period has no holiday;
 *   2. holiday pay is counted EXACTLY ONCE in gross pay - both when a paid
 *      holiday has an attendance row and when nobody recorded the day (the
 *      calendar sweep), and never inside basic_pay;
 *   3. basic salary stays separate from holiday pay, overtime, night
 *      differential and allowances, and the earning items always add up to
 *      gross pay;
 *   4. overtime is paid per request type (REGULAR 1.25, HOLIDAY 2.00) and night
 *      differential covers only the 22:00-06:00 window, each on its own item;
 *   5. deduction totals are the sum of the itemised deductions, net pay is
 *      gross - deductions, and an absent or unpaid-leave day is charged ONCE
 *      (it earns no basic pay, so it is not deducted again);
 *   6. a calendar year of basic salary totalling 360,000.00 produces 30,000.00
 *      of 13th-month pay;
 *   7. part-year employment contributes its actual earnings only;
 *   8. a salary change during the year is reflected in the historical totals;
 *   9. a finalized payroll period crossing 31 Dec / 1 Jan blocks 13th-month
 *      generation instead of guessing;
 *  10. DRAFT (recalculable) payroll is excluded from the 13th-month total;
 *  11. recalculating a draft period does not duplicate payroll rows or items;
 *  12. finalized/paid payroll rows and released/paid 13th-month records are
 *      never changed by a later calculation.
 *
 * Everything is created inside ONE outer transaction and rolled back when the
 * script ends, so no fixture ever survives - the genuine attendance_payroll
 * database is never touched (tests/db_guard.php refuses it).
 *
 * The 13th-month half of this suite drives the REAL PayrollEngine over real
 * attendance and saves the engine's own figures, then asks
 * ThirteenthPayService to read them back; the module's own ledger/workflow
 * rules are covered in depth by tests/thirteenth_pay_test.php.
 *
 * Usage:
 *   DB_NAME=attendance_payroll_test php tests/payroll_calculation_test.php
 *
 * Exit code 0 = every check passed, 1 = at least one check failed.
 */

declare(strict_types=1);

use App\Core\Database;
use App\Core\Settings;
use App\Core\ValidationException;
use App\Services\PayrollEngine;
use App\Services\PayrollPaymentService;
use App\Services\PayrollService;
use App\Services\ThirteenthPayService;

require dirname(__DIR__) . '/api/autoload.php';

$config = require dirname(__DIR__) . '/api/config/config.php';
date_default_timezone_set((string) $config['app']['timezone']);

// Refuse to write anything when the configured database looks like production.
require __DIR__ . '/db_guard.php';
pmsAssertSafeTestDatabase();

// Monthly salary of 22,000.00 over 22 working days of 8 hours gives exactly
// 1,000.00 a day and 125.00 an hour, so every expectation below is hand
// arithmetic rather than a re-run of the engine's own formula.
const MONTHLY_SALARY = 22000.00;
const DAILY_RATE     = 1000.00;
const HOURLY_RATE    = 125.00;
const WORK_DAYS      = 22.0;
const WORK_HOURS     = 8.0;

// Periods used by the engine scenarios. October 2025 and September 2025 carry
// no seeded holiday (the seeded calendar has none in either month), so a
// "no holiday earning" expectation cannot be tripped by live data.
const PERIOD_START = '2025-10-01';
const PERIOD_END   = '2025-10-31';

$passed   = 0;
$failed   = 0;
$failures = [];

function check(string $label, bool $ok, string $detail = ''): void
{
    global $passed, $failed, $failures;

    if ($ok) {
        $passed++;
        echo "  PASS  $label\n";
        return;
    }

    $failed++;
    $failures[] = $label;
    echo "  FAIL  $label\n";
    if ($detail !== '') {
        echo "        $detail\n";
    }
}

function checkMoney(string $label, float $expected, float $actual): void
{
    check(
        $label,
        abs($expected - $actual) < 0.005,
        sprintf('expected %s, got %s', number_format($expected, 2), number_format($actual, 2))
    );
}

function checkSame(string $label, mixed $expected, mixed $actual): void
{
    check($label, $expected === $actual, sprintf('expected %s, got %s', var_export($expected, true), var_export($actual, true)));
}

function heading(string $title): void
{
    echo "\n", $title, "\n", str_repeat('-', strlen($title)), "\n";
}

// ---------------------------------------------------------------------------
// Fixture helpers
// ---------------------------------------------------------------------------

$sequence = 0;

function nextCode(string $prefix): string
{
    global $sequence;
    $sequence++;

    return sprintf('%s%02d_%s', $prefix, $sequence, strtoupper(bin2hex(random_bytes(3))));
}

function makeEmployee(float $salary, array $over = []): int
{
    return Database::insert('employees', array_merge([
        'employee_number' => nextCode('PAYT-'),
        'first_name'      => 'Payroll',
        'last_name'       => 'Calc',
        'gender'          => 'OTHER',
        'date_hired'      => '2024-01-01',
        'employment_type' => 'FULL_TIME',
        'salary_type'     => 'MONTHLY',
        'basic_salary'    => $salary,
        'status'          => 'ACTIVE',
    ], $over));
}

/**
 * The employee holds no work schedule, so AttendanceEngine::markAbsences()
 * treats every day as a rest day and never invents an ABSENT row: the only
 * attendance in the period is what the test itself writes.
 */
function addAttendance(int $employeeId, string $date, string $status = 'PRESENT', array $over = []): void
{
    Database::insert('attendance', array_merge([
        'employee_id'     => $employeeId,
        'attendance_date' => $date,
        'status'          => $status,
        'source'          => 'MANUAL',
    ], $over));
}

/** @return list<string> the dates written */
function addPresentDays(int $employeeId, array $dates): array
{
    foreach ($dates as $date) {
        addAttendance($employeeId, $date, 'PRESENT');
    }

    return $dates;
}

/** @return list<string> consecutive dates starting at $from */
function consecutiveDates(string $from, int $count): array
{
    $cursor = new DateTimeImmutable($from);
    $dates  = [];

    for ($i = 0; $i < $count; $i++) {
        $dates[] = $cursor->format('Y-m-d');
        $cursor  = $cursor->modify('+1 day');
    }

    return $dates;
}

/**
 * Phase 5: the FINALIZED -> PAID gate refuses while any payable payroll row
 * is outstanding, so a test that wants to mark a period paid must disburse
 * the salary first. Settle every payable row through the production
 * PayrollPaymentService - the same path the Payments page uses - never by
 * touching the cached payment columns directly. Rows with a non-positive
 * net pay need no disbursement (the gate reads them as settled) and
 * already-settled rows are skipped.
 *
 * @return int how many payroll rows this settled
 */
function disbursePeriodFully(PayrollPaymentService $payments, int $periodId, int $userId): int
{
    $rows = Database::select(
        'SELECT id, net_pay, amount_paid, payment_status
           FROM payroll
          WHERE payroll_period_id = :pid
          ORDER BY id',
        ['pid' => $periodId]
    );

    $settled = 0;
    foreach ($rows as $row) {
        if ((string) ($row['payment_status'] ?? '') === 'PAID') {
            continue;
        }
        $net = round((float) ($row['net_pay'] ?? 0), 2);
        if ($net <= 0) {
            continue;
        }
        $due = round($net - (float) ($row['amount_paid'] ?? 0), 2);
        if ($due <= 0) {
            continue;
        }
        $payments->record((int) $row['id'], [
            'amount'         => $due,
            'payment_method' => 'CASH',
            'payment_status' => 'COMPLETED',
            'confirmed'      => true,
            'notes'          => 'Automated test: full salary disbursement before PAID.',
        ], $userId);
        $settled++;
    }

    return $settled;
}

function makeHoliday(string $date, int $isPaid = 1, string $type = 'REGULAR'): int
{
    return Database::insert('holidays', [
        'name'         => 'Payroll calc test holiday ' . nextCode(''),
        'holiday_date' => $date,
        'holiday_type' => $type,
        'is_paid'      => $isPaid,
        'is_recurring' => 0,
        'status'       => 'ACTIVE',
    ]);
}

function makePeriod(string $start, string $end, string $status, int $userId): int
{
    return Database::insert('payroll_periods', [
        'code'       => nextCode('PAYT-PP-'),
        'name'       => 'Payroll calc test ' . $start,
        'start_date' => $start,
        'end_date'   => $end,
        'pay_date'   => $end,
        'status'     => $status,
        'created_by' => $userId,
    ]);
}

/** @return array<string, mixed> */
function employeeRow(int $employeeId): array
{
    $row = Database::selectOne('SELECT * FROM employees WHERE id = :id', ['id' => $employeeId]);

    if ($row === null) {
        throw new RuntimeException('Fixture employee ' . $employeeId . ' disappeared.');
    }

    return $row;
}

/** Run the real engine for one employee over a period. @return array<string, mixed> */
function calculate(PayrollEngine $engine, int $employeeId, string $from, string $to): array
{
    return $engine->calculateEmployee(employeeRow($employeeId), $from, $to);
}

/** Amount of one earning/deduction line, 0.0 when the line is absent. */
function itemAmount(array $lines, string $code): float
{
    foreach ($lines as $line) {
        if (strtoupper((string) $line['code']) === strtoupper($code)) {
            return (float) $line['amount'];
        }
    }

    return 0.0;
}

/** How many lines carry a code (proves "counted exactly once", not twice). */
function itemCount(array $lines, string $code): int
{
    $count = 0;
    foreach ($lines as $line) {
        if (strtoupper((string) $line['code']) === strtoupper($code)) {
            $count++;
        }
    }

    return $count;
}

function itemTotal(array $lines): float
{
    $total = 0.0;
    foreach ($lines as $line) {
        $total += (float) $line['amount'];
    }

    return round($total, 2);
}

function earningCodes(array $calc): array
{
    return array_map(static fn (array $line): string => strtoupper((string) $line['code']), (array) $calc['earnings']);
}

/**
 * Save one engine-produced payroll row and its itemised breakdown for a period,
 * mirroring PayrollService::insertPayrollRow(). The 13th-month scenarios use it
 * so their totals come from the real engine and real attendance instead of
 * hand-written amounts, without recalculating every other employee over a whole
 * year.
 *
 * @return array<string, mixed> the engine calculation that was saved
 */
function saveEnginePayroll(PayrollEngine $engine, int $periodId, int $employeeId, string $from, string $to): array
{
    $calc = calculate($engine, $employeeId, $from, $to);

    $payrollId = Database::insert('payroll', [
        'payroll_period_id'    => $periodId,
        'employee_id'          => $employeeId,
        'basic_pay'            => $calc['basic_pay'],
        'gross_pay'            => $calc['gross_pay'],
        'net_pay'              => $calc['net_pay'],
        'total_deductions'     => $calc['total_deductions'],
        'absent_days'          => $calc['absent_days'],
        'leave_days'           => $calc['leave_days'],
        'is_locked'            => 1,
        'calculation_snapshot' => (string) json_encode($calc['snapshot'], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
        'calculated_at'        => date('Y-m-d H:i:s'),
    ]);

    foreach (['earnings' => 'EARNING', 'deductions' => 'DEDUCTION'] as $key => $type) {
        foreach ((array) $calc[$key] as $line) {
            Database::insert('payroll_items', [
                'payroll_id' => $payrollId,
                'item_type'  => $type,
                'code'       => $line['code'],
                'name'       => $line['name'],
                'amount'     => $line['amount'],
                'remarks'    => $line['remarks'] ?? null,
            ]);
        }
    }

    return $calc;
}

/** The saved payroll row of one employee in one period (recalculation replaces rows). */
function savedRow(int $periodId, int $employeeId): ?array
{
    return Database::selectOne(
        'SELECT * FROM payroll WHERE payroll_period_id = :p AND employee_id = :e',
        ['p' => $periodId, 'e' => $employeeId]
    );
}

function savedRowCount(int $periodId): int
{
    return (int) (Database::scalar('SELECT COUNT(*) FROM payroll WHERE payroll_period_id = :p', ['p' => $periodId]) ?? 0);
}

function savedItemCount(int $periodId, int $employeeId): int
{
    return (int) (Database::scalar(
        'SELECT COUNT(*) FROM payroll_items pi
           JOIN payroll p ON p.id = pi.payroll_id
          WHERE p.payroll_period_id = :p AND p.employee_id = :e',
        ['p' => $periodId, 'e' => $employeeId]
    ) ?? 0);
}

// ---------------------------------------------------------------------------
// Scenario
// ---------------------------------------------------------------------------

Database::beginTransaction();

try {
    $userId = (int) (Database::scalar(
        "SELECT id FROM users WHERE username = 'admin' AND deleted_at IS NULL LIMIT 1"
    ) ?? 0);

    if ($userId === 0) {
        throw new RuntimeException('admin account not found - seed the database first.');
    }

    $engine         = new PayrollEngine();
    $payrollService = new PayrollService($engine);
    $thirteenth     = new ThirteenthPayService();
    $payments       = new PayrollPaymentService();

    heading('0. Environment (the arithmetic below depends on these settings)');
    checkMoney('working_days_per_month is 22', WORK_DAYS, (float) Settings::float('payroll.working_days_per_month', 0.0));
    checkMoney('working_hours_per_day is 8', WORK_HOURS, (float) Settings::float('payroll.working_hours_per_day', 0.0));
    checkMoney('overtime_multiplier is 1.25', 1.25, (float) Settings::float('payroll.overtime_multiplier', 0.0));
    checkMoney('overtime_holiday_multiplier is 2.00', 2.00, (float) Settings::float('payroll.overtime_holiday_multiplier', 0.0));
    checkMoney('night_differential_multiplier is 1.10', 1.10, (float) Settings::float('payroll.night_differential_multiplier', 0.0));
    checkMoney('holiday_rate_multiplier is 1.00', 1.00, (float) Settings::float('payroll.holiday_rate_multiplier', 0.0));

    // -----------------------------------------------------------------------
    heading('1. Normal basic pay without holiday earnings');
    // -----------------------------------------------------------------------
    $empNormal = makeEmployee(MONTHLY_SALARY);
    addPresentDays($empNormal, consecutiveDates('2025-10-01', 22));
    $calcNormal = calculate($engine, $empNormal, PERIOD_START, PERIOD_END);

    checkMoney('daily rate is 22,000.00 / 22', DAILY_RATE, (float) $calcNormal['daily_rate']);
    checkMoney('hourly rate is 1,000.00 / 8', HOURLY_RATE, (float) $calcNormal['hourly_rate']);
    checkMoney('22 present days pay 22 x 1,000.00', 22 * DAILY_RATE, (float) $calcNormal['basic_pay']);
    checkMoney('no holiday earning in a holiday-free period', 0.00, (float) $calcNormal['holiday_pay']);
    checkMoney('no overtime earned', 0.00, (float) $calcNormal['overtime_pay']);
    checkMoney('no night differential earned', 0.00, (float) $calcNormal['night_pay']);
    checkMoney('gross pay equals basic pay', (float) $calcNormal['basic_pay'], (float) $calcNormal['gross_pay']);
    checkMoney('present_days counts the 22 rows', 22.0, (float) $calcNormal['present_days']);
    checkSame('only one earning line (BASIC)', ['BASIC'], earningCodes($calcNormal));
    checkMoney('the earning lines add up to gross pay', (float) $calcNormal['gross_pay'], itemTotal((array) $calcNormal['earnings']));
    check(
        'the snapshot records that holiday pay is NOT inside basic_pay',
        ($calcNormal['snapshot']['accounting']['holiday_pay_included_in_basic'] ?? null) === false
    );

    // -----------------------------------------------------------------------
    heading('2. Holiday pay is counted exactly once');
    // -----------------------------------------------------------------------
    makeHoliday('2025-10-20', 1);

    // 2a: paid holiday nobody recorded - the calendar, not attendance, pays it.
    $empHoliday = makeEmployee(MONTHLY_SALARY);
    addPresentDays($empHoliday, array_merge(consecutiveDates('2025-10-01', 19), ['2025-10-21', '2025-10-22']));
    $calcHoliday = calculate($engine, $empHoliday, PERIOD_START, PERIOD_END);

    checkMoney('21 present days pay 21,000.00', 21 * DAILY_RATE, (float) $calcHoliday['basic_pay']);
    checkMoney('the paid holiday pays one more daily rate', DAILY_RATE, (float) $calcHoliday['holiday_pay']);
    checkMoney('gross pay is 22,000.00 - the holiday is not doubled', 22 * DAILY_RATE, (float) $calcHoliday['gross_pay']);
    checkMoney('the holiday is NOT inside basic pay', 0.00, (float) $calcHoliday['basic_pay'] - 21 * DAILY_RATE);
    checkSame('exactly one HOLIDAY earning line', 1, itemCount((array) $calcHoliday['earnings'], 'HOLIDAY'));
    checkMoney('the HOLIDAY line carries one daily rate', DAILY_RATE, itemAmount((array) $calcHoliday['earnings'], 'HOLIDAY'));
    checkMoney('the earning lines add up to gross pay', (float) $calcHoliday['gross_pay'], itemTotal((array) $calcHoliday['earnings']));

    // 2b: the same holiday with an explicit HOLIDAY attendance row (manual
    // attendance / a scan on the day) must not pay it a second time.
    $empHolidayRow = makeEmployee(MONTHLY_SALARY);
    addPresentDays($empHolidayRow, array_merge(consecutiveDates('2025-10-01', 19), ['2025-10-21', '2025-10-22']));
    addAttendance($empHolidayRow, '2025-10-20', 'HOLIDAY', ['is_holiday' => 1]);
    $calcHolidayRow = calculate($engine, $empHolidayRow, PERIOD_START, PERIOD_END);

    checkMoney('the recorded holiday still pays exactly one daily rate', DAILY_RATE, (float) $calcHolidayRow['holiday_pay']);
    checkMoney('gross pay is unchanged by the recorded row', 22 * DAILY_RATE, (float) $calcHolidayRow['gross_pay']);
    checkSame('still exactly one HOLIDAY earning line', 1, itemCount((array) $calcHolidayRow['earnings'], 'HOLIDAY'));
    checkSame('the holiday day does not become basic pay', 0.0, (float) $calcHolidayRow['basic_pay'] - 21 * DAILY_RATE);

    // 2c: an unpaid holiday pays nothing (every recorded day is present, so the
    // only unrecorded date is the unpaid holiday itself).
    makeHoliday('2025-10-24', 0);
    $empUnpaidHoliday = makeEmployee(MONTHLY_SALARY);
    addPresentDays($empUnpaidHoliday, consecutiveDates('2025-10-01', 22));
    $calcUnpaidHoliday = calculate($engine, $empUnpaidHoliday, PERIOD_START, PERIOD_END);

    checkMoney('an unpaid holiday adds no holiday earning', 0.00, (float) $calcUnpaidHoliday['holiday_pay']);
    checkMoney('gross pay is the 22 present days only', 22 * DAILY_RATE, (float) $calcUnpaidHoliday['gross_pay']);

    // -----------------------------------------------------------------------
    heading('3. Basic salary stays separate from every other earning');
    // -----------------------------------------------------------------------
    $empMixed = makeEmployee(MONTHLY_SALARY);
    addPresentDays($empMixed, array_merge(consecutiveDates('2025-10-01', 19), ['2025-10-21']));
    addAttendance($empMixed, '2025-10-20', 'HOLIDAY', ['is_holiday' => 1]);

    $allowanceCode = nextCode('TALW');
    $allowanceId   = Database::insert('allowances', [
        'code' => $allowanceCode, 'name' => 'Payroll calc allowance',
        'amount' => 1500.00, 'is_taxable' => 1, 'is_active' => 1,
    ]);
    Database::insert('employee_allowances', [
        'employee_id' => $empMixed, 'allowance_id' => $allowanceId, 'amount' => 1500.00, 'is_active' => 1,
    ]);

    Database::execute(
        "UPDATE attendance SET overtime_hours = 2.00 WHERE employee_id = :emp AND attendance_date = '2025-10-21'",
        ['emp' => $empMixed]
    );
    Database::insert('overtime_requests', [
        'employee_id' => $empMixed, 'overtime_date' => '2025-10-21',
        'start_time' => '18:00:00', 'end_time' => '20:00:00', 'hours' => 2.00,
        'ot_type' => 'REGULAR', 'reason' => 'payroll calc test', 'status' => 'APPROVED', 'applied_hours' => 2.00,
    ]);

    $calcMixed    = calculate($engine, $empMixed, PERIOD_START, PERIOD_END);
    $basicMixed   = 20 * DAILY_RATE;                 // 20 present days
    $holidayMixed = DAILY_RATE;                      // the 20 October holiday
    $overtimeMixed = 2 * HOURLY_RATE * 1.25;         // 312.50
    $allowanceMixed = 1500.00;

    checkMoney('basic_pay holds the present days only', $basicMixed, (float) $calcMixed['basic_pay']);
    checkMoney('holiday pay is classified on its own line', $holidayMixed, (float) $calcMixed['holiday_pay']);
    checkMoney('overtime is classified on its own line', $overtimeMixed, (float) $calcMixed['overtime_pay']);
    checkMoney('the allowance is a separate earning', $allowanceMixed, (float) $calcMixed['allowances_total']);
    checkMoney(
        'gross pay = basic + holiday + overtime + night + allowances',
        $basicMixed + $holidayMixed + $overtimeMixed + (float) $calcMixed['night_pay'] + $allowanceMixed,
        (float) $calcMixed['gross_pay']
    );
    checkMoney('the BASIC line equals payroll.basic_pay', $basicMixed, itemAmount((array) $calcMixed['earnings'], 'BASIC'));
    checkMoney('the HOLIDAY line equals holiday_pay', $holidayMixed, itemAmount((array) $calcMixed['earnings'], 'HOLIDAY'));
    checkMoney('the OT line equals overtime_pay', $overtimeMixed, itemAmount((array) $calcMixed['earnings'], 'OT'));
    checkMoney('the allowance line equals allowances_total', $allowanceMixed, itemAmount((array) $calcMixed['earnings'], $allowanceCode));
    checkMoney('the earning lines add up to gross pay', (float) $calcMixed['gross_pay'], itemTotal((array) $calcMixed['earnings']));
    check(
        'basic_pay does not contain holiday, overtime or allowance money',
        (float) $calcMixed['basic_pay'] === $basicMixed,
        sprintf('basic_pay=%s', number_format((float) $calcMixed['basic_pay'], 2))
    );

    // -----------------------------------------------------------------------
    heading('4. Overtime and night differential keep their own classification');
    // -----------------------------------------------------------------------
    // 4a: 22 present days, one 22:00-02:00 shift and 2 approved REGULAR OT hours.
    $empOt = makeEmployee(MONTHLY_SALARY);
    addPresentDays($empOt, consecutiveDates('2025-10-01', 21));
    addAttendance($empOt, '2025-10-22', 'PRESENT', [
        'time_in' => '2025-10-22 22:00:00', 'time_out' => '2025-10-23 02:00:00',
    ]);
    Database::execute(
        "UPDATE attendance SET overtime_hours = 2.00 WHERE employee_id = :emp AND attendance_date = '2025-10-01'",
        ['emp' => $empOt]
    );
    Database::insert('overtime_requests', [
        'employee_id' => $empOt, 'overtime_date' => '2025-10-01',
        'start_time' => '18:00:00', 'end_time' => '20:00:00', 'hours' => 2.00,
        'ot_type' => 'REGULAR', 'reason' => 'payroll calc test', 'status' => 'APPROVED', 'applied_hours' => 2.00,
    ]);

    $calcOt = calculate($engine, $empOt, PERIOD_START, PERIOD_END);
    checkMoney('22 present days still pay 22,000.00', 22 * DAILY_RATE, (float) $calcOt['basic_pay']);
    checkMoney('2 OT hours at 125.00 x 1.25 = 312.50', 312.50, (float) $calcOt['overtime_pay']);
    checkMoney('4 night hours at 125.00 x 0.10 = 50.00', 50.00, (float) $calcOt['night_pay']);
    checkMoney('night hours are measured as 4.00', 4.0, (float) $calcOt['night_hours']);
    checkMoney('overtime hours are measured as 2.00', 2.0, (float) $calcOt['overtime_hours']);
    checkMoney('gross pay adds both premiums once', 22 * DAILY_RATE + 312.50 + 50.00, (float) $calcOt['gross_pay']);
    checkSame('overtime is an OT earning line', 1, itemCount((array) $calcOt['earnings'], 'OT'));
    checkSame('night differential is an ND earning line', 1, itemCount((array) $calcOt['earnings'], 'ND'));
    checkMoney('ND is not mixed into OT', 312.50, itemAmount((array) $calcOt['earnings'], 'OT'));
    checkMoney('OT is not mixed into ND', 50.00, itemAmount((array) $calcOt['earnings'], 'ND'));

    // 4b: the same 2 hours requested as HOLIDAY overtime pay 2.00 x the hour.
    $empOtHoliday = makeEmployee(MONTHLY_SALARY);
    addPresentDays($empOtHoliday, consecutiveDates('2025-10-01', 22));
    Database::execute(
        "UPDATE attendance SET overtime_hours = 2.00 WHERE employee_id = :emp AND attendance_date = '2025-10-01'",
        ['emp' => $empOtHoliday]
    );
    Database::insert('overtime_requests', [
        'employee_id' => $empOtHoliday, 'overtime_date' => '2025-10-01',
        'start_time' => '18:00:00', 'end_time' => '20:00:00', 'hours' => 2.00,
        'ot_type' => 'HOLIDAY', 'reason' => 'payroll calc test', 'status' => 'APPROVED', 'applied_hours' => 2.00,
    ]);

    $calcOtHoliday = calculate($engine, $empOtHoliday, PERIOD_START, PERIOD_END);
    checkMoney('HOLIDAY overtime uses the 2.00 multiplier (500.00)', 2 * HOURLY_RATE * 2.00, (float) $calcOtHoliday['overtime_pay']);
    checkMoney('basic pay is untouched by the OT type', 22 * DAILY_RATE, (float) $calcOtHoliday['basic_pay']);
    checkMoney(
        'gross pay = basic + overtime only',
        22 * DAILY_RATE + 500.00,
        (float) $calcOtHoliday['gross_pay']
    );

    // -----------------------------------------------------------------------
    heading('5. Deduction totals and net-pay arithmetic');
    // -----------------------------------------------------------------------
    // 5a: a fully present period - the baseline every other case is compared to.
    $empFull = makeEmployee(MONTHLY_SALARY);
    addPresentDays($empFull, consecutiveDates('2025-10-01', 22));
    $calcFull = calculate($engine, $empFull, PERIOD_START, PERIOD_END);

    checkMoney('a full period earns 22,000.00', 22 * DAILY_RATE, (float) $calcFull['basic_pay']);
    checkMoney('no absence to charge', 0.00, (float) $calcFull['absence_deduction']);
    checkMoney('no unpaid leave to charge', 0.00, (float) $calcFull['leave_deduction']);
    checkMoney('deductions are the statutory shares only', (float) $calcFull['statutory_total'], (float) $calcFull['total_deductions']);
    checkMoney('net pay = gross pay - total deductions', (float) $calcFull['gross_pay'] - (float) $calcFull['total_deductions'], (float) $calcFull['net_pay']);

    // 5b: two ABSENT days. An absent day earns no basic pay, so it must NOT be
    // deducted a second time (that double charge produced negative net pay).
    $empAbsent = makeEmployee(MONTHLY_SALARY);
    addPresentDays($empAbsent, consecutiveDates('2025-10-01', 20));
    addAttendance($empAbsent, '2025-10-21', 'ABSENT');
    addAttendance($empAbsent, '2025-10-22', 'ABSENT');
    $calcAbsent = calculate($engine, $empAbsent, PERIOD_START, PERIOD_END);

    checkMoney('20 present days earn 20,000.00', 20 * DAILY_RATE, (float) $calcAbsent['basic_pay']);
    checkMoney('both absent days are recorded', 2.0, (float) $calcAbsent['absent_days']);
    checkMoney('an absent day is not deducted a second time', 0.00, (float) $calcAbsent['absence_deduction']);
    checkSame('no ABSENCE deduction line is produced', 0, itemCount((array) $calcAbsent['deductions'], 'ABSENCE'));
    checkMoney(
        'two absent days cost exactly two daily rates',
        2 * DAILY_RATE,
        (float) $calcFull['basic_pay'] - (float) $calcAbsent['basic_pay']
    );
    checkMoney(
        'the deductions do not grow because of the absence',
        (float) $calcFull['total_deductions'],
        (float) $calcAbsent['total_deductions']
    );
    checkMoney('net pay stays gross - deductions', (float) $calcAbsent['gross_pay'] - (float) $calcAbsent['total_deductions'], (float) $calcAbsent['net_pay']);
    check('net pay is not negative', (float) $calcAbsent['net_pay'] > 0.0, sprintf('net_pay=%s', number_format((float) $calcAbsent['net_pay'], 2)));

    // 5c: two approved UNPAID leave days plus a fixed deduction and an active loan.
    $empLeave = makeEmployee(MONTHLY_SALARY);
    addPresentDays($empLeave, consecutiveDates('2025-10-01', 20));

    $unpaidType = Database::insert('leave_types', [
        'code' => nextCode('TULT'), 'name' => 'Payroll calc unpaid leave', 'is_paid' => 0, 'is_active' => 1,
    ]);
    $leaveRequest = Database::insert('leave_requests', [
        'employee_id' => $empLeave, 'leave_type_id' => $unpaidType,
        'start_date' => '2025-10-21', 'end_date' => '2025-10-22', 'days' => 2.00,
        'reason' => 'payroll calc test', 'status' => 'APPROVED',
    ]);
    addAttendance($empLeave, '2025-10-21', 'LEAVE', ['leave_request_id' => $leaveRequest]);
    addAttendance($empLeave, '2025-10-22', 'LEAVE', ['leave_request_id' => $leaveRequest]);

    $fixedCode = nextCode('TDED');
    $fixedId   = Database::insert('deductions', [
        'code' => $fixedCode, 'name' => 'Payroll calc deduction', 'amount' => 500.00, 'is_active' => 1,
    ]);
    Database::insert('employee_deductions', [
        'employee_id' => $empLeave, 'deduction_id' => $fixedId, 'amount' => 500.00, 'is_active' => 1,
    ]);
    Database::insert('loans', [
        'employee_id' => $empLeave, 'loan_type' => 'SALARY_LOAN', 'principal_amount' => 6000.00,
        'monthly_deduction' => 1000.00, 'balance' => 5000.00, 'start_date' => '2025-01-01', 'status' => 'ACTIVE',
    ]);

    $calcLeave = calculate($engine, $empLeave, PERIOD_START, PERIOD_END);

    checkMoney('an unpaid leave day earns no basic pay either', 20 * DAILY_RATE, (float) $calcLeave['basic_pay']);
    checkMoney('both leave days are recorded', 2.0, (float) $calcLeave['leave_days']);
    checkMoney('unpaid leave is not charged a second time', 0.00, (float) $calcLeave['leave_deduction']);
    checkSame('no UNPAID_LEAVE deduction line is produced', 0, itemCount((array) $calcLeave['deductions'], 'UNPAID_LEAVE'));
    // A 1000.00 monthly deduction is split across the pay periods of the
    // month (Phase 3A): with semi-monthly payroll ONE period proposes half.
    $loanInstalment = $engine->loanInstalmentForPeriod(1000.00, $engine->settings());

    checkMoney(
        'the fixed deduction and the loan instalment are other deductions',
        round(500.00 + $loanInstalment, 2),
        (float) $calcLeave['other_deductions']
    );
    checkMoney('the fixed deduction is itemised', 500.00, itemAmount((array) $calcLeave['deductions'], $fixedCode));
    checkMoney('the loan instalment is itemised', $loanInstalment, itemAmount((array) $calcLeave['deductions'], 'LOAN'));
    checkSame(
        'exactly one loan line per active loan',
        1,
        itemCount((array) $calcLeave['deductions'], 'LOAN')
    );
    checkMoney(
        'total deductions include the leave value only through the missing pay',
        round((float) $calcLeave['statutory_total'] + 500.00 + $loanInstalment, 2),
        (float) $calcLeave['total_deductions']
    );
    checkMoney('the deduction lines add up to total_deductions', (float) $calcLeave['total_deductions'], itemTotal((array) $calcLeave['deductions']));
    checkMoney('net pay = gross - deductions', (float) $calcLeave['gross_pay'] - (float) $calcLeave['total_deductions'], (float) $calcLeave['net_pay']);
    checkMoney(
        'the unpaid-leave value is still reported for reference',
        2 * DAILY_RATE,
        $engine->unpaidLeaveDeduction($empLeave, PERIOD_START, PERIOD_END, DAILY_RATE)
    );
    check(
        'the reference value is deliberately not charged to the payslip',
        (float) $calcLeave['leave_deduction'] === 0.0 && (float) $calcLeave['net_pay'] === round((float) $calcLeave['gross_pay'] - (float) $calcLeave['total_deductions'], 2)
    );

    // -----------------------------------------------------------------------
    heading('11. Recalculating a draft period duplicates nothing');
    // -----------------------------------------------------------------------
    $lockPeriod = $payrollService->createPeriod([
        'start_date' => '2025-09-01',
        'end_date'   => '2025-09-30',
        'pay_date'   => '2025-09-30',
        'name'       => 'Payroll calculation test 2025-09',
    ], $userId);
    $lockPeriodId = (int) $lockPeriod['id'];

    $empLock = makeEmployee(MONTHLY_SALARY);
    addPresentDays($empLock, consecutiveDates('2025-09-01', 20));

    $payrollService->calculate($lockPeriodId, $userId);

    $lockRow = Database::selectOne(
        'SELECT * FROM payroll WHERE payroll_period_id = :p AND employee_id = :e',
        ['p' => $lockPeriodId, 'e' => $empLock]
    );

    if ($lockRow === null) {
        throw new RuntimeException('the calculated period produced no row for the fixture employee.');
    }

    // A recalculation replaces the unlocked rows, so the row id changes: every
    // count below is taken per period/employee, never by payroll id.
    $rowsAfterFirst  = savedRowCount($lockPeriodId);
    $itemsAfterFirst = savedItemCount($lockPeriodId, $empLock);
    checkMoney('the saved row keeps the engine arithmetic (20,000.00)', 20 * DAILY_RATE, (float) $lockRow['basic_pay']);
    checkMoney('the saved row is not locked yet', 0.0, (float) $lockRow['is_locked']);
    check('the calculation saved at least one payroll row', $rowsAfterFirst >= 1, 'rows=' . $rowsAfterFirst);
    check('the calculation saved the itemised breakdown', $itemsAfterFirst >= 1, 'items=' . $itemsAfterFirst);

    $payrollService->calculate($lockPeriodId, $userId);

    $lockRowAgain     = savedRow($lockPeriodId, $empLock);
    $rowsAfterSecond  = savedRowCount($lockPeriodId);
    $itemsAfterSecond = savedItemCount($lockPeriodId, $empLock);

    checkSame('the payroll row count is unchanged', $rowsAfterFirst, $rowsAfterSecond);
    checkSame('the payroll item count is unchanged', $itemsAfterFirst, $itemsAfterSecond);
    checkMoney('the recalculated basic pay matches', (float) $lockRow['basic_pay'], (float) ($lockRowAgain['basic_pay'] ?? 0));
    checkMoney('the recalculated gross pay matches', (float) $lockRow['gross_pay'], (float) ($lockRowAgain['gross_pay'] ?? 0));
    checkMoney('the recalculated net pay matches', (float) $lockRow['net_pay'], (float) ($lockRowAgain['net_pay'] ?? 0));
    checkMoney('the recalculated deduction total matches', (float) $lockRow['total_deductions'], (float) ($lockRowAgain['total_deductions'] ?? 0));

    // -----------------------------------------------------------------------
    heading('12. Finalized and paid payroll is protected');
    // -----------------------------------------------------------------------
    $payrollService->transition($lockPeriodId, 'APPROVED', $userId);
    $payrollService->transition($lockPeriodId, 'FINALIZED', $userId);

    $lockedRow = savedRow($lockPeriodId, $empLock);
    checkSame('finalizing locks the payroll row', 1, (int) ($lockedRow['is_locked'] ?? -1));

    $refusedOnFinalized = false;
    $refusalMessage     = '';
    try {
        $payrollService->calculate($lockPeriodId, $userId);
    } catch (RuntimeException $e) {
        $refusedOnFinalized = true;
        $refusalMessage     = $e->getMessage();
    }
    check('recalculating a finalized period is refused', $refusedOnFinalized, $refusalMessage);

    $afterRefusal = savedRow($lockPeriodId, $empLock);
    checkMoney('the locked gross pay is unchanged', (float) ($lockedRow['gross_pay'] ?? 0), (float) ($afterRefusal['gross_pay'] ?? 0));
    checkMoney('the locked net pay is unchanged', (float) ($lockedRow['net_pay'] ?? 0), (float) ($afterRefusal['net_pay'] ?? 0));
    checkSame('the refused call added or removed no rows', $rowsAfterFirst, savedRowCount($lockPeriodId));
    checkSame('the period is still FINALIZED', 'FINALIZED', (string) Database::scalar('SELECT status FROM payroll_periods WHERE id = :id', ['id' => $lockPeriodId]));

    // Phase 5: the PAID gate needs the salary actually disbursed first, so
    // settle every payable row through the production payment service.
    $settled = disbursePeriodFully($payments, $lockPeriodId, $userId);
    check('the period salary is disbursed before PAID', $settled >= 1, 'payments recorded=' . $settled);
    check('every payroll row reports fully paid', (bool) $payments->periodReadiness($lockPeriodId)['ready']);

    $payrollService->transition($lockPeriodId, 'PAID', $userId);

    $refusedOnPaid = false;
    try {
        $payrollService->calculate($lockPeriodId, $userId);
    } catch (RuntimeException $e) {
        $refusedOnPaid = true;
    }
    check('a paid period cannot be recalculated either', $refusedOnPaid);
    checkSame('paid rows stay locked', 1, (int) ($afterRefusal['is_locked'] ?? -1));
    checkSame('the locked amounts are still the recalculated ones', (float) $lockRow['gross_pay'], (float) ($afterRefusal['gross_pay'] ?? 0));

    // -----------------------------------------------------------------------
    heading('6-8. 13th-month pay over engine-produced payroll rows');
    // -----------------------------------------------------------------------
    $p24h1 = makePeriod('2024-01-01', '2024-06-30', 'FINALIZED', $userId);
    $p24h2 = makePeriod('2024-07-01', '2024-12-31', 'FINALIZED', $userId);

    // A full year of basic salary: 2024 is a leap year, so H1 has 182 days and
    // H2 has 184. Dropping the leap day and five November days leaves exactly
    // 360 paid days at 1,000.00 a day - 360,000.00 for the year.
    $empYear = makeEmployee(MONTHLY_SALARY, ['date_hired' => '2024-01-01']);
    $yearH1  = array_values(array_filter(
        consecutiveDates('2024-01-01', 182),
        static fn (string $date): bool => $date !== '2024-02-29'
    ));
    $unpaidTail = ['2024-11-26', '2024-11-27', '2024-11-28', '2024-11-29', '2024-11-30'];
    $yearH2  = array_values(array_filter(
        consecutiveDates('2024-07-01', 184),
        static fn (string $date): bool => !in_array($date, $unpaidTail, true)
    ));

    addPresentDays($empYear, $yearH1);
    $yearHalf1 = saveEnginePayroll($engine, $p24h1, $empYear, '2024-01-01', '2024-06-30');
    addPresentDays($empYear, $yearH2);
    $yearHalf2 = saveEnginePayroll($engine, $p24h2, $empYear, '2024-07-01', '2024-12-31');

    checkMoney('the first half of the year holds 181,000.00', 181 * DAILY_RATE, (float) $yearHalf1['basic_pay']);
    checkMoney('the second half of the year holds 179,000.00', 179 * DAILY_RATE, (float) $yearHalf2['basic_pay']);
    checkMoney('the year totals 360,000.00 of basic salary', 360000.00, round((float) $yearHalf1['basic_pay'] + (float) $yearHalf2['basic_pay'], 2));

    // Part-year employment: hired 1 July, so only the second half can qualify.
    $empPart = makeEmployee(MONTHLY_SALARY, ['date_hired' => '2024-07-01']);
    addPresentDays($empPart, consecutiveDates('2024-07-01', 90));
    $partHalf2 = saveEnginePayroll($engine, $p24h2, $empPart, '2024-07-01', '2024-12-31');
    checkMoney('the part-year employee earned 90,000.00', 90000.00, (float) $partHalf2['basic_pay']);

    // Salary change during the year: 22,000.00 a month, then 33,000.00.
    $empSalary = makeEmployee(MONTHLY_SALARY, ['date_hired' => '2024-01-01']);
    addPresentDays($empSalary, consecutiveDates('2024-01-01', 91));
    $salaryH1 = saveEnginePayroll($engine, $p24h1, $empSalary, '2024-01-01', '2024-06-30');
    Database::update('employees', ['basic_salary' => 33000.00], ['id' => $empSalary]);
    addPresentDays($empSalary, consecutiveDates('2024-07-01', 100));
    $salaryH2 = saveEnginePayroll($engine, $p24h2, $empSalary, '2024-07-01', '2024-12-31');

    checkMoney('the old rate paid 91 days at 1,000.00', 91000.00, (float) $salaryH1['basic_pay']);
    checkMoney('the new rate paid 100 days at 1,500.00', 150000.00, (float) $salaryH2['basic_pay']);

    // A DRAFT (recalculable) period in the same year must not contribute.
    $empDraft = makeEmployee(MONTHLY_SALARY, ['date_hired' => '2024-01-01']);
    addPresentDays($empDraft, consecutiveDates('2024-01-01', 50));
    $draftHalf1   = saveEnginePayroll($engine, $p24h1, $empDraft, '2024-01-01', '2024-06-30');
    $draftPeriod  = makePeriod('2024-02-01', '2024-02-29', 'DRAFT', $userId);
    Database::insert('payroll', [
        'payroll_period_id' => $draftPeriod,
        'employee_id'       => $empDraft,
        'basic_pay'         => 120000.00,
        'gross_pay'         => 120000.00,
        'net_pay'           => 120000.00,
        'is_locked'         => 0,
        'calculated_at'     => date('Y-m-d H:i:s'),
    ]);
    checkMoney('the finalized part of that year holds 50,000.00', 50000.00, (float) $draftHalf1['basic_pay']);

    $generated = $thirteenth->generate(2024, $userId);
    $records   = [];
    foreach ($generated['records'] as $record) {
        $records[(int) $record['employee_id']] = $record;
    }

    checkSame('one 13th-month record per eligible employee', 4, count($records));
    checkMoney(
        'a year of 360,000.00 of basic salary produces 30,000.00',
        30000.00,
        (float) ($records[$empYear]['thirteenth_pay'] ?? 0)
    );
    checkMoney(
        'the qualifying total is the year of basic salary',
        360000.00,
        (float) ($records[$empYear]['gross_total'] ?? 0)
    );
    checkMoney(
        'part-year employment uses its actual eligible earnings (90,000.00 / 12)',
        7500.00,
        (float) ($records[$empPart]['thirteenth_pay'] ?? 0)
    );
    checkMoney(
        'the salary change is reflected in the annual total (241,000.00 / 12)',
        20083.33,
        (float) ($records[$empSalary]['thirteenth_pay'] ?? 0)
    );
    checkMoney(
        'the DRAFT period is excluded (50,000.00 / 12)',
        4166.67,
        (float) ($records[$empDraft]['thirteenth_pay'] ?? 0)
    );
    checkMoney(
        'the draft 120,000.00 never reaches the annual total',
        50000.00,
        (float) ($records[$empDraft]['gross_total'] ?? 0)
    );

    // -----------------------------------------------------------------------
    heading('9. A period crossing the calendar-year boundary is refused');
    // -----------------------------------------------------------------------
    $crossPeriod = makePeriod('2024-12-16', '2025-01-15', 'FINALIZED', $userId);
    $empCross    = makeEmployee(MONTHLY_SALARY, ['date_hired' => '2024-01-01']);
    Database::insert('payroll', [
        'payroll_period_id' => $crossPeriod,
        'employee_id'       => $empCross,
        'basic_pay'         => 80000.00,
        'gross_pay'         => 80000.00,
        'net_pay'           => 80000.00,
        'is_locked'         => 1,
        'calculated_at'     => date('Y-m-d H:i:s'),
    ]);

    $blocked2024  = false;
    $blocked2025  = false;
    $blockMessage = '';

    try {
        $thirteenth->generate(2024, $userId);
    } catch (ValidationException $e) {
        $blockMessage = (string) ($e->errors()['calendar_year'] ?? '');
        $blocked2024  = str_contains($blockMessage, 'cross the calendar-year boundary');
    }
    check('a December/January period blocks 2024 instead of guessing', $blocked2024, $blockMessage);

    try {
        $thirteenth->generate(2025, $userId);
    } catch (ValidationException $e) {
        $blocked2025 = true;
    }
    check('the same period blocks 2025 as well', $blocked2025);
    checkSame(
        'no misleading record is created for the unallocatable period',
        0,
        (int) Database::scalar('SELECT COUNT(*) FROM thirteenth_pays WHERE employee_id = :e', ['e' => $empCross])
    );

    $survivor = Database::selectOne(
        'SELECT thirteenth_pay, status FROM thirteenth_pays WHERE employee_id = :e AND calendar_year = 2024',
        ['e' => $empYear]
    );
    checkMoney('the saved figures survive the refused run', 30000.00, (float) ($survivor['thirteenth_pay'] ?? 0));
    checkSame('the saved record is still DRAFT', 'DRAFT', (string) ($survivor['status'] ?? ''));

    // Drop the unallocatable period and regenerate: DRAFT rows refresh in place.
    Database::delete('payroll_periods', ['id' => $crossPeriod]);
    $secondRun = $thirteenth->generate(2024, $userId);
    checkSame('regenerating does not duplicate records', 4, count($secondRun['records']));
    checkSame(
        'exactly one 13th-month row per employee and year',
        1,
        (int) Database::scalar(
            'SELECT COUNT(*) FROM thirteenth_pays WHERE employee_id = :e AND calendar_year = 2024',
            ['e' => $empYear]
        )
    );

    // -----------------------------------------------------------------------
    heading('12. Released and paid 13th-month records are never overwritten');
    // -----------------------------------------------------------------------
    $thirteenth->submitForApproval(2024, $userId);
    $thirteenth->approve(2024, $userId);
    $released = $thirteenth->releaseApproved(2024, $userId);
    checkSame('every generated record is released', 4, (int) ($released['released'] ?? 0));

    // Change the underlying payroll after release: the paid record must not move.
    Database::execute(
        'UPDATE payroll SET basic_pay = 999999.00, gross_pay = 999999.00 WHERE employee_id = :e AND payroll_period_id = :p',
        ['e' => $empYear, 'p' => $p24h1]
    );

    $afterRelease = $thirteenth->generate(2024, $userId);
    $yearRecord   = null;
    foreach ($afterRelease['records'] as $record) {
        if ((int) $record['employee_id'] === $empYear) {
            $yearRecord = $record;
        }
    }

    checkSame('the paid record keeps its PAID status', 'PAID', (string) ($yearRecord['status'] ?? ''));
    checkMoney('the paid amount is untouched by the later calculation', 30000.00, (float) ($yearRecord['thirteenth_pay'] ?? 0));
    checkSame(
        'still exactly one record for the employee and year',
        1,
        (int) Database::scalar(
            'SELECT COUNT(*) FROM thirteenth_pays WHERE employee_id = :e AND calendar_year = 2024',
            ['e' => $empYear]
        )
    );
} catch (Throwable $e) {
    check('no unexpected exception', false, get_class($e) . ': ' . $e->getMessage() . ' @ ' . $e->getFile() . ':' . $e->getLine());
} finally {
    // Every fixture created above (employees, attendance, holidays, periods,
    // payroll rows, payroll items, allowances, deductions, loans, leave and the
    // 13th-month ledger) is rolled back here: nothing is ever committed.
    Database::rollBack();
}

echo "\n", $passed, ' passed, ', $failed, " failed\n";

if ($failures !== []) {
    echo "\nFailures:\n";
    foreach ($failures as $failure) {
        echo '  - ', $failure, "\n";
    }
    echo "\nPAYROLL CALCULATION: FAILED\n";
    exit(1);
}

echo "\nPAYROLL CALCULATION: every check passed\n";
exit(0);