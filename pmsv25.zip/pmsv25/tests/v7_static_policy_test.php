<?php
declare(strict_types=1);
/* Source-contract/regression test that does not need a DB driver. */
require __DIR__.'/../api/services/FixedMonthlyPolicy.php';
require __DIR__.'/../api/services/PayrollCalendarService.php';
use App\Services\FixedMonthlyPolicy;
use App\Services\PayrollCalendarService;
$base=dirname(__DIR__);
$tests = 0;
function verify(bool $ok, string $message): void {
    global $tests;
    if (!$ok) { fwrite(STDERR,"FAIL: $message\n"); exit(1); }
    echo "PASS: $message\n"; $tests++;
}
function contains(string $file,string $needle): bool {
    global $base; return str_contains((string)file_get_contents($base.'/'.$file),$needle);
}
verify(FixedMonthlyPolicy::cutoffBasic(20000,'2026-10-01','2026-10-15') === 10000.0,'First cutoff basic 10000');
verify(FixedMonthlyPolicy::cutoffBasic(20000,'2026-10-16','2026-10-31') === 10000.0,'Second cutoff basic 10000');
verify(round(10000-500-250-100,2)===9150.0,'Example employee net with only government deductions');
verify(PayrollCalendarService::periodsForMonth(2026,10)[0] === ['2026-10-01','2026-10-15','2026-10-20'],'Fixed 1-15/20th schedule');
verify(PayrollCalendarService::periodsForMonth(2026,10)[1] === ['2026-10-16','2026-10-31','2026-11-05'],'Fixed 16-last/5th schedule');
verify(PayrollCalendarService::adjustedPayday('2026-11-20',['2026-11-20'])==='2026-11-19','Move bank holiday payday earlier');
verify(contains('api/services/PayrollEngine.php',"['MONTHLY', 'SEMI_MONTHLY']"),'Legacy semi-monthly is fixed basic');
verify(contains('api/services/PayrollEngine.php','unpaid_rest_5day_divisor'),'Five-day rest-unpaid rate configuration');
verify(contains('api/services/PayrollEngine.php','unpaid_rest_6day_divisor'),'Six-day rest-unpaid rate configuration');
verify(contains('api/services/AttendanceService.php','verified_correction'),'Manual time-in correction guard');
verify(contains('api/services/PayrollService.php','officialPayday($startDate, $endDate)'),'Enforce official payroll dates');
verify(contains('api/services/PayrollService.php',"['APPROVED','FINALIZED','PAID']"),'Period status invalid-calendar guard');
verify(contains('api/services/PayslipService.php','releasedOnly'),'Only released personal payslips');
verify(contains('api/controllers/PayrollAdjustmentController.php',"Auth::roleCode() !== 'MANAGER'"),'Manager-only adjustment approval');
verify(contains('database/migrations/20261023_v7_adjustments_policy.sql','CREATE TABLE IF NOT EXISTS payroll_adjustments'),'Non-destructive adjustments table');
verify(contains('frontend/js/app.js','My QR Code'),'Employee own QR menu');
verify(is_file($base.'/frontend/payroll/adjustments.html'),'Adjustment management page');
verify(is_file($base.'/frontend/payroll/deductions.html'),'Company deduction management page');
echo "V7 source-contract checks passed ($tests). Live database behavior NOT tested.\n";
