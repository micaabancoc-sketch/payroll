"""Non-DB source consistency checks; execute with Python 3."""
from pathlib import Path
p=Path(__file__).resolve().parents[1]
service=(p/'api/services/PayrollService.php').read_text()
controller=(p/'api/controllers/PayrollController.php').read_text()
routes=(p/'api/routes.php').read_text()
ui=(p/'frontend/payroll/index.html').read_text()
nav=(p/'frontend/js/app.js').read_text()
loan=(p/'api/services/LoanService.php').read_text()
checks={
 'backend individual calculate': 'function calculateSingleEmployee(' in service,
 'backend locks DRAFT': 'FOR UPDATE' in service and "(string)$period['status'] !== 'DRAFT'" in service,
 'backend one employee only': "SELECT id, is_locked, amount_paid, payment_status FROM payroll WHERE payroll_period_id=:pid AND employee_id=:eid FOR UPDATE" in service,
 'backend cannot approve partial': "'period_status'=>'DRAFT'" in service,
 'backend maintains attendance verification': 'calculateEmployee($employee, $start, $end)' in service,
 'backend writes itemized rows': "'payroll_id'=>$payrollId, 'item_type'=>'EARNING'" in service,
 'backend writes statutory rows': "'payroll_id'=>$payrollId" in service,
 'controller restricts HR': "if (Auth::roleCode() !== 'HR_PAYROLL')" in controller,
 'route allows individual calculation': "'/api/payroll/periods/{id}/calculate-employee'" in routes,
 'route lists batch exceptions': "'/api/payroll/periods/{id}/attendance-exceptions'" in routes,
 'UI calculate individual': 'Calculate Employee (Save Draft)' in ui,
 'UI batch attendance exceptions': 'View Batch Exceptions' in ui,
 'UI differentiates full batch': '>Calculate All (Save Draft)</button>' in ui,
 'Staff no duplicate personal nav': "{ section: 'My Personal'" not in nav,
 'HR Manager dropdown': 'var personalLinks' in nav and 'My Attendance' in nav,
 'Admin no payroll reviewer view': "'payroll/reviewer.html': ['MANAGER']" in nav,
 'HR self-loan scope': "!empty($filters['mine'])" in loan,
}
for k,v in checks.items():print(('PASS' if v else 'FAIL'),k)
if not all(checks.values()):raise SystemExit(1)
