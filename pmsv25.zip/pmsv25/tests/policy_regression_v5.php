<?php
declare(strict_types=1);
require __DIR__ . '/../api/services/FixedMonthlyPolicy.php';
require __DIR__ . '/../api/services/CompanyLoanPolicy.php';
require __DIR__ . '/../api/services/PayrollCalendarService.php';
require __DIR__ . '/../api/services/StatutoryDeductionService.php';
use App\Services\FixedMonthlyPolicy;
use App\Services\CompanyLoanPolicy;
use App\Services\PayrollCalendarService;
use App\Services\StatutoryDeductionService;
function check(bool $condition, string $message): void {
    if (!$condition) { throw new RuntimeException('FAIL: ' . $message); }
    echo "PASS: {$message}\n";
}
check(FixedMonthlyPolicy::cutoffBasic(20000, '2026-10-01', '2026-10-15') === 10000.00, 'first kinsenas fixed salary');
check(FixedMonthlyPolicy::cutoffBasic(20000, '2026-10-16', '2026-10-31') === 10000.00, 'second kinsenas fixed salary');
check(FixedMonthlyPolicy::cutoffBasic(20000, '2026-10-01', '2026-10-15', '2026-10-08') === 5333.33, 'hire partway through first cutoff');
check(FixedMonthlyPolicy::cutoffBasic(20000, '2026-10-01', '2026-10-15', '2026-10-20') === 0.0, 'not employed until after cutoff');
check(round(FixedMonthlyPolicy::dailyRate(20000), 2) === 657.53, '365-divisor daily rate, subject to paid-day agreement');
check(round(FixedMonthlyPolicy::dailyRate(20000) / 480 * 30, 2) === 41.10, '30-min late deduction calculated using real minute rate');
check(FixedMonthlyPolicy::earnedBasic(10000, 657.53, 0, 41.10, 0) === 9301.37, '13th-month earned basic excludes unpaid time');
check(CompanyLoanPolicy::terms('SALARY_LOAN', 10000, 6)['per_cutoff'] === 875.00, '5% flat company loan / 12 cutoffs');
check(CompanyLoanPolicy::terms('SALARY_LOAN', 10000, 12)['total_repayment'] === 10500.00, 'loan interest fixed regardless of term');
check(CompanyLoanPolicy::terms('CASH_ADVANCE', 10000, 2)['interest_amount'] === 0.0, 'salary advance no interest');
check(CompanyLoanPolicy::maxPrincipal('CASH_ADVANCE', 20000) === 10000.0, '50% salary advance cap');
check(CompanyLoanPolicy::maxPrincipal('SALARY_LOAN', 20000) === 20000.0, '100% company loan cap');
try { CompanyLoanPolicy::terms('CASH_ADVANCE', 10000, 3); throw new RuntimeException('Over-limit accepted'); }
catch (InvalidArgumentException $ex) { check(true, 'salary advance term >2 months blocked'); }
try { CompanyLoanPolicy::terms('SALARY_LOAN', 10000, 13); throw new RuntimeException('Over-limit accepted'); }
catch (InvalidArgumentException $ex) { check(true, 'company loan term >12 months blocked'); }
check(PayrollCalendarService::adjustedPayday('2026-11-21', []) === '2026-11-20', 'weekend payday advances');
check(PayrollCalendarService::adjustedPayday('2026-11-20', ['2026-11-20']) === '2026-11-19', 'holiday payday advances');
check(StatutoryDeductionService::equalSplitAmount(101.01, '2026-10-15') === 50.51, 'first contribution half with odd centavo');
check(StatutoryDeductionService::equalSplitAmount(101.01, '2026-10-31') === 50.50, 'second contribution half absorbs odd centavo');
check(round(StatutoryDeductionService::equalSplitAmount(101.01, '2026-10-15') + StatutoryDeductionService::equalSplitAmount(101.01, '2026-10-31'), 2) === 101.01, 'combined statutory deductions reconcile to monthly obligation');
echo "Policy regression tests PASSED.\n";
