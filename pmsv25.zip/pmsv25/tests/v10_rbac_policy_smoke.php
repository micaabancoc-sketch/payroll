<?php
/** Static RBAC smoke checks (no database or server required). */
declare(strict_types=1);
require dirname(__DIR__) . '/api/core/RolePolicy.php';
use App\Core\RolePolicy;
$cases = [
    ['ADMIN', 'settings.manage', true],
    ['ADMIN', 'user.view', true],
    ['ADMIN', 'employees.view', false],
    ['ADMIN', 'payroll.calculate', false],
    ['ADMIN', 'overtime.create', false],
    ['HR_PAYROLL', 'employees.update', true],
    ['HR_PAYROLL', 'overtime.approve', true],
    ['HR_PAYROLL', 'payroll.calculate', true],
    ['HR_PAYROLL', 'payroll.finalize', true],
    ['HR_PAYROLL', 'settings.manage', false],
    ['MANAGER', 'employees.view', true],
    ['MANAGER', 'overtime.create', true],
    ['MANAGER', 'overtime.approve', false],
    ['MANAGER', 'payroll.calculate', false],
    ['MANAGER', 'payroll.payslip.view', false],
    ['STAFF', 'overtime.create', false],
    ['STAFF', 'overtime.approve', false],
    ['STAFF', 'leave.create', true],
    ['STAFF', 'payroll.payslip.view_own', true],
    ['STAFF', 'payroll.payslip.view', false],
];
$bad = 0;
foreach ($cases as [$role, $permission, $expected]) {
    $actual = RolePolicy::allows($role, $permission);
    if ($actual !== $expected) {
        fwrite(STDERR, "FAIL $role $permission expected=" . ($expected ? 'yes':'no') . "\n");
        ++$bad;
    }
}
echo count($cases)-$bad . '/' . count($cases) . " RBAC checks passed\n";
exit($bad === 0 ? 0 : 1);
