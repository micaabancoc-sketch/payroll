<?php
declare(strict_types=1);

require dirname(__DIR__) . '/api/autoload.php';
// V23 autoloader assumes a case-insensitive filesystem (XAMPP Windows).
// Load these classes directly for portable offline testing on Linux.
require_once dirname(__DIR__) . '/api/services/PayslipService.php';
require_once dirname(__DIR__) . '/api/services/ThirteenthPayService.php';

use App\Services\PayslipService;
use App\Services\ThirteenthPayService;

/** Tests the pure payment-status calculation without accessing a real DB. */
function verify(bool $ok, string $name): void
{
    if (!$ok) {
        fwrite(STDERR, "FAIL: {$name}\n");
        exit(1);
    }
    echo "PASS: {$name}\n";
}

$method = (new ReflectionClass(PayslipService::class))->getMethod('paymentFromCompletedAmount');
$calc = static fn(float $net, float $paid, ?string $date = null): array => $method->invoke(null, $net, $paid, $date);

$unpaid = $calc(9265.02, 0.0);
verify($unpaid['status'] === 'UNPAID' && abs($unpaid['balance_due'] - 9265.02) < .001, 'Finalized but unpaid stays unpaid');

$partial = $calc(9265.02, 2000.00, '2026-11-03');
verify($partial['status'] === 'PARTIAL' && abs($partial['balance_due'] - 7265.02) < .001 && $partial['last_payment_date'] === '2026-11-03', 'Partial payment and last payment date');

$paid = $calc(9265.02, 9265.02, '2026-11-03');
verify($paid['status'] === 'PAID' && $paid['balance_due'] === 0.0, 'Completed payment is paid');

$over = $calc(9265.02, 9500.00);
verify($over['status'] === 'PAID' && $over['amount_paid'] === 9265.02, 'Reported payment is capped at net pay');

$zero = $calc(0.0, 0.0);
verify($zero['status'] === 'PAID' && $zero['balance_due'] === 0.0, 'Zero-net account has no outstanding balance');

$root = dirname(__DIR__);
$service = file_get_contents($root . '/api/services/ThirteenthPayService.php');
$frontend = file_get_contents($root . '/frontend/payroll/thirteenth.html');
verify(ThirteenthPayService::BIR_BENEFITS_EXEMPTION === 90000.00, '90k BIR annual combined benefits threshold is declared');
verify(str_contains($service, "'ordinary_deductions' => 0.0") && str_contains($service, "'net_thirteenth_pay'"), '13th-month routine deductions are zero and net is explicit');
verify(str_contains($service, 'cannot automatically clear that payment'), '13th-month over-ceiling release guard remains');
verify(str_contains($frontend, 'NET') || str_contains($frontend, 'Net 13th-Month'), '13th month UI shows net payout');
verify(str_contains($frontend, "role !== 'HR_PAYROLL'"), '13th month approval UI matches HR-only controller');

echo "All V23.3 offline policy checks passed.\n";
