<?php
/**
 * Government contributions (SSS, PhilHealth, Pag-IBIG) and BIR withholding tax
 * — end-to-end test.
 *
 * Proves that:
 *   1. the seeded schedules really are the published ones (SSS Circular
 *      2024-006 for 2025, PhilHealth Advisory 2025-0002, Pag-IBIG Circular
 *      No. 460, BIR RR 11-2018 Annex E) and that the legacy fixed SSS /
 *      PhilHealth / Pag-IBIG / TAX deductions were switched off so nothing can
 *      be charged twice;
 *   2. every rate, floor, ceiling, salary-credit step and tax bracket is
 *      applied correctly (including the MSC rounding, the Pag-IBIG 1% tier and
 *      the Fund Salary "basic + allowances" definition, and the BIR daily,
 *      weekly, semi-monthly and monthly tables);
 *   3. a monthly contribution is allocated to a twice-monthly payroll so both
 *      halves add up to exactly one monthly amount;
 *   4. the payroll engine, the payroll table, the payroll_statutory audit rows
 *      and the payslip all agree, and that net pay is still
 *      gross − employee deductions: employer shares never touch net pay;
 *   5. a custom (non-statutory) employee deduction still applies, while an
 *      assignment carrying a statutory code is ignored;
 *   6. a new effective-dated version can be published from the Settings API
 *      layer without touching the seeded data;
 *   7. the schedule that was in force for the payroll period is the one that
 *      is used (historical, current and future periods), a recalculation of a
 *      draft does not duplicate statutory rows, and a finalized period is
 *      locked against recalculation.
 *
 * Everything created here (employee, attendance, payroll period, test
 * deduction and the temporary schedule version) is removed on exit, so a pass
 * leaves the database exactly as it was.
 *
 * It refuses to start when the configured database looks like production (see
 * tests/db_guard.php), so it cannot be pointed at live payroll data by mistake.
 *
 * Usage: php tests/statutory_deductions_test.php
 */

declare(strict_types=1);

use App\Core\Settings;
use App\Services\PayrollEngine;
use App\Services\PayrollService;
use App\Services\PayslipService;
use App\Services\StatutoryDeductionService;

require dirname(__DIR__) . '/api/autoload.php';

$config = require dirname(__DIR__) . '/api/config/config.php';
date_default_timezone_set((string) $config['app']['timezone']);

// Refuse to write anything when the configured database looks like production:
// this suite inserts payroll rows and toggles a system setting. The check has to
// happen before the first fixture and before Settings::get() reads the table.
require __DIR__ . '/db_guard.php';
pmsAssertSafeTestDatabase();

const PERIOD_START = '2026-07-01';
const PERIOD_END   = '2026-07-31';
const SALARY       = 30000.00;

const SSS_EMPLOYEE      = 1500.00;   // 5% of MSC 30,000.00
const SSS_EMPLOYER      = 3000.00;   // 10% of MSC 30,000.00
const SSS_EC            = 30.00;     // MSC above 14,500.00
const PHILHEALTH_EMPLOYEE = 750.00;  // 2.5% of 30,000.00
const PHILHEALTH_EMPLOYER = 750.00;
const PAGIBIG_EMPLOYEE  = 200.00;    // 2% of the 10,000.00 Fund Salary ceiling
const PAGIBIG_EMPLOYER  = 200.00;

$passed   = 0;
$failed   = 0;
$failures = [];

/** @var array<string, list<int>> */
$created = [
    'employees'  => [],
    'periods'    => [],
    'deductions' => [],
    'schedules'  => [],
];

$GLOBALS['createdEmployees']  = &$created['employees'];
$GLOBALS['createdPeriods']    = &$created['periods'];
$GLOBALS['createdDeductions'] = &$created['deductions'];
$GLOBALS['createdSchedules']  = &$created['schedules'];
$GLOBALS['originalStatutoryEnabled'] = (string) Settings::get('statutory.enabled', '1');

function check(string $label, bool $ok, string $detail = ''): void
{
    global $passed, $failed, $failures;

    if ($ok) {
        $passed++;
        echo "  PASS  $label\n";
        return;
    }

    $failed++;
    $failures[] = $label;
    echo "  FAIL  $label\n";
    if ($detail !== '') {
        echo "        $detail\n";
    }
}

function checkMoney(string $label, float $expected, float $actual): void
{
    check(
        $label,
        abs($expected - $actual) < 0.005,
        sprintf('expected %s, got %s', number_format($expected, 2), number_format($actual, 2))
    );
}

function checkSame(string $label, mixed $expected, mixed $actual): void
{
    check($label, $expected === $actual, sprintf('expected %s, got %s', var_export($expected, true), var_export($actual, true)));
}

// ---------------------------------------------------------------------------
// Database helpers (a private connection, independent of the app's Database)
// ---------------------------------------------------------------------------

function testDb(): PDO
{
    static $pdo = null;

    if ($pdo instanceof PDO) {
        return $pdo;
    }

    $config = require dirname(__DIR__) . '/api/config/config.php';
    $db     = $config['database'];

    $pdo = new PDO(
        sprintf('mysql:host=%s;port=%d;dbname=%s;charset=utf8mb4', $db['host'], $db['port'], $db['name']),
        $db['user'],
        $db['password'],
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC]
    );

    return $pdo;
}

/** @param array<string, mixed> $data */
function insertRow(string $table, array $data): int
{
    $columns      = array_keys($data);
    $placeholders = array_map(static fn (string $c): string => ':' . $c, $columns);
    $quoted       = array_map(static fn (string $c): string => '`' . $c . '`', $columns);

    $sql  = sprintf('INSERT INTO `%s` (%s) VALUES (%s)', $table, implode(', ', $quoted), implode(', ', $placeholders));
    $stmt = testDb()->prepare($sql);
    $stmt->execute($data);

    return (int) testDb()->lastInsertId();
}

function scalarValue(string $sql, array $params = []): mixed
{
    $stmt = testDb()->prepare($sql);
    $stmt->execute($params);
    $value = $stmt->fetchColumn();

    return $value === false ? null : $value;
}

/** @return array<string, mixed>|null */
function dbRow(string $sql, array $params = []): ?array
{
    $stmt = testDb()->prepare($sql);
    $stmt->execute($params);
    $row = $stmt->fetch();

    return $row === false ? null : $row;
}

function randomSuffix(): string
{
    return strtoupper(bin2hex(random_bytes(4)));
}

// ---------------------------------------------------------------------------
// Cleanup: remove every fixture even if an assertion throws
// ---------------------------------------------------------------------------

register_shutdown_function(static function (): void {
    // Never leave the master switch off if the test toggled it.
    Settings::set('statutory.enabled', (string) $GLOBALS['originalStatutoryEnabled'], null);

    foreach ($GLOBALS['createdEmployees'] as $employeeId) {
        testDb()->exec('DELETE FROM attendance WHERE employee_id = ' . (int) $employeeId);
        testDb()->exec('DELETE FROM employee_deductions WHERE employee_id = ' . (int) $employeeId);
        testDb()->exec('DELETE FROM employee_allowances WHERE employee_id = ' . (int) $employeeId);
        testDb()->exec('DELETE FROM employees WHERE id = ' . (int) $employeeId);
    }

    foreach ($GLOBALS['createdDeductions'] as $deductionId) {
        testDb()->exec('DELETE FROM deductions WHERE id = ' . (int) $deductionId);
    }

    foreach ($GLOBALS['createdSchedules'] as $scheduleId) {
        testDb()->exec('DELETE FROM statutory_schedules WHERE id = ' . (int) $scheduleId);
    }

    foreach ($GLOBALS['createdPeriods'] as $periodId) {
        // Cascades to payroll, payroll_items and payroll_statutory.
        testDb()->exec('DELETE FROM payroll_periods WHERE id = ' . (int) $periodId);
    }

    // Attendance rows the engine generated for the test period (absence rows
    // carry source AUTO; nothing in this range exists outside the test).
    testDb()->exec(sprintf(
        "DELETE FROM attendance WHERE source = 'AUTO' AND attendance_date BETWEEN '%s' AND '%s'",
        PERIOD_START,
        PERIOD_END
    ));
});

// ---------------------------------------------------------------------------
// Fixtures
// ---------------------------------------------------------------------------

function newEmployee(): int
{
    $suffix = randomSuffix();

    $id = insertRow('employees', [
        'employee_number'  => 'STAT-' . $suffix,
        'first_name'       => 'Statutory',
        'last_name'        => 'Probe' . $suffix,
        'gender'           => 'OTHER',
        'email'            => 'statutory.' . strtolower($suffix) . '@test.local',
        'employment_type'  => 'FULL_TIME',
        'date_hired'       => '2026-01-05',
        'salary_type'      => 'MONTHLY',
        'basic_salary'     => SALARY,
        'work_schedule_id' => 1,
        'status'           => 'ACTIVE',
    ]);

    $GLOBALS['createdEmployees'][] = $id;

    return $id;
}

/** @param array<string, mixed> $overrides */
function newDeduction(array $overrides = []): int
{
    $id = insertRow('deductions', array_merge([
        'code'          => 'TEST-' . randomSuffix(),
        'name'          => 'Test deduction',
        'amount'        => 0.00,
        'is_percentage' => 0,
        'description'   => 'Created by tests/statutory_deductions_test.php',
        'is_active'     => 1,
    ], $overrides));

    $GLOBALS['createdDeductions'][] = $id;

    return $id;
}

/** Attendance on every weekday of the test period (no holidays in July 2026). */
function withAttendance(int $employeeId, string $start, string $end): int
{
    $days  = 0;
    $shift = scalarValue('SELECT id FROM shifts WHERE code = :code', ['code' => 'DAY']);

    for ($date = new DateTimeImmutable($start); $date <= new DateTimeImmutable($end); $date = $date->modify('+1 day')) {
        $dow = (int) $date->format('N');
        if ($dow > 5) {
            continue;
        }

        insertRow('attendance', [
            'employee_id'      => $employeeId,
            'attendance_date'  => $date->format('Y-m-d'),
            'shift_id'         => $shift !== null ? (int) $shift : null,
            'work_schedule_id' => 1,
            'time_in'          => $date->format('Y-m-d') . ' 08:00:00',
            'time_out'         => $date->format('Y-m-d') . ' 17:00:00',
            'worked_hours'     => 8.00,
            'status'           => 'PRESENT',
            'source'           => 'MANUAL',
        ]);
        $days++;
    }

    return $days;
}

/** @param array<string, mixed> $extra */
function context(float $gross, float $monthlyBasic, string $start, string $end, array $settings, array $extra = []): array
{
    return array_merge([
        'start_date'             => $start,
        'end_date'               => $end,
        'monthly_basic'          => $monthlyBasic,
        'monthly_allowances'     => 0.0,
        'gross_pay'              => $gross,
        'non_taxable_allowances' => 0.0,
        'settings'               => $settings,
    ], $extra);
}

$service = new StatutoryDeductionService();

/** Settings that switch the three contributions off, leaving only the tax. */
$taxOnly = [
    'statutory_enabled'          => true,
    'statutory_sss_enabled'      => false,
    'statutory_philhealth_enabled' => false,
    'statutory_pagibig_enabled'  => false,
    'statutory_tax_enabled'      => true,
    'pay_frequency'              => 'SEMI_MONTHLY',
];

// ===========================================================================
echo "\n1. Seeded schedules and legacy deductions\n";
// ===========================================================================

$sss = $service->scheduleFor('SSS', '2026-07-31');
$philhealth = $service->scheduleFor('PHILHEALTH', '2026-07-31');
$pagibig = $service->scheduleFor('PAGIBIG', '2026-07-31');

check('SSS 2025 schedule is present and effective', $sss !== null && $sss['effective_from'] === '2025-01-01');
checkSame('SSS employee rate is 5%', '5.0000', (string) $sss['employee_rate']);
checkSame('SSS employer rate is 10%', '10.0000', (string) $sss['employer_rate']);
checkSame('SSS MSC range', '5000.00-35000.00', sprintf('%s-%s', $sss['credit_min'], $sss['credit_max']));
checkSame('SSS credit step', '500.00', (string) $sss['credit_step']);
checkSame('SSS EC amounts', '10.00/30.00 at 14500.00', sprintf('%s/%s at %s', $sss['ec_amount'], $sss['ec_amount_high'], $sss['ec_threshold']));
check('SSS cites SSS Circular 2024-006', str_contains((string) $sss['source_name'], '2024-006'));

check('PhilHealth 2025 schedule is present', $philhealth !== null && $philhealth['effective_from'] === '2025-01-01');
checkSame('PhilHealth floor and ceiling', '10000.00-100000.00', sprintf('%s-%s', $philhealth['salary_floor'], $philhealth['salary_ceiling']));
checkSame('PhilHealth employee share is 2.5%', '2.5000', (string) $philhealth['employee_rate']);
check('PhilHealth cites Advisory 2025-0002', str_contains((string) $philhealth['source_name'], '2025-0002'));

check('Pag-IBIG schedule is present from February 2024', $pagibig !== null && $pagibig['effective_from'] === '2024-02-01');
checkSame('Pag-IBIG Fund Salary ceiling is 10,000', '10000.00', (string) $pagibig['salary_ceiling']);
checkSame('Pag-IBIG 1% tier below 1,500', '1.0000', (string) $pagibig['low_employee_rate']);
check('Pag-IBIG cites HDMF Circular 460', str_contains((string) $pagibig['source_name'], '460'));

$birSchedules = testDb()->query("SELECT frequency, effective_from FROM bir_withholding_schedules WHERE status = 'ACTIVE' ORDER BY frequency")->fetchAll();
checkSame('Four BIR tables are published', 4, count($birSchedules));
checkSame('BIR tables are effective 1 January 2023', ['2023-01-01'], array_values(array_unique(array_column($birSchedules, 'effective_from'))));
checkSame('BIR bracket rows seeded', 24, (int) scalarValue('SELECT COUNT(*) FROM bir_withholding_brackets'));

// HDMF Circular No. 460 defines the Fund Salary as the "basic salary and other
// allowances" (up to the P10,000.00 ceiling), so the seeded base must include
// allowances - not the basic salary alone.
checkSame(
    'The seeded Pag-IBIG Fund Salary base includes allowances',
    'MONTHLY_BASIC_PLUS_ALLOWANCES',
    (string) scalarValue("SELECT setting_value FROM system_settings WHERE setting_key = 'statutory.pagibig_salary_base'")
);
checkSame(
    'The Pag-IBIG schedule records the same Fund Salary base',
    'MONTHLY_BASIC_PLUS_ALLOWANCES',
    (string) scalarValue("SELECT salary_base FROM statutory_schedules WHERE code = 'PAGIBIG' AND effective_from = '2024-02-01'")
);

$deactivated = testDb()->query("SELECT COUNT(*) FROM deductions WHERE code IN ('SSS','PHILHEALTH','PAGIBIG','TAX') AND is_active = 1")->fetchColumn();
checkSame('Legacy fixed statutory deductions are switched off', 0, (int) $deactivated);
checkSame('Custom deductions are untouched', 1, (int) scalarValue("SELECT COUNT(*) FROM deductions WHERE code = 'UNIFORM' AND is_active = 1"));

// ===========================================================================
echo "\n2. Contribution maths\n";
// ===========================================================================

$contributionOnly = [
    'statutory_enabled'             => true,
    'statutory_sss_enabled'         => true,
    'statutory_philhealth_enabled'  => true,
    'statutory_pagibig_enabled'     => true,
    'statutory_tax_enabled'         => false,
];

/** @return array<string, mixed> */
function contributions(StatutoryDeductionService $service, float $salary, string $start, string $end, array $settings): array
{
    return $service->calculate(context(0.0, $salary, $start, $end, $settings));
}

$fullMonth = contributions($service, SALARY, PERIOD_START, PERIOD_END, $contributionOnly);

checkMoney('SSS employee share for 30,000', SSS_EMPLOYEE, (float) $fullMonth['contributions']['SSS']['employee_amount']);
checkMoney('SSS employer share for 30,000', SSS_EMPLOYER, (float) $fullMonth['contributions']['SSS']['employer_amount']);
checkMoney('SSS EC premium for MSC above 14,500', SSS_EC, (float) $fullMonth['contributions']['SSS']['extra_amount']);
checkMoney('PhilHealth employee share for 30,000', PHILHEALTH_EMPLOYEE, (float) $fullMonth['contributions']['PHILHEALTH']['employee_amount']);
checkMoney('Pag-IBIG employee share is capped at 2% of 10,000', PAGIBIG_EMPLOYEE, (float) $fullMonth['contributions']['PAGIBIG']['employee_amount']);

$sssCases = [
    ['salary' => 5000.00,  'msc' => 5000.00,  'employee' => 250.00,  'employer' => 500.00,  'ec' => 10.00],
    ['salary' => 5240.00,  'msc' => 5000.00,  'employee' => 250.00,  'employer' => 500.00,  'ec' => 10.00],
    ['salary' => 5250.00,  'msc' => 5500.00,  'employee' => 275.00,  'employer' => 550.00,  'ec' => 10.00],
    ['salary' => 14500.00, 'msc' => 14500.00, 'employee' => 725.00,  'employer' => 1450.00, 'ec' => 10.00],
    ['salary' => 15000.00, 'msc' => 15000.00, 'employee' => 750.00,  'employer' => 1500.00, 'ec' => 30.00],
    ['salary' => 20000.00, 'msc' => 20000.00, 'employee' => 1000.00, 'employer' => 2000.00, 'ec' => 30.00],
    ['salary' => 40000.00, 'msc' => 35000.00, 'employee' => 1750.00, 'employer' => 3500.00, 'ec' => 30.00],
];

foreach ($sssCases as $case) {
    $result = contributions($service, $case['salary'], PERIOD_START, PERIOD_END, $contributionOnly)['contributions']['SSS'];

    checkMoney(sprintf('SSS MSC for a %s salary is %s', number_format($case['salary'], 2), number_format($case['msc'], 2)), $case['msc'], (float) $result['credited_base']);
    checkMoney(sprintf('SSS employee share for a %s salary', number_format($case['salary'], 2)), $case['employee'], (float) $result['employee_amount']);
    checkMoney(sprintf('SSS employer share for a %s salary', number_format($case['salary'], 2)), $case['employer'], (float) $result['employer_amount']);
    checkMoney(sprintf('SSS EC premium for a %s salary', number_format($case['salary'], 2)), $case['ec'], (float) $result['extra_amount']);
}

$philhealthCases = [
    ['salary' => 5000.00,   'base' => 10000.00,  'employee' => 250.00],
    ['salary' => 10000.00,  'base' => 10000.00,  'employee' => 250.00],
    ['salary' => 30000.00,  'base' => 30000.00,  'employee' => 750.00],
    ['salary' => 100000.00, 'base' => 100000.00, 'employee' => 2500.00],
    ['salary' => 250000.00, 'base' => 100000.00, 'employee' => 2500.00],
];

foreach ($philhealthCases as $case) {
    $result = contributions($service, $case['salary'], PERIOD_START, PERIOD_END, $contributionOnly)['contributions']['PHILHEALTH'];

    checkMoney(sprintf('PhilHealth base for a %s salary', number_format($case['salary'], 2)), $case['base'], (float) $result['credited_base']);
    checkMoney(sprintf('PhilHealth employee share for a %s salary', number_format($case['salary'], 2)), $case['employee'], (float) $result['employee_amount']);
    checkMoney(sprintf('PhilHealth employer share for a %s salary', number_format($case['salary'], 2)), $case['employee'], (float) $result['employer_amount']);
}

$pagibigCases = [
    ['salary' => 1000.00,  'employee' => 10.00,  'employer' => 20.00],
    ['salary' => 1500.00,  'employee' => 15.00,  'employer' => 30.00],
    ['salary' => 1500.01,  'employee' => 30.00,  'employer' => 30.00],
    ['salary' => 5000.00,  'employee' => 100.00, 'employer' => 100.00],
    ['salary' => 10000.00, 'employee' => 200.00, 'employer' => 200.00],
    ['salary' => 50000.00, 'employee' => 200.00, 'employer' => 200.00],
];

foreach ($pagibigCases as $case) {
    $result = contributions($service, $case['salary'], PERIOD_START, PERIOD_END, $contributionOnly)['contributions']['PAGIBIG'];

    checkMoney(sprintf('Pag-IBIG employee share for a %s salary', number_format($case['salary'], 2)), $case['employee'], (float) $result['employee_amount']);
    checkMoney(sprintf('Pag-IBIG employer share for a %s salary', number_format($case['salary'], 2)), $case['employer'], (float) $result['employer_amount']);
}

// The Fund Salary is the basic salary plus the other allowances (Circular No.
// 460), capped at P10,000.00. An 8,000.00 basic with 2,500.00 of allowances
// therefore contributes on the ceiling, not on the basic salary alone.
$pagibigWithAllowances = static fn (string $base): array => $service->calculate(context(
    0.0,
    8000.00,
    PERIOD_START,
    PERIOD_END,
    array_merge($contributionOnly, ['statutory_pagibig_salary_base' => $base]),
    ['monthly_allowances' => 2500.00]
))['contributions']['PAGIBIG'];

checkMoney(
    'Fund Salary includes allowances (8,000 + 2,500 is capped at 10,000)',
    10000.00,
    (float) $pagibigWithAllowances('MONTHLY_BASIC_PLUS_ALLOWANCES')['credited_base']
);
checkMoney(
    'Employee share on the allowance-inclusive Fund Salary',
    200.00,
    (float) $pagibigWithAllowances('MONTHLY_BASIC_PLUS_ALLOWANCES')['employee_amount']
);
checkMoney(
    'A basic-only base still ignores the allowances',
    8000.00,
    (float) $pagibigWithAllowances('MONTHLY_BASIC')['credited_base']
);
checkMoney(
    'Employee share on the basic-only base',
    160.00,
    (float) $pagibigWithAllowances('MONTHLY_BASIC')['employee_amount']
);

// ===========================================================================
echo "\n3. Monthly allocation to a twice-monthly payroll\n";
// ===========================================================================

checkMoney('A full month is allocated 100%', 1.0, $service->allocationFactor(PERIOD_START, PERIOD_END));
checkMoney(
    '1-15 July is 15/31 of the month',
    round(15 / 31, 6),
    $service->allocationFactor('2026-07-01', '2026-07-15')
);
checkMoney(
    '16-31 July is 16/31 of the month',
    round(16 / 31, 6),
    $service->allocationFactor('2026-07-16', '2026-07-31')
);
checkMoney('February 1-15 is 15/28', round(15 / 28, 6), $service->allocationFactor('2026-02-01', '2026-02-15'));
checkMoney(
    'EQUAL_SPLIT with 2 periods per month is half',
    0.5,
    $service->allocationFactor('2026-07-01', '2026-07-15', ['statutory_allocation_basis' => 'EQUAL_SPLIT', 'statutory_periods_per_month' => 2])
);
checkMoney(
    'EQUAL_SPLIT with 4 periods per month is a quarter',
    0.25,
    $service->allocationFactor('2026-07-01', '2026-07-07', ['statutory_allocation_basis' => 'EQUAL_SPLIT', 'statutory_periods_per_month' => 4])
);

$firstHalf  = contributions($service, SALARY, '2026-07-01', '2026-07-15', $contributionOnly);
$secondHalf = contributions($service, SALARY, '2026-07-16', '2026-07-31', $contributionOnly);

checkMoney('First half SSS share is 15/31 of the monthly amount', 725.81, (float) $firstHalf['contributions']['SSS']['employee_amount']);
checkMoney('Second half SSS share is 16/31 of the monthly amount', 774.19, (float) $secondHalf['contributions']['SSS']['employee_amount']);
checkMoney(
    'Both halves add up to exactly one monthly SSS amount',
    SSS_EMPLOYEE,
    (float) $firstHalf['contributions']['SSS']['employee_amount'] + (float) $secondHalf['contributions']['SSS']['employee_amount']
);
checkMoney(
    'Both halves add up to exactly one monthly PhilHealth amount',
    PHILHEALTH_EMPLOYEE,
    (float) $firstHalf['contributions']['PHILHEALTH']['employee_amount'] + (float) $secondHalf['contributions']['PHILHEALTH']['employee_amount']
);
checkMoney(
    'Both halves add up to exactly one monthly Pag-IBIG amount',
    PAGIBIG_EMPLOYEE,
    (float) $firstHalf['contributions']['PAGIBIG']['employee_amount'] + (float) $secondHalf['contributions']['PAGIBIG']['employee_amount']
);
checkMoney(
    'Both halves add up to exactly one monthly contribution total',
    2450.00,
    (float) $firstHalf['employee_total'] + (float) $secondHalf['employee_total']
);

// ===========================================================================
echo "\n4. BIR withholding tax\n";
// ===========================================================================

/** @return array<string, mixed> */
function taxFor(StatutoryDeductionService $service, float $gross, string $start, string $end, array $settings): array
{
    return $service->calculate(context($gross, 0.0, $start, $end, $settings));
}

$monthlyCases = [
    ['gross' => 20833.00, 'tax' => 0.00],
    ['gross' => 20834.00, 'tax' => 0.15],
    ['gross' => 33333.00, 'tax' => 1875.00],
    ['gross' => 33334.00, 'tax' => 1875.20],
    ['gross' => 66667.00, 'tax' => 8541.80],
    ['gross' => 100000.00, 'tax' => 16875.05],
    ['gross' => 666667.00, 'tax' => 183541.80],
    ['gross' => 700000.00, 'tax' => 195208.35],
];

foreach ($monthlyCases as $case) {
    $result = taxFor($service, $case['gross'], PERIOD_START, PERIOD_END, $taxOnly);

    checkMoney(sprintf('Monthly table tax on %s', number_format($case['gross'], 2)), $case['tax'], (float) $result['withholding_tax']['amount']);
}

checkSame('A full-month period uses the monthly table', 'MONTHLY', taxFor($service, 30000.0, PERIOD_START, PERIOD_END, $taxOnly)['tax_frequency']);

$semiMonthlyCases = [
    ['gross' => 10417.00, 'tax' => 0.00],
    ['gross' => 10418.00, 'tax' => 0.15],
    ['gross' => 16667.00, 'tax' => 937.50],
    ['gross' => 33333.00, 'tax' => 4270.70],
    ['gross' => 100000.00, 'tax' => 21770.80],
];

foreach ($semiMonthlyCases as $case) {
    $result = taxFor($service, $case['gross'], '2026-07-01', '2026-07-15', $taxOnly);

    checkMoney(sprintf('Semi-monthly table tax on %s', number_format($case['gross'], 2)), $case['tax'], (float) $result['withholding_tax']['amount']);
}

checkSame('A half-month period uses the semi-monthly table', 'SEMI_MONTHLY', taxFor($service, 20000.0, '2026-07-01', '2026-07-15', $taxOnly)['tax_frequency']);

// The daily and weekly tables are seeded too: a payroll that runs on those
// frequencies must be withheld with the matching Annex E table.
$dailyCases = [
    ['gross' => 685.00,   'tax' => 0.00],     // bracket 1 - below threshold
    ['gross' => 700.00,   'tax' => 2.25],     // 0.00 + 15% over 685
    ['gross' => 1200.00,  'tax' => 82.45],    // 61.65 + 20% over 1,096
    ['gross' => 2192.00,  'tax' => 280.85],   // 280.85 + 25% over 2,192
    ['gross' => 5000.00,  'tax' => 982.85],   // 280.85 + 25% over 2,192
    ['gross' => 7000.00,  'tax' => 1558.90],  // 1,102.60 + 30% over 5,479
    ['gross' => 30000.00, 'tax' => 8862.70],  // 6,034.00 + 35% over 21,918
];

foreach ($dailyCases as $case) {
    $result = taxFor($service, $case['gross'], '2026-07-01', '2026-07-01', array_merge($taxOnly, ['pay_frequency' => 'DAILY']));

    checkMoney(sprintf('Daily table tax on %s', number_format($case['gross'], 2)), $case['tax'], (float) $result['withholding_tax']['amount']);
}

$weeklyCases = [
    ['gross' => 4808.00,   'tax' => 0.00],      // bracket 1 - below threshold
    ['gross' => 4809.00,   'tax' => 0.15],      // 0.00 + 15% over 4,808
    ['gross' => 7692.00,   'tax' => 432.60],    // 432.60 + 20% over 7,692
    ['gross' => 10000.00,  'tax' => 894.20],    // 432.60 + 20% over 7,692
    ['gross' => 20000.00,  'tax' => 3124.95],   // 1,971.20 + 25% over 15,385
    ['gross' => 38462.00,  'tax' => 7740.45],   // 7,740.45 + 30% over 38,462
    ['gross' => 60000.00,  'tax' => 14201.85],  // 7,740.45 + 30% over 38,462
    ['gross' => 153846.00, 'tax' => 42355.65],  // 42,355.65 + 35% over 153,846
];

foreach ($weeklyCases as $case) {
    $result = taxFor($service, $case['gross'], '2026-07-01', '2026-07-07', array_merge($taxOnly, ['pay_frequency' => 'WEEKLY']));

    checkMoney(sprintf('Weekly table tax on %s', number_format($case['gross'], 2)), $case['tax'], (float) $result['withholding_tax']['amount']);
}

checkSame(
    'A daily payroll uses the daily table',
    'DAILY',
    taxFor($service, 500.0, '2026-07-01', '2026-07-01', array_merge($taxOnly, ['pay_frequency' => 'DAILY']))['tax_frequency']
);
checkSame(
    'A weekly payroll uses the weekly table',
    'WEEKLY',
    taxFor($service, 500.0, '2026-07-01', '2026-07-07', array_merge($taxOnly, ['pay_frequency' => 'WEEKLY']))['tax_frequency']
);

// A period before the published table existed must not invent a rate: the tax
// is reported as missing (visible in the audit trail) and nothing is withheld.
$beforeTables = taxFor($service, 20000.0, '2022-12-01', '2022-12-15', $taxOnly);
checkMoney('A period before the BIR table existed withholds nothing', 0.00, (float) $beforeTables['withholding_tax']['amount']);
check('A period before the BIR table existed is reported, not silent', ($beforeTables['withholding_tax']['missing'] ?? false) === true);

// Contributions come off the taxable compensation, and non-taxable allowances
// never do.
$withContributions = $service->calculate(context(31363.64, SALARY, PERIOD_START, PERIOD_END, array_merge($contributionOnly, [
    'statutory_tax_enabled' => true,
])));
checkMoney('Taxable compensation excludes the employee contributions', 31363.64 - 2450.00, (float) $withContributions['taxable_compensation']);
checkMoney('Monthly tax on 28,913.64', 1212.10, (float) $withContributions['withholding_tax']['amount']);

$withNonTaxable = $service->calculate(context(
    31363.64,
    SALARY,
    PERIOD_START,
    PERIOD_END,
    array_merge($contributionOnly, ['statutory_tax_enabled' => true]),
    ['non_taxable_allowances' => 1500.00]
));
checkMoney('Non-taxable allowances are removed from the taxable base', 31363.64 - 2450.00 - 1500.00, (float) $withNonTaxable['taxable_compensation']);

// ===========================================================================
echo "\n5. Payroll engine, payroll table and payslip\n";
// ===========================================================================

$employeeId = newEmployee();
$presentDays = withAttendance($employeeId, PERIOD_START, PERIOD_END);
checkSame('Attendance fixture covers the July 2026 weekdays', 23, $presentDays);

$engine   = new PayrollEngine();
$employee = dbRow('SELECT * FROM employees WHERE id = :id', ['id' => $employeeId]);
$engineResult = $engine->calculateEmployee($employee, PERIOD_START, PERIOD_END);

checkMoney('Basic pay is 23 x the daily rate', round(23 * (SALARY / 22), 2), (float) $engineResult['basic_pay']);
checkMoney('Gross pay equals basic pay (no overtime, allowances or holidays)', (float) $engineResult['basic_pay'], (float) $engineResult['gross_pay']);

$deductionCodes = array_map(static fn (array $item): string => (string) $item['code'], $engineResult['deductions']);
foreach (['SSS_EE', 'PHILHEALTH_EE', 'PAGIBIG_EE', 'WITHHOLDING_TAX'] as $code) {
    check(sprintf('The payslip carries a %s line', $code), in_array($code, $deductionCodes, true));
}

checkMoney('Engine SSS deduction', SSS_EMPLOYEE, (float) $engineResult['statutory_sss']);
checkMoney('Engine PhilHealth deduction', PHILHEALTH_EMPLOYEE, (float) $engineResult['statutory_philhealth']);
checkMoney('Engine Pag-IBIG deduction', PAGIBIG_EMPLOYEE, (float) $engineResult['statutory_pagibig']);
checkMoney('Engine withholding tax', 1212.10, (float) $engineResult['withholding_tax']);
checkMoney('Engine statutory total', 3662.10, (float) $engineResult['statutory_total']);
checkMoney(
    'Employer shares (including the SSS EC premium) are reported, not deducted',
    SSS_EMPLOYER + SSS_EC + PHILHEALTH_EMPLOYER + PAGIBIG_EMPLOYER,
    (float) $engineResult['employer_contributions']
);
checkMoney(
    'Net pay is still gross pay minus employee deductions',
    (float) $engineResult['gross_pay'] - (float) $engineResult['total_deductions'],
    (float) $engineResult['net_pay']
);
checkMoney(
    'Total deductions include the employee statutory amounts',
    (float) $engineResult['statutory_total'] + (float) $engineResult['other_deductions']
        + (float) $engineResult['late_deduction'] + (float) $engineResult['undertime_deduction']
        + (float) $engineResult['absence_deduction'] + (float) $engineResult['leave_deduction'],
    (float) $engineResult['total_deductions']
);
check(
    'The employer share is not what the employee pays',
    abs((float) $engineResult['net_pay'] - ((float) $engineResult['gross_pay'] - (float) $engineResult['total_deductions'])) < 0.005
        && (float) $engineResult['employer_contributions'] > 0
);
check('The snapshot records the statutory schedule sources', isset($engineResult['snapshot']['statutory']['schedules'][0]['source']));

// Persistence: a payroll row, the audit rows and the payslip.
$periodId = insertRow('payroll_periods', [
    'code'       => 'PP-TEST-' . randomSuffix(),
    'name'       => 'Statutory test period',
    'start_date' => PERIOD_START,
    'end_date'   => PERIOD_END,
    'pay_date'   => '2026-08-05',
    'status'     => 'DRAFT',
]);
$GLOBALS['createdPeriods'][] = $periodId;

$calculation = (new PayrollService())->calculate($periodId);
check('PayrollService processed at least the fixture employee', (int) $calculation['employees_processed'] >= 1);

$payrollRow = dbRow('SELECT * FROM payroll WHERE payroll_period_id = :pid AND employee_id = :emp', ['pid' => $periodId, 'emp' => $employeeId]);
check('A payroll row was written', $payrollRow !== null);
checkMoney('Stored SSS deduction', SSS_EMPLOYEE, (float) $payrollRow['statutory_sss']);
checkMoney('Stored PhilHealth deduction', PHILHEALTH_EMPLOYEE, (float) $payrollRow['statutory_philhealth']);
checkMoney('Stored Pag-IBIG deduction', PAGIBIG_EMPLOYEE, (float) $payrollRow['statutory_pagibig']);
checkMoney('Stored withholding tax', 1212.10, (float) $payrollRow['withholding_tax']);
checkMoney('Stored statutory total', 3662.10, (float) $payrollRow['statutory_total']);
checkMoney('Stored employer contributions', 3980.00, (float) $payrollRow['employer_contributions']);
checkMoney(
    'Stored net pay equals gross minus total deductions',
    (float) $payrollRow['gross_pay'] - (float) $payrollRow['total_deductions'],
    (float) $payrollRow['net_pay']
);

$statutoryRows = testDb()->prepare('SELECT code, employee_amount, employer_amount, extra_amount, schedule_source FROM payroll_statutory WHERE payroll_id = :id ORDER BY id');
$statutoryRows->execute(['id' => (int) $payrollRow['id']]);
$audit = $statutoryRows->fetchAll();
checkSame('Four statutory audit rows were written', 4, count($audit));
checkSame('Audit rows cover SSS, PhilHealth, Pag-IBIG and the tax', ['SSS', 'PHILHEALTH', 'PAGIBIG', 'WITHHOLDING_TAX'], array_column($audit, 'code'));
check('Each audit row records where the rule came from', trim((string) $audit[0]['schedule_source']) !== '');
checkMoney('The audit row keeps the monthly amount next to the period amount', SSS_EMPLOYEE, (float) $audit[0]['employee_amount']);

$payslip = (new PayslipService())->render((int) $payrollRow['id']);
checkMoney('Payslip totals show the SSS deduction', SSS_EMPLOYEE, (float) $payslip['payslip']['totals']['statutory_sss']);
checkMoney('Payslip totals show the withholding tax', 1212.10, (float) $payslip['payslip']['totals']['withholding_tax']);
checkMoney('Payslip totals show the statutory total', 3662.10, (float) $payslip['payslip']['totals']['statutory_total']);
checkMoney(
    'Payslip totals agree with net pay',
    (float) $payslip['payslip']['totals']['gross_pay'] - (float) $payslip['payslip']['totals']['total_deductions'],
    (float) $payslip['payslip']['totals']['net_pay']
);

$employerLines = array_column($payslip['payslip']['employer_contributions'], 'code');
checkSame('Payslip lists the employer shares for reference only', ['SSS', 'PHILHEALTH', 'PAGIBIG'], $employerLines);
$payslipDeductionCodes = array_map(static fn (array $item): string => (string) $item['code'], $payslip['payslip']['deductions']);
check('Payslip deductions include the statutory codes', in_array('SSS_EE', $payslipDeductionCodes, true) && in_array('WITHHOLDING_TAX', $payslipDeductionCodes, true));

// A recalculation replaces the previous unlocked figures instead of stacking a
// second set of statutory rows on top of the first.
$recalculation = (new PayrollService())->calculate($periodId);
check('Recalculating the draft period reprocesses the employee', (int) $recalculation['employees_processed'] >= 1);

$recalculatedRow = dbRow('SELECT * FROM payroll WHERE payroll_period_id = :pid AND employee_id = :emp', ['pid' => $periodId, 'emp' => $employeeId]);
check('The recalculated payroll row exists', $recalculatedRow !== null);
checkSame(
    'Exactly one payroll row per employee after a recalculation',
    1,
    (int) scalarValue('SELECT COUNT(*) FROM payroll WHERE payroll_period_id = :pid AND employee_id = :emp', ['pid' => $periodId, 'emp' => $employeeId])
);
checkSame(
    'A recalculation does not duplicate the statutory detail rows',
    4,
    (int) scalarValue('SELECT COUNT(*) FROM payroll_statutory WHERE payroll_id = :id', ['id' => (int) $recalculatedRow['id']])
);
checkMoney('The recalculated statutory total is unchanged', 3662.10, (float) $recalculatedRow['statutory_total']);
checkMoney('The recalculated net pay is unchanged', (float) $payrollRow['net_pay'], (float) $recalculatedRow['net_pay']);

// Finalized payroll is protected: the period is locked (finalized_at set) and a
// further recalculation is refused.
testDb()->exec("UPDATE payroll_periods SET status = 'FINALIZED', finalized_at = NOW() WHERE id = " . (int) $periodId);
$lockedOut = false;
try {
    (new PayrollService())->calculate($periodId);
} catch (RuntimeException) {
    $lockedOut = true;
}
check('A finalized (locked) period cannot be recalculated', $lockedOut);

// ===========================================================================
echo "\n6. No double deduction, custom deductions still apply\n";
// ===========================================================================

// 'SSS_EE' is one of the reserved statutory codes: the engine must ignore an
// employee assignment that carries it while the schedules are in charge.
$legacy = newDeduction(['code' => 'SSS_EE', 'name' => 'Legacy SSS assignment', 'amount' => 500.00]);
$custom = newDeduction(['code' => 'CAFE', 'name' => 'Company canteen', 'amount' => 250.00]);

insertRow('employee_deductions', ['employee_id' => $employeeId, 'deduction_id' => $legacy, 'amount' => 500.00, 'is_active' => 1]);
insertRow('employee_deductions', ['employee_id' => $employeeId, 'deduction_id' => $custom, 'amount' => 250.00, 'is_active' => 1]);

$employee = dbRow('SELECT * FROM employees WHERE id = :id', ['id' => $employeeId]);
$withAssignments = (new PayrollEngine())->calculateEmployee($employee, PERIOD_START, PERIOD_END);

$codes = array_map(static fn (array $item): string => (string) $item['code'], $withAssignments['deductions']);
check('An assignment carrying a reserved statutory code is ignored', count(array_keys($codes, 'SSS_EE', true)) === 1);
check('The statutory SSS line is still there', in_array('SSS_EE', $codes, true));
checkMoney('A custom deduction still applies', 250.00, (float) $withAssignments['other_deductions']);
checkMoney('The ignored SSS assignment is not part of other deductions', 250.00, (float) $withAssignments['other_deductions']);

Settings::set('statutory.enabled', '0', null);
$employee = dbRow('SELECT * FROM employees WHERE id = :id', ['id' => $employeeId]);
$disabled = (new PayrollEngine())->calculateEmployee($employee, PERIOD_START, PERIOD_END);
$disabledCodes = array_map(static fn (array $item): string => (string) $item['code'], $disabled['deductions']);

checkMoney('With the master switch off nothing is charged as statutory', 0.0, (float) $disabled['statutory_total']);
check('With the master switch off the legacy fixed deduction applies again', count(array_keys($disabledCodes, 'SSS_EE', true)) === 1);
checkMoney('Other deductions then include the legacy SSS amount', 750.00, (float) $disabled['other_deductions']);

Settings::set('statutory.enabled', (string) $GLOBALS['originalStatutoryEnabled'], null);

// ===========================================================================
echo "\n7. Publishing a new effective-dated version\n";
// ===========================================================================

$tempSchedule = insertRow('statutory_schedules', [
    'code'           => 'TEST_UNIT',
    'name'           => 'Temporary test schedule',
    'agency'         => 'Test',
    'scheme'         => 'PERCENTAGE',
    'effective_from' => '2026-01-01',
    'salary_base'    => 'MONTHLY_BASIC',
    'employee_rate'  => 1.0000,
    'employer_rate'  => 2.0000,
    'rounding'       => 'CENTAVO',
    'deduction_code' => 'TEST_UNIT_EE',
    'deduction_name' => 'Temporary test deduction',
    'status'         => 'ACTIVE',
]);
$GLOBALS['createdSchedules'][] = $tempSchedule;

$updated = $service->updateSchedule($tempSchedule, ['employee_rate' => '3.5000', 'notes' => 'Edited by the test']);
checkSame('Editing a schedule version stores the new rate', '3.5000', (string) $updated['employee_rate']);
checkSame('Editing a schedule version stores the note', 'Edited by the test', (string) $updated['notes']);

$validationFailed = false;
try {
    $service->updateSchedule($tempSchedule, ['employee_rate' => '-1']);
} catch (InvalidArgumentException) {
    $validationFailed = true;
}
check('A negative rate is rejected', $validationFailed);

$version = $service->createVersion('TEST_UNIT', '2027-01-01');
$GLOBALS['createdSchedules'][] = (int) $version['id'];
checkSame('The new version starts on the requested date', '2027-01-01', (string) $version['effective_from']);
checkMoney('The new version copies the edited rate', 3.5, (float) $version['employee_rate']);

$previous = dbRow('SELECT effective_to FROM statutory_schedules WHERE id = :id', ['id' => $tempSchedule]);
checkSame('The previous version is closed the day before', '2026-12-31', (string) $previous['effective_to']);

// ===========================================================================
echo "\n8. Effective-dated schedule selection\n";
// ===========================================================================

// Two test-only SSS versions so the same employee is costed with the version
// that was actually in force for the period (the seeded 2025-01-01 version must
// still apply to the periods before the first test version starts).
$service->clearCache();

$sssFromJuly = insertRow('statutory_schedules', [
    'code'           => 'SSS',
    'name'           => 'SSS Contribution (July test version)',
    'agency'         => 'Test',
    'scheme'         => 'CREDIT_RATE',
    'effective_from' => '2026-07-01',
    'salary_base'    => 'MONTHLY_BASIC',
    'employee_rate'  => 6.0000,
    'employer_rate'  => 11.0000,
    'credit_min'     => 5000.00,
    'credit_max'     => 35000.00,
    'credit_step'    => 500.00,
    'rounding'       => 'CENTAVO',
    'deduction_code' => 'SSS_EE',
    'deduction_name' => 'SSS Contribution (Employee Share)',
    'status'         => 'ACTIVE',
]);
$GLOBALS['createdSchedules'][] = $sssFromJuly;

$sssFromSeptember = insertRow('statutory_schedules', [
    'code'           => 'SSS',
    'name'           => 'SSS Contribution (September test version)',
    'agency'         => 'Test',
    'scheme'         => 'CREDIT_RATE',
    'effective_from' => '2026-09-01',
    'salary_base'    => 'MONTHLY_BASIC',
    'employee_rate'  => 7.0000,
    'employer_rate'  => 12.0000,
    'credit_min'     => 5000.00,
    'credit_max'     => 35000.00,
    'credit_step'    => 500.00,
    'rounding'       => 'CENTAVO',
    'deduction_code' => 'SSS_EE',
    'deduction_name' => 'SSS Contribution (Employee Share)',
    'status'         => 'ACTIVE',
]);
$GLOBALS['createdSchedules'][] = $sssFromSeptember;

$june      = contributions($service, SALARY, '2026-06-01', '2026-06-15', $contributionOnly)['contributions']['SSS'];
$july      = contributions($service, SALARY, '2026-07-01', '2026-07-15', $contributionOnly)['contributions']['SSS'];
$september = contributions($service, SALARY, '2026-09-01', '2026-09-15', $contributionOnly)['contributions']['SSS'];

checkSame('June 2026 still uses the seeded 2025 schedule', '2025-01-01', (string) $june['schedule_effective_from']);
checkSame('July 2026 uses the version effective 1 July', '2026-07-01', (string) $july['schedule_effective_from']);
checkSame('September 2026 uses the version effective 1 September', '2026-09-01', (string) $september['schedule_effective_from']);
checkMoney('The seeded 5% still applies to a June period', 1500.00, (float) $june['monthly_employee_amount']);
checkMoney('The 6% version applies to a July period', 1800.00, (float) $july['monthly_employee_amount']);
checkMoney('The 7% version applies to a September period', 2100.00, (float) $september['monthly_employee_amount']);

// The BIR tables are effective-dated the same way: a period before the first
// published table has nothing to withhold and says so, rather than guessing.
check('No BIR table is published for a 2022 period', $service->birScheduleFor('SEMI_MONTHLY', '2022-12-15') === null);
check('The 2023-onwards table is found for a 2026 period', $service->birScheduleFor('SEMI_MONTHLY', '2026-07-15') !== null);

// ===========================================================================
// Summary
// ===========================================================================

echo "\n" . str_repeat('-', 70) . "\n";
printf("STATUTORY DEDUCTIONS: %d passed, %d failed\n", $passed, $failed);

if ($failed > 0) {
    echo "\nFailures:\n";
    foreach ($failures as $failure) {
        echo '  - ' . $failure . "\n";
    }
    exit(1);
}

echo "All statutory deduction checks passed.\n";
exit(0);