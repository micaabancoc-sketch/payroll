<?php
/**
 * Statutory reports & remittance tracking test (Phase 6).
 *
 * Proves, against real locked-period evidence, that:
 *   1. the migration is applied: the statutory_remittances register, its
 *      snapshot items and the report.statutory / remittance.view /
 *      remittance.manage permissions all exist;
 *   2. the contribution register (ReportService::statutoryContributions) only
 *      reports locked periods — a DRAFT period's rows are excluded, exactly as
 *      StatutoryRemittanceService treats a draft as non-evidence;
 *   3. the register filters by agency, code, employee and date window, and
 *      paginates;
 *   4. StatutoryRemittanceService::generate() files a remittance whose snapshot
 *      totals equal the sum of the underlying payroll_statutory rows, and
 *      ReportService::statutoryRemittances() lists that filed register without
 *      ever recomputing a contribution;
 *   5. ReportService::statutorySummary() aggregates the per-agency / per-month
 *      due totals and they reconcile to the filed register;
 *   6. the report and the remittance service never disagree about which agency
 *      files a payroll_statutory code (both read StatutoryRemittanceService::
 *      AGENCIES);
 *   7. the OPEN -> SUBMITTED -> PAID confirmation gate is honoured: nothing is
 *      marked paid without a payment reference and a payment date, and a
 *      payment date can never be in the future.
 *
 * Everything is created inside ONE outer transaction and rolled back when the
 * script ends, so no fixture ever survives — the genuine database is never
 * touched (tests/db_guard.php refuses it). Nested-safe savepoints let the
 * remittance service's own begin/commit run inside the outer transaction
 * without committing anything.
 *
 * Usage:
 *   DB_NAME=attendance_payroll_test php tests/statutory_remittances_report_test.php
 *
 * Exit code 0 = every check passed, 1 = at least one check failed.
 */

declare(strict_types=1);

use App\Core\Database;
use App\Core\ValidationException;
use App\Services\PayrollEngine;
use App\Services\PayrollService;
use App\Services\ReportService;
use App\Services\StatutoryRemittanceService;

require dirname(__DIR__) . '/api/autoload.php';

function check(string $label, bool $ok, string $detail = ''): void
{
    global $passed, $failed, $failures;

    if ($ok) {
        $passed++;
        echo "  PASS  $label\n";
        return;
    }

    $failed++;
    $failures[] = $label;
    echo "  FAIL  $label\n";
    if ($detail !== '') {
        echo "        $detail\n";
    }
}

function checkMoney(string $label, float $expected, float $actual): void
{
    check(
        $label,
        abs($expected - $actual) < 0.005,
        sprintf('expected %s, got %s', number_format($expected, 2), number_format($actual, 2))
    );
}

function checkSame(string $label, mixed $expected, mixed $actual): void
{
    check($label, $expected === $actual, sprintf('expected %s, got %s', var_export($expected, true), var_export($actual, true)));
}

function heading(string $title): void
{
    echo "\n", $title, "\n", str_repeat('-', strlen($title)), "\n";
}

// ---------------------------------------------------------------------------
// Fixture helpers
// ---------------------------------------------------------------------------

$sequence = 0;

function nextCode(string $prefix): string
{
    global $sequence;
    $sequence++;

    return sprintf('%s%02d_%s', $prefix, $sequence, strtoupper(bin2hex(random_bytes(3))));
}

function makeEmployee(float $salary): int
{
    return Database::insert('employees', [
        'employee_number' => nextCode('REM-'),
        'first_name'      => 'Remit',
        'last_name'       => 'Mgmt',
        'gender'          => 'OTHER',
        'date_hired'      => '2024-01-01',
        'employment_type' => 'FULL_TIME',
        'salary_type'     => 'MONTHLY',
        'basic_salary'    => $salary,
        'status'          => 'ACTIVE',
    ]);
}

function addPresentDays(int $employeeId, array $dates): void
{
    foreach ($dates as $date) {
        Database::insert('attendance', [
            'employee_id'     => $employeeId,
            'attendance_date' => $date,
            'status'          => 'PRESENT',
            'source'          => 'MANUAL',
        ]);
    }
}

function consecutiveDates(string $from, int $count): array
{
    $cursor = new DateTimeImmutable($from);
    $dates  = [];

    for ($i = 0; $i < $count; $i++) {
        $dates[] = $cursor->format('Y-m-d');
        $cursor  = $cursor->modify('+1 day');
    }

    return $dates;
}

function payrollRowId(int $periodId, int $employeeId): int
{
    return (int) (Database::scalar(
        'SELECT id FROM payroll WHERE payroll_period_id = :pid AND employee_id = :e',
        ['pid' => $periodId, 'e' => $employeeId]
    ) ?? 0);
}

/**
 * Create, calculate and lock a one-employee period, returning both ids. The
 * employee must be present on every day of [start, end] so net pay equals the
 * full basic salary. The period ends FINALIZED — a locked status whose rows
 * count as filing evidence.
 *
 * @return array{period: int, payroll: int}
 */
function lockedPeriod(PayrollService $payroll, int $employeeId, string $start, string $end, string $name, int $userId): array
{
    $period = $payroll->createPeriod([
        'start_date' => $start,
        'end_date'   => $end,
        'pay_date'   => $end,
        'name'       => $name,
    ], $userId);
    $periodId = (int) $period['id'];

    $payroll->calculate($periodId, $userId);
    $payroll->transition($periodId, 'APPROVED', $userId);
    $payroll->transition($periodId, 'FINALIZED', $userId);

    return ['period' => $periodId, 'payroll' => payrollRowId($periodId, $employeeId)];
}

function remittanceAuditCount(string $action, int $remittanceId): int
{
    return (int) (Database::scalar(
        "SELECT COUNT(*) FROM audit_logs
           WHERE action = :a AND entity_type = 'statutory_remittance' AND entity_id = :e",
        ['a' => $action, 'e' => (string) $remittanceId]
    ) ?? 0);
}

$config = require dirname(__DIR__) . '/api/config/config.php';
date_default_timezone_set((string) $config['app']['timezone']);

// Refuse to write anything when the configured database looks like production.
require __DIR__ . '/db_guard.php';
pmsAssertSafeTestDatabase();

const PER_A_START = '2026-06-01';
const PER_A_END   = '2026-06-30';
// A separate, non-overlapping month for the DRAFT control period: overlapping
// periods are rejected by PayrollService, so the draft gets its own window.
const PER_DRAFT_START = '2026-05-01';
const PER_DRAFT_END   = '2026-05-31';

const SALARY = 30000.00;
const SSS_EMPLOYEE = 1500.00;   // 5% of the MSC-capped basic salary.
const SSS_EMPLOYER = 3000.00;   // 10% of the MSC.
const SSS_EC       = 30.00;     // MSC above the 14,500.00 EC threshold.

$passed   = 0;
$failed   = 0;
$failures = [];

Database::beginTransaction();


try {
    $userId = (int) (Database::scalar(
        "SELECT id FROM users WHERE username = 'admin' AND deleted_at IS NULL LIMIT 1"
    ) ?? 0);

    if ($userId === 0) {
        throw new RuntimeException('admin account not found - seed the database first.');
    }

    $engine   = new PayrollEngine();
    $payroll  = new PayrollService($engine);
    $reports  = new ReportService();
    $remitSvc = new StatutoryRemittanceService();

    // -----------------------------------------------------------------------
    heading('1. Preflight: the Phase 6 migration is applied');
    // -----------------------------------------------------------------------
    $remTable = (int) (Database::scalar(
        "SELECT COUNT(*) FROM information_schema.tables
          WHERE table_schema = DATABASE() AND table_name IN ('statutory_remittances','statutory_remittance_items')"
    ) ?? 0);
    check('the remittance register and its items exist', $remTable === 2,
        'run: php database/migrate_statutory_remittances.php');

    $remCols = (int) (Database::scalar(
        "SELECT COUNT(*) FROM information_schema.columns
          WHERE table_schema = DATABASE() AND table_name = 'statutory_remittances'
            AND column_name IN ('reference_no','agency_code','status','total_employee',
                                'filing_reference','paid_reference','paid_date')"
    ) ?? 0);
    check('the register carries the filing/payment columns', $remCols === 7,
        'run: php database/migrate_statutory_remittances.php');

    $windowKey = (int) (Database::scalar(
        "SELECT COUNT(DISTINCT index_name) FROM information_schema.statistics
          WHERE table_schema = DATABASE() AND table_name = 'statutory_remittances'
            AND index_name = 'uq_remittance_window'"
    ) ?? 0);
    check('the (agency, window) uniqueness key exists', $windowKey === 1,
        'run: php database/migrate_statutory_remittances.php');

    $perms = (int) (Database::scalar(
        "SELECT COALESCE(SUM(
                    JSON_CONTAINS(`permissions`, '\"report.statutory\"')
                  + JSON_CONTAINS(`permissions`, '\"remittance.view\"')
                  + JSON_CONTAINS(`permissions`, '\"remittance.manage\"')
                ), 0)
           FROM `roles`
          WHERE `code` = 'MANAGER' AND JSON_VALID(`permissions`)"
    ) ?? 0);
    check('MANAGER holds the three remittance permissions', $perms === 3,
        'run: php database/migrate_statutory_remittances.php');

    if ($remTable !== 2) {
        throw new RuntimeException('Phase 6 schema missing - run: php database/migrate_statutory_remittances.php');
    }


    // -----------------------------------------------------------------------
    heading('2. Locked periods produce real payroll_statutory evidence');
    // -----------------------------------------------------------------------
    $empA = makeEmployee(SALARY);
    addPresentDays($empA, consecutiveDates(PER_A_START, 30));
    $finalA = lockedPeriod($payroll, $empA, PER_A_START, PER_A_END, 'Remit Jun 2026', $userId);
    checkSame('the June period is locked (FINALIZED)', 'FINALIZED',
        (string) (Database::scalar('SELECT status FROM payroll_periods WHERE id = :id', ['id' => $finalA['period']]) ?? ''));

    $payrollA = $finalA['payroll'];
    $sssRow = Database::selectOne(
        'SELECT employee_amount, employer_amount, extra_amount FROM payroll_statutory
          WHERE payroll_id = :id AND code = :code',
        ['id' => $payrollA, 'code' => 'SSS']
    );
    check('the SSS contribution row exists on the locked period', $sssRow !== null);
    checkMoney('the SSS employee share is the expected 5%', SSS_EMPLOYEE, (float) ($sssRow['employee_amount'] ?? 0));
    checkMoney('the SSS employer share is the expected 10%', SSS_EMPLOYER, (float) ($sssRow['employer_amount'] ?? 0));
    checkMoney('the SSS EC amount is carried as extra', SSS_EC, (float) ($sssRow['extra_amount'] ?? 0));

    $statutoryCodeCount = (int) (Database::scalar(
        'SELECT COUNT(*) FROM payroll_statutory WHERE payroll_id = :id',
        ['id' => $payrollA]
    ) ?? 0);
    check('every statutory line (SSS, PhilHealth, Pag-IBIG, tax) was audited', $statutoryCodeCount === 4,
        sprintf('rows: %d', $statutoryCodeCount));

    // A DRAFT period with statutory rows must be excluded from every report:
    // a draft can still be recalculated, so its contributions are not evidence.
    // PayrollService::calculate() advances DRAFT -> FOR_REVIEW, so we calculate
    // (to produce the rows) and then force the period back to DRAFT. It gets its
    // own non-overlapping month (May) because overlapping periods are rejected.
    $empDraft = makeEmployee(SALARY);
    addPresentDays($empDraft, consecutiveDates(PER_DRAFT_START, 31));
    $draft = $payroll->createPeriod([
        'start_date' => PER_DRAFT_START,
        'end_date'   => PER_DRAFT_END,
        'pay_date'   => PER_DRAFT_END,
        'name'       => 'Remit Draft 2026',
    ], $userId);
    $draftId = (int) $draft['id'];
    $payroll->calculate($draftId, $userId);
    Database::execute(
        "UPDATE payroll_periods SET status = 'DRAFT', finalized_at = NULL, approved_at = NULL WHERE id = :id",
        ['id' => $draftId]
    );
    checkSame('the control period is forced back to DRAFT', 'DRAFT',
        (string) (Database::scalar('SELECT status FROM payroll_periods WHERE id = :id', ['id' => $draftId]) ?? ''));
    $draftPayroll = payrollRowId($draftId, $empDraft);
    check('the draft period also has statutory rows', (int) (Database::scalar(
        'SELECT COUNT(*) FROM payroll_statutory WHERE payroll_id = :id', ['id' => $draftPayroll]
    ) ?? 0) === 4);


    // -----------------------------------------------------------------------
    heading('3. The contribution register only reports locked periods');
    // -----------------------------------------------------------------------
    // PayrollService::calculate() processes every active employee, so the June
    // period carries a row per seeded employee plus our fixture. We therefore
    // assert per-employee (empA) and against the DRAFT control (empDraft),
    // which is independent of how many employees the seed contains.
    $empA_rows = $reports->statutoryContributions(['employee_id' => $empA]);
    checkSame("empA's locked register has one row per statutory code", 4, $empA_rows['total'],
        sprintf('rows: %d', $empA_rows['total']));
    $agencies = array_values(array_unique(array_column($empA_rows['items'], 'agency_code')));
    sort($agencies);
    checkSame('the four codes map to the four filing agencies',
        ['BIR_WITHHOLDING', 'PAGIBIG', 'PHILHEALTH', 'SSS'], $agencies);
    check('every reported row is tagged with a filing agency',
        count(array_filter(array_column($empA_rows['items'], 'agency_code'), static fn ($v) => $v !== null)) === 4);

    // The DRAFT exclusion, proven directly: empDraft has statutory rows in the
    // database (verified above) yet contributes zero locked register rows. If
    // drafts were treated as evidence this would be 4, not 0.
    $draftEmpOnly = $reports->statutoryContributions(['employee_id' => $empDraft]);
    checkSame('the draft-only employee contributes no locked rows', 0, $draftEmpOnly['total']);

    // Filter by agency (SSS) — expands to the SSS code only, scoped to empA.
    $sssOnly = $reports->statutoryContributions(['agency_code' => 'SSS', 'employee_id' => $empA]);
    checkSame('an agency filter narrows to that agency code', 1, $sssOnly['total']);
    checkSame('the filtered row is the SSS line', 'SSS', (string) ($sssOnly['items'][0]['code'] ?? ''));
    checkSame('the filtered row is tagged with the SSS agency', 'SSS', (string) ($sssOnly['items'][0]['agency_code'] ?? ''));

    // Filter by code directly.
    $taxOnly = $reports->statutoryContributions(['code' => 'WITHHOLDING_TAX', 'employee_id' => $empA]);
    checkSame('a code filter narrows to that code', 1, $taxOnly['total']);
    checkSame('the tax row files under BIR_WITHHOLDING', 'BIR_WITHHOLDING',
        (string) ($taxOnly['items'][0]['agency_code'] ?? ''));

    // Date window: a window that excludes June returns nothing for empA.
    $outside = $reports->statutoryContributions(['employee_id' => $empA, 'date_from' => '2030-01-01', 'date_to' => '2030-12-31']);
    checkSame('a window outside the locked periods returns nothing', 0, $outside['total']);

    // Pagination caps the page but keeps the true total (empA has 4 rows).
    $paged = $reports->statutoryContributions(['employee_id' => $empA], 1, 2);
    check('pagination caps the page but keeps the true total', count($paged['items']) === 2 && $paged['total'] === 4,
        sprintf('items: %d, total: %d', count($paged['items']), $paged['total']));


    // -----------------------------------------------------------------------
    heading('4. Filing an SSS remittance snapshots the underlying rows');
    // -----------------------------------------------------------------------
    // The authoritative expectation is the sum of the SSS payroll_statutory rows
    // in the locked June period — the remittance must reconcile to this, whatever
    // the employee count. This is the "validate against existing payroll
    // records" requirement.
    $sssSource = Database::selectOne(
        "SELECT COALESCE(SUM(ps.employee_amount), 0) AS ee,
                COALESCE(SUM(ps.employer_amount), 0) AS er,
                COALESCE(SUM(ps.extra_amount), 0)    AS ex,
                COUNT(DISTINCT p.employee_id)        AS emp_count
           FROM payroll_statutory ps
           JOIN payroll p ON p.id = ps.payroll_id
           JOIN payroll_periods pp ON pp.id = p.payroll_period_id
          WHERE pp.id = :pid AND ps.code = 'SSS'",
        ['pid' => $finalA['period']]
    ) ?? ['ee' => 0, 'er' => 0, 'ex' => 0, 'emp_count' => 0];
    $expEe = round((float) $sssSource['ee'], 2);
    $expEr = round((float) $sssSource['er'], 2);
    $expEx = round((float) $sssSource['ex'], 2);
    $expCount = (int) $sssSource['emp_count'];

    $remit = $remitSvc->generate([
        'agency_code'  => 'SSS',
        'period_start' => PER_A_START,
        'period_end'   => PER_A_END,
        'due_date'     => '2026-07-30',
    ], $userId);

    checkSame('the filed remittance starts OPEN', 'OPEN', (string) $remit['status']);
    checkSame('the remittance counts every contributing employee', $expCount, (int) $remit['employee_count']);
    checkMoney('the employee total reconciles to the SSS employee shares', $expEe, (float) $remit['total_employee']);
    checkMoney('the employer total reconciles to the SSS employer shares', $expEr, (float) $remit['total_employer']);
    checkMoney('the extra total reconciles to the SSS EC amounts', $expEx, (float) $remit['total_extra']);
    checkMoney('the grand total is employee + employer + extra', round($expEe + $expEr + $expEx, 2), (float) $remit['total_amount']);
    $remitId = (int) $remit['id'];
    checkSame('generating a remittance is audit-logged', 1, remittanceAuditCount('STATUTORY_REMITTANCE_GENERATED', $remitId));

    // The remittance register report lists exactly what the service committed.
    $register = $reports->statutoryRemittances([]);
    checkSame('the register lists the one filed remittance', 1, count($register));
    checkSame('the register row matches the filed id', $remitId, (int) ($register[0]['id'] ?? 0));
    checkMoney('the register total matches the filed total', round($expEe + $expEr + $expEx, 2), (float) ($register[0]['total_amount'] ?? 0));
    checkSame('the register status matches', 'OPEN', (string) ($register[0]['status'] ?? ''));

    // Register filters.
    $regSss = $reports->statutoryRemittances(['agency_code' => 'SSS']);
    checkSame('an agency filter narrows the register', 1, count($regSss));
    $regPhil = $reports->statutoryRemittances(['agency_code' => 'PHILHEALTH']);
    checkSame('a different agency filter empties the register', 0, count($regPhil));
    $regOpen = $reports->statutoryRemittances(['status' => 'OPEN']);
    checkSame('a status filter matches the OPEN remittance', 1, count($regOpen));
    $regPaid = $reports->statutoryRemittances(['status' => 'PAID']);
    checkSame('no PAID remittance exists yet', 0, count($regPaid));


    // -----------------------------------------------------------------------
    heading('5. The per-agency / per-month summary reconciles to the register');
    // -----------------------------------------------------------------------
    // Scope to the fixture's own month. statutorySummary() aggregates over every
    // locked period, and the test database may hold unrelated locked payroll
    // history (e.g. the seeded Aug/Sep sample). The assertion is about "one row
    // per agency for the month", so filter to the June fixture window.
    $summary = $reports->statutorySummary(['date_from' => PER_A_START, 'date_to' => PER_A_END]);
    checkSame('the summary has one row per agency for the month', 4, count($summary),
        sprintf('rows: %d', count($summary)));

    $sssSummary = null;
    foreach ($summary as $row) {
        if ((string) $row['agency_code'] === 'SSS') {
            $sssSummary = $row;
        }
    }
    check('the summary has an SSS row', $sssSummary !== null);
    if ($sssSummary !== null) {
        checkSame('the SSS summary is labelled June 2026', '2026-06', (string) $sssSummary['period_label']);
        checkMoney('the SSS summary employee total matches the source rows', $expEe, (float) $sssSummary['total_employee']);
        checkMoney('the SSS summary employer total matches the source rows', $expEr, (float) $sssSummary['total_employer']);
        checkMoney('the SSS summary extra total matches the source rows', $expEx, (float) $sssSummary['total_extra']);
        checkMoney('the SSS summary grand total matches the filed remittance', round($expEe + $expEr + $expEx, 2), (float) $sssSummary['total_amount']);
    }

    // A summary scoped to one agency (and the fixture month) returns only that agency.
    $sssSummaryOnly = $reports->statutorySummary([
        'agency_code' => 'SSS',
        'date_from'   => PER_A_START,
        'date_to'     => PER_A_END,
    ]);
    checkSame('an agency filter narrows the summary to one row', 1, count($sssSummaryOnly));
    checkSame('the narrowed summary is the SSS agency', 'SSS', (string) ($sssSummaryOnly[0]['agency_code'] ?? ''));

    // -----------------------------------------------------------------------
    heading('6. The report and the remittance service agree on the agency map');
    // -----------------------------------------------------------------------
    $mapAgrees = true;
    foreach (StatutoryRemittanceService::AGENCIES as $agencyCode => $meta) {
        $rows = $reports->statutoryContributions(['agency_code' => $agencyCode]);
        foreach ($rows['items'] as $item) {
            if ((string) $item['agency_code'] !== $agencyCode) {
                $mapAgrees = false;
            }
        }
    }
    check('every code the report tags belongs to the agency that files it', $mapAgrees);

    // An unknown agency matches nothing, never everything.
    $unknown = $reports->statutoryContributions(['agency_code' => 'NOPE']);
    checkSame('an unknown agency filter returns no rows', 0, $unknown['total']);


    // -----------------------------------------------------------------------
    heading('7. The OPEN -> SUBMITTED -> PAID gate is honoured');
    // -----------------------------------------------------------------------
    // Cannot pay straight from OPEN: submit must come first.
    $payFromOpen = false;
    try {
        $remitSvc->pay($remitId, ['paid_reference' => 'OR-1', 'paid_date' => '2026-07-20'], $userId);
    } catch (ValidationException $e) {
        $payFromOpen = array_key_exists('status', $e->errors());
    }
    check('a remittance cannot be paid before it is filed', $payFromOpen);

    $submitted = $remitSvc->submit($remitId, ['filing_reference' => 'SSS-RS-2026-06'], $userId);
    checkSame('filing moves the remittance to SUBMITTED', 'SUBMITTED', (string) $submitted['status']);

    // Paid requires a reference and a date, and the date cannot be in the future.
    $payNoRef = false;
    try {
        $remitSvc->pay($remitId, ['paid_date' => '2026-07-20'], $userId);
    } catch (ValidationException $e) {
        $payNoRef = array_key_exists('paid_reference', $e->errors());
    }
    check('marking paid requires a payment reference', $payNoRef);

    $futureDate = (new DateTimeImmutable('tomorrow'))->format('Y-m-d');
    $payFuture = false;
    try {
        $remitSvc->pay($remitId, ['paid_reference' => 'OR-FUTURE', 'paid_date' => $futureDate], $userId);
    } catch (ValidationException $e) {
        $payFuture = array_key_exists('paid_date', $e->errors());
    }
    check('a payment date cannot be in the future', $payFuture);

    $paid = $remitSvc->pay($remitId, ['paid_reference' => 'OR-2026-7788', 'paid_date' => '2026-07-20'], $userId);
    checkSame('a confirmed payment marks the remittance PAID', 'PAID', (string) $paid['status']);
    check('the payment reference is stored', (string) $paid['paid_reference'] === 'OR-2026-7788');

    // The register report now reflects PAID.
    $regAfter = $reports->statutoryRemittances(['status' => 'PAID']);
    checkSame('the register now lists the PAID remittance', 1, count($regAfter));
    checkSame('the register shows the stored payment reference', 'OR-2026-7788',
        (string) ($regAfter[0]['paid_reference'] ?? ''));

    // A PAID remittance is frozen: it cannot be regenerated.
    $regenerateFrozen = false;
    try {
        $remitSvc->generate([
            'agency_code'  => 'SSS',
            'period_start' => PER_A_START,
            'period_end'   => PER_A_END,
        ], $userId);
    } catch (ValidationException $e) {
        $regenerateFrozen = true;
    }
    check('a PAID remittance cannot be regenerated', $regenerateFrozen);
} catch (Throwable $e) {
    check('no unexpected exception', false, get_class($e) . ': ' . $e->getMessage() . ' @ ' . $e->getFile() . ':' . $e->getLine());
} finally {
    // Every fixture created above (employees, attendance, periods, payroll
    // rows, statutory rows and the remittance register) is rolled back here:
    // nothing is ever committed.
    Database::rollBack();
}

echo "\n", $passed, ' passed, ', $failed, " failed\n";

if ($failures !== []) {
    echo "\nFailures:\n";
    foreach ($failures as $failure) {
        echo '  - ', $failure, "\n";
    }
    echo "\nSTATUTORY REMITTANCES & REPORTS: FAILED\n";
    exit(1);
}

echo "\nSTATUTORY REMITTANCES & REPORTS: every check passed\n";
exit(0);

