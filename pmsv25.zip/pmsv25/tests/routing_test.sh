#!/usr/bin/env bash
#
# Entry point and navigation test.
#
# Verifies the thing the browser cares about: that http://localhost/pms/ opens
# the sign-in page, that its assets load, and that every relative link on every
# page resolves to a file that actually exists once the page's <base href> is
# applied. That last part is what stops a page in a subfolder from linking to a
# 404 the moment the base path changes.
#
# Usage: bash tests/routing_test.sh [site_root]
#   site_root defaults to http://localhost/pms

SITE="${1:-http://localhost/pms}"
ROOT_DIR="$(cd "$(dirname "$0")/.." && pwd)"

PASS=0
FAIL=0

ok()  { echo "  PASS  $1"; PASS=$((PASS + 1)); }
bad() { echo "  FAIL  $1"; echo "        $2"; FAIL=$((FAIL + 1)); }

status() { curl -s -o /dev/null -w '%{http_code}' --max-time 10 "$1"; }
body()   { curl -s --max-time 10 "$1"; }

echo "=============================================="
echo " ENTRY POINT & NAVIGATION TEST"
echo "=============================================="
echo "Site root: $SITE"
echo

echo "--- The front door -----------------------------------------"
for url in "$SITE/" "$SITE/index" "$SITE/index.html"; do
  code=$(status "$url")
  page=$(body "$url")

  if [ "$code" = "200" ] && echo "$page" | grep -q 'id="login-form"'; then
    ok "$url  serves the sign-in page"
  else
    bad "$url" "HTTP $code; login form count: $(echo "$page" | grep -c 'login-form')"
  fi
done

echo
echo "--- Assets load from the root page -------------------------"
for asset in /frontend/css/app.css /frontend/js/api.js /frontend/js/app.js /frontend/js/charts.js; do
  code=$(status "$SITE$asset")
  if [ "$code" = "200" ]; then ok "GET $asset"; else bad "GET $asset" "HTTP $code"; fi
done

echo
echo "--- Sign-in page wiring ------------------------------------"
PAGE=$(body "$SITE/")

echo "$PAGE" | grep -q '<base href="frontend/">' \
  && ok "root page declares a relative <base> into the frontend folder" \
  || bad "root <base>" 'expected <base href="frontend/">'

echo "$PAGE" | grep -q 'Api.setSession' \
  && ok "sign-in stores the session through the API client" \
  || bad "session storage" "Api.setSession not used"

echo "$PAGE" | grep -q "location.replace('dashboard.html')" \
  && ok "sign-in forwards to dashboard.html" \
  || bad "post-login redirect" "no forward to dashboard.html"

# A relative <base> is what makes the project portable between /pms/ and /.
echo "$PAGE" | grep -qE '<base href="/(pms|app)' \
  && bad "base path is hard-coded" "a fixed path breaks on another deployment" \
  || ok "no absolute deployment path is baked into the page"
echo
echo "--- Every relative link resolves (the subfolder 404 fix) ---"

# resolve <page_url> <base_href> <link>
#
# Applies the page's <base href> to a relative link exactly as a browser would,
# so the real resolution is tested rather than assumed.
resolve() {
  local page="$1" base="$2" link="$3"
  local dir answer

  # Directory of the page: /pms/frontend/employees/index.html -> .../employees/
  dir=$(echo "$page" | sed 's|/[^/]*$|/|')

  case "$base" in
    "")   answer="$dir$link" ;;
    /*)   answer="$base$link" ;;
    */)   answer="${dir}${base}${link}" ;;
    *)    answer="${dir}${base}$link" ;;
  esac

  # Collapse "a/b/../" segments.
  while echo "$answer" | grep -q '/[^/]*/\.\./'; do
    answer=$(echo "$answer" | sed 's|/[^/]*/\.\./|/|')
  done

  echo "$answer"
}

PAGES="index.html $(cd "$ROOT_DIR" && find frontend -name '*.html' | sort)"

for rel in $PAGES; do
  file="$ROOT_DIR/$rel"

  base=$(grep -o '<base href="[^"]*"' "$file" | head -1 | sed 's/.*href="//; s/"$//')
  page_url="$SITE/$rel"

  # Strip <base> itself, then collect hrefs from the page body. The base tag
  # also has an href attribute and would otherwise be tested as a link.
  #
  # Links assembled by string concatenation in JavaScript are dropped here, on
  # the whole line. Filtering inside the loop would be too late: the unquoted
  # loop variable word-splits on spaces and turns
  # "payroll/payslips.html?id=' + row.id + '" into a bogus 'row.id' path.
  links=$(sed 's|<base[^>]*>||g' "$file" \
    | grep -o 'href="[^"]*"' \
    | sed 's/href="//; s/"$//' \
    | grep -vE '^(https?:|mailto:|data:|//|#)' \
    | grep -vE '\.css$' \
    | grep -vE "['\"+<>\$()]" \
    | sort -u)

  for link in $links; do
    case "$link" in *\'*|*+*|*'<'*) continue ;; esac

    target=$(resolve "$page_url" "$base" "$link")
    code=$(status "$target")

    if [ "$code" = "200" ]; then
      ok "$rel  '$link' -> $target"
    else
      bad "$rel  '$link' -> $target" "HTTP $code (base='$base')"
    fi
  done
done

echo
echo "--- Sidebar navigation resolves from every page ------------"
#
# This is the bug the <base> tags exist to prevent. The sidebar builds its links
# in app.js as frontend-root-relative paths (dashboard.html, employees/index.html).
# Without a <base> the browser resolves them against the *current directory*, so
# from /pms/frontend/employees/index.html "Dashboard" became
# /pms/frontend/employees/dashboard.html — a 404. Every nav target is resolved
# here against each page's own base to prove it lands on a real file.
NAV_HREFS=$(grep -o "href: '[^']*'" "$ROOT_DIR/frontend/js/app.js" \
  | sed "s/href: '//; s/'$//" | sort -u)

for rel in $PAGES; do
  file="$ROOT_DIR/$rel"
  base=$(grep -o '<base href="[^"]*"' "$file" | head -1 | sed 's/.*href="//; s/"$//')
  page_url="$SITE/$rel"

  for link in $NAV_HREFS; do
    target=$(resolve "$page_url" "$base" "$link")
    code=$(status "$target")

    if [ "$code" = "200" ]; then
      ok "$rel  nav '$link' -> $target"
    else
      bad "$rel  nav '$link' -> $target" "HTTP $code (base='$base')"
    fi
  done
done

echo
echo "--- Source and configuration are unreachable ---------------"
for guarded in \
    /database/main.sql \
    /api/config/config.php \
    /api/core/Auth.php \
    /tests/api_test.sh \
    /tests/routing_test.sh \
    /README.md \
    '/storage/logs/' ; do
  code=$(status "$SITE$guarded")

  if [ "$code" = "403" ] || [ "$code" = "404" ]; then
    ok "blocked  $guarded  (HTTP $code)"
  else
    bad "blocked $guarded" "expected 403/404, got HTTP $code"
  fi
done

echo
echo "--- Missing pages give a real 404 --------------------------"
code=$(status "$SITE/no-such-page")
if [ "$code" = "404" ]; then
  ok "unknown page returns 404"
else
  bad "unknown page" "expected 404, got $code"
fi

echo
echo "=============================================="
echo " RESULT: $PASS passed, $FAIL failed"
echo "=============================================="

[ "$FAIL" -eq 0 ] || exit 1
