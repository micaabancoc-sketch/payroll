<?php
declare(strict_types=1);

/**
 * 13th-Month Pay calculation tests (database-backed, self-cleaning).
 *
 * Boots the app autoloader directly (not api/bootstrap.php, which dispatches an
 * HTTP request and exits). All fixtures are created inside ONE outer
 * transaction and rolled back when the script finishes, so no test data ever
 * survives. The module tables must exist first:
 *
 *   php database/migrate_13th_month.php
 *
 * Usage:
 *   php tests/thirteenth_pay_test.php
 *
 * Exit code 0 = all checks passed, 1 = at least one check failed.
 */

spl_autoload_register(static function (string $class): void {
    $prefix = 'App\\';
    if (!str_starts_with($class, $prefix)) {
        return;
    }

    $relative = substr($class, strlen($prefix));
    $parts    = explode('\\', $relative);
    $file     = array_pop($parts);
    $subDir   = $parts === [] ? '' : strtolower(implode('/', $parts)) . '/';

    $path = __DIR__ . '/../api/' . $subDir . strtolower($file) . '.php';
    if (is_file($path)) {
        require_once $path;
    }
});

require __DIR__ . '/../api/config/config.php';

date_default_timezone_set('Asia/Manila');

use App\Core\Database;
use App\Core\ValidationException;
use App\Services\PayrollEngine;
use App\Services\ThirteenthPayService;

$checks   = 0;
$failures = [];

function check(bool $condition, string $label, string $detail = ''): void
{
    global $checks, $failures;
    $checks++;

    if ($condition) {
        echo 'ok   ', $label, "\n";
        return;
    }

    $failures[] = $detail === '' ? $label : $label . ' — ' . $detail;
    echo 'FAIL ', $label, $detail === '' ? '' : ' — ' . $detail, "\n";
}

// ---------------------------------------------------------------------------
// Fixture helpers (all writes happen inside the outer transaction below).
// ---------------------------------------------------------------------------

function makeEmployee(array $over = []): int
{
    return Database::insert('employees', array_merge([
        'employee_number'  => 'T13-' . strtoupper(substr(bin2hex(random_bytes(6)), 0, 10)),
        'first_name'       => 'T13',
        'last_name'        => 'Test',
        'gender'           => 'OTHER',
        'date_hired'       => '2026-01-01',
        'employment_type'  => 'FULL_TIME',
        'salary_type'      => 'MONTHLY',
        'basic_salary'     => 20000.00,
        'status'           => 'ACTIVE',
    ], $over));
}

function makePeriod(string $code, string $start, string $end, string $status, int $userId): int
{
    return Database::insert('payroll_periods', [
        'code'       => $code,
        'name'       => 'T13 ' . $code,
        'start_date' => $start,
        'end_date'   => $end,
        'pay_date'   => $end,
        'status'     => $status,
        'created_by' => $userId,
    ]);
}

function makePayroll(int $periodId, int $employeeId, float $basic, float $gross, array $snapshot, float $net = 0.0): int
{
    return Database::insert('payroll', [
        'payroll_period_id'    => $periodId,
        'employee_id'          => $employeeId,
        'basic_pay'            => round($basic, 2),
        'gross_pay'            => round($gross, 2),
        'net_pay'              => round($net, 2),
        'is_locked'            => 1,
        'calculation_snapshot' => json_encode($snapshot, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
        'calculated_at'        => date('Y-m-d H:i:s'),
    ]);
}

function makeItem(int $payrollId, string $code, string $name, float $amount): void
{
    Database::insert('payroll_items', [
        'payroll_id' => $payrollId,
        'item_type'  => 'EARNING',
        'code'       => $code,
        'name'       => $name,
        'amount'     => round($amount, 2),
    ]);
}

/** Snapshot shape produced by engines BEFORE the holiday-pay separation fix. */
function legacySnapshot(): array
{
    return [
        'settings'        => ['payroll.working_days_per_month' => 22.0],
        'daily_rate'      => 1000.0,
        'hourly_rate'     => 125.0,
        'attendance_rows' => 1,
        'period'          => ['start' => '2026-01-01', 'end' => '2026-12-31'],
    ];
}

/** Snapshot shape produced by the fixed engine (accounting marker present). */
function fixedSnapshot(): array
{
    return legacySnapshot() + ['accounting' => ['holiday_pay_included_in_basic' => false]];
}

// ---------------------------------------------------------------------------
// Scenario
// ---------------------------------------------------------------------------

Database::beginTransaction();

try {
    $userId = (int) (Database::scalar(
        "SELECT id FROM users WHERE username = 'admin' AND deleted_at IS NULL LIMIT 1"
    ) ?? 0);

    if ($userId === 0) {
        throw new RuntimeException('admin account not found — seed the database first.');
    }

    $service = new ThirteenthPayService();
    $engine  = new PayrollEngine();

    // --- Case A: engine-level holiday separation -----------------------------
    $empEngine   = makeEmployee(['basic_salary' => 30000.00]);
    $holidayDate = '2026-10-30';

    Database::insert('holidays', [
        'name'          => 'T13 Test Holiday ' . $holidayDate,
        'holiday_date'  => $holidayDate,
        'holiday_type'  => 'REGULAR',
        'is_paid'       => 1,
        'is_recurring'  => 0,
        'status'        => 'ACTIVE',
    ]);
    Database::insert('attendance', [
        'employee_id'     => $empEngine,
        'attendance_date' => $holidayDate,
        'status'          => 'HOLIDAY',
        'is_holiday'      => 1,
        'source'          => 'MANUAL',
    ]);

    $empRow = Database::selectOne('SELECT * FROM employees WHERE id = :id', ['id' => $empEngine]);
    if ($empRow !== null) {
        $calc = $engine->calculateEmployee($empRow, $holidayDate, $holidayDate);
        $expectedHoliday = round(30000.00 / 22.0, 2);

        check(
            abs((float) $calc['holiday_pay'] - $expectedHoliday) < 0.01,
            'engine: paid holiday is paid',
            sprintf('holiday_pay=%.2f expected≈%.2f', (float) $calc['holiday_pay'], $expectedHoliday)
        );
        check(
            (float) $calc['basic_pay'] === 0.0,
            'engine: holiday is NOT embedded in basic_pay',
            sprintf('basic_pay=%.2f', (float) $calc['basic_pay'])
        );
        check(
            abs((float) $calc['gross_pay'] - (float) $calc['holiday_pay']) < 0.01,
            'engine: gross counts holiday exactly once',
            sprintf('gross=%.2f holiday=%.2f', (float) $calc['gross_pay'], (float) $calc['holiday_pay'])
        );
        check(
            ($calc['snapshot']['accounting']['holiday_pay_included_in_basic'] ?? null) === false,
            'engine: snapshot accounting marker written for new rows'
        );
    } else {
        check(false, 'engine: fixture employee row loadable');
    }

    // --- Fixtures for the annual computation --------------------------------
    // 1. 360,000.00 basic -> 30,000.00
    $e360 = makeEmployee(['basic_salary' => 30000.00]);
    $p360 = makePeriod('T13-360', '2026-01-01', '2026-12-31', 'FINALIZED', $userId);
    makePayroll($p360, $e360, 360000.00, 360000.00, fixedSnapshot());

    // 2. 180,000.00 basic -> 15,000.00
    $e180 = makeEmployee();
    $p180 = makePeriod('T13-180', '2026-01-01', '2026-12-31', 'FINALIZED', $userId);
    makePayroll($p180, $e180, 180000.00, 180000.00, fixedSnapshot());

    // 3. Overtime must not increase the basic total (60000 basic + 20000 OT).
    $eOt = makeEmployee(['basic_salary' => 60000.00]);
    $pOt = makePeriod('T13-OT', '2026-02-01', '2026-02-28', 'PAID', $userId);
    $prOt = makePayroll($pOt, $eOt, 60000.00, 80000.00, fixedSnapshot(), 78000.00);
    makeItem($prOt, 'OT', 'Overtime', 20000.00);

    // 4. Legacy holiday contamination: basic_pay 70000 includes 5000 holiday.
    $eHol = makeEmployee();
    $pHol = makePeriod('T13-HOL', '2026-03-01', '2026-03-31', 'FINALIZED', $userId);
    $prHol = makePayroll($pHol, $eHol, 70000.00, 70000.00, legacySnapshot());
    makeItem($prHol, 'HOLIDAY', 'Holiday Pay', 5000.00);

    // 5. New-style row: basic_pay 60000 is clean; a separate 5000 HOLIDAY item
    //    must NOT be subtracted again.
    $eHolN = makeEmployee();
    $pHolN = makePeriod('T13-HOLN', '2026-04-01', '2026-04-30', 'FINALIZED', $userId);
    $prHolN = makePayroll($pHolN, $eHolN, 60000.00, 65000.00, fixedSnapshot());
    makeItem($prHolN, 'HOLIDAY', 'Holiday Pay', 5000.00);

    // 6. Salary change: 50000 (May) + 70000 (July) = 120000 -> 10000.
    $eSal = makeEmployee();
    $pSal1 = makePeriod('T13-SAL1', '2026-05-01', '2026-05-31', 'FINALIZED', $userId);
    makePayroll($pSal1, $eSal, 50000.00, 50000.00, fixedSnapshot());
    $pSal2 = makePeriod('T13-SAL2', '2026-07-01', '2026-07-31', 'FINALIZED', $userId);
    makePayroll($pSal2, $eSal, 70000.00, 70000.00, fixedSnapshot());

    // 7. Part-year employee: 90000 -> 7500 (proportional, actual earnings only).
    $ePart = makeEmployee();
    $pPart = makePeriod('T13-PART', '2026-06-01', '2026-06-30', 'FINALIZED', $userId);
    makePayroll($pPart, $ePart, 90000.00, 90000.00, fixedSnapshot());

    // 8. Draft / recalculable periods must not contaminate the result.
    $eDraft = makeEmployee();
    $pAppr = makePeriod('T13-APPR', '2026-08-01', '2026-08-31', 'APPROVED', $userId);
    makePayroll($pAppr, $eDraft, 100000.00, 100000.00, fixedSnapshot());
    $pDraft = makePeriod('T13-DRAFTY', '2026-09-01', '2026-09-30', 'DRAFT', $userId);
    makePayroll($pDraft, $eDraft, 50000.00, 50000.00, fixedSnapshot());

    // 9. Calendar-year boundary: a period crossing 31 Dec / 1 Jan.
    $eCross = makeEmployee();
    $pCross = makePeriod('T13-CROSS', '2026-12-16', '2027-01-15', 'FINALIZED', $userId);
    makePayroll($pCross, $eCross, 80000.00, 80000.00, fixedSnapshot());

    $crossBlocked = false;
    try {
        $service->generate(2026, $userId);
    } catch (ValidationException $e) {
        $message = (string) ($e->errors()['calendar_year'] ?? '');
        $crossBlocked = str_contains($message, 'cross the calendar-year boundary');
        check(
            $crossBlocked,
            'service: crossing period blocks generation instead of guessing',
            $message
        );
    }

    if (!$crossBlocked) {
        check(false, 'service: crossing period must raise ValidationException');
    }

    // Remove the crossing period; the rest of the year is fully allocatable.
    Database::delete('payroll', ['payroll_period_id' => $pCross]);
    Database::delete('payroll_periods', ['id' => $pCross]);

    // --- Generate and reconcile every figure ---
    $result  = $service->generate(2026, $userId);
    $records = [];
    foreach ($result['records'] as $r) {
        $records[(int) $r['employee_id']] = $r;
    }

    // Manual sums come straight from the fixture rows above (each basic_pay is
    // the recorded eligible basic earned in that period; holiday is subtracted
    // only for the legacy row; overtime/gross is never used).
    $expectations = [
        $e360  => [360000.00, 30000.00],
        $e180  => [180000.00, 15000.00],
        $eOt   => [60000.00, 5000.00],
        $eHol  => [65000.00, 5416.67],
        $eHolN => [60000.00, 5000.00],
        $eSal  => [120000.00, 10000.00],
        $ePart => [90000.00, 7500.00],
    ];

    foreach ($expectations as $empId => [$expectedGross, $expected13th]) {
        check(
            isset($records[$empId]),
            "employee {$empId}: record generated for " . sprintf('%.2f basic', $expectedGross)
        );

        if (!isset($records[$empId])) {
            continue;
        }

        check(
            abs((float) $records[$empId]['gross_total'] - $expectedGross) < 0.005,
            "employee {$empId}: gross_total is the eligible basic total",
            sprintf('got %.2f expected %.2f', (float) $records[$empId]['gross_total'], $expectedGross)
        );
        check(
            abs((float) $records[$empId]['thirteenth_pay'] - $expected13th) < 0.005,
            "employee {$empId}: 13th pay = total / 12 rounded to 2dp",
            sprintf('got %.2f expected %.2f', (float) $records[$empId]['thirteenth_pay'], $expected13th)
        );
    }

    check(
        !isset($records[$eDraft]),
        'employee with only APPROVED/DRAFT periods gets NO record'
    );

    check(
        ($result['reconciliation']['legacy_holiday_rows_corrected'] ?? 0) === 1,
        'reconciliation: exactly one legacy holiday row corrected',
        json_encode($result['reconciliation'] ?? null)
    );
    check(
        abs(($result['reconciliation']['legacy_holiday_adjustment'] ?? 0.0) - 5000.00) < 0.005,
        'reconciliation: legacy holiday adjustment is the itemised amount'
    );

    // --- 10. Repeated generate: no duplicates, no overwrite past DRAFT -------
    $second  = $service->generate(2026, $userId);
    $secondByEmp = [];
    foreach ($second['records'] as $r) {
        $secondByEmp[(int) $r['employee_id']] = $r;
    }
    check(
        count($second['records']) === count($result['records']),
        'repeated generate: record count unchanged (no duplicates)'
    );
    check(
        isset($secondByEmp[$e360]) && (string) $secondByEmp[$e360]['status'] === 'DRAFT'
        && abs((float) $secondByEmp[$e360]['thirteenth_pay'] - 30000.00) < 0.005,
        'repeated generate: DRAFT rows refresh in place with the same amount'
    );

    // Walk the full workflow, then prove a later Generate cannot touch PAID.
    $service->submitForApproval(2026, $userId);
    $service->approve(2026, $userId);
    $released = $service->releaseApproved(2026, $userId);
    // Compare against the records Generate actually produced, not just the
    // fixture subset in $expectations. The test database may hold unrelated
    // locked 2026 payroll history (e.g. the seeded Aug/Sep sample), and
    // generate() correctly includes every eligible employee for the year. The
    // invariant under test is "every eligible record was approved and released",
    // so the expected count is the full generated set.
    check(
        ($released['released'] ?? 0) === count($result['records']),
        'release: every eligible record approved and released',
        json_encode($released['released'] ?? null)
    );

    $after = $service->generate(2026, $userId);
    $afterByEmp = [];
    foreach ($after['records'] as $r) {
        $afterByEmp[(int) $r['employee_id']] = $r;
    }
    check(
        isset($afterByEmp[$e360])
        && (string) $afterByEmp[$e360]['status'] === 'PAID'
        && abs((float) $afterByEmp[$e360]['thirteenth_pay'] - 30000.00) < 0.005,
        'generate after release: PAID records are not overwritten'
    );
    check(
        (int) (Database::scalar(
            'SELECT COUNT(*) FROM thirteenth_pays WHERE employee_id = :e AND calendar_year = 2026',
            ['e' => $e360]
        ) ?? 0) === 1,
        'no duplicate thirteenth_pays row per employee/year after repeated generate'
    );

    // --- 11. Release -> Payment ledger (unique row, partial, no overpay) -----
    $payId = (int) $records[$e360]['id'];

    $ledger = Database::selectOne(
        'SELECT amount, payment_status FROM thirteenth_payments WHERE thirteenth_pay_id = :id',
        ['id' => $payId]
    );
    check(
        $ledger !== null && (string) $ledger['payment_status'] === 'PENDING'
        && abs((float) $ledger['amount']) < 0.005,
        'release: opens a PENDING ledger row with 0.00 disbursed',
        json_encode($ledger)
    );

    $unpaid = [];
    foreach ($service->unpaidReleased(2026)['records'] as $r) {
        $unpaid[(int) $r['employee_id']] = $r;
    }
    check(
        isset($unpaid[$e360]) && abs((float) $unpaid[$e360]['balance_due'] - 30000.00) < 0.005,
        'unpaid: released-but-unpaid row lists the full balance',
        json_encode($unpaid[$e360] ?? null)
    );
    check(
        isset($unpaid[$e360]) && (string) ($unpaid[$e360]['payment_status'] ?? '') === 'PENDING',
        'unpaid: a released-but-untouched row reports a PENDING payment status',
        json_encode($unpaid[$e360] ?? null)
    );

    // Partial payment: the ledger row accumulates instead of a second INSERT
    // (thirteenth_pay_id is UNIQUE, so a plain INSERT used to raise SQLSTATE 23000).
    $first = $service->recordPayment($payId, 10000.00, $userId);
    check(($first['success'] ?? false) === true, 'payment: first (partial) payment succeeds');

    $partial = [];
    foreach ($first['records'] as $r) {
        $partial[(int) $r['employee_id']] = $r;
    }
    check(
        isset($partial[$e360])
        && abs((float) $partial[$e360]['paid_total'] - 10000.00) < 0.005
        && abs((float) $partial[$e360]['balance_due'] - 20000.00) < 0.005,
        'unpaid: partial payment reduces the balance',
        json_encode($partial[$e360] ?? null)
    );
    check(
        isset($partial[$e360]) && (string) ($partial[$e360]['payment_status'] ?? '') === 'PARTIAL',
        'unpaid: a partly paid row reports a PARTIAL payment status',
        json_encode($partial[$e360] ?? null)
    );

    $ledgerPartial = Database::selectOne(
        'SELECT amount, payment_status FROM thirteenth_payments WHERE thirteenth_pay_id = :id',
        ['id' => $payId]
    );
    check(
        $ledgerPartial !== null
        && (string) $ledgerPartial['payment_status'] === 'PARTIAL'
        && abs((float) $ledgerPartial['amount'] - 10000.00) < 0.005,
        'payment: a part-payment is stored as PARTIAL, never COMPLETED',
        json_encode($ledgerPartial)
    );

    // Overpaying the remainder must be refused (the same money can never be
    // recorded twice even if the caller posts a stale/large amount).
    $overpayBlocked = false;
    try {
        $service->recordPayment($payId, 25000.00, $userId);
    } catch (ValidationException $e) {
        $overpayBlocked = str_contains((string) ($e->errors()['amount'] ?? ''), 'exceeds');
    }
    check($overpayBlocked, 'payment: amount above the remaining balance is rejected');

    // Settle the balance: the record leaves the released-but-unpaid list.
    $second = $service->recordPayment($payId, 20000.00, $userId);
    $settled = [];
    foreach ($second['records'] as $r) {
        $settled[(int) $r['employee_id']] = $r;
    }
    check(!isset($settled[$e360]), 'payment: a fully paid record leaves the unpaid list');

    check(
        (int) (Database::scalar(
            'SELECT COUNT(*) FROM thirteenth_payments WHERE thirteenth_pay_id = :id',
            ['id' => $payId]
        ) ?? 0) === 1,
        'payment: release + two payments keep exactly one ledger row (no duplicate)'
    );
    check(
        abs((float) (Database::scalar(
            'SELECT amount FROM thirteenth_payments WHERE thirteenth_pay_id = :id',
            ['id' => $payId]
        ) ?? 0) - 30000.00) < 0.005,
        'payment: accumulated ledger amount equals the 13th-month pay'
    );

    $ledgerSettled = Database::selectOne(
        'SELECT amount, payment_status FROM thirteenth_payments WHERE thirteenth_pay_id = :id',
        ['id' => $payId]
    );
    check(
        $ledgerSettled !== null
        && (string) $ledgerSettled['payment_status'] === 'COMPLETED'
        && abs((float) $ledgerSettled['amount'] - 30000.00) < 0.005,
        'payment: only the payment that settles the balance flips the row to COMPLETED',
        json_encode($ledgerSettled)
    );

    // --- 11b. Documented example: 10,000.00 due, 4,000.00 then 6,000.00 -----
    // $eSal earned exactly 120,000.00 -> 13th-month pay of 10,000.00. It is
    // released alongside every other record, so it is PENDING with 0.00 paid.
    $salPayId  = (int) $records[$eSal]['id'];
    $salLedger = Database::selectOne(
        'SELECT amount, payment_status FROM thirteenth_payments WHERE thirteenth_pay_id = :id',
        ['id' => $salPayId]
    );
    check(
        $salLedger !== null
        && (string) $salLedger['payment_status'] === 'PENDING'
        && abs((float) $salLedger['amount']) < 0.005,
        'example: a 10,000.00 record is released PENDING with 0.00 paid',
        json_encode($salLedger)
    );

    $ex1 = $service->recordPayment($salPayId, 4000.00, $userId);
    $exRows = [];
    foreach ($ex1['records'] as $r) {
        $exRows[(int) $r['employee_id']] = $r;
    }
    check(
        isset($exRows[$eSal])
        && abs((float) $exRows[$eSal]['paid_total'] - 4000.00) < 0.005
        && abs((float) $exRows[$eSal]['balance_due'] - 6000.00) < 0.005,
        'example: paying 4,000.00 of 10,000.00 leaves a 6,000.00 balance',
        json_encode($exRows[$eSal] ?? null)
    );
    check(
        isset($exRows[$eSal]) && (string) ($exRows[$eSal]['payment_status'] ?? '') === 'PARTIAL',
        'example: the record stays in Released/Unpaid and reads PARTIAL, not COMPLETED',
        json_encode($exRows[$eSal] ?? null)
    );

    $exLedgerPartial = Database::selectOne(
        'SELECT amount, payment_status FROM thirteenth_payments WHERE thirteenth_pay_id = :id',
        ['id' => $salPayId]
    );
    check(
        $exLedgerPartial !== null
        && (string) $exLedgerPartial['payment_status'] === 'PARTIAL'
        && abs((float) $exLedgerPartial['amount'] - 4000.00) < 0.005,
        'example: the ledger holds 4,000.00 marked PARTIAL after the first payment',
        json_encode($exLedgerPartial)
    );

    // One centavo over the outstanding 6,000.00 must still be refused.
    $exOverBlocked = false;
    try {
        $service->recordPayment($salPayId, 6000.01, $userId);
    } catch (ValidationException $e) {
        $exOverBlocked = str_contains((string) ($e->errors()['amount'] ?? ''), 'exceeds');
    }
    check($exOverBlocked, 'example: 6,000.01 against a 6,000.00 balance is rejected');

    $ex2 = $service->recordPayment($salPayId, 6000.00, $userId);
    $exSettled = [];
    foreach ($ex2['records'] as $r) {
        $exSettled[(int) $r['employee_id']] = $r;
    }
    check(
        !isset($exSettled[$eSal]),
        'example: the second payment clears the balance and leaves Released/Unpaid'
    );

    $exLedgerDone = Database::selectOne(
        'SELECT amount, payment_status FROM thirteenth_payments WHERE thirteenth_pay_id = :id',
        ['id' => $salPayId]
    );
    check(
        $exLedgerDone !== null
        && (string) $exLedgerDone['payment_status'] === 'COMPLETED'
        && abs((float) $exLedgerDone['amount'] - 10000.00) < 0.005,
        'example: the ledger then reads 10,000.00 and COMPLETED',
        json_encode($exLedgerDone)
    );
    check(
        (int) (Database::scalar(
            'SELECT COUNT(*) FROM thirteenth_payments WHERE thirteenth_pay_id = :id',
            ['id' => $salPayId]
        ) ?? 0) === 1,
        'example: two payments on one record still leave exactly one ledger row'
    );

    // Only released (PAID) records may receive money.
    $draftEmp     = makeEmployee();
    $draftPayId   = Database::insert('thirteenth_pays', [
        'employee_id'    => $draftEmp,
        'calendar_year'  => 2026,
        'gross_total'    => 12000.00,
        'thirteenth_pay' => 1000.00,
        'status'         => 'DRAFT',
        'generated_by'   => $userId,
    ]);
    $notPaidBlocked = false;
    try {
        $service->recordPayment($draftPayId, 1000.00, $userId);
    } catch (ValidationException $e) {
        $notPaidBlocked = str_contains((string) ($e->errors()['pay_id'] ?? ''), 'released');
    }
    check($notPaidBlocked, 'payment: an un-released record cannot be paid');
} catch (Throwable $e) {
    check(false, 'unexpected exception', get_class($e) . ': ' . $e->getMessage() . ' @ ' . $e->getFile() . ':' . $e->getLine());
} finally {
    // The whole fixture set (employees, periods, payroll rows, items, holidays,
    // attendance, thirteenth_pays and the audit trail) rolls back here.
    Database::rollBack();
}

echo "\n{$checks} check(s), ", count($failures), " failure(s)\n";

if ($failures !== []) {
    echo "\nFailures:\n";
    foreach ($failures as $failure) {
        echo '  - ', $failure, "\n";
    }
    exit(1);
}

exit(0);