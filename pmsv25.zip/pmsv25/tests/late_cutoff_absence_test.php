<?php

declare(strict_types=1);

use App\Core\Settings;
use App\Services\AttendanceEngine;
use App\Services\AttendanceReconciler;
use App\Services\AttendanceService;
use App\Services\QrCodeService;

require dirname(__DIR__) . '/api/autoload.php';


require __DIR__ . '/db_guard.php';
pmsAssertSafeTestDatabase();

$config = require dirname(__DIR__) . '/api/config/config.php';
date_default_timezone_set((string) $config['app']['timezone']);

$base = getenv('PMS_API_BASE') ?: ($argv[1] ?? 'http://localhost/pms/api');

const REF_DATE = '2026-06-15';

$passed   = 0;
$failed   = 0;
$failures = [];

/** @var array<string, list<int>> */
$created = [
    'employees' => [],
    'users'     => [],
    'shifts'    => [],
    'schedules' => [],
    'holidays'  => [],
    'leaves'    => [],
];

// Preserved so the configurability check can be undone even after a fatal error.
$GLOBALS['originalCutoff'] = (string) Settings::get('attendance.late_cutoff_minutes', 30);

$GLOBALS['createdEmployees'] = &$created['employees'];
$GLOBALS['createdUsers']     = &$created['users'];
$GLOBALS['createdShifts']    = &$created['shifts'];
$GLOBALS['createdSchedules'] = &$created['schedules'];
$GLOBALS['createdHolidays']  = &$created['holidays'];
$GLOBALS['createdLeaves']    = &$created['leaves'];

function check(string $label, bool $ok, string $detail = ''): void
{
    global $passed, $failed, $failures;

    if ($ok) {
        $passed++;
        echo "  PASS  $label\n";
        return;
    }

    $failed++;
    $failures[] = $label;
    echo "  FAIL  $label\n";
    if ($detail !== '') {
        echo "        $detail\n";
    }
}

// ---------------------------------------------------------------------------
// Database helpers (a private connection, independent of the app's Database)
// ---------------------------------------------------------------------------

function testDb(): PDO
{
    static $pdo = null;

    if ($pdo instanceof PDO) {
        return $pdo;
    }

    $config = require dirname(__DIR__) . '/api/config/config.php';
    $db     = $config['database'];

    $pdo = new PDO(
        sprintf('mysql:host=%s;port=%d;dbname=%s;charset=utf8mb4', $db['host'], $db['port'], $db['name']),
        $db['user'],
        $db['password'],
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC]
    );

    return $pdo;
}

/** @param array<string, mixed> $data */
function insertRow(string $table, array $data): int
{
    $columns      = array_keys($data);
    $placeholders = array_map(static fn (string $c): string => ':' . $c, $columns);
    $quoted       = array_map(static fn (string $c): string => '`' . $c . '`', $columns);

    $sql  = sprintf('INSERT INTO `%s` (%s) VALUES (%s)', $table, implode(', ', $quoted), implode(', ', $placeholders));
    $stmt = testDb()->prepare($sql);
    $stmt->execute($data);

    return (int) testDb()->lastInsertId();
}

function scalarValue(string $sql, array $params = []): mixed
{
    $stmt = testDb()->prepare($sql);
    $stmt->execute($params);
    $value = $stmt->fetchColumn();

    return $value === false ? null : $value;
}

/** @return array<string, mixed>|null */
function dbRow(string $sql, array $params = []): ?array
{
    $stmt = testDb()->prepare($sql);
    $stmt->execute($params);
    $row = $stmt->fetch();

    return $row === false ? null : $row;
}

function randomSuffix(): string
{
    return strtoupper(bin2hex(random_bytes(4)));
}

// ---------------------------------------------------------------------------
// Fixtures
// ---------------------------------------------------------------------------

function roleId(string $code): int
{
    return (int) (scalarValue('SELECT id FROM roles WHERE code = :code', ['code' => $code]) ?? 0);
}

/** @param array<string, mixed> $overrides */
function newShift(array $overrides = []): int
{
    $id = insertRow('shifts', array_merge([
        'code'                 => 'CUT-' . randomSuffix(),
        'name'                 => 'Cut-off test shift',
        'start_time'           => '08:00:00',
        'end_time'             => '17:00:00',
        'is_overnight'         => 0,
        'grace_period_minutes' => 5,
        'required_hours'       => 8.00,
        'is_active'            => 1,
    ], $overrides));

    $GLOBALS['createdShifts'][] = $id;

    return $id;
}

/**
 * A 7-day schedule pointing at one shift. $restDay / $omitDay let a single
 * weekday be made a rest day, or left out entirely (no schedule for the date).
 */
function newSchedule(int $shiftId, ?int $restDay = null, ?int $omitDay = null): int
{
    $id = insertRow('work_schedules', [
        'code'          => 'CUT-SCH-' . randomSuffix(),
        'name'          => 'Cut-off test schedule',
        'schedule_type' => 'REGULAR',
        'is_active'     => 1,
    ]);

    $GLOBALS['createdSchedules'][] = $id;

    for ($dow = 0; $dow <= 6; $dow++) {
        if ($omitDay !== null && $dow === $omitDay) {
            continue;
        }

        $isRest = ($restDay !== null && $dow === $restDay);

        insertRow('work_schedule_days', [
            'work_schedule_id' => $id,
            'day_of_week'      => $dow,
            'shift_id'         => $isRest ? null : $shiftId,
            'is_rest_day'      => $isRest ? 1 : 0,
        ]);
    }

    return $id;
}

/** Employee, optionally linked to a login with the given role code. */
function newEmployee(?int $scheduleId, ?string $roleCode = null): int
{
    $suffix = randomSuffix();

    $id = insertRow('employees', [
        'employee_number'  => 'CUT-' . $suffix,
        'first_name'       => 'Cutoff',
        'last_name'        => 'Probe' . $suffix,
        'gender'           => 'OTHER',
        'email'            => 'cutoff.' . $suffix . '@test.local',
        'employment_type'  => 'FULL_TIME',
        'date_hired'       => '2026-01-05',
        'salary_type'      => 'MONTHLY',
        'basic_salary'     => 20000.00,
        'work_schedule_id' => $scheduleId,
        'status'           => 'ACTIVE',
    ]);

    $GLOBALS['createdEmployees'][] = $id;

    if ($roleCode !== null) {
        $userId = insertRow('users', [
            'username'      => 'cutoff' . strtolower($roleCode) . strtolower($suffix),
            'email'         => 'user.' . strtolower($suffix) . '@test.local',
            'password_hash' => password_hash('Password123@', PASSWORD_DEFAULT),
            'full_name'     => 'Cut-off ' . $roleCode . ' ' . $suffix,
            'role_id'       => roleId($roleCode),
            'employee_id'   => $id,
            'status'        => 'ACTIVE',
        ]);

        $GLOBALS['createdUsers'][] = $userId;
    }

    return $id;
}

/** Issue a real QR badge and return its plaintext token. */
function tokenFor(int $employeeId): string
{
    $issued = (new QrCodeService())->issue($employeeId, null, true);

    return (string) $issued['token'];
}

/** @return array<string, mixed>|null */
function attendanceRow(int $employeeId, string $date): ?array
{
    return dbRow(
        'SELECT * FROM attendance WHERE employee_id = :emp AND attendance_date = :date AND deleted_at IS NULL LIMIT 1',
        ['emp' => $employeeId, 'date' => $date]
    );
}

function attendanceCount(int $employeeId, string $date): int
{
    return (int) scalarValue(
        'SELECT COUNT(*) FROM attendance WHERE employee_id = :emp AND attendance_date = :date',
        ['emp' => $employeeId, 'date' => $date]
    );
}

function scanLogCount(int $employeeId): int
{
    return (int) scalarValue('SELECT COUNT(*) FROM attendance_logs WHERE employee_id = :emp', ['emp' => $employeeId]);
}

// ---------------------------------------------------------------------------
// Cleanup (never leaves fixtures behind, even on a fatal error)
// ---------------------------------------------------------------------------

function cleanup(): void
{
    try {
        $pdo = testDb();

        $employees = array_map('intval', $GLOBALS['createdEmployees']);
        $users     = array_map('intval', $GLOBALS['createdUsers']);
        $shifts    = array_map('intval', $GLOBALS['createdShifts']);
        $schedules = array_map('intval', $GLOBALS['createdSchedules']);
        $holidays  = array_map('intval', $GLOBALS['createdHolidays']);
        $leaves    = array_map('intval', $GLOBALS['createdLeaves']);

        $in = static fn (array $ids): string => implode(',', $ids);

        if ($users !== []) {
            $pdo->exec('DELETE FROM users WHERE id IN (' . $in($users) . ')');
        }
        if ($employees !== []) {
            $pdo->exec('DELETE FROM attendance_logs WHERE employee_id IN (' . $in($employees) . ')');
            $pdo->exec('DELETE FROM attendance WHERE employee_id IN (' . $in($employees) . ')');
            $pdo->exec('DELETE FROM leave_requests WHERE employee_id IN (' . $in($employees) . ')');
            $pdo->exec('DELETE FROM employee_qr_codes WHERE employee_id IN (' . $in($employees) . ')');
            $pdo->exec('DELETE FROM employees WHERE id IN (' . $in($employees) . ')');

            foreach ($employees as $employeeId) {
                foreach (glob(dirname(__DIR__) . '/storage/qrcodes/emp-' . $employeeId . '-qr*.svg') ?: [] as $file) {
                    @unlink($file);
                }
            }
        }
        if ($leaves !== []) {
            $pdo->exec('DELETE FROM leave_requests WHERE id IN (' . $in($leaves) . ')');
        }
        if ($holidays !== []) {
            $pdo->exec('DELETE FROM holidays WHERE id IN (' . $in($holidays) . ')');
        }
        if ($schedules !== []) {
            $pdo->exec('DELETE FROM work_schedule_days WHERE work_schedule_id IN (' . $in($schedules) . ')');
            $pdo->exec('DELETE FROM work_schedules WHERE id IN (' . $in($schedules) . ')');
        }
        if ($shifts !== []) {
            $pdo->exec('DELETE FROM shifts WHERE id IN (' . $in($shifts) . ')');
        }

        // Put the cut-off setting back exactly as it was found.
        Settings::set('attendance.late_cutoff_minutes', (string) ($GLOBALS['originalCutoff'] ?? '30'));
    } catch (Throwable $e) {
        fwrite(STDERR, 'cleanup warning: ' . $e->getMessage() . PHP_EOL);
    }
}

register_shutdown_function('cleanup');

// ---------------------------------------------------------------------------
// Rule-level helpers (injected clock keeps the boundaries deterministic)
// ---------------------------------------------------------------------------

function at(string $date, string $time): DateTimeImmutable
{
    return new DateTimeImmutable($date . ' ' . $time);
}

/** @return array{denied: bool, result: array<string, mixed>|null, message: string} */
function attemptScan(AttendanceService $svc, string $token, DateTimeImmutable $at): array
{
    try {
        return ['denied' => false, 'result' => $svc->scan($token, null, $at), 'message' => ''];
    } catch (RuntimeException $e) {
        return ['denied' => true, 'result' => null, 'message' => $e->getMessage()];
    }
}

/** @return array{denied: bool, result: array<string, mixed>|null, message: string} */
function attemptPreview(AttendanceService $svc, string $token, DateTimeImmutable $at): array
{
    try {
        return ['denied' => false, 'result' => $svc->preview($token, null, $at), 'message' => ''];
    } catch (RuntimeException $e) {
        return ['denied' => true, 'result' => null, 'message' => $e->getMessage()];
    }
}

/** @return array{denied: bool, result: array<string, mixed>|null, message: string} */
function attemptOverride(AttendanceService $svc, int $employeeId, DateTimeImmutable $at): array
{
    try {
        return ['denied' => false, 'result' => $svc->scanForEmployee($employeeId, null, $at), 'message' => ''];
    } catch (RuntimeException $e) {
        return ['denied' => true, 'result' => null, 'message' => $e->getMessage()];
    }
}

// ---------------------------------------------------------------------------
// HTTP helpers (mirrors the other DB-backed test scripts)
// ---------------------------------------------------------------------------

/**
 * @param  array<string, mixed> $body
 * @return array{status: int, json: array<string, mixed>, raw: string}
 */
function httpApi(string $method, string $path, array $body = [], ?string $token = null): array
{
    global $base;

    $headers = ['Content-Type: application/json', 'Accept: application/json'];
    if ($token !== null) {
        $headers[] = 'Authorization: Bearer ' . $token;
    }

    $options = [
        'http' => [
            'method'        => strtoupper($method),
            'header'        => implode("\r\n", $headers),
            'ignore_errors' => true,
            'timeout'       => 20,
        ],
    ];

    if ($body !== []) {
        $options['http']['content'] = json_encode($body, JSON_UNESCAPED_SLASHES);
    }

    $raw    = @file_get_contents($base . $path, false, stream_context_create($options));
    $status = 0;

    foreach ($http_response_header ?? [] as $line) {
        if (preg_match('#^HTTP/\S+\s+(\d+)#', $line, $m)) {
            $status = (int) $m[1];
        }
    }

    $decoded = json_decode((string) $raw, true);

    return [
        'status' => $status,
        'json'   => is_array($decoded) ? $decoded : [],
        'raw'    => (string) $raw,
    ];
}

function login(string $username): string
{
    $response = httpApi('POST', '/auth/login', ['username' => $username, 'password' => 'Password123@']);

    return (string) ($response['json']['data']['token'] ?? '');
}

// ===========================================================================
// 0. Configuration
// ===========================================================================

echo "30-minute late cut-off and automatic absence — test\n";
echo str_repeat('=', 62) . "\n\n";

$engine = new AttendanceEngine();
$svc    = new AttendanceService();

echo "[0] Configuration\n";
// Pin the documented default for the duration of the run (cleanup restores the
// original value), so the 29/30/31 assertions do not depend on local config.
Settings::set('attendance.late_cutoff_minutes', '30');
Settings::flush();
check('cut-off is 30 minutes', $engine->lateCutoffMinutes() === 30, 'got ' . $engine->lateCutoffMinutes());
check('application timezone is the configured one', date_default_timezone_get() === (string) $config['app']['timezone'], 'got ' . date_default_timezone_get());

// Configurability: the rule reads system_settings, so a different value moves
// the boundary. Restored immediately so nothing downstream is affected.
Settings::set('attendance.late_cutoff_minutes', '20');
Settings::flush();
check('cut-off is configurable (20 minutes)', $engine->lateCutoffMinutes() === 20, 'got ' . $engine->lateCutoffMinutes());
Settings::set('attendance.late_cutoff_minutes', '30');
Settings::flush();
check('cut-off restored to 30 minutes', $engine->lateCutoffMinutes() === 30);

// ===========================================================================
// 1–3. 29 / 30 / 31 minutes late — all allowed, all marked LATE
// ===========================================================================

echo "\n[1] Time-in 29 minutes after start — allowed\n";

$dayShiftId  = newShift(['start_time' => '08:00:00', 'end_time' => '17:00:00']);
$daySchedule = newSchedule($dayShiftId);

$emp29 = newEmployee($daySchedule);
$r29   = attemptScan($svc, tokenFor($emp29), at(REF_DATE, '08:29:00'));

check('29 minutes late is NOT denied', $r29['denied'] === false, $r29['message']);
check('29 minutes late records a TIME_IN', ($r29['result']['event_type'] ?? '') === 'TIME_IN');

$row29 = attendanceRow($emp29, REF_DATE);
check('29 minutes late is not marked ABSENT', ($row29['status'] ?? '') !== 'ABSENT', json_encode($row29));
check('29 minutes late stores the time-in', ($row29['time_in'] ?? '') === REF_DATE . ' 08:29:00', json_encode($row29));

echo "\n[2] Time-in exactly 30 minutes after start — allowed, LATE\n";

$emp30 = newEmployee($daySchedule);
$r30   = attemptScan($svc, tokenFor($emp30), at(REF_DATE, '08:30:00'));

check('exactly 30 minutes late is NOT denied', $r30['denied'] === false, $r30['message']);
check('30 minutes late records a TIME_IN', ($r30['result']['event_type'] ?? '') === 'TIME_IN');

// Record time-out so status finalizes from INCOMPLETE to LATE
$out30 = attemptScan($svc, tokenFor($emp30), at(REF_DATE, '17:00:00'));
check('30 minutes late time-out recorded', ($out30['result']['event_type'] ?? '') === 'TIME_OUT', $out30['message']);

$row30 = attendanceRow($emp30, REF_DATE);
check('30 minutes late is marked LATE (not ABSENT)', ($row30['status'] ?? '') === 'LATE', json_encode($row30));
check('30 minutes late stores late_minutes=25 (30 raw - 5 grace)', ($row30['late_minutes'] ?? 0) === 25, json_encode($row30));

echo "\n[3] Time-in 31 minutes after start — allowed, LATE\n";

$emp31 = newEmployee($daySchedule);
$r31   = attemptScan($svc, tokenFor($emp31), at(REF_DATE, '08:31:00'));

check('31 minutes late is NOT denied', $r31['denied'] === false, $r31['message']);
check('31 minutes late records a TIME_IN', ($r31['result']['event_type'] ?? '') === 'TIME_IN');

// Record time-out so status finalizes from INCOMPLETE to LATE
$out31 = attemptScan($svc, tokenFor($emp31), at(REF_DATE, '17:00:00'));
check('31 minutes late time-out recorded', ($out31['result']['event_type'] ?? '') === 'TIME_OUT', $out31['message']);

check('31 minutes late is marked LATE (not ABSENT)', (attendanceRow($emp31, REF_DATE)['status'] ?? '') === 'LATE');
check('31 minutes late stores late_minutes=26 (31 raw - 5 grace)', (attendanceRow($emp31, REF_DATE)['late_minutes'] ?? 0) === 26);

// ===========================================================================
// 4–5. The rule is identical for a STAFF and a MANAGER employee
// ===========================================================================

echo "\n[4] STAFF employee is subject to the same rule\n";

$empStaff = newEmployee($daySchedule, 'STAFF');
check('employee is linked to the STAFF role', (string) scalarValue(
    'SELECT r.code FROM users u JOIN roles r ON r.id = u.role_id WHERE u.employee_id = :emp',
    ['emp' => $empStaff]
) === 'STAFF');

$rStaff = attemptScan($svc, tokenFor($empStaff), at(REF_DATE, '08:30:00'));
check('STAFF: 30 minutes late is NOT denied', $rStaff['denied'] === false, $rStaff['message']);
check('STAFF: records TIME_IN', ($rStaff['result']['event_type'] ?? '') === 'TIME_IN');

// Record time-out so status finalizes
$outStaff = attemptScan($svc, tokenFor($empStaff), at(REF_DATE, '17:00:00'));
check('STAFF: time-out recorded', ($outStaff['result']['event_type'] ?? '') === 'TIME_OUT', $outStaff['message']);
check('STAFF: marked LATE', (attendanceRow($empStaff, REF_DATE)['status'] ?? '') === 'LATE');

echo "\n[5] MANAGER employee is subject to the same rule\n";

$empManager = newEmployee($daySchedule, 'MANAGER');
check('employee is linked to the MANAGER role', (string) scalarValue(
    'SELECT r.code FROM users u JOIN roles r ON r.id = u.role_id WHERE u.employee_id = :emp',
    ['emp' => $empManager]
) === 'MANAGER');

$rManager = attemptScan($svc, tokenFor($empManager), at(REF_DATE, '08:30:00'));
check('MANAGER: 30 minutes late is NOT denied', $rManager['denied'] === false, $rManager['message']);
check('MANAGER: records TIME_IN', ($rManager['result']['event_type'] ?? '') === 'TIME_IN');

// Record time-out so status finalizes
$outManager = attemptScan($svc, tokenFor($empManager), at(REF_DATE, '17:00:00'));
check('MANAGER: time-out recorded', ($outManager['result']['event_type'] ?? '') === 'TIME_OUT', $outManager['message']);
check('MANAGER: marked LATE', (attendanceRow($empManager, REF_DATE)['status'] ?? '') === 'LATE');

// ===========================================================================
// 6. Every service entry point funnels through the same rule
// ===========================================================================

echo "\n[6] Alternate attendance entry points\n";

// Uploaded QR image -> preview (must ALLOW a late scan, describe TIME_IN).
$empPreview = newEmployee($daySchedule);
$previewToken = tokenFor($empPreview);
$previewDenied = attemptPreview($svc, $previewToken, at(REF_DATE, '08:30:00'));

check('uploaded-image preview allows a 30-minute-late scan', $previewDenied['denied'] === false);
check('preview describes a TIME_IN', ($previewDenied['result']['event_type'] ?? '') === 'TIME_IN');
check('preview writes no attendance row', attendanceRow($empPreview, REF_DATE) === null);
check('preview writes no scan log', scanLogCount($empPreview) === 0, 'logs=' . scanLogCount($empPreview));

// The same preview on a permitted scan still describes a TIME_IN and writes nothing.
$previewOk = attemptPreview($svc, $previewToken, at(REF_DATE, '08:29:00'));
check('preview allows the 29-minute scan', $previewOk['denied'] === false && ($previewOk['result']['event_type'] ?? '') === 'TIME_IN');
check('allowed preview still writes nothing', attendanceRow($empPreview, REF_DATE) === null && scanLogCount($empPreview) === 0);

// Operator manual / override path - allows late scans too.
$empOverride = newEmployee($daySchedule);
tokenFor($empOverride);
$override = attemptOverride($svc, $empOverride, at(REF_DATE, '08:30:00'));

check('operator override allows the 30-minute-late scan', $override['denied'] === false, $override['message']);
check('override records TIME_IN', ($override['result']['event_type'] ?? '') === 'TIME_IN');

// Record time-out so status finalizes
$outOverride = attemptScan($svc, tokenFor($empOverride), at(REF_DATE, '17:00:00'));
check('override time-out recorded', ($outOverride['result']['event_type'] ?? '') === 'TIME_OUT', $outOverride['message']);
check('override marked LATE', (attendanceRow($empOverride, REF_DATE)['status'] ?? '') === 'LATE');

// A denied scan is an expected outcome, so it must never overwrite an existing
// valid time-in (case 8 protection, checked here at the point of denial too).
echo "\n[6b] A denied scan never overwrites a valid time-in\n";

$empValid = newEmployee($daySchedule);
$validToken = tokenFor($empValid);

// Record a valid, on-time time-in first.
$valid = attemptScan($svc, $validToken, at(REF_DATE, '08:00:00'));
check('on-time time-in is recorded', $valid['denied'] === false && ($valid['result']['event_type'] ?? '') === 'TIME_IN');

// Force an absence attempt for the same day: the existing row must survive.
check('canMarkAbsence refuses a day that already has a record', (new AttendanceEngine())->canMarkAbsence($empValid, REF_DATE, at(REF_DATE, '09:00:00')) === false);
$afterAttempt = attendanceRow($empValid, REF_DATE);
check('existing time-in is untouched', ($afterAttempt['time_in'] ?? '') === REF_DATE . ' 08:00:00', json_encode($afterAttempt));
check('existing record count is still exactly one', attendanceCount($empValid, REF_DATE) === 1);

// ===========================================================================
// 7 & 10. Automatic absence when nobody scans + idempotency
// ===========================================================================

echo "\n[7] Reconciler marks ABSENT without any scan\n";

$refNow = at(REF_DATE, '09:00:00');   // shift 08:00 -> cut-off 08:30 has passed
$reconcileEngine = new AttendanceEngine();

$empNever = newEmployee($daySchedule);
$firstRun  = $reconcileEngine->markAbsencesAfterCutoff(REF_DATE, $refNow, [$empNever]);
$secondRun = $reconcileEngine->markAbsencesAfterCutoff(REF_DATE, $refNow, [$empNever]);

$neverRow = attendanceRow($empNever, REF_DATE);
check('employee who never scanned is marked ABSENT', ($neverRow['status'] ?? '') === 'ABSENT', json_encode($neverRow));
check('a row was created on the first pass', $firstRun === 1, 'created=' . $firstRun);
check('a second pass creates no duplicate (case 10)', $secondRun === 0 && attendanceCount($empNever, REF_DATE) === 1);
check('the auto row is sourced AUTO with no time-in', ($neverRow['source'] ?? '') === 'AUTO' && ($neverRow['time_in'] ?? null) === null);

echo "\n[7b] AttendanceReconciler service is idempotent\n";

$empReconciler = newEmployee($daySchedule);
$reconciler    = new AttendanceReconciler();
$run1 = $reconciler->run($refNow, [$empReconciler]);
$run2 = $reconciler->run($refNow, [$empReconciler]);

check('reconciler run reports a completed pass', ($run1['ran'] ?? false) === true, json_encode($run1));
check('reconciler created one absence', ($run1['created'] ?? -1) === 1, json_encode($run1));
check('reconciler rerun created none', ($run2['created'] ?? -1) === 0, json_encode($run2));
check('reconciler left exactly one row', attendanceCount($empReconciler, REF_DATE) === 1);

echo "\n[10b] Concurrent runs are serialised by the advisory lock\n";

$lockConnection = testDb();   // a SEPARATE connection from the app's Database
$locked = (int) $lockConnection->query("SELECT GET_LOCK('pms_attendance_absence_reconciler', 1) AS l")->fetchColumn();

if ($locked === 1) {
    $blocked = $reconciler->run($refNow, [$empReconciler]);
    check('a run is skipped while another holds the lock', ($blocked['ran'] ?? true) === false && ($blocked['locked'] ?? false) === true, json_encode($blocked));
    $lockConnection->query("SELECT RELEASE_LOCK('pms_attendance_absence_reconciler')");
} else {
    check('a run is skipped while another holds the lock', false, 'could not acquire the test lock');
}

// ===========================================================================
// 9. Protected exceptions are never marked absent
// ===========================================================================

echo "\n[9] Exceptions are never marked absent\n";

// (a) earlier than the cut-off: not yet absent.
$empEarly = newEmployee($daySchedule);
check('before the cut-off nothing is marked', $reconcileEngine->canMarkAbsence($empEarly, REF_DATE, at(REF_DATE, '08:29:00')) === false);
check('after the cut-off it is markable', $reconcileEngine->canMarkAbsence($empEarly, REF_DATE, $refNow) === true);

// (b) rest day.
$restSchedule = newSchedule($dayShiftId, 1);   // Monday (day_of_week 1) is a rest day
$empRest = newEmployee($restSchedule);
check('rest day is never marked absent', $reconcileEngine->canMarkAbsence($empRest, REF_DATE, $refNow) === false);
check('rest-day marking is refused', $reconcileEngine->markAbsenceAfterCutoff($empRest, REF_DATE, $refNow) === false);

// (c) no schedule entry for the date.
$gapSchedule = newSchedule($dayShiftId, null, 1);   // Monday omitted entirely
$empGap = newEmployee($gapSchedule);
check('a day with no assigned shift is never marked absent', $reconcileEngine->canMarkAbsence($empGap, REF_DATE, $refNow) === false);

// (d) unscheduled employee.
$empNoSchedule = newEmployee(null);
check('an employee with no schedule is never marked absent', $reconcileEngine->canMarkAbsence($empNoSchedule, REF_DATE, $refNow) === false);

// (e) holiday.
$holidayId = insertRow('holidays', [
    'name'          => 'Cut-off test holiday ' . randomSuffix(),
    'holiday_date'  => REF_DATE,
    'holiday_type'  => 'SPECIAL',
    'is_paid'       => 0,
    'is_recurring'  => 0,
    'status'        => 'ACTIVE',
]);
$GLOBALS['createdHolidays'][] = $holidayId;

$empHoliday = newEmployee($daySchedule);
check('a holiday is never marked absent', $reconcileEngine->canMarkAbsence($empHoliday, REF_DATE, $refNow) === false);
check('holiday marking is refused', $reconcileEngine->markAbsenceAfterCutoff($empHoliday, REF_DATE, $refNow) === false);
check('no holiday attendance row was written', attendanceRow($empHoliday, REF_DATE) === null);
testDb()->exec('DELETE FROM holidays WHERE id = ' . (int) $holidayId);

// (f) approved leave.
$empLeave = newEmployee($daySchedule);
$leaveId  = insertRow('leave_requests', [
    'employee_id'   => $empLeave,
    'leave_type_id' => 1,   // Vacation Leave (seeded)
    'start_date'    => REF_DATE,
    'end_date'      => REF_DATE,
    'days'          => 1,
    'reason'        => 'Cut-off test approved leave',
    'status'        => 'APPROVED',
]);
$GLOBALS['createdLeaves'][] = $leaveId;

check('approved leave is never marked absent', $reconcileEngine->canMarkAbsence($empLeave, REF_DATE, $refNow) === false);
check('approved-leave marking is refused', $reconcileEngine->markAbsenceAfterCutoff($empLeave, REF_DATE, $refNow) === false);
testDb()->exec('DELETE FROM leave_requests WHERE id = ' . (int) $leaveId);

// ===========================================================================
// 11. Overnight shifts and timezone handling
// ===========================================================================

echo "\n[11] Overnight shifts and date boundaries\n";

$nightShiftId  = newShift(['start_time' => '22:00:00', 'end_time' => '06:00:00', 'is_overnight' => 1, 'grace_period_minutes' => 20]);
$nightSchedule = newSchedule($nightShiftId);
$nightShift    = dbRow('SELECT * FROM shifts WHERE id = :id', ['id' => $nightShiftId]);

check('night cut-off is 22:30 on the shift start date', $reconcileEngine->lateCutoffOn($nightShift, REF_DATE)->format('Y-m-d H:i') === '2026-06-15 22:30');

$empNight    = newEmployee($nightSchedule);
$nightToken  = tokenFor($empNight);
$afterMidnight = at('2026-06-16', '00:15:00');   // 2h15m into the shift that began on the 15th

check('a 00:15 scan belongs to the previous day', $reconcileEngine->attendanceDateFor($empNight, $afterMidnight) === REF_DATE);
check('a 22:29 scan still belongs to the 15th', $reconcileEngine->attendanceDateFor($empNight, at(REF_DATE, '22:29:00')) === REF_DATE);

$nightDenied = attemptScan($svc, $nightToken, $afterMidnight);
check('overnight: a post-cut-off scan is allowed (LATE)', $nightDenied['denied'] === false, $nightDenied['message']);
check('overnight: records TIME_IN', ($nightDenied['result']['event_type'] ?? '') === 'TIME_IN');

// Record time-out so status finalizes
$outNight = attemptScan($svc, $nightToken, at(REF_DATE, '06:00:00'));
check('overnight: time-out recorded', ($outNight['result']['event_type'] ?? '') === 'TIME_OUT', $outNight['message']);
check('overnight: marked LATE', (attendanceRow($empNight, REF_DATE)['status'] ?? '') === 'LATE');

// 29 minutes into the night shift is still allowed.
$empNightOk   = newEmployee($nightSchedule);
$nightOk      = attemptScan($svc, tokenFor($empNightOk), at(REF_DATE, '22:29:00'));
check('overnight: 29 minutes late is allowed', $nightOk['denied'] === false && ($nightOk['result']['event_type'] ?? '') === 'TIME_IN');
check('overnight: the allowed row is on the shift start day', attendanceRow($empNightOk, REF_DATE) !== null);

// ===========================================================================
// 12. Existing flows keep working (time-out, correction, payroll catch-up)
// ===========================================================================

echo "\n[12] Existing time-out, correction and payroll behaviour\n";

$empFlow    = newEmployee($daySchedule);
$flowToken  = tokenFor($empFlow);

$flowIn = attemptScan($svc, $flowToken, at(REF_DATE, '08:00:00'));
check('time-in still records through the normal flow', $flowIn['denied'] === false && ($flowIn['result']['event_type'] ?? '') === 'TIME_IN');

$flowOut = attemptScan($svc, $flowToken, at(REF_DATE, '17:00:00'));
check('time-out still records after a valid time-in', ($flowOut['result']['event_type'] ?? '') === 'TIME_OUT', $flowOut['message']);
check('completed day stores the time-out', (attendanceRow($empFlow, REF_DATE)['time_out'] ?? '') === REF_DATE . ' 17:00:00');

// Operator attendance correction (POST /api/attendance) is an authorised
// adjustment and must remain open regardless of the cut-off.
$empCorrection = newEmployee($daySchedule);
$corrected = $svc->record($empCorrection, [
    'attendance_date' => REF_DATE,
    'time_in'         => '08:00',
    'time_out'        => '17:00',
]);
check('manual correction still writes a full day', $corrected['time_in'] !== null && $corrected['time_out'] !== null, json_encode($corrected));
check('manual correction is not forced to ABSENT', ($corrected['status'] ?? '') !== 'ABSENT', $corrected['status'] ?? '');

// Payroll's own catch-up (AttendanceEngine::markAbsences) must not duplicate an
// absence the reconciler already recorded.
check('payroll catch-up leaves an existing absence alone', $reconcileEngine->markAbsences($empNever, REF_DATE, REF_DATE) === 0);
$empPayroll = newEmployee($daySchedule);
check('payroll catch-up still creates a missing working day', $reconcileEngine->markAbsences($empPayroll, REF_DATE, REF_DATE) === 1);

// ===========================================================================
// HTTP wiring: the running API enforces the same rule
// ===========================================================================

echo "\n[HTTP] The endpoints enforce the rule\n";

$managerToken = login('manager');
$adminToken   = login('admin');

if ($managerToken === '' || $adminToken === '') {
    check('could log in to the running API', false, 'manager/admin login failed at ' . $base);
} else {
    $sinceMidnight = ((int) date('G')) * 60 + (int) date('i');

    // A shift that began 31+ minutes ago on the SAME calendar day (guarded so a
    // late-night run cannot accidentally cross midnight and invert the result).
    if ($sinceMidnight >= 32) {
        $pastStart  = date('H:i:s', time() - 31 * 60);
        $lateShift  = newShift(['start_time' => $pastStart, 'end_time' => '23:59:00']);
        $lateSchedule = newSchedule($lateShift);

        $empHttp = newEmployee($lateSchedule);
        $httpToken = tokenFor($empHttp);

        $httpLate = httpApi('POST', '/attendance/scan', ['token' => $httpToken]);
        check('HTTP badge scan: 30+ minutes late is accepted (200)', $httpLate['status'] === 200, 'status=' . $httpLate['status']);
        $dataLate = $httpLate['json']['data'] ?? [];
        check('HTTP badge scan: records a TIME_IN', ($dataLate['event_type'] ?? '') === 'TIME_IN', substr($httpLate['raw'], 0, 200));
        $rowHttp = attendanceRow($empHttp, date('Y-m-d'));
        check('HTTP badge scan: time-in was stored', ($rowHttp['time_in'] ?? null) !== null);
        check('HTTP badge scan: late_minutes recorded', (int) ($rowHttp['late_minutes'] ?? 0) >= 25, json_encode($rowHttp));

        // Record a time-out so the status finalises from INCOMPLETE to LATE.
        httpApi('POST', '/attendance/scan', ['token' => $httpToken]);
        $rowHttp = attendanceRow($empHttp, date('Y-m-d'));
        check('HTTP badge scan: row is marked LATE (not ABSENT)', ($rowHttp['status'] ?? '') === 'LATE', json_encode($rowHttp));

        $empHttpOverride = newEmployee($lateSchedule);
        tokenFor($empHttpOverride);
        $httpOverride = httpApi('POST', '/attendance/scan', ['employee_id' => $empHttpOverride], $managerToken);
        check('HTTP manager override: 30+ minutes late is accepted (200)', $httpOverride['status'] === 200, 'status=' . $httpOverride['status']);
        // Time-out for the override record so status finalises to LATE.
        httpApi('POST', '/attendance/scan', ['employee_id' => $empHttpOverride], $managerToken);
        check('HTTP manager override: row is marked LATE', (attendanceRow($empHttpOverride, date('Y-m-d'))['status'] ?? '') === 'LATE');

        $empHttpPreview = newEmployee($lateSchedule);
        $httpPreviewToken = tokenFor($empHttpPreview);
        $httpPreview = httpApi('POST', '/attendance/scan/preview', ['token' => $httpPreviewToken]);
        check('HTTP preview: 30+ minutes late is accepted (200)', $httpPreview['status'] === 200, 'status=' . $httpPreview['status']);
        $dataPreview = $httpPreview['json']['data'] ?? [];
        check('HTTP preview: describes a TIME_IN', ($dataPreview['event_type'] ?? '') === 'TIME_IN');
        check('HTTP preview writes no attendance row', attendanceRow($empHttpPreview, date('Y-m-d')) === null);
        check('HTTP preview writes no scan log', scanLogCount($empHttpPreview) === 0);
    } else {
        echo "  SKIP  HTTP past-start cases (local time is too close to midnight to build a same-day past start)\n";
    }

    // An allowed scan still succeeds through HTTP (the confirmation flow is intact).
    if ($sinceMidnight >= 11) {
        $okStart    = date('H:i:s', time() - 10 * 60);
        $okShift    = newShift(['start_time' => $okStart, 'end_time' => '23:59:00']);
        $okSchedule = newSchedule($okShift);
        $empHttpOk  = newEmployee($okSchedule);
        $httpOkToken = tokenFor($empHttpOk);

        $httpOk = httpApi('POST', '/attendance/scan', ['token' => $httpOkToken]);
        check('HTTP allowed scan still records a TIME_IN (200)', $httpOk['status'] === 200 && str_contains($httpOk['raw'], '"event_type":"TIME_IN"'), 'status=' . $httpOk['status'] . ' body=' . substr($httpOk['raw'], 0, 160));
        check('HTTP allowed scan stored a time-in', (attendanceRow($empHttpOk, date('Y-m-d'))['time_in'] ?? null) !== null);
    } else {
        echo "  SKIP  HTTP allowed case (local time is too close to midnight)\n";
    }
}

// ===========================================================================
// Summary
// ===========================================================================

echo "\n" . str_repeat('=', 62) . "\n";
echo sprintf("RESULT: %d passed, %d failed\n", $passed, $failed);

if ($failed === 0) {
    echo "ALL CHECKS PASSED\n";
    exit(0);
}

echo "SOME CHECKS FAILED\n";
foreach ($failures as $failure) {
    echo "  - {$failure}\n";
}

exit(1);