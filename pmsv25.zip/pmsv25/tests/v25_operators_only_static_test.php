<?php
/** Conservative, no-DB checks for the defense demo gates. */
declare(strict_types=1);
require dirname(__DIR__) . '/api/core/Database.php';
require dirname(__DIR__) . '/api/core/demostaffscope.php';
use App\Core\DemoStaffScope;
function checked(bool $yes, string $msg): void { if (!$yes) {fwrite(STDERR,"FAIL: $msg\n"); exit(1);} }
$root=dirname(__DIR__);
checked(DemoStaffScope::enabled(),'staff-only demo is active');
$gates=[
 'api/services/LoanService.php'=>['assertDemoParticipant','assertDemoBorrower'],
 'api/services/AttendanceService.php'=>['assertIncluded($employeeId)'],
 'api/services/LeaveService.php'=>['assertDemoParticipant'],
 'api/services/OvertimeService.php'=>['assertDemoParticipant'],
 'api/services/ThirteenthPayService.php'=>['excludingRoles', 'limitedDemoScope'],
 'api/services/QrCodeService.php'=>['assertDemoParticipant'],
 'api/services/EmployeeService.php'=>['participates($employeeId)', 'participates($id)'],
 'api/controllers/PayrollController.php'=>['isSystemOperator()'],
 'frontend/js/app.js'=>["'profile/my-qr.html': ['STAFF']", "'payroll/payslips.html': ['STAFF']"],
];
foreach ($gates as $file=>$words) {
 $s=file_get_contents($root.'/'.$file);
 foreach ($words as $w) checked(str_contains($s,$w),"$file missing $w");
}
$migration=file_get_contents($root.'/database/SAFE_V25_STAFF_ONLY_DEMO_ELIGIBILITY.sql');
checked(!preg_match('/\b(DELETE\s+FROM|TRUNCATE|DROP\s+TABLE)\b/i',$migration),'migration does not delete records');
checked(str_contains($migration,'UPDATE employees'),'migration updates employee eligibility only');
echo "PASS: V25 operator-only no-DB policy checks\n";
