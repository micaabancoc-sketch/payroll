#!/usr/bin/env node
/**
 * Execute the frontend JavaScript and check what it actually does.
 *
 * tests/js_syntax_check.js only parses the files. That is not enough: an
 * unexported global or a helper that silently returns its input both parse
 * perfectly and still leave every page broken. This harness runs the real files
 * against a small DOM stub so the behaviour is exercised, not assumed.
 *
 * It is deliberately dependency-free — no jsdom, no npm install — because the
 * project ships with no build step.
 *
 * Usage: node tests/frontend_js_test.js
 */

'use strict';

const fs = require('fs');
const path = require('path');

const ROOT = path.resolve(__dirname, '..');
const JS_DIR = path.join(ROOT, 'frontend', 'js');

let passed = 0;
let failed = 0;

function ok(label) {
  console.log(`  PASS  ${label}`);
  passed += 1;
}

function bad(label, detail) {
  console.log(`  FAIL  ${label}`);
  console.log(`        ${detail}`);
  failed += 1;
}

function check(label, condition, detail) {
  if (condition) {
    ok(label);
  } else {
    bad(label, detail || 'assertion failed');
  }
}

function equal(label, actual, expected) {
  check(
    label,
    actual === expected,
    `expected ${JSON.stringify(expected)}, got ${JSON.stringify(actual)}`
  );
}

// ---------------------------------------------------------------------------
// A DOM stub, just large enough for the helpers under test
// ---------------------------------------------------------------------------

/**
 * Match an element against the handful of selector shapes the app uses:
 * "input", ".class", "[attr]" and "tag[attr=\"value\"]".
 */
function matches(element, selector) {
  const withAttribute = selector.match(/^([A-Za-z]*)\[([\w-]+)(?:="([^"]*)")?\]$/);

  if (withAttribute) {
    const [, tag, name, value] = withAttribute;

    if (tag && element.tagName.toLowerCase() !== tag.toLowerCase()) {
      return false;
    }

    const actual = element.getAttribute(name);

    if (actual === null) {
      return false;
    }

    return value === undefined || actual === value;
  }

  if (selector.charAt(0) === '.') {
    return String(element.className).split(/\s+/).indexOf(selector.slice(1)) !== -1;
  }

  return element.tagName.toLowerCase() === selector.toLowerCase();
}

/** Collect descendants of `root` (excluding root) that match the selector. */
function collect(root, selector) {
  const found = [];

  (function walk(node) {
    (node.childNodes || []).forEach((child) => {
      if (child.nodeType !== 1) {
        return;
      }

      if (matches(child, selector)) {
        found.push(child);
      }

      walk(child);
    });
  })(root);

  return found;
}

function createElement(tagName) {
  const element = {
    tagName: String(tagName).toUpperCase(),
    nodeType: 1,
    parentNode: null,
    childNodes: [],
    attributes: {},
    style: {},
    innerHTML: '',
    textContent: '',
    value: '',
    title: '',
    disabled: false,
    hidden: false,
    focused: false,
    _listeners: {},

    appendChild(child) {
      child.parentNode = this;
      this.childNodes.push(child);
      return child;
    },

    insertBefore(node, reference) {
      node.parentNode = this;

      const index = this.childNodes.indexOf(reference);

      if (index === -1) {
        this.childNodes.push(node);
      } else {
        this.childNodes.splice(index, 0, node);
      }

      return node;
    },

    setAttribute(name, value) {
      this.attributes[name] = String(value);
    },

    getAttribute(name) {
      return Object.prototype.hasOwnProperty.call(this.attributes, name)
        ? this.attributes[name]
        : null;
    },

    hasAttribute(name) {
      return this.getAttribute(name) !== null;
    },

    addEventListener(type, handler) {
      (this._listeners[type] = this._listeners[type] || []).push(handler);
    },

    /** Fire a listener, as the browser would on a real click. */
    dispatch(type) {
      const event = { type, target: this, preventDefault() {} };

      (this._listeners[type] || []).forEach((handler) => handler.call(this, event));

      return event;
    },

    focus() { this.focused = true; },
    setSelectionRange() {},
    closest(selector) {
      let node = this;

      while (node) {
        if (node.nodeType === 1 && matches(node, selector)) {
          return node;
        }

        node = node.parentNode;
      }

      return null;
    },
    querySelectorAll(selector) { return collect(this, selector); },
    querySelector(selector) { return collect(this, selector)[0] || null; },
  };

  // In a real browser `type` and `className` reflect attributes, and the app
  // relies on that (it queries input[type="password"] and sets .className).
  // Mirror it so the selector behaviour under test matches the browser.
  Object.defineProperty(element, 'type', {
    get() { return this.attributes.type || ''; },
    set(value) { this.attributes.type = String(value); },
    enumerable: true,
  });

  Object.defineProperty(element, 'className', {
    get() { return this.attributes.class || ''; },
    set(value) { this.attributes.class = String(value); },
    enumerable: true,
  });

  return element;
}

function createDocument() {
  const document = createElement('#document');

  document.readyState = 'complete';
  document.createElement = createElement;

  return document;
}
// ---------------------------------------------------------------------------
// Load the real frontend modules against the stub
// ---------------------------------------------------------------------------

/**
 * Run a frontend file. `globals` are injected as parameters, which is how the
 * modules see window/document; anything else they reference (Api, App) resolves
 * against globalThis exactly as it does in a browser.
 */
function load(file, globals) {
  const source = fs.readFileSync(path.join(JS_DIR, file), 'utf8');
  const names = Object.keys(globals);

  new Function(...names, source)(...names.map((name) => globals[name]));
}

/** Build a fresh window/document pair pointed at `pathname`. */
function createBrowser(pathname) {
  const window = {
    location: {
      pathname,
      search: '',
      replaced: null,
      replace(url) { this.replaced = url; },
    },
  };

  window.window = window;

  const document = createDocument();

  const localStorage = {
    _data: {},
    getItem(key) { return Object.prototype.hasOwnProperty.call(this._data, key) ? this._data[key] : null; },
    setItem(key, value) { this._data[key] = String(value); },
    removeItem(key) { delete this._data[key]; },
  };

  return { window, document, localStorage };
}

console.log('==============================================');
console.log(' FRONTEND JAVASCRIPT BEHAVIOUR TEST');
console.log('==============================================');
console.log();

// ---------------------------------------------------------------------------
console.log('--- Every module publishes its global ----------------------');
// ---------------------------------------------------------------------------
//
// The pages call App.<something> from their inline scripts. If app.js forgets
// to export, every signed-in page dies with "App is not defined" while the
// sign-in page keeps working — a combination that is easy to miss.

const browser = createBrowser('/pms/frontend/dashboard.html');

globalThis.window = browser.window;
globalThis.document = browser.document;
globalThis.localStorage = browser.localStorage;

load('api.js', { window: browser.window, document: browser.document, localStorage: browser.localStorage });

check('api.js exports Api', typeof browser.window.Api === 'object' && browser.window.Api !== null,
  'window.Api is ' + typeof browser.window.Api);

// app.js looks Api up as a global, exactly as it does in the browser.
globalThis.Api = browser.window.Api;

load('app.js', { window: browser.window, document: browser.document, localStorage: browser.localStorage });
globalThis.App = browser.window.App;

check('app.js exports App', typeof browser.window.App === 'object' && browser.window.App !== null,
  'window.App is ' + typeof browser.window.App
  + ' — the pages call App.guard()/renderNav()/escapeHtml() and would all throw');

load('charts.js', { window: browser.window, document: browser.document });
globalThis.Charts = browser.window.Charts;

check('charts.js exports Charts', typeof browser.window.Charts === 'object' && browser.window.Charts !== null,
  'window.Charts is ' + typeof browser.window.Charts);

const Api = browser.window.Api;
const App = browser.window.App;

// The functions the pages depend on must exist on the exported object.
['guard', 'renderNav', 'renderHeader', 'notify', 'escapeHtml', 'can', 'canAny',
 'applyPermissions', 'formatMoney', 'formatDate', 'enhancePasswordFields',
 'refreshNavBadges'].forEach((name) => {
  check(`App.${name} exists`, typeof App[name] === 'function', `typeof App.${name} is ${typeof App[name]}`);
});

['token', 'user', 'setSession', 'clearSession', 'loginUrl', 'get', 'post', 'put', 'delete'].forEach((name) => {
  check(`Api.${name} exists`, typeof Api[name] === 'function', `typeof Api.${name} is ${typeof Api[name]}`);
});

// ---------------------------------------------------------------------------
console.log();
console.log('--- escapeHtml actually escapes ----------------------------');
// ---------------------------------------------------------------------------
//
// Replacing a character with itself looks like escaping but does nothing. It
// parses, it does not throw, and it silently turns every interpolated value
// into an injection point.

equal('escapes <', App.escapeHtml('<script>'), '&lt;script&gt;');
equal('escapes >', App.escapeHtml('a > b'), 'a &gt; b');
equal('escapes &', App.escapeHtml('Tom & Jerry'), 'Tom &amp; Jerry');
equal('escapes double quotes', App.escapeHtml('say "hi"'), 'say &quot;hi&quot;');
equal('escapes single quotes', App.escapeHtml("it's"), 'it&#39;s');
equal('neutralises an img/onerror payload',
  App.escapeHtml('<img src=x onerror=alert(1)>'),
  '&lt;img src=x onerror=alert(1)&gt;');

// The ampersand must go first, or the entities above get re-escaped.
equal('escapes & before the other entities', App.escapeHtml('&lt;'), '&amp;lt;');
equal('leaves ordinary text alone', App.escapeHtml('Juan Dela Cruz'), 'Juan Dela Cruz');
equal('handles null', App.escapeHtml(null), '');
equal('handles undefined', App.escapeHtml(undefined), '');
equal('handles a number', App.escapeHtml(42), '42');
// ---------------------------------------------------------------------------
console.log();
console.log('--- Password reveal toggle ---------------------------------');
// ---------------------------------------------------------------------------

const form = browser.document.createElement('form');
const field = browser.document.createElement('input');

field.type = 'password';
field.id = 'password';
  field.value = 'Password123@';

form.appendChild(field);
browser.document.appendChild(form);

// Nothing should be wrapped before the helper runs.
equal('no toggle before enhancing', browser.document.querySelectorAll('.password-toggle').length, 0);

App.enhancePasswordFields();

const wrapper = field.parentNode;
const toggle = wrapper.querySelector('.password-toggle');

equal('input is wrapped in .password-field', wrapper.className, 'password-field');
check('a toggle button was added', toggle !== null, 'no .password-toggle inside the wrapper');

if (toggle) {
  equal('toggle cannot submit the form', toggle.type, 'button');
  equal('starts hidden', field.type, 'password');
  equal('starts labelled "Show password"', toggle.getAttribute('aria-label'), 'Show password');
  equal('starts aria-pressed=false', toggle.getAttribute('aria-pressed'), 'false');
  equal('starts with the eye icon', toggle.innerHTML.indexOf('<svg') === 0, true);
  equal('icon is hidden from screen readers', toggle.innerHTML.indexOf('aria-hidden="true"') !== -1, true);

  toggle.dispatch('click');
  equal('clicking reveals the password', field.type, 'text');
  equal('label flips to "Hide password"', toggle.getAttribute('aria-label'), 'Hide password');
  equal('aria-pressed flips to true', toggle.getAttribute('aria-pressed'), 'true');
  equal('icon swaps to the struck-through eye', toggle.innerHTML.indexOf('<line') !== -1, true);
  equal('caret focus returns to the field', field.focused, true);

  toggle.dispatch('click');
  equal('clicking again hides it', field.type, 'password');
  equal('label flips back', toggle.getAttribute('aria-label'), 'Show password');
  equal('aria-pressed flips back', toggle.getAttribute('aria-pressed'), 'false');

  // A revealed field is no longer input[type=password], so the guard attribute
  // is what stops a second pass from wrapping it again.
  toggle.dispatch('click');
  equal('field is revealed again', field.type, 'text');

  App.enhancePasswordFields();
  equal('re-running does not double-wrap', wrapper.childNodes.length, 2);
  equal('still only one toggle on the page', browser.document.querySelectorAll('.password-toggle').length, 1);
}

// A container-scoped call is how dialogs enhance a form they just built.
const dialog = browser.document.createElement('div');
const dialogField = browser.document.createElement('input');

dialogField.type = 'password';
dialog.appendChild(dialogField);
form.appendChild(dialog);

App.enhancePasswordFields(dialog);

equal('enhancing a subtree wraps its field', dialogField.parentNode.className, 'password-field');
equal('the original field was left alone', wrapper.className, 'password-field');
equal('two toggles in total now', browser.document.querySelectorAll('.password-toggle').length, 2);

// The form still holds the fields, so submission is unaffected.
check('field is still inside the form', field.closest('form') === form,
  'the wrapper broke the field out of its form');

// ---------------------------------------------------------------------------
console.log();
console.log('--- API base path derived from the page URL ----------------');
// ---------------------------------------------------------------------------
//
// The frontend has to find the API whether it is served from the project root
// or from a page nested inside frontend/.

function baseFor(pathname) {
  const scope = createBrowser(pathname);

  globalThis.window = scope.window;
  globalThis.document = scope.document;
  globalThis.localStorage = scope.localStorage;

  load('api.js', { window: scope.window, document: scope.document, localStorage: scope.localStorage });

  return scope.window.Api.base();
}

equal('sign-in page at the project root', baseFor('/pms/'), '/pms/api');
equal('sign-in page addressed as index.html', baseFor('/pms/index.html'), '/pms/api');
equal('a page inside the frontend folder', baseFor('/pms/frontend/dashboard.html'), '/pms/frontend/../api');
equal('a page nested one level deeper', baseFor('/pms/frontend/employees/index.html'), '/pms/frontend/../api');
equal('deployed at a domain root', baseFor('/'), '/api');
equal('deployed at a domain root, index.html', baseFor('/index.html'), '/api');

// ---------------------------------------------------------------------------
console.log();
console.log('--- Other helpers ------------------------------------------');
// ---------------------------------------------------------------------------

equal('label turns an enum into words', App.label('FULL_TIME'), 'Full Time');
equal('formatMoney uses the peso prefix by default', App.formatMoney(1234.5), 'PHP 1,234.50');
equal('formatNumber groups thousands', App.formatNumber(1234567), '1,234,567.00');
equal('formatDate returns a dash for an empty value', App.formatDate(''), '');

// Sample-data marking. Only the flag the API derives from the seeder's
// user-agent marker may badge a row; genuine activity must stay plain.
equal('genuine audit row: no sample badge', App.sampleBadge({ is_sample: false }), '');
equal('audit row with no flag: no sample badge', App.sampleBadge({ id: 1, username: 'admin' }), '');
equal('missing row: no sample badge', App.sampleBadge(undefined), '');
check('isSampleData accepts a boolean flag', App.isSampleData({ is_sample: true }) === true && App.isSampleData({ is_sample: false }) === false, 'boolean flag handling');
check('isSampleData tolerates a 1/0 payload', App.isSampleData({ is_sample: 1 }) === true && App.isSampleData({ is_sample: 0 }) === false, 'numeric flag handling');
check('seeded audit row: badged as test data', App.sampleBadge({ is_sample: true }).indexOf('badge-sample') !== -1, App.sampleBadge({ is_sample: true }));
check('the sample badge names the seeder, not the account', App.sampleBadge({ is_sample: true }).toLowerCase().indexOf('test data') !== -1 && App.sampleBadge({ is_sample: true }).toLowerCase().indexOf('password') === -1, App.sampleBadge({ is_sample: true }));

// Login redirect target has to stay correct, or a signed-out user lands on a
// 404 instead of the sign-in page.
equal('sign-out target is the application root', Api.loginUrl(), '../');

console.log();
console.log('==============================================');
console.log(` RESULT: ${passed} passed, ${failed} failed`);
console.log('==============================================');

process.exit(failed === 0 ? 0 : 1);
