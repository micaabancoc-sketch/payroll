"""Compare the interleaved codeword stream of our PHP encoder with segno's.

Reading the codewords back out of a finished matrix validates the whole chain
(byte-mode header, terminator, padding, Reed-Solomon, block interleaving) and
points directly at whichever stage diverges.
"""
import subprocess
import sys

import segno

PHP = r"C:\xampp\php\php.exe"
SCRIPT = r"C:\xampp\htdocs\pms\tests\qr_matrix.php"

ALIGNMENT = {
    1: [], 2: [6, 18], 3: [6, 22], 4: [6, 26], 5: [6, 30],
    6: [6, 34], 7: [6, 22, 38], 8: [6, 24, 42], 9: [6, 26, 46], 10: [6, 28, 50],
}


def reserved_map(version):
    size = 17 + 4 * version
    res = [[False] * size for _ in range(size)]

    def block(top, left):
        for dy in range(-1, 8):
            for dx in range(-1, 8):
                y, x = top + dy, left + dx
                if 0 <= y < size and 0 <= x < size:
                    res[y][x] = True

    block(0, 0)
    block(0, size - 7)
    block(size - 7, 0)
    for i in range(size):
        res[6][i] = True
        res[i][6] = True
    for cy in ALIGNMENT[version]:
        for cx in ALIGNMENT[version]:
            if (cy <= 8 and cx <= 8) or (cy <= 8 and cx >= size - 9) or (cy >= size - 9 and cx <= 8):
                continue
            for dy in range(-2, 3):
                for dx in range(-2, 3):
                    res[cy + dy][cx + dx] = True
    for i in range(9):
        res[8][i] = True
        res[i][8] = True
    for i in range(8):
        res[8][size - 1 - i] = True
        res[size - 1 - i][8] = True
    if version >= 7:
        for i in range(6):
            for j in range(3):
                res[i][size - 11 + j] = True
                res[size - 11 + j][i] = True
    return res


def unmask(value, y, x, mask):
    if mask == 0:
        cond = (y + x) % 2 == 0
    elif mask == 1:
        cond = y % 2 == 0
    elif mask == 2:
        cond = x % 3 == 0
    elif mask == 3:
        cond = (y + x) % 3 == 0
    elif mask == 4:
        cond = (y // 2 + x // 3) % 2 == 0
    elif mask == 5:
        cond = (y * x) % 2 + (y * x) % 3 == 0
    elif mask == 6:
        cond = ((y * x) % 2 + (y * x) % 3) % 2 == 0
    else:
        cond = ((y + x) % 2 + (y * x) % 3) % 2 == 0
    return (not value) if cond else value


def read_codewords(matrix, version, mask, total):
    size = 17 + 4 * version
    res = reserved_map(version)
    bits = []
    upward = True
    right = size - 1
    while right > 0:
        if right == 6:
            right = 5
        for step in range(size):
            y = size - 1 - step if upward else step
            for c in range(2):
                x = right - c
                if res[y][x]:
                    continue
                bits.append(int(unmask(matrix[y][x], y, x, mask)))
        upward = not upward
        right -= 2
    cw = []
    for i in range(total):
        byte = 0
        for j in range(8):
            byte = (byte << 1) | bits[i * 8 + j]
        cw.append(byte)
    return cw


def php_codewords(text, ecc):
    out = subprocess.run([PHP, SCRIPT, "--cw", text, ecc], capture_output=True, text=True)
    lines = [l for l in out.stdout.strip().split("\n") if l]
    if len(lines) < 2:
        raise RuntimeError(out.stderr[:400])
    version = int(lines[0].split()[1])
    cw = [int(v) for v in lines[1].split()]
    return version, cw


CASES = [
    ("A", "L"),
    ("HELLO WORLD", "M"),
    ("ATT-EMP-8F72A9C1-4D31", "M"),
    ("ATT-EMP-8F72A9C1-4D31", "H"),
    ("A" * 60, "M"),
    ("1234567890", "L"),
]
SPEC_TOTAL = {"1": 26, "2": 44, "3": 70, "4": 100, "5": 134, "6": 172,
              "7": 196, "8": 242, "9": 292, "10": 346}


def deinterleave(stream, g1_blocks, g1_len, g2_blocks, g2_len):
    """Undo QR block interleaving and return the logical data codewords."""
    blocks = [[] for _ in range(g1_blocks + g2_blocks)]
    lengths = [g1_len] * g1_blocks + [g2_len] * g2_blocks
    idx = 0
    for pos in range(max(lengths)):
        for b, length in enumerate(lengths):
            if pos < length:
                blocks[b].append(stream[idx])
                idx += 1
    out = []
    for block in blocks:
        out.extend(block)
    return out


# version -> level -> (group1 blocks, group1 length, group2 blocks, group2 length)
BLOCK_SPEC = {
    (1, "L"): (1, 19, 0, 0), (1, "M"): (1, 16, 0, 0), (1, "Q"): (1, 13, 0, 0), (1, "H"): (1, 9, 0, 0),
    (2, "L"): (1, 34, 0, 0), (2, "M"): (1, 28, 0, 0), (2, "Q"): (1, 22, 0, 0), (2, "H"): (1, 16, 0, 0),
    (3, "L"): (1, 55, 0, 0), (3, "M"): (1, 44, 0, 0), (3, "Q"): (2, 17, 0, 0), (3, "H"): (2, 13, 0, 0),
    (4, "L"): (1, 80, 0, 0), (4, "M"): (2, 32, 0, 0), (4, "Q"): (2, 24, 0, 0), (4, "H"): (4, 9, 0, 0),
    (5, "L"): (1, 108, 0, 0), (5, "M"): (2, 43, 0, 0), (5, "Q"): (2, 15, 2, 16), (5, "H"): (2, 11, 2, 12),
    (6, "L"): (2, 68, 0, 0), (6, "M"): (4, 27, 0, 0), (6, "Q"): (4, 19, 0, 0), (6, "H"): (4, 15, 0, 0),
    (7, "L"): (2, 78, 0, 0), (7, "M"): (4, 31, 0, 0), (7, "Q"): (2, 14, 4, 15), (7, "H"): (4, 13, 1, 14),
    (8, "L"): (2, 97, 0, 0), (8, "M"): (2, 38, 2, 39), (8, "Q"): (4, 18, 2, 19), (8, "H"): (4, 14, 2, 15),
    (9, "L"): (2, 116, 0, 0), (9, "M"): (3, 36, 2, 37), (9, "Q"): (4, 16, 4, 17), (9, "H"): (4, 12, 4, 13),
    (10, "L"): (2, 68, 2, 69), (10, "M"): (4, 43, 1, 44), (10, "Q"): (6, 19, 2, 20), (10, "H"): (6, 15, 2, 16),
}

fail = 0
for text, ecc in CASES:
    version, ours_stream = php_codewords(text, ecc)
    total = SPEC_TOTAL[str(version)]
    ours_stream = ours_stream[:total]

    q = segno.make(text, error=ecc.lower(), mode="byte", boost_error=False, micro=False)
    matrix = [[1 if v else 0 for v in r] for r in q.matrix]
    theirs_stream = read_codewords(matrix, q.version, q.mask, total)

    g1b, g1l, g2b, g2l = BLOCK_SPEC[(version, ecc)]
    n_data = g1b * g1l + g2b * g2l

    ours = deinterleave(ours_stream, g1b, g1l, g2b, g2l)
    theirs = deinterleave(theirs_stream, g1b, g1l, g2b, g2l)

    label = f"{text[:24]!r:28} ecc={ecc} v{version}"
    blocks = f"{g1b + g2b} block(s)"

    # 1. The meaningful prefix — byte-mode indicator, character count and the
    #    payload itself — must be byte-identical to the reference encoder.
    #    4 mode bits + 8/16 count bits + 8 bits per character, rounded up.
    count_bits = 8 if version <= 9 else 16
    meaningful = (4 + count_bits + 8 * len(text.encode()) + 7) // 8

    if ours[:meaningful] != theirs[:meaningful]:
        fail += 1
        d = [i for i in range(meaningful) if ours[i] != theirs[i]]
        print(f"FAIL  {label} payload codewords differ at {d[:8]}")
        for i in d[:8]:
            print(f"        [{i:2d}] php={ours[i]:3d} (0x{ours[i]:02x})  segno={theirs[i]:3d} (0x{theirs[i]:02x})")
        continue

    # 2. Everything after the payload must be the 0xEC / 0x11 pad sequence.
    #    (segno emits one extra null byte here; that is a benign capacity waste
    #    which is why ECC is verified by decoding, not by comparison.)
    tail = ours[meaningful:n_data]
    expected_tail = [0xEC if i % 2 == 0 else 0x11 for i in range(len(tail))]
    if tail != expected_tail:
        fail += 1
        bad = [i for i, (a, b) in enumerate(zip(tail, expected_tail)) if a != b]
        print(f"FAIL  {label} padding is not a valid 0xEC/0x11 sequence (at {bad[:6]})")
        continue

    print(
        f"PASS  {label}  {blocks}: {meaningful} payload codewords identical"
        f" to reference, {n_data - meaningful} pad codewords valid"
    )