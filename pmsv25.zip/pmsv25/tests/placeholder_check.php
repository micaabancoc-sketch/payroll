<?php
/**
 * Detect reused PDO named placeholders.
 *
 * With PDO::ATTR_EMULATE_PREPARES = false a named placeholder may appear only
 * once in a statement, so `WHERE a = :x OR b = :x` fails at runtime with
 * SQLSTATE[HY093] "Invalid parameter number".
 *
 * A regex over the raw source misses these (multi-line SQL, nested quotes,
 * heredocs). This walks PHP tokens instead, so every SQL string literal in the
 * codebase is inspected reliably.
 *
 * Usage: php tests/placeholder_check.php
 */

declare(strict_types=1);

$root = dirname(__DIR__);
$problems = [];
$scanned = 0;

$iterator = new RecursiveIteratorIterator(
    new RecursiveDirectoryIterator($root, FilesystemIterator::SKIP_DOTS)
);

foreach ($iterator as $file) {
    /** @var SplFileInfo $file */
    if (!$file->isFile() || $file->getExtension() !== 'php') {
        continue;
    }

    $path = $file->getPathname();

    // Skip this checker itself and any vendor-style trees.
    if (str_contains($path, 'vendor') || basename($path) === 'placeholder_check.php') {
        continue;
    }

    $source = file_get_contents($path);

    if ($source === false) {
        continue;
    }

    $scanned++;

    foreach (token_get_all($source) as $token) {
        if (!is_array($token)) {
            continue;
        }

        [$id, $text, $line] = $token;

        if ($id !== T_CONSTANT_ENCAPSED_STRING) {
            continue;
        }

        // Drop the surrounding quotes.
        $sql = substr($text, 1, -1);

        if ($sql === '' || !preg_match('/\b(SELECT|INSERT|UPDATE|DELETE)\b/i', $sql)) {
            continue;
        }

        preg_match_all('/(?<![\w:]):([a-zA-Z_][a-zA-Z0-9_]*)/', $sql, $matches);

        $counts = array_count_values($matches[1]);
        $dupes  = array_filter($counts, static fn (int $n): bool => $n > 1);

        if ($dupes === []) {
            continue;
        }

        $detail = [];

        foreach ($dupes as $name => $count) {
            $detail[] = sprintf(':%s (%d times)', $name, $count);
        }

        $problems[] = sprintf(
            '%s:%d  reused placeholder(s): %s',
            str_replace('\\', '/', substr($path, strlen($root) + 1)),
            $line,
            implode(', ', $detail)
        );
    }
}

echo "PDO placeholder check\n";
echo str_repeat('-', 60) . "\n";
echo sprintf("Scanned %d PHP file(s).\n\n", $scanned);

if ($problems === []) {
    echo "No reused named placeholders found.\n";
    exit(0);
}

foreach ($problems as $problem) {
    echo 'ISSUE  ' . $problem . PHP_EOL;
}

echo PHP_EOL . count($problems) . " issue(s) found." . PHP_EOL;

exit(1);