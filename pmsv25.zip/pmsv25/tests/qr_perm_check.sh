#!/usr/bin/env bash
# Runtime verification of the QR permission boundaries.
#
#   QR generation (issue / disable / regenerate)  -> ADMIN only
#   QR reading (svg / active / history)           -> own code, always
#                                                  someone else's -> 403 unless qr.view
#
# For issue() we target a NONEXISTENT employee id. That proves the permission
# *gate* passed (404 from the service layer) versus blocked (403 from the guard)
# without issuing or revoking anybody's real QR code.

BASE="${BASE:-http://127.0.0.1:8099/api}"
PASS=0
FAIL=0

login() {
  curl -s -X POST "$BASE/auth/login" -H 'Content-Type: application/json' \
    -d "{\"username\":\"$1\",\"password\":\"Password123@\"}" \
    | grep -o '"token":"[^"]*"' | cut -d'"' -f4
}

# expect <label> <actual> <wanted>
expect() {
  if [ "$2" = "$3" ]; then
    printf '  ok   %-58s %s\n' "$1" "$2"
    PASS=$((PASS + 1))
  else
    printf '  FAIL %-58s got %s want %s\n' "$1" "$2" "$3"
    FAIL=$((FAIL + 1))
  fi
}

# status <token> <method> <path> [data]
status() {
  if [ "$2" = "POST" ]; then
    curl -s -o /dev/null -w '%{http_code}' -X POST "$BASE$3" \
      -H "Authorization: Bearer $1" -H 'Content-Type: application/json' -d "$4"
  else
    curl -s -o /dev/null -w '%{http_code}' -X "$2" "$BASE$3" -H "Authorization: Bearer $1"
  fi
}

echo ">>> QR permission boundaries"

ADMIN_TOKEN=$(login admin)
MANAGER_TOKEN=$(login manager)
STAFF_TOKEN=$(login staff)

for pair in "ADMIN_TOKEN=$ADMIN_TOKEN" "MANAGER_TOKEN=$MANAGER_TOKEN" "STAFF_TOKEN=$STAFF_TOKEN"; do
  name=${pair%%=*}
  val=${pair#*=}
  if [ -z "$val" ]; then
    printf '  FAIL could not log in to obtain %s\n' "$name"
    FAIL=$((FAIL + 1))
  fi
done

if [ "$FAIL" -ne 0 ]; then
  echo "SOME CHECKS FAILED"
  exit 1
fi

GHOST=999999   # no such employee -> exercises the gate without touching real data

# --- ADMIN: full access, including generation ---------------------------------
expect "admin  GET  /qr/svg/2          (any employee)" "$(status "$ADMIN_TOKEN" GET  /qr/svg/2)"        "200"
expect "admin  GET  /qr/active/2       (any employee)" "$(status "$ADMIN_TOKEN" GET  /qr/active/2)"     "200"
expect "admin  POST /qr/issue/$GHOST   (generation allowed)" "$(status "$ADMIN_TOKEN" POST "/qr/issue/$GHOST" '{}')" "404"

# --- MANAGER (employee_id 2) --------------------------------------------------
expect "mgr    GET  /qr/svg/2          (own QR)"       "$(status "$MANAGER_TOKEN" GET  /qr/svg/2)"    "200"
expect "mgr    GET  /qr/active/2       (own QR)"       "$(status "$MANAGER_TOKEN" GET  /qr/active/2)" "200"
expect "mgr    GET  /qr/svg/1          (someone else's)" "$(status "$MANAGER_TOKEN" GET /qr/svg/1)"   "403"
expect "mgr    GET  /qr/active/1       (someone else's)" "$(status "$MANAGER_TOKEN" GET /qr/active/1)" "403"
expect "mgr    GET  /employees/1/qr    (someone else's)" "$(status "$MANAGER_TOKEN" GET /employees/1/qr)" "403"
expect "mgr    GET  /employees/1/qr/history (someone else's)" "$(status "$MANAGER_TOKEN" GET /employees/1/qr/history)" "403"
expect "mgr    POST /qr/issue/1        (generation blocked)" "$(status "$MANAGER_TOKEN" POST "/qr/issue/1" '{}')" "403"
expect "mgr    POST /qr/issue/$GHOST   (generation blocked)" "$(status "$MANAGER_TOKEN" POST "/qr/issue/$GHOST" '{}')" "403"

# --- STAFF (employee_id 1) ----------------------------------------------------
expect "staff  GET  /qr/svg/1          (own QR)"       "$(status "$STAFF_TOKEN" GET  /qr/svg/1)"    "200"
expect "staff  GET  /qr/active/1       (own QR)"       "$(status "$STAFF_TOKEN" GET  /qr/active/1)" "200"
expect "staff  GET  /qr/svg/2          (someone else's)" "$(status "$STAFF_TOKEN" GET /qr/svg/2)"   "403"
expect "staff  GET  /qr/active/2       (someone else's)" "$(status "$STAFF_TOKEN" GET /qr/active/2)" "403"
expect "staff  GET  /employees/2/qr    (someone else's)" "$(status "$STAFF_TOKEN" GET /employees/2/qr)" "403"
expect "staff  GET  /employees/2/qr/history (someone else's)" "$(status "$STAFF_TOKEN" GET /employees/2/qr/history)" "403"
expect "staff  POST /qr/issue/1        (generation blocked)" "$(status "$STAFF_TOKEN" POST "/qr/issue/1" '{}')" "403"

# --- Manual entry by employee ID ---------------------------------------------
# Naming an employee instead of presenting a badge is an operator override.
# It must never be reachable anonymously, which is the whole reason the QR
# token is the only unauthenticated way into /attendance/scan.
#
# As above, we target a NONEXISTENT employee so a permitted request proves the
# gate opened (422 from the service layer) without recording any attendance.
GHOST=999999

scan() {
  if [ -n "$2" ]; then
    curl -s -o /dev/null -w '%{http_code}' -X POST "$BASE/attendance/scan" \
      -H "Authorization: Bearer $2" -H 'Content-Type: application/json' -d "$1"
  else
    curl -s -o /dev/null -w '%{http_code}' -X POST "$BASE/attendance/scan" \
      -H 'Content-Type: application/json' -d "$1"
  fi
}

expect "anon   POST /attendance/scan employee_id   (blocked)"  "$(scan "{\"employee_id\":$GHOST}" '')"              "401"
expect "staff  POST /attendance/scan employee_id   (blocked)"  "$(scan "{\"employee_id\":$GHOST}" "$STAFF_TOKEN")"  "403"
expect "mgr    POST /attendance/scan employee_id   (override allowed)" "$(scan "{\"employee_id\":$GHOST}" "$MANAGER_TOKEN")" "422"
expect "admin  POST /attendance/scan employee_id   (override allowed)" "$(scan "{\"employee_id\":$GHOST}" "$ADMIN_TOKEN")"  "422"

# The badge path must stay anonymous: a bad token is rejected as a bad token
# (422), never as a missing session (401). Losing this would break every kiosk.
expect "anon   POST /attendance/scan token         (still anonymous)" "$(scan '{"token":"ATT-NOT-A-REAL-TOKEN-0000"}' '')" "422"

echo "RESULT: $PASS passed, $FAIL failed"
if [ "$FAIL" -eq 0 ]; then
  echo "ALL CHECKS PASSED"
  exit 0
fi
echo "SOME CHECKS FAILED"
exit 1