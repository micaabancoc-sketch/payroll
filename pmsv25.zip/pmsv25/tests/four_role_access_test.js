#!/usr/bin/env node
'use strict';
// Offline role-separation smoke test: navigation and migration grants.
const fs = require('fs');
const vm = require('vm');
const path = require('path');
const assert = require('assert');
const base = path.resolve(__dirname, '..');
const sql = fs.readFileSync(path.join(base, 'database/migrations/20261022_four_role_access.sql'), 'utf8');
const roleRegex = /(?:VALUES \('HR_PAYROLL'[^\n]*\n\s*'([^']+)'|permissions='([^']+)' WHERE code='(STAFF|MANAGER)')/g;
let match; const roles = {};
while ((match = roleRegex.exec(sql))) {
  if (match[1]) roles.HR_PAYROLL = JSON.parse(match[1]);
  else roles[match[3]] = JSON.parse(match[2]);
}
for (const role of ['HR_PAYROLL', 'MANAGER', 'STAFF']) assert.ok(Array.isArray(roles[role]), `Missing role ${role}`);
const has = (role, permission) => roles[role].includes(permission);
assert.ok(has('HR_PAYROLL','payroll.calculate'));
assert.ok(has('HR_PAYROLL','employees.create'));
assert.ok(has('HR_PAYROLL','loans.view'));
assert.ok(!has('HR_PAYROLL','payroll.approve'));
assert.ok(!has('HR_PAYROLL','payroll.mark_paid'));
assert.ok(!has('HR_PAYROLL','settings.manage'));
assert.ok(has('MANAGER','leave.approve'));
assert.ok(has('MANAGER','overtime.create'));
assert.ok(has('MANAGER','payroll.approve'));
assert.ok(!has('MANAGER','loans.view'));
assert.ok(!has('MANAGER','payroll.calculate'));
assert.ok(has('STAFF','loans.view_own'));
assert.ok(!has('STAFF','loans.view'));
assert.ok(!has('STAFF','payroll.period.view'));
const source = fs.readFileSync(path.join(base, 'frontend/js/app.js'), 'utf8');
let session={role:null};
const nav={innerHTML:''};
const document={readyState:'loading',querySelector(sel){return sel==='[data-nav]'?nav:null},addEventListener(){},querySelectorAll(){return []}};
const api={user:()=>session};
const window={addEventListener(){}};window.window=window;
vm.runInNewContext(source,{window,document,Api:api,console,Promise});
const tests=[
  ['ADMIN',['*'],{employees:true,payroll:true,loans:true}],
  ['HR_PAYROLL',roles.HR_PAYROLL,{employees:true,payroll:true,loans:true}],
  ['MANAGER',roles.MANAGER,{employees:true,payroll:true,loans:false}],
  ['STAFF',roles.STAFF,{employees:false,payroll:false,loans:true}],
];
for (const [role, permissions, expect] of tests){
  session={role, permissions};
  window.App.renderNav('dashboard');
  const html=nav.innerHTML;
  assert.strictEqual(html.includes('employees/index.html'),expect.employees,`${role} employees`);
  assert.strictEqual(html.includes('payroll/index.html'),expect.payroll,`${role} payroll`);
  assert.strictEqual(html.includes('loans/index.html'),expect.loans,`${role} loans`);
}
const employeeCode=fs.readFileSync(path.join(base,'api/services/EmployeeService.php'),'utf8');
assert.ok(employeeCode.includes('accountRoleByCode'), 'Independent account role missing');
assert.ok(employeeCode.includes('Only Admin can assign Admin, Manager, or HR/Payroll roles'), 'Privileged role validation missing');
assert.ok(employeeCode.includes('The selected position does not belong to the selected department'), 'Department-position validation missing');
const payrollCode=fs.readFileSync(path.join(base,'api/controllers/PayrollController.php'),'utf8');
assert.ok(payrollCode.includes('Payroll approval is assigned to the Manager role'));
assert.ok(payrollCode.includes('Only Admin can finalize and release the payroll'));
console.log('PASS: 4 role SQL grants, 4 nav profiles, independent account roles and payroll separation');
