"""Fast source-level safety regression checks; does not access users' database."""
from pathlib import Path
p=Path(__file__).resolve().parents[1]
svc=(p/'api/services/PayrollService.php').read_text()
eng=(p/'api/services/PayrollEngine.php').read_text()
ctrl=(p/'api/controllers/PayrollController.php').read_text()
ui=(p/'frontend/payroll/index.html').read_text()
route=(p/'api/routes.php').read_text()
tests={
  'full-batch estimate allows provisional scans': 'calculateEmployee($employee, $startDate, $endDate, true)' in svc,
  'verified single employee still fails closed': 'calculateEmployee($employee, $start, $end)' in svc,
  'engine strict by default': 'bool $provisionalDraft = false' in eng and '$this->assertAttendanceVerified($employee, $startDate, $endDate);' in eng,
  'engine filters legacy auto-absent and incomplete rows': 'unset($unresolvedDates' not in eng and 'array_fill_keys(array_column($attendanceIssues' in eng and '!isset($unresolvedDates' in eng,
  'provisional dates in snapshot': "'provisional_absent_days' => count($attendanceIssues)" in eng,
  'full-batch remains DRAFT if exceptions': "$nextStatus = $unresolvedDays > 0 ? 'DRAFT' : 'FOR_REVIEW'" in svc,
  'backend prevents approval until all employee rows verified': 'assertBatchVerifiedForRelease($periodId, $period)' in svc and 'active employees are missing from this payroll' in svc,
  'blocked calculation retains unpayable placeholder': "'financial_exception'=>$reason" in svc and "'payment_status'       => !empty($calculation['provisional']) ? 'UNPAID'" in svc,
  'existing locked/paid rows protected': 'Cannot recalculate a period with locked or partly paid employee records' in svc,
  'HR cannot self-confirm absent': 'if (Auth::employeeId() === $employeeId)' in svc,
  'verification reason and attendance audit': 'mb_strlen($reason) < 15' in svc and 'AuditLogger::ATTENDANCE_ADJUST' in svc,
  'confirm requires role permission': "Auth::authorize('attendance.adjust');" in ctrl and "Auth::roleCode() !== 'HR_PAYROLL'" in ctrl,
  'POST confirm route added': "'/api/payroll/periods/{id}/attendance-exceptions/confirm-absence'" in route,
  'UI distinguishes actual and provisional absences': 'Confirmed absent' in ui and 'For verification' in ui and 'PROVISIONAL DRAFT' in ui,
  'UI no fake auto absent payroll': 'Missing days have no confirmed absence deduction' in ui,
  'UI has confirmation evidence prompt': 'Confirm Absent (evidence required)' in ui and 'App.prompt(' in ui,
  'UI all-employee action explicit': 'Calculate All (Save Draft)' in ui,
}
for label,success in tests.items():print(('PASS' if success else 'FAIL')+'  '+label)
if not all(tests.values()): raise SystemExit('One or more V19 source checks failed.')
