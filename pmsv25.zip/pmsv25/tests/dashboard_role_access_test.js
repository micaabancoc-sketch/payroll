#!/usr/bin/env node
'use strict';
/** Test the actual App.renderNav function without requiring MySQL. */
const fs = require('fs');
const vm = require('vm');
const path = require('path');
const assert = require('assert');
const source = fs.readFileSync(path.join(__dirname, '../frontend/js/app.js'), 'utf8');
const nav = { innerHTML: '' };
const document = {
  readyState: 'loading',
  querySelector(selector) { return selector === '[data-nav]' ? nav : null; },
  addEventListener() {},
  querySelectorAll() { return []; },
};
const session = { user: null };
const Api = { user: () => session.user };
const win = { addEventListener() {} };
win.window = win;
vm.runInNewContext(source, {window:win, document, Api, console, Promise});
const App = win.App;
const cases = [
  {role:'ADMIN',permissions:['*'],loan:true,employees:true,payroll:true},
  {role:'MANAGER',permissions:['dashboard.view','employees.view','attendance.view_own','payroll.period.view','loans.view'],loan:false,employees:true,payroll:true},
  {role:'STAFF',permissions:['dashboard.view','attendance.view_own','attendance.scan','leave.view_own','overtime.view_own','payroll.payslip.view_own','loans.view_own','loans.create'],loan:true,employees:false,payroll:false},
];
for (const c of cases) {
  session.user = {role:c.role,permissions:c.permissions};
  App.renderNav('dashboard');
  assert.strictEqual(nav.innerHTML.includes('loans/index.html'),c.loan,`${c.role} loan menu`);
  assert.strictEqual(nav.innerHTML.includes('employees/index.html'),c.employees,`${c.role} employee directory menu`);
  assert.strictEqual(nav.innerHTML.includes('payroll/index.html'),c.payroll,`${c.role} payroll runs menu`);
  console.log(`PASS ${c.role} sidebar`);
}
