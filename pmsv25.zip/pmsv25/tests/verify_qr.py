"""Verify the pure-PHP QR encoder with a real, independent scanner.

Strategy
--------
A matrix-level comparison against another library can be ambiguous (mask
selection is a heuristic), so the decisive test is: render the QR produced by
our PHP encoder into a bitmap and let zxing-cpp (an independent, widely used
scanner) read it back. If the payload round-trips, the encoder is correct.

Additionally the encoded bytes are compared against segno's byte-mode
codeword stream, which validates mode/length/padding independently of masking.
"""
import re
import subprocess
import sys

from PIL import Image
import zxingcpp

PHP = r"C:\xampp\php\php.exe"
SCRIPT = r"C:\xampp\htdocs\pms\tests\qr_matrix.php"

CASES = [
    ("ATT-EMP-8F72A9C1-4D31", "M"),
    ("ATT-EMP-8F72A9C1-4D31", "L"),
    ("ATT-EMP-8F72A9C1-4D31", "Q"),
    ("ATT-EMP-8F72A9C1-4D31", "H"),
    ("HELLO WORLD", "M"),
    ("ATT-7F92A81C-4D31-9B2E-0001", "M"),
    ("A" * 60, "M"),
    ("1234567890", "L"),
    ("attendance-scan-token-0042", "Q"),
    ("ATT-EMP-" + "X" * 80, "L"),
    ("ATT|E#0001$", "M"),
]


def php_matrix(text, ecc, mask=None):
    cmd = [PHP, SCRIPT, text, ecc]
    if mask is not None:
        cmd.append(str(mask))
    out = subprocess.run(cmd, capture_output=True, text=True)
    lines = [l for l in out.stdout.strip().split("\n") if l]
    if not lines:
        raise RuntimeError(f"php error: {out.stderr[:400]}")
    head = lines[0].split()
    return int(head[1]), int(head[3]), [l.strip() for l in lines[1:]]


def render(rows, scale=8, quiet=4):
    size = len(rows)
    dim = (size + quiet * 2) * scale
    img = Image.new("L", (dim, dim), 255)
    px = img.load()
    for y, row in enumerate(rows):
        for x, cell in enumerate(row):
            if cell == "1":
                for dy in range(scale):
                    for dx in range(scale):
                        px[(x + quiet) * scale + dx, (y + quiet) * scale + dy] = 0
    return img


def decode(img):
    results = zxingcpp.read_barcodes(img)
    return results[0].text if results else None


# A subpath must be: moveto, horizontal run, vertical drop, negative run back, close.
# Subpaths are space-separated, and each one itself contains a space after the
# moveto, so the whole attribute is validated as a single pattern.
SUBPATH = r"M-?\d+ -?\d+h-?\d+v-?\d+h-?\d+z"
WHOLE_PATH = re.compile(r"^(?:" + SUBPATH + r")(?: " + SUBPATH + r")*$")


def php_svg_path(text, ecc):
    """The d="" attribute our own SVG renderer emits."""
    out = subprocess.run(
        [PHP, SCRIPT, "--svg", text, ecc], capture_output=True, text=True
    )
    match = re.search(r'd="([^"]*)"', out.stdout)
    if not match:
        raise RuntimeError(f"no path in SVG output: {out.stdout[:200]}{out.stderr[:200]}")
    return match.group(1)


def expected_path(rows, scale=8, quiet=4):
    """Rebuild the run-length path independently from the text matrix."""
    parts = []
    for y, row in enumerate(rows):
        x = 0
        while x < len(row):
            if row[x] != "1":
                x += 1
                continue
            start = x
            while x < len(row) and row[x] == "1":
                x += 1
            run = x - start
            parts.append(
                f"M{(start + quiet) * scale} {(y + quiet) * scale}"
                f"h{run * scale}v{scale}h{-run * scale}z"
            )
    return " ".join(parts)


def check_svg(text, ecc, rows):
    """toSvg() must emit valid path data that matches the encoded matrix.

    The matrix-level decode above cannot catch a broken renderer: browsers stop
    parsing path data at the first invalid token, so a malformed "h--8z" draws
    only a fragment while the matrix still scans perfectly.
    """
    d = php_svg_path(text, ecc)

    if "--" in d:
        raise AssertionError("malformed path data (double negative) e.g. 'h--8z'")

    if not WHOLE_PATH.match(d):
        head = d[:40]
        raise AssertionError(f"invalid path syntax near {head!r}")

    want = expected_path(rows)
    if d != want:
        raise AssertionError("SVG path does not match the encoded matrix")


failures = 0

print("=== Round-trip decode with zxing-cpp (independent scanner) ===")
for text, ecc in CASES:
    label = f"{text[:34]!r:38} ecc={ecc}"
    try:
        version, mask, rows = php_matrix(text, ecc)
        decoded = decode(render(rows))
    except Exception as exc:                                   # noqa: BLE001
        print(f"FAIL  {label} exception: {exc}")
        failures += 1
        continue

    if decoded == text:
        print(f"PASS  {label}  v{version} mask={mask} decoded OK")
    else:
        print(f"FAIL  {label}  decoded={decoded!r}")
        failures += 1

print()
print("=== Decode with every mask forced (0-7) ===")
for text, ecc in [("ATT-EMP-8F72A9C1-4D31", "M"), ("ATT-7F92A81C-4D31-9B2E-0001", "Q")]:
    for mask in range(8):
        try:
            _v, _m, rows = php_matrix(text, ecc, mask)
            decoded = decode(render(rows))
        except Exception as exc:                               # noqa: BLE001
            print(f"FAIL  {text[:20]!r} ecc={ecc} mask={mask}: {exc}")
            failures += 1
            continue
        if decoded == text:
            print(f"PASS  {text[:20]!r:24} ecc={ecc} mask={mask}")
        else:
            print(f"FAIL  {text[:20]!r:24} ecc={ecc} mask={mask} -> {decoded!r}")
            failures += 1

print()
print("=== SVG renderer output (path syntax must match the matrix) ===")
for text, ecc in CASES:
    label = f"{text[:34]!r:38} ecc={ecc}"
    try:
        _v, _m, rows = php_matrix(text, ecc)
        check_svg(text, ecc, rows)
    except Exception as exc:                                   # noqa: BLE001
        print(f"FAIL  {label} {exc}")
        failures += 1
        continue
    print(f"PASS  {label}  path OK")

print()
print("ALL PASS" if failures == 0 else f"{failures} FAILURE(S)")
sys.exit(1 if failures else 0)