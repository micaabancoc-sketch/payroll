<?php
declare(strict_types=1);
require dirname(__DIR__).'/api/core/Router.php';
$router = new \App\Core\Router();
require dirname(__DIR__).'/api/routes.php';
$reflect = new ReflectionClass($router);
$prop = $reflect->getProperty('routes');
$routes = $prop->getValue($router);
$lookup = static function (string $method,string $path) use($routes): array {
    foreach ($routes as $route) {
        if ($route['method'] === $method && $route['pattern'] === $path) return $route;
    }
    throw new RuntimeException("Missing route $method $path");
};
foreach (['/api/loans','/api/loans/options','/api/loans/summary','/api/loans/{id}','/api/loans/{id}/payments'] as $path) {
    if ($lookup('GET',$path)['permission'] !== null) throw new RuntimeException("GET $path must authorize in controller (Admin or own)");
}
foreach ([
    ['POST','/api/loans','loans.create'],
    ['POST','/api/loans/{id}/approve','loans.approve'],
    ['PUT','/api/loans/{id}','loans.update'],
    ['POST','/api/loans/{id}/payments','loans.payment']
] as [$method,$path,$permission]) {
    if ($lookup($method,$path)['permission'] !== $permission) throw new RuntimeException("Unexpected $method $path permission");
}
echo "Loan route policy tests passed\n";
