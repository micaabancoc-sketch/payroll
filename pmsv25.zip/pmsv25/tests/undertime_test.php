<?php

/**
 * Undertime policy test (audit fix: undertime on non-workdays + report visibility).
 *
 * Verifies the intended undertime policy end to end:
 *   2. A valid time-out scan BEFORE the scheduled end is accepted.
 *   3. Late minutes are calculated separately from undertime minutes.
 *   4. The undertime deduction applies only for an early departure and only
 *      while payroll.undertime_deduction_enabled is on.
 *   5. Clocking out exactly at the scheduled end produces NO undertime and no
 *      deduction.
 *   6. Late and undertime are never deducted twice (each applies once, from
 *      disjoint time windows).
 *   7. Approved LEAVE, HOLIDAY and REST_DAY rows never accrue late/undertime
 *      minutes or deductions, even when scans land on those days - and a LATE
 *      day that also ended early is still visible in the undertime report
 *      (the report filters on recorded minutes, not the single status value).
 *
 * Usage: DB_NAME=attendance_payroll_test php tests/undertime_test.php
 *   Refuses production-looking databases via tests/db_guard.php.
 */

declare(strict_types=1);

use App\Services\AttendanceService;
use App\Services\PayrollEngine;
use App\Services\QrCodeService;
use App\Services\ReportService;

require dirname(__DIR__) . '/api/autoload.php';

// Refuse to touch a production or genuine-use database.
require __DIR__ . '/db_guard.php';
pmsAssertSafeTestDatabase();

$config = require dirname(__DIR__) . '/api/config/config.php';
date_default_timezone_set((string) $config['app']['timezone']);

// A Monday: work_schedule_days are day-of-week based.
const REF_DATE = '2026-06-22';

$passed   = 0;
$failed   = 0;
$failures = [];

$GLOBALS['createdEmployees'] = [];
$GLOBALS['createdShifts']    = [];
$GLOBALS['createdSchedules'] = [];
$GLOBALS['createdHolidays']  = [];
$GLOBALS['createdLeave']     = [];
$GLOBALS['createdLeaveType'] = [];
$GLOBALS['settingsBackup']   = null;

function check(string $label, bool $ok, string $detail = ''): void
{
    global $passed, $failed, $failures;

    if ($ok) {
        $passed++;
        echo "  PASS  $label\n";
        return;
    }

    $failed++;
    $failures[] = $label;
    echo "  FAIL  $label\n";
    if ($detail !== '') {
        echo "        $detail\n";
    }
}

// ---------------------------------------------------------------------------
// Database helpers (private connection, independent of the app's Database)
// ---------------------------------------------------------------------------

function testDb(): PDO
{
    static $pdo = null;

    if ($pdo instanceof PDO) {
        return $pdo;
    }

    $cfg = require dirname(__DIR__) . '/api/config/config.php';
    $db  = $cfg['database'];

    $pdo = new PDO(
        sprintf('mysql:host=%s;port=%d;dbname=%s;charset=utf8mb4', $db['host'], $db['port'], $db['name']),
        $db['user'], $db['password'],
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC]
    );

    return $pdo;
}

/** @param array<string, mixed> $data */
function insertRow(string $table, array $data): int
{
    $columns      = array_keys($data);
    $placeholders = array_map(static fn (string $c): string => ':' . $c, $columns);
    $quoted       = array_map(static fn (string $c): string => '`' . $c . '`', $columns);

    $sql  = sprintf('INSERT INTO `%s` (%s) VALUES (%s)', $table, implode(', ', $quoted), implode(', ', $placeholders));
    $stmt = testDb()->prepare($sql);
    $stmt->execute($data);

    return (int) testDb()->lastInsertId();
}

/** @return array<string, mixed>|null */
function dbRow(string $sql, array $params = []): ?array
{
    $stmt = testDb()->prepare($sql);
    $stmt->execute($params);
    $row = $stmt->fetch();

    return $row === false ? null : $row;
}

function randomSuffix(): string
{
    return strtoupper(bin2hex(random_bytes(4)));
}

/**
 * @param array<string, mixed> $overrides
 * @return int shift id
 */
function newShift(array $overrides = []): int
{
    $id = insertRow('shifts', array_merge([
        'code'                 => 'UT-' . randomSuffix(),
        'name'                 => 'Undertime test shift',
        'start_time'           => '08:00:00',
        'end_time'             => '17:00:00',
        'is_overnight'         => 0,
        'grace_period_minutes' => 5,
        'required_hours'       => 8.00,
        'is_active'            => 1,
    ], $overrides));

    $GLOBALS['createdShifts'][] = $id;

    return $id;
}

/**
 * @param array<string, mixed> $overrides
 * @return int schedule id
 */
function newSchedule(array $overrides = []): int
{
    $shiftId  = $overrides['shift_id'] ?? null;
    $restDows = $overrides['rest_days'] ?? [];
    unset($overrides['shift_id'], $overrides['rest_days']);

    $id = insertRow('work_schedules', array_merge([
        'code'          => 'UT-SCH-' . randomSuffix(),
        'name'          => 'Undertime test schedule',
        'schedule_type' => 'REGULAR',
        'is_active'     => 1,
    ], $overrides));

    $GLOBALS['createdSchedules'][] = $id;

    if ($shiftId !== null) {
        for ($dow = 0; $dow <= 6; $dow++) {
            $isRest = in_array($dow, $restDows, true);

            insertRow('work_schedule_days', [
                'work_schedule_id' => $id,
                'day_of_week'      => $dow,
                // A rest day may still carry a shift assignment; the engine
                // must not accrue undertime on it either way.
                'shift_id'         => $isRest ? null : $shiftId,
                'is_rest_day'      => $isRest ? 1 : 0,
            ]);
        }
    }

    return $id;
}

/**
 * @param array<string, mixed> $overrides
 * @return int employee id
 */
function newEmployee(array $overrides = []): int
{
    $id = insertRow('employees', array_merge([
        'employee_number'  => 'UT-EMP-' . randomSuffix(),
        'first_name'       => 'Undertime',
        'last_name'        => 'Test',
        'status'           => 'ACTIVE',
        'employment_type'  => 'FULL_TIME',
        'date_hired'       => '2026-01-01',
        'salary_type'      => 'MONTHLY',
        'basic_salary'     => 22000.00,
        'work_schedule_id' => null,
        'department_id'    => null,
        'position_id'      => null,
    ], $overrides));

    $GLOBALS['createdEmployees'][] = $id;

    return $id;
}

function tokenFor(int $employeeId): string
{
    $issued = (new QrCodeService())->issue($employeeId, null, false);

    return $issued['token'];
}

/** @return array{denied: bool, result: array<string, mixed>|null, message: string} */
function attemptScan(AttendanceService $svc, string $token, string $at): array
{
    $atObj = new DateTimeImmutable($at);
    try {
        return ['denied' => false, 'result' => $svc->scan($token, null, $atObj), 'message' => ''];
    } catch (\RuntimeException $e) {
        return ['denied' => true, 'result' => null, 'message' => $e->getMessage()];
    }
}

/** @return array<string, mixed>|null */
function attendanceRow(int $employeeId, string $date): ?array
{
    return dbRow(
        'SELECT * FROM attendance WHERE employee_id = :emp AND attendance_date = :date AND deleted_at IS NULL LIMIT 1',
        ['emp' => $employeeId, 'date' => $date]
    );
}

/** @return array<string, mixed> the full employee row (engine input) */
function employeeRow(int $employeeId): array
{
    return dbRow('SELECT * FROM employees WHERE id = :id', ['id' => $employeeId]) ?? [];
}

/** Run the real payroll engine for one employee over the reference day. */
function calculate(PayrollEngine $engine, int $employeeId): array
{
    return $engine->calculateEmployee(employeeRow($employeeId), REF_DATE, REF_DATE);
}

/** @return array<string, mixed> */
function shiftRow(int $shiftId): array
{
    return dbRow('SELECT * FROM shifts WHERE id = :id', ['id' => $shiftId]) ?? [];
}

// ---------------------------------------------------------------------------
// Settings toggle (undertime on/off) with crash-safe restore
// ---------------------------------------------------------------------------

function setUndertimeEnabled(bool $enabled): void
{
    if ($GLOBALS['settingsBackup'] === null) {
        $GLOBALS['settingsBackup'] = (string) (dbRow(
            "SELECT setting_value FROM system_settings WHERE setting_key = 'payroll.undertime_deduction_enabled'"
        )['setting_value'] ?? '1');
    }

    $stmt = testDb()->prepare(
        "UPDATE system_settings SET setting_value = :v WHERE setting_key = 'payroll.undertime_deduction_enabled'"
    );
    $stmt->execute(['v' => $enabled ? '1' : '0']);

    // The engine reads through App\Core\Settings, which caches per process.
    \App\Core\Settings::flush();
}

// ---------------------------------------------------------------------------
// Cleanup (never leaves fixtures behind, even on a fatal error)
// ---------------------------------------------------------------------------

function cleanup(): void
{
    try {
        // Restore the deduction setting first: it is shared, not a fixture.
        if ($GLOBALS['settingsBackup'] !== null) {
            $stmt = testDb()->prepare(
                "UPDATE system_settings SET setting_value = :v WHERE setting_key = 'payroll.undertime_deduction_enabled'"
            );
            $stmt->execute(['v' => $GLOBALS['settingsBackup']]);
            $GLOBALS['settingsBackup'] = null;
        }

        $pdo = testDb();
        $in  = static fn (array $ids): string => implode(',', array_map('intval', $ids));

        $employees = array_map('intval', $GLOBALS['createdEmployees']);
        $shifts    = array_map('intval', $GLOBALS['createdShifts']);
        $schedules = array_map('intval', $GLOBALS['createdSchedules']);
        $holidays  = array_map('intval', $GLOBALS['createdHolidays']);
        $leaves    = array_map('intval', $GLOBALS['createdLeave']);
        $leaveType = array_map('intval', $GLOBALS['createdLeaveType']);

        if ($employees !== []) {
            $pdo->exec('DELETE FROM attendance_logs WHERE employee_id IN (' . $in($employees) . ')');
            $pdo->exec('DELETE FROM attendance WHERE employee_id IN (' . $in($employees) . ')');
            $pdo->exec('DELETE FROM leave_requests WHERE employee_id IN (' . $in($employees) . ')');
            $pdo->exec('DELETE FROM employee_qr_codes WHERE employee_id IN (' . $in($employees) . ')');
            $pdo->exec('DELETE FROM employees WHERE id IN (' . $in($employees) . ')');

            foreach ($employees as $employeeId) {
                foreach (glob(dirname(__DIR__) . '/storage/qrcodes/emp-' . $employeeId . '-qr*.svg') ?: [] as $file) {
                    @unlink($file);
                }
            }
        }
        if ($leaves !== []) {
            $pdo->exec('DELETE FROM leave_requests WHERE id IN (' . $in($leaves) . ')');
        }
        if ($leaveType !== []) {
            $pdo->exec('DELETE FROM leave_types WHERE id IN (' . $in($leaveType) . ')');
        }
        if ($holidays !== []) {
            $pdo->exec('DELETE FROM holidays WHERE id IN (' . $in($holidays) . ')');
        }
        if ($schedules !== []) {
            $pdo->exec('DELETE FROM work_schedule_days WHERE work_schedule_id IN (' . $in($schedules) . ')');
            $pdo->exec('DELETE FROM work_schedules WHERE id IN (' . $in($schedules) . ')');
        }
        if ($shifts !== []) {
            $pdo->exec('DELETE FROM shifts WHERE id IN (' . $in($shifts) . ')');
        }
    } catch (\Throwable $e) {
        fwrite(STDERR, 'cleanup warning: ' . $e->getMessage() . PHP_EOL);
    }
}

// Registered BEFORE the first test so even a fatal error mid-run cannot leave
// fixtures (or the toggled setting) behind.
register_shutdown_function('cleanup');

// ===========================================================================
// Tests
// ===========================================================================

$shiftId   = newShift();
$scheduleId = newSchedule(['shift_id' => $shiftId]);
$svc       = new AttendanceService();
$pe        = new PayrollEngine();
$reports   = new ReportService();

// ---------------------------------------------------------------------------
// [1] Rule 5: clock-out EXACTLY at the scheduled end -> no undertime at all
// ---------------------------------------------------------------------------

echo "\n[1] Clock-out exactly at the scheduled end (17:00:00)\n";

$emp1 = newEmployee(['work_schedule_id' => $scheduleId]);
$tok1 = tokenFor($emp1);

$in1  = attemptScan($svc, $tok1, REF_DATE . ' 08:00:00');
$out1 = attemptScan($svc, $tok1, REF_DATE . ' 17:00:00');
check('time-in recorded', $in1['denied'] === false, $in1['message']);
check('time-out recorded (on-time scan is valid)', $out1['denied'] === false, $out1['message']);

$row1 = attendanceRow($emp1, REF_DATE);
check('status is PRESENT', ($row1['status'] ?? '') === 'PRESENT', json_encode($row1));
check('undertime_minutes is 0', (int) ($row1['undertime_minutes'] ?? -1) === 0, json_encode($row1));
check('late_minutes is 0', (int) ($row1['late_minutes'] ?? -1) === 0, json_encode($row1));

$calc1 = calculate($pe, $emp1);
check('payroll undertime_deduction is 0.00', abs((float) $calc1['undertime_deduction'] - 0.0) < 0.005, json_encode($calc1['undertime_deduction']));
check('payroll late_deduction is 0.00', abs((float) $calc1['late_deduction'] - 0.0) < 0.005, json_encode($calc1['late_deduction']));
check('basic pay is one full daily rate (1,000.00)', abs((float) $calc1['basic_pay'] - 1000.0) < 0.005, json_encode($calc1['basic_pay']));

// ---------------------------------------------------------------------------
// [2] Rules 2 + 4: early clock-out is accepted and deducted once, on the hour
// ---------------------------------------------------------------------------

echo "\n[2] Early clock-out at 15:00 (2 hours before the scheduled end)\n";

$emp2 = newEmployee(['work_schedule_id' => $scheduleId]);
$tok2 = tokenFor($emp2);

attemptScan($svc, $tok2, REF_DATE . ' 08:00:00');
$out2 = attemptScan($svc, $tok2, REF_DATE . ' 15:00:00');
check('early time-out scan is NOT denied (rule 2)', $out2['denied'] === false, $out2['message']);

$row2 = attendanceRow($emp2, REF_DATE);
check('status is UNDERTIME', ($row2['status'] ?? '') === 'UNDERTIME', json_encode($row2));
check('undertime_minutes is 120', (int) ($row2['undertime_minutes'] ?? -1) === 120, json_encode($row2));
check('late_minutes is 0', (int) ($row2['late_minutes'] ?? -1) === 0, json_encode($row2));
check('worked_hours is 7.00', (float) ($row2['worked_hours'] ?? -1) === 7.0, json_encode($row2));

$calc2 = calculate($pe, $emp2);
// PER_HOUR at 60.00 -> 120 minutes cost exactly 2 x 60.00.
check('payroll undertime_deduction is 120.00 (2h x 60.00)', abs((float) $calc2['undertime_deduction'] - 120.0) < 0.005, json_encode($calc2['undertime_deduction']));
check('basic pay still one daily rate (deduction carries the shortage)', abs((float) $calc2['basic_pay'] - 1000.0) < 0.005, json_encode($calc2['basic_pay']));

// [2b] The same scenario with the deduction DISABLED must not deduct.
setUndertimeEnabled(false);
$calc2b = calculate($pe, $emp2);
check('undertime deduction disabled -> deduction is 0.00 (rule 4)', abs((float) $calc2b['undertime_deduction'] - 0.0) < 0.005, json_encode($calc2b['undertime_deduction']));
setUndertimeEnabled(true);
$calc2c = calculate($pe, $emp2);
check('re-enabled -> deduction is 120.00 again', abs((float) $calc2c['undertime_deduction'] - 120.0) < 0.005, json_encode($calc2c['undertime_deduction']));

// ---------------------------------------------------------------------------
// [3] Rules 3 + 6: late AND early out - separate minutes, one deduction each
// ---------------------------------------------------------------------------

echo "\n[3] Late clock-in (08:30) + early clock-out (15:00)\n";

$emp3 = newEmployee(['work_schedule_id' => $scheduleId]);
$tok3 = tokenFor($emp3);

attemptScan($svc, $tok3, REF_DATE . ' 08:30:00');
attemptScan($svc, $tok3, REF_DATE . ' 15:00:00');

$row3 = attendanceRow($emp3, REF_DATE);
// Rule 3: late and undertime are measured from opposite ends of the shift.
check('late_minutes is 25 (30 raw - 5 grace) - NOT 145', (int) ($row3['late_minutes'] ?? -1) === 25, json_encode($row3));
check('undertime_minutes is 120 - NOT 145', (int) ($row3['undertime_minutes'] ?? -1) === 120, json_encode($row3));
check('status is LATE (late wins when both apply)', ($row3['status'] ?? '') === 'LATE', json_encode($row3));

$calc3 = calculate($pe, $emp3);
// Rule 6: each deduction appears exactly once, from disjoint windows.
check('late_deduction is 50.00 (25 min x 2.00), once', abs((float) $calc3['late_deduction'] - 50.0) < 0.005, json_encode($calc3['late_deduction']));
check('undertime_deduction is 120.00 (120 min / 60 x 60.00), once', abs((float) $calc3['undertime_deduction'] - 120.0) < 0.005, json_encode($calc3['undertime_deduction']));
check('recorded minutes are the disjoint sum 25 + 120 = 145', (int) $calc3['late_minutes'] + (int) $calc3['undertime_minutes'] === 145, json_encode([$calc3['late_minutes'], $calc3['undertime_minutes']]));

// [3b] Recalculating the same period must produce identical figures.
$calc3b = calculate($pe, $emp3);
check('recalculation is idempotent (no double deduction)', $calc3b['undertime_deduction'] === $calc3['undertime_deduction'] && $calc3b['late_deduction'] === $calc3['late_deduction'], json_encode([$calc3b['late_deduction'], $calc3b['undertime_deduction']]));

// ---------------------------------------------------------------------------
// [4] Rule 7 (report visibility): a LATE day that also ended early must still
//     appear in the undertime report - the deduction was taken from it.
// ---------------------------------------------------------------------------

echo "\n[4] Undertime report includes late+early days\n";

$report = $reports->undertimeReport(['employee_id' => $emp3, 'date' => REF_DATE]);
check('the late+early day is listed in the undertime report', $report['total'] === 1, json_encode($report['total']));
check('the report row carries the 120 undertime minutes', (int) ($report['items'][0]['undertime_minutes'] ?? -1) === 120, json_encode($report['items'][0] ?? null));

$reportExact = $reports->undertimeReport(['employee_id' => $emp1, 'date' => REF_DATE]);
check('the on-time day is NOT listed in the undertime report', $reportExact['total'] === 0, json_encode($reportExact['total']));

// ---------------------------------------------------------------------------
// [5] Rule 7 (approved leave): a LEAVE day never accrues undertime, even when
//     scans land on it - and it is never deducted.
// ---------------------------------------------------------------------------

echo "\n[5] Approved LEAVE day + early scans\n";

$emp5 = newEmployee(['work_schedule_id' => $scheduleId]);

$leaveTypeId = insertRow('leave_types', [
    'code'          => 'UT-LT-' . randomSuffix(),
    'name'          => 'Undertime test leave',
    'is_paid'       => 1,
    'default_days'  => 1.00,
    'is_active'     => 1,
]);
$GLOBALS['createdLeaveType'][] = $leaveTypeId;

$leaveId = insertRow('leave_requests', [
    'employee_id'   => $emp5,
    'leave_type_id' => $leaveTypeId,
    'start_date'    => REF_DATE,
    'end_date'      => REF_DATE,
    'days'          => 1.00,
    'start_half'    => 'FULL',
    'end_half'      => 'FULL',
    'reason'        => 'Undertime policy test',
    'status'        => 'APPROVED',
    'approved_at'   => date('Y-m-d H:i:s'),
]);
$GLOBALS['createdLeave'][] = $leaveId;

// Mirror LeaveService::markLeaveAttendance: the approved leave creates the
// LEAVE attendance row before any scan happens.
insertRow('attendance', [
    'employee_id'      => $emp5,
    'attendance_date'  => REF_DATE,
    'shift_id'         => $shiftId,
    'work_schedule_id' => $scheduleId,
    'scheduled_start'  => '08:00:00',
    'scheduled_end'    => '17:00:00',
    'status'           => 'LEAVE',
    'is_rest_day'      => 0,
    'is_holiday'       => 0,
    'leave_request_id' => $leaveId,
    'source'           => 'AUTO',
]);

$tok5 = tokenFor($emp5);
attemptScan($svc, $tok5, REF_DATE . ' 08:00:00');
attemptScan($svc, $tok5, REF_DATE . ' 15:00:00');

$row5 = attendanceRow($emp5, REF_DATE);
check('status stays LEAVE', ($row5['status'] ?? '') === 'LEAVE', json_encode($row5));
check('LEAVE day records no late minutes', (int) ($row5['late_minutes'] ?? -1) === 0, json_encode($row5));
check('LEAVE day records no undertime minutes', (int) ($row5['undertime_minutes'] ?? -1) === 0, json_encode($row5));

$calc5 = calculate($pe, $emp5);
check('LEAVE day produces no undertime deduction', abs((float) $calc5['undertime_deduction'] - 0.0) < 0.005, json_encode($calc5['undertime_deduction']));
check('LEAVE day produces no late deduction', abs((float) $calc5['late_deduction'] - 0.0) < 0.005, json_encode($calc5['late_deduction']));
check('paid leave still earns its daily rate', abs((float) $calc5['basic_pay'] - 1000.0) < 0.005, json_encode($calc5['basic_pay']));
check('LEAVE day is not listed in the undertime report', $reports->undertimeReport(['employee_id' => $emp5, 'date' => REF_DATE])['total'] === 0);

// ---------------------------------------------------------------------------
// [6] Rule 7 (holiday / rest day): scans on a holiday or rest day are paid as
//     overtime, never as undertime or lateness.
// ---------------------------------------------------------------------------

echo "\n[6] Holiday and rest day + early scans\n";

$holidaysId = insertRow('holidays', [
    'name'         => 'Undertime test holiday',
    'holiday_date' => REF_DATE,
    'holiday_type' => 'REGULAR',
    'is_paid'      => 1,
    'is_recurring' => 0,
    'status'       => 'ACTIVE',
]);
$GLOBALS['createdHolidays'][] = $holidaysId;

$emp6 = newEmployee(['work_schedule_id' => $scheduleId]);
$tok6 = tokenFor($emp6);
attemptScan($svc, $tok6, REF_DATE . ' 08:00:00');
attemptScan($svc, $tok6, REF_DATE . ' 15:00:00');

$row6 = attendanceRow($emp6, REF_DATE);
check('holiday scan status is HOLIDAY', ($row6['status'] ?? '') === 'HOLIDAY', json_encode($row6));
check('holiday records no late minutes', (int) ($row6['late_minutes'] ?? -1) === 0, json_encode($row6));
check('holiday records no undertime minutes', (int) ($row6['undertime_minutes'] ?? -1) === 0, json_encode($row6));
check('holiday hours are classified as overtime (7.00)', (float) ($row6['overtime_hours'] ?? -1) === 7.0, json_encode($row6));

$calc6 = calculate($pe, $emp6);
check('holiday day produces no undertime deduction', abs((float) $calc6['undertime_deduction'] - 0.0) < 0.005, json_encode($calc6['undertime_deduction']));

// The holiday fixture is removed now so it cannot affect employee 7's day.
testDb()->exec('DELETE FROM holidays WHERE id = ' . $holidaysId);
$GLOBALS['createdHolidays'] = array_values(array_diff($GLOBALS['createdHolidays'], [$holidaysId]));

$restShiftId  = newShift();
$restSchedId  = newSchedule(['shift_id' => $restShiftId, 'rest_days' => [1]]); // Monday = rest
$emp7 = newEmployee(['work_schedule_id' => $restSchedId]);
$tok7 = tokenFor($emp7);
attemptScan($svc, $tok7, REF_DATE . ' 08:00:00');
attemptScan($svc, $tok7, REF_DATE . ' 15:00:00');

$row7 = attendanceRow($emp7, REF_DATE);
check('rest-day scan status is REST_DAY', ($row7['status'] ?? '') === 'REST_DAY', json_encode($row7));
check('rest day records no late minutes', (int) ($row7['late_minutes'] ?? -1) === 0, json_encode($row7));
check('rest day records no undertime minutes', (int) ($row7['undertime_minutes'] ?? -1) === 0, json_encode($row7));

$calc7 = calculate($pe, $emp7);
check('rest day produces no undertime deduction', abs((float) $calc7['undertime_deduction'] - 0.0) < 0.005, json_encode($calc7['undertime_deduction']));

// ---------------------------------------------------------------------------
// Summary
// ---------------------------------------------------------------------------

echo "\n" . str_repeat('=', 62) . "\n";
printf("Results: %d passed, %d failed\n", $passed, $failed);

if ($failed > 0) {
    echo "\nFailed checks:\n";
    foreach ($failures as $failure) {
        echo "  - $failure\n";
    }
    exit(1);
}

echo "UNDERTIME POLICY: every check passed\n";
exit(0);



