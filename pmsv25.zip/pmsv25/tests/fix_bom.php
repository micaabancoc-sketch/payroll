<?php
$path = 'c:\xampp\htdocs\pms\tests\overtime_midnight_completion_test.php';
$content = file_get_contents($path);
$bom = chr(0xEF) . chr(0xBB) . chr(0xBF);
if (substr($content, 0, 3) === $bom) {
    $content = substr($content, 3);
    file_put_contents($path, $content);
    echo "BOM removed\n";
} else {
    echo "No BOM found. First 20 bytes: " . bin2hex(substr($content, 0, 20)) . "\n";
}