<?php


declare(strict_types=1);

/**
 * Inspect the configured database and decide whether it is safe to write to.
 *
 * @return array{safe: bool, env: string, database: string, host: string, port: int, reason: string}
 */
function pmsTestDatabaseVerdict(): array
{
    try {
        $config = require __DIR__ . '/../api/config/config.php';
    } catch (\Throwable $e) {
        fwrite(STDERR, "Cannot read api/config/config.php: {$e->getMessage()}\n");
        exit(2);
    }

    $env   = strtolower(trim((string) ($config['app']['env'] ?? 'development')));
    $db    = $config['database'] ?? [];
    $name  = trim((string) ($db['name'] ?? ''));
    $lower = strtolower($name);

    $reasons = [];

    if ($env === 'production' || $env === 'prod') {
        $reasons[] = "APP_ENV is '{$env}'";
    }

    if ($name === '') {
        $reasons[] = 'the configured database name is empty';
    } elseif (
        preg_match('/(^|[_\-.])prod(uction)?([_\-.]|$)/', $lower) === 1
        || preg_match('/(^|[_\-.])live([_\-.]|$)/', $lower) === 1
    ) {
        $reasons[] = "the database name '{$name}' looks like a production database";
    }

    if (strcasecmp($name, 'attendance_payroll') === 0) {
        $reasons[] = "the database name '{$name}' is the default/genuine working database";
    }

    return [
        'safe'     => $reasons === [],
        'env'      => $env === '' ? '(unset)' : $env,
        'database' => $name === '' ? '(empty)' : $name,
        'host'     => (string) ($db['host'] ?? ''),
        'port'     => (int) ($db['port'] ?? 0),
        'reason'   => implode('; ', $reasons),
    ];
}

/**
 * Enforce the verdict: report where the suite is about to write and stop with a
 * non-zero exit code when the target is not a test database.
 */
function pmsAssertSafeTestDatabase(): void
{
    $verdict = pmsTestDatabaseVerdict();

    echo "Test-database safety check\n";
    echo str_repeat('-', 60), "\n";
    printf("  Target:  %s @ %s:%d\n", $verdict['database'], $verdict['host'], $verdict['port']);
    printf("  APP_ENV: %s\n", $verdict['env']);

    if ($verdict['safe']) {
        echo "  Verdict: SAFE - a development/test database\n";

        return;
    }

    if (getenv('PMS_ALLOW_PRODUCTION_DB') === '1' || getenv('PMS_ALLOW_GENUINE_DB') === '1') {
        printf("  Verdict: OVERRIDDEN - %s\n", $verdict['reason']);
        echo "\n";
        echo "  *** WARNING: PMS_ALLOW_PRODUCTION_DB=1 / PMS_ALLOW_GENUINE_DB=1 is set. ***\n";
        echo "  *** These suites delete payroll periods, toggle settings and ***\n";
        echo "  *** insert payroll rows. That is about to happen to what looks ***\n";
        echo "  *** like a production database. ***\n";
        echo "\n";

        return;
    }

    printf("  Verdict: REFUSED - %s\n", $verdict['reason']);
    echo "\n";
    echo "Refusing to run the test suite against a production or genuine-use database.\n";
    echo "Point DB_NAME at a test database and try again, for example:\n";
    echo "\n";
    echo "  DB_NAME=attendance_payroll_test php tests/db_guard.php\n";
    echo "\n";
    echo "To run anyway, re-run with PMS_ALLOW_PRODUCTION_DB=1, or with\n";
    echo "PMS_ALLOW_GENUINE_DB=1 when the target is 'attendance_payroll' itself.\n";

    exit(1);
}

// Act only when this file is the entry point (run_all.sh calls it directly). A
// suite that requires it decides for itself when to enforce the check.
$pmsGuardEntry = $_SERVER['SCRIPT_FILENAME'] ?? '';

if (PHP_SAPI === 'cli' && $pmsGuardEntry !== '' && realpath($pmsGuardEntry) === realpath(__FILE__)) {
    pmsAssertSafeTestDatabase();
}