# Role dashboard and loan-access corrections (October 22, 2026)

This update is based on `pms_policy_updated_v2.zip`. It does not redesign any page or change `frontend/css/app.css` or the image assets.

## Fixed in this version

1. **Employee → My Loans.** The sidebar now displays My Loans to employees with `loans.view_own`, without giving them company-wide `loans.view`. Employees can view their own loan requests, balances, and payment history; the API filters by the logged-in employee's ID. Employees may file Company Loan / Salary Advance requests with a requested amount and purpose. Their request begins as **PENDING**, without payroll deductions.
2. **Manager → no broad loan ledger.** The Manager sidebar excludes My Loans even for old cached permissions; the backend loan GET endpoints explicitly reject Manager accounts. The non-destructive SQL migration removes their legacy `loans.view` permission. Payroll review permissions remain intact.
3. **Admin → full loan administration.** Admin retains company-wide loan records, repayment ledger, and approval/edit permissions.
4. **Latest payroll card.** Payroll dashboard status and trend queries ignore future cutoffs (`end_date <= CURDATE()`). Employee dashboard payroll information shows only completed-period finalized/paid payroll records. The empty state explains that a completed cutoff is not yet available.
5. **Safer application submission.** Employee-provided employee IDs, balance, start date, end date, amortization, and reference number are disregarded for new employee loan requests. New requests store a zero **pending** amortization; Admin must set a valid monthly installment before the system allows approval. Unlinked accounts cannot read aggregate loan repayment totals.

## IMPORTANT: What this does **not** implement

- It does **not** complete the previously agreed employee acceptance of Admin-set loan terms, 5% flat company-loan interest handling, loan disbursement authorization, all agency loan amortization rules, or every statutory payroll calculation. The existing loan approval action still activates a loan after Admin approval once an installment is set. **Do not treat this as the complete final loan workflow.**
- It does **not** provide a live XAMPP/MySQL integration test or prove all Philippine statutory computations. Keep real payroll processing disabled until the full system is verified.
- The shared dashboard design and widgets are preserved. The provided screenshot of the Employee role showed the Payslip page, not the actual Employee Dashboard, so its exact visual content still needs browser review.

## Safe installation on existing XAMPP database

1. Back up both project folder and existing MySQL database using phpMyAdmin first.
2. Copy the changed files into a **separate test** project folder; do not overwrite your working application without a backup.
3. In phpMyAdmin, select the **existing application's** database. Run **only** `database/migrations/20261022_role_dashboard_permissions.sql` in its SQL tab to update the Manager role. (The file uses MySQL/MariaDB JSON functions.)
4. **Do not reimport `database/main.sql` into an existing database**: it contains DROP TABLE statements for fresh installs.
5. Log out and sign in again so each browser receives a refreshed permission list.
6. Check these specific cases: Employee sees My Loans and only their own loans; Manager sees payroll approvals but no My Loans; Admin sees all loans; future payroll periods no longer appear as Latest Payroll; no other employee's loan is retrievable by changing a URL ID.

## Automated checks run

- PHP lint over all `.php` files under `api` and `database`: passed.
- JavaScript parser checks for application JS and all 17 inline script blocks: passed.
- Existing frontend functional suite: 77 passed, 0 failed.
- Role-sidebar tests: Admin, Manager, STAFF passed.
- Loan route permission tests: passed.
- Payroll calendar policy tests: passed.
- **No** end-to-end MySQL test (this environment has no PDO MySQL driver).
