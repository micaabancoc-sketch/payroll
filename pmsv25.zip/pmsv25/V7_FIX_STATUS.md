# V7 – Policy and Bug Fix Status

Date: 23 Oct 2026. UI design/theme preserved. 

| User-reported issue | V7 action | Verification |
|---|---|---|
| ₱20,000 salary incorrectly computed by days present | `MONTHLY` and legacy `SEMI_MONTHLY` both fixed ₱10,000 per complete cutoff; rest days do not lower the basic cutoff amount | PHP policy checks passed; DB calculation needs QA |
| Fixed day shift / work schedule | Existing Settings/Schedules and Employees assignment maintained; default 8–5, 12–1 break | Configuration needs QA |
| Employee QR Scanner menu should be personal QR | Staff sidebar now links `My QR Code` in Profile; terminal for scanning others stays separate | Frontend syntax tests passed |
| Leave duration inaccurate | Date preview asks backend for count of scheduled working days excluding rest days/holidays; API now explains rejected fields | DB and leave balance QA needed |
| Employee Leave request fails generic `given data invalid` | Server validation errors exposed by Axios; basic client required-fields validation | Actual reason requires XAMPP input and balance checks |
| OT assignment filtering and invalid form | Added Department → Position → employee multi-selection; prefilled 17:30–19:30; backend assignment validation retained | OT create end-to-end needs QA |
| Employee loans end date confusing | For company/advance, employee requests principal; Admin offers 1–12 / 1–2 months, employee accepts, Admin disburses; agency loans retain verified start and end | XAMPP loan request test needed |
| Loan form generic errors | Optional blank fields removed; API now exposes field-specific validation errors | XAMPP QA needed |
| Fixed kinsenas and payday | Server enforces 1–15 / 16–month-end; 20th/next 5th previous applicable banking day; invalid legacy periods blocked from transition | Calendar PHP tests pass; holiday DB QA |
| Duplicate entries | Existing DB uniqueness + new adjustment request hash and custom deduction assignment guard; loan/QR/leave guards retained | Full concurrency checks not done |
| Rest day counted as Present | Regular unworked rest-day scans disabled by default and not a working-day leave deduction; company uses salary/2 basic | Rest-day WORKED premium scanning remains open QA |
| Payslip view button broken | `historyCard` declared; Staff own draft payslips now excluded until FINALIZED/PAID | Frontend tests pass; live QA needed |
| Payroll adjustments missing | New HR request/Manager decision API + page + `payroll_adjustments` table; engine applies only approved adjustments after recalculation | DB migration not live tested |
| Deduction Types & Payroll Deductions missing | New Admin management page/API; auto statutory/loan/attendance lines stay inside payroll_items | DB not live tested |
| 18 historical OT hours without QR scans | Existing records intentionally not deleted; must review imported/demo/approved OT source | NOT FIXED by erasing data |
| Manual 10 AM Time In unexpectedly accepted | Server checks standard regular 7–9 window for manual normal Time In; only Manager documented verified correction can go outside it | QA must test HTTP POST directly |
| Accurate statutory and legal total net pay | Effective-dated statutory schedules retained, monthly split, employer share separated; schedule-sensitive 261/313 reference factor added | Needs official tables and legal/accounting review |

## Not certified

Live MySQL integration, rest-day-work premium workflow, overtime holiday interactions, full annual SIL conversions/13th/final-pay legal cases, and bank holiday coverage were **not confirmed**. Do NOT pay actual salaries from unverified payroll.
