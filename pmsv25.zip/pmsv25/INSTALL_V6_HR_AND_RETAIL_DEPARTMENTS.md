# PMS V6: HR demo login + recommended retail departments

## What this update does
- Keeps all existing V5 visual styling, PHP APIs and current data intact.
- Adds/activates five retail-oriented departments and seven recommended positions.
- Adds one **fictional**, linked HR/Payroll Staff demo employee/account (username `hr`) with an initial salary history.
- Shows a clearer validation message if Add Employee has no Department or Position.
- Does **not** complete the remaining payroll policy work or certify labor-law accuracy.

## Required safe installation
1. **Back up the existing XAMPP database first.** Prefer a copy for testing.
2. Replace your test project files with this V6 project, or at minimum include the migration and updated `frontend/employees/index.html`.
3. Confirm the V4/V5 migrations for four roles have been applied.
4. In phpMyAdmin, **select your test PMS database** and import only:
   `database/migrations/20261022_retail_org_hr_demo.sql`
5. Logout/Login to refresh role permissions, then go to **Settings > Organization** to see the active departments/positions.
6. Test login: **username `hr` / temporary password `Password123@`**. Change it on first login when prompted. This is a demo account only.
7. Review HR dashboard permissions and the employee profile's Department/Position/Monthly Salary.

Do **NOT** reimport `database/main.sql` on an existing database. It DROPs and recreates tables.

If `hr` was already registered in users, the migration leaves the existing account untouched; check the verification SELECT at the end of the script. No password is reset. If it doesn't show the expected role, inspect the existing account rather than forcing a new one.

## Recommended organization (5 departments / 7 featured positions)

| Department | Code | Suggested active positions | Demo department default salary |
| --- | --- | --- | --- |
| Cashier | CASH | Cashier; Head Cashier | PHP 20,000/month |
| Sales Floor | SALES | Sales Associate | PHP 21,000/month (existing V5 value retained if set) |
| Inventory & Stockroom | STOCK | Stock Clerk; Inventory Controller | PHP 22,000/month |
| HR & Payroll | HR | HR/Payroll Officer | PHP 30,000/month |
| Store Operations | OPS | Store Supervisor | PHP 28,000/month |

Legacy positions/departments may also remain in the database; they are not deleted. Salary amounts are only classroom demo defaults (not DOLE minimum wage figures or mandatory rates), and the existing frontend currently copies them into each employee's salary when creating the account. Actual wages must be configured per employee according to a valid contract, wage orders and company policy; the UI's department-locked salary is a separate limitation to address before real deployment.

The payroll frequency is semi-monthly, but Salary Type for a monthly-paid worker should be **Monthly**. Semi-monthly is the payout schedule, not a change of salary basis.

**Known V5 limitation:** the Add Employee UI currently assigns Mon-Sat schedule by default regardless of department. The SQL demo HR employee is assigned STD-MF; verify schedule configuration if editing or recreating it. This does not certify schedule policy completeness.

## Quick validation
- Admin: Settings > Organization shows active HR & Payroll and HR/Payroll Officer.
- Admin: Employees list contains fictional Demo HR Payroll with username hr, role HR_PAYROLL and PHP 30,000/month salary.
- HR account: sign in, change password, view allowed HR screens; cannot finalize/release payroll or change system settings.
- Employee form: select HR & Payroll Department -> HR/Payroll Officer Position -> Account Role HR / Payroll Staff -> Salary Type Monthly -> salary auto-fills.

**No live MySQL testing was possible in this build environment** (PHP's pdo_mysql driver was not installed); migration should be tested in XAMPP before using on real data.
