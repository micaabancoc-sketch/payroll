# Four-role policy – V4

Role codes are **ADMIN**, **HR_PAYROLL**, **MANAGER**, and **STAFF** (displayed Employee / Staff; keeps existing logins compatible). Jobs/positions and system roles are separate.

| Task | Admin | HR/Payroll | Manager | Employee |
|---|---|---|---|---|
| Users, roles, department/position, settings | Manage | — | — | — |
| Employee records | Full | Create/edit | View | Own profile |
| Attendance | Oversight | Correct | Correct/verify | Own scans |
| Leave approval / OT assignment | Oversight | — | Approve/assign | Apply/view |
| Payroll preparation | Oversight | Generate/calculate | View | — |
| Payroll approval | — | — | Approve | — |
| Payroll finalization / release | Finalize/record | — | — | — |
| Company loan management | Approve | Prepare/track repayments | — | Request/view own |
| Statutory remittances | Oversight | Manage | — | — |
| Payslips | View | Prepare/view | Review | Own |

**Existing records:** Apply `database/migrations/20261022_four_role_access.sql` after database backup. This migration adds `HR_PAYROLL` and keeps existing STAFF users. Log out and back in after migration. Do **not** re-import `main.sql` into an existing database (it drops tables).

**New accounts:** Admin can select role when adding an employee. HR/Payroll can add only Employee/Staff accounts, and cannot elevate permissions by changing a job position. Existing accounts are not automatically promoted.

**Testing:** Static PHP and JavaScript checks included. Live XAMPP/MySQL integration is still required. This release implements the four-role access change, NOT all outstanding payroll rules.

**UI refinement:** The existing payroll page only shows the Approve button for Manager, even though the Admin role has the wildcard for other tasks. The 13th-month page now offers a Manager-only Approve button. Only Managers see OT assignment controls. No stylesheet or visual theme files were changed.
