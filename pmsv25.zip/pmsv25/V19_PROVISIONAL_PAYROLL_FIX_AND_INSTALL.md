# PMS V19 — Provisional Payroll Calculation & Verification Queue (TEST BUILD)

## Scope of this update

Based on the existing V18 package; includes all V18 Payroll/UI and other inherited features.

- **Calculate All (Save Draft)** saves a DRAFT payroll row for each eligible active employee in the elapsed cutoff, even if some scheduled attendance dates have no QR entries.
- Missing/incomplete scans and legacy automatic absences are flagged as **PROVISIONAL / FOR VERIFICATION** in the employee payroll snapshot. They are **not** automatically saved as confirmed ABSENT in the attendance table, and they **do not incur an automatic absence deduction**.
- The Payroll Periods table shows a provisional employee/day count. The period detail table distinguishes **Confirmed absent** from **For verification**, and warns that figures are estimates only.
- If an employee has a known **non-loan deductions exceed gross pay** issue, their DRAFT row is a visibly **blocked zero-amount placeholder**, *not a valid wage calculation*. HR must resolve the financial exception, then recalculate.
- **View Batch Exceptions** lists the exact unresolved dates. **Confirm Absent** is available only for *missing scans* and *legacy auto-absence* dates and requires evidence/justification (at least 15 characters); there is a server-side role check and audit log. HR cannot confirm their own absence. Incomplete Time In/Out requires genuine correction elsewhere.
- **Approval, finalization, and PAID** are guarded in the backend. If even one date is unresolved, a financial exception exists, an employee row is missing, or a provisional snapshot remains, the period cannot advance.
- Once *all* exceptions are properly resolved, rerun **Calculate All**; a clean batch moves to **FOR_REVIEW**. No payroll disbursement occurs from DRAFT calculation.

**Important:** Missing scans are not proof of absences. Provisional net pay might overestimate compensation. These amounts must never be paid until verified. A company cannot infer attendance just from missing scans. HR's own corrections still require the separate independent reviewer workflow, which is not completed in this focused build.

## Safe install on XAMPP

1. Export/back up your current working V18 database and **do not overwrite** your working V18 folder.
2. In phpMyAdmin, create a **new** database called `attendance_payroll_v19_test`. Import a FULL **COPY** of the V18 test database into this new database. Do not use a new empty database unless you import the full schema and test records.
3. Unzip the project into `C:\xampp\htdocs\pmsv19`.
4. Database config lives in `pmsv19/api/config/config.php`; default `DB_NAME` fallback is **attendance_payroll_v19_test** to discourage accidental writes to production. If your Apache or environment sets `DB_NAME`, it overrides the fallback; ensure it points to the clone.
5. The included `SAFE_V19_DATABASE_MIGRATION.sql` is a **no-op** (SELECT only); it is not necessary to import for an already migrated V18 test DB. If upgrading a V16 clone, apply the V17 migration FIRST, then use V19 source code.
6. Open `http://localhost/pmsv19/` and login as HR with your demo credentials.

## Test scenario (Oct 16–31, 2026)

1. Open **Payroll Processing**, select `PP-20261016-20261031`.
2. Click **Calculate All (Save Draft)**. Read the confirmation carefully.
3. Expected: rows for all eligible employees, but period stays **DRAFT** with **FOR VERIFICATION** counts if unresolved scans exist. The saved amounts are estimates, not paid salaries. Previous one-employee DRAFT rows may be replaced when recalculating the full batch.
4. Scroll to the period detail table. Compare **Confirmed absent** versus **For verification**. They must not be the same thing.
5. Click **View Batch Exceptions**. Expect dated issues; inspect QR logs, leave, holidays, schedules and rest days.
6. If you have genuine evidence that a non-HR employee was absent on a listed missing day, use **Confirm Absent**, enter the real evidence and confirm. For demo-only scenarios, do this **only on the cloned test DB**. Do not manufacture attendance or evidence on any live system.
7. For an incomplete punch, use an authorized attendance correction instead. For HR's own missing dates, refer to the independent Manager Reviewer; the HR button will reject self-approval.
8. Click **Calculate All (Save Draft)** again after attendance has been resolved. The period moves to **FOR_REVIEW** only when *all* required checks pass.
9. **Do not** Finalize, Release, Mark Paid, or perform actual remittances during this exploratory test.

## Tests performed in package construction

- PHP syntax lint (all source PHP files).
- Inline frontend JavaScript syntax check and standalone JS syntax checks.
- Static source regression checks for provisional snapshots, absence distinction, payment/approval guards, HR no-self-confirm, and V18 individual payroll behavior.

## Not run here

There was **no connection to your local MariaDB/XAMPP**, and no real end-to-end database test of transactions, payroll formulas, tax schedules, or real payment flows. This remains a **test build**, not certified for production or legal payroll compliance.

## Other existing pending items not fully completed in V19

Full HR independent reviewer for personal attendance/OT/leave, statutory schedule verification, legal uniform deduction policies, company-loan and agency remittance reconciliations, 13th month independent approvals, and older Archive UI removal. Do not treat V19 as production-ready.
