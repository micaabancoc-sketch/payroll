# PMS V11 — Kiosk Scanner and Pop-up Forms

## This is an UPDATE to V10, not a new database import
Do not import `database/main.sql` or `IMPORT_FRESH_ONE_FILE_DEFENSE.sql` over an existing populated database. Those are for clean/fresh installations. Back up the V10 database and files first.

### 1. Replace project files
Extract the ZIP into your XAMPP web root as the `pms/` folder, backing up your existing `pms/` first. Typical path: `C:\xampp\htdocs\pms`.

### 2. Apply the kiosk-role migration (existing V9/V10 database)
In phpMyAdmin, choose your **existing** PMS database and run:

`database/migrations/20261029_v11_kiosk_role.sql`

This adds the **KIOSK** device role to the existing `roles` table, without creating any employee or login credentials.

### 3. Create a dedicated scanner login
1. Sign in as technical IT **Admin** at `http://localhost/pms/`.
2. Open **User Accounts** → **Add User** (opens a pop-up over the list).
3. Enter a unique kiosk username, e.g., `frontdesk_scanner_1`, name, strong unique password.
4. Set Role = **Attendance Kiosk**, leave Employee ID blank (hidden for kiosk).
5. Create the account; verify that the account is active.
6. Use a dedicated Windows user / browser profile or a company-controlled kiosk machine for that login. Do NOT use the HR or Manager account at the kiosk.

### 4. OPEN THE SCANNER
On the dedicated kiosk computer with a webcam, open:

`http://localhost/pms/kiosk.html`

Sign in **with the KIOSK account**, click **Open Scanner**, allow camera permission. The app takes you to `http://localhost/pms/frontend/attendance/scanner.html` automatically. Employees present their **My QR** badge to the kiosk. All QR attendance requests use the authenticated kiosk account; the scan endpoint rejects calls from Admin, HR, Manager and Staff.

If the kiosk is on **another device**, `localhost` means *that device*, not your server. Use the server's reachable hostname with **HTTPS**; browser camera access typically requires a secure origin (HTTPS or same-machine localhost). Don't expose the XAMPP development server publicly.

Click **Exit** on the scanner to stop the camera and sign out the kiosk. Credentials should not be shared with employees.

### 5. Who can access what
- **IT Admin:** manages account creation, technical configuration, kiosk credentials; not a payroll employee.
- **KIOSK:** camera scanning and QR preview only. No employee profile, HR, Manager, payslip or admin pages.
- **HR/Payroll:** My QR, My Attendance, HR verification and payroll pages; no scanner page/link.
- **Manager:** My QR, My Attendance, assigned-team pages; no scanner page/link.
- **Staff:** My QR, own attendance, leave, own payslips; no scanner page/link.

Neither Staff nor Manager/HR can post attendance QR scans to the kiosk-only API, including via direct requests.

### 6. Add/Edit pop-ups
- **User Accounts → Add User** is now a modal pop-up, no longer an appended card below the table.
- **Payroll Adjustments → New Adjustment** uses a modal pop-up.
- **Authorized Deductions → Add Type / Assign Deduction** uses modal pop-ups.
- Employees, attendance correction, leave, OT, loan and settings creation already use modals and retain their existing overlay style.
- Close using **X**, Cancel, Escape, or clicking the background. Validation errors remain visible in the modal.

### 7. Important known limits
- This code passed PHP syntax, embedded JS syntax and static role-permission checks. **A live XAMPP/MySQL login and camera scan has NOT been exercised here**. Test with an actual kiosk account and test employee QR before real use.
- Kiosk is an authenticated browser session, **not device hardware attestation**. Secure the physical device, password, network, and browser session.
- Payment calculations, holidays, divisor assumptions, statutory tables, and loan calculations remain subject to the separate payroll integration and policy verification.
- Some inherited V9/V10 archive-oriented source branches may remain for database compatibility; archive navigation and archive API operations are disabled, and attendance's archived tab is hidden. This is not a database purge.
- Independent review is required for an HR officer's own OT and personal payroll adjustments. Additional company-designated approvers still need to be configured if none exist.
