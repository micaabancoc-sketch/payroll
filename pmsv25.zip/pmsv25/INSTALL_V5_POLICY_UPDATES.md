# V5 — Policy integration and safe local testing

**Status: Development/testing build, NOT certified production payroll software.**

This is an update to V4, not a fresh replacement of your instructor's native PHP/PDO/Vanilla-JS/Axios architecture. Existing HTML/CSS styles and dashboard layouts are preserved. SweetAlert2 is still used for dialogs.

## Safe install on XAMPP

1. Make a backup of **both** the entire existing project directory and its MySQL database.
2. Copy V5 into a **separate folder** under `C:\xampp\htdocs\`. Test against a COPY of your existing database, not the production/original database.
3. If upgrading from V3 or older, read `INSTALL_V4_FOUR_ROLES.md` and apply the V4 role migration to the test database first. If V4 is already installed, do **not** rerun V4 migration.
4. On the test database, run the following **new V5 migrations**, in this order, using phpMyAdmin SQL. Run each **once only** and verify success before the next:
   - `database/migrations/20261022_fixed_monthly_policy.sql`
   - `database/migrations/20261022_loan_terms_acceptance.sql`
   - `database/migrations/20261022_overtime_scan_sessions.sql`
5. Check `api/config/connection-pdo.php` / the existing environment configuration points to the COPY database. Do not expose your DB credentials publicly.
6. Log out all user sessions, then log in to test each of the four roles. Use fictional sample employees only.
7. DO NOT re-import `database/main.sql` on an existing database. That file explicitly **drops tables**, and has a hard-coded `USE attendance_payroll` statement.

## Updates in this version

- Fixed MONTHLY basic compensation to **monthly basic salary / 2 for a complete cutoff**. Partial initial cutoff is prorated for new hires. Daily/hourly calculation uses a configured annual divisor (default 365, only if this is justified by the actual fully monthly-paid terms).
- Prevents double-charging one absence/unpaid leave as both non-accrual and a second deduction in fixed-monthly records. 13th-month basis tracks basic salary actually earned after unpaid time adjustments.
- Statutory monthly employee contribution is split between cutoffs with a centavo-reconciliation rule; unavailable effective-dated statutory tables cause a calculation error rather than silently assuming zero.
- Company loan: 5% flat interest, principal capped at one monthly salary, maximum 12 months. Salary advance: 0% interest, 50% of monthly salary maximum, max 2 months.
- Company loan workflow: employee request -> Admin terms offer -> employee accepts the actual terms -> Admin confirms money release -> only then can payroll collect deductions. Loans are not automatically released upon approval.
- SSS/Pag-IBIG loan categories are registered by Admin based on agency-approved repayment details; Admin does not invent agency interest or repayment duration.
- Loan shortfalls are recorded for Admin review; the payroll draft does not knowingly make net salary negative to fund loan deductions.
- Regular Time In is blocked outside 7:00–9:00 AM for an 8:00 AM shift. The actual work done outside cutoff requires an authorized attendance correction.
- Separate manager-assigned OT QR Time In / Time Out after regular Time Out; actual completed OT scans are required to approve payable OT, capped to assignment and 4 hours daily.
- QR Time Out and OT Time Out show confirmation; regular Early Time Out shows a stronger warning. Canceled preview transactions do not change attendance.
- Preserves the existing role separation and five fictional sample accounts from V4.

## Static tests already run by the author

- `php tests/policy_regression_v5.php` — test arithmetic and core fixed-term policies.
- `php tests/payroll_calendar_policy_test.php` — pay-period and holiday/weekend payday functions.
- `node tests/frontend_js_test.js` — existing DOM/JS suite.
- `node tests/four_role_access_test.js` — static 4-role permissions.
- `node tests/js_syntax_check.js` — embedded frontend JavaScript syntax.
- PHP parser syntax checked for all PHP files in `api/`.

These are **not** substitutes for running the application on your XAMPP/MySQL stack.

## Required live acceptance tests before real payroll use

1. Run fresh and existing-database migrations on a TEST database and verify table constraints/FKs.
2. Login as Admin / HR-Payroll / Manager / Employee and attempt unauthorized routes directly (not only menus).
3. Test Time In at 7:00, 8:00, 8:01, 9:00, and 9:01; include late correction and preview cancellation.
4. Test 5:00 Time Out -> 5:30 authorized OT Time In -> OT Time Out at assigned end; test 5:20 late regular Time Out and no OT assignment.
5. Test 5- vs 6-day schedules, rest days, ordinary and special holidays, and partial hire/separation cutoffs.
6. Use test employees with no leave, paid/unpaid leave, multiple unpaid absences, undertime and late time, plus 13th-month accrual.
7. Test Company Loan offer, acceptance, release, amortization, failed repayment, partial installment and balance reconciliation; verify agency loans are not treated as company loans.
8. Test payroll periods 1-15 / 16-end, 20th/5th paydays, consecutive holidays and local holidays in DB.
9. Independently compare effective-dated SSS / PhilHealth / Pag-IBIG / BIR calculations and remittances with current official tables and sample agency calculators; verify withholding and month-end rounding.
10. Test payroll approval, final release, payouts and adjustments: committed loan ledger rows should reconcile against actual PAID payroll only.

## Important NOT-YET-VERIFIED areas

- This execution environment did not have a working MySQL PDO driver or a running XAMPP browser. **No live DB migrations or end-to-end API + browser + payroll tests were possible.**
- The **365-day divisor is only a proposed choice** for an agreed fixed monthly-paid arrangement covering all calendar days. Verify compensation coverage, minimum wage, and the proper divisor against applicable DOLE guidance before enabling actual wage payments.
- Holiday duty premiums, statutory holiday eligibility on prior-day absences, SIL cash conversion/eligibility, resignation final pay, tax adjustments, and all edge cases are not independently certified here.
- Government contribution tables need a separate dated accuracy audit against official SSS/PhilHealth/Pag-IBIG/BIR rules effective on the payroll date; 2025 tables may not cover future changes.
- Attendance auto-absence reconciliation from legacy versions still needs review against your "Pending Verification" policy before live use.
- All financial transactions require complete integration and concurrency testing on a real database. **Do not process actual salary payments with this unverified build.**

This file is deliberately explicit about what has and has not been verified to avoid false claims of 100% compliance.
