# PMS V17 — Consolidated test build

**Status: testing build only.** PHP and frontend JS syntax checks passed in an offline environment. No MariaDB/XAMPP end-to-end tests or statutory legal certification have been performed. **DO NOT USE THIS BUILD TO PAY REAL EMPLOYEES** until the below tests and HR/legal review pass.

## Included source improvements

1. **Attendance safety:** missing/unverified scans are reported as payroll exceptions instead of silently becoming `ABSENT`; automated absence reconciliation is disabled. Verified legacy attendance remains intact. Payroll calculation will intentionally refuse an employee's unresolved scheduled work days.
2. **Read-only employee payroll preview:** Payroll Processing has an Employee Payroll Check tool to inspect one employee and identify attendance exceptions without writing a payroll row, generating a payslip, or calculating all employees. This is **not** employee-only final payroll processing.
3. **Overtime integrity:** verified OT cannot be cancelled through the ordinary service; historical unrecorded employee response is labeled clearly. Existing HR-authorized-before-OT-scan and early QR capture controls are retained; verify them against a real kiosk.
4. **Leave permissions:** Managers cannot edit leave applications they do not own; leave approvers cannot approve/reject their own requests at the service layer.
5. **Supervisor-based team:** HR's employee form has Assigned Supervisor. Manager team queries include employees explicitly assigned to that Manager across departments, and fall back to same department for legacy employees without an assigned supervisor. Manager-only salary fields are withheld from employee list. Cross-department views and all other team endpoints still need integration testing.
6. **Attendance by cutoff:** a semi-monthly Payroll Period selector populates the existing From/To filter; custom dates remain available.
7. **Personal sidebar:** HR/Manager/Staff have one login with a separate My Personal group including personal attendance, leave, overtime, QR, profile, and payslips. Personal attendance/leave/OT API list calls are server-scoped by the signed-in employee ID. Manager own loan list is enabled by the existing service-side own-record filter; note that HR own-loan view still requires dedicated separation.
8. **Company deductions:** new employee assignments require a total authorized balance and signed-authorization reference; payroll caps installments to the remaining balance, and only after the full period has been actually disbursed and marked `PAID` does the system record and settle installments. Fully paid assignments automatically become Inactive/Completed. **Legacy unlimited active assignments without a total/authorization are not deducted by this build**, and must be reviewed by HR. This does not retroactively write paid installments.
9. **Payroll adjustments:** a saved adjustment can be viewed. The specially designated independent Manager Reviewer can approve/reject documented pending adjustment requests; their view does not expose all payroll or salary details.
10. **Company loan:** HR loan-release button and evidence/reference requirements, with recorded payroll deduction authorization. Newly offered company loans default to no arbitrary flat 5% interest; prior offers are not rewritten.
11. **SSS/Pag-IBIG agency loans:** new registrations remain `PENDING` until HR verifies the actual agency notice and documented deduction consent; new agency loans do not become ACTIVE merely from creation. Payroll excludes legacy agency loans without verified agency evidence and excludes unverified company loan releases.
12. **Reports:** attendance/leave ledger approved leave KPI and Leave by Type chart exclude rejected/cancelled days; historical cancelled/rejected rows still display in detail.
13. **IT Admin:** canonical least-privilege role policy remains, and technical-role wording clarified. The system requires more permission audits on historic/settings endpoints before production.

## Important limitations still needing implementation/review

- **Live verification required:** no active MySQL/MariaDB connection was available to run full end-to-end workflows. Module status is not equivalent to payroll approval.
- **13th-month approval workflow** still needs separation of HR data preparation from independent authorization, particularly when HR receives the payment. Its generation still depends on finalized annual earnings; historic payroll import/reconciliation has not been implemented.
- **HR's personal loan/leave/OT/attendance correction independent review** is not fully implemented. The single Manager Reviewer approval page currently handles *payroll adjustments*, not every other HR personal case.
- **Company loan internal approval authority, no-interest policy, legal permissibility of every deduction**, statutory schedules/tax rules, and 13th-month computation need qualified HR/legal review. Source defaults are not a substitute for lawful payroll policy.
- **Statutory contribution/BIR settings ownership** is not fully split from the existing Admin settings screen. Must independently validate permissions and government schedule data before production.
- **Old archive/purge flows** remain in backend and some UIs; don't use them. Removing them without affecting historical records and tests requires an additional complete audit.
- **Employee-only final payroll processing** is not offered; the new check is read-only. Calculating the entire period still requires every employee's attendance exceptions resolved.
- **No automatic HR conclusion** of whether a missing scan means absence, approved leave, or a missed time-out; HR must resolve using an auditable legitimate source record.
- **Payment posting and remittance** must be reconciled against real supporting evidence. PMS does not transfer bank/agency money.

## SAFE LOCAL INSTALLATION (backup + clone)

1. In phpMyAdmin: **Export a FULL SQL backup** of the existing `attendance_payroll` database. Save the existing `C:\xampp\htdocs\pmsv15` folder separately.
2. **Create a separate test database** (example: `attendance_payroll_v17_test`) and import your backed-up SQL there. Do not post this export publicly (contains emails/password hashes and tokens).
3. Unzip this ZIP into a **new folder** `C:\xampp\htdocs\pmsv17`. The archive's top folder is `pmsv17`. Do not overwrite your working `pmsv15` installation yet.
4. In phpMyAdmin select the **CLONED** database. If its schema has not received V16 migration, first run the prior `PMS_V16_SAFE_DATABASE_MIGRATION.sql` from your V16 package. Then run **`PMS_V17_SAFE_DATABASE_MIGRATION.sql`**. The new migration is included in the project as `SAFE_V17_DATABASE_MIGRATION.sql`.
5. Update the copied project's DB connection settings / environment configuration to point to the **test** database, not the live/old one. Verify the app URL at `http://localhost/pmsv17/` with your local rewrite setup.
6. Test roles (IT Admin, HR, Manager, Staff, kiosk), supervisor assignment across departments, manager own leave approval denial, pending payroll adjustments/Manager reviewer approval, company installment sum and PAID ledger, loan activation evidence, reports, and missing-scan controls.
7. Never create fake government remittances, actual salary payments, or loans just to test; use a test DB and fictitious references marked `DEMO ONLY`.
8. Rollback strategy: stop using `pmsv17`, restore the **database backup** into your TEST database and use original `pmsv15` code. The migration itself does not delete your existing data.

**Important**: A `pmsv15` folder name does not identify source version; ZIP identifies the test build. No password or token from your live SQL dump was embedded in this test ZIP.
